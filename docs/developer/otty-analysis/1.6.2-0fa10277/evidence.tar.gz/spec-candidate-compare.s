
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010146b730 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E>:
10146bc54: d10203ff    	sub	sp, sp, #0x80
10146bc58: 6d0123e9    	stp	d9, d8, [sp, #0x10]
10146bc5c: a9026ffc    	stp	x28, x27, [sp, #0x20]
10146bc60: a90367fa    	stp	x26, x25, [sp, #0x30]
10146bc64: a9045ff8    	stp	x24, x23, [sp, #0x40]
10146bc68: a90557f6    	stp	x22, x21, [sp, #0x50]
10146bc6c: a9064ff4    	stp	x20, x19, [sp, #0x60]
10146bc70: a9077bfd    	stp	x29, x30, [sp, #0x70]
10146bc74: 9101c3fd    	add	x29, sp, #0x70
10146bc78: aa0203f3    	mov	x19, x2
10146bc7c: aa0103f4    	mov	x20, x1
10146bc80: f940001a    	ldr	x26, [x0]
10146bc84: f9400f48    	ldr	x8, [x26, #0x18]
10146bc88: b4000e08    	cbz	x8, 0x10146be48 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x718>
10146bc8c: a9420740    	ldp	x0, x1, [x26, #0x20]
10146bc90: 91002282    	add	x2, x20, #0x8
10146bc94: 97d386fa    	bl	0x10094d87c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a854>
10146bc98: d2800009    	mov	x9, #0x0                ; =0
10146bc9c: d379fc08    	lsr	x8, x0, #57
10146bca0: a9405f58    	ldp	x24, x23, [x26]
10146bca4: 0e010d08    	dup.8b	v8, w8
10146bca8: a9415696    	ldp	x22, x21, [x20, #0x10]
10146bcac: 6f07e7e1    	movi.2d	v1, #0xffffffffffffffff
10146bcb0: 8a17001c    	and	x28, x0, x23
10146bcb4: fc7c6b09    	ldr	d9, [x24, x28]
10146bcb8: 2e288d20    	cmeq.8b	v0, v9, v8
10146bcbc: 9e660008    	fmov	x8, d0
10146bcc0: f201c11b    	ands	x27, x8, #0x8080808080808080
10146bcc4: 54000280    	b.eq	0x10146bd14 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x5e4>
10146bcc8: f90007e9    	str	x9, [sp, #0x8]
10146bccc: dac00368    	rbit	x8, x27
10146bcd0: dac01108    	clz	x8, x8
10146bcd4: 8b480f88    	add	x8, x28, x8, lsr #3
10146bcd8: 8a170108    	and	x8, x8, x23
10146bcdc: cb081719    	sub	x25, x24, x8, lsl #5
10146bce0: f85f0328    	ldur	x8, [x25, #-0x10]
10146bce4: eb0802bf    	cmp	x21, x8
10146bce8: 540000c1    	b.ne	0x10146bd00 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x5d0>
10146bcec: f85e8321    	ldur	x1, [x25, #-0x18]
10146bcf0: aa1603e0    	mov	x0, x22
10146bcf4: aa1503e2    	mov	x2, x21
10146bcf8: 941977c9    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10146bcfc: 34000280    	cbz	w0, 0x10146bd4c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x61c>
10146bd00: d1000768    	sub	x8, x27, #0x1
10146bd04: ea1b011b    	ands	x27, x8, x27
10146bd08: f94007e9    	ldr	x9, [sp, #0x8]
10146bd0c: 6f07e7e1    	movi.2d	v1, #0xffffffffffffffff
10146bd10: 54fffde1    	b.ne	0x10146bccc <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x59c>
10146bd14: 2e218d20    	cmeq.8b	v0, v9, v1
10146bd18: 2e30a800    	umaxv.8b	b0, v0
10146bd1c: 1e260008    	fmov	w8, s0
10146bd20: 37000148    	tbnz	w8, #0x0, 0x10146bd48 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x618>
10146bd24: 91002129    	add	x9, x9, #0x8
10146bd28: 8b090380    	add	x0, x28, x9
10146bd2c: 8a17001c    	and	x28, x0, x23
10146bd30: fc7c6b09    	ldr	d9, [x24, x28]
10146bd34: 2e288d20    	cmeq.8b	v0, v9, v8
10146bd38: 9e660008    	fmov	x8, d0
10146bd3c: f201c11b    	ands	x27, x8, #0x8080808080808080
10146bd40: 54fffc41    	b.ne	0x10146bcc8 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x598>
10146bd44: 17fffff4    	b	0x10146bd14 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x5e4>
10146bd48: d2800019    	mov	x25, #0x0               ; =0
10146bd4c: f9400f48    	ldr	x8, [x26, #0x18]
10146bd50: b40005e8    	cbz	x8, 0x10146be0c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x6dc>
10146bd54: a9420740    	ldp	x0, x1, [x26, #0x20]
10146bd58: 91002262    	add	x2, x19, #0x8
10146bd5c: 97d386c8    	bl	0x10094d87c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a854>
10146bd60: d2800009    	mov	x9, #0x0                ; =0
10146bd64: d379fc08    	lsr	x8, x0, #57
10146bd68: 0e010d08    	dup.8b	v8, w8
10146bd6c: a9415676    	ldp	x22, x21, [x19, #0x10]
10146bd70: 6f07e7e1    	movi.2d	v1, #0xffffffffffffffff
10146bd74: 8a17001b    	and	x27, x0, x23
10146bd78: fc7b6b09    	ldr	d9, [x24, x27]
10146bd7c: 2e288d20    	cmeq.8b	v0, v9, v8
10146bd80: 9e660008    	fmov	x8, d0
10146bd84: f201c11c    	ands	x28, x8, #0x8080808080808080
10146bd88: 54000280    	b.eq	0x10146bdd8 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x6a8>
10146bd8c: f90007e9    	str	x9, [sp, #0x8]
10146bd90: dac00388    	rbit	x8, x28
10146bd94: dac01108    	clz	x8, x8
10146bd98: 8b480f68    	add	x8, x27, x8, lsr #3
10146bd9c: 8a170108    	and	x8, x8, x23
10146bda0: cb08171a    	sub	x26, x24, x8, lsl #5
10146bda4: f85f0348    	ldur	x8, [x26, #-0x10]
10146bda8: eb0802bf    	cmp	x21, x8
10146bdac: 540000c1    	b.ne	0x10146bdc4 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x694>
10146bdb0: f85e8341    	ldur	x1, [x26, #-0x18]
10146bdb4: aa1603e0    	mov	x0, x22
10146bdb8: aa1503e2    	mov	x2, x21
10146bdbc: 94197798    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10146bdc0: 340002c0    	cbz	w0, 0x10146be18 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x6e8>
10146bdc4: d1000788    	sub	x8, x28, #0x1
10146bdc8: ea1c011c    	ands	x28, x8, x28
10146bdcc: f94007e9    	ldr	x9, [sp, #0x8]
10146bdd0: 6f07e7e1    	movi.2d	v1, #0xffffffffffffffff
10146bdd4: 54fffde1    	b.ne	0x10146bd90 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x660>
10146bdd8: 2e218d20    	cmeq.8b	v0, v9, v1
10146bddc: 2e30a800    	umaxv.8b	b0, v0
10146bde0: 1e260008    	fmov	w8, s0
10146bde4: 37000188    	tbnz	w8, #0x0, 0x10146be14 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x6e4>
10146bde8: 91002129    	add	x9, x9, #0x8
10146bdec: 8b090360    	add	x0, x27, x9
10146bdf0: 8a17001b    	and	x27, x0, x23
10146bdf4: fc7b6b09    	ldr	d9, [x24, x27]
10146bdf8: 2e288d20    	cmeq.8b	v0, v9, v8
10146bdfc: 9e660008    	fmov	x8, d0
10146be00: f201c11c    	ands	x28, x8, #0x8080808080808080
10146be04: 54fffc41    	b.ne	0x10146bd8c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x65c>
10146be08: 17fffff4    	b	0x10146bdd8 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x6a8>
10146be0c: b50004f9    	cbnz	x25, 0x10146bea8 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x778>
10146be10: 1400000e    	b	0x10146be48 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x718>
10146be14: d280001a    	mov	x26, #0x0               ; =0
10146be18: b4000119    	cbz	x25, 0x10146be38 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x708>
10146be1c: b400047a    	cbz	x26, 0x10146bea8 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x778>
10146be20: fc5f8340    	ldur	d0, [x26, #-0x8]
10146be24: fc5f8321    	ldur	d1, [x25, #-0x8]
10146be28: 1e612000    	fcmp	d0, d1
10146be2c: 540000c9    	b.ls	0x10146be44 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x714>
10146be30: 540000cb    	b.lt	0x10146be48 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x718>
10146be34: 14000002    	b	0x10146be3c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x70c>
10146be38: b400009a    	cbz	x26, 0x10146be48 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x718>
10146be3c: 52800000    	mov	w0, #0x0                ; =0
10146be40: 1400001b    	b	0x10146beac <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x77c>
10146be44: 5400032b    	b.lt	0x10146bea8 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x778>
10146be48: 3941a688    	ldrb	w8, [x20, #0x69]
10146be4c: 531d7109    	lsl	w9, w8, #3
10146be50: d280400a    	mov	x10, #0x200             ; =512
10146be54: f2a0602a    	movk	x10, #0x301, lsl #16
10146be58: f2c0006a    	movk	x10, #0x3, lsl #32
10146be5c: 9ac92549    	lsr	x9, x10, x9
10146be60: 5280008b    	mov	w11, #0x4               ; =4
10146be64: 7100191f    	cmp	w8, #0x6
10146be68: 1a8b3128    	csel	w8, w9, w11, lo
10146be6c: 12000908    	and	w8, w8, #0x7
10146be70: 3941a669    	ldrb	w9, [x19, #0x69]
10146be74: 531d712c    	lsl	w12, w9, #3
10146be78: 9acc254a    	lsr	x10, x10, x12
10146be7c: 7100193f    	cmp	w9, #0x6
10146be80: 1a8b3149    	csel	w9, w10, w11, lo
10146be84: 12000929    	and	w9, w9, #0x7
10146be88: 6b09011f    	cmp	w8, w9
10146be8c: 1a9f27e0    	cset	w0, lo
10146be90: 540000e1    	b.ne	0x10146beac <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x77c>
10146be94: f9400288    	ldr	x8, [x20]
10146be98: f9400269    	ldr	x9, [x19]
10146be9c: eb09011f    	cmp	x8, x9
10146bea0: 1a9f27e0    	cset	w0, lo
10146bea4: 14000002    	b	0x10146beac <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x77c>
10146bea8: 52800020    	mov	w0, #0x1                ; =1
10146beac: a9477bfd    	ldp	x29, x30, [sp, #0x70]
10146beb0: a9464ff4    	ldp	x20, x19, [sp, #0x60]
10146beb4: a94557f6    	ldp	x22, x21, [sp, #0x50]
10146beb8: a9445ff8    	ldp	x24, x23, [sp, #0x40]
10146bebc: a94367fa    	ldp	x26, x25, [sp, #0x30]
10146bec0: a9426ffc    	ldp	x28, x27, [sp, #0x20]
10146bec4: 6d4123e9    	ldp	d9, d8, [sp, #0x10]
10146bec8: 910203ff    	add	sp, sp, #0x80
10146becc: d65f03c0    	ret
10146bed0: aa0103e2    	mov	x2, x1
10146bed4: a9408408    	ldp	x8, x1, [x0, #0x8]
10146bed8: aa0803e0    	mov	x0, x8
10146bedc: 140e92e2    	b	0x101810a64 <__ZN42_$LT$str$u20$as$u20$core..fmt..Display$GT$3fmt17hdf239df79767b34aE>
10146bee0: d10103ff    	sub	sp, sp, #0x40
10146bee4: a9024ff4    	stp	x20, x19, [sp, #0x20]
10146bee8: a9037bfd    	stp	x29, x30, [sp, #0x30]
10146beec: 9100c3fd    	add	x29, sp, #0x30
10146bef0: 39400028    	ldrb	w8, [x1]
10146bef4: 7100091f    	cmp	w8, #0x2
10146bef8: 540000cc    	b.gt	0x10146bf10 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x7e0>
10146befc: 34000228    	cbz	w8, 0x10146bf40 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x810>
10146bf00: 7100051f    	cmp	w8, #0x1
10146bf04: ad400420    	ldp	q0, q1, [x1]
10146bf08: ad000400    	stp	q0, q1, [x0]
10146bf0c: 14000029    	b	0x10146bfb0 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x880>
10146bf10: 71000d1f    	cmp	w8, #0x3
10146bf14: 540001a0    	b.eq	0x10146bf48 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x818>
10146bf18: 7100111f    	cmp	w8, #0x4
10146bf1c: 54000241    	b.ne	0x10146bf64 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x834>
10146bf20: a9410828    	ldp	x8, x2, [x1, #0x10]
10146bf24: aa0003f3    	mov	x19, x0
10146bf28: 91002000    	add	x0, x0, #0x8
10146bf2c: aa0803e1    	mov	x1, x8
10146bf30: 940017c3    	bl	0x101471e3c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x4aac>
10146bf34: 52800088    	mov	w8, #0x4                ; =4
10146bf38: 39000268    	strb	w8, [x19]
10146bf3c: 1400001d    	b	0x10146bfb0 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x880>
10146bf40: 3900001f    	strb	wzr, [x0]
10146bf44: 1400001b    	b	0x10146bfb0 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x880>
10146bf48: 91002008    	add	x8, x0, #0x8
10146bf4c: aa0003f3    	mov	x19, x0
10146bf50: 91002020    	add	x0, x1, #0x8
10146bf54: 940e8c9e    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10146bf58: 52800068    	mov	w8, #0x3                ; =3
10146bf5c: 39000268    	strb	w8, [x19]
10146bf60: 14000014    	b	0x10146bfb0 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x880>
10146bf64: f9400c28    	ldr	x8, [x1, #0x18]
10146bf68: b4000148    	cbz	x8, 0x10146bf90 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x860>
10146bf6c: f9400428    	ldr	x8, [x1, #0x8]
10146bf70: b4000288    	cbz	x8, 0x10146bfc0 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x890>
10146bf74: aa0003f3    	mov	x19, x0
10146bf78: f9400822    	ldr	x2, [x1, #0x10]
10146bf7c: 910023e0    	add	x0, sp, #0x8
10146bf80: aa0803e1    	mov	x1, x8
10146bf84: 940025bf    	bl	0x101475680 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x82f0>
10146bf88: aa1303e0    	mov	x0, x19
10146bf8c: 14000003    	b	0x10146bf98 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x868>
10146bf90: f90007ff    	str	xzr, [sp, #0x8]
10146bf94: f9000fff    	str	xzr, [sp, #0x18]
10146bf98: 3cc083e0    	ldur	q0, [sp, #0x8]
10146bf9c: 3c808000    	stur	q0, [x0, #0x8]
10146bfa0: f9400fe8    	ldr	x8, [sp, #0x18]
10146bfa4: f9000c08    	str	x8, [x0, #0x18]
10146bfa8: 528000a8    	mov	w8, #0x5                ; =5
10146bfac: 39000008    	strb	w8, [x0]
10146bfb0: a9437bfd    	ldp	x29, x30, [sp, #0x30]
10146bfb4: a9424ff4    	ldp	x20, x19, [sp, #0x20]
10146bfb8: 910103ff    	add	sp, sp, #0x40
10146bfbc: d65f03c0    	ret
10146bfc0: f0006fe0    	adrp	x0, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
10146bfc4: 911ba000    	add	x0, x0, #0x6e8
10146bfc8: 94195e6f    	bl	0x101ac3984 <__ZN4core6option13unwrap_failed17h256cedb8a2d2ba0aE>
10146bfcc: d100c3ff    	sub	sp, sp, #0x30
10146bfd0: a9027bfd    	stp	x29, x30, [sp, #0x20]
10146bfd4: 910083fd    	add	x29, sp, #0x20
10146bfd8: aa0103e8    	mov	x8, x1
10146bfdc: aa0003e5    	mov	x5, x0
10146bfe0: 91002009    	add	x9, x0, #0x8
10146bfe4: f81f83a9    	stur	x9, [x29, #-0x8]
10146bfe8: f0006fe9    	adrp	x9, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
10146bfec: 9110a12b    	add	x11, x9, #0x428
10146bff0: d10023a9    	sub	x9, x29, #0x8
10146bff4: 5280012a    	mov	w10, #0x9               ; =9
10146bff8: a900afe9    	stp	x9, x11, [sp, #0x8]
10146bffc: f90003ea    	str	x10, [sp]
10146c000: d00043a1    	adrp	x1, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10146c004: 91333421    	add	x1, x1, #0xccd
10146c008: d00043a3    	adrp	x3, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10146c00c: 913a6463    	add	x3, x3, #0xe99
10146c010: d0006fe6    	adrp	x6, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
10146c014: 9104c0c6    	add	x6, x6, #0x130
10146c018: d00043a7    	adrp	x7, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10146c01c: 913a90e7    	add	x7, x7, #0xea4
10146c020: aa0803e0    	mov	x0, x8
10146c024: 52800122    	mov	w2, #0x9                ; =9
10146c028: 52800164    	mov	w4, #0xb                ; =11
10146c02c: 940ebc3d    	bl	0x10181b120 <__ZN4core3fmt9Formatter26debug_struct_field2_finish17h99064e3569e8d319E>
10146c030: a9427bfd    	ldp	x29, x30, [sp, #0x20]
10146c034: 9100c3ff    	add	sp, sp, #0x30
10146c038: d65f03c0    	ret
10146c03c: d100c3ff    	sub	sp, sp, #0x30
10146c040: a9027bfd    	stp	x29, x30, [sp, #0x20]
10146c044: 910083fd    	add	x29, sp, #0x20
10146c048: aa0103e8    	mov	x8, x1
10146c04c: f81f83a0    	stur	x0, [x29, #-0x8]
10146c050: d0006fe9    	adrp	x9, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
10146c054: 9111a12b    	add	x11, x9, #0x468
10146c058: d10023a9    	sub	x9, x29, #0x8
10146c05c: 528001aa    	mov	w10, #0xd               ; =13
10146c060: a900afe9    	stp	x9, x11, [sp, #0x8]
10146c064: f90003ea    	str	x10, [sp]
10146c068: d00043a1    	adrp	x1, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10146c06c: 9130a821    	add	x1, x1, #0xc2a
10146c070: d0003583    	adrp	x3, 0x101b1e000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x17014>
10146c074: 91116063    	add	x3, x3, #0x458
10146c078: d0006fe6    	adrp	x6, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
10146c07c: 911120c6    	add	x6, x6, #0x448
10146c080: 91001005    	add	x5, x0, #0x4
10146c084: d00043a7    	adrp	x7, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10146c088: 913ab4e7    	add	x7, x7, #0xead
10146c08c: aa0803e0    	mov	x0, x8
10146c090: 528000a2    	mov	w2, #0x5                ; =5
10146c094: 52800084    	mov	w4, #0x4                ; =4
10146c098: 940ebc22    	bl	0x10181b120 <__ZN4core3fmt9Formatter26debug_struct_field2_finish17h99064e3569e8d319E>
10146c09c: a9427bfd    	ldp	x29, x30, [sp, #0x20]
10146c0a0: 9100c3ff    	add	sp, sp, #0x30
10146c0a4: d65f03c0    	ret
10146c0a8: d10243ff    	sub	sp, sp, #0x90
10146c0ac: a9055ff8    	stp	x24, x23, [sp, #0x50]
10146c0b0: a90657f6    	stp	x22, x21, [sp, #0x60]
10146c0b4: a9074ff4    	stp	x20, x19, [sp, #0x70]
10146c0b8: a9087bfd    	stp	x29, x30, [sp, #0x80]
10146c0bc: 910203fd    	add	x29, sp, #0x80
10146c0c0: aa0403f5    	mov	x21, x4
10146c0c4: aa0303f4    	mov	x20, x3
10146c0c8: aa0203f6    	mov	x22, x2
10146c0cc: aa0103f7    	mov	x23, x1
10146c0d0: aa0003f3    	mov	x19, x0
10146c0d4: aa0403e0    	mov	x0, x4
10146c0d8: 9419787b    	bl	0x101aca2c4 <_writev+0x101aca2c4>
10146c0dc: 93407c18    	sxtw	x24, w0
10146c0e0: 34000400    	cbz	w0, 0x10146c160 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xa30>
10146c0e4: d0003608    	adrp	x8, 0x101b2e000 <__ZN4jiff4span4Span22has_fractional_seconds9SUBSECOND17hdf4148a953a76d03E+0xe5e4>
10146c0e8: 3dc23500    	ldr	q0, [x8, #0x8d0]
10146c0ec: 3d8003e0    	str	q0, [sp]
10146c0f0: a9015bf7    	stp	x23, x22, [sp, #0x10]
10146c0f4: 9100a3e8    	add	x8, sp, #0x28
10146c0f8: aa1703e0    	mov	x0, x23
10146c0fc: aa1603e1    	mov	x1, x22
10146c100: 9400cd99    	bl	0x10149f764 <__ZN8rusqlite14str_for_sqlite17h84f1f243e0beacb0E>
10146c104: d2800276    	mov	x22, #0x13              ; =19
10146c108: f2f00016    	movk	x22, #0x8000, lsl #48
10146c10c: a9428be8    	ldp	x8, x2, [sp, #0x28]
10146c110: b9403be3    	ldr	w3, [sp, #0x38]
10146c114: eb16011f    	cmp	x8, x22
10146c118: 540002e1    	b.ne	0x10146c174 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xa44>
10146c11c: f94023e4    	ldr	x4, [sp, #0x40]
10146c120: aa1503e0    	mov	x0, x21
10146c124: 52800021    	mov	w1, #0x1                ; =1
10146c128: 9419786a    	bl	0x101aca2d0 <_writev+0x101aca2d0>
10146c12c: f9400288    	ldr	x8, [x20]
10146c130: 92f00009    	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10146c134: eb09011f    	cmp	x8, x9
10146c138: 54000342    	b.hs	0x10146c1a0 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xa70>
10146c13c: aa0003e1    	mov	x1, x0
10146c140: 91000509    	add	x9, x8, #0x1
10146c144: f9000289    	str	x9, [x20]
10146c148: 35000340    	cbnz	w0, 0x10146c1b0 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xa80>
10146c14c: f9000288    	str	x8, [x20]
10146c150: 7100071f    	cmp	w24, #0x1
10146c154: 54000061    	b.ne	0x10146c160 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xa30>
10146c158: f9000276    	str	x22, [x19]
10146c15c: 1400000b    	b	0x10146c188 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xa58>
10146c160: d0003608    	adrp	x8, 0x101b2e000 <__ZN4jiff4span4Span22has_fractional_seconds9SUBSECOND17hdf4148a953a76d03E+0xe5e4>
10146c164: 3dc23900    	ldr	q0, [x8, #0x8e0]
10146c168: 3d800260    	str	q0, [x19]
10146c16c: f9000a78    	str	x24, [x19, #0x10]
10146c170: 14000006    	b	0x10146c188 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xa58>
10146c174: b9403fe9    	ldr	w9, [sp, #0x3c]
10146c178: a9442fea    	ldp	x10, x11, [sp, #0x40]
10146c17c: a9000a68    	stp	x8, x2, [x19]
10146c180: 29022663    	stp	w3, w9, [x19, #0x10]
10146c184: a901ae6a    	stp	x10, x11, [x19, #0x18]
10146c188: a9487bfd    	ldp	x29, x30, [sp, #0x80]
10146c18c: a9474ff4    	ldp	x20, x19, [sp, #0x70]
10146c190: a94657f6    	ldp	x22, x21, [sp, #0x60]
10146c194: a9455ff8    	ldp	x24, x23, [sp, #0x50]
10146c198: 910243ff    	add	sp, sp, #0x90
10146c19c: d65f03c0    	ret
10146c1a0: d0006fe0    	adrp	x0, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
10146c1a4: 91148000    	add	x0, x0, #0x520
10146c1a8: 94195d38    	bl	0x101ac3688 <__ZN4core4cell30panic_already_mutably_borrowed17h517b4291a1fe68f0E>
10146c1ac: d4200020    	brk	#0x1
10146c1b0: f9400a80    	ldr	x0, [x20, #0x10]
10146c1b4: 9100a3e8    	add	x8, sp, #0x28
10146c1b8: 941896fe    	bl	0x101a91db0 <__ZN8rusqlite5error17error_from_handle17h9d46f73c365044f5E>
10146c1bc: a9428be8    	ldp	x8, x2, [sp, #0x28]
10146c1c0: 294727e3    	ldp	w3, w9, [sp, #0x38]
10146c1c4: a9442fea    	ldp	x10, x11, [sp, #0x40]
10146c1c8: f940028c    	ldr	x12, [x20]
10146c1cc: d100058c    	sub	x12, x12, #0x1
10146c1d0: f900028c    	str	x12, [x20]
10146c1d4: eb16011f    	cmp	x8, x22
10146c1d8: 54fffbc0    	b.eq	0x10146c150 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xa20>
10146c1dc: 17ffffe8    	b	0x10146c17c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xa4c>
