
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010147c70c <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE>:
10147c784: d10243ff    	sub	sp, sp, #0x90
10147c788: a9036ffc    	stp	x28, x27, [sp, #0x30]
10147c78c: a90467fa    	stp	x26, x25, [sp, #0x40]
10147c790: a9055ff8    	stp	x24, x23, [sp, #0x50]
10147c794: a90657f6    	stp	x22, x21, [sp, #0x60]
10147c798: a9074ff4    	stp	x20, x19, [sp, #0x70]
10147c79c: a9087bfd    	stp	x29, x30, [sp, #0x80]
10147c7a0: 910203fd    	add	x29, sp, #0x80
10147c7a4: aa0003f3    	mov	x19, x0
10147c7a8: 52800108    	mov	w8, #0x8                ; =8
10147c7ac: a90023ff    	stp	xzr, x8, [sp]
10147c7b0: a9017fff    	stp	xzr, xzr, [sp, #0x10]
10147c7b4: 52800028    	mov	w8, #0x1                ; =1
10147c7b8: a9027fe8    	stp	x8, xzr, [sp, #0x20]
10147c7bc: b40019e2    	cbz	x2, 0x10147caf8 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x3ec>
10147c7c0: aa0103f5    	mov	x21, x1
10147c7c4: d2800014    	mov	x20, #0x0               ; =0
10147c7c8: 52800009    	mov	w9, #0x0                ; =0
10147c7cc: 52800018    	mov	w24, #0x0               ; =0
10147c7d0: 8b020039    	add	x25, x1, x2
10147c7d4: 5280003a    	mov	w26, #0x1               ; =1
10147c7d8: 5280031c    	mov	w28, #0x18              ; =24
10147c7dc: 52800028    	mov	w8, #0x1                ; =1
10147c7e0: 52800036    	mov	w22, #0x1               ; =1
10147c7e4: 14000005    	b	0x10147c7f8 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0xec>
10147c7e8: 52000318    	eor	w24, w24, #0x1
10147c7ec: 52800029    	mov	w9, #0x1                ; =1
10147c7f0: eb1902bf    	cmp	x21, x25
10147c7f4: 540015a0    	b.eq	0x10147caa8 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x39c>
10147c7f8: aa1503ea    	mov	x10, x21
10147c7fc: 38c0154b    	ldrsb	w11, [x10], #0x1
10147c800: 12001d77    	and	w23, w11, #0xff
10147c804: 37f800ab    	tbnz	w11, #0x1f, 0x10147c818 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x10c>
10147c808: aa0a03f5    	mov	x21, x10
10147c80c: 710082ff    	cmp	w23, #0x20
10147c810: 540003c1    	b.ne	0x10147c888 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x17c>
10147c814: 14000022    	b	0x10147c89c <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x190>
10147c818: 394006aa    	ldrb	w10, [x21, #0x1]
10147c81c: 1200154b    	and	w11, w10, #0x3f
10147c820: 710382ff    	cmp	w23, #0xe0
10147c824: 540001e3    	b.lo	0x10147c860 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x154>
10147c828: 120012ea    	and	w10, w23, #0x1f
10147c82c: 39400aac    	ldrb	w12, [x21, #0x2]
10147c830: 1200158c    	and	w12, w12, #0x3f
10147c834: 2a0b198b    	orr	w11, w12, w11, lsl #6
10147c838: 7103c2ff    	cmp	w23, #0xf0
10147c83c: 540001e3    	b.lo	0x10147c878 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x16c>
10147c840: 39400eac    	ldrb	w12, [x21, #0x3]
10147c844: 910012b5    	add	x21, x21, #0x4
10147c848: 1200158c    	and	w12, w12, #0x3f
10147c84c: 2a0b1997    	orr	w23, w12, w11, lsl #6
10147c850: 330e0957    	bfi	w23, w10, #18, #3
10147c854: 710082ff    	cmp	w23, #0x20
10147c858: 54000181    	b.ne	0x10147c888 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x17c>
10147c85c: 14000010    	b	0x10147c89c <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x190>
10147c860: 91000ab5    	add	x21, x21, #0x2
10147c864: 331a12eb    	bfi	w11, w23, #6, #5
10147c868: aa0b03f7    	mov	x23, x11
10147c86c: 710082ff    	cmp	w23, #0x20
10147c870: 540000c1    	b.ne	0x10147c888 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x17c>
10147c874: 1400000a    	b	0x10147c89c <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x190>
10147c878: 91000eb5    	add	x21, x21, #0x3
10147c87c: 2a0a3177    	orr	w23, w11, w10, lsl #12
10147c880: 710082ff    	cmp	w23, #0x20
10147c884: 540000c0    	b.eq	0x10147c89c <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x190>
10147c888: 71008aff    	cmp	w23, #0x22
10147c88c: 54fffae0    	b.eq	0x10147c7e8 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0xdc>
10147c890: 510026ea    	sub	w10, w23, #0x9
10147c894: 7100155f    	cmp	w10, #0x5
10147c898: 54000142    	b.hs	0x10147c8c0 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x1b4>
10147c89c: 36000638    	tbz	w24, #0x0, 0x10147c960 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x254>
10147c8a0: 52800036    	mov	w22, #0x1               ; =1
10147c8a4: aa1603fb    	mov	x27, x22
10147c8a8: f9400fe9    	ldr	x9, [sp, #0x18]
10147c8ac: cb140129    	sub	x9, x9, x20
10147c8b0: eb0902df    	cmp	x22, x9
10147c8b4: aa1403e9    	mov	x9, x20
10147c8b8: 540002e9    	b.ls	0x10147c914 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x208>
10147c8bc: 14000052    	b	0x10147ca04 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x2f8>
10147c8c0: 710202ff    	cmp	w23, #0x80
10147c8c4: 540001a3    	b.lo	0x10147c8f8 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x1ec>
10147c8c8: 53087eea    	lsr	w10, w23, #8
10147c8cc: 71007d5f    	cmp	w10, #0x1f
10147c8d0: 540002ac    	b.gt	0x10147c924 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x218>
10147c8d4: 340003aa    	cbz	w10, 0x10147c948 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x23c>
10147c8d8: 7100595f    	cmp	w10, #0x16
10147c8dc: 540007c1    	b.ne	0x10147c9d4 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x2c8>
10147c8e0: 5282d00a    	mov	w10, #0x1680            ; =5760
10147c8e4: 6b0a02ff    	cmp	w23, w10
10147c8e8: 1a9f17ea    	cset	w10, eq
10147c8ec: 2a2a030a    	orn	w10, w24, w10
10147c8f0: 3600038a    	tbz	w10, #0x0, 0x10147c960 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x254>
10147c8f4: 14000038    	b	0x10147c9d4 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x2c8>
10147c8f8: 5280003b    	mov	w27, #0x1               ; =1
10147c8fc: 52800036    	mov	w22, #0x1               ; =1
10147c900: f9400fe9    	ldr	x9, [sp, #0x18]
10147c904: cb140129    	sub	x9, x9, x20
10147c908: eb0902df    	cmp	x22, x9
10147c90c: aa1403e9    	mov	x9, x20
10147c910: 540007a8    	b.hi	0x10147ca04 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x2f8>
10147c914: 8b090109    	add	x9, x8, x9
10147c918: 3600089b    	tbz	w27, #0x0, 0x10147ca28 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x31c>
10147c91c: 39000137    	strb	w23, [x9]
10147c920: 1400005d    	b	0x10147ca94 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x388>
10147c924: 7100815f    	cmp	w10, #0x20
10147c928: 54000480    	b.eq	0x10147c9b8 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x2ac>
10147c92c: 7100c15f    	cmp	w10, #0x30
10147c930: 54000521    	b.ne	0x10147c9d4 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x2c8>
10147c934: 71400eff    	cmp	w23, #0x3, lsl #12      ; =0x3000
10147c938: 1a9f17ea    	cset	w10, eq
10147c93c: 2a2a030a    	orn	w10, w24, w10
10147c940: 3600010a    	tbz	w10, #0x0, 0x10147c960 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x254>
10147c944: 14000024    	b	0x10147c9d4 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x2c8>
10147c948: 92401eea    	and	x10, x23, #0xff
10147c94c: d000490b    	adrp	x11, 0x101d9e000 <__ZN10serde_core2de5impls79_$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$std..time..SystemTime$GT$11deserialize14check_overflow13NANOS_PER_SEC17hdc7a2dcd898dff25E+0xffe0>
10147c950: 91239d6b    	add	x11, x11, #0x8e7
10147c954: 386a696a    	ldrb	w10, [x11, x10]
10147c958: 2a2a030a    	orn	w10, w24, w10
10147c95c: 370003ca    	tbnz	w10, #0x0, 0x10147c9d4 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x2c8>
10147c960: 36000289    	tbz	w9, #0x0, 0x10147c9b0 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x2a4>
10147c964: a9415ffb    	ldp	x27, x23, [sp, #0x10]
10147c968: a901ebff    	stp	xzr, x26, [sp, #0x18]
10147c96c: f90017ff    	str	xzr, [sp, #0x28]
10147c970: f94003e8    	ldr	x8, [sp]
10147c974: eb08037f    	cmp	x27, x8
10147c978: 54000061    	b.ne	0x10147c984 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x278>
10147c97c: 910003e0    	mov	x0, sp
10147c980: 9419187c    	bl	0x101ac2b70 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hb575521872840d8cE>
10147c984: 52800009    	mov	w9, #0x0                ; =0
10147c988: f94007e8    	ldr	x8, [sp, #0x8]
10147c98c: 9b1c2368    	madd	x8, x27, x28, x8
10147c990: a9005917    	stp	x23, x22, [x8]
10147c994: f9000914    	str	x20, [x8, #0x10]
10147c998: 91000768    	add	x8, x27, #0x1
10147c99c: f9000be8    	str	x8, [sp, #0x10]
10147c9a0: 52800028    	mov	w8, #0x1                ; =1
10147c9a4: 52800036    	mov	w22, #0x1               ; =1
10147c9a8: d2800014    	mov	x20, #0x0               ; =0
10147c9ac: 17ffff91    	b	0x10147c7f0 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0xe4>
10147c9b0: 52800009    	mov	w9, #0x0                ; =0
10147c9b4: 17ffff8f    	b	0x10147c7f0 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0xe4>
10147c9b8: 92401eea    	and	x10, x23, #0xff
10147c9bc: d000490b    	adrp	x11, 0x101d9e000 <__ZN10serde_core2de5impls79_$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$std..time..SystemTime$GT$11deserialize14check_overflow13NANOS_PER_SEC17hdc7a2dcd898dff25E+0xffe0>
10147c9c0: 91239d6b    	add	x11, x11, #0x8e7
10147c9c4: 386a696a    	ldrb	w10, [x11, x10]
10147c9c8: 5301054a    	ubfx	w10, w10, #1, #1
10147c9cc: 2a2a030a    	orn	w10, w24, w10
10147c9d0: 3607fc8a    	tbz	w10, #0x0, 0x10147c960 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x254>
10147c9d4: 714042ff    	cmp	w23, #0x10, lsl #12     ; =0x10000
10147c9d8: 52800069    	mov	w9, #0x3                ; =3
10147c9dc: 9a893529    	cinc	x9, x9, hs
10147c9e0: 712002ff    	cmp	w23, #0x800
10147c9e4: 2a1f03fb    	mov	w27, wzr
10147c9e8: 5280004a    	mov	w10, #0x2               ; =2
10147c9ec: 9a893156    	csel	x22, x10, x9, lo
10147c9f0: f9400fe9    	ldr	x9, [sp, #0x18]
10147c9f4: cb140129    	sub	x9, x9, x20
10147c9f8: eb0902df    	cmp	x22, x9
10147c9fc: aa1403e9    	mov	x9, x20
10147ca00: 54fff8a9    	b.ls	0x10147c914 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x208>
10147ca04: 910063e0    	add	x0, sp, #0x18
10147ca08: aa1403e1    	mov	x1, x20
10147ca0c: aa1603e2    	mov	x2, x22
10147ca10: 52800023    	mov	w3, #0x1                ; =1
10147ca14: 52800024    	mov	w4, #0x1                ; =1
10147ca18: 9416af8e    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10147ca1c: a94227e8    	ldp	x8, x9, [sp, #0x20]
10147ca20: 8b090109    	add	x9, x8, x9
10147ca24: 3707f7db    	tbnz	w27, #0x0, 0x10147c91c <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x210>
10147ca28: 12800fea    	mov	w10, #-0x80             ; =-128
10147ca2c: 330016ea    	bfxil	w10, w23, #0, #6
10147ca30: 712002ff    	cmp	w23, #0x800
10147ca34: 540000c2    	b.hs	0x10147ca4c <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x340>
10147ca38: 53067eeb    	lsr	w11, w23, #6
10147ca3c: 321a056b    	orr	w11, w11, #0xc0
10147ca40: 3900012b    	strb	w11, [x9]
10147ca44: 3900052a    	strb	w10, [x9, #0x1]
10147ca48: 14000013    	b	0x10147ca94 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x388>
10147ca4c: 12800feb    	mov	w11, #-0x80             ; =-128
10147ca50: 33062eeb    	bfxil	w11, w23, #6, #6
10147ca54: 714042ff    	cmp	w23, #0x10, lsl #12     ; =0x10000
10147ca58: 540000e2    	b.hs	0x10147ca74 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x368>
10147ca5c: 530c7eec    	lsr	w12, w23, #12
10147ca60: 321b098c    	orr	w12, w12, #0xe0
10147ca64: 3900012c    	strb	w12, [x9]
10147ca68: 3900052b    	strb	w11, [x9, #0x1]
10147ca6c: 3900092a    	strb	w10, [x9, #0x2]
10147ca70: 14000009    	b	0x10147ca94 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x388>
10147ca74: 12800fec    	mov	w12, #-0x80             ; =-128
10147ca78: 53127eed    	lsr	w13, w23, #18
10147ca7c: 321c6dad    	orr	w13, w13, #0xfffffff0
10147ca80: 3900012d    	strb	w13, [x9]
10147ca84: 330c46ec    	bfxil	w12, w23, #12, #6
10147ca88: 3900052c    	strb	w12, [x9, #0x1]
10147ca8c: 3900092b    	strb	w11, [x9, #0x2]
10147ca90: 39000d2a    	strb	w10, [x9, #0x3]
10147ca94: 8b1402d4    	add	x20, x22, x20
10147ca98: f90017f4    	str	x20, [sp, #0x28]
10147ca9c: 52800029    	mov	w9, #0x1                ; =1
10147caa0: aa0803f6    	mov	x22, x8
10147caa4: 17ffff53    	b	0x10147c7f0 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0xe4>
10147caa8: f9400ff5    	ldr	x21, [sp, #0x18]
10147caac: 36000309    	tbz	w9, #0x0, 0x10147cb0c <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x400>
10147cab0: f94013f6    	ldr	x22, [sp, #0x20]
10147cab4: f9400bf7    	ldr	x23, [sp, #0x10]
10147cab8: f94003e8    	ldr	x8, [sp]
10147cabc: eb0802ff    	cmp	x23, x8
10147cac0: 54000061    	b.ne	0x10147cacc <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x3c0>
10147cac4: 910003e0    	mov	x0, sp
10147cac8: 9419182a    	bl	0x101ac2b70 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hb575521872840d8cE>
10147cacc: f94007e8    	ldr	x8, [sp, #0x8]
10147cad0: 52800309    	mov	w9, #0x18               ; =24
10147cad4: 9b0922e8    	madd	x8, x23, x9, x8
10147cad8: a9005915    	stp	x21, x22, [x8]
10147cadc: f9000914    	str	x20, [x8, #0x10]
10147cae0: 910006e8    	add	x8, x23, #0x1
10147cae4: f9000be8    	str	x8, [sp, #0x10]
10147cae8: f9000a68    	str	x8, [x19, #0x10]
10147caec: 3dc003e0    	ldr	q0, [sp]
10147caf0: 3d800260    	str	q0, [x19]
10147caf4: 1400000f    	b	0x10147cb30 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x424>
10147caf8: 3dc003e0    	ldr	q0, [sp]
10147cafc: 3d800260    	str	q0, [x19]
10147cb00: f9400be8    	ldr	x8, [sp, #0x10]
10147cb04: f9000a68    	str	x8, [x19, #0x10]
10147cb08: 1400000a    	b	0x10147cb30 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x424>
10147cb0c: 3dc003e0    	ldr	q0, [sp]
10147cb10: 3d800260    	str	q0, [x19]
10147cb14: f9400be8    	ldr	x8, [sp, #0x10]
10147cb18: f9000a68    	str	x8, [x19, #0x10]
10147cb1c: b40000b5    	cbz	x21, 0x10147cb30 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x424>
10147cb20: f94013e0    	ldr	x0, [sp, #0x20]
10147cb24: aa1503e1    	mov	x1, x21
10147cb28: 52800022    	mov	w2, #0x1                ; =1
10147cb2c: 97d886ec    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147cb30: a9487bfd    	ldp	x29, x30, [sp, #0x80]
10147cb34: a9474ff4    	ldp	x20, x19, [sp, #0x70]
10147cb38: a94657f6    	ldp	x22, x21, [sp, #0x60]
10147cb3c: a9455ff8    	ldp	x24, x23, [sp, #0x50]
10147cb40: a94467fa    	ldp	x26, x25, [sp, #0x40]
10147cb44: a9436ffc    	ldp	x28, x27, [sp, #0x30]
10147cb48: 910243ff    	add	sp, sp, #0x90
10147cb4c: d65f03c0    	ret
10147cb50: aa0003f3    	mov	x19, x0
10147cb54: 1400000c    	b	0x10147cb84 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x478>
10147cb58: aa0003f3    	mov	x19, x0
10147cb5c: b40001f5    	cbz	x21, 0x10147cb98 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x48c>
10147cb60: aa1603e0    	mov	x0, x22
10147cb64: aa1503e1    	mov	x1, x21
10147cb68: 1400000a    	b	0x10147cb90 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x484>
10147cb6c: aa0003f3    	mov	x19, x0
10147cb70: b40000b7    	cbz	x23, 0x10147cb84 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x478>
10147cb74: aa1603e0    	mov	x0, x22
10147cb78: aa1703e1    	mov	x1, x23
10147cb7c: 52800022    	mov	w2, #0x1                ; =1
10147cb80: 97d886d7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147cb84: f9400fe1    	ldr	x1, [sp, #0x18]
10147cb88: b4000081    	cbz	x1, 0x10147cb98 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x48c>
10147cb8c: f94013e0    	ldr	x0, [sp, #0x20]
10147cb90: 52800022    	mov	w2, #0x1                ; =1
10147cb94: 97d886d2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147cb98: 910003e0    	mov	x0, sp
10147cb9c: 97d317dc    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10147cba0: aa1303e0    	mov	x0, x19
10147cba4: 9419328c    	bl	0x101ac95d4 <_writev+0x101ac95d4>
