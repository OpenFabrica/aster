
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010142ebbc <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E>:
10142ebbc: a9bb67fa    	stp	x26, x25, [sp, #-0x50]!
10142ebc0: a9015ff8    	stp	x24, x23, [sp, #0x10]
10142ebc4: a90257f6    	stp	x22, x21, [sp, #0x20]
10142ebc8: a9034ff4    	stp	x20, x19, [sp, #0x30]
10142ebcc: a9047bfd    	stp	x29, x30, [sp, #0x40]
10142ebd0: 910103fd    	add	x29, sp, #0x40
10142ebd4: f9404c08    	ldr	x8, [x0, #0x98]
10142ebd8: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10142ebdc: eb09011f    	cmp	x8, x9
10142ebe0: 540005c0    	b.eq	0x10142ec98 <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0xdc>
10142ebe4: f9405408    	ldr	x8, [x0, #0xa8]
10142ebe8: b4000588    	cbz	x8, 0x10142ec98 <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0xdc>
10142ebec: aa0203f4    	mov	x20, x2
10142ebf0: aa0103f5    	mov	x21, x1
10142ebf4: f9405013    	ldr	x19, [x0, #0xa0]
10142ebf8: 52801c09    	mov	w9, #0xe0               ; =224
10142ebfc: 9b094d16    	madd	x22, x8, x9, x19
10142ec00: d2f00017    	mov	x23, #-0x8000000000000000 ; =-9223372036854775808
10142ec04: 14000004    	b	0x10142ec14 <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0x58>
10142ec08: 91038273    	add	x19, x19, #0xe0
10142ec0c: eb16027f    	cmp	x19, x22
10142ec10: 54000440    	b.eq	0x10142ec98 <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0xdc>
10142ec14: f9403668    	ldr	x8, [x19, #0x68]
10142ec18: eb17011f    	cmp	x8, x23
10142ec1c: 54000120    	b.eq	0x10142ec40 <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0x84>
10142ec20: f9403e68    	ldr	x8, [x19, #0x78]
10142ec24: eb14011f    	cmp	x8, x20
10142ec28: 540000c1    	b.ne	0x10142ec40 <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0x84>
10142ec2c: f9403a60    	ldr	x0, [x19, #0x70]
10142ec30: aa1503e1    	mov	x1, x21
10142ec34: aa1403e2    	mov	x2, x20
10142ec38: 941a6bf9    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10142ec3c: 34000300    	cbz	w0, 0x10142ec9c <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0xe0>
10142ec40: f9406668    	ldr	x8, [x19, #0xc8]
10142ec44: eb17011f    	cmp	x8, x23
10142ec48: 54fffe00    	b.eq	0x10142ec08 <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0x4c>
10142ec4c: f9406e68    	ldr	x8, [x19, #0xd8]
10142ec50: b4fffdc8    	cbz	x8, 0x10142ec08 <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0x4c>
10142ec54: f9406a69    	ldr	x9, [x19, #0xd0]
10142ec58: 8b080508    	add	x8, x8, x8, lsl #1
10142ec5c: d37df118    	lsl	x24, x8, #3
10142ec60: 91004139    	add	x25, x9, #0x10
10142ec64: 14000004    	b	0x10142ec74 <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0xb8>
10142ec68: 91006339    	add	x25, x25, #0x18
10142ec6c: f1006318    	subs	x24, x24, #0x18
10142ec70: 54fffcc0    	b.eq	0x10142ec08 <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0x4c>
10142ec74: f9400328    	ldr	x8, [x25]
10142ec78: eb14011f    	cmp	x8, x20
10142ec7c: 54ffff61    	b.ne	0x10142ec68 <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0xac>
10142ec80: f85f8320    	ldur	x0, [x25, #-0x8]
10142ec84: aa1503e1    	mov	x1, x21
10142ec88: aa1403e2    	mov	x2, x20
10142ec8c: 941a6be4    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10142ec90: 35fffec0    	cbnz	w0, 0x10142ec68 <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0xac>
10142ec94: 14000002    	b	0x10142ec9c <__ZN17otty_autocomplete4spec14CompletionSpec15find_subcommand17he59b78ed0cfe6189E+0xe0>
10142ec98: d2800013    	mov	x19, #0x0               ; =0
10142ec9c: aa1303e0    	mov	x0, x19
10142eca0: a9447bfd    	ldp	x29, x30, [sp, #0x40]
10142eca4: a9434ff4    	ldp	x20, x19, [sp, #0x30]
10142eca8: a94257f6    	ldp	x22, x21, [sp, #0x20]
10142ecac: a9415ff8    	ldp	x24, x23, [sp, #0x10]
10142ecb0: a8c567fa    	ldp	x26, x25, [sp], #0x50
10142ecb4: d65f03c0    	ret

000000010142ecb8 <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E>:
10142ecb8: f9400008    	ldr	x8, [x0]
10142ecbc: f1000d1f    	cmp	x8, #0x3
10142ecc0: 54000100    	b.eq	0x10142ece0 <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E+0x28>
10142ecc4: f100111f    	cmp	x8, #0x4
10142ecc8: 54000101    	b.ne	0x10142ece8 <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E+0x30>
10142eccc: 52800008    	mov	w8, #0x0                ; =0
10142ecd0: 52800009    	mov	w9, #0x0                ; =0
10142ecd4: 12000120    	and	w0, w9, #0x1
10142ecd8: 12000101    	and	w1, w8, #0x1
10142ecdc: d65f03c0    	ret
10142ece0: a9412800    	ldp	x0, x10, [x0, #0x10]
10142ece4: 14000002    	b	0x10142ecec <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E+0x34>
10142ece8: 5280002a    	mov	w10, #0x1               ; =1
10142ecec: 52800008    	mov	w8, #0x0                ; =0
10142ecf0: 52800009    	mov	w9, #0x0                ; =0
10142ecf4: 52800d0b    	mov	w11, #0x68              ; =104
10142ecf8: 9b0b014a    	madd	x10, x10, x11, x0
10142ecfc: 528deccb    	mov	w11, #0x6f66            ; =28518
10142ed00: 72ac8d8b    	movk	w11, #0x646c, lsl #16
10142ed04: 528cac8c    	mov	w12, #0x6564            ; =25956
10142ed08: 72ae6e4c    	movk	w12, #0x7372, lsl #16
10142ed0c: d28d2ccd    	mov	x13, #0x6966            ; =26982
10142ed10: f2acad8d    	movk	x13, #0x656c, lsl #16
10142ed14: f2cc2e0d    	movk	x13, #0x6170, lsl #32
10142ed18: f2ed0e8d    	movk	x13, #0x6874, lsl #48
10142ed1c: 52800e6e    	mov	w14, #0x73              ; =115
10142ed20: 5280030f    	mov	w15, #0x18              ; =24
10142ed24: eb0a001f    	cmp	x0, x10
10142ed28: 54fffd60    	b.eq	0x10142ecd4 <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E+0x1c>
10142ed2c: aa0003e1    	mov	x1, x0
10142ed30: f8468410    	ldr	x16, [x0], #0x68
10142ed34: f1000a1f    	cmp	x16, #0x2
10142ed38: 54ffff60    	b.eq	0x10142ed24 <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E+0x6c>
10142ed3c: 370000d0    	tbnz	w16, #0x0, 0x10142ed54 <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E+0x9c>
10142ed40: f9400c30    	ldr	x16, [x1, #0x18]
10142ed44: b4ffff10    	cbz	x16, 0x10142ed24 <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E+0x6c>
10142ed48: f9400831    	ldr	x17, [x1, #0x10]
10142ed4c: 9b0f4610    	madd	x16, x16, x15, x17
10142ed50: 14000003    	b	0x10142ed5c <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E+0xa4>
10142ed54: 91002031    	add	x17, x1, #0x8
10142ed58: 91008030    	add	x16, x1, #0x20
10142ed5c: 91006231    	add	x17, x17, #0x18
10142ed60: 9101a020    	add	x0, x1, #0x68
10142ed64: 1400000b    	b	0x10142ed90 <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E+0xd8>
10142ed68: b9400022    	ldr	w2, [x1]
10142ed6c: b8403021    	ldur	w1, [x1, #0x3]
10142ed70: 6b0b005f    	cmp	w2, w11
10142ed74: 7a4c0020    	ccmp	w1, w12, #0x0, eq
10142ed78: 1a9f17e1    	cset	w1, eq
10142ed7c: 2a080028    	orr	w8, w1, w8
10142ed80: 91006231    	add	x17, x17, #0x18
10142ed84: d1006221    	sub	x1, x17, #0x18
10142ed88: eb10003f    	cmp	x1, x16
10142ed8c: 54fffcc0    	b.eq	0x10142ed24 <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E+0x6c>
10142ed90: a97f0a21    	ldp	x1, x2, [x17, #-0x10]
10142ed94: f1001c5f    	cmp	x2, #0x7
10142ed98: 54fffe80    	b.eq	0x10142ed68 <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E+0xb0>
10142ed9c: f100245f    	cmp	x2, #0x9
10142eda0: 54ffff01    	b.ne	0x10142ed80 <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E+0xc8>
10142eda4: f9400022    	ldr	x2, [x1]
10142eda8: 39402021    	ldrb	w1, [x1, #0x8]
10142edac: eb0d005f    	cmp	x2, x13
10142edb0: 7a4e0020    	ccmp	w1, w14, #0x0, eq
10142edb4: 1a9f17e1    	cset	w1, eq
10142edb8: 2a080028    	orr	w8, w1, w8
10142edbc: 2a090029    	orr	w9, w1, w9
10142edc0: 17fffff0    	b	0x10142ed80 <__ZN17otty_autocomplete4spec14CompletionSpec18filepath_templates17h00f485c12d63ebc3E+0xc8>

000000010142edc4 <__ZN17otty_autocomplete4spec14CompletionSpec18find_option_direct17h3feee326741eac69E>:
10142edc4: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
10142edc8: a90157f6    	stp	x22, x21, [sp, #0x10]
10142edcc: a9024ff4    	stp	x20, x19, [sp, #0x20]
10142edd0: a9037bfd    	stp	x29, x30, [sp, #0x30]
10142edd4: 9100c3fd    	add	x29, sp, #0x30
10142edd8: f9405808    	ldr	x8, [x0, #0xb0]
10142eddc: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10142ede0: eb09011f    	cmp	x8, x9
10142ede4: 540003e0    	b.eq	0x10142ee60 <__ZN17otty_autocomplete4spec14CompletionSpec18find_option_direct17h3feee326741eac69E+0x9c>
10142ede8: f9406008    	ldr	x8, [x0, #0xc0]
10142edec: b40003a8    	cbz	x8, 0x10142ee60 <__ZN17otty_autocomplete4spec14CompletionSpec18find_option_direct17h3feee326741eac69E+0x9c>
10142edf0: aa0203f3    	mov	x19, x2
10142edf4: aa0103f4    	mov	x20, x1
10142edf8: f9405c15    	ldr	x21, [x0, #0xb8]
10142edfc: 52801309    	mov	w9, #0x98               ; =152
10142ee00: 9b095516    	madd	x22, x8, x9, x21
10142ee04: 14000004    	b	0x10142ee14 <__ZN17otty_autocomplete4spec14CompletionSpec18find_option_direct17h3feee326741eac69E+0x50>
10142ee08: 910262b5    	add	x21, x21, #0x98
10142ee0c: eb1602bf    	cmp	x21, x22
10142ee10: 54000280    	b.eq	0x10142ee60 <__ZN17otty_autocomplete4spec14CompletionSpec18find_option_direct17h3feee326741eac69E+0x9c>
10142ee14: f9403ea8    	ldr	x8, [x21, #0x78]
10142ee18: b4ffff88    	cbz	x8, 0x10142ee08 <__ZN17otty_autocomplete4spec14CompletionSpec18find_option_direct17h3feee326741eac69E+0x44>
10142ee1c: f9403aa9    	ldr	x9, [x21, #0x70]
10142ee20: 8b080508    	add	x8, x8, x8, lsl #1
10142ee24: d37df117    	lsl	x23, x8, #3
10142ee28: 91004138    	add	x24, x9, #0x10
10142ee2c: 14000004    	b	0x10142ee3c <__ZN17otty_autocomplete4spec14CompletionSpec18find_option_direct17h3feee326741eac69E+0x78>
10142ee30: 91006318    	add	x24, x24, #0x18
10142ee34: f10062f7    	subs	x23, x23, #0x18
10142ee38: 54fffe80    	b.eq	0x10142ee08 <__ZN17otty_autocomplete4spec14CompletionSpec18find_option_direct17h3feee326741eac69E+0x44>
10142ee3c: f9400308    	ldr	x8, [x24]
10142ee40: eb13011f    	cmp	x8, x19
10142ee44: 54ffff61    	b.ne	0x10142ee30 <__ZN17otty_autocomplete4spec14CompletionSpec18find_option_direct17h3feee326741eac69E+0x6c>
10142ee48: f85f8300    	ldur	x0, [x24, #-0x8]
10142ee4c: aa1403e1    	mov	x1, x20
10142ee50: aa1303e2    	mov	x2, x19
10142ee54: 941a6b72    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10142ee58: 35fffec0    	cbnz	w0, 0x10142ee30 <__ZN17otty_autocomplete4spec14CompletionSpec18find_option_direct17h3feee326741eac69E+0x6c>
10142ee5c: 14000002    	b	0x10142ee64 <__ZN17otty_autocomplete4spec14CompletionSpec18find_option_direct17h3feee326741eac69E+0xa0>
10142ee60: d2800015    	mov	x21, #0x0               ; =0
10142ee64: aa1503e0    	mov	x0, x21
10142ee68: a9437bfd    	ldp	x29, x30, [sp, #0x30]
10142ee6c: a9424ff4    	ldp	x20, x19, [sp, #0x20]
10142ee70: a94157f6    	ldp	x22, x21, [sp, #0x10]
10142ee74: a8c45ff8    	ldp	x24, x23, [sp], #0x40
10142ee78: d65f03c0    	ret

000000010142ee7c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E>:
10142ee7c: f9406408    	ldr	x8, [x0, #0xc8]
10142ee80: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10142ee84: eb09011f    	cmp	x8, x9
10142ee88: 54000320    	b.eq	0x10142eeec <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x70>
10142ee8c: f9406c08    	ldr	x8, [x0, #0xd8]
10142ee90: b40002e8    	cbz	x8, 0x10142eeec <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x70>
10142ee94: 8b080508    	add	x8, x8, x8, lsl #1
10142ee98: f9406809    	ldr	x9, [x0, #0xd0]
10142ee9c: d37df108    	lsl	x8, x8, #3
10142eea0: 91004129    	add	x9, x9, #0x10
10142eea4: 528d2d0a    	mov	w10, #0x6968            ; =26984
10142eea8: 72ac8c8a    	movk	w10, #0x6464, lsl #16
10142eeac: 528dccab    	mov	w11, #0x6e65            ; =28261
