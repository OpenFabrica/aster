10006e844:     	adrp	x8, 0x10237e000
10006e848:     	ldr	x8, [x8, #0xf70]
10006e84c:     	cmn	x8, #0x1
10006e850:     	b.ne	0x10006e860
10006e854:     	adrp	x0, 0x1023d9000
10006e858:     	add	x0, x0, #0x700
10006e85c:     	ret
10006e860:     	stp	x29, x30, [sp, #-0x10]!
10006e864:     	mov	x29, sp
10006e868:     	adrp	x0, 0x10237e000
10006e86c:     	add	x0, x0, #0xf70
10006e870:     	adrp	x1, 0x10006e000
10006e874:     	add	x1, x1, #0x810
10006e878:     	bl	0x101aca948 ; symbol _swift_once
10006e87c:     	ldp	x29, x30, [sp], #0x10
10006e880:     	b	0x10006e854
10006e884:     	adrp	x0, 0x10237e000
10006e888:     	add	x0, x0, #0xf70
10006e88c:     	adrp	x1, 0x1023d9000
10006e890:     	add	x1, x1, #0x700
10006e894:     	adrp	x2, 0x10006e000
10006e898:     	add	x2, x2, #0x810
