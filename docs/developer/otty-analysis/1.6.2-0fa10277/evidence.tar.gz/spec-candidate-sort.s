
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010144d488 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE>:
10145963c: d102c3ff    	sub	sp, sp, #0xb0
101459640: a9075ff8    	stp	x24, x23, [sp, #0x70]
101459644: a90857f6    	stp	x22, x21, [sp, #0x80]
101459648: a9094ff4    	stp	x20, x19, [sp, #0x90]
10145964c: a90a7bfd    	stp	x29, x30, [sp, #0xa0]
101459650: 910283fd    	add	x29, sp, #0xa0
101459654: aa0203f3    	mov	x19, x2
101459658: aa0003f4    	mov	x20, x0
10145965c: d2800016    	mov	x22, #0x0               ; =0
101459660: 52800e08    	mov	w8, #0x70               ; =112
101459664: 9b080037    	madd	x23, x1, x8, x0
101459668: 9101c008    	add	x8, x0, #0x70
10145966c: aa0003f5    	mov	x21, x0
101459670: 1400000e    	b	0x1014596a8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc220>
101459674: aa1403e8    	mov	x8, x20
101459678: ad4207e0    	ldp	q0, q1, [sp, #0x40]
10145967c: ad020500    	stp	q0, q1, [x8, #0x40]
101459680: 3dc01be0    	ldr	q0, [sp, #0x60]
101459684: 3d801900    	str	q0, [x8, #0x60]
101459688: ad4007e0    	ldp	q0, q1, [sp]
10145968c: ad000500    	stp	q0, q1, [x8]
101459690: ad4103e1    	ldp	q1, q0, [sp, #0x20]
101459694: ad010101    	stp	q1, q0, [x8, #0x20]
101459698: 9101c2a8    	add	x8, x21, #0x70
10145969c: 9101c2d6    	add	x22, x22, #0x70
1014596a0: eb17011f    	cmp	x8, x23
1014596a4: 54000460    	b.eq	0x101459730 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc2a8>
1014596a8: aa1503e2    	mov	x2, x21
1014596ac: aa0803f5    	mov	x21, x8
1014596b0: aa1303e0    	mov	x0, x19
1014596b4: aa0803e1    	mov	x1, x8
1014596b8: 94004967    	bl	0x10146bc54 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x524>
1014596bc: 34fffee0    	cbz	w0, 0x101459698 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc210>
1014596c0: ad4206a0    	ldp	q0, q1, [x21, #0x40]
1014596c4: ad0207e0    	stp	q0, q1, [sp, #0x40]
1014596c8: 3dc01aa0    	ldr	q0, [x21, #0x60]
1014596cc: 3d801be0    	str	q0, [sp, #0x60]
1014596d0: ad4006a0    	ldp	q0, q1, [x21]
1014596d4: ad0007e0    	stp	q0, q1, [sp]
1014596d8: ad4102a1    	ldp	q1, q0, [x21, #0x20]
1014596dc: aa1603f8    	mov	x24, x22
1014596e0: ad0103e1    	stp	q1, q0, [sp, #0x20]
1014596e4: 8b180288    	add	x8, x20, x24
1014596e8: ad420500    	ldp	q0, q1, [x8, #0x40]
1014596ec: ad058500    	stp	q0, q1, [x8, #0xb0]
1014596f0: 3dc01900    	ldr	q0, [x8, #0x60]
1014596f4: 3d803500    	str	q0, [x8, #0xd0]
1014596f8: ad400500    	ldp	q0, q1, [x8]
1014596fc: ad038500    	stp	q0, q1, [x8, #0x70]
101459700: ad410101    	ldp	q1, q0, [x8, #0x20]
101459704: ad048101    	stp	q1, q0, [x8, #0x90]
101459708: b4fffb78    	cbz	x24, 0x101459674 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc1ec>
10145970c: d101c318    	sub	x24, x24, #0x70
101459710: 910003e1    	mov	x1, sp
101459714: 8b140302    	add	x2, x24, x20
101459718: aa1303e0    	mov	x0, x19
10145971c: 9400494e    	bl	0x10146bc54 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x524>
101459720: 3707fe20    	tbnz	w0, #0x0, 0x1014596e4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc25c>
101459724: 8b180288    	add	x8, x20, x24
101459728: 9101c108    	add	x8, x8, #0x70
10145972c: 17ffffd3    	b	0x101459678 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc1f0>
101459730: a94a7bfd    	ldp	x29, x30, [sp, #0xa0]
101459734: a9494ff4    	ldp	x20, x19, [sp, #0x90]
101459738: a94857f6    	ldp	x22, x21, [sp, #0x80]
10145973c: a9475ff8    	ldp	x24, x23, [sp, #0x70]
101459740: 9102c3ff    	add	sp, sp, #0xb0
101459744: d65f03c0    	ret
101459748: a9bb67fa    	stp	x26, x25, [sp, #-0x50]!
10145974c: a9015ff8    	stp	x24, x23, [sp, #0x10]
101459750: a90257f6    	stp	x22, x21, [sp, #0x20]
101459754: a9034ff4    	stp	x20, x19, [sp, #0x30]
101459758: a9047bfd    	stp	x29, x30, [sp, #0x40]
10145975c: 910103fd    	add	x29, sp, #0x40
101459760: aa0203f3    	mov	x19, x2
101459764: aa0003f4    	mov	x20, x0
101459768: d2800017    	mov	x23, #0x0               ; =0
10145976c: 8b010c18    	add	x24, x0, x1, lsl #3
101459770: 91002008    	add	x8, x0, #0x8
101459774: aa0003f9    	mov	x25, x0
101459778: 14000007    	b	0x101459794 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc30c>
10145977c: aa1403e8    	mov	x8, x20
101459780: f9000115    	str	x21, [x8]
101459784: 91002328    	add	x8, x25, #0x8
101459788: 910022f7    	add	x23, x23, #0x8
10145978c: eb18011f    	cmp	x8, x24
101459790: 540002c0    	b.eq	0x1014597e8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc360>
101459794: a9405736    	ldp	x22, x21, [x25]
101459798: aa0803f9    	mov	x25, x8
10145979c: aa1303e0    	mov	x0, x19
1014597a0: aa1503e1    	mov	x1, x21
1014597a4: aa1603e2    	mov	x2, x22
1014597a8: 94004824    	bl	0x10146b838 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x108>
1014597ac: 34fffec0    	cbz	w0, 0x101459784 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc2fc>
1014597b0: aa1703fa    	mov	x26, x23
1014597b4: 8b1a0288    	add	x8, x20, x26
1014597b8: f9000516    	str	x22, [x8, #0x8]
1014597bc: b4fffe1a    	cbz	x26, 0x10145977c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc2f4>
1014597c0: f85f8116    	ldur	x22, [x8, #-0x8]
1014597c4: aa1303e0    	mov	x0, x19
1014597c8: aa1503e1    	mov	x1, x21
1014597cc: aa1603e2    	mov	x2, x22
1014597d0: 9400481a    	bl	0x10146b838 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x108>
1014597d4: d100235a    	sub	x26, x26, #0x8
1014597d8: 3707fee0    	tbnz	w0, #0x0, 0x1014597b4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc32c>
1014597dc: 8b1a0288    	add	x8, x20, x26
1014597e0: 91002108    	add	x8, x8, #0x8
1014597e4: 17ffffe7    	b	0x101459780 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc2f8>
1014597e8: a9447bfd    	ldp	x29, x30, [sp, #0x40]
1014597ec: a9434ff4    	ldp	x20, x19, [sp, #0x30]
1014597f0: a94257f6    	ldp	x22, x21, [sp, #0x20]
1014597f4: a9415ff8    	ldp	x24, x23, [sp, #0x10]
1014597f8: a8c567fa    	ldp	x26, x25, [sp], #0x50
1014597fc: d65f03c0    	ret
101459800: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
101459804: a90167fa    	stp	x26, x25, [sp, #0x10]
101459808: a9025ff8    	stp	x24, x23, [sp, #0x20]
10145980c: a90357f6    	stp	x22, x21, [sp, #0x30]
101459810: a9044ff4    	stp	x20, x19, [sp, #0x40]
101459814: a9057bfd    	stp	x29, x30, [sp, #0x50]
101459818: 910143fd    	add	x29, sp, #0x50
10145981c: aa0003f3    	mov	x19, x0
101459820: d2800016    	mov	x22, #0x0               ; =0
101459824: 52800308    	mov	w8, #0x18               ; =24
101459828: 9b080037    	madd	x23, x1, x8, x0
10145982c: 91006008    	add	x8, x0, #0x18
101459830: aa0003f8    	mov	x24, x0
101459834: 14000008    	b	0x101459854 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc3cc>
101459838: aa1303e8    	mov	x8, x19
10145983c: a900511a    	stp	x26, x20, [x8]
101459840: f9000915    	str	x21, [x8, #0x10]
101459844: 91006308    	add	x8, x24, #0x18
101459848: 910062d6    	add	x22, x22, #0x18
10145984c: eb17011f    	cmp	x8, x23
101459850: 540005a0    	b.eq	0x101459904 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc47c>
101459854: aa1803f9    	mov	x25, x24
101459858: aa0803f8    	mov	x24, x8
10145985c: a9425734    	ldp	x20, x21, [x25, #0x20]
101459860: f9400b28    	ldr	x8, [x25, #0x10]
101459864: eb0802bf    	cmp	x21, x8
101459868: 540000e1    	b.ne	0x101459884 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc3fc>
10145986c: f9400721    	ldr	x1, [x25, #0x8]
101459870: aa1403e0    	mov	x0, x20
101459874: aa1503e2    	mov	x2, x21
101459878: 9419c0e9    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10145987c: 36fffe40    	tbz	w0, #0x1f, 0x101459844 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc3bc>
101459880: 14000002    	b	0x101459888 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc400>
101459884: 54fffe02    	b.hs	0x101459844 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc3bc>
101459888: 3dc00320    	ldr	q0, [x25]
10145988c: a9416b28    	ldp	x8, x26, [x25, #0x10]
101459890: 3d800300    	str	q0, [x24]
101459894: f9000b08    	str	x8, [x24, #0x10]
101459898: aa1303e8    	mov	x8, x19
10145989c: eb13033f    	cmp	x25, x19
1014598a0: 54fffce0    	b.eq	0x10145983c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc3b4>
1014598a4: aa1603fb    	mov	x27, x22
1014598a8: 1400000e    	b	0x1014598e0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc458>
1014598ac: f85f0381    	ldur	x1, [x28, #-0x10]
1014598b0: aa1403e0    	mov	x0, x20
1014598b4: aa1503e2    	mov	x2, x21
1014598b8: 9419c0d9    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
1014598bc: 36f80200    	tbz	w0, #0x1f, 0x1014598fc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc474>
1014598c0: d1006339    	sub	x25, x25, #0x18
1014598c4: d1006388    	sub	x8, x28, #0x18
1014598c8: 3dc00100    	ldr	q0, [x8]
1014598cc: 3d800380    	str	q0, [x28]
1014598d0: f9400908    	ldr	x8, [x8, #0x10]
1014598d4: f9000b88    	str	x8, [x28, #0x10]
1014598d8: f100637b    	subs	x27, x27, #0x18
1014598dc: 54fffae0    	b.eq	0x101459838 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc3b0>
1014598e0: 8b1b027c    	add	x28, x19, x27
1014598e4: f85f8388    	ldur	x8, [x28, #-0x8]
1014598e8: eb0802bf    	cmp	x21, x8
1014598ec: 54fffe00    	b.eq	0x1014598ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc424>
1014598f0: 54fffe83    	b.lo	0x1014598c0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc438>
1014598f4: aa1903e8    	mov	x8, x25
1014598f8: 17ffffd1    	b	0x10145983c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc3b4>
1014598fc: 8b1b0268    	add	x8, x19, x27
