100582e2c:     	stp	x24, x23, [sp, #-0x40]!
100582e30:     	stp	x22, x21, [sp, #0x10]
100582e34:     	stp	x20, x19, [sp, #0x20]
100582e38:     	stp	x29, x30, [sp, #0x30]
100582e3c:     	add	x29, sp, #0x30
100582e40:     	mov	x20, x3
100582e44:     	mov	x21, x2
100582e48:     	mov	x22, x1
100582e4c:     	mov	x23, x0
100582e50:     	adrp	x0, 0x102341000
100582e54:     	add	x0, x0, #0x6d0
100582e58:     	adrp	x1, 0x101ae1000
100582e5c:     	add	x1, x1, #0x7e0 ; possible literal '\n14'
100582e60:     	bl	0x100003c4c
100582e64:     	mov	w1, #0x80               ; =128
100582e68:     	mov	w2, #0x7                ; =7
100582e6c:     	bl	0x101aca588 ; symbol _swift_allocObject
100582e70:     	mov	x19, x0
100582e74:     	adrp	x8, 0x101ae1000
100582e78:     	ldr	q0, [x8, #0xbd0]
100582e7c:     	str	q0, [x0, #0x10]
100582e80:     	mov	w8, #0x6967             ; =26983
100582e84:     	movk	w8, #0x74, lsl #16
100582e88:     	mov	x9, #-0x1d00000000000000 ; =-2089670227099910144
100582e8c:     	stp	x8, x9, [x0, #0x20]
100582e90:     	mov	w8, #0x432d             ; =17197
100582e94:     	mov	x9, #-0x1e00000000000000 ; =-2161727821137838080
100582e98:     	stp	x8, x9, [x0, #0x30]
100582e9c:     	stp	x23, x22, [x0, #0x40]
100582ea0:     	mov	x8, #0x6863             ; =26723
100582ea4:     	movk	x8, #0x6365, lsl #16
100582ea8:     	movk	x8, #0x6f6b, lsl #32
100582eac:     	movk	x8, #0x7475, lsl #48
100582eb0:     	mov	x10, #-0x1800000000000000 ; =-1729382256910270464
100582eb4:     	stp	x8, x10, [x0, #0x50]
100582eb8:     	mov	w8, #0x622d             ; =25133
100582ebc:     	stp	x8, x9, [x0, #0x60]
100582ec0:     	stp	x21, x20, [x0, #0x70]
100582ec4:     	adrp	x8, 0x102326000
100582ec8:     	ldr	x0, [x8, #0xa50]
100582ecc:     	bl	0x101ac9d24 ; symbol _objc_opt_self
100582ed0:     	mov	x21, x0
100582ed4:     	mov	x0, x22
100582ed8:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100582edc:     	mov	x0, x20
100582ee0:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100582ee4:     	mov	x0, x21
100582ee8:     	bl	0x101ad04e0 ; selector processInfo
100582eec:     	mov	x29, x29
100582ef0:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
100582ef4:     	mov	x20, x0
100582ef8:     	bl	0x101acd780 ; selector environment
100582efc:     	mov	x29, x29
100582f00:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
100582f04:     	mov	x21, x0
100582f08:     	mov	x0, x20
100582f0c:     	bl	0x101ac9d30 ; symbol _objc_release
100582f10:     	adrp	x1, 0x1022ce000
100582f14:     	ldr	x1, [x1, #0x38]
100582f18:     	adrp	x3, 0x1022ce000
100582f1c:     	ldr	x3, [x3, #0x48]
100582f20:     	mov	x0, x21
100582f24:     	mov	x2, x1
100582f28:     	bl	0x101ac5ef0 ; symbol _$sSD10FoundationE36_unconditionallyBridgeFromObjectiveCySDyxq_GSo12NSDictionaryCSgFZ
100582f2c:     	mov	x20, x0
100582f30:     	mov	x0, x21
100582f34:     	bl	0x101ac9d30 ; symbol _objc_release
100582f38:     	mov	x0, x19
100582f3c:     	mov	x1, x20
100582f40:     	mov	x2, #0x0                ; =0
100582f44:     	mov	w3, #0x1                ; =1
100582f48:     	bl	0x1000697ac
100582f4c:     	mov	x21, x1
100582f50:     	mov	x22, x2
100582f54:     	mov	x0, x19
100582f58:     	bl	0x101aca960 ; symbol _swift_release
100582f5c:     	mov	x0, x20
100582f60:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100582f64:     	mov	x0, x21
100582f68:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100582f6c:     	cmp	w22, #0x0
100582f70:     	cset	w0, eq
100582f74:     	ldp	x29, x30, [sp, #0x30]
100582f78:     	ldp	x20, x19, [sp, #0x20]
100582f7c:     	ldp	x22, x21, [sp, #0x10]
100582f80:     	ldp	x24, x23, [sp], #0x40
100582f84:     	ret
100582f88:     	b	0x10057b214
100582f8c:     	b	0x100586eec
100582f90:     	b	0x1005869c4
