
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010144d488 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE>:
1014591cc: d102c3ff    	sub	sp, sp, #0xb0
1014591d0: a9056ffc    	stp	x28, x27, [sp, #0x50]
1014591d4: a90667fa    	stp	x26, x25, [sp, #0x60]
1014591d8: a9075ff8    	stp	x24, x23, [sp, #0x70]
1014591dc: a90857f6    	stp	x22, x21, [sp, #0x80]
1014591e0: a9094ff4    	stp	x20, x19, [sp, #0x90]
1014591e4: a90a7bfd    	stp	x29, x30, [sp, #0xa0]
1014591e8: 910283fd    	add	x29, sp, #0xa0
1014591ec: aa0003f3    	mov	x19, x0
1014591f0: d2800015    	mov	x21, #0x0               ; =0
1014591f4: 52800d08    	mov	w8, #0x68               ; =104
1014591f8: 9b080036    	madd	x22, x1, x8, x0
1014591fc: 9101a008    	add	x8, x0, #0x68
101459200: aa0003fa    	mov	x26, x0
101459204: 14000011    	b	0x101459248 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbdc0>
101459208: aa1303e8    	mov	x8, x19
10145920c: f9000119    	str	x25, [x8]
101459210: a900e354    	stp	x20, x24, [x26, #0x8]
101459214: ad4003e1    	ldp	q1, q0, [sp]
101459218: 3c828340    	stur	q0, [x26, #0x28]
10145921c: ad410be0    	ldp	q0, q2, [sp, #0x20]
101459220: 3c838340    	stur	q0, [x26, #0x38]
101459224: 3c848342    	stur	q2, [x26, #0x48]
101459228: 3dc013e0    	ldr	q0, [sp, #0x40]
10145922c: 3c858340    	stur	q0, [x26, #0x58]
101459230: 3c818341    	stur	q1, [x26, #0x18]
101459234: 9101a2e8    	add	x8, x23, #0x68
101459238: 9101a2b5    	add	x21, x21, #0x68
10145923c: aa1703fa    	mov	x26, x23
101459240: eb16011f    	cmp	x8, x22
101459244: 540005c0    	b.eq	0x1014592fc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbe74>
101459248: aa0803f7    	mov	x23, x8
10145924c: a9476354    	ldp	x20, x24, [x26, #0x70]
101459250: a940a341    	ldp	x1, x8, [x26, #0x8]
101459254: eb080319    	subs	x25, x24, x8
101459258: 9a883302    	csel	x2, x24, x8, lo
10145925c: aa1403e0    	mov	x0, x20
101459260: 9419c26f    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101459264: 93407c08    	sxtw	x8, w0
101459268: 7100001f    	cmp	w0, #0x0
10145926c: 9a880328    	csel	x8, x25, x8, eq
101459270: b6fffe28    	tbz	x8, #0x3f, 0x101459234 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbdac>
101459274: f9403759    	ldr	x25, [x26, #0x68]
101459278: ad450740    	ldp	q0, q1, [x26, #0xa0]
10145927c: ad0107e0    	stp	q0, q1, [sp, #0x20]
101459280: 3dc03340    	ldr	q0, [x26, #0xc0]
101459284: 3d8013e0    	str	q0, [sp, #0x40]
101459288: ad440341    	ldp	q1, q0, [x26, #0x80]
10145928c: aa1503fb    	mov	x27, x21
101459290: ad0003e1    	stp	q1, q0, [sp]
101459294: 8b1b027a    	add	x26, x19, x27
101459298: ad410341    	ldp	q1, q0, [x26, #0x20]
10145929c: 3c898340    	stur	q0, [x26, #0x98]
1014592a0: ad420b40    	ldp	q0, q2, [x26, #0x40]
1014592a4: 3c8a8340    	stur	q0, [x26, #0xa8]
1014592a8: 3c8b8342    	stur	q2, [x26, #0xb8]
1014592ac: ad400b40    	ldp	q0, q2, [x26]
1014592b0: 3c868340    	stur	q0, [x26, #0x68]
1014592b4: 3c878342    	stur	q2, [x26, #0x78]
1014592b8: f9403348    	ldr	x8, [x26, #0x60]
1014592bc: f9006748    	str	x8, [x26, #0xc8]
1014592c0: 3c888341    	stur	q1, [x26, #0x88]
1014592c4: b4fffa3b    	cbz	x27, 0x101459208 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbd80>
1014592c8: a97a2341    	ldp	x1, x8, [x26, #-0x60]
1014592cc: eb08031c    	subs	x28, x24, x8
1014592d0: 9a883302    	csel	x2, x24, x8, lo
1014592d4: aa1403e0    	mov	x0, x20
1014592d8: 9419c251    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
1014592dc: 93407c08    	sxtw	x8, w0
1014592e0: 7100001f    	cmp	w0, #0x0
1014592e4: 9a880388    	csel	x8, x28, x8, eq
1014592e8: d101a37b    	sub	x27, x27, #0x68
1014592ec: b7fffd48    	tbnz	x8, #0x3f, 0x101459294 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbe0c>
1014592f0: 8b1b0268    	add	x8, x19, x27
1014592f4: 9101a108    	add	x8, x8, #0x68
1014592f8: 17ffffc5    	b	0x10145920c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbd84>
1014592fc: a94a7bfd    	ldp	x29, x30, [sp, #0xa0]
101459300: a9494ff4    	ldp	x20, x19, [sp, #0x90]
101459304: a94857f6    	ldp	x22, x21, [sp, #0x80]
101459308: a9475ff8    	ldp	x24, x23, [sp, #0x70]
10145930c: a94667fa    	ldp	x26, x25, [sp, #0x60]
101459310: a9456ffc    	ldp	x28, x27, [sp, #0x50]
101459314: 9102c3ff    	add	sp, sp, #0xb0
101459318: d65f03c0    	ret
