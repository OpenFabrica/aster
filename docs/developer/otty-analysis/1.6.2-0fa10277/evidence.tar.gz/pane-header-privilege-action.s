1006e46fc:	sub	sp, sp, #0x60
1006e4700:	stp	x24, x23, [sp, #0x20]
1006e4704:	stp	x22, x21, [sp, #0x30]
1006e4708:	stp	x20, x19, [sp, #0x40]
1006e470c:	stp	x29, x30, [sp, #0x50]
1006e4710:	add	x29, sp, #0x50
1006e4714:	bl	0x101ad5780 ; selector tag
1006e4718:	sub	x21, x0, #0x1
1006e471c:	cmp	x21, #0x13
1006e4720:	b.hi	0x1006e4e08
1006e4724:	bl	0x10060388c
1006e4728:	cbz	x0, 0x1006e4e08
1006e472c:	mov	x20, x0
1006e4730:	ldr	x8, [x0]
1006e4734:	ldr	x8, [x8, #0x260]
1006e4738:	blr	x8
1006e473c:	mov	x19, x0
1006e4740:	mov	x0, x20
1006e4744:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e4748:	cbz	x19, 0x1006e4e08
1006e474c:	ldr	x8, [x19]
1006e4750:	ldr	x8, [x8, #0x370]
1006e4754:	mov	x20, x19
1006e4758:	blr	x8
1006e475c:	and	x8, x21, #0xff
1006e4760:	adrp	x9, 5147 ; 0x101aff000
1006e4764:	add	x9, x9, #0x680
1006e4768:	adr	x10, #16
1006e476c:	ldrh	w11, [x9, x8, lsl #1]
1006e4770:	add	x10, x10, x11, lsl #2
1006e4774:	br	x10
1006e4778:	ldr	x8, [x0]
1006e477c:	ldr	x8, [x8, #0xf0]
1006e4780:	mov	x20, x0
1006e4784:	mov	w0, #0x0
1006e4788:	blr	x8
1006e478c:	ldr	x8, [x20]
1006e4790:	ldr	x8, [x8, #0x108]
1006e4794:	mov	w0, #0x0
1006e4798:	blr	x8
1006e479c:	adrp	x0, 7261 ; 0x102341000
1006e47a0:	add	x0, x0, #0x6d0
1006e47a4:	adrp	x1, 5117 ; 0x101ae1000
1006e47a8:	add	x1, x1, #0x7e0
1006e47ac:	bl	0x100003c4c
1006e47b0:	adrp	x1, 7295 ; 0x102363000
1006e47b4:	add	x1, x1, #0x300
1006e47b8:	b	0x1006e4a4c
1006e47bc:	mov	x21, x0
1006e47c0:	ldr	x8, [x19]
1006e47c4:	ldr	x8, [x8, #0x500]
1006e47c8:	mov	x20, x19
1006e47cc:	blr	x8
1006e47d0:	tbz	w0, #0x0, 0x1006e4e20
1006e47d4:	bl	0x10060388c
1006e47d8:	cbz	x0, 0x1006e4e9c
1006e47dc:	mov	x20, x0
1006e47e0:	ldr	x8, [x0]
1006e47e4:	ldr	x8, [x8, #0xf0]
1006e47e8:	blr	x8
1006e47ec:	mov	x22, x0
1006e47f0:	mov	x0, x20
1006e47f4:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e47f8:	b	0x1006e4ea4
1006e47fc:	ldr	x8, [x0]
1006e4800:	ldr	x8, [x8, #0x1a0]
1006e4804:	mov	x21, x0
1006e4808:	mov	x0, sp
1006e480c:	mov	x20, x21
1006e4810:	blr	x8
1006e4814:	mov	x8, x0
1006e4818:	ldrb	w9, [x1]
1006e481c:	mov	w10, #0x1
1006e4820:	bic	w9, w10, w9
1006e4824:	strb	w9, [x1]
1006e4828:	mov	x0, sp
1006e482c:	mov	w1, #0x0
1006e4830:	blr	x8
1006e4834:	adrp	x0, 7261 ; 0x102341000
1006e4838:	add	x0, x0, #0x6d0
1006e483c:	adrp	x1, 5117 ; 0x101ae1000
1006e4840:	add	x1, x1, #0x7e0
1006e4844:	bl	0x100003c4c
1006e4848:	adrp	x1, 7295 ; 0x102363000
1006e484c:	add	x1, x1, #0xd8
1006e4850:	b	0x1006e4bf8
1006e4854:	adrp	x8, 6920 ; 0x1021ec000
1006e4858:	add	x8, x8, #0x628
1006e485c:	mov	x20, x0
1006e4860:	mov	x0, x8
1006e4864:	mov	w1, #0x18
1006e4868:	mov	w2, #0x7
1006e486c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1006e4870:	mov	x21, x0
1006e4874:	add	x0, x0, #0x10
1006e4878:	mov	x1, x19
1006e487c:	bl	0x101acab58 ; symbol stub for: _swift_weakInit
1006e4880:	adrp	x0, 6920 ; 0x1021ec000
1006e4884:	add	x0, x0, #0x678
1006e4888:	mov	w1, #0x20
1006e488c:	mov	w2, #0x7
1006e4890:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1006e4894:	mov	x22, x0
1006e4898:	stp	x20, x21, [x0, #0x10]
1006e489c:	mov	x0, x20
1006e48a0:	bl	0x101aca978 ; symbol stub for: _swift_retain
1006e48a4:	mov	x0, x21
1006e48a8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1006e48ac:	adrp	x0, 1 ; 0x1006e5000
1006e48b0:	add	x0, x0, #0xaec
1006e48b4:	b	0x1006e4d2c
1006e48b8:	ldr	x8, [x0]
1006e48bc:	ldr	x8, [x8, #0x128]
1006e48c0:	mov	x20, x0
1006e48c4:	mov	x0, sp
1006e48c8:	blr	x8
1006e48cc:	mov	x8, x0
1006e48d0:	ldrb	w9, [x1]
1006e48d4:	mov	w10, #0x1
1006e48d8:	bic	w9, w10, w9
1006e48dc:	strb	w9, [x1]
1006e48e0:	mov	x0, sp
1006e48e4:	mov	w1, #0x0
1006e48e8:	blr	x8
1006e48ec:	adrp	x0, 7261 ; 0x102341000
1006e48f0:	add	x0, x0, #0x6d0
1006e48f4:	adrp	x1, 5117 ; 0x101ae1000
1006e48f8:	add	x1, x1, #0x7e0
1006e48fc:	bl	0x100003c4c
1006e4900:	adrp	x1, 7295 ; 0x102363000
1006e4904:	add	x1, x1, #0x1f0
1006e4908:	b	0x1006e4de8
1006e490c:	adrp	x8, 6920 ; 0x1021ec000
1006e4910:	add	x8, x8, #0x628
1006e4914:	mov	x20, x0
1006e4918:	mov	x0, x8
1006e491c:	mov	w1, #0x18
1006e4920:	mov	w2, #0x7
1006e4924:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1006e4928:	mov	x21, x0
1006e492c:	add	x0, x0, #0x10
1006e4930:	mov	x1, x19
1006e4934:	bl	0x101acab58 ; symbol stub for: _swift_weakInit
1006e4938:	adrp	x0, 6920 ; 0x1021ec000
1006e493c:	add	x0, x0, #0x650
1006e4940:	mov	w1, #0x20
1006e4944:	mov	w2, #0x7
1006e4948:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1006e494c:	mov	x22, x0
1006e4950:	stp	x20, x21, [x0, #0x10]
1006e4954:	mov	x0, x20
1006e4958:	bl	0x101aca978 ; symbol stub for: _swift_retain
1006e495c:	mov	x0, x21
1006e4960:	bl	0x101aca978 ; symbol stub for: _swift_retain
1006e4964:	adrp	x0, 1 ; 0x1006e5000
1006e4968:	add	x0, x0, #0xa28
1006e496c:	b	0x1006e4d2c
1006e4970:	mov	x20, x0
1006e4974:	bl	0x101aca978 ; symbol stub for: _swift_retain
1006e4978:	adrp	x0, 1 ; 0x1006e5000
1006e497c:	add	x0, x0, #0xc74
1006e4980:	b	0x1006e4d78
1006e4984:	ldr	x8, [x0]
1006e4988:	ldr	x8, [x8, #0x110]
1006e498c:	mov	x20, x0
1006e4990:	mov	x0, sp
1006e4994:	blr	x8
1006e4998:	mov	x8, x0
1006e499c:	ldrb	w9, [x1]
1006e49a0:	mov	w10, #0x1
1006e49a4:	bic	w9, w10, w9
1006e49a8:	strb	w9, [x1]
1006e49ac:	mov	x0, sp
1006e49b0:	mov	w1, #0x0
1006e49b4:	blr	x8
1006e49b8:	adrp	x0, 7261 ; 0x102341000
1006e49bc:	add	x0, x0, #0x6d0
1006e49c0:	adrp	x1, 5117 ; 0x101ae1000
1006e49c4:	add	x1, x1, #0x7e0
1006e49c8:	bl	0x100003c4c
1006e49cc:	adrp	x1, 7295 ; 0x102363000
1006e49d0:	add	x1, x1, #0x290
1006e49d4:	b	0x1006e4de8
1006e49d8:	mov	x20, x0
1006e49dc:	bl	0x101aca978 ; symbol stub for: _swift_retain
1006e49e0:	adrp	x0, 1 ; 0x1006e5000
1006e49e4:	add	x0, x0, #0x990
1006e49e8:	b	0x1006e4d78
1006e49ec:	ldr	x8, [x0]
1006e49f0:	ldr	x8, [x8, #0x120]
1006e49f4:	mov	x20, x0
1006e49f8:	mov	w0, #0x0
1006e49fc:	blr	x8
1006e4a00:	ldr	x8, [x20]
1006e4a04:	ldr	x8, [x8, #0x138]
1006e4a08:	mov	w0, #0x0
1006e4a0c:	blr	x8
1006e4a10:	ldr	x8, [x20]
1006e4a14:	ldr	x8, [x8, #0x150]
1006e4a18:	mov	w0, #0x0
1006e4a1c:	blr	x8
1006e4a20:	ldr	x8, [x20]
1006e4a24:	ldr	x8, [x8, #0x168]
1006e4a28:	mov	w0, #0x0
1006e4a2c:	blr	x8
1006e4a30:	adrp	x0, 7261 ; 0x102341000
1006e4a34:	add	x0, x0, #0x6d0
1006e4a38:	adrp	x1, 5117 ; 0x101ae1000
1006e4a3c:	add	x1, x1, #0x7e0
1006e4a40:	bl	0x100003c4c
1006e4a44:	adrp	x1, 7295 ; 0x102363000
1006e4a48:	add	x1, x1, #0x228
1006e4a4c:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1006e4a50:	ldr	x8, [x20]
1006e4a54:	ldr	x8, [x8, #0x2d0]
1006e4a58:	blr	x8
1006e4a5c:	b	0x1006e4d44
1006e4a60:	ldr	x8, [x0]
1006e4a64:	ldr	x8, [x8, #0x170]
1006e4a68:	mov	x20, x0
1006e4a6c:	mov	x0, sp
1006e4a70:	blr	x8
1006e4a74:	mov	x8, x0
1006e4a78:	ldrb	w9, [x1]
1006e4a7c:	mov	w10, #0x1
1006e4a80:	bic	w9, w10, w9
1006e4a84:	strb	w9, [x1]
1006e4a88:	mov	x0, sp
1006e4a8c:	mov	w1, #0x0
1006e4a90:	blr	x8
1006e4a94:	adrp	x0, 7261 ; 0x102341000
1006e4a98:	add	x0, x0, #0x6d0
1006e4a9c:	adrp	x1, 5117 ; 0x101ae1000
1006e4aa0:	add	x1, x1, #0x7e0
1006e4aa4:	bl	0x100003c4c
1006e4aa8:	adrp	x1, 7295 ; 0x102363000
1006e4aac:	add	x1, x1, #0x148
1006e4ab0:	b	0x1006e4de8
1006e4ab4:	ldr	x8, [x0]
1006e4ab8:	ldr	x8, [x8, #0xf8]
1006e4abc:	mov	x20, x0
1006e4ac0:	mov	x0, sp
1006e4ac4:	blr	x8
1006e4ac8:	mov	x8, x0
1006e4acc:	ldrb	w9, [x1]
1006e4ad0:	mov	w10, #0x1
1006e4ad4:	bic	w9, w10, w9
1006e4ad8:	strb	w9, [x1]
1006e4adc:	mov	x0, sp
1006e4ae0:	mov	w1, #0x0
1006e4ae4:	blr	x8
1006e4ae8:	adrp	x0, 7261 ; 0x102341000
1006e4aec:	add	x0, x0, #0x6d0
1006e4af0:	adrp	x1, 5117 ; 0x101ae1000
1006e4af4:	add	x1, x1, #0x7e0
1006e4af8:	bl	0x100003c4c
1006e4afc:	adrp	x1, 7295 ; 0x102363000
1006e4b00:	add	x1, x1, #0x2c8
1006e4b04:	b	0x1006e4de8
1006e4b08:	mov	x21, x0
1006e4b0c:	bl	0x10061d6d4
1006e4b10:	eor	w23, w0, #0x1
1006e4b14:	bl	0x100603a08
1006e4b18:	cbz	x0, 0x1006e4e2c
1006e4b1c:	ldr	x8, [x0]
1006e4b20:	adrp	x9, 7147 ; 0x1022cf000
1006e4b24:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1006e4b28:	ldr	x9, [x9]
1006e4b2c:	and	x8, x9, x8
1006e4b30:	ldr	x8, [x8, #0x278]
1006e4b34:	mov	x20, x0
1006e4b38:	mov	x22, x0
1006e4b3c:	blr	x8
1006e4b40:	mov	x20, x0
1006e4b44:	mov	x0, x22
1006e4b48:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e4b4c:	b	0x1006e4e30
1006e4b50:	ldr	x8, [x0]
1006e4b54:	ldr	x8, [x8, #0x140]
1006e4b58:	mov	x20, x0
1006e4b5c:	mov	x0, sp
1006e4b60:	blr	x8
1006e4b64:	mov	x8, x0
1006e4b68:	ldrb	w9, [x1]
1006e4b6c:	mov	w10, #0x1
1006e4b70:	bic	w9, w10, w9
1006e4b74:	strb	w9, [x1]
1006e4b78:	mov	x0, sp
1006e4b7c:	mov	w1, #0x0
1006e4b80:	blr	x8
1006e4b84:	adrp	x0, 7261 ; 0x102341000
1006e4b88:	add	x0, x0, #0x6d0
1006e4b8c:	adrp	x1, 5117 ; 0x101ae1000
1006e4b90:	add	x1, x1, #0x7e0
1006e4b94:	bl	0x100003c4c
1006e4b98:	adrp	x1, 7295 ; 0x102363000
1006e4b9c:	add	x1, x1, #0x1b8
1006e4ba0:	b	0x1006e4de8
1006e4ba4:	ldr	x8, [x0]
1006e4ba8:	ldr	x8, [x8, #0x188]
1006e4bac:	mov	x21, x0
1006e4bb0:	mov	x0, sp
1006e4bb4:	mov	x20, x21
1006e4bb8:	blr	x8
1006e4bbc:	mov	x8, x0
1006e4bc0:	ldrb	w9, [x1]
1006e4bc4:	mov	w10, #0x1
1006e4bc8:	bic	w9, w10, w9
1006e4bcc:	strb	w9, [x1]
1006e4bd0:	mov	x0, sp
1006e4bd4:	mov	w1, #0x0
1006e4bd8:	blr	x8
1006e4bdc:	adrp	x0, 7261 ; 0x102341000
1006e4be0:	add	x0, x0, #0x6d0
1006e4be4:	adrp	x1, 5117 ; 0x101ae1000
1006e4be8:	add	x1, x1, #0x7e0
1006e4bec:	bl	0x100003c4c
1006e4bf0:	adrp	x1, 7295 ; 0x102363000
1006e4bf4:	add	x1, x1, #0x110
1006e4bf8:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1006e4bfc:	ldr	x8, [x21]
1006e4c00:	ldr	x8, [x8, #0x2d0]
1006e4c04:	blr	x8
1006e4c08:	ldr	x8, [x19]
1006e4c0c:	ldr	x8, [x8, #0x6c8]
1006e4c10:	mov	x20, x19
1006e4c14:	blr	x8
1006e4c18:	mov	x0, x19
1006e4c1c:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e4c20:	mov	x0, x21
1006e4c24:	b	0x1006e4e04
1006e4c28:	ldr	x8, [x0]
1006e4c2c:	ldr	x8, [x8, #0x158]
1006e4c30:	mov	x20, x0
1006e4c34:	mov	x0, sp
1006e4c38:	blr	x8
1006e4c3c:	mov	x8, x0
1006e4c40:	ldrb	w9, [x1]
1006e4c44:	mov	w10, #0x1
1006e4c48:	bic	w9, w10, w9
1006e4c4c:	strb	w9, [x1]
1006e4c50:	mov	x0, sp
1006e4c54:	mov	w1, #0x0
1006e4c58:	blr	x8
1006e4c5c:	adrp	x0, 7261 ; 0x102341000
1006e4c60:	add	x0, x0, #0x6d0
1006e4c64:	adrp	x1, 5117 ; 0x101ae1000
1006e4c68:	add	x1, x1, #0x7e0
1006e4c6c:	bl	0x100003c4c
1006e4c70:	adrp	x1, 7295 ; 0x102363000
1006e4c74:	add	x1, x1, #0x180
1006e4c78:	b	0x1006e4de8
1006e4c7c:	mov	x21, x0
1006e4c80:	bl	0x10061d8dc
1006e4c84:	eor	w24, w0, #0x1
1006e4c88:	bl	0x10060388c
1006e4c8c:	mov	x22, x0
1006e4c90:	bl	0x100603a08
1006e4c94:	cbz	x0, 0x1006e4e68
1006e4c98:	ldr	x8, [x0]
1006e4c9c:	adrp	x9, 7147 ; 0x1022cf000
1006e4ca0:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1006e4ca4:	ldr	x9, [x9]
1006e4ca8:	and	x8, x9, x8
1006e4cac:	ldr	x8, [x8, #0x278]
1006e4cb0:	mov	x20, x0
1006e4cb4:	mov	x23, x0
1006e4cb8:	blr	x8
1006e4cbc:	mov	x20, x0
1006e4cc0:	mov	x0, x23
1006e4cc4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e4cc8:	b	0x1006e4e6c
1006e4ccc:	adrp	x8, 6920 ; 0x1021ec000
1006e4cd0:	add	x8, x8, #0x628
1006e4cd4:	mov	x20, x0
1006e4cd8:	mov	x0, x8
1006e4cdc:	mov	w1, #0x18
1006e4ce0:	mov	w2, #0x7
1006e4ce4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1006e4ce8:	mov	x21, x0
1006e4cec:	add	x0, x0, #0x10
1006e4cf0:	mov	x1, x19
1006e4cf4:	bl	0x101acab58 ; symbol stub for: _swift_weakInit
1006e4cf8:	adrp	x0, 6920 ; 0x1021ec000
1006e4cfc:	add	x0, x0, #0x6a0
1006e4d00:	mov	w1, #0x20
1006e4d04:	mov	w2, #0x7
1006e4d08:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1006e4d0c:	mov	x22, x0
1006e4d10:	stp	x20, x21, [x0, #0x10]
1006e4d14:	mov	x0, x20
1006e4d18:	bl	0x101aca978 ; symbol stub for: _swift_retain
1006e4d1c:	mov	x0, x21
1006e4d20:	bl	0x101aca978 ; symbol stub for: _swift_retain
1006e4d24:	adrp	x0, 1 ; 0x1006e5000
1006e4d28:	add	x0, x0, #0xbb0
1006e4d2c:	mov	x1, x22
1006e4d30:	bl	0x1004f7934
1006e4d34:	mov	x0, x21
1006e4d38:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e4d3c:	mov	x0, x22
1006e4d40:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e4d44:	mov	x0, x19
1006e4d48:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e4d4c:	mov	x0, x20
1006e4d50:	ldp	x29, x30, [sp, #0x50]
1006e4d54:	ldp	x20, x19, [sp, #0x40]
1006e4d58:	ldp	x22, x21, [sp, #0x30]
1006e4d5c:	ldp	x24, x23, [sp, #0x20]
1006e4d60:	add	sp, sp, #0x60
1006e4d64:	b	0x101aca960 ; symbol stub for: _swift_release
1006e4d68:	mov	x20, x0
1006e4d6c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1006e4d70:	adrp	x0, 1 ; 0x1006e5000
1006e4d74:	add	x0, x0, #0xce8
1006e4d78:	mov	x1, x20
1006e4d7c:	bl	0x1004f7934
1006e4d80:	mov	x0, x19
1006e4d84:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e4d88:	mov	x0, x20
1006e4d8c:	mov	w1, #0x2
1006e4d90:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1006e4d94:	b	0x1006e4e08
1006e4d98:	ldr	x8, [x0]
1006e4d9c:	ldr	x8, [x8, #0x260]
1006e4da0:	mov	x20, x0
1006e4da4:	mov	x0, sp
1006e4da8:	blr	x8
1006e4dac:	mov	x8, x0
1006e4db0:	ldrb	w9, [x1]
1006e4db4:	mov	w10, #0x1
1006e4db8:	bic	w9, w10, w9
1006e4dbc:	strb	w9, [x1]
1006e4dc0:	mov	x0, sp
1006e4dc4:	mov	w1, #0x0
1006e4dc8:	blr	x8
1006e4dcc:	adrp	x0, 7261 ; 0x102341000
1006e4dd0:	add	x0, x0, #0x6d0
1006e4dd4:	adrp	x1, 5117 ; 0x101ae1000
1006e4dd8:	add	x1, x1, #0x7e0
1006e4ddc:	bl	0x100003c4c
1006e4de0:	adrp	x1, 7295 ; 0x102363000
1006e4de4:	add	x1, x1, #0x98
1006e4de8:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1006e4dec:	ldr	x8, [x20]
1006e4df0:	ldr	x8, [x8, #0x2d0]
1006e4df4:	blr	x8
1006e4df8:	mov	x0, x19
1006e4dfc:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e4e00:	mov	x0, x20
1006e4e04:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e4e08:	ldp	x29, x30, [sp, #0x50]
1006e4e0c:	ldp	x20, x19, [sp, #0x40]
1006e4e10:	ldp	x22, x21, [sp, #0x30]
1006e4e14:	ldp	x24, x23, [sp, #0x20]
1006e4e18:	add	sp, sp, #0x60
1006e4e1c:	ret
1006e4e20:	mov	x0, x19
1006e4e24:	bl	0x1006e4464
1006e4e28:	b	0x1006e4ec0
1006e4e2c:	mov	x20, #0x0
1006e4e30:	and	w0, w23, #0x1
1006e4e34:	mov	x1, x20
1006e4e38:	bl	0x10064e640
1006e4e3c:	mov	x0, x19
1006e4e40:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e4e44:	mov	x0, x21
1006e4e48:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e4e4c:	mov	x0, x20
1006e4e50:	ldp	x29, x30, [sp, #0x50]
1006e4e54:	ldp	x20, x19, [sp, #0x40]
1006e4e58:	ldp	x22, x21, [sp, #0x30]
1006e4e5c:	ldp	x24, x23, [sp, #0x20]
1006e4e60:	add	sp, sp, #0x60
1006e4e64:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e4e68:	mov	x20, #0x0
1006e4e6c:	and	w0, w24, #0x1
1006e4e70:	mov	x1, x22
1006e4e74:	mov	x2, x20
1006e4e78:	bl	0x10064e0d8
1006e4e7c:	mov	x0, x19
1006e4e80:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e4e84:	mov	x0, x21
1006e4e88:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e4e8c:	mov	x0, x20
1006e4e90:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e4e94:	mov	x0, x22
1006e4e98:	b	0x1006e4d50
1006e4e9c:	adrp	x22, 7147 ; 0x1022cf000
1006e4ea0:	ldr	x22, [x22, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1006e4ea4:	ldr	x8, [x19]
1006e4ea8:	ldr	x8, [x8, #0x5e0]
1006e4eac:	mov	x0, x22
1006e4eb0:	mov	x20, x19
1006e4eb4:	blr	x8
1006e4eb8:	mov	x0, x22
1006e4ebc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e4ec0:	mov	x0, x19
1006e4ec4:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e4ec8:	mov	x0, x21
1006e4ecc:	b	0x1006e4d50
1006e4ed0:	stp	x29, x30, [sp, #-0x10]!
1006e4ed4:	mov	x29, sp
1006e4ed8:	adrp	x0, 7248 ; 0x102334000
1006e4edc:	add	x0, x0, #0xd88
1006e4ee0:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1006e4ee4:	mov	x1, #0x0
1006e4ee8:	ldp	x29, x30, [sp], #0x10
1006e4eec:	ret
1006e4ef0:	stp	x24, x23, [sp, #-0x40]!
1006e4ef4:	stp	x22, x21, [sp, #0x10]
1006e4ef8:	stp	x20, x19, [sp, #0x20]
1006e4efc:	stp	x29, x30, [sp, #0x30]
1006e4f00:	add	x29, sp, #0x30
1006e4f04:	adrp	x0, 7263 ; 0x102343000
1006e4f08:	add	x0, x0, #0x20
1006e4f0c:	adrp	x1, 5118 ; 0x101ae2000
1006e4f10:	add	x1, x1, #0x680
1006e4f14:	bl	0x100003c4c
1006e4f18:	ldur	x8, [x0, #-0x8]
1006e4f1c:	ldr	x9, [x8, #0x40]
1006e4f20:	add	x8, x9, #0xf
1006e4f24:	and	x8, x8, #0xfffffffffffffff0
1006e4f28:	adrp	x16, 7143 ; 0x1022cb000
1006e4f2c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1006e4f30:	blr	x16
1006e4f34:	mov	x9, sp
1006e4f38:	sub	x21, x9, x8
1006e4f3c:	mov	sp, x21
1006e4f40:	mov	x0, #0x0
1006e4f44:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1006e4f48:	mov	x19, x0
1006e4f4c:	ldur	x23, [x0, #-0x8]
1006e4f50:	ldr	x8, [x23, #0x40]
1006e4f54:	mov	x9, x8
1006e4f58:	adrp	x16, 7143 ; 0x1022cb000
1006e4f5c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1006e4f60:	blr	x16
1006e4f64:	mov	x9, sp
1006e4f68:	add	x8, x8, #0xf
1006e4f6c:	and	x8, x8, #0xfffffffffffffff0
1006e4f70:	sub	x20, x9, x8
1006e4f74:	mov	sp, x20
1006e4f78:	adrp	x8, 5891 ; 0x101de7000
1006e4f7c:	add	x8, x8, #0x430 ; literal pool for: "mailto:otty@appmakes.io"
1006e4f80:	sub	x8, x8, #0x20
1006e4f84:	orr	x1, x8, #0x8000000000000000
1006e4f88:	mov	x8, x21
1006e4f8c:	mov	x0, #0x17
1006e4f90:	movk	x0, #0xd000, lsl #48
1006e4f94:	bl	0x101ac4e10 ; symbol stub for: _$s10Foundation3URLV6stringACSgSSh_tcfC
1006e4f98:	ldr	x8, [x23, #0x30]
1006e4f9c:	mov	x0, x21
1006e4fa0:	mov	w1, #0x1
1006e4fa4:	mov	x2, x19
1006e4fa8:	blr	x8
1006e4fac:	cmp	w0, #0x1
1006e4fb0:	b.ne	0x1006e4fd0
1006e4fb4:	adrp	x1, 7263 ; 0x102343000
1006e4fb8:	add	x1, x1, #0x20
1006e4fbc:	adrp	x2, 5118 ; 0x101ae2000
1006e4fc0:	add	x2, x2, #0x680
1006e4fc4:	mov	x0, x21
1006e4fc8:	bl	0x10002d870
1006e4fcc:	b	0x1006e5034
1006e4fd0:	ldr	x8, [x23, #0x20]
1006e4fd4:	mov	x0, x20
1006e4fd8:	mov	x1, x21
1006e4fdc:	mov	x2, x19
1006e4fe0:	blr	x8
1006e4fe4:	adrp	x8, 7234 ; 0x102326000
1006e4fe8:	ldr	x0, [x8, #0xa10] ; Objc class ref: _OBJC_CLASS_$_NSWorkspace
1006e4fec:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1006e4ff0:	bl	0x101ad4ec0 ; selector sharedWorkspace
1006e4ff4:	mov	x29, x29
1006e4ff8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006e4ffc:	mov	x21, x0
1006e5000:	bl	0x101ac4d8c ; symbol stub for: _$s10Foundation3URLV19_bridgeToObjectiveCSo5NSURLCyF
1006e5004:	mov	x22, x0
1006e5008:	mov	x0, x21
1006e500c:	mov	x2, x22
1006e5010:	bl	0x101acfdc0 ; selector openURL:
1006e5014:	mov	x0, x21
1006e5018:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e501c:	mov	x0, x22
1006e5020:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e5024:	ldr	x8, [x23, #0x8]
1006e5028:	mov	x0, x20
1006e502c:	mov	x1, x19
1006e5030:	blr	x8
1006e5034:	sub	sp, x29, #0x30
1006e5038:	ldp	x29, x30, [sp, #0x30]
1006e503c:	ldp	x20, x19, [sp, #0x20]
1006e5040:	ldp	x22, x21, [sp, #0x10]
1006e5044:	ldp	x24, x23, [sp], #0x40
1006e5048:	ret
1006e504c:	stp	x26, x25, [sp, #-0x50]!
1006e5050:	stp	x24, x23, [sp, #0x10]
1006e5054:	stp	x22, x21, [sp, #0x20]
1006e5058:	stp	x20, x19, [sp, #0x30]
1006e505c:	stp	x29, x30, [sp, #0x40]
1006e5060:	add	x29, sp, #0x40
1006e5064:	mov	x0, #0x0
1006e5068:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1006e506c:	mov	x19, x0
1006e5070:	ldur	x25, [x0, #-0x8]
1006e5074:	ldr	x8, [x25, #0x40]
1006e5078:	mov	x9, x8
1006e507c:	adrp	x16, 7142 ; 0x1022cb000
1006e5080:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1006e5084:	blr	x16
1006e5088:	mov	x9, sp
1006e508c:	add	x8, x8, #0xf
1006e5090:	and	x8, x8, #0xfffffffffffffff0
1006e5094:	sub	x20, x9, x8
1006e5098:	mov	sp, x20
1006e509c:	adrp	x8, 7233 ; 0x102326000
1006e50a0:	ldr	x0, [x8, #0xa70] ; Objc class ref: _OBJC_CLASS_$_NSBundle
1006e50a4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1006e50a8:	bl	0x101acf640 ; selector mainBundle
1006e50ac:	mov	x29, x29
1006e50b0:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006e50b4:	mov	x22, x0
1006e50b8:	mov	x0, #0x5243
1006e50bc:	movk	x0, #0x4445, lsl #16
1006e50c0:	movk	x0, #0x5449, lsl #32
1006e50c4:	movk	x0, #0x53, lsl #48
1006e50c8:	mov	x1, #-0x1900000000000000
1006e50cc:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e50d0:	mov	x23, x0
1006e50d4:	mov	w0, #0x646d
1006e50d8:	mov	x1, #-0x1e00000000000000
1006e50dc:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e50e0:	mov	x24, x0
1006e50e4:	mov	x0, x22
1006e50e8:	mov	x2, x23
1006e50ec:	mov	x3, x24
1006e50f0:	bl	0x101ad00c0 ; selector pathForResource:ofType:
1006e50f4:	mov	x29, x29
1006e50f8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006e50fc:	mov	x21, x0
1006e5100:	mov	x0, x22
1006e5104:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e5108:	mov	x0, x23
1006e510c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e5110:	mov	x0, x24
1006e5114:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e5118:	cbz	x21, 0x1006e519c
1006e511c:	mov	x0, x21
1006e5120:	bl	0x101ac625c ; symbol stub for: _$sSS10FoundationE36_unconditionallyBridgeFromObjectiveCySSSo8NSStringCSgFZ
1006e5124:	mov	x22, x0
1006e5128:	mov	x23, x1
1006e512c:	mov	x0, x21
1006e5130:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e5134:	adrp	x8, 7233 ; 0x102326000
1006e5138:	ldr	x0, [x8, #0xa10] ; Objc class ref: _OBJC_CLASS_$_NSWorkspace
1006e513c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1006e5140:	bl	0x101ad4ec0 ; selector sharedWorkspace
1006e5144:	mov	x29, x29
1006e5148:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006e514c:	mov	x21, x0
1006e5150:	mov	x8, x20
1006e5154:	mov	x0, x22
1006e5158:	mov	x1, x23
1006e515c:	bl	0x101ac4d68 ; symbol stub for: _$s10Foundation3URLV15fileURLWithPathACSSh_tcfC
1006e5160:	mov	x0, x23
1006e5164:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e5168:	bl	0x101ac4d8c ; symbol stub for: _$s10Foundation3URLV19_bridgeToObjectiveCSo5NSURLCyF
1006e516c:	mov	x22, x0
1006e5170:	ldr	x8, [x25, #0x8]
1006e5174:	mov	x0, x20
1006e5178:	mov	x1, x19
1006e517c:	blr	x8
1006e5180:	mov	x0, x21
1006e5184:	mov	x2, x22
1006e5188:	bl	0x101acfdc0 ; selector openURL:
1006e518c:	mov	x0, x21
1006e5190:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e5194:	mov	x0, x22
1006e5198:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e519c:	sub	sp, x29, #0x40
1006e51a0:	ldp	x29, x30, [sp, #0x40]
1006e51a4:	ldp	x20, x19, [sp, #0x30]
1006e51a8:	ldp	x22, x21, [sp, #0x20]
1006e51ac:	ldp	x24, x23, [sp, #0x10]
1006e51b0:	ldp	x26, x25, [sp], #0x50
1006e51b4:	ret
1006e51b8:	stp	x29, x30, [sp, #-0x10]!
1006e51bc:	mov	x29, sp
1006e51c0:	adrp	x0, 7247 ; 0x102334000
1006e51c4:	add	x0, x0, #0xe68
1006e51c8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1006e51cc:	mov	x1, #0x0
1006e51d0:	ldp	x29, x30, [sp], #0x10
1006e51d4:	ret
1006e51d8:	stp	x29, x30, [sp, #-0x10]!
1006e51dc:	mov	x29, sp
1006e51e0:	adrp	x0, 7247 ; 0x102334000
1006e51e4:	add	x0, x0, #0xf38
1006e51e8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1006e51ec:	mov	x1, #0x0
1006e51f0:	ldp	x29, x30, [sp], #0x10
1006e51f4:	ret
1006e51f8:	stp	x26, x25, [sp, #-0x50]!
1006e51fc:	stp	x24, x23, [sp, #0x10]
1006e5200:	stp	x22, x21, [sp, #0x20]
1006e5204:	stp	x20, x19, [sp, #0x30]
1006e5208:	stp	x29, x30, [sp, #0x40]
1006e520c:	add	x29, sp, #0x40
1006e5210:	sub	sp, sp, #0x30
1006e5214:	adrp	x0, 7294 ; 0x102363000
1006e5218:	add	x0, x0, #0x690
1006e521c:	adrp	x1, 5116 ; 0x101ae1000
1006e5220:	add	x1, x1, #0x9e0
1006e5224:	bl	0x100003c4c
1006e5228:	ldur	x8, [x0, #-0x8]
1006e522c:	ldr	x9, [x8, #0x40]
1006e5230:	add	x8, x9, #0xf
1006e5234:	and	x8, x8, #0xfffffffffffffff0
1006e5238:	adrp	x16, 7142 ; 0x1022cb000
1006e523c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1006e5240:	blr	x16
1006e5244:	mov	x9, sp
1006e5248:	sub	x22, x9, x8
1006e524c:	mov	sp, x22
1006e5250:	mov	x0, #0x0
1006e5254:	bl	0x101ac5308 ; symbol stub for: _$s22UniformTypeIdentifiers6UTTypeVMa
1006e5258:	mov	x20, x0
1006e525c:	ldur	x26, [x0, #-0x8]
1006e5260:	ldr	x8, [x26, #0x40]
1006e5264:	mov	x9, x8
1006e5268:	adrp	x16, 7142 ; 0x1022cb000
1006e526c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1006e5270:	blr	x16
1006e5274:	mov	x9, sp
1006e5278:	add	x10, x8, #0xf
1006e527c:	and	x12, x10, #0xfffffffffffffff0
1006e5280:	sub	x23, x9, x12
1006e5284:	mov	sp, x23
1006e5288:	mov	x9, x8
1006e528c:	adrp	x16, 7142 ; 0x1022cb000
1006e5290:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1006e5294:	blr	x16
1006e5298:	mov	x8, sp
1006e529c:	sub	x21, x8, x12
1006e52a0:	mov	sp, x21
1006e52a4:	adrp	x8, 7233 ; 0x102326000
1006e52a8:	ldr	x0, [x8, #0xb18] ; Objc class ref: _OBJC_CLASS_$_NSOpenPanel
1006e52ac:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e52b0:	bl	0x101ace2c0 ; selector init
1006e52b4:	mov	x19, x0
1006e52b8:	bl	0x100309f3c
1006e52bc:	ldp	x24, x25, [x0]
1006e52c0:	mov	x0, x25
1006e52c4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1006e52c8:	mov	x8, x23
1006e52cc:	bl	0x101ac52a8 ; symbol stub for: _$s22UniformTypeIdentifiers6UTTypeV4dataACvgZ
1006e52d0:	mov	x8, x22
1006e52d4:	mov	x0, x24
1006e52d8:	mov	x1, x25
1006e52dc:	mov	x2, x23
1006e52e0:	bl	0x101ac5278 ; symbol stub for: _$s22UniformTypeIdentifiers6UTTypeV17filenameExtension12conformingToACSgSS_ACtcfC
1006e52e4:	ldr	x8, [x26, #0x30]
1006e52e8:	mov	x0, x22
1006e52ec:	mov	w1, #0x1
1006e52f0:	mov	x2, x20
1006e52f4:	blr	x8
1006e52f8:	cmp	w0, #0x1
1006e52fc:	b.ne	0x1006e531c
1006e5300:	adrp	x1, 7294 ; 0x102363000
1006e5304:	add	x1, x1, #0x690
1006e5308:	adrp	x2, 5116 ; 0x101ae1000
1006e530c:	add	x2, x2, #0x9e0
1006e5310:	mov	x0, x22
1006e5314:	bl	0x10002d870
1006e5318:	b	0x1006e53d4
1006e531c:	ldr	x8, [x26, #0x20]
1006e5320:	mov	x0, x21
1006e5324:	mov	x1, x22
1006e5328:	mov	x2, x20
1006e532c:	blr	x8
1006e5330:	adrp	x0, 7284 ; 0x102359000
1006e5334:	add	x0, x0, #0x310
1006e5338:	adrp	x1, 5130 ; 0x101aef000
1006e533c:	add	x1, x1, #0x510
1006e5340:	bl	0x100003c4c
1006e5344:	ldr	x8, [x26, #0x48]
1006e5348:	ldrb	w9, [x26, #0x50]
1006e534c:	add	x10, x9, #0x20
1006e5350:	bic	x23, x10, x9
1006e5354:	add	x1, x23, x8
1006e5358:	orr	x2, x9, #0x7
1006e535c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1006e5360:	mov	x22, x0
1006e5364:	adrp	x8, 5116 ; 0x101ae1000
1006e5368:	ldr	q0, [x8, #0x130]
1006e536c:	str	q0, [x0, #0x10]
1006e5370:	ldr	x8, [x26, #0x10]
1006e5374:	add	x0, x0, x23
1006e5378:	mov	x1, x21
1006e537c:	mov	x2, x20
1006e5380:	blr	x8
1006e5384:	mov	x0, x19
1006e5388:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e538c:	mov	x23, x0
1006e5390:	mov	x0, x22
1006e5394:	mov	x1, x20
1006e5398:	bl	0x101ac6754 ; symbol stub for: _$sSa10FoundationE19_bridgeToObjectiveCSo7NSArrayCyF
1006e539c:	mov	x24, x0
1006e53a0:	mov	x0, x22
1006e53a4:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e53a8:	mov	x0, x23
1006e53ac:	mov	x2, x24
1006e53b0:	bl	0x101ad1840 ; selector setAllowedContentTypes:
1006e53b4:	mov	x0, x23
1006e53b8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e53bc:	mov	x0, x24
1006e53c0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e53c4:	ldr	x8, [x26, #0x8]
1006e53c8:	mov	x0, x21
1006e53cc:	mov	x1, x20
1006e53d0:	blr	x8
1006e53d4:	mov	x0, x19
1006e53d8:	mov	w2, #0x0
1006e53dc:	bl	0x101ad19e0 ; selector setAllowsMultipleSelection:
1006e53e0:	mov	x0, x19
1006e53e4:	mov	w2, #0x0
1006e53e8:	bl	0x101ad2080 ; selector setCanChooseDirectories:
1006e53ec:	adrp	x0, 6919 ; 0x1021ec000
1006e53f0:	add	x0, x0, #0x5d8
1006e53f4:	mov	w1, #0x18
1006e53f8:	mov	w2, #0x7
1006e53fc:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1006e5400:	str	x19, [x0, #0x10]
1006e5404:	adrp	x8, 0 ; 0x1006e5000
1006e5408:	add	x8, x8, #0x988
1006e540c:	stp	x8, x0, [x29, #-0x50]
1006e5410:	adrp	x8, 7142 ; 0x1022cb000
1006e5414:	ldr	x8, [x8, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1006e5418:	stur	x8, [x29, #-0x70]
1006e541c:	adrp	x8, 5116 ; 0x101ae1000
1006e5420:	ldr	d0, [x8]
1006e5424:	stur	d0, [x29, #-0x68]
1006e5428:	adrp	x8, -1652 ; 0x100071000
1006e542c:	add	x8, x8, #0xb1c
1006e5430:	adrp	x9, 6919 ; 0x1021ec000
1006e5434:	add	x9, x9, #0x5f0
1006e5438:	stp	x8, x9, [x29, #-0x60]
1006e543c:	sub	x0, x29, #0x70
1006e5440:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1006e5444:	mov	x20, x0
1006e5448:	ldur	x21, [x29, #-0x48]
1006e544c:	mov	x0, x19
1006e5450:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e5454:	mov	x19, x0
1006e5458:	mov	x0, x21
1006e545c:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e5460:	mov	x0, x19
1006e5464:	mov	x2, x20
1006e5468:	bl	0x101acbbc0 ; selector beginWithCompletionHandler:
1006e546c:	mov	x0, x20
1006e5470:	bl	0x101ac9520 ; symbol stub for: __Block_release
1006e5474:	mov	x0, x19
1006e5478:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e547c:	sub	sp, x29, #0x40
1006e5480:	ldp	x29, x30, [sp, #0x40]
1006e5484:	ldp	x20, x19, [sp, #0x30]
1006e5488:	ldp	x22, x21, [sp, #0x20]
1006e548c:	ldp	x24, x23, [sp, #0x10]
1006e5490:	ldp	x26, x25, [sp], #0x50
1006e5494:	ret
1006e5498:	stp	x29, x30, [sp, #-0x10]!
1006e549c:	mov	x29, sp
1006e54a0:	adrp	x0, 7248 ; 0x102335000
1006e54a4:	add	x0, x0, #0x0
1006e54a8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1006e54ac:	mov	x1, #0x0
1006e54b0:	ldp	x29, x30, [sp], #0x10
1006e54b4:	ret
1006e54b8:	sub	sp, sp, #0x150
1006e54bc:	stp	x28, x27, [sp, #0xf0]
1006e54c0:	stp	x26, x25, [sp, #0x100]
1006e54c4:	stp	x24, x23, [sp, #0x110]
1006e54c8:	stp	x22, x21, [sp, #0x120]
1006e54cc:	stp	x20, x19, [sp, #0x130]
1006e54d0:	stp	x29, x30, [sp, #0x140]
1006e54d4:	add	x29, sp, #0x140
1006e54d8:	mov	x19, #0x6e75
1006e54dc:	movk	x19, #0x6e6b, lsl #16
1006e54e0:	movk	x19, #0x776f, lsl #32
1006e54e4:	movk	x19, #0x6e, lsl #48
1006e54e8:	adrp	x8, 7233 ; 0x102326000
1006e54ec:	ldr	x0, [x8, #0xa70] ; Objc class ref: _OBJC_CLASS_$_NSBundle
1006e54f0:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1006e54f4:	bl	0x101acf640 ; selector mainBundle
1006e54f8:	mov	x29, x29
1006e54fc:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006e5500:	mov	x20, x0
1006e5504:	bl	0x101ace2a0 ; selector infoDictionary
1006e5508:	mov	x29, x29
1006e550c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006e5510:	mov	x21, x0
1006e5514:	mov	x0, x20
1006e5518:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e551c:	adrp	x26, 7146 ; 0x1022cf000
1006e5520:	ldr	x26, [x26, #0x490] ; literal pool symbol address: _$sypN
1006e5524:	cbz	x21, 0x1006e55c4
1006e5528:	adrp	x1, 7145 ; 0x1022ce000
1006e552c:	ldr	x1, [x1, #0x38] ; literal pool symbol address: _$sSSN
1006e5530:	adrp	x3, 7145 ; 0x1022ce000
1006e5534:	ldr	x3, [x3, #0x48] ; literal pool symbol address: _$sSSSHsWP
1006e5538:	add	x2, x26, #0x8
1006e553c:	mov	x0, x21
1006e5540:	bl	0x101ac5ef0 ; symbol stub for: _$sSD10FoundationE36_unconditionallyBridgeFromObjectiveCySDyxq_GSo12NSDictionaryCSgFZ
1006e5544:	mov	x20, x0
1006e5548:	mov	x0, x21
1006e554c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e5550:	ldr	x8, [x20, #0x10]
1006e5554:	cbz	x8, 0x1006e55bc
1006e5558:	mov	x0, #0x744f
1006e555c:	movk	x0, #0x7974, lsl #16
1006e5560:	movk	x0, #0x6947, lsl #32
1006e5564:	movk	x0, #0x4874, lsl #48
1006e5568:	mov	x1, #0x7361
1006e556c:	movk	x1, #0x68, lsl #16
1006e5570:	movk	x1, #0xeb00, lsl #48
1006e5574:	bl	0x1000240a8
1006e5578:	tbz	w1, #0x0, 0x1006e55bc
1006e557c:	ldr	x8, [x20, #0x38]
1006e5580:	add	x0, x8, x0, lsl #5
1006e5584:	sub	x1, x29, #0x70
1006e5588:	bl	0x100029a08
1006e558c:	mov	x0, x20
1006e5590:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e5594:	adrp	x3, 7145 ; 0x1022ce000
1006e5598:	ldr	x3, [x3, #0x38] ; literal pool symbol address: _$sSSN
1006e559c:	add	x0, sp, #0x8
1006e55a0:	sub	x1, x29, #0x70
1006e55a4:	add	x2, x26, #0x8
1006e55a8:	mov	w4, #0x6
1006e55ac:	bl	0x101aca6f0 ; symbol stub for: _swift_dynamicCast
1006e55b0:	cbz	w0, 0x1006e55c4
1006e55b4:	ldp	x19, x21, [sp, #0x8]
1006e55b8:	b	0x1006e55c8
1006e55bc:	mov	x0, x20
1006e55c0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e55c4:	mov	x21, #-0x1900000000000000
1006e55c8:	mov	x8, #0x6168
1006e55cc:	movk	x8, #0x6873, lsl #16
1006e55d0:	movk	x8, #0x203a, lsl #32
1006e55d4:	mov	x9, #-0x1a00000000000000
1006e55d8:	stp	x8, x9, [x29, #-0x70]
1006e55dc:	sub	x20, x29, #0x70
1006e55e0:	mov	x0, x19
1006e55e4:	mov	x1, x21
1006e55e8:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1006e55ec:	mov	x0, x21
1006e55f0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e55f4:	ldp	x20, x19, [x29, #-0x70]
1006e55f8:	adrp	x0, 7269 ; 0x10234a000
1006e55fc:	add	x0, x0, #0xb40
1006e5600:	adrp	x1, 5116 ; 0x101ae1000
1006e5604:	add	x1, x1, #0x290
1006e5608:	bl	0x100003c4c
1006e560c:	add	x1, sp, #0x60
1006e5610:	bl	0x101aca8b8 ; symbol stub for: _swift_initStackObject
1006e5614:	mov	x22, x0
1006e5618:	adrp	x8, 5116 ; 0x101ae1000
1006e561c:	ldr	q0, [x8, #0x140]
1006e5620:	str	q0, [x0, #0x10]
1006e5624:	adrp	x8, 7141 ; 0x1022ca000
1006e5628:	ldr	x8, [x8, #0x5c8] ; literal pool symbol address: _NSFontAttributeName
1006e562c:	ldr	x0, [x8]
1006e5630:	mov	x21, x22
1006e5634:	str	x0, [x21, #0x20]!
1006e5638:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e563c:	bl	0x10002dd04
1006e5640:	mov.16b	v1, v0
1006e5644:	fmov	d0, #11.00000000
1006e5648:	bl	0x100004700
1006e564c:	mov	x23, x0
1006e5650:	adrp	x1, 7285 ; 0x10235a000
1006e5654:	add	x1, x1, #0x560
1006e5658:	adrp	x2, 7233 ; 0x102326000
1006e565c:	add	x2, x2, #0x9e8 ; Objc class ref: _OBJC_CLASS_$_NSFont
1006e5660:	mov	x0, #0x0
1006e5664:	bl	0x10002d97c
1006e5668:	str	x23, [x22, #0x28]
1006e566c:	adrp	x8, 7141 ; 0x1022ca000
1006e5670:	ldr	x8, [x8, #0x638] ; literal pool symbol address: _NSForegroundColorAttributeName
1006e5674:	ldr	x23, [x8]
1006e5678:	stp	x0, x23, [x22, #0x40]
1006e567c:	adrp	x24, 7233 ; 0x102326000
1006e5680:	add	x24, x24, #0x9c8 ; Objc class ref: _OBJC_CLASS_$_NSColor
1006e5684:	ldr	x0, [x24]
1006e5688:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1006e568c:	mov	x25, x0
1006e5690:	mov	x0, x23
1006e5694:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e5698:	mov	x0, x25
1006e569c:	bl	0x101ad12e0 ; selector secondaryLabelColor
1006e56a0:	mov	x29, x29
1006e56a4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006e56a8:	mov	x23, x0
1006e56ac:	adrp	x1, 7262 ; 0x102343000
1006e56b0:	add	x1, x1, #0xb20
1006e56b4:	mov	x0, #0x0
1006e56b8:	mov	x2, x24
1006e56bc:	bl	0x10002d97c
1006e56c0:	str	x0, [x22, #0x68]
1006e56c4:	str	x23, [x22, #0x50]
1006e56c8:	adrp	x1, 7269 ; 0x10234a000
1006e56cc:	add	x1, x1, #0xb60
1006e56d0:	adrp	x2, 5116 ; 0x101ae1000
1006e56d4:	add	x2, x2, #0x7f0
1006e56d8:	mov	x0, x22
1006e56dc:	bl	0x10011ce44
1006e56e0:	mov	x23, x0
1006e56e4:	mov	x0, x22
1006e56e8:	bl	0x101aca990 ; symbol stub for: _swift_setDeallocating
1006e56ec:	adrp	x0, 7269 ; 0x10234a000
1006e56f0:	add	x0, x0, #0xb50
1006e56f4:	adrp	x1, 5116 ; 0x101ae1000
1006e56f8:	add	x1, x1, #0x2a0
1006e56fc:	bl	0x100003c4c
1006e5700:	mov	x2, x0
1006e5704:	mov	x0, x21
1006e5708:	mov	w1, #0x2
1006e570c:	bl	0x101aca5ac ; symbol stub for: _swift_arrayDestroy
1006e5710:	adrp	x8, 7233 ; 0x102326000
1006e5714:	ldr	x0, [x8, #0xb68] ; Objc class ref: _OBJC_CLASS_$_NSAttributedString
1006e5718:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e571c:	mov	x21, x0
1006e5720:	mov	x0, x20
1006e5724:	mov	x1, x19
1006e5728:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e572c:	mov	x22, x0
1006e5730:	mov	x0, x19
1006e5734:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e5738:	mov	x0, #0x0
1006e573c:	bl	0x10002c784
1006e5740:	mov	x19, x0
1006e5744:	adrp	x1, -1721 ; 0x10002c000
1006e5748:	add	x1, x1, #0x784
1006e574c:	adrp	x0, 7259 ; 0x102340000
1006e5750:	add	x0, x0, #0xf30
1006e5754:	adrp	x2, 5117 ; 0x101ae2000
1006e5758:	add	x2, x2, #0x620
1006e575c:	bl	0x10002c7c4
1006e5760:	mov	x3, x0
1006e5764:	add	x2, x26, #0x8
1006e5768:	mov	x0, x23
1006e576c:	mov	x1, x19
1006e5770:	bl	0x101ac5ed8 ; symbol stub for: _$sSD10FoundationE19_bridgeToObjectiveCSo12NSDictionaryCyF
1006e5774:	mov	x19, x0
1006e5778:	mov	x0, x23
1006e577c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e5780:	mov	x0, x21
1006e5784:	mov	x2, x22
1006e5788:	mov	x3, x19
1006e578c:	bl	0x101ace880 ; selector initWithString:attributes:
1006e5790:	mov	x20, x0
1006e5794:	mov	x0, x22
1006e5798:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e579c:	mov	x0, x19
1006e57a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e57a4:	adrp	x8, 7141 ; 0x1022ca000
1006e57a8:	ldr	x8, [x8, #0x558] ; literal pool symbol address: _NSApp
1006e57ac:	ldr	x19, [x8]
1006e57b0:	cbz	x19, 0x1006e58fc
1006e57b4:	adrp	x0, 7294 ; 0x102363000
1006e57b8:	add	x0, x0, #0x68
1006e57bc:	adrp	x1, 5146 ; 0x101aff000
1006e57c0:	add	x1, x1, #0x8b8
1006e57c4:	bl	0x100003c4c
1006e57c8:	add	x1, sp, #0x18
1006e57cc:	bl	0x101aca8b8 ; symbol stub for: _swift_initStackObject
1006e57d0:	mov	x21, x0
1006e57d4:	adrp	x8, 5116 ; 0x101ae1000
1006e57d8:	ldr	q0, [x8, #0x130]
1006e57dc:	str	q0, [x0, #0x10]
1006e57e0:	adrp	x8, 7141 ; 0x1022ca000
1006e57e4:	ldr	x8, [x8, #0x528] ; literal pool symbol address: _NSAboutPanelOptionCredits
1006e57e8:	ldr	x22, [x8]
1006e57ec:	mov	x23, x0
1006e57f0:	str	x22, [x23, #0x20]!
1006e57f4:	adrp	x1, 7294 ; 0x102363000
1006e57f8:	add	x1, x1, #0x70
1006e57fc:	adrp	x2, 7233 ; 0x102326000
1006e5800:	add	x2, x2, #0xb68 ; Objc class ref: _OBJC_CLASS_$_NSAttributedString
1006e5804:	mov	x0, #0x0
1006e5808:	bl	0x10002d97c
1006e580c:	str	x0, [x21, #0x40]
1006e5810:	str	x20, [x21, #0x28]
1006e5814:	mov	x0, x19
1006e5818:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e581c:	mov	x19, x0
1006e5820:	mov	x0, x22
1006e5824:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e5828:	mov	x0, x20
1006e582c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e5830:	mov	x20, x0
1006e5834:	adrp	x1, 7294 ; 0x102363000
1006e5838:	add	x1, x1, #0x88
1006e583c:	adrp	x2, 5146 ; 0x101aff000
1006e5840:	add	x2, x2, #0x8c8
1006e5844:	mov	x0, x21
1006e5848:	bl	0x10011ce44
1006e584c:	mov	x22, x0
1006e5850:	mov	x0, x21
1006e5854:	bl	0x101aca990 ; symbol stub for: _swift_setDeallocating
1006e5858:	adrp	x1, 7294 ; 0x102363000
1006e585c:	add	x1, x1, #0x78
1006e5860:	adrp	x2, 5146 ; 0x101aff000
1006e5864:	add	x2, x2, #0x8c0
1006e5868:	mov	x0, x23
1006e586c:	bl	0x10002d870
1006e5870:	mov	x0, #0x0
1006e5874:	bl	0x1006e5950
1006e5878:	mov	x21, x0
1006e587c:	adrp	x1, 0 ; 0x1006e5000
1006e5880:	add	x1, x1, #0x950
1006e5884:	adrp	x0, 7294 ; 0x102363000
1006e5888:	add	x0, x0, #0x80
1006e588c:	adrp	x2, 5146 ; 0x101aff000
1006e5890:	add	x2, x2, #0xa44
1006e5894:	bl	0x10002c7c4
1006e5898:	mov	x3, x0
1006e589c:	add	x2, x26, #0x8
1006e58a0:	mov	x0, x22
1006e58a4:	mov	x1, x21
1006e58a8:	bl	0x101ac5ed8 ; symbol stub for: _$sSD10FoundationE19_bridgeToObjectiveCSo12NSDictionaryCyF
1006e58ac:	mov	x21, x0
1006e58b0:	mov	x0, x22
1006e58b4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e58b8:	mov	x0, x19
1006e58bc:	mov	x2, x21
1006e58c0:	bl	0x101acfea0 ; selector orderFrontStandardAboutPanelWithOptions:
1006e58c4:	mov	x0, x20
1006e58c8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e58cc:	mov	x0, x19
1006e58d0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e58d4:	mov	x0, x21
1006e58d8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e58dc:	ldp	x29, x30, [sp, #0x140]
1006e58e0:	ldp	x20, x19, [sp, #0x130]
1006e58e4:	ldp	x22, x21, [sp, #0x120]
1006e58e8:	ldp	x24, x23, [sp, #0x110]
1006e58ec:	ldp	x26, x25, [sp, #0x100]
1006e58f0:	ldp	x28, x27, [sp, #0xf0]
1006e58f4:	add	sp, sp, #0x150
1006e58f8:	ret
1006e58fc:	brk	#0x1
1006e5900:	stp	x29, x30, [sp, #-0x10]!
1006e5904:	mov	x29, sp
1006e5908:	adrp	x0, 7248 ; 0x102335000
1006e590c:	add	x0, x0, #0xd8
1006e5910:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1006e5914:	mov	x1, #0x0
1006e5918:	ldp	x29, x30, [sp], #0x10
1006e591c:	ret
1006e5920:	stp	x29, x30, [sp, #-0x10]!
1006e5924:	mov	x29, sp
1006e5928:	adrp	x0, 7247 ; 0x102334000
1006e592c:	add	x0, x0, #0x4c8
1006e5930:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1006e5934:	mov	x1, #0x0
1006e5938:	ldp	x29, x30, [sp], #0x10
1006e593c:	ret
1006e5940:	mov	x0, x20
1006e5944:	mov	w1, #0x20
1006e5948:	mov	w2, #0x7
1006e594c:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1006e5950:	adrp	x1, 7294 ; 0x102363000
1006e5954:	add	x1, x1, #0x4a0
1006e5958:	adrp	x2, 6919 ; 0x1021ec000
1006e595c:	add	x2, x2, #0x768
1006e5960:	b	0x10002db1c
1006e5964:	stp	x29, x30, [sp, #-0x10]!
1006e5968:	mov	x29, sp
1006e596c:	ldr	x0, [x20, #0x10]
1006e5970:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e5974:	mov	x0, x20
1006e5978:	mov	w1, #0x18
1006e597c:	mov	w2, #0x7
1006e5980:	ldp	x29, x30, [sp], #0x10
1006e5984:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1006e5988:	ldr	x1, [x20, #0x10]
1006e598c:	b	0x1006e2ae0
1006e5990:	sub	sp, sp, #0x30
1006e5994:	stp	x29, x30, [sp, #0x20]
1006e5998:	add	x29, sp, #0x20
1006e599c:	ldr	x8, [x20]
1006e59a0:	ldr	x8, [x8, #0x230]
1006e59a4:	mov	x0, sp
1006e59a8:	blr	x8
1006e59ac:	mov	x8, x0
1006e59b0:	ldrb	w9, [x1]
1006e59b4:	mov	w10, #0x1
1006e59b8:	bic	w9, w10, w9
1006e59bc:	strb	w9, [x1]
1006e59c0:	mov	x0, sp
1006e59c4:	mov	w1, #0x0
1006e59c8:	blr	x8
1006e59cc:	adrp	x0, 7260 ; 0x102341000
1006e59d0:	add	x0, x0, #0x6d0
1006e59d4:	adrp	x1, 5116 ; 0x101ae1000
1006e59d8:	add	x1, x1, #0x7e0
1006e59dc:	bl	0x100003c4c
1006e59e0:	adrp	x1, 7294 ; 0x102363000
1006e59e4:	add	x1, x1, #0x460
1006e59e8:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1006e59ec:	ldr	x8, [x20]
1006e59f0:	ldr	x8, [x8, #0x2d0]
1006e59f4:	blr	x8
1006e59f8:	ldp	x29, x30, [sp, #0x20]
1006e59fc:	add	sp, sp, #0x30
1006e5a00:	ret
1006e5a04:	stp	x29, x30, [sp, #-0x10]!
1006e5a08:	mov	x29, sp
1006e5a0c:	add	x0, x20, #0x10
1006e5a10:	bl	0x101acab4c ; symbol stub for: _swift_weakDestroy
1006e5a14:	mov	x0, x20
1006e5a18:	mov	w1, #0x18
1006e5a1c:	mov	w2, #0x7
1006e5a20:	ldp	x29, x30, [sp], #0x10
1006e5a24:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1006e5a28:	sub	sp, sp, #0x50
1006e5a2c:	stp	x22, x21, [sp, #0x20]
1006e5a30:	stp	x20, x19, [sp, #0x30]
1006e5a34:	stp	x29, x30, [sp, #0x40]
1006e5a38:	add	x29, sp, #0x40
1006e5a3c:	ldp	x19, x21, [x20, #0x10]
1006e5a40:	ldr	x8, [x19]
1006e5a44:	ldr	x8, [x8, #0x1e8]
1006e5a48:	mov	x0, sp
1006e5a4c:	mov	x20, x19
1006e5a50:	blr	x8
1006e5a54:	mov	x8, x0
1006e5a58:	ldrb	w9, [x1]
1006e5a5c:	mov	w10, #0x1
1006e5a60:	bic	w9, w10, w9
1006e5a64:	strb	w9, [x1]
1006e5a68:	mov	x0, sp
1006e5a6c:	mov	w1, #0x0
1006e5a70:	blr	x8
1006e5a74:	adrp	x0, 7260 ; 0x102341000
1006e5a78:	add	x0, x0, #0x6d0
1006e5a7c:	adrp	x1, 5116 ; 0x101ae1000
1006e5a80:	add	x1, x1, #0x7e0
1006e5a84:	bl	0x100003c4c
1006e5a88:	adrp	x1, 7294 ; 0x102363000
1006e5a8c:	add	x1, x1, #0x428
1006e5a90:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1006e5a94:	ldr	x8, [x19]
1006e5a98:	ldr	x8, [x8, #0x2d0]
1006e5a9c:	blr	x8
1006e5aa0:	add	x0, x21, #0x10
1006e5aa4:	mov	x1, sp
1006e5aa8:	mov	x2, #0x0
1006e5aac:	mov	x3, #0x0
1006e5ab0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1006e5ab4:	add	x0, x21, #0x10
1006e5ab8:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1006e5abc:	cbz	x0, 0x1006e5ad8
1006e5ac0:	mov	x20, x0
1006e5ac4:	ldr	x8, [x0]
1006e5ac8:	ldr	x8, [x8, #0x6c8]
1006e5acc:	blr	x8
1006e5ad0:	mov	x0, x20
1006e5ad4:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e5ad8:	ldp	x29, x30, [sp, #0x40]
1006e5adc:	ldp	x20, x19, [sp, #0x30]
1006e5ae0:	ldp	x22, x21, [sp, #0x20]
1006e5ae4:	add	sp, sp, #0x50
1006e5ae8:	ret
1006e5aec:	sub	sp, sp, #0x50
1006e5af0:	stp	x22, x21, [sp, #0x20]
1006e5af4:	stp	x20, x19, [sp, #0x30]
1006e5af8:	stp	x29, x30, [sp, #0x40]
1006e5afc:	add	x29, sp, #0x40
1006e5b00:	ldp	x19, x21, [x20, #0x10]
1006e5b04:	ldr	x8, [x19]
1006e5b08:	ldr	x8, [x8, #0x1d0]
1006e5b0c:	mov	x0, sp
1006e5b10:	mov	x20, x19
1006e5b14:	blr	x8
1006e5b18:	mov	x8, x0
1006e5b1c:	ldrb	w9, [x1]
1006e5b20:	mov	w10, #0x1
1006e5b24:	bic	w9, w10, w9
1006e5b28:	strb	w9, [x1]
1006e5b2c:	mov	x0, sp
1006e5b30:	mov	w1, #0x0
1006e5b34:	blr	x8
1006e5b38:	adrp	x0, 7260 ; 0x102341000
1006e5b3c:	add	x0, x0, #0x6d0
1006e5b40:	adrp	x1, 5116 ; 0x101ae1000
1006e5b44:	add	x1, x1, #0x7e0
1006e5b48:	bl	0x100003c4c
1006e5b4c:	adrp	x1, 7294 ; 0x102363000
1006e5b50:	add	x1, x1, #0x3f0
1006e5b54:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1006e5b58:	ldr	x8, [x19]
1006e5b5c:	ldr	x8, [x8, #0x2d0]
1006e5b60:	blr	x8
1006e5b64:	add	x0, x21, #0x10
1006e5b68:	mov	x1, sp
1006e5b6c:	mov	x2, #0x0
1006e5b70:	mov	x3, #0x0
1006e5b74:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1006e5b78:	add	x0, x21, #0x10
1006e5b7c:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1006e5b80:	cbz	x0, 0x1006e5b9c
1006e5b84:	mov	x20, x0
1006e5b88:	ldr	x8, [x0]
1006e5b8c:	ldr	x8, [x8, #0x6c8]
1006e5b90:	blr	x8
1006e5b94:	mov	x0, x20
1006e5b98:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e5b9c:	ldp	x29, x30, [sp, #0x40]
1006e5ba0:	ldp	x20, x19, [sp, #0x30]
1006e5ba4:	ldp	x22, x21, [sp, #0x20]
1006e5ba8:	add	sp, sp, #0x50
1006e5bac:	ret
1006e5bb0:	sub	sp, sp, #0x50
1006e5bb4:	stp	x22, x21, [sp, #0x20]
1006e5bb8:	stp	x20, x19, [sp, #0x30]
1006e5bbc:	stp	x29, x30, [sp, #0x40]
1006e5bc0:	add	x29, sp, #0x40
1006e5bc4:	ldp	x19, x21, [x20, #0x10]
1006e5bc8:	ldr	x8, [x19]
1006e5bcc:	ldr	x8, [x8, #0x1b8]
1006e5bd0:	mov	x0, sp
1006e5bd4:	mov	x20, x19
1006e5bd8:	blr	x8
1006e5bdc:	mov	x8, x0
1006e5be0:	ldrb	w9, [x1]
1006e5be4:	mov	w10, #0x1
1006e5be8:	bic	w9, w10, w9
1006e5bec:	strb	w9, [x1]
1006e5bf0:	mov	x0, sp
1006e5bf4:	mov	w1, #0x0
1006e5bf8:	blr	x8
1006e5bfc:	adrp	x0, 7260 ; 0x102341000
1006e5c00:	add	x0, x0, #0x6d0
1006e5c04:	adrp	x1, 5116 ; 0x101ae1000
1006e5c08:	add	x1, x1, #0x7e0
1006e5c0c:	bl	0x100003c4c
1006e5c10:	adrp	x1, 7294 ; 0x102363000
1006e5c14:	add	x1, x1, #0x3b8
1006e5c18:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1006e5c1c:	ldr	x8, [x19]
1006e5c20:	ldr	x8, [x8, #0x2d0]
1006e5c24:	blr	x8
1006e5c28:	add	x0, x21, #0x10
1006e5c2c:	mov	x1, sp
1006e5c30:	mov	x2, #0x0
1006e5c34:	mov	x3, #0x0
1006e5c38:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1006e5c3c:	add	x0, x21, #0x10
1006e5c40:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1006e5c44:	cbz	x0, 0x1006e5c60
1006e5c48:	mov	x20, x0
1006e5c4c:	ldr	x8, [x0]
1006e5c50:	ldr	x8, [x8, #0x6c8]
1006e5c54:	blr	x8
1006e5c58:	mov	x0, x20
1006e5c5c:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e5c60:	ldp	x29, x30, [sp, #0x40]
1006e5c64:	ldp	x20, x19, [sp, #0x30]
1006e5c68:	ldp	x22, x21, [sp, #0x20]
1006e5c6c:	add	sp, sp, #0x50
1006e5c70:	ret
1006e5c74:	sub	sp, sp, #0x30
1006e5c78:	stp	x29, x30, [sp, #0x20]
1006e5c7c:	add	x29, sp, #0x20
1006e5c80:	ldr	x8, [x20]
1006e5c84:	ldr	x8, [x8, #0x218]
1006e5c88:	mov	x0, sp
1006e5c8c:	blr	x8
1006e5c90:	mov	x8, x0
1006e5c94:	ldrb	w9, [x1]
1006e5c98:	mov	w10, #0x1
1006e5c9c:	bic	w9, w10, w9
1006e5ca0:	strb	w9, [x1]
1006e5ca4:	mov	x0, sp
1006e5ca8:	mov	w1, #0x0
1006e5cac:	blr	x8
1006e5cb0:	adrp	x0, 7260 ; 0x102341000
1006e5cb4:	add	x0, x0, #0x6d0
1006e5cb8:	adrp	x1, 5116 ; 0x101ae1000
1006e5cbc:	add	x1, x1, #0x7e0
1006e5cc0:	bl	0x100003c4c
1006e5cc4:	adrp	x1, 7294 ; 0x102363000
1006e5cc8:	add	x1, x1, #0x380
1006e5ccc:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1006e5cd0:	ldr	x8, [x20]
1006e5cd4:	ldr	x8, [x8, #0x2d0]
1006e5cd8:	blr	x8
1006e5cdc:	ldp	x29, x30, [sp, #0x20]
1006e5ce0:	add	sp, sp, #0x30
1006e5ce4:	ret
1006e5ce8:	sub	sp, sp, #0x30
1006e5cec:	stp	x29, x30, [sp, #0x20]
1006e5cf0:	add	x29, sp, #0x20
1006e5cf4:	ldr	x8, [x20]
1006e5cf8:	ldr	x8, [x8, #0x200]
1006e5cfc:	mov	x0, sp
1006e5d00:	blr	x8
1006e5d04:	mov	x8, x0
1006e5d08:	ldrb	w9, [x1]
1006e5d0c:	mov	w10, #0x1
1006e5d10:	bic	w9, w10, w9
1006e5d14:	strb	w9, [x1]
1006e5d18:	mov	x0, sp
1006e5d1c:	mov	w1, #0x0
1006e5d20:	blr	x8
1006e5d24:	adrp	x0, 7260 ; 0x102341000
1006e5d28:	add	x0, x0, #0x6d0
1006e5d2c:	adrp	x1, 5116 ; 0x101ae1000
1006e5d30:	add	x1, x1, #0x7e0
1006e5d34:	bl	0x100003c4c
1006e5d38:	adrp	x1, 7294 ; 0x102363000
1006e5d3c:	add	x1, x1, #0x348
1006e5d40:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1006e5d44:	ldr	x8, [x20]
1006e5d48:	ldr	x8, [x8, #0x2d0]
1006e5d4c:	blr	x8
1006e5d50:	ldp	x29, x30, [sp, #0x20]
1006e5d54:	add	sp, sp, #0x30
1006e5d58:	ret
1006e5d5c:	cmp	x0, #0x3e8
1006e5d60:	b.eq	0x1006e5d74
1006e5d64:	cmp	x0, #0x3e9
1006e5d68:	b.ne	0x1006e5d84
1006e5d6c:	mov	w0, #0x1
1006e5d70:	b	0x1006e5d78
1006e5d74:	mov	w0, #0x0
1006e5d78:	ldr	x8, [x20]
1006e5d7c:	ldr	x1, [x8, #0x5d8]
1006e5d80:	br	x1
1006e5d84:	ret
1006e5d88:	stp	x29, x30, [sp, #-0x10]!
1006e5d8c:	mov	x29, sp
1006e5d90:	ldr	x0, [x20, #0x18]
1006e5d94:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e5d98:	mov	x0, x20
1006e5d9c:	mov	w1, #0x20
1006e5da0:	mov	w2, #0x7
1006e5da4:	ldp	x29, x30, [sp], #0x10
1006e5da8:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1006e5dac:	stp	x29, x30, [sp, #-0x10]!
1006e5db0:	mov	x29, sp
1006e5db4:	ldr	x0, [x20, #0x10]
1006e5db8:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e5dbc:	ldr	x0, [x20, #0x20]
1006e5dc0:	cbz	x0, 0x1006e5dd8
1006e5dc4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e5dc8:	ldr	x0, [x20, #0x48]
1006e5dcc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e5dd0:	ldr	x0, [x20, #0x50]
1006e5dd4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e5dd8:	ldr	x0, [x20, #0x78]
1006e5ddc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e5de0:	mov	x0, x20
1006e5de4:	mov	w1, #0x80
1006e5de8:	mov	w2, #0x7
1006e5dec:	ldp	x29, x30, [sp], #0x10
1006e5df0:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1006e5df4:	sub	sp, sp, #0xd0
1006e5df8:	stp	x24, x23, [sp, #0x90]
1006e5dfc:	stp	x22, x21, [sp, #0xa0]
1006e5e00:	stp	x20, x19, [sp, #0xb0]
1006e5e04:	stp	x29, x30, [sp, #0xc0]
1006e5e08:	add	x29, sp, #0xc0
1006e5e0c:	ldr	x23, [x20, #0x10]
1006e5e10:	ldp	x22, x19, [x20, #0x70]
1006e5e14:	add	x0, x23, #0x10
1006e5e18:	sub	x1, x29, #0x48
1006e5e1c:	mov	x2, #0x0
1006e5e20:	mov	x3, #0x0
1006e5e24:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1006e5e28:	add	x0, x23, #0x10
1006e5e2c:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1006e5e30:	cbz	x0, 0x1006e5eb8
1006e5e34:	adrp	x8, 7293 ; 0x102362000
1006e5e38:	ldr	x8, [x8, #0xd58]
1006e5e3c:	add	x9, x0, x8
1006e5e40:	ldp	x8, x1, [x9]
1006e5e44:	ldp	x2, x3, [x9, #0x10]
1006e5e48:	ldp	x4, x5, [x9, #0x20]
1006e5e4c:	ldp	x6, x7, [x9, #0x30]
1006e5e50:	ldp	x10, x11, [x9, #0x40]
1006e5e54:	ldrb	w12, [x9, #0x50]
1006e5e58:	ldur	q0, [x20, #0x28]
1006e5e5c:	ldur	q1, [x20, #0x18]
1006e5e60:	stp	q1, q0, [x9]
1006e5e64:	ldur	q0, [x20, #0x48]
1006e5e68:	ldur	q1, [x20, #0x58]
1006e5e6c:	ldrb	w13, [x20, #0x68]
1006e5e70:	ldur	q2, [x20, #0x38]
1006e5e74:	strb	w13, [x9, #0x50]
1006e5e78:	stp	q0, q1, [x9, #0x30]
1006e5e7c:	str	q2, [x9, #0x20]
1006e5e80:	strb	w12, [sp, #0x10]
1006e5e84:	stp	x10, x11, [sp]
1006e5e88:	mov	x21, x0
1006e5e8c:	mov	x0, x8
1006e5e90:	bl	0x10068d274
1006e5e94:	adrp	x2, 7293 ; 0x102362000
1006e5e98:	add	x2, x2, #0xd50
1006e5e9c:	adrp	x3, 5136 ; 0x101af5000
1006e5ea0:	add	x3, x3, #0xd80
1006e5ea4:	add	x0, x20, #0x18
1006e5ea8:	add	x1, sp, #0x20
1006e5eac:	bl	0x10002d8f4
1006e5eb0:	mov	x0, x21
1006e5eb4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e5eb8:	add	x0, x23, #0x10
1006e5ebc:	add	x1, sp, #0x20
1006e5ec0:	mov	x2, #0x0
1006e5ec4:	mov	x3, #0x0
1006e5ec8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1006e5ecc:	add	x0, x23, #0x10
1006e5ed0:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1006e5ed4:	cbz	x0, 0x1006e5f08
1006e5ed8:	adrp	x8, 7293 ; 0x102362000
1006e5edc:	ldr	x8, [x8, #0xd48]
1006e5ee0:	add	x9, x0, x8
1006e5ee4:	ldr	x8, [x9, #0x8]
1006e5ee8:	stp	x22, x19, [x9]
1006e5eec:	mov	x20, x0
1006e5ef0:	mov	x0, x8
1006e5ef4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e5ef8:	mov	x0, x19
1006e5efc:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1006e5f00:	mov	x0, x20
1006e5f04:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e5f08:	ldp	x29, x30, [sp, #0xc0]
1006e5f0c:	ldp	x20, x19, [sp, #0xb0]
1006e5f10:	ldp	x22, x21, [sp, #0xa0]
1006e5f14:	ldp	x24, x23, [sp, #0x90]
1006e5f18:	add	sp, sp, #0xd0
1006e5f1c:	ret
1006e5f20:	adrp	x8, 7294 ; 0x102363000
1006e5f24:	ldr	x0, [x8, #0x490]
1006e5f28:	cbz	x0, 0x1006e5f30
1006e5f2c:	ret
1006e5f30:	stp	x29, x30, [sp, #-0x10]!
1006e5f34:	mov	x29, sp
1006e5f38:	adrp	x0, 5140 ; 0x101af9000
1006e5f3c:	add	x0, x0, #0xeb8
1006e5f40:	adrp	x1, 6911 ; 0x1021e4000
1006e5f44:	add	x1, x1, #0xbd8
1006e5f48:	bl	0x101aca87c ; symbol stub for: _swift_getWitnessTable
1006e5f4c:	adrp	x8, 7294 ; 0x102363000
1006e5f50:	add	x8, x8, #0x490
1006e5f54:	stlr	x0, [x8]
1006e5f58:	ldp	x29, x30, [sp], #0x10
1006e5f5c:	ret
1006e5f60:	stp	x29, x30, [sp, #-0x10]!
1006e5f64:	mov	x29, sp
1006e5f68:	adrp	x0, 7294 ; 0x102363000
1006e5f6c:	add	x0, x0, #0x4b0
1006e5f70:	adrp	x1, 0 ; 0x1006e5000
1006e5f74:	add	x1, x1, #0x950
1006e5f78:	adrp	x2, 5146 ; 0x101aff000
1006e5f7c:	add	x2, x2, #0x95c
1006e5f80:	bl	0x10002c7c4
1006e5f84:	ldp	x29, x30, [sp], #0x10
1006e5f88:	ret
1006e5f8c:	stp	x29, x30, [sp, #-0x10]!
1006e5f90:	mov	x29, sp
1006e5f94:	adrp	x0, 7294 ; 0x102363000
1006e5f98:	add	x0, x0, #0x4b8
1006e5f9c:	adrp	x1, 0 ; 0x1006e5000
1006e5fa0:	add	x1, x1, #0x950
1006e5fa4:	adrp	x2, 5146 ; 0x101aff000
1006e5fa8:	add	x2, x2, #0x930
1006e5fac:	bl	0x10002c7c4
1006e5fb0:	ldp	x29, x30, [sp], #0x10
1006e5fb4:	ret
1006e5fb8:	stp	x29, x30, [sp, #-0x10]!
1006e5fbc:	mov	x29, sp
1006e5fc0:	adrp	x0, 7294 ; 0x102363000
1006e5fc4:	add	x0, x0, #0x4c0
1006e5fc8:	adrp	x1, 0 ; 0x1006e5000
1006e5fcc:	add	x1, x1, #0x950
1006e5fd0:	adrp	x2, 5146 ; 0x101aff000
1006e5fd4:	add	x2, x2, #0x9cc
1006e5fd8:	bl	0x10002c7c4
1006e5fdc:	ldp	x29, x30, [sp], #0x10
1006e5fe0:	ret
1006e5fe4:	b	0x1006e3bec
1006e5fe8:	b	0x1006e3bec
1006e5fec:	b	0x1006e3bec
1006e5ff0:	b	0x1006e3c00
1006e5ff4:	b	0x1006e3c00
1006e5ff8:	b	0x1006e3c00
1006e5ffc:	b	0x1006dbce0
