
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101446824 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E>:
101446860: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
101446864: a90167fa    	stp	x26, x25, [sp, #0x10]
101446868: a9025ff8    	stp	x24, x23, [sp, #0x20]
10144686c: a90357f6    	stp	x22, x21, [sp, #0x30]
101446870: a9044ff4    	stp	x20, x19, [sp, #0x40]
101446874: a9057bfd    	stp	x29, x30, [sp, #0x50]
101446878: 910143fd    	add	x29, sp, #0x50
10144687c: d11283e9    	sub	x9, sp, #0x4a0
101446880: 9279e13f    	and	sp, x9, #0xffffffffffffff80
101446884: f90003ff    	str	xzr, [sp]
101446888: aa0003f4    	mov	x20, x0
10144688c: b4000882    	cbz	x2, 0x10144699c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x178>
101446890: aa0703f8    	mov	x24, x7
101446894: aa0603f6    	mov	x22, x6
101446898: aa0503f7    	mov	x23, x5
10144689c: aa0403f3    	mov	x19, x4
1014468a0: aa0303f5    	mov	x21, x3
1014468a4: aa0103f9    	mov	x25, x1
1014468a8: d100045a    	sub	x26, x2, #0x1
1014468ac: a9400420    	ldp	x0, x1, [x1]
1014468b0: 910103e8    	add	x8, sp, #0x40
1014468b4: 940ded4d    	bl	0x1017c1de8 <__ZN3std3sys7process4unix6common7Command3new17h3ae46a10d36f3b8dE>
1014468b8: b400011a    	cbz	x26, 0x1014468d8 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xb4>
1014468bc: 91004339    	add	x25, x25, #0x10
1014468c0: 8b1a133a    	add	x26, x25, x26, lsl #4
1014468c4: a8c10b21    	ldp	x1, x2, [x25], #0x10
1014468c8: 910103e0    	add	x0, sp, #0x40
1014468cc: 940decd8    	bl	0x1017c1c2c <__ZN3std3sys7process4unix6common7Command3arg17h1fb6297ebb32a5b5E>
1014468d0: eb1a033f    	cmp	x25, x26
1014468d4: 54ffff81    	b.ne	0x1014468c4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xa0>
1014468d8: 910103e0    	add	x0, sp, #0x40
1014468dc: 52800021    	mov	w1, #0x1                ; =1
1014468e0: 940dede1    	bl	0x1017c2064 <__ZN3std3sys7process4unix6common7Command5stdin17he05d2920cc1cdacaE>
1014468e4: 910103e0    	add	x0, sp, #0x40
1014468e8: 52800041    	mov	w1, #0x2                ; =2
1014468ec: 940dee3e    	bl	0x1017c21e4 <__ZN3std3sys7process4unix6common7Command6stdout17hb5275bb9375ba951E>
1014468f0: 7100031f    	cmp	w24, #0x0
1014468f4: 52800028    	mov	w8, #0x1                ; =1
1014468f8: 1a880501    	cinc	w1, w8, ne
1014468fc: 910103e0    	add	x0, sp, #0x40
101446900: 940dee28    	bl	0x1017c21a0 <__ZN3std3sys7process4unix6common7Command6stderr17h0082f293763cae08E>
101446904: b40000b5    	cbz	x21, 0x101446918 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xf4>
101446908: 910103e0    	add	x0, sp, #0x40
10144690c: aa1503e1    	mov	x1, x21
101446910: aa1303e2    	mov	x2, x19
101446914: 940ded00    	bl	0x1017c1d14 <__ZN3std3sys7process4unix6common7Command3cwd17he2af3dce12b17622E>
101446918: 90007122    	adrp	x2, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
10144691c: 9112c042    	add	x2, x2, #0x4b0
101446920: 910103e0    	add	x0, sp, #0x40
101446924: 52800021    	mov	w1, #0x1                ; =1
101446928: 940dee40    	bl	0x1017c2228 <__ZN3std3sys7process4unix6common7Command8pre_exec17h5ec95e356a0cda7eE>
10144692c: 910603e8    	add	x8, sp, #0x180
101446930: 910103e0    	add	x0, sp, #0x40
101446934: 940e058a    	bl	0x1017c7f5c <__ZN3std7process7Command5spawn17h3ccafe47d6dac765E>
101446938: b94183e8    	ldr	w8, [sp, #0x180]
10144693c: 7100091f    	cmp	w8, #0x2
101446940: 54000341    	b.ne	0x1014469a8 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x184>
101446944: f940c7f3    	ldr	x19, [sp, #0x188]
101446948: 92400668    	and	x8, x19, #0x3
10144694c: f100051f    	cmp	x8, #0x1
101446950: 54000201    	b.ne	0x101446990 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x16c>
101446954: f85ffe75    	ldr	x21, [x19, #-0x1]!
101446958: f9400676    	ldr	x22, [x19, #0x8]
10144695c: f94002c8    	ldr	x8, [x22]
101446960: b4000068    	cbz	x8, 0x10144696c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x148>
101446964: aa1503e0    	mov	x0, x21
101446968: d63f0100    	blr	x8
10144696c: f94006c1    	ldr	x1, [x22, #0x8]
101446970: b4000081    	cbz	x1, 0x101446980 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x15c>
101446974: f9400ac2    	ldr	x2, [x22, #0x10]
101446978: aa1503e0    	mov	x0, x21
10144697c: 97d95f58    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101446980: aa1303e0    	mov	x0, x19
101446984: 52800301    	mov	w1, #0x18               ; =24
101446988: 52800102    	mov	w2, #0x8                ; =8
10144698c: 97d95f54    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101446990: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101446994: f9000288    	str	x8, [x20]
101446998: 140001cd    	b	0x1014470cc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x8a8>
10144699c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014469a0: f9000288    	str	x8, [x20]
1014469a4: 140001cc    	b	0x1014470d4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x8b0>
1014469a8: 910423fb    	add	x27, sp, #0x108
1014469ac: 3cc7c360    	ldur	q0, [x27, #0x7c]
1014469b0: 3c804360    	stur	q0, [x27, #0x4]
1014469b4: b94197f5    	ldr	w21, [sp, #0x194]
1014469b8: b9011ff5    	str	w21, [sp, #0x11c]
1014469bc: b9010be8    	str	w8, [sp, #0x108]
1014469c0: b9411bfa    	ldr	w26, [sp, #0x118]
1014469c4: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
1014469c8: fd008fe0    	str	d0, [sp, #0x118]
1014469cc: d0007cbc    	adrp	x28, 0x1023dc000 <__ZN15crossbeam_utils6atomic11atomic_cell4lock5LOCKS17he2ac33ecd5b81040E+0x1680>
1014469d0: 912d839c    	add	x28, x28, #0xb60
1014469d4: 310006bf    	cmn	w21, #0x1
1014469d8: 540000e0    	b.eq	0x1014469f4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x1d0>
1014469dc: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014469e0: f901ffe8    	str	x8, [sp, #0x3f8]
1014469e4: f9400388    	ldr	x8, [x28]
1014469e8: b40000a8    	cbz	x8, 0x1014469fc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x1d8>
1014469ec: d1000518    	sub	x24, x8, #0x1
1014469f0: 1400003f    	b	0x101446aec <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2c8>
1014469f4: f90093ff    	str	xzr, [sp, #0x120]
1014469f8: 14000088    	b	0x101446c18 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x3f4>
1014469fc: 900044e0    	adrp	x0, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
101446a00: 912cc000    	add	x0, x0, #0xb30
101446a04: 911083e8    	add	x8, sp, #0x420
101446a08: 528001c1    	mov	w1, #0xe                ; =14
101446a0c: 940dbc51    	bl	0x1017b5b50 <__ZN3std3env7_var_os17h289066a7989eb522E>
101446a10: f94213f9    	ldr	x25, [sp, #0x420]
101446a14: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101446a18: eb08033f    	cmp	x25, x8
101446a1c: 54000061    	b.ne	0x101446a28 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x204>
101446a20: 52a00418    	mov	w24, #0x200000          ; =2097152
101446a24: 14000030    	b	0x101446ae4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2c0>
101446a28: aa1a03f3    	mov	x19, x26
101446a2c: f94217fa    	ldr	x26, [sp, #0x428]
101446a30: f9421be1    	ldr	x1, [sp, #0x430]
101446a34: 910603e8    	add	x8, sp, #0x180
101446a38: aa1a03e0    	mov	x0, x26
101446a3c: 940f789f    	bl	0x101824cb8 <__ZN4core3str8converts9from_utf817ha54c467cc832e2ffE>
101446a40: b94183e8    	ldr	w8, [sp, #0x180]
101446a44: 7100051f    	cmp	w8, #0x1
101446a48: 54000400    	b.eq	0x101446ac8 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2a4>
101446a4c: f940cbe9    	ldr	x9, [sp, #0x190]
101446a50: b40003c9    	cbz	x9, 0x101446ac8 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2a4>
101446a54: f940c7e8    	ldr	x8, [sp, #0x188]
101446a58: f100053f    	cmp	x9, #0x1
101446a5c: 54000101    	b.ne	0x101446a7c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x258>
101446a60: 3940010a    	ldrb	w10, [x8]
101446a64: 52a00418    	mov	w24, #0x200000          ; =2097152
101446a68: 7100ad5f    	cmp	w10, #0x2b
101446a6c: 54000300    	b.eq	0x101446acc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2a8>
101446a70: 7100b55f    	cmp	w10, #0x2d
101446a74: 540002c0    	b.eq	0x101446acc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2a8>
101446a78: 14000002    	b	0x101446a80 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x25c>
101446a7c: 3940010a    	ldrb	w10, [x8]
101446a80: 7100ad5f    	cmp	w10, #0x2b
101446a84: 1a9f17ea    	cset	w10, eq
101446a88: 9a881508    	cinc	x8, x8, eq
101446a8c: cb0a0129    	sub	x9, x9, x10
101446a90: f100453f    	cmp	x9, #0x11
101446a94: 54003662    	b.hs	0x101447160 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x93c>
101446a98: d2800018    	mov	x24, #0x0               ; =0
101446a9c: b4000189    	cbz	x9, 0x101446acc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2a8>
101446aa0: 5280014a    	mov	w10, #0xa               ; =10
101446aa4: 3840150b    	ldrb	w11, [x8], #0x1
101446aa8: 5100c16b    	sub	w11, w11, #0x30
101446aac: 7100257f    	cmp	w11, #0x9
101446ab0: 540000c8    	b.hi	0x101446ac8 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2a4>
101446ab4: 9b0a7f0c    	mul	x12, x24, x10
101446ab8: 8b2b4198    	add	x24, x12, w11, uxtw
101446abc: f1000529    	subs	x9, x9, #0x1
101446ac0: 54ffff21    	b.ne	0x101446aa4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x280>
101446ac4: 14000002    	b	0x101446acc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2a8>
101446ac8: 52a00418    	mov	w24, #0x200000          ; =2097152
101446acc: b40000b9    	cbz	x25, 0x101446ae0 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2bc>
101446ad0: aa1a03e0    	mov	x0, x26
101446ad4: aa1903e1    	mov	x1, x25
101446ad8: 52800022    	mov	w2, #0x1                ; =1
101446adc: 97d95f00    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101446ae0: aa1303fa    	mov	x26, x19
101446ae4: 91000708    	add	x8, x24, #0x1
101446ae8: f9000388    	str	x8, [x28]
101446aec: 940dff29    	bl	0x1017c6790 <__ZN3std6thread2id8ThreadId3new17hfe165afcc1283f9eE>
101446af0: 910fe3e1    	add	x1, sp, #0x3f8
101446af4: 940dff75    	bl	0x1017c68c8 <__ZN3std6thread6thread6Thread3new17h7b25d1ddb970d059E>
101446af8: f90093e0    	str	x0, [sp, #0x120]
101446afc: 9104e3e8    	add	x8, sp, #0x138
101446b00: 910483e0    	add	x0, sp, #0x120
101446b04: 940e0302    	bl	0x1017c770c <__ZN3std6thread9spawnhook15run_spawn_hooks17h5ea1de6c6de4a5c8E>
101446b08: 52800028    	mov	w8, #0x1                ; =1
101446b0c: 4e080d00    	dup.2d	v0, x8
101446b10: 3d8063e0    	str	q0, [sp, #0x180]
101446b14: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101446b18: a91923ff    	stp	xzr, x8, [sp, #0x190]
101446b1c: 97d95ef5    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101446b20: 52800600    	mov	w0, #0x30               ; =48
101446b24: 52800101    	mov	w1, #0x8                ; =8
101446b28: 97d95eec    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101446b2c: b40036a0    	cbz	x0, 0x101447200 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x9dc>
101446b30: aa0003f9    	mov	x25, x0
101446b34: ad4c07e0    	ldp	q0, q1, [sp, #0x180]
101446b38: ad000400    	stp	q0, q1, [x0]
101446b3c: 3dc06be0    	ldr	q0, [sp, #0x1a0]
101446b40: 3d800800    	str	q0, [x0, #0x20]
101446b44: f901efe0    	str	x0, [sp, #0x3d8]
101446b48: 52800028    	mov	w8, #0x1                ; =1
101446b4c: f8280008    	ldadd	x8, x8, [x0]
101446b50: b7f83dc8    	tbnz	x8, #0x3f, 0x101447308 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xae4>
101446b54: b9044bf5    	str	w21, [sp, #0x448]
101446b58: ad418760    	ldp	q0, q1, [x27, #0x30]
101446b5c: 3d810be0    	str	q0, [sp, #0x420]
101446b60: 3d810fe1    	str	q1, [sp, #0x430]
101446b64: f90223f9    	str	x25, [sp, #0x440]
101446b68: f9400b28    	ldr	x8, [x25, #0x10]
101446b6c: b4000068    	cbz	x8, 0x101446b78 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x354>
101446b70: 91004100    	add	x0, x8, #0x10
101446b74: 940dff29    	bl	0x1017c6818 <__ZN3std6thread6scoped9ScopeData29increment_num_running_threads17hf05734fd928f52cdE>
101446b78: 3dc10be0    	ldr	q0, [sp, #0x420]
101446b7c: 3dc10fe1    	ldr	q1, [sp, #0x430]
101446b80: ad0c07e0    	stp	q0, q1, [sp, #0x180]
101446b84: 3dc113e0    	ldr	q0, [sp, #0x440]
101446b88: 3d806be0    	str	q0, [sp, #0x1a0]
101446b8c: 97d95ed9    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101446b90: 52800600    	mov	w0, #0x30               ; =48
101446b94: 52800101    	mov	w1, #0x8                ; =8
101446b98: 97d95ed0    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101446b9c: b40033c0    	cbz	x0, 0x101447214 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x9f0>
101446ba0: 3dc10be0    	ldr	q0, [sp, #0x420]
101446ba4: 3dc10fe1    	ldr	q1, [sp, #0x430]
101446ba8: ad000400    	stp	q0, q1, [x0]
101446bac: 3dc113e0    	ldr	q0, [sp, #0x440]
101446bb0: 3d800800    	str	q0, [x0, #0x20]
101446bb4: f94093e8    	ldr	x8, [sp, #0x120]
101446bb8: 52800029    	mov	w9, #0x1                ; =1
101446bbc: f8290108    	ldadd	x9, x8, [x8]
101446bc0: b7f83a48    	tbnz	x8, #0x3f, 0x101447308 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xae4>
101446bc4: f94093e8    	ldr	x8, [sp, #0x120]
101446bc8: a91803e8    	stp	x8, x0, [sp, #0x180]
101446bcc: f0007108    	adrp	x8, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101446bd0: 91394108    	add	x8, x8, #0xe50
101446bd4: f900cbe8    	str	x8, [sp, #0x190]
101446bd8: 97d95ec6    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101446bdc: 52800300    	mov	w0, #0x18               ; =24
101446be0: 52800101    	mov	w1, #0x8                ; =8
101446be4: 97d95ebd    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101446be8: b40031e0    	cbz	x0, 0x101447224 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xa00>
101446bec: aa0003e1    	mov	x1, x0
101446bf0: 3dc063e0    	ldr	q0, [sp, #0x180]
101446bf4: 3d800000    	str	q0, [x0]
101446bf8: f940cbe8    	ldr	x8, [sp, #0x190]
101446bfc: f9000808    	str	x8, [x0, #0x10]
101446c00: aa1803e0    	mov	x0, x24
101446c04: 940de405    	bl	0x1017bfc18 <__ZN3std3sys6thread4unix6Thread3new17h310ce26df5a62a27E>
101446c08: 370034e0    	tbnz	w0, #0x0, 0x1014472a4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xa80>
101446c0c: f94093e8    	ldr	x8, [sp, #0x120]
101446c10: a91267e8    	stp	x8, x25, [sp, #0x120]
101446c14: f9009be1    	str	x1, [sp, #0x130]
101446c18: 52800028    	mov	w8, #0x1                ; =1
101446c1c: 4e080d00    	dup.2d	v0, x8
101446c20: 3d80c3e0    	str	q0, [sp, #0x300]
101446c24: 390c43ff    	strb	wzr, [sp, #0x310]
101446c28: f90143ff    	str	xzr, [sp, #0x280]
101446c2c: 390a23ff    	strb	wzr, [sp, #0x288]
101446c30: a9187fff    	stp	xzr, xzr, [sp, #0x180]
101446c34: f90107ff    	str	xzr, [sp, #0x208]
101446c38: f90103ff    	str	xzr, [sp, #0x200]
101446c3c: 52800109    	mov	w9, #0x8                ; =8
101446c40: f9014bff    	str	xzr, [sp, #0x290]
101446c44: f9014fe9    	str	x9, [sp, #0x298]
101446c48: f90157ff    	str	xzr, [sp, #0x2a8]
101446c4c: f90153ff    	str	xzr, [sp, #0x2a0]
101446c50: f9015be9    	str	x9, [sp, #0x2b0]
101446c54: f9015fff    	str	xzr, [sp, #0x2b8]
101446c58: 390b03e8    	strb	w8, [sp, #0x2c0]
101446c5c: 97d95ea5    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101446c60: 52804000    	mov	w0, #0x200              ; =512
101446c64: 52801001    	mov	w1, #0x80               ; =128
101446c68: 97d95e9c    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101446c6c: aa0003f5    	mov	x21, x0
101446c70: b4002a60    	cbz	x0, 0x1014471bc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x998>
101446c74: 910603e1    	add	x1, sp, #0x180
101446c78: aa1503e0    	mov	x0, x21
101446c7c: 52804002    	mov	w2, #0x200              ; =512
101446c80: 941a0bea    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101446c84: b90163fa    	str	w26, [sp, #0x160]
101446c88: 3dc00360    	ldr	q0, [x27]
101446c8c: 3d801360    	str	q0, [x27, #0x40]
101446c90: f9408fe8    	ldr	x8, [sp, #0x118]
101446c94: f900afe8    	str	x8, [sp, #0x158]
101446c98: 52800028    	mov	w8, #0x1                ; =1
101446c9c: a913d7e8    	stp	x8, x21, [sp, #0x138]
101446ca0: f9001ff5    	str	x21, [sp, #0x38]
101446ca4: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101446ca8: f901efe8    	str	x8, [sp, #0x3d8]
101446cac: f9400388    	ldr	x8, [x28]
101446cb0: b4000068    	cbz	x8, 0x101446cbc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x498>
101446cb4: d1000518    	sub	x24, x8, #0x1
101446cb8: 1400003d    	b	0x101446dac <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x588>
101446cbc: 900044e0    	adrp	x0, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
101446cc0: 912cc000    	add	x0, x0, #0xb30
101446cc4: 911083e8    	add	x8, sp, #0x420
101446cc8: 528001c1    	mov	w1, #0xe                ; =14
101446ccc: 940dbba1    	bl	0x1017b5b50 <__ZN3std3env7_var_os17h289066a7989eb522E>
101446cd0: f94213f9    	ldr	x25, [sp, #0x420]
101446cd4: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101446cd8: eb08033f    	cmp	x25, x8
101446cdc: 54000061    	b.ne	0x101446ce8 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x4c4>
101446ce0: 52a00418    	mov	w24, #0x200000          ; =2097152
101446ce4: 14000030    	b	0x101446da4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x580>
101446ce8: aa1a03f3    	mov	x19, x26
101446cec: f94217fa    	ldr	x26, [sp, #0x428]
101446cf0: f9421be1    	ldr	x1, [sp, #0x430]
101446cf4: 910603e8    	add	x8, sp, #0x180
101446cf8: aa1a03e0    	mov	x0, x26
101446cfc: 940f77ef    	bl	0x101824cb8 <__ZN4core3str8converts9from_utf817ha54c467cc832e2ffE>
101446d00: b94183e8    	ldr	w8, [sp, #0x180]
101446d04: 7100051f    	cmp	w8, #0x1
101446d08: 54000400    	b.eq	0x101446d88 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x564>
101446d0c: f940cbe9    	ldr	x9, [sp, #0x190]
101446d10: b40003c9    	cbz	x9, 0x101446d88 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x564>
101446d14: f940c7e8    	ldr	x8, [sp, #0x188]
101446d18: f100053f    	cmp	x9, #0x1
101446d1c: 54000101    	b.ne	0x101446d3c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x518>
101446d20: 3940010a    	ldrb	w10, [x8]
101446d24: 52a00418    	mov	w24, #0x200000          ; =2097152
101446d28: 7100ad5f    	cmp	w10, #0x2b
101446d2c: 54000300    	b.eq	0x101446d8c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x568>
101446d30: 7100b55f    	cmp	w10, #0x2d
101446d34: 540002c0    	b.eq	0x101446d8c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x568>
101446d38: 14000002    	b	0x101446d40 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x51c>
101446d3c: 3940010a    	ldrb	w10, [x8]
101446d40: 7100ad5f    	cmp	w10, #0x2b
101446d44: 1a9f17ea    	cset	w10, eq
101446d48: 9a881508    	cinc	x8, x8, eq
101446d4c: cb0a0129    	sub	x9, x9, x10
101446d50: f100453f    	cmp	x9, #0x11
101446d54: 54001e02    	b.hs	0x101447114 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x8f0>
101446d58: d2800018    	mov	x24, #0x0               ; =0
101446d5c: b4000189    	cbz	x9, 0x101446d8c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x568>
101446d60: 5280014a    	mov	w10, #0xa               ; =10
101446d64: 3840150b    	ldrb	w11, [x8], #0x1
101446d68: 5100c16b    	sub	w11, w11, #0x30
101446d6c: 7100257f    	cmp	w11, #0x9
101446d70: 540000c8    	b.hi	0x101446d88 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x564>
101446d74: 9b0a7f0c    	mul	x12, x24, x10
101446d78: 8b2b4198    	add	x24, x12, w11, uxtw
101446d7c: f1000529    	subs	x9, x9, #0x1
101446d80: 54ffff21    	b.ne	0x101446d64 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x540>
101446d84: 14000002    	b	0x101446d8c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x568>
101446d88: 52a00418    	mov	w24, #0x200000          ; =2097152
101446d8c: b40000b9    	cbz	x25, 0x101446da0 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x57c>
101446d90: aa1a03e0    	mov	x0, x26
101446d94: aa1903e1    	mov	x1, x25
101446d98: 52800022    	mov	w2, #0x1                ; =1
101446d9c: 97d95e50    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101446da0: aa1303fa    	mov	x26, x19
101446da4: 91000708    	add	x8, x24, #0x1
101446da8: f9000388    	str	x8, [x28]
101446dac: 940dfe79    	bl	0x1017c6790 <__ZN3std6thread2id8ThreadId3new17hfe165afcc1283f9eE>
101446db0: 910f63e1    	add	x1, sp, #0x3d8
101446db4: 940dfec5    	bl	0x1017c68c8 <__ZN3std6thread6thread6Thread3new17h7b25d1ddb970d059E>
101446db8: f901fbe0    	str	x0, [sp, #0x3f0]
101446dbc: 910fe3e8    	add	x8, sp, #0x3f8
101446dc0: 910fc3e0    	add	x0, sp, #0x3f0
101446dc4: 940e0252    	bl	0x1017c770c <__ZN3std6thread9spawnhook15run_spawn_hooks17h5ea1de6c6de4a5c8E>
101446dc8: 52800028    	mov	w8, #0x1                ; =1
101446dcc: 4e080d00    	dup.2d	v0, x8
101446dd0: 3d8063e0    	str	q0, [sp, #0x180]
101446dd4: a9197fff    	stp	xzr, xzr, [sp, #0x190]
101446dd8: 97d95e46    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101446ddc: 52800600    	mov	w0, #0x30               ; =48
101446de0: 52800101    	mov	w1, #0x8                ; =8
101446de4: 97d95e3d    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101446de8: b4001f20    	cbz	x0, 0x1014471cc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x9a8>
101446dec: aa0003f9    	mov	x25, x0
101446df0: ad4c07e0    	ldp	q0, q1, [sp, #0x180]
101446df4: ad000400    	stp	q0, q1, [x0]
101446df8: 3dc06be0    	ldr	q0, [sp, #0x1a0]
101446dfc: 3d800800    	str	q0, [x0, #0x20]
101446e00: f9020fe0    	str	x0, [sp, #0x418]
101446e04: 52800028    	mov	w8, #0x1                ; =1
101446e08: f8280008    	ldadd	x8, x8, [x0]
101446e0c: b7f827e8    	tbnz	x8, #0x3f, 0x101447308 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xae4>
101446e10: 911083e8    	add	x8, sp, #0x420
101446e14: ad418760    	ldp	q0, q1, [x27, #0x30]
101446e18: 3c828100    	stur	q0, [x8, #0x28]
101446e1c: 3c838101    	stur	q1, [x8, #0x38]
101446e20: 3dc01760    	ldr	q0, [x27, #0x50]
101446e24: 3c848100    	stur	q0, [x8, #0x48]
101446e28: ad578760    	ldp	q0, q1, [x27, #0x2f0]
101446e2c: 3d810be0    	str	q0, [sp, #0x420]
101446e30: 3d810fe1    	str	q1, [sp, #0x430]
101446e34: f90223f9    	str	x25, [sp, #0x440]
101446e38: f9400b28    	ldr	x8, [x25, #0x10]
101446e3c: b4000068    	cbz	x8, 0x101446e48 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x624>
101446e40: 91004100    	add	x0, x8, #0x10
101446e44: 940dfe75    	bl	0x1017c6818 <__ZN3std6thread6scoped9ScopeData29increment_num_running_threads17hf05734fd928f52cdE>
101446e48: 3dc113e0    	ldr	q0, [sp, #0x440]
101446e4c: 3dc117e1    	ldr	q1, [sp, #0x450]
101446e50: ad0d07e0    	stp	q0, q1, [sp, #0x1a0]
101446e54: 3dc11be0    	ldr	q0, [sp, #0x460]
101446e58: 3d8073e0    	str	q0, [sp, #0x1c0]
101446e5c: f9423be8    	ldr	x8, [sp, #0x470]
101446e60: f900ebe8    	str	x8, [sp, #0x1d0]
101446e64: 3dc10be0    	ldr	q0, [sp, #0x420]
101446e68: 3dc10fe1    	ldr	q1, [sp, #0x430]
101446e6c: ad0c07e0    	stp	q0, q1, [sp, #0x180]
101446e70: 97d95e20    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101446e74: 52800b00    	mov	w0, #0x58               ; =88
101446e78: 52800101    	mov	w1, #0x8                ; =8
101446e7c: 97d95e17    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101446e80: b4001b00    	cbz	x0, 0x1014471e0 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x9bc>
101446e84: 3dc113e0    	ldr	q0, [sp, #0x440]
101446e88: 3dc117e1    	ldr	q1, [sp, #0x450]
101446e8c: ad010400    	stp	q0, q1, [x0, #0x20]
101446e90: 3dc11be0    	ldr	q0, [sp, #0x460]
101446e94: 3d801000    	str	q0, [x0, #0x40]
101446e98: f9423be8    	ldr	x8, [sp, #0x470]
101446e9c: f9002808    	str	x8, [x0, #0x50]
101446ea0: 3dc10be0    	ldr	q0, [sp, #0x420]
101446ea4: 3dc10fe1    	ldr	q1, [sp, #0x430]
101446ea8: ad000400    	stp	q0, q1, [x0]
101446eac: 52800028    	mov	w8, #0x1                ; =1
101446eb0: f941fbe9    	ldr	x9, [sp, #0x3f0]
101446eb4: f8280128    	ldadd	x8, x8, [x9]
101446eb8: b7f82288    	tbnz	x8, #0x3f, 0x101447308 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xae4>
101446ebc: f941fbe8    	ldr	x8, [sp, #0x3f0]
101446ec0: a91803e8    	stp	x8, x0, [sp, #0x180]
101446ec4: f0007108    	adrp	x8, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101446ec8: 9137c108    	add	x8, x8, #0xdf0
101446ecc: f900cbe8    	str	x8, [sp, #0x190]
101446ed0: 97d95e08    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101446ed4: 52800300    	mov	w0, #0x18               ; =24
101446ed8: 52800101    	mov	w1, #0x8                ; =8
101446edc: 97d95dff    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101446ee0: b4001880    	cbz	x0, 0x1014471f0 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x9cc>
101446ee4: aa0003e1    	mov	x1, x0
101446ee8: 3dc063e0    	ldr	q0, [sp, #0x180]
101446eec: 3d800000    	str	q0, [x0]
101446ef0: f940cbe8    	ldr	x8, [sp, #0x190]
101446ef4: f9000808    	str	x8, [x0, #0x10]
101446ef8: aa1803e0    	mov	x0, x24
101446efc: 940de347    	bl	0x1017bfc18 <__ZN3std3sys6thread4unix6Thread3new17h310ce26df5a62a27E>
101446f00: 370019a0    	tbnz	w0, #0x0, 0x101447234 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xa10>
101446f04: f941fbe8    	ldr	x8, [sp, #0x3f0]
101446f08: a91867e8    	stp	x8, x25, [sp, #0x180]
101446f0c: f900cbe1    	str	x1, [sp, #0x190]
101446f10: 910603e0    	add	x0, sp, #0x180
101446f14: 940039b8    	bl	0x1014555f4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x816c>
101446f18: 940dfd65    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101446f1c: f9009fe0    	str	x0, [sp, #0x138]
101446f20: b90143e1    	str	w1, [sp, #0x140]
101446f24: 9104e3e0    	add	x0, sp, #0x138
101446f28: aa1703e1    	mov	x1, x23
101446f2c: aa1603e2    	mov	x2, x22
101446f30: 940dfcd4    	bl	0x1017c6280 <__ZN3std4time7Instant11checked_add17hd4c9d4728c1a116dE>
101446f34: aa0103e3    	mov	x3, x1
101446f38: 52994008    	mov	w8, #0xca00             ; =51712
101446f3c: 72a77348    	movk	w8, #0x3b9a, lsl #16
101446f40: 6b08003f    	cmp	w1, w8
101446f44: 54000221    	b.ne	0x101446f88 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x764>
101446f48: 910603e0    	add	x0, sp, #0x180
101446f4c: f9401fe1    	ldr	x1, [sp, #0x38]
101446f50: 52994003    	mov	w3, #0xca00             ; =51712
101446f54: 72a77343    	movk	w3, #0x3b9a, lsl #16
101446f58: 940019af    	bl	0x10144d614 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x18c>
101446f5c: f940c3f6    	ldr	x22, [sp, #0x180]
101446f60: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101446f64: eb0802df    	cmp	x22, x8
101446f68: 54000861    	b.ne	0x101447074 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x850>
101446f6c: 52800028    	mov	w8, #0x1                ; =1
101446f70: 3910a3e8    	strb	w8, [sp, #0x428]
101446f74: f90213f6    	str	x22, [sp, #0x420]
101446f78: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101446f7c: eb0802df    	cmp	x22, x8
101446f80: 540008e0    	b.eq	0x10144709c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x878>
101446f84: 14000009    	b	0x101446fa8 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x784>
101446f88: aa0003e2    	mov	x2, x0
101446f8c: 911083e0    	add	x0, sp, #0x420
101446f90: f9401fe1    	ldr	x1, [sp, #0x38]
101446f94: 940019a0    	bl	0x10144d614 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x18c>
101446f98: f94213f6    	ldr	x22, [sp, #0x420]
101446f9c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101446fa0: eb0802df    	cmp	x22, x8
101446fa4: 540007c0    	b.eq	0x10144709c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x878>
101446fa8: b90037fa    	str	w26, [sp, #0x34]
101446fac: f94217f7    	ldr	x23, [sp, #0x428]
101446fb0: f9421bf3    	ldr	x19, [sp, #0x430]
101446fb4: 3950e3fc    	ldrb	w28, [sp, #0x438]
101446fb8: b9444bfa    	ldr	w26, [sp, #0x448]
101446fbc: b9444ff9    	ldr	w25, [sp, #0x44c]
101446fc0: b94453f8    	ldr	w24, [sp, #0x450]
101446fc4: f94093e8    	ldr	x8, [sp, #0x120]
101446fc8: b40002c8    	cbz	x8, 0x101447020 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x7fc>
101446fcc: f900b7e8    	str	x8, [sp, #0x168]
101446fd0: 3cc20360    	ldur	q0, [x27, #0x20]
101446fd4: 3c868360    	stur	q0, [x27, #0x68]
101446fd8: 910603e0    	add	x0, sp, #0x180
101446fdc: 9105a3e1    	add	x1, sp, #0x168
101446fe0: 9400200c    	bl	0x10144f010 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b88>
101446fe4: a9586fe8    	ldp	x8, x27, [sp, #0x180]
101446fe8: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101446fec: eb09011f    	cmp	x8, x9
101446ff0: 54000821    	b.ne	0x1014470f4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x8d0>
101446ff4: f940cbf5    	ldr	x21, [sp, #0x190]
101446ff8: f94002a8    	ldr	x8, [x21]
101446ffc: b4000068    	cbz	x8, 0x101447008 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x7e4>
101447000: aa1b03e0    	mov	x0, x27
101447004: d63f0100    	blr	x8
101447008: f94006a1    	ldr	x1, [x21, #0x8]
10144700c: b4000081    	cbz	x1, 0x10144701c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x7f8>
101447010: f9400aa2    	ldr	x2, [x21, #0x10]
101447014: aa1b03e0    	mov	x0, x27
101447018: 97d95db1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10144701c: d2800008    	mov	x8, #0x0                ; =0
101447020: d2800009    	mov	x9, #0x0                ; =0
101447024: 5280003b    	mov	w27, #0x1               ; =1
101447028: a9005e96    	stp	x22, x23, [x20]
10144702c: a9012293    	stp	x19, x8, [x20, #0x10]
101447030: a902269b    	stp	x27, x9, [x20, #0x20]
101447034: 3900c29c    	strb	w28, [x20, #0x30]
101447038: 3100075f    	cmn	w26, #0x1
10144703c: 54000060    	b.eq	0x101447048 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x824>
101447040: aa1a03e0    	mov	x0, x26
101447044: 941a09e5    	bl	0x101ac97d8 <_writev+0x101ac97d8>
101447048: 3100073f    	cmn	w25, #0x1
10144704c: f9401ff5    	ldr	x21, [sp, #0x38]
101447050: 54000060    	b.eq	0x10144705c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x838>
101447054: aa1903e0    	mov	x0, x25
101447058: 941a09e0    	bl	0x101ac97d8 <_writev+0x101ac97d8>
10144705c: 3100071f    	cmn	w24, #0x1
101447060: b94037fa    	ldr	w26, [sp, #0x34]
101447064: 54000200    	b.eq	0x1014470a4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x880>
101447068: aa1803e0    	mov	x0, x24
10144706c: 941a09db    	bl	0x101ac97d8 <_writev+0x101ac97d8>
101447070: 1400000d    	b	0x1014470a4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x880>
101447074: 911083e8    	add	x8, sp, #0x420
101447078: ad440760    	ldp	q0, q1, [x27, #0x80]
10144707c: 3c808100    	stur	q0, [x8, #0x8]
101447080: 3c818101    	stur	q1, [x8, #0x18]
101447084: 3cca0360    	ldur	q0, [x27, #0xa0]
101447088: 3c828100    	stur	q0, [x8, #0x28]
10144708c: f90213f6    	str	x22, [sp, #0x420]
101447090: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101447094: eb0802df    	cmp	x22, x8
101447098: 54fff881    	b.ne	0x101446fa8 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x784>
10144709c: f9000288    	str	x8, [x20]
1014470a0: f9401ff5    	ldr	x21, [sp, #0x38]
1014470a4: 52800020    	mov	w0, #0x1                ; =1
1014470a8: aa1503e1    	mov	x1, x21
1014470ac: 940026fe    	bl	0x101450ca4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x381c>
1014470b0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014470b4: eb0802df    	cmp	x22, x8
1014470b8: 540000a1    	b.ne	0x1014470cc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x8a8>
1014470bc: f94093e8    	ldr	x8, [sp, #0x120]
1014470c0: b4000068    	cbz	x8, 0x1014470cc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x8a8>
1014470c4: 910483e0    	add	x0, sp, #0x120
1014470c8: 94003c27    	bl	0x101456164 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8cdc>
1014470cc: 910103e0    	add	x0, sp, #0x40
1014470d0: 94003096    	bl	0x101453328 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5ea0>
1014470d4: d10143bf    	sub	sp, x29, #0x50
1014470d8: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1014470dc: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1014470e0: a94357f6    	ldp	x22, x21, [sp, #0x30]
1014470e4: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1014470e8: a94167fa    	ldp	x26, x25, [sp, #0x10]
1014470ec: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1014470f0: d65f03c0    	ret
1014470f4: f940cbe9    	ldr	x9, [sp, #0x190]
1014470f8: a9005e96    	stp	x22, x23, [x20]
1014470fc: a9012293    	stp	x19, x8, [x20, #0x10]
101447100: a902269b    	stp	x27, x9, [x20, #0x20]
101447104: 3900c29c    	strb	w28, [x20, #0x30]
101447108: 3100075f    	cmn	w26, #0x1
10144710c: 54fff9a1    	b.ne	0x101447040 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x81c>
101447110: 17ffffce    	b	0x101447048 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x824>
101447114: d280000a    	mov	x10, #0x0               ; =0
101447118: 52a00418    	mov	w24, #0x200000          ; =2097152
10144711c: 5280014b    	mov	w11, #0xa               ; =10
101447120: b4000469    	cbz	x9, 0x1014471ac <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x988>
101447124: 3840150c    	ldrb	w12, [x8], #0x1
101447128: 5100c18c    	sub	w12, w12, #0x30
10144712c: 7100259f    	cmp	w12, #0x9
101447130: 54ffe2e8    	b.hi	0x101446d8c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x568>
101447134: 9bcb7d4d    	umulh	x13, x10, x11
101447138: eb0d03ff    	cmp	xzr, x13
10144713c: 1a9f07ed    	cset	w13, ne
101447140: 8b0a094a    	add	x10, x10, x10, lsl #2
101447144: d37ff94a    	lsl	x10, x10, #1
101447148: ab2c414a    	adds	x10, x10, w12, uxtw
10144714c: 1a9f37ec    	cset	w12, hs
101447150: 3707e1ed    	tbnz	w13, #0x0, 0x101446d8c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x568>
101447154: d1000529    	sub	x9, x9, #0x1
101447158: 3607fe4c    	tbz	w12, #0x0, 0x101447120 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x8fc>
10144715c: 17ffff0c    	b	0x101446d8c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x568>
101447160: d280000a    	mov	x10, #0x0               ; =0
101447164: 52a00418    	mov	w24, #0x200000          ; =2097152
101447168: 5280014b    	mov	w11, #0xa               ; =10
10144716c: b4000249    	cbz	x9, 0x1014471b4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x990>
101447170: 3840150c    	ldrb	w12, [x8], #0x1
101447174: 5100c18c    	sub	w12, w12, #0x30
101447178: 7100259f    	cmp	w12, #0x9
10144717c: 54ffca88    	b.hi	0x101446acc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2a8>
101447180: 9bcb7d4d    	umulh	x13, x10, x11
101447184: eb0d03ff    	cmp	xzr, x13
101447188: 1a9f07ed    	cset	w13, ne
10144718c: 8b0a094a    	add	x10, x10, x10, lsl #2
101447190: d37ff94a    	lsl	x10, x10, #1
101447194: ab2c414a    	adds	x10, x10, w12, uxtw
101447198: 1a9f37ec    	cset	w12, hs
10144719c: 3707c98d    	tbnz	w13, #0x0, 0x101446acc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2a8>
1014471a0: d1000529    	sub	x9, x9, #0x1
1014471a4: 3607fe4c    	tbz	w12, #0x0, 0x10144716c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x948>
1014471a8: 17fffe49    	b	0x101446acc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2a8>
1014471ac: aa0a03f8    	mov	x24, x10
1014471b0: 17fffef7    	b	0x101446d8c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x568>
1014471b4: aa0a03f8    	mov	x24, x10
1014471b8: 17fffe45    	b	0x101446acc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x2a8>
1014471bc: 52801000    	mov	w0, #0x80               ; =128
1014471c0: 52804001    	mov	w1, #0x200              ; =512
1014471c4: 9419f05e    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
1014471c8: 14000050    	b	0x101447308 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xae4>
1014471cc: 910603f3    	add	x19, sp, #0x180
1014471d0: 52800100    	mov	w0, #0x8                ; =8
1014471d4: 52800601    	mov	w1, #0x30               ; =48
1014471d8: 9419f059    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
1014471dc: 1400004b    	b	0x101447308 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xae4>
1014471e0: 52800100    	mov	w0, #0x8                ; =8
1014471e4: 52800b01    	mov	w1, #0x58               ; =88
1014471e8: 9419f055    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
1014471ec: 14000047    	b	0x101447308 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xae4>
1014471f0: 52800100    	mov	w0, #0x8                ; =8
1014471f4: 52800301    	mov	w1, #0x18               ; =24
1014471f8: 9419f051    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
1014471fc: 14000043    	b	0x101447308 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xae4>
101447200: 910603f3    	add	x19, sp, #0x180
101447204: 52800100    	mov	w0, #0x8                ; =8
101447208: 52800601    	mov	w1, #0x30               ; =48
10144720c: 9419f04c    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
101447210: 1400003e    	b	0x101447308 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xae4>
101447214: 52800100    	mov	w0, #0x8                ; =8
101447218: 52800601    	mov	w1, #0x30               ; =48
10144721c: 9419f048    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
101447220: 1400003a    	b	0x101447308 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xae4>
101447224: 52800100    	mov	w0, #0x8                ; =8
101447228: 52800301    	mov	w1, #0x18               ; =24
10144722c: 9419f044    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
101447230: 14000036    	b	0x101447308 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xae4>
101447234: aa1a03f5    	mov	x21, x26
101447238: aa0103f3    	mov	x19, x1
10144723c: 92800014    	mov	x20, #-0x1              ; =-1
101447240: f8740328    	ldaddl	x20, x8, [x25]
101447244: f100051f    	cmp	x8, #0x1
101447248: 54000081    	b.ne	0x101447258 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xa34>
10144724c: d50339bf    	dmb	ishld
101447250: 911063e0    	add	x0, sp, #0x418
101447254: 94009040    	bl	0x10146b354 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h66f5b1462a26fcfaE>
101447258: f941fbe8    	ldr	x8, [sp, #0x3f0]
10144725c: f8740108    	ldaddl	x20, x8, [x8]
101447260: f100051f    	cmp	x8, #0x1
101447264: 540000a1    	b.ne	0x101447278 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xa54>
101447268: aa1503fa    	mov	x26, x21
10144726c: d50339bf    	dmb	ishld
101447270: 910fc3e0    	add	x0, sp, #0x3f0
101447274: 940e5504    	bl	0x1017dc684 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h381a557efa9838c6E>
101447278: f900c3f3    	str	x19, [sp, #0x180]
10144727c: 900044c0    	adrp	x0, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101447280: 9127f400    	add	x0, x0, #0x9fd
101447284: f0007103    	adrp	x3, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
101447288: 91000063    	add	x3, x3, #0x0
10144728c: b0007104    	adrp	x4, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101447290: 91266084    	add	x4, x4, #0x998
101447294: 910603e2    	add	x2, sp, #0x180
101447298: 528002c1    	mov	w1, #0x16               ; =22
10144729c: 9419f1c1    	bl	0x101ac39a0 <__ZN4core6result13unwrap_failed17hbc9d97d7032fd501E>
1014472a0: 1400001a    	b	0x101447308 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xae4>
1014472a4: aa0103f3    	mov	x19, x1
1014472a8: 92800014    	mov	x20, #-0x1              ; =-1
1014472ac: f8740328    	ldaddl	x20, x8, [x25]
1014472b0: f100051f    	cmp	x8, #0x1
1014472b4: 54000081    	b.ne	0x1014472c4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xaa0>
1014472b8: d50339bf    	dmb	ishld
1014472bc: 910f63e0    	add	x0, sp, #0x3d8
1014472c0: 9400909d    	bl	0x10146b534 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17haf7bd87e7cd97c2eE>
1014472c4: f94093e8    	ldr	x8, [sp, #0x120]
1014472c8: f8740108    	ldaddl	x20, x8, [x8]
1014472cc: f100051f    	cmp	x8, #0x1
1014472d0: 54000081    	b.ne	0x1014472e0 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xabc>
1014472d4: d50339bf    	dmb	ishld
1014472d8: 910483e0    	add	x0, sp, #0x120
1014472dc: 940e54ea    	bl	0x1017dc684 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h381a557efa9838c6E>
1014472e0: f900c3f3    	str	x19, [sp, #0x180]
1014472e4: 900044c0    	adrp	x0, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014472e8: 9127f400    	add	x0, x0, #0x9fd
1014472ec: f0007103    	adrp	x3, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
1014472f0: 91000063    	add	x3, x3, #0x0
1014472f4: b0007104    	adrp	x4, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
1014472f8: 91266084    	add	x4, x4, #0x998
1014472fc: 910603e2    	add	x2, sp, #0x180
101447300: 528002c1    	mov	w1, #0x16               ; =22
101447304: 9419f1a7    	bl	0x101ac39a0 <__ZN4core6result13unwrap_failed17hbc9d97d7032fd501E>
101447308: d4200020    	brk	#0x1
10144730c: aa0003f4    	mov	x20, x0
101447310: f94006a1    	ldr	x1, [x21, #0x8]
101447314: b4000561    	cbz	x1, 0x1014473c0 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xb9c>
101447318: f9400aa2    	ldr	x2, [x21, #0x10]
10144731c: aa1b03e0    	mov	x0, x27
101447320: 97d95cef    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101447324: 14000027    	b	0x1014473c0 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xb9c>
101447328: aa0003f4    	mov	x20, x0
10144732c: 140000c6    	b	0x101447644 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe20>
101447330: aa0003f4    	mov	x20, x0
101447334: b40009d9    	cbz	x25, 0x10144746c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xc48>
101447338: aa1a03e0    	mov	x0, x26
10144733c: aa1903e1    	mov	x1, x25
101447340: 52800022    	mov	w2, #0x1                ; =1
101447344: 97d95ce6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101447348: 14000049    	b	0x10144746c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xc48>
10144734c: aa0003f4    	mov	x20, x0
101447350: 52800013    	mov	w19, #0x0               ; =0
101447354: 14000078    	b	0x101447534 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xd10>
101447358: aa0003f4    	mov	x20, x0
10144735c: f94006c1    	ldr	x1, [x22, #0x8]
101447360: b4000081    	cbz	x1, 0x101447370 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xb4c>
101447364: f9400ac2    	ldr	x2, [x22, #0x10]
101447368: aa1503e0    	mov	x0, x21
10144736c: 97d95cdc    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101447370: aa1303e0    	mov	x0, x19
101447374: 52800301    	mov	w1, #0x18               ; =24
101447378: 52800102    	mov	w2, #0x8                ; =8
10144737c: 97d95cd8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101447380: 140000b7    	b	0x10144765c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe38>
101447384: aa0003f4    	mov	x20, x0
101447388: b5000079    	cbnz	x25, 0x101447394 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xb70>
10144738c: aa1303fa    	mov	x26, x19
101447390: 14000048    	b	0x1014474b0 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xc8c>
101447394: aa1a03e0    	mov	x0, x26
101447398: aa1903e1    	mov	x1, x25
10144739c: 52800022    	mov	w2, #0x1                ; =1
1014473a0: 97d95ccf    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014473a4: aa1303fa    	mov	x26, x19
1014473a8: 14000042    	b	0x1014474b0 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xc8c>
1014473ac: aa0003f4    	mov	x20, x0
1014473b0: 52800013    	mov	w19, #0x0               ; =0
1014473b4: aa1503fa    	mov	x26, x21
1014473b8: 1400003b    	b	0x1014474a4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xc80>
1014473bc: aa0003f4    	mov	x20, x0
1014473c0: 911083e8    	add	x8, sp, #0x420
1014473c4: 91007100    	add	x0, x8, #0x1c
1014473c8: 97d3a3fc    	bl	0x1009303b8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1d390>
1014473cc: b40000b6    	cbz	x22, 0x1014473e0 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xbbc>
1014473d0: aa1703e0    	mov	x0, x23
1014473d4: aa1603e1    	mov	x1, x22
1014473d8: 52800022    	mov	w2, #0x1                ; =1
1014473dc: 97d95cc0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014473e0: 52800013    	mov	w19, #0x0               ; =0
1014473e4: b94037fa    	ldr	w26, [sp, #0x34]
1014473e8: f9401ff5    	ldr	x21, [sp, #0x38]
1014473ec: 14000087    	b	0x101447608 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xde4>
1014473f0: aa0003f4    	mov	x20, x0
1014473f4: 910603e0    	add	x0, sp, #0x180
1014473f8: 94002fa1    	bl	0x10145327c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5df4>
1014473fc: 14000092    	b	0x101447644 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe20>
101447400: 9419f249    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101447404: aa0003f4    	mov	x20, x0
101447408: 911083e0    	add	x0, sp, #0x420
10144740c: 94002def    	bl	0x101452bc8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5740>
101447410: 14000039    	b	0x1014474f4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xcd0>
101447414: 1400002e    	b	0x1014474cc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xca8>
101447418: aa0003f4    	mov	x20, x0
10144741c: 910603e0    	add	x0, sp, #0x180
101447420: 94002f97    	bl	0x10145327c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5df4>
101447424: 52800033    	mov	w19, #0x1               ; =1
101447428: aa1503fa    	mov	x26, x21
10144742c: f9401ff5    	ldr	x21, [sp, #0x38]
101447430: 14000076    	b	0x101447608 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xde4>
101447434: 9419f23c    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101447438: aa0003f4    	mov	x20, x0
10144743c: 911083e0    	add	x0, sp, #0x420
101447440: 94002c4e    	bl	0x101452578 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x50f0>
101447444: f9401ff5    	ldr	x21, [sp, #0x38]
101447448: 14000053    	b	0x101447594 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xd70>
10144744c: aa0003f4    	mov	x20, x0
101447450: 14000029    	b	0x1014474f4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xcd0>
101447454: aa0003f4    	mov	x20, x0
101447458: 14000036    	b	0x101447530 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xd0c>
10144745c: aa0003f4    	mov	x20, x0
101447460: 1400003e    	b	0x101447558 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xd34>
101447464: aa1a03f3    	mov	x19, x26
101447468: aa0003f4    	mov	x20, x0
10144746c: aa1503e0    	mov	x0, x21
101447470: 941a08da    	bl	0x101ac97d8 <_writev+0x101ac97d8>
101447474: aa1303fa    	mov	x26, x19
101447478: 14000073    	b	0x101447644 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe20>
10144747c: aa0003f4    	mov	x20, x0
101447480: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101447484: eb0802df    	cmp	x22, x8
101447488: 54000d40    	b.eq	0x101447630 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe0c>
10144748c: 14000074    	b	0x10144765c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe38>
101447490: aa0003f4    	mov	x20, x0
101447494: f9401ff5    	ldr	x21, [sp, #0x38]
101447498: 1400003f    	b	0x101447594 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xd70>
10144749c: aa0003f4    	mov	x20, x0
1014474a0: 52800033    	mov	w19, #0x1               ; =1
1014474a4: f9401ff5    	ldr	x21, [sp, #0x38]
1014474a8: 1400004c    	b	0x1014475d8 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xdb4>
1014474ac: aa0003f4    	mov	x20, x0
1014474b0: f9401ff5    	ldr	x21, [sp, #0x38]
1014474b4: 14000052    	b	0x1014475fc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xdd8>
1014474b8: aa0003f4    	mov	x20, x0
1014474bc: 52800033    	mov	w19, #0x1               ; =1
1014474c0: f9401ff5    	ldr	x21, [sp, #0x38]
1014474c4: 14000051    	b	0x101447608 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xde4>
1014474c8: 14000001    	b	0x1014474cc <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xca8>
1014474cc: aa0003f4    	mov	x20, x0
1014474d0: 14000063    	b	0x10144765c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe38>
1014474d4: aa0003f4    	mov	x20, x0
1014474d8: 910603e0    	add	x0, sp, #0x180
1014474dc: 94003282    	bl	0x101453ee4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6a5c>
1014474e0: 14000005    	b	0x1014474f4 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xcd0>
1014474e4: 9419f210    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014474e8: aa0003f4    	mov	x20, x0
1014474ec: 910603e0    	add	x0, sp, #0x180
1014474f0: 94002db6    	bl	0x101452bc8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5740>
1014474f4: 92800008    	mov	x8, #-0x1               ; =-1
1014474f8: f8680328    	ldaddl	x8, x8, [x25]
1014474fc: f100051f    	cmp	x8, #0x1
101447500: 54000081    	b.ne	0x101447510 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xcec>
101447504: d50339bf    	dmb	ishld
101447508: 910f63e0    	add	x0, sp, #0x3d8
10144750c: 9400900a    	bl	0x10146b534 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17haf7bd87e7cd97c2eE>
101447510: 52800013    	mov	w19, #0x0               ; =0
101447514: 14000008    	b	0x101447534 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xd10>
101447518: 9419f203    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
10144751c: aa0003f4    	mov	x20, x0
101447520: 91004260    	add	x0, x19, #0x10
101447524: 9400391b    	bl	0x101455990 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8508>
101447528: 9104e3e0    	add	x0, sp, #0x138
10144752c: 94003508    	bl	0x10145494c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x74c4>
101447530: 52800033    	mov	w19, #0x1               ; =1
101447534: f94093e8    	ldr	x8, [sp, #0x120]
101447538: 92800009    	mov	x9, #-0x1               ; =-1
10144753c: f8690108    	ldaddl	x9, x8, [x8]
101447540: f100051f    	cmp	x8, #0x1
101447544: 54000081    	b.ne	0x101447554 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xd30>
101447548: d50339bf    	dmb	ishld
10144754c: 910483e0    	add	x0, sp, #0x120
101447550: 940e544d    	bl	0x1017dc684 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h381a557efa9838c6E>
101447554: 36000793    	tbz	w19, #0x0, 0x101447644 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe20>
101447558: aa1503e0    	mov	x0, x21
10144755c: 941a089f    	bl	0x101ac97d8 <_writev+0x101ac97d8>
101447560: 14000039    	b	0x101447644 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe20>
101447564: 9419f1f0    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101447568: 9419f1ef    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
10144756c: aa0003f4    	mov	x20, x0
101447570: 910603e0    	add	x0, sp, #0x180
101447574: 9400325c    	bl	0x101453ee4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6a5c>
101447578: f9401ff5    	ldr	x21, [sp, #0x38]
10144757c: 14000006    	b	0x101447594 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xd70>
101447580: 9419f1e9    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101447584: aa0003f4    	mov	x20, x0
101447588: 910603e0    	add	x0, sp, #0x180
10144758c: 94002bfb    	bl	0x101452578 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x50f0>
101447590: f9401ff5    	ldr	x21, [sp, #0x38]
101447594: 92800008    	mov	x8, #-0x1               ; =-1
101447598: f8680328    	ldaddl	x8, x8, [x25]
10144759c: f100051f    	cmp	x8, #0x1
1014475a0: 54000081    	b.ne	0x1014475b0 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xd8c>
1014475a4: d50339bf    	dmb	ishld
1014475a8: 911063e0    	add	x0, sp, #0x418
1014475ac: 94008f6a    	bl	0x10146b354 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h66f5b1462a26fcfaE>
1014475b0: 52800013    	mov	w19, #0x0               ; =0
1014475b4: 14000009    	b	0x1014475d8 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xdb4>
1014475b8: 9419f1db    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014475bc: aa0003f4    	mov	x20, x0
1014475c0: 91004260    	add	x0, x19, #0x10
1014475c4: 9400371f    	bl	0x101455240 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7db8>
1014475c8: f9401ff5    	ldr	x21, [sp, #0x38]
1014475cc: 910fe3e0    	add	x0, sp, #0x3f8
1014475d0: 940034df    	bl	0x10145494c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x74c4>
1014475d4: 52800033    	mov	w19, #0x1               ; =1
1014475d8: f941fbe8    	ldr	x8, [sp, #0x3f0]
1014475dc: 92800009    	mov	x9, #-0x1               ; =-1
1014475e0: f8690108    	ldaddl	x9, x8, [x8]
1014475e4: f100051f    	cmp	x8, #0x1
1014475e8: 54000081    	b.ne	0x1014475f8 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xdd4>
1014475ec: d50339bf    	dmb	ishld
1014475f0: 910fc3e0    	add	x0, sp, #0x3f0
1014475f4: 940e5424    	bl	0x1017dc684 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h381a557efa9838c6E>
1014475f8: 36000073    	tbz	w19, #0x0, 0x101447604 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xde0>
1014475fc: 9104e3e0    	add	x0, sp, #0x138
101447600: 9400399c    	bl	0x101455c70 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x87e8>
101447604: 52800033    	mov	w19, #0x1               ; =1
101447608: 52800020    	mov	w0, #0x1                ; =1
10144760c: aa1503e1    	mov	x1, x21
101447610: 940025a5    	bl	0x101450ca4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x381c>
101447614: 370000f3    	tbnz	w19, #0x0, 0x101447630 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe0c>
101447618: 14000011    	b	0x10144765c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe38>
10144761c: 9419f1c2    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101447620: 9419f1c1    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101447624: aa0003f4    	mov	x20, x0
101447628: 910603e0    	add	x0, sp, #0x180
10144762c: 94002b68    	bl	0x1014523cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x4f44>
101447630: f94093e8    	ldr	x8, [sp, #0x120]
101447634: b4000068    	cbz	x8, 0x101447640 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe1c>
101447638: 910483e0    	add	x0, sp, #0x120
10144763c: 94003aca    	bl	0x101456164 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8cdc>
101447640: b50000f5    	cbnz	x21, 0x10144765c <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe38>
101447644: 3100075f    	cmn	w26, #0x1
101447648: 54000060    	b.eq	0x101447654 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0xe30>
10144764c: aa1a03e0    	mov	x0, x26
101447650: 941a0862    	bl	0x101ac97d8 <_writev+0x101ac97d8>
101447654: 910423e0    	add	x0, sp, #0x108
101447658: 97d3a358    	bl	0x1009303b8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1d390>
10144765c: 910103e0    	add	x0, sp, #0x40
101447660: 94002f32    	bl	0x101453328 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5ea0>
101447664: aa1403e0    	mov	x0, x20
101447668: 941a07db    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10144766c: 9419f1ae    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101447670: 9419f1ad    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
