
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101587868 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E>:
101587868: d101c3ff    	sub	sp, sp, #0x70
10158786c: a9054ff4    	stp	x20, x19, [sp, #0x50]
101587870: a9067bfd    	stp	x29, x30, [sp, #0x60]
101587874: 910183fd    	add	x29, sp, #0x60
101587878: aa0803f4    	mov	x20, x8
10158787c: a90007e0    	stp	x0, x1, [sp]
101587880: 97cf1439    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
101587884: 910043e8    	add	x8, sp, #0x10
101587888: 940a0fab    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
10158788c: a941a3f3    	ldp	x19, x8, [sp, #0x18]
101587890: f1001d1f    	cmp	x8, #0x7
101587894: 540002ed    	b.le	0x1015878f0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x88>
101587898: f100251f    	cmp	x8, #0x9
10158789c: 540005ed    	b.le	0x101587958 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0xf0>
1015878a0: f100291f    	cmp	x8, #0xa
1015878a4: 54000d00    	b.eq	0x101587a44 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x1dc>
1015878a8: f1002d1f    	cmp	x8, #0xb
1015878ac: 54001300    	b.eq	0x101587b0c <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x2a4>
1015878b0: f1003d1f    	cmp	x8, #0xf
1015878b4: 540015a1    	b.ne	0x101587b68 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x300>
1015878b8: f9400268    	ldr	x8, [x19]
1015878bc: f8407269    	ldur	x9, [x19, #0x7]
1015878c0: d28c2e8a    	mov	x10, #0x6174            ; =24948
1015878c4: f2a56c4a    	movk	x10, #0x2b62, lsl #16
1015878c8: f2cd2e4a    	movk	x10, #0x6972, lsl #32
1015878cc: f2ed0cea    	movk	x10, #0x6867, lsl #48
1015878d0: eb0a011f    	cmp	x8, x10
1015878d4: d28e8d08    	mov	x8, #0x7468             ; =29800
1015878d8: f2ac25a8    	movk	x8, #0x612d, lsl #16
1015878dc: f2ce4e48    	movk	x8, #0x7272, lsl #32
1015878e0: f2eeede8    	movk	x8, #0x776f, lsl #48
1015878e4: fa480120    	ccmp	x9, x8, #0x0, eq
1015878e8: 54001401    	b.ne	0x101587b68 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x300>
1015878ec: 140000bc    	b	0x101587bdc <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x374>
1015878f0: f100111f    	cmp	x8, #0x4
1015878f4: 5400016c    	b.gt	0x101587920 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0xb8>
1015878f8: f1000d1f    	cmp	x8, #0x3
1015878fc: 54000740    	b.eq	0x1015879e4 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x17c>
101587900: f100111f    	cmp	x8, #0x4
101587904: 54001321    	b.ne	0x101587b68 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x300>
101587908: b9400268    	ldr	w8, [x19]
10158790c: 528dedc9    	mov	w9, #0x6f6e             ; =28526
101587910: 72acadc9    	movk	w9, #0x656e, lsl #16
101587914: 6b09011f    	cmp	w8, w9
101587918: 54001281    	b.ne	0x101587b68 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x300>
10158791c: 14000075    	b	0x101587af0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x288>
101587920: f100151f    	cmp	x8, #0x5
101587924: 540007e0    	b.eq	0x101587a20 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x1b8>
101587928: f1001d1f    	cmp	x8, #0x7
10158792c: 540011e1    	b.ne	0x101587b68 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x300>
101587930: b9400268    	ldr	w8, [x19]
101587934: b8403269    	ldur	w9, [x19, #0x3]
101587938: 528d2c8a    	mov	w10, #0x6964            ; =26980
10158793c: 72ac2e6a    	movk	w10, #0x6173, lsl #16
101587940: 6b0a011f    	cmp	w8, w10
101587944: 528c4c28    	mov	w8, #0x6261             ; =25185
101587948: 72acad88    	movk	w8, #0x656c, lsl #16
10158794c: 7a480120    	ccmp	w9, w8, #0x0, eq
101587950: 540010c1    	b.ne	0x101587b68 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x300>
101587954: 14000067    	b	0x101587af0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x288>
101587958: f100211f    	cmp	x8, #0x8
10158795c: 54000bc0    	b.eq	0x101587ad4 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x26c>
101587960: f100251f    	cmp	x8, #0x9
101587964: 54001021    	b.ne	0x101587b68 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x300>
101587968: f9400268    	ldr	x8, [x19]
10158796c: 39402269    	ldrb	w9, [x19, #0x8]
101587970: d28c2e8a    	mov	x10, #0x6174            ; =24948
101587974: f2a56c4a    	movk	x10, #0x2b62, lsl #16
101587978: f2cd2e4a    	movk	x10, #0x6972, lsl #32
10158797c: f2ed0cea    	movk	x10, #0x6867, lsl #48
101587980: eb0a011f    	cmp	x8, x10
101587984: 52800e88    	mov	w8, #0x74               ; =116
101587988: 7a480120    	ccmp	w9, w8, #0x0, eq
10158798c: 54001280    	b.eq	0x101587bdc <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x374>
101587990: f9400268    	ldr	x8, [x19]
101587994: 39402269    	ldrb	w9, [x19, #0x8]
101587998: d28c2e8a    	mov	x10, #0x6174            ; =24948
10158799c: f2a56c4a    	movk	x10, #0x2b62, lsl #16
1015879a0: f2ce4c2a    	movk	x10, #0x7261, lsl #32
1015879a4: f2edee4a    	movk	x10, #0x6f72, lsl #48
1015879a8: eb0a011f    	cmp	x8, x10
1015879ac: 52800ee8    	mov	w8, #0x77               ; =119
1015879b0: 7a480120    	ccmp	w9, w8, #0x0, eq
1015879b4: 54001140    	b.eq	0x101587bdc <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x374>
1015879b8: f9400268    	ldr	x8, [x19]
1015879bc: 39402269    	ldrb	w9, [x19, #0x8]
1015879c0: d28e8c6a    	mov	x10, #0x7463            ; =29795
1015879c4: f2ad8e4a    	movk	x10, #0x6c72, lsl #16
1015879c8: f2ce0e6a    	movk	x10, #0x7073, lsl #32
1015879cc: f2ec6c2a    	movk	x10, #0x6361, lsl #48
1015879d0: eb0a011f    	cmp	x8, x10
1015879d4: 52800ca8    	mov	w8, #0x65               ; =101
1015879d8: 7a480120    	ccmp	w9, w8, #0x0, eq
1015879dc: 54000c61    	b.ne	0x101587b68 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x300>
1015879e0: 14000036    	b	0x101587ab8 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x250>
1015879e4: 79400268    	ldrh	w8, [x19]
1015879e8: 39400a69    	ldrb	w9, [x19, #0x2]
1015879ec: 528c2e8a    	mov	w10, #0x6174            ; =24948
1015879f0: 6b0a011f    	cmp	w8, w10
1015879f4: 52800c48    	mov	w8, #0x62               ; =98
1015879f8: 7a480120    	ccmp	w9, w8, #0x0, eq
1015879fc: 54000fe0    	b.eq	0x101587bf8 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x390>
101587a00: 79400268    	ldrh	w8, [x19]
101587a04: 39400a69    	ldrb	w9, [x19, #0x2]
101587a08: 528ccdea    	mov	w10, #0x666f            ; =26223
101587a0c: 6b0a011f    	cmp	w8, w10
101587a10: 52800cc8    	mov	w8, #0x66               ; =102
101587a14: 7a480120    	ccmp	w9, w8, #0x0, eq
101587a18: 54000a81    	b.ne	0x101587b68 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x300>
101587a1c: 14000035    	b	0x101587af0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x288>
101587a20: b9400268    	ldr	w8, [x19]
101587a24: 39401269    	ldrb	w9, [x19, #0x4]
101587a28: 528d2e4a    	mov	w10, #0x6972            ; =26994
101587a2c: 72ad0cea    	movk	w10, #0x6867, lsl #16
101587a30: 6b0a011f    	cmp	w8, w10
101587a34: 52800e88    	mov	w8, #0x74               ; =116
101587a38: 7a480120    	ccmp	w9, w8, #0x0, eq
101587a3c: 54000961    	b.ne	0x101587b68 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x300>
101587a40: 14000060    	b	0x101587bc0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x358>
101587a44: f9400268    	ldr	x8, [x19]
101587a48: 79401269    	ldrh	w9, [x19, #0x8]
101587a4c: d28d2e4a    	mov	x10, #0x6972            ; =26994
101587a50: f2ad0cea    	movk	x10, #0x6867, lsl #16
101587a54: f2cc2e8a    	movk	x10, #0x6174, lsl #32
101587a58: f2ee4e4a    	movk	x10, #0x7272, lsl #48
101587a5c: eb0a011f    	cmp	x8, x10
101587a60: 528eede8    	mov	w8, #0x776f             ; =30575
101587a64: 7a480120    	ccmp	w9, w8, #0x0, eq
101587a68: 54000ac0    	b.eq	0x101587bc0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x358>
101587a6c: f9400268    	ldr	x8, [x19]
101587a70: 79401269    	ldrh	w9, [x19, #0x8]
101587a74: d28e8c6a    	mov	x10, #0x7463            ; =29795
101587a78: f2ad8e4a    	movk	x10, #0x6c72, lsl #16
101587a7c: f2ce656a    	movk	x10, #0x732b, lsl #32
101587a80: f2ec2e0a    	movk	x10, #0x6170, lsl #48
101587a84: eb0a011f    	cmp	x8, x10
101587a88: 528cac68    	mov	w8, #0x6563             ; =25955
101587a8c: 7a480120    	ccmp	w9, w8, #0x0, eq
101587a90: 54000140    	b.eq	0x101587ab8 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x250>
101587a94: f9400269    	ldr	x9, [x19]
101587a98: 7940126a    	ldrh	w10, [x19, #0x8]
101587a9c: d28e8c6b    	mov	x11, #0x7463            ; =29795
101587aa0: f2ad8e4b    	movk	x11, #0x6c72, lsl #16
101587aa4: f2ce65ab    	movk	x11, #0x732d, lsl #32
101587aa8: f2ec2e0b    	movk	x11, #0x6170, lsl #48
101587aac: eb0b013f    	cmp	x9, x11
101587ab0: 7a480140    	ccmp	w10, w8, #0x0, eq
101587ab4: 540005a1    	b.ne	0x101587b68 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x300>
101587ab8: 52800068    	mov	w8, #0x3                ; =3
101587abc: 39002288    	strb	w8, [x20, #0x8]
101587ac0: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101587ac4: f9000288    	str	x8, [x20]
101587ac8: f9400be1    	ldr	x1, [sp, #0x10]
101587acc: b50006c1    	cbnz	x1, 0x101587ba4 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x33c>
101587ad0: 14000038    	b	0x101587bb0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x348>
101587ad4: f9400268    	ldr	x8, [x19]
101587ad8: d28d2c89    	mov	x9, #0x6964             ; =26980
101587adc: f2ac2e69    	movk	x9, #0x6173, lsl #16
101587ae0: f2cd8c49    	movk	x9, #0x6c62, lsl #32
101587ae4: f2ec8ca9    	movk	x9, #0x6465, lsl #48
101587ae8: eb09011f    	cmp	x8, x9
101587aec: 540003e1    	b.ne	0x101587b68 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x300>
101587af0: 52800088    	mov	w8, #0x4                ; =4
101587af4: 39002288    	strb	w8, [x20, #0x8]
101587af8: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101587afc: f9000288    	str	x8, [x20]
101587b00: f9400be1    	ldr	x1, [sp, #0x10]
101587b04: b5000501    	cbnz	x1, 0x101587ba4 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x33c>
101587b08: 1400002a    	b	0x101587bb0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x348>
101587b0c: d28e8d08    	mov	x8, #0x7468             ; =29800
101587b10: f2ac25a8    	movk	x8, #0x612d, lsl #16
101587b14: f2ce4e48    	movk	x8, #0x7272, lsl #32
101587b18: f2eeede8    	movk	x8, #0x776f, lsl #48
101587b1c: f9400269    	ldr	x9, [x19]
101587b20: f840326a    	ldur	x10, [x19, #0x3]
101587b24: d28d2e4b    	mov	x11, #0x6972            ; =26994
101587b28: f2ad0ceb    	movk	x11, #0x6867, lsl #16
101587b2c: f2c5ae8b    	movk	x11, #0x2d74, lsl #32
101587b30: f2ee4c2b    	movk	x11, #0x7261, lsl #48
101587b34: eb0b013f    	cmp	x9, x11
101587b38: fa480140    	ccmp	x10, x8, #0x0, eq
101587b3c: 54000420    	b.eq	0x101587bc0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x358>
101587b40: f9400269    	ldr	x9, [x19]
101587b44: f840326a    	ldur	x10, [x19, #0x3]
101587b48: 914c8108    	add	x8, x8, #0x320, lsl #12 ; =0x320000
101587b4c: d28d2e4b    	mov	x11, #0x6972            ; =26994
101587b50: f2ad0ceb    	movk	x11, #0x6867, lsl #16
101587b54: f2cbee8b    	movk	x11, #0x5f74, lsl #32
101587b58: f2ee4c2b    	movk	x11, #0x7261, lsl #48
101587b5c: eb0b013f    	cmp	x9, x11
101587b60: fa480140    	ccmp	x10, x8, #0x0, eq
101587b64: 540002e0    	b.eq	0x101587bc0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x358>
101587b68: 910003e8    	mov	x8, sp
101587b6c: 900003e9    	adrp	x9, 0x101603000 <__ZN3std2io5error5Error3new17h3fc09d96e530f798E+0x13fc>
101587b70: 910c9129    	add	x9, x9, #0x324
101587b74: a93e27a8    	stp	x8, x9, [x29, #-0x20]
101587b78: f0004440    	adrp	x0, 0x101e12000 <_writev+0x101e12000>
101587b7c: 91154800    	add	x0, x0, #0x552
101587b80: 9100a3e8    	add	x8, sp, #0x28
101587b84: d10083a1    	sub	x1, x29, #0x20
101587b88: 940a0e7e    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
101587b8c: 3cc283e0    	ldur	q0, [sp, #0x28]
101587b90: 3d800280    	str	q0, [x20]
101587b94: f9401fe8    	ldr	x8, [sp, #0x38]
101587b98: f9000a88    	str	x8, [x20, #0x10]
101587b9c: f9400be1    	ldr	x1, [sp, #0x10]
101587ba0: b4000081    	cbz	x1, 0x101587bb0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x348>
101587ba4: aa1303e0    	mov	x0, x19
101587ba8: 52800022    	mov	w2, #0x1                ; =1
101587bac: 97d45acc    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101587bb0: a9467bfd    	ldp	x29, x30, [sp, #0x60]
101587bb4: a9454ff4    	ldp	x20, x19, [sp, #0x50]
101587bb8: 9101c3ff    	add	sp, sp, #0x70
101587bbc: d65f03c0    	ret
101587bc0: 52800048    	mov	w8, #0x2                ; =2
101587bc4: 39002288    	strb	w8, [x20, #0x8]
101587bc8: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101587bcc: f9000288    	str	x8, [x20]
101587bd0: f9400be1    	ldr	x1, [sp, #0x10]
101587bd4: b5fffe81    	cbnz	x1, 0x101587ba4 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x33c>
101587bd8: 17fffff6    	b	0x101587bb0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x348>
101587bdc: 52800028    	mov	w8, #0x1                ; =1
101587be0: 39002288    	strb	w8, [x20, #0x8]
101587be4: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101587be8: f9000288    	str	x8, [x20]
101587bec: f9400be1    	ldr	x1, [sp, #0x10]
101587bf0: b5fffda1    	cbnz	x1, 0x101587ba4 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x33c>
101587bf4: 17ffffef    	b	0x101587bb0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x348>
101587bf8: 3900229f    	strb	wzr, [x20, #0x8]
101587bfc: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101587c00: f9000288    	str	x8, [x20]
101587c04: f9400be1    	ldr	x1, [sp, #0x10]
101587c08: b5fffce1    	cbnz	x1, 0x101587ba4 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x33c>
101587c0c: 17ffffe9    	b	0x101587bb0 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x348>
101587c10: aa0003f4    	mov	x20, x0
101587c14: f9400be1    	ldr	x1, [sp, #0x10]
101587c18: b4000081    	cbz	x1, 0x101587c28 <__ZN11otty_config20AutocompleteShortcut5parse17h8879551d32c20721E+0x3c0>
101587c1c: aa1303e0    	mov	x0, x19
101587c20: 52800022    	mov	w2, #0x1                ; =1
101587c24: 97d45aae    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101587c28: aa1403e0    	mov	x0, x20
101587c2c: 9415066a    	bl	0x101ac95d4 <_writev+0x101ac95d4>
