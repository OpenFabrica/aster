
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010142ee7c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E>:
10142fcd4: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10142fcd8: a90167fa    	stp	x26, x25, [sp, #0x10]
10142fcdc: a9025ff8    	stp	x24, x23, [sp, #0x20]
10142fce0: a90357f6    	stp	x22, x21, [sp, #0x30]
10142fce4: a9044ff4    	stp	x20, x19, [sp, #0x40]
10142fce8: a9057bfd    	stp	x29, x30, [sp, #0x50]
10142fcec: 910143fd    	add	x29, sp, #0x50
10142fcf0: d113c3ff    	sub	sp, sp, #0x4f0
10142fcf4: f90003ff    	str	xzr, [sp]
10142fcf8: aa0103f4    	mov	x20, x1
10142fcfc: aa0003f9    	mov	x25, x0
10142fd00: a9422029    	ldp	x9, x8, [x1, #0x20]
10142fd04: eb09011f    	cmp	x8, x9
10142fd08: 540001e2    	b.hs	0x10142fd44 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0xec8>
10142fd0c: f9400e8a    	ldr	x10, [x20, #0x18]
10142fd10: 5280002b    	mov	w11, #0x1               ; =1
10142fd14: d284c00c    	mov	x12, #0x2600            ; =9728
10142fd18: f2c0002c    	movk	x12, #0x1, lsl #32
10142fd1c: 3868694d    	ldrb	w13, [x10, x8]
10142fd20: 710081bf    	cmp	w13, #0x20
10142fd24: 9acd216e    	lsl	x14, x11, x13
10142fd28: 8a0c01ce    	and	x14, x14, x12
10142fd2c: fa4099c4    	ccmp	x14, #0x0, #0x4, ls
10142fd30: 54000180    	b.eq	0x10142fd60 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0xee4>
10142fd34: 91000508    	add	x8, x8, #0x1
10142fd38: f9001688    	str	x8, [x20, #0x28]
10142fd3c: eb08013f    	cmp	x9, x8
10142fd40: 54fffee1    	b.ne	0x10142fd1c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0xea0>
10142fd44: 528000b3    	mov	w19, #0x5               ; =5
10142fd48: f900f3f3    	str	x19, [sp, #0x1e0]
10142fd4c: 910783e1    	add	x1, sp, #0x1e0
10142fd50: aa1403e0    	mov	x0, x20
10142fd54: 94197cf5    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
10142fd58: a9000333    	stp	x19, x0, [x25]
10142fd5c: 14000538    	b	0x10143123c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x23c0>
10142fd60: 71016dbf    	cmp	w13, #0x5b
10142fd64: 54003880    	b.eq	0x101430474 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x15f8>
10142fd68: 7101edbf    	cmp	w13, #0x7b
10142fd6c: 5400a941    	b.ne	0x101431294 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2418>
10142fd70: 3940c289    	ldrb	w9, [x20, #0x30]
10142fd74: 51000529    	sub	w9, w9, #0x1
10142fd78: 3900c289    	strb	w9, [x20, #0x30]
10142fd7c: 72001d3f    	tst	w9, #0xff
10142fd80: 54008d40    	b.eq	0x101430f28 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x20ac>
10142fd84: 91000508    	add	x8, x8, #0x1
10142fd88: f9001688    	str	x8, [x20, #0x28]
10142fd8c: f900b3f4    	str	x20, [sp, #0x160]
10142fd90: 52800028    	mov	w8, #0x1                ; =1
10142fd94: 3905a3e8    	strb	w8, [sp, #0x168]
10142fd98: b24107ea    	mov	x10, #-0x7fffffffffffffff ; =-9223372036854775807
10142fd9c: f81103aa    	stur	x10, [x29, #-0xf0]
10142fda0: f81283aa    	stur	x10, [x29, #-0xd8]
10142fda4: 528000a9    	mov	w9, #0x5                ; =5
10142fda8: 528000a8    	mov	w8, #0x5                ; =5
10142fdac: a90223f9    	stp	x25, x8, [sp, #0x20]
10142fdb0: f9016be9    	str	x9, [sp, #0x2d0]
10142fdb4: f900c3ea    	str	x10, [sp, #0x180]
10142fdb8: a958bbe4    	ldp	x4, x14, [sp, #0x188]
10142fdbc: f9416fea    	ldr	x10, [sp, #0x2d8]
10142fdc0: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10142fdc4: b24107ec    	mov	x12, #-0x7fffffffffffffff ; =-9223372036854775807
10142fdc8: b24107ef    	mov	x15, #-0x7fffffffffffffff ; =-9223372036854775807
10142fdcc: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
10142fdd0: f9002be9    	str	x9, [sp, #0x50]
10142fdd4: a97337ab    	ldp	x11, x13, [x29, #-0xd0]
10142fdd8: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
10142fddc: f9002fe9    	str	x9, [sp, #0x58]
10142fde0: f90023e9    	str	x9, [sp, #0x40]
10142fde4: 528000a9    	mov	w9, #0x5                ; =5
10142fde8: f90033e9    	str	x9, [sp, #0x60]
10142fdec: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
10142fdf0: f90027e9    	str	x9, [sp, #0x48]
10142fdf4: a90327ea    	stp	x10, x9, [sp, #0x30]
10142fdf8: a971aba9    	ldp	x9, x10, [x29, #-0xe8]
10142fdfc: f90037ef    	str	x15, [sp, #0x68]
10142fe00: aa0403fb    	mov	x27, x4
10142fe04: aa0e03f5    	mov	x21, x14
10142fe08: aa0c03f3    	mov	x19, x12
10142fe0c: aa0b03f8    	mov	x24, x11
10142fe10: aa0d03f6    	mov	x22, x13
10142fe14: aa0803fc    	mov	x28, x8
10142fe18: aa0903f7    	mov	x23, x9
10142fe1c: aa0a03f9    	mov	x25, x10
10142fe20: 910783e0    	add	x0, sp, #0x1e0
10142fe24: 910583e1    	add	x1, sp, #0x160
10142fe28: 9400f327    	bl	0x10146cac4 <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x2d8>
10142fe2c: 394783e8    	ldrb	w8, [sp, #0x1e0]
10142fe30: 7100051f    	cmp	w8, #0x1
10142fe34: 540037e0    	b.eq	0x101430530 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x16b4>
10142fe38: 394787e8    	ldrb	w8, [sp, #0x1e1]
10142fe3c: 7100051f    	cmp	w8, #0x1
10142fe40: 54003901    	b.ne	0x101430560 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x16e4>
10142fe44: f940b3fa    	ldr	x26, [sp, #0x160]
10142fe48: f9401748    	ldr	x8, [x26, #0x28]
10142fe4c: 91000508    	add	x8, x8, #0x1
10142fe50: f9001748    	str	x8, [x26, #0x28]
10142fe54: f9000b5f    	str	xzr, [x26, #0x10]
10142fe58: 910783e8    	add	x8, sp, #0x1e0
10142fe5c: 91006340    	add	x0, x26, #0x18
10142fe60: aa1a03e1    	mov	x1, x26
10142fe64: 940983cc    	bl	0x101690d94 <__ZN68_$LT$serde_json..read..StrRead$u20$as$u20$serde_json..read..Read$GT$9parse_str17h79c5c49f51148a19E>
10142fe68: a95e07e8    	ldp	x8, x1, [sp, #0x1e0]
10142fe6c: f100091f    	cmp	x8, #0x2
10142fe70: 54004020    	b.eq	0x101430674 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x17f8>
10142fe74: f940fbe2    	ldr	x2, [sp, #0x1f0]
10142fe78: d10303a0    	sub	x0, x29, #0xc0
10142fe7c: 94006bf4    	bl	0x10144ae4c <__ZN197_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionKind$GT$..deserialize..__FieldVisitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h04becca310550952E+0x14>
10142fe80: 385403a8    	ldurb	w8, [x29, #-0xc0]
10142fe84: 7100051f    	cmp	w8, #0x1
10142fe88: 54004120    	b.eq	0x1014306ac <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1830>
10142fe8c: 385413a8    	ldurb	w8, [x29, #-0xbf]
10142fe90: 7100091f    	cmp	w8, #0x2
10142fe94: 5400036d    	b.le	0x10142ff00 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1084>
10142fe98: 7100111f    	cmp	w8, #0x4
10142fe9c: 5400064c    	b.gt	0x10142ff64 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x10e8>
10142fea0: 71000d1f    	cmp	w8, #0x3
10142fea4: 54000ec1    	b.ne	0x10143007c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1200>
10142fea8: f94027ea    	ldr	x10, [sp, #0x48]
10142feac: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10142feb0: eb08015f    	cmp	x10, x8
10142feb4: 5400b381    	b.ne	0x101431524 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x26a8>
10142feb8: a9422349    	ldp	x9, x8, [x26, #0x20]
10142febc: eb09011f    	cmp	x8, x9
10142fec0: 54004662    	b.hs	0x10143078c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1910>
10142fec4: f841834a    	ldur	x10, [x26, #0x18]
10142fec8: 3868694b    	ldrb	w11, [x10, x8]
10142fecc: 7100e97f    	cmp	w11, #0x3a
10142fed0: 5400b5c8    	b.hi	0x101431588 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x270c>
10142fed4: 5280002c    	mov	w12, #0x1               ; =1
10142fed8: 9acb218c    	lsl	x12, x12, x11
10142fedc: d284c00d    	mov	x13, #0x2600            ; =9728
10142fee0: f2c0002d    	movk	x13, #0x1, lsl #32
10142fee4: ea0d019f    	tst	x12, x13
10142fee8: 54001a80    	b.eq	0x101430238 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x13bc>
10142feec: 91000508    	add	x8, x8, #0x1
10142fef0: f9001748    	str	x8, [x26, #0x28]
10142fef4: eb08013f    	cmp	x9, x8
10142fef8: 54fffe81    	b.ne	0x10142fec8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x104c>
10142fefc: 14000224    	b	0x10143078c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1910>
10142ff00: 34000628    	cbz	w8, 0x10142ffc4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1148>
10142ff04: 7100051f    	cmp	w8, #0x1
10142ff08: 540008a1    	b.ne	0x10143001c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x11a0>
10142ff0c: f9402be8    	ldr	x8, [sp, #0x50]
10142ff10: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
10142ff14: eb09011f    	cmp	x8, x9
10142ff18: 5400a701    	b.ne	0x1014313f8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x257c>
10142ff1c: a9422349    	ldp	x9, x8, [x26, #0x20]
10142ff20: eb09011f    	cmp	x8, x9
10142ff24: 54004582    	b.hs	0x1014307d4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1958>
10142ff28: f841834a    	ldur	x10, [x26, #0x18]
10142ff2c: 3868694b    	ldrb	w11, [x10, x8]
10142ff30: 7100e97f    	cmp	w11, #0x3a
10142ff34: 5400b748    	b.hi	0x10143161c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x27a0>
10142ff38: 5280002c    	mov	w12, #0x1               ; =1
10142ff3c: 9acb218c    	lsl	x12, x12, x11
10142ff40: d284c00d    	mov	x13, #0x2600            ; =9728
10142ff44: f2c0002d    	movk	x13, #0x1, lsl #32
10142ff48: ea0d019f    	tst	x12, x13
10142ff4c: 540010c0    	b.eq	0x101430164 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x12e8>
10142ff50: 91000508    	add	x8, x8, #0x1
10142ff54: f9001748    	str	x8, [x26, #0x28]
10142ff58: eb08013f    	cmp	x9, x8
10142ff5c: 54fffe81    	b.ne	0x10142ff2c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x10b0>
10142ff60: 1400021d    	b	0x1014307d4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1958>
10142ff64: 7100151f    	cmp	w8, #0x5
10142ff68: 54000b41    	b.ne	0x1014300d0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1254>
10142ff6c: f94023ea    	ldr	x10, [sp, #0x40]
10142ff70: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10142ff74: eb08015f    	cmp	x10, x8
10142ff78: 54009d21    	b.ne	0x10143131c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x24a0>
10142ff7c: a9422349    	ldp	x9, x8, [x26, #0x20]
10142ff80: eb09011f    	cmp	x8, x9
10142ff84: 54003dc2    	b.hs	0x10143073c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x18c0>
10142ff88: f841834a    	ldur	x10, [x26, #0x18]
10142ff8c: 3868694b    	ldrb	w11, [x10, x8]
10142ff90: 7100e97f    	cmp	w11, #0x3a
10142ff94: 5400b1e8    	b.hi	0x1014315d0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2754>
10142ff98: 5280002c    	mov	w12, #0x1               ; =1
10142ff9c: 9acb218c    	lsl	x12, x12, x11
10142ffa0: d284c00d    	mov	x13, #0x2600            ; =9728
10142ffa4: f2c0002d    	movk	x13, #0x1, lsl #32
10142ffa8: ea0d019f    	tst	x12, x13
10142ffac: 54001740    	b.eq	0x101430294 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1418>
10142ffb0: 91000508    	add	x8, x8, #0x1
10142ffb4: f9001748    	str	x8, [x26, #0x28]
10142ffb8: eb08013f    	cmp	x9, x8
10142ffbc: 54fffe81    	b.ne	0x10142ff8c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1110>
10142ffc0: 140001df    	b	0x10143073c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x18c0>
10142ffc4: f9402fe8    	ldr	x8, [sp, #0x58]
10142ffc8: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
10142ffcc: eb09011f    	cmp	x8, x9
10142ffd0: 5400a781    	b.ne	0x1014314c0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2644>
10142ffd4: a9422349    	ldp	x9, x8, [x26, #0x20]
10142ffd8: eb09011f    	cmp	x8, x9
10142ffdc: 54003802    	b.hs	0x1014306dc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1860>
10142ffe0: f841834a    	ldur	x10, [x26, #0x18]
10142ffe4: 3868694b    	ldrb	w11, [x10, x8]
10142ffe8: 7100e97f    	cmp	w11, #0x3a
10142ffec: 5400b408    	b.hi	0x10143166c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x27f0>
10142fff0: 5280002c    	mov	w12, #0x1               ; =1
10142fff4: 9acb218c    	lsl	x12, x12, x11
10142fff8: d284c00d    	mov	x13, #0x2600            ; =9728
10142fffc: f2c0002d    	movk	x13, #0x1, lsl #32
101430000: ea0d019f    	tst	x12, x13
101430004: 54000820    	b.eq	0x101430108 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x128c>
101430008: 91000508    	add	x8, x8, #0x1
10143000c: f9001748    	str	x8, [x26, #0x28]
101430010: eb08013f    	cmp	x9, x8
101430014: 54fffe81    	b.ne	0x10142ffe4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1168>
101430018: 140001b1    	b	0x1014306dc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1860>
10143001c: f9401fea    	ldr	x10, [sp, #0x38]
101430020: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101430024: eb08015f    	cmp	x10, x8
101430028: 5400a1a1    	b.ne	0x10143145c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x25e0>
10143002c: a9422f4a    	ldp	x10, x11, [x26, #0x20]
101430030: eb0a017f    	cmp	x11, x10
101430034: 54004002    	b.hs	0x101430834 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19b8>
101430038: f8418348    	ldur	x8, [x26, #0x18]
10143003c: 91000969    	add	x9, x11, #0x2
101430040: 386b690c    	ldrb	w12, [x8, x11]
101430044: 7100e99f    	cmp	w12, #0x3a
101430048: 5400b608    	b.hi	0x101431708 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x288c>
10143004c: 5280002d    	mov	w13, #0x1               ; =1
101430050: 9acc21ad    	lsl	x13, x13, x12
101430054: d284c00e    	mov	x14, #0x2600            ; =9728
101430058: f2c0002e    	movk	x14, #0x1, lsl #32
10143005c: ea0e01bf    	tst	x13, x14
101430060: 54000ba0    	b.eq	0x1014301d4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1358>
101430064: 9100056b    	add	x11, x11, #0x1
101430068: f900174b    	str	x11, [x26, #0x28]
10143006c: 91000529    	add	x9, x9, #0x1
101430070: eb0b015f    	cmp	x10, x11
101430074: 54fffe61    	b.ne	0x101430040 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x11c4>
101430078: 140001ef    	b	0x101430834 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19b8>
10143007c: f94033e8    	ldr	x8, [sp, #0x60]
101430080: f100151f    	cmp	x8, #0x5
101430084: 54009881    	b.ne	0x101431394 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2518>
101430088: a9422349    	ldp	x9, x8, [x26, #0x20]
10143008c: eb09011f    	cmp	x8, x9
101430090: 54003f82    	b.hs	0x101430880 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1a04>
101430094: f841834a    	ldur	x10, [x26, #0x18]
101430098: 3868694b    	ldrb	w11, [x10, x8]
10143009c: 7100e97f    	cmp	w11, #0x3a
1014300a0: 5400b0e8    	b.hi	0x1014316bc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2840>
1014300a4: 5280002c    	mov	w12, #0x1               ; =1
1014300a8: 9acb218c    	lsl	x12, x12, x11
1014300ac: d284c00d    	mov	x13, #0x2600            ; =9728
1014300b0: f2c0002d    	movk	x13, #0x1, lsl #32
1014300b4: ea0d019f    	tst	x12, x13
1014300b8: 540011c0    	b.eq	0x1014302f0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1474>
1014300bc: 91000508    	add	x8, x8, #0x1
1014300c0: f9001748    	str	x8, [x26, #0x28]
1014300c4: eb08013f    	cmp	x9, x8
1014300c8: 54fffe81    	b.ne	0x101430098 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x121c>
1014300cc: 140001ed    	b	0x101430880 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1a04>
1014300d0: aa1a03e0    	mov	x0, x26
1014300d4: 97ff4c10    	bl	0x101403114 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x20c8>
1014300d8: aa1903ea    	mov	x10, x25
1014300dc: aa1703e9    	mov	x9, x23
1014300e0: aa1c03e8    	mov	x8, x28
1014300e4: aa1603ed    	mov	x13, x22
1014300e8: aa1803eb    	mov	x11, x24
1014300ec: aa1303ec    	mov	x12, x19
1014300f0: aa1503ee    	mov	x14, x21
1014300f4: aa1b03e4    	mov	x4, x27
1014300f8: f94037e5    	ldr	x5, [sp, #0x68]
1014300fc: aa0503ef    	mov	x15, x5
101430100: b4ffe7e0    	cbz	x0, 0x10142fdfc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0xf80>
101430104: 1400022c    	b	0x1014309b4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b38>
101430108: f100e97f    	cmp	x11, #0x3a
10143010c: 5400ab01    	b.ne	0x10143166c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x27f0>
101430110: 91000508    	add	x8, x8, #0x1
101430114: f9001748    	str	x8, [x26, #0x28]
101430118: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10143011c: f9002fe8    	str	x8, [sp, #0x58]
101430120: d10303a0    	sub	x0, x29, #0xc0
101430124: aa1a03e1    	mov	x1, x26
101430128: 9400fe0b    	bl	0x10146f954 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x25c4>
10143012c: f85403a8    	ldur	x8, [x29, #-0xc0]
101430130: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
101430134: eb09011f    	cmp	x8, x9
101430138: 54005e20    	b.eq	0x101430cfc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1e80>
10143013c: f9002fe8    	str	x8, [sp, #0x58]
101430140: aa1903ea    	mov	x10, x25
101430144: aa1703e9    	mov	x9, x23
101430148: aa1c03e8    	mov	x8, x28
10143014c: aa1603ed    	mov	x13, x22
101430150: f85483ab    	ldur	x11, [x29, #-0xb8]
101430154: f9000feb    	str	x11, [sp, #0x18]
101430158: f85503ab    	ldur	x11, [x29, #-0xb0]
10143015c: f90007eb    	str	x11, [sp, #0x8]
101430160: 14000017    	b	0x1014301bc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1340>
101430164: f100e97f    	cmp	x11, #0x3a
101430168: 5400a5a1    	b.ne	0x10143161c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x27a0>
10143016c: 91000508    	add	x8, x8, #0x1
101430170: f9001748    	str	x8, [x26, #0x28]
101430174: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101430178: f9002be8    	str	x8, [sp, #0x50]
10143017c: d10303a0    	sub	x0, x29, #0xc0
101430180: aa1a03e1    	mov	x1, x26
101430184: 9400fdf4    	bl	0x10146f954 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x25c4>
101430188: f85403a8    	ldur	x8, [x29, #-0xc0]
10143018c: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
101430190: eb09011f    	cmp	x8, x9
101430194: 54005d00    	b.eq	0x101430d34 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1eb8>
101430198: f9002be8    	str	x8, [sp, #0x50]
10143019c: aa1903ea    	mov	x10, x25
1014301a0: aa1703e9    	mov	x9, x23
1014301a4: aa1c03e8    	mov	x8, x28
1014301a8: aa1603ed    	mov	x13, x22
1014301ac: f85483ab    	ldur	x11, [x29, #-0xb8]
1014301b0: f9000beb    	str	x11, [sp, #0x10]
1014301b4: f85503ab    	ldur	x11, [x29, #-0xb0]
1014301b8: f90003eb    	str	x11, [sp]
1014301bc: aa1803eb    	mov	x11, x24
1014301c0: aa1303ec    	mov	x12, x19
1014301c4: aa1503ee    	mov	x14, x21
1014301c8: aa1b03e4    	mov	x4, x27
1014301cc: f94037ef    	ldr	x15, [sp, #0x68]
1014301d0: 17ffff0b    	b	0x10142fdfc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0xf80>
1014301d4: f100e99f    	cmp	x12, #0x3a
1014301d8: 5400a981    	b.ne	0x101431708 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x288c>
1014301dc: 9100056b    	add	x11, x11, #0x1
1014301e0: f900174b    	str	x11, [x26, #0x28]
1014301e4: eb0a017f    	cmp	x11, x10
1014301e8: 540011a2    	b.hs	0x10143041c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x15a0>
1014301ec: 5280002b    	mov	w11, #0x1               ; =1
1014301f0: cb0a016b    	sub	x11, x11, x10
1014301f4: 9100110c    	add	x12, x8, #0x4
1014301f8: 8b09018d    	add	x13, x12, x9
1014301fc: 385fb1ad    	ldurb	w13, [x13, #-0x5]
101430200: 710081bf    	cmp	w13, #0x20
101430204: 5280002e    	mov	w14, #0x1               ; =1
101430208: 9acd21ce    	lsl	x14, x14, x13
10143020c: d284c00f    	mov	x15, #0x2600            ; =9728
101430210: f2c0002f    	movk	x15, #0x1, lsl #32
101430214: 8a0f01ce    	and	x14, x14, x15
101430218: fa4099c4    	ccmp	x14, #0x0, #0x4, ls
10143021c: 54000b40    	b.eq	0x101430384 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1508>
101430220: f9001749    	str	x9, [x26, #0x28]
101430224: 91000529    	add	x9, x9, #0x1
101430228: 8b09016d    	add	x13, x11, x9
10143022c: f10009bf    	cmp	x13, #0x2
101430230: 54fffe41    	b.ne	0x1014301f8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x137c>
101430234: 1400007a    	b	0x10143041c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x15a0>
101430238: f100e97f    	cmp	x11, #0x3a
10143023c: 54009a61    	b.ne	0x101431588 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x270c>
101430240: 91000508    	add	x8, x8, #0x1
101430244: f9001748    	str	x8, [x26, #0x28]
101430248: d10303a0    	sub	x0, x29, #0xc0
10143024c: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101430250: f90027e8    	str	x8, [sp, #0x48]
101430254: aa1a03e1    	mov	x1, x26
101430258: 9400fe17    	bl	0x10146fab4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2724>
10143025c: a9742fac    	ldp	x12, x11, [x29, #-0xc0]
101430260: aa1903ea    	mov	x10, x25
101430264: aa1703e9    	mov	x9, x23
101430268: aa1c03e8    	mov	x8, x28
10143026c: aa1503ee    	mov	x14, x21
101430270: f85503ad    	ldur	x13, [x29, #-0xb0]
101430274: aa1b03e4    	mov	x4, x27
101430278: f94037e5    	ldr	x5, [sp, #0x68]
10143027c: aa0503ef    	mov	x15, x5
101430280: f90027ec    	str	x12, [sp, #0x48]
101430284: b24107e0    	mov	x0, #-0x7fffffffffffffff ; =-9223372036854775807
101430288: eb00019f    	cmp	x12, x0
10143028c: 54ffdb81    	b.ne	0x10142fdfc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0xf80>
101430290: 140001c6    	b	0x1014309a8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b2c>
101430294: f100e97f    	cmp	x11, #0x3a
101430298: 540099c1    	b.ne	0x1014315d0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2754>
10143029c: 91000508    	add	x8, x8, #0x1
1014302a0: f9001748    	str	x8, [x26, #0x28]
1014302a4: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
1014302a8: f90023e8    	str	x8, [sp, #0x40]
1014302ac: d10303a0    	sub	x0, x29, #0xc0
1014302b0: aa1a03e1    	mov	x1, x26
1014302b4: 9401068a    	bl	0x101471cdc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x494c>
1014302b8: a97413af    	ldp	x15, x4, [x29, #-0xc0]
1014302bc: aa1903ea    	mov	x10, x25
1014302c0: aa1703e9    	mov	x9, x23
1014302c4: aa1c03e8    	mov	x8, x28
1014302c8: aa1603ed    	mov	x13, x22
1014302cc: f85503ae    	ldur	x14, [x29, #-0xb0]
1014302d0: aa1803eb    	mov	x11, x24
1014302d4: aa1303ec    	mov	x12, x19
1014302d8: f90023ef    	str	x15, [sp, #0x40]
1014302dc: b24107f0    	mov	x16, #-0x7fffffffffffffff ; =-9223372036854775807
1014302e0: eb1001ff    	cmp	x15, x16
1014302e4: f94037f0    	ldr	x16, [sp, #0x68]
1014302e8: 54ffd8a1    	b.ne	0x10142fdfc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0xf80>
1014302ec: 1400026a    	b	0x101430c94 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1e18>
1014302f0: f100e97f    	cmp	x11, #0x3a
1014302f4: 54009e41    	b.ne	0x1014316bc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2840>
1014302f8: 91000508    	add	x8, x8, #0x1
1014302fc: f9001748    	str	x8, [x26, #0x28]
101430300: 910783e0    	add	x0, sp, #0x1e0
101430304: 528000a8    	mov	w8, #0x5                ; =5
101430308: f90033e8    	str	x8, [sp, #0x60]
10143030c: aa1a03e1    	mov	x1, x26
101430310: 9400f421    	bl	0x10146d394 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x4>
101430314: f940f3e8    	ldr	x8, [sp, #0x1e0]
101430318: f100151f    	cmp	x8, #0x5
10143031c: 54004d40    	b.eq	0x101430cc4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1e48>
101430320: f940f7e9    	ldr	x9, [sp, #0x1e8]
101430324: f9001be9    	str	x9, [sp, #0x30]
101430328: 910783ec    	add	x12, sp, #0x1e0
10143032c: ad418580    	ldp	q0, q1, [x12, #0x30]
101430330: 910b43f0    	add	x16, sp, #0x2d0
101430334: ad018600    	stp	q0, q1, [x16, #0x30]
101430338: 3cc50180    	ldur	q0, [x12, #0x50]
10143033c: 3c850200    	stur	q0, [x16, #0x50]
101430340: aa0803ee    	mov	x14, x8
101430344: f8460188    	ldur	x8, [x12, #0x60]
101430348: f8060208    	stur	x8, [x16, #0x60]
10143034c: aa1903ea    	mov	x10, x25
101430350: aa1703e9    	mov	x9, x23
101430354: aa1c03e8    	mov	x8, x28
101430358: aa1603ed    	mov	x13, x22
10143035c: aa1803eb    	mov	x11, x24
101430360: ad408580    	ldp	q0, q1, [x12, #0x10]
101430364: aa1303ec    	mov	x12, x19
101430368: f90033ee    	str	x14, [sp, #0x60]
10143036c: f90017ee    	str	x14, [sp, #0x28]
101430370: aa1503ee    	mov	x14, x21
101430374: aa1b03e4    	mov	x4, x27
101430378: f94037ef    	ldr	x15, [sp, #0x68]
10143037c: ad008600    	stp	q0, q1, [x16, #0x10]
101430380: 17fffe9f    	b	0x10142fdfc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0xf80>
101430384: 7101b9bf    	cmp	w13, #0x6e
101430388: 540004a1    	b.ne	0x10143041c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x15a0>
10143038c: f9001749    	str	x9, [x26, #0x28]
101430390: eb0a013f    	cmp	x9, x10
101430394: 9a8a812a    	csel	x10, x9, x10, hi
101430398: 54004f22    	b.hs	0x101430d7c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1f00>
10143039c: 3869690c    	ldrb	w12, [x8, x9]
1014303a0: 9100052b    	add	x11, x9, #0x1
1014303a4: f900174b    	str	x11, [x26, #0x28]
1014303a8: 7101d59f    	cmp	w12, #0x75
1014303ac: 54009d21    	b.ne	0x101431750 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x28d4>
1014303b0: eb0a017f    	cmp	x11, x10
1014303b4: 54004e40    	b.eq	0x101430d7c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1f00>
1014303b8: 8b09010b    	add	x11, x8, x9
1014303bc: 3940056c    	ldrb	w12, [x11, #0x1]
1014303c0: 9100092b    	add	x11, x9, #0x2
1014303c4: f900174b    	str	x11, [x26, #0x28]
1014303c8: 7101b19f    	cmp	w12, #0x6c
1014303cc: 54009c21    	b.ne	0x101431750 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x28d4>
1014303d0: eb0a017f    	cmp	x11, x10
1014303d4: 54004d40    	b.eq	0x101430d7c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1f00>
1014303d8: 8b090108    	add	x8, x8, x9
1014303dc: 39400908    	ldrb	w8, [x8, #0x2]
1014303e0: 91000d29    	add	x9, x9, #0x3
1014303e4: f9001749    	str	x9, [x26, #0x28]
1014303e8: 7101b11f    	cmp	w8, #0x6c
1014303ec: 54009b21    	b.ne	0x101431750 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x28d4>
1014303f0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014303f4: aa1603ed    	mov	x13, x22
1014303f8: aa1803eb    	mov	x11, x24
1014303fc: aa1303ec    	mov	x12, x19
101430400: a974aba9    	ldp	x9, x10, [x29, #-0xb8]
101430404: aa1503ee    	mov	x14, x21
101430408: aa1b03e4    	mov	x4, x27
10143040c: f94037ef    	ldr	x15, [sp, #0x68]
101430410: d2f00010    	mov	x16, #-0x8000000000000000 ; =-9223372036854775808
101430414: f9001ff0    	str	x16, [sp, #0x38]
101430418: 17fffe79    	b	0x10142fdfc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0xf80>
10143041c: d10303a0    	sub	x0, x29, #0xc0
101430420: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101430424: f9001fe8    	str	x8, [sp, #0x38]
101430428: aa1a03e1    	mov	x1, x26
10143042c: 94010b0b    	bl	0x101473058 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5cc8>
101430430: a97427a8    	ldp	x8, x9, [x29, #-0xc0]
101430434: aa1603ed    	mov	x13, x22
101430438: aa1803eb    	mov	x11, x24
10143043c: aa1303ec    	mov	x12, x19
101430440: aa1503ee    	mov	x14, x21
101430444: f85503aa    	ldur	x10, [x29, #-0xb0]
101430448: aa1b03e4    	mov	x4, x27
10143044c: f94037e5    	ldr	x5, [sp, #0x68]
101430450: aa0503ef    	mov	x15, x5
101430454: f9001fe8    	str	x8, [sp, #0x38]
101430458: b24107e0    	mov	x0, #-0x7fffffffffffffff ; =-9223372036854775807
10143045c: eb00011f    	cmp	x8, x0
101430460: 54ffcce1    	b.ne	0x10142fdfc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0xf80>
101430464: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101430468: f9001fe8    	str	x8, [sp, #0x38]
10143046c: aa0903e0    	mov	x0, x9
101430470: 14000151    	b	0x1014309b4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b38>
101430474: 3940c289    	ldrb	w9, [x20, #0x30]
101430478: 51000529    	sub	w9, w9, #0x1
10143047c: 3900c289    	strb	w9, [x20, #0x30]
101430480: 72001d3f    	tst	w9, #0xff
101430484: 54005520    	b.eq	0x101430f28 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x20ac>
101430488: 91000508    	add	x8, x8, #0x1
10143048c: f9001688    	str	x8, [x20, #0x28]
101430490: f81003b4    	stur	x20, [x29, #-0x100]
101430494: 52800028    	mov	w8, #0x1                ; =1
101430498: 381083a8    	sturb	w8, [x29, #-0xf8]
10143049c: 910783e0    	add	x0, sp, #0x1e0
1014304a0: d10403a1    	sub	x1, x29, #0x100
1014304a4: 9400f23b    	bl	0x10146cd90 <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x5a4>
1014304a8: 394783e8    	ldrb	w8, [sp, #0x1e0]
1014304ac: 7100051f    	cmp	w8, #0x1
1014304b0: 540000e1    	b.ne	0x1014304cc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1650>
1014304b4: aa1903fb    	mov	x27, x25
1014304b8: d2800055    	mov	x21, #0x2               ; =2
1014304bc: f2f00015    	movk	x21, #0x8000, lsl #48
1014304c0: f940f7e0    	ldr	x0, [sp, #0x1e8]
1014304c4: 528000bc    	mov	w28, #0x5               ; =5
1014304c8: 140002ee    	b	0x101431080 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2204>
1014304cc: 394787e8    	ldrb	w8, [sp, #0x1e1]
1014304d0: 7100051f    	cmp	w8, #0x1
1014304d4: 540022c1    	b.ne	0x10143092c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1ab0>
1014304d8: f85003a1    	ldur	x1, [x29, #-0x100]
1014304dc: 910783e0    	add	x0, sp, #0x1e0
1014304e0: 9400fd1d    	bl	0x10146f954 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x25c4>
1014304e4: a95e5bf5    	ldp	x21, x22, [sp, #0x1e0]
1014304e8: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
1014304ec: eb0802bf    	cmp	x21, x8
1014304f0: 540000e1    	b.ne	0x10143050c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1690>
1014304f4: aa1903fb    	mov	x27, x25
1014304f8: d2800055    	mov	x21, #0x2               ; =2
1014304fc: f2f00015    	movk	x21, #0x8000, lsl #48
101430500: 528000bc    	mov	w28, #0x5               ; =5
101430504: aa1603e0    	mov	x0, x22
101430508: 140002de    	b	0x101431080 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2204>
10143050c: f940fbf3    	ldr	x19, [sp, #0x1f0]
101430510: 910783e0    	add	x0, sp, #0x1e0
101430514: d10403a1    	sub	x1, x29, #0x100
101430518: 9400f21e    	bl	0x10146cd90 <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x5a4>
10143051c: 394783e8    	ldrb	w8, [sp, #0x1e0]
101430520: 7100051f    	cmp	w8, #0x1
101430524: 54000821    	b.ne	0x101430628 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x17ac>
101430528: f940f7f7    	ldr	x23, [sp, #0x1e8]
10143052c: 140002cc    	b	0x10143105c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21e0>
101430530: f94037e8    	ldr	x8, [sp, #0x68]
101430534: a9186fe8    	stp	x8, x27, [sp, #0x180]
101430538: f900cbf5    	str	x21, [sp, #0x190]
10143053c: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101430540: f9016be9    	str	x9, [sp, #0x2d0]
101430544: f9016fe8    	str	x8, [sp, #0x2d8]
101430548: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
10143054c: f81383b6    	stur	x22, [x29, #-0xc8]
101430550: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101430554: f81203b9    	stur	x25, [x29, #-0xe0]
101430558: f940f7e4    	ldr	x4, [sp, #0x1e8]
10143055c: 14000120    	b	0x1014309dc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b60>
101430560: f94037e8    	ldr	x8, [sp, #0x68]
101430564: a9186fe8    	stp	x8, x27, [sp, #0x180]
101430568: f900cbf5    	str	x21, [sp, #0x190]
10143056c: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101430570: f9016be9    	str	x9, [sp, #0x2d0]
101430574: f9016fe8    	str	x8, [sp, #0x2d8]
101430578: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
10143057c: f81383b6    	stur	x22, [x29, #-0xc8]
101430580: b24107eb    	mov	x11, #-0x7fffffffffffffff ; =-9223372036854775807
101430584: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101430588: a94523ea    	ldp	x10, x8, [sp, #0x50]
10143058c: eb0b011f    	cmp	x8, x11
101430590: 9a880128    	csel	x8, x9, x8, eq
101430594: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101430598: eb0b015f    	cmp	x10, x11
10143059c: 9a8a012a    	csel	x10, x9, x10, eq
1014305a0: f81203b9    	stur	x25, [x29, #-0xe0]
1014305a4: f9401fec    	ldr	x12, [sp, #0x38]
1014305a8: eb0b019f    	cmp	x12, x11
1014305ac: 540000a0    	b.eq	0x1014305c0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1744>
1014305b0: d103c3a9    	sub	x9, x29, #0xf0
1014305b4: 3cc08120    	ldur	q0, [x9, #0x8]
1014305b8: 3d80efe0    	str	q0, [sp, #0x3b0]
1014305bc: aa0c03e9    	mov	x9, x12
1014305c0: a9443bef    	ldp	x15, x14, [sp, #0x40]
1014305c4: eb0b01df    	cmp	x14, x11
1014305c8: a94133ed    	ldp	x13, x12, [sp, #0x10]
1014305cc: a94043e0    	ldp	x0, x16, [sp]
1014305d0: 54001841    	b.ne	0x1014308d8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1a5c>
1014305d4: d2f0000e    	mov	x14, #-0x8000000000000000 ; =-9223372036854775808
1014305d8: f94033eb    	ldr	x11, [sp, #0x60]
1014305dc: f100157f    	cmp	x11, #0x5
1014305e0: 54001880    	b.eq	0x1014308f0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1a74>
1014305e4: f9416ff8    	ldr	x24, [sp, #0x2d8]
1014305e8: 910b43f1    	add	x17, sp, #0x2d0
1014305ec: ad418620    	ldp	q0, q1, [x17, #0x30]
1014305f0: ad1f87e0    	stp	q0, q1, [sp, #0x3f0]
1014305f4: 3cc50220    	ldur	q0, [x17, #0x50]
1014305f8: 3d8107e0    	str	q0, [sp, #0x410]
1014305fc: f846022b    	ldur	x11, [x17, #0x60]
101430600: f90213eb    	str	x11, [sp, #0x420]
101430604: ad408620    	ldp	q0, q1, [x17, #0x10]
101430608: ad1e87e0    	stp	q0, q1, [sp, #0x3d0]
10143060c: b24107eb    	mov	x11, #-0x7fffffffffffffff ; =-9223372036854775807
101430610: eb0b01ff    	cmp	x15, x11
101430614: 54001780    	b.eq	0x101430904 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1a88>
101430618: 910603eb    	add	x11, sp, #0x180
10143061c: 3cc08160    	ldur	q0, [x11, #0x8]
101430620: 3d810fe0    	str	q0, [sp, #0x430]
101430624: 14000161    	b	0x101430ba8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1d2c>
101430628: 394787e8    	ldrb	w8, [sp, #0x1e1]
10143062c: 7100051f    	cmp	w8, #0x1
101430630: 540016e1    	b.ne	0x10143090c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1a90>
101430634: f85003a1    	ldur	x1, [x29, #-0x100]
101430638: 910783e0    	add	x0, sp, #0x1e0
10143063c: 9400fcc6    	bl	0x10146f954 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x25c4>
101430640: a95e5ff8    	ldp	x24, x23, [sp, #0x1e0]
101430644: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101430648: eb08031f    	cmp	x24, x8
10143064c: 54005080    	b.eq	0x10143105c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21e0>
101430650: f940fbfa    	ldr	x26, [sp, #0x1f0]
101430654: 910783e0    	add	x0, sp, #0x1e0
101430658: d10403a1    	sub	x1, x29, #0x100
10143065c: 9400f1cd    	bl	0x10146cd90 <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x5a4>
101430660: 394783e8    	ldrb	w8, [sp, #0x1e0]
101430664: 7100051f    	cmp	w8, #0x1
101430668: 54001741    	b.ne	0x101430950 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1ad4>
10143066c: f940f7fb    	ldr	x27, [sp, #0x1e8]
101430670: 14000274    	b	0x101431040 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21c4>
101430674: f94037e8    	ldr	x8, [sp, #0x68]
101430678: a9186fe8    	stp	x8, x27, [sp, #0x180]
10143067c: f900cbf5    	str	x21, [sp, #0x190]
101430680: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101430684: f9016be9    	str	x9, [sp, #0x2d0]
101430688: f9016fe8    	str	x8, [sp, #0x2d8]
10143068c: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101430690: f81383b6    	stur	x22, [x29, #-0xc8]
101430694: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101430698: f81203b9    	stur	x25, [x29, #-0xe0]
10143069c: a9445ff9    	ldp	x25, x23, [sp, #0x40]
1014306a0: f9401ff6    	ldr	x22, [sp, #0x38]
1014306a4: aa0103e4    	mov	x4, x1
1014306a8: 140000cf    	b	0x1014309e4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b68>
1014306ac: f94037e8    	ldr	x8, [sp, #0x68]
1014306b0: a9186fe8    	stp	x8, x27, [sp, #0x180]
1014306b4: f900cbf5    	str	x21, [sp, #0x190]
1014306b8: a942a3e9    	ldp	x9, x8, [sp, #0x28]
1014306bc: f9016be9    	str	x9, [sp, #0x2d0]
1014306c0: f9016fe8    	str	x8, [sp, #0x2d8]
1014306c4: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
1014306c8: f81383b6    	stur	x22, [x29, #-0xc8]
1014306cc: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
1014306d0: f81203b9    	stur	x25, [x29, #-0xe0]
1014306d4: f85483a4    	ldur	x4, [x29, #-0xb8]
1014306d8: 140000c1    	b	0x1014309dc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b60>
1014306dc: f94037e8    	ldr	x8, [sp, #0x68]
1014306e0: a9186fe8    	stp	x8, x27, [sp, #0x180]
1014306e4: f900cbf5    	str	x21, [sp, #0x190]
1014306e8: a942a3e9    	ldp	x9, x8, [sp, #0x28]
1014306ec: f9016be9    	str	x9, [sp, #0x2d0]
1014306f0: f9016fe8    	str	x8, [sp, #0x2d8]
1014306f4: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
1014306f8: f81383b6    	stur	x22, [x29, #-0xc8]
1014306fc: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101430700: f81203b9    	stur	x25, [x29, #-0xe0]
101430704: 52800068    	mov	w8, #0x3                ; =3
101430708: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
10143070c: f9002fe9    	str	x9, [sp, #0x58]
101430710: f900f3e8    	str	x8, [sp, #0x1e0]
101430714: 910783e1    	add	x1, sp, #0x1e0
101430718: aa1a03e0    	mov	x0, x26
10143071c: a9445ff9    	ldp	x25, x23, [sp, #0x40]
101430720: f9401ff6    	ldr	x22, [sp, #0x38]
101430724: 94197a81    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
101430728: aa0003e4    	mov	x4, x0
10143072c: f81483a0    	stur	x0, [x29, #-0xb8]
101430730: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101430734: f9002fe8    	str	x8, [sp, #0x58]
101430738: 140000ab    	b	0x1014309e4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b68>
10143073c: f94037e8    	ldr	x8, [sp, #0x68]
101430740: a9186fe8    	stp	x8, x27, [sp, #0x180]
101430744: f900cbf5    	str	x21, [sp, #0x190]
101430748: a942a3e9    	ldp	x9, x8, [sp, #0x28]
10143074c: f9016be9    	str	x9, [sp, #0x2d0]
101430750: f9016fe8    	str	x8, [sp, #0x2d8]
101430754: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101430758: f81383b6    	stur	x22, [x29, #-0xc8]
10143075c: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101430760: f81203b9    	stur	x25, [x29, #-0xe0]
101430764: 52800068    	mov	w8, #0x3                ; =3
101430768: b24107f9    	mov	x25, #-0x7fffffffffffffff ; =-9223372036854775807
10143076c: f900f3e8    	str	x8, [sp, #0x1e0]
101430770: 910783e1    	add	x1, sp, #0x1e0
101430774: aa1a03e0    	mov	x0, x26
101430778: f94027f7    	ldr	x23, [sp, #0x48]
10143077c: f9401ff6    	ldr	x22, [sp, #0x38]
101430780: 94197a6a    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
101430784: aa0003e4    	mov	x4, x0
101430788: 140000b2    	b	0x101430a50 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1bd4>
10143078c: f94037e8    	ldr	x8, [sp, #0x68]
101430790: a9186fe8    	stp	x8, x27, [sp, #0x180]
101430794: f900cbf5    	str	x21, [sp, #0x190]
101430798: a942a3e9    	ldp	x9, x8, [sp, #0x28]
10143079c: f9016be9    	str	x9, [sp, #0x2d0]
1014307a0: f9016fe8    	str	x8, [sp, #0x2d8]
1014307a4: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
1014307a8: f81383b6    	stur	x22, [x29, #-0xc8]
1014307ac: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
1014307b0: f81203b9    	stur	x25, [x29, #-0xe0]
1014307b4: 52800068    	mov	w8, #0x3                ; =3
1014307b8: b24107f7    	mov	x23, #-0x7fffffffffffffff ; =-9223372036854775807
1014307bc: f900f3e8    	str	x8, [sp, #0x1e0]
1014307c0: 910783e1    	add	x1, sp, #0x1e0
1014307c4: aa1a03e0    	mov	x0, x26
1014307c8: a943e7f6    	ldp	x22, x25, [sp, #0x38]
1014307cc: 94197a57    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
1014307d0: 1400002a    	b	0x101430878 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19fc>
1014307d4: f94037e8    	ldr	x8, [sp, #0x68]
1014307d8: a9186fe8    	stp	x8, x27, [sp, #0x180]
1014307dc: f900cbf5    	str	x21, [sp, #0x190]
1014307e0: a942a3e9    	ldp	x9, x8, [sp, #0x28]
1014307e4: f9016be9    	str	x9, [sp, #0x2d0]
1014307e8: f9016fe8    	str	x8, [sp, #0x2d8]
1014307ec: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
1014307f0: f81383b6    	stur	x22, [x29, #-0xc8]
1014307f4: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
1014307f8: f81203b9    	stur	x25, [x29, #-0xe0]
1014307fc: 52800068    	mov	w8, #0x3                ; =3
101430800: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
101430804: f9002be9    	str	x9, [sp, #0x50]
101430808: f900f3e8    	str	x8, [sp, #0x1e0]
10143080c: 910783e1    	add	x1, sp, #0x1e0
101430810: aa1a03e0    	mov	x0, x26
101430814: a9445ff9    	ldp	x25, x23, [sp, #0x40]
101430818: f9401ff6    	ldr	x22, [sp, #0x38]
10143081c: 94197a43    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
101430820: aa0003e4    	mov	x4, x0
101430824: f81483a0    	stur	x0, [x29, #-0xb8]
101430828: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10143082c: f9002be8    	str	x8, [sp, #0x50]
101430830: 1400006d    	b	0x1014309e4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b68>
101430834: f94037e8    	ldr	x8, [sp, #0x68]
101430838: a9186fe8    	stp	x8, x27, [sp, #0x180]
10143083c: f900cbf5    	str	x21, [sp, #0x190]
101430840: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101430844: f9016be9    	str	x9, [sp, #0x2d0]
101430848: f9016fe8    	str	x8, [sp, #0x2d8]
10143084c: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101430850: f81383b6    	stur	x22, [x29, #-0xc8]
101430854: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101430858: f81203b9    	stur	x25, [x29, #-0xe0]
10143085c: 52800068    	mov	w8, #0x3                ; =3
101430860: b24107f6    	mov	x22, #-0x7fffffffffffffff ; =-9223372036854775807
101430864: f900f3e8    	str	x8, [sp, #0x1e0]
101430868: 910783e1    	add	x1, sp, #0x1e0
10143086c: aa1a03e0    	mov	x0, x26
101430870: a9445ff9    	ldp	x25, x23, [sp, #0x40]
101430874: 94197a2d    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
101430878: aa0003e4    	mov	x4, x0
10143087c: 1400005a    	b	0x1014309e4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b68>
101430880: f94037e8    	ldr	x8, [sp, #0x68]
101430884: a9186fe8    	stp	x8, x27, [sp, #0x180]
101430888: f900cbf5    	str	x21, [sp, #0x190]
10143088c: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101430890: f9016be9    	str	x9, [sp, #0x2d0]
101430894: f9016fe8    	str	x8, [sp, #0x2d8]
101430898: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
10143089c: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
1014308a0: f81203b9    	stur	x25, [x29, #-0xe0]
1014308a4: 52800068    	mov	w8, #0x3                ; =3
1014308a8: 528000a9    	mov	w9, #0x5                ; =5
1014308ac: f90033e9    	str	x9, [sp, #0x60]
1014308b0: a933a3b6    	stp	x22, x8, [x29, #-0xc8]
1014308b4: d10303a1    	sub	x1, x29, #0xc0
1014308b8: aa1a03e0    	mov	x0, x26
1014308bc: a9445ff9    	ldp	x25, x23, [sp, #0x40]
1014308c0: f9401ff6    	ldr	x22, [sp, #0x38]
1014308c4: 94197a19    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
1014308c8: aa0003e4    	mov	x4, x0
1014308cc: 528000a8    	mov	w8, #0x5                ; =5
1014308d0: f90033e8    	str	x8, [sp, #0x60]
1014308d4: 14000044    	b	0x1014309e4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b68>
1014308d8: d10363ab    	sub	x11, x29, #0xd8
1014308dc: 3cc08160    	ldur	q0, [x11, #0x8]
1014308e0: 3d80f3e0    	str	q0, [sp, #0x3c0]
1014308e4: f94033eb    	ldr	x11, [sp, #0x60]
1014308e8: f100157f    	cmp	x11, #0x5
1014308ec: 54ffe7c1    	b.ne	0x1014305e4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1768>
1014308f0: 5280008b    	mov	w11, #0x4               ; =4
1014308f4: f90033eb    	str	x11, [sp, #0x60]
1014308f8: b24107eb    	mov	x11, #-0x7fffffffffffffff ; =-9223372036854775807
1014308fc: eb0b01ff    	cmp	x15, x11
101430900: 54ffe8c1    	b.ne	0x101430618 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x179c>
101430904: d2f0000f    	mov	x15, #-0x8000000000000000 ; =-9223372036854775808
101430908: 140000a8    	b	0x101430ba8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1d2c>
10143090c: b00071c1    	adrp	x1, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101430910: 9129c021    	add	x1, x1, #0xa70
101430914: 900071c2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101430918: 9113a042    	add	x2, x2, #0x4e8
10143091c: 52800020    	mov	w0, #0x1                ; =1
101430920: 941979a2    	bl	0x101a8efa8 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0xc8>
101430924: aa0003f7    	mov	x23, x0
101430928: 140001cd    	b	0x10143105c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21e0>
10143092c: aa1903fb    	mov	x27, x25
101430930: b00071c1    	adrp	x1, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101430934: 9129c021    	add	x1, x1, #0xa70
101430938: 900071c2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
10143093c: 9113a042    	add	x2, x2, #0x4e8
101430940: d2800000    	mov	x0, #0x0                ; =0
101430944: 94197999    	bl	0x101a8efa8 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0xc8>
101430948: b24107f5    	mov	x21, #-0x7fffffffffffffff ; =-9223372036854775807
10143094c: 17fffede    	b	0x1014304c4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1648>
101430950: 394787e8    	ldrb	w8, [sp, #0x1e1]
101430954: 7100051f    	cmp	w8, #0x1
101430958: 540020a1    	b.ne	0x101430d6c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1ef0>
10143095c: f85003a1    	ldur	x1, [x29, #-0x100]
101430960: a9422029    	ldp	x9, x8, [x1, #0x20]
101430964: eb09011f    	cmp	x8, x9
101430968: 540024c2    	b.hs	0x101430e00 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1f84>
10143096c: f9400c2a    	ldr	x10, [x1, #0x18]
101430970: 5280002b    	mov	w11, #0x1               ; =1
101430974: d284c00c    	mov	x12, #0x2600            ; =9728
101430978: f2c0002c    	movk	x12, #0x1, lsl #32
10143097c: 3868694d    	ldrb	w13, [x10, x8]
101430980: 710081bf    	cmp	w13, #0x20
101430984: 9acd216e    	lsl	x14, x11, x13
101430988: 8a0c01ce    	and	x14, x14, x12
10143098c: fa4099c4    	ccmp	x14, #0x0, #0x4, ls
101430990: 540021a0    	b.eq	0x101430dc4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1f48>
101430994: 91000508    	add	x8, x8, #0x1
101430998: f9001428    	str	x8, [x1, #0x28]
10143099c: eb08013f    	cmp	x9, x8
1014309a0: 54fffee1    	b.ne	0x10143097c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b00>
1014309a4: 14000117    	b	0x101430e00 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1f84>
1014309a8: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
1014309ac: f90027e8    	str	x8, [sp, #0x48]
1014309b0: aa0b03e0    	mov	x0, x11
1014309b4: a9186fe5    	stp	x5, x27, [sp, #0x180]
1014309b8: f900cbf5    	str	x21, [sp, #0x190]
1014309bc: a942a3e9    	ldp	x9, x8, [sp, #0x28]
1014309c0: f9016be9    	str	x9, [sp, #0x2d0]
1014309c4: f9016fe8    	str	x8, [sp, #0x2d8]
1014309c8: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
1014309cc: f81383b6    	stur	x22, [x29, #-0xc8]
1014309d0: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
1014309d4: aa0003e4    	mov	x4, x0
1014309d8: f81203b9    	stur	x25, [x29, #-0xe0]
1014309dc: a9445ff9    	ldp	x25, x23, [sp, #0x40]
1014309e0: f9401ff6    	ldr	x22, [sp, #0x38]
1014309e4: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
1014309e8: eb08033f    	cmp	x25, x8
1014309ec: 54000320    	b.eq	0x101430a50 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1bd4>
1014309f0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014309f4: eb08033f    	cmp	x25, x8
1014309f8: 540002c0    	b.eq	0x101430a50 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1bd4>
1014309fc: aa0403f8    	mov	x24, x4
101430a00: a958cffa    	ldp	x26, x19, [sp, #0x188]
101430a04: b4000193    	cbz	x19, 0x101430a34 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1bb8>
101430a08: 91002355    	add	x21, x26, #0x8
101430a0c: 14000004    	b	0x101430a1c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1ba0>
101430a10: 910062b5    	add	x21, x21, #0x18
101430a14: f1000673    	subs	x19, x19, #0x1
101430a18: 540000e0    	b.eq	0x101430a34 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1bb8>
101430a1c: f85f82a1    	ldur	x1, [x21, #-0x8]
101430a20: b4ffff81    	cbz	x1, 0x101430a10 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b94>
101430a24: f94002a0    	ldr	x0, [x21]
101430a28: 52800022    	mov	w2, #0x1                ; =1
101430a2c: 97d9b72c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101430a30: 17fffff8    	b	0x101430a10 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b94>
101430a34: b40000d9    	cbz	x25, 0x101430a4c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1bd0>
101430a38: 8b190728    	add	x8, x25, x25, lsl #1
101430a3c: d37df101    	lsl	x1, x8, #3
101430a40: aa1a03e0    	mov	x0, x26
101430a44: 52800102    	mov	w2, #0x8                ; =8
101430a48: 97d9b725    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101430a4c: aa1803e4    	mov	x4, x24
101430a50: aa0403f8    	mov	x24, x4
101430a54: f94033e8    	ldr	x8, [sp, #0x60]
101430a58: f100151f    	cmp	x8, #0x5
101430a5c: 54000300    	b.eq	0x101430abc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1c40>
101430a60: f100111f    	cmp	x8, #0x4
101430a64: 540002c0    	b.eq	0x101430abc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1c40>
101430a68: f1000d1f    	cmp	x8, #0x3
101430a6c: 54000241    	b.ne	0x101430ab4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1c38>
101430a70: f94173fa    	ldr	x26, [sp, #0x2e0]
101430a74: f94177f3    	ldr	x19, [sp, #0x2e8]
101430a78: b40000f3    	cbz	x19, 0x101430a94 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1c18>
101430a7c: aa1a03fb    	mov	x27, x26
101430a80: aa1b03e0    	mov	x0, x27
101430a84: 94008c5d    	bl	0x101453bf8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6770>
101430a88: 9101a37b    	add	x27, x27, #0x68
101430a8c: f1000673    	subs	x19, x19, #0x1
101430a90: 54ffff81    	b.ne	0x101430a80 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1c04>
101430a94: f9416fe8    	ldr	x8, [sp, #0x2d8]
101430a98: b4000128    	cbz	x8, 0x101430abc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1c40>
101430a9c: 52800d09    	mov	w9, #0x68               ; =104
101430aa0: 9b097d01    	mul	x1, x8, x9
101430aa4: aa1a03e0    	mov	x0, x26
101430aa8: 52800102    	mov	w2, #0x8                ; =8
101430aac: 97d9b70c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101430ab0: 14000003    	b	0x101430abc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1c40>
101430ab4: 910b43e0    	add	x0, sp, #0x2d0
101430ab8: 94008c50    	bl	0x101453bf8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6770>
101430abc: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101430ac0: eb0802ff    	cmp	x23, x8
101430ac4: 54000240    	b.eq	0x101430b0c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1c90>
101430ac8: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101430acc: eb0802ff    	cmp	x23, x8
101430ad0: 540001e0    	b.eq	0x101430b0c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1c90>
101430ad4: a9734fba    	ldp	x26, x19, [x29, #-0xd0]
101430ad8: b40000f3    	cbz	x19, 0x101430af4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1c78>
101430adc: aa1a03fb    	mov	x27, x26
101430ae0: aa1b03e0    	mov	x0, x27
101430ae4: 94008d50    	bl	0x101454024 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6b9c>
101430ae8: 9102637b    	add	x27, x27, #0x98
101430aec: f1000673    	subs	x19, x19, #0x1
101430af0: 54ffff81    	b.ne	0x101430ae0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1c64>
101430af4: b40000d7    	cbz	x23, 0x101430b0c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1c90>
101430af8: 52801308    	mov	w8, #0x98               ; =152
101430afc: 9b087ee1    	mul	x1, x23, x8
101430b00: aa1a03e0    	mov	x0, x26
101430b04: 52800102    	mov	w2, #0x8                ; =8
101430b08: 97d9b6f5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101430b0c: d2800055    	mov	x21, #0x2               ; =2
101430b10: f2f00015    	movk	x21, #0x8000, lsl #48
101430b14: eb1502df    	cmp	x22, x21
101430b18: 5400020b    	b.lt	0x101430b58 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1cdc>
101430b1c: a971a3ba    	ldp	x26, x8, [x29, #-0xe8]
101430b20: 91000513    	add	x19, x8, #0x1
101430b24: aa1a03e0    	mov	x0, x26
101430b28: f1000673    	subs	x19, x19, #0x1
101430b2c: 540000a0    	b.eq	0x101430b40 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1cc4>
101430b30: 9103801b    	add	x27, x0, #0xe0
101430b34: 94008f11    	bl	0x101454778 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x72f0>
101430b38: aa1b03e0    	mov	x0, x27
101430b3c: 17fffffb    	b	0x101430b28 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1cac>
101430b40: b40000d6    	cbz	x22, 0x101430b58 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1cdc>
101430b44: d378dec8    	lsl	x8, x22, #8
101430b48: cb161501    	sub	x1, x8, x22, lsl #5
101430b4c: aa1a03e0    	mov	x0, x26
101430b50: 52800102    	mov	w2, #0x8                ; =8
101430b54: 97d9b6e2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101430b58: f9402be1    	ldr	x1, [sp, #0x50]
101430b5c: eb15003f    	cmp	x1, x21
101430b60: 540000ab    	b.lt	0x101430b74 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1cf8>
101430b64: b4000081    	cbz	x1, 0x101430b74 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1cf8>
101430b68: f9400be0    	ldr	x0, [sp, #0x10]
101430b6c: 52800022    	mov	w2, #0x1                ; =1
101430b70: 97d9b6db    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101430b74: 528000a8    	mov	w8, #0x5                ; =5
101430b78: f90033e8    	str	x8, [sp, #0x60]
101430b7c: d2800048    	mov	x8, #0x2                ; =2
101430b80: f2f00008    	movk	x8, #0x8000, lsl #48
101430b84: f9402fe1    	ldr	x1, [sp, #0x58]
101430b88: eb08003f    	cmp	x1, x8
101430b8c: f9400fe0    	ldr	x0, [sp, #0x18]
101430b90: 540000cb    	b.lt	0x101430ba8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1d2c>
101430b94: b40000a1    	cbz	x1, 0x101430ba8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1d2c>
101430b98: 52800022    	mov	w2, #0x1                ; =1
101430b9c: 97d9b6d0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101430ba0: 528000a8    	mov	w8, #0x5                ; =5
101430ba4: f90033e8    	str	x8, [sp, #0x60]
101430ba8: 3940c28b    	ldrb	w11, [x20, #0x30]
101430bac: 1100056b    	add	w11, w11, #0x1
101430bb0: 3900c28b    	strb	w11, [x20, #0x30]
101430bb4: f94033eb    	ldr	x11, [sp, #0x60]
101430bb8: f9016beb    	str	x11, [sp, #0x2d0]
101430bbc: f9016ff8    	str	x24, [sp, #0x2d8]
101430bc0: ad5f87e0    	ldp	q0, q1, [sp, #0x3f0]
101430bc4: ad1807e0    	stp	q0, q1, [sp, #0x300]
101430bc8: 3dc107e0    	ldr	q0, [sp, #0x410]
101430bcc: 3d80cbe0    	str	q0, [sp, #0x320]
101430bd0: f94213eb    	ldr	x11, [sp, #0x420]
101430bd4: ad5e87e0    	ldp	q0, q1, [sp, #0x3d0]
101430bd8: ad1707e0    	stp	q0, q1, [sp, #0x2e0]
101430bdc: f9019beb    	str	x11, [sp, #0x330]
101430be0: f9019fe8    	str	x8, [sp, #0x338]
101430be4: f901a3ec    	str	x12, [sp, #0x340]
101430be8: f901a7f0    	str	x16, [sp, #0x348]
101430bec: f901abea    	str	x10, [sp, #0x350]
101430bf0: f901afed    	str	x13, [sp, #0x358]
101430bf4: f901b3e0    	str	x0, [sp, #0x360]
101430bf8: f901b7e9    	str	x9, [sp, #0x368]
101430bfc: ad5d83e1    	ldp	q1, q0, [sp, #0x3b0]
101430c00: 3d80dfe1    	str	q1, [sp, #0x370]
101430c04: 910b43e8    	add	x8, sp, #0x2d0
101430c08: 3c8b8100    	stur	q0, [x8, #0xb8]
101430c0c: f901c3ee    	str	x14, [sp, #0x380]
101430c10: f901cfef    	str	x15, [sp, #0x398]
101430c14: 3dc10fe0    	ldr	q0, [sp, #0x430]
101430c18: 3d80ebe0    	str	q0, [sp, #0x3a0]
101430c1c: aa1403e0    	mov	x0, x20
101430c20: 97ff4f35    	bl	0x1014048f4 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x38a8>
101430c24: aa0003f6    	mov	x22, x0
101430c28: ad5b87e0    	ldp	q0, q1, [sp, #0x370]
101430c2c: ad1407e0    	stp	q0, q1, [sp, #0x280]
101430c30: ad5c87e0    	ldp	q0, q1, [sp, #0x390]
101430c34: ad1507e0    	stp	q0, q1, [sp, #0x2a0]
101430c38: ad5987e0    	ldp	q0, q1, [sp, #0x330]
101430c3c: ad1207e0    	stp	q0, q1, [sp, #0x240]
101430c40: ad5a87e0    	ldp	q0, q1, [sp, #0x350]
101430c44: ad1307e0    	stp	q0, q1, [sp, #0x260]
101430c48: ad5787e0    	ldp	q0, q1, [sp, #0x2f0]
101430c4c: ad1007e0    	stp	q0, q1, [sp, #0x200]
101430c50: ad5887e0    	ldp	q0, q1, [sp, #0x310]
101430c54: ad1107e0    	stp	q0, q1, [sp, #0x220]
101430c58: ad5687e0    	ldp	q0, q1, [sp, #0x2d0]
101430c5c: ad0f07e0    	stp	q0, q1, [sp, #0x1e0]
101430c60: f90163e0    	str	x0, [sp, #0x2c0]
101430c64: f940f3e8    	ldr	x8, [sp, #0x1e0]
101430c68: f100151f    	cmp	x8, #0x5
101430c6c: f94013f9    	ldr	x25, [sp, #0x20]
101430c70: 540028a1    	b.ne	0x101431184 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2308>
101430c74: f940f7f5    	ldr	x21, [sp, #0x1e8]
101430c78: b4002bf6    	cbz	x22, 0x1014311f4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2378>
101430c7c: f94002c8    	ldr	x8, [x22]
101430c80: f100051f    	cmp	x8, #0x1
101430c84: 54002721    	b.ne	0x101431168 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x22ec>
101430c88: 910022c0    	add	x0, x22, #0x8
101430c8c: 9400897c    	bl	0x10145327c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5df4>
101430c90: 14000155    	b	0x1014311e4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2368>
101430c94: a9186ff0    	stp	x16, x27, [sp, #0x180]
101430c98: f900cbf5    	str	x21, [sp, #0x190]
101430c9c: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101430ca0: f9016be9    	str	x9, [sp, #0x2d0]
101430ca4: f9016fe8    	str	x8, [sp, #0x2d8]
101430ca8: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101430cac: f81383b6    	stur	x22, [x29, #-0xc8]
101430cb0: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101430cb4: f81203b9    	stur	x25, [x29, #-0xe0]
101430cb8: f94027f7    	ldr	x23, [sp, #0x48]
101430cbc: f9401ff6    	ldr	x22, [sp, #0x38]
101430cc0: 17ffff64    	b	0x101430a50 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1bd4>
101430cc4: f94037e8    	ldr	x8, [sp, #0x68]
101430cc8: a9186fe8    	stp	x8, x27, [sp, #0x180]
101430ccc: f900cbf5    	str	x21, [sp, #0x190]
101430cd0: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101430cd4: f9016be9    	str	x9, [sp, #0x2d0]
101430cd8: f9016fe8    	str	x8, [sp, #0x2d8]
101430cdc: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101430ce0: f81383b6    	stur	x22, [x29, #-0xc8]
101430ce4: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101430ce8: f81203b9    	stur	x25, [x29, #-0xe0]
101430cec: f940f7e4    	ldr	x4, [sp, #0x1e8]
101430cf0: a9445ff9    	ldp	x25, x23, [sp, #0x40]
101430cf4: f9401ff6    	ldr	x22, [sp, #0x38]
101430cf8: 17fffef5    	b	0x1014308cc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1a50>
101430cfc: f94037e8    	ldr	x8, [sp, #0x68]
101430d00: a9186fe8    	stp	x8, x27, [sp, #0x180]
101430d04: f900cbf5    	str	x21, [sp, #0x190]
101430d08: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101430d0c: f9016be9    	str	x9, [sp, #0x2d0]
101430d10: f9016fe8    	str	x8, [sp, #0x2d8]
101430d14: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101430d18: f81383b6    	stur	x22, [x29, #-0xc8]
101430d1c: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101430d20: f81203b9    	stur	x25, [x29, #-0xe0]
101430d24: f85483a4    	ldur	x4, [x29, #-0xb8]
101430d28: a9445ff9    	ldp	x25, x23, [sp, #0x40]
101430d2c: f9401ff6    	ldr	x22, [sp, #0x38]
101430d30: 17fffe80    	b	0x101430730 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x18b4>
101430d34: f94037e8    	ldr	x8, [sp, #0x68]
101430d38: a9186fe8    	stp	x8, x27, [sp, #0x180]
101430d3c: f900cbf5    	str	x21, [sp, #0x190]
101430d40: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101430d44: f9016be9    	str	x9, [sp, #0x2d0]
101430d48: f9016fe8    	str	x8, [sp, #0x2d8]
101430d4c: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101430d50: f81383b6    	stur	x22, [x29, #-0xc8]
101430d54: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101430d58: f81203b9    	stur	x25, [x29, #-0xe0]
101430d5c: f85483a4    	ldur	x4, [x29, #-0xb8]
101430d60: a9445ff9    	ldp	x25, x23, [sp, #0x40]
101430d64: f9401ff6    	ldr	x22, [sp, #0x38]
101430d68: 17fffeb0    	b	0x101430828 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19ac>
101430d6c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101430d70: f81103a8    	stur	x8, [x29, #-0xf0]
101430d74: 5280003c    	mov	w28, #0x1               ; =1
101430d78: 14000032    	b	0x101430e40 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1fc4>
101430d7c: f94037e8    	ldr	x8, [sp, #0x68]
101430d80: a9186fe8    	stp	x8, x27, [sp, #0x180]
101430d84: f900cbf5    	str	x21, [sp, #0x190]
101430d88: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101430d8c: f9016be9    	str	x9, [sp, #0x2d0]
101430d90: f9016fe8    	str	x8, [sp, #0x2d8]
101430d94: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101430d98: f81383b6    	stur	x22, [x29, #-0xc8]
101430d9c: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101430da0: f81203b9    	stur	x25, [x29, #-0xe0]
101430da4: 528000a8    	mov	w8, #0x5                ; =5
101430da8: b24107f6    	mov	x22, #-0x7fffffffffffffff ; =-9223372036854775807
101430dac: f900f3e8    	str	x8, [sp, #0x1e0]
101430db0: 910783e1    	add	x1, sp, #0x1e0
101430db4: aa1a03e0    	mov	x0, x26
101430db8: a9445ff9    	ldp	x25, x23, [sp, #0x40]
101430dbc: 94197a98    	bl	0x101a8f81c <__ZN10serde_json2de21Deserializer$LT$R$GT$23parse_exponent_overflow17h8d2c34d8b104f113E+0x90>
101430dc0: 17fffeae    	b	0x101430878 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19fc>
101430dc4: 7101b9bf    	cmp	w13, #0x6e
101430dc8: 540001c1    	b.ne	0x101430e00 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1f84>
101430dcc: 91000508    	add	x8, x8, #0x1
101430dd0: f9001428    	str	x8, [x1, #0x28]
101430dd4: f0004568    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101430dd8: 9117d508    	add	x8, x8, #0x5f5
101430ddc: aa0103e0    	mov	x0, x1
101430de0: aa0803e1    	mov	x1, x8
101430de4: 52800062    	mov	w2, #0x3                ; =3
101430de8: 97ff4ab9    	bl	0x1014038cc <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x2880>
101430dec: aa0003fb    	mov	x27, x0
101430df0: b5001280    	cbnz	x0, 0x101431040 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21c4>
101430df4: a95ea7fb    	ldp	x27, x9, [sp, #0x1e8]
101430df8: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101430dfc: 1400000c    	b	0x101430e2c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1fb0>
101430e00: 910783e0    	add	x0, sp, #0x1e0
101430e04: 94010895    	bl	0x101473058 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5cc8>
101430e08: a95e6fe8    	ldp	x8, x27, [sp, #0x1e0]
101430e0c: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
101430e10: eb09011f    	cmp	x8, x9
101430e14: 54001160    	b.eq	0x101431040 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21c4>
101430e18: d2800049    	mov	x9, #0x2                ; =2
101430e1c: f2f00009    	movk	x9, #0x8000, lsl #48
101430e20: eb09011f    	cmp	x8, x9
101430e24: 540010e0    	b.eq	0x101431040 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21c4>
101430e28: f940fbe9    	ldr	x9, [sp, #0x1f0]
101430e2c: a9316fa8    	stp	x8, x27, [x29, #-0xf0]
101430e30: f81203a9    	stur	x9, [x29, #-0xe0]
101430e34: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101430e38: eb09011f    	cmp	x8, x9
101430e3c: 1a9f17fc    	cset	w28, eq
101430e40: 910783e0    	add	x0, sp, #0x1e0
101430e44: d10403a1    	sub	x1, x29, #0x100
101430e48: 9400efd2    	bl	0x10146cd90 <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x5a4>
101430e4c: 394783e8    	ldrb	w8, [sp, #0x1e0]
101430e50: 7100051f    	cmp	w8, #0x1
101430e54: 54000061    	b.ne	0x101430e60 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1fe4>
101430e58: f940f7fb    	ldr	x27, [sp, #0x1e8]
101430e5c: 14000076    	b	0x101431034 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21b8>
101430e60: 394787e8    	ldrb	w8, [sp, #0x1e1]
101430e64: 7100051f    	cmp	w8, #0x1
101430e68: 540001c1    	b.ne	0x101430ea0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2024>
101430e6c: f85003a1    	ldur	x1, [x29, #-0x100]
101430e70: 910783e0    	add	x0, sp, #0x1e0
101430e74: 9400fb10    	bl	0x10146fab4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2724>
101430e78: a95e6fe9    	ldp	x9, x27, [sp, #0x1e0]
101430e7c: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101430e80: eb08013f    	cmp	x9, x8
101430e84: 54000d80    	b.eq	0x101431034 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21b8>
101430e88: f940fbe8    	ldr	x8, [sp, #0x1f0]
101430e8c: f90033e9    	str	x9, [sp, #0x60]
101430e90: a932efa9    	stp	x9, x27, [x29, #-0xd8]
101430e94: f9002be8    	str	x8, [sp, #0x50]
101430e98: f81383a8    	stur	x8, [x29, #-0xc8]
101430e9c: 14000005    	b	0x101430eb0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2034>
101430ea0: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101430ea4: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101430ea8: f90033e8    	str	x8, [sp, #0x60]
101430eac: f81283a9    	stur	x9, [x29, #-0xd8]
101430eb0: 910783e0    	add	x0, sp, #0x1e0
101430eb4: d10403a1    	sub	x1, x29, #0x100
101430eb8: b9006bfc    	str	w28, [sp, #0x68]
101430ebc: 9400efb5    	bl	0x10146cd90 <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x5a4>
101430ec0: 394783e8    	ldrb	w8, [sp, #0x1e0]
101430ec4: 7100051f    	cmp	w8, #0x1
101430ec8: f9002ffb    	str	x27, [sp, #0x58]
101430ecc: 54000081    	b.ne	0x101430edc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2060>
101430ed0: aa1903fb    	mov	x27, x25
101430ed4: f940f7f9    	ldr	x25, [sp, #0x1e8]
101430ed8: 1400003c    	b	0x101430fc8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x214c>
101430edc: 394787e8    	ldrb	w8, [sp, #0x1e1]
101430ee0: 7100051f    	cmp	w8, #0x1
101430ee4: 540002e1    	b.ne	0x101430f40 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x20c4>
101430ee8: f85003a1    	ldur	x1, [x29, #-0x100]
101430eec: 910783e0    	add	x0, sp, #0x1e0
101430ef0: 9400f129    	bl	0x10146d394 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x4>
101430ef4: aa1903fb    	mov	x27, x25
101430ef8: a95e67fc    	ldp	x28, x25, [sp, #0x1e0]
101430efc: f100179f    	cmp	x28, #0x5
101430f00: 54000640    	b.eq	0x101430fc8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x214c>
101430f04: ad5087e0    	ldp	q0, q1, [sp, #0x210]
101430f08: ad3b07a0    	stp	q0, q1, [x29, #-0xa0]
101430f0c: 3dc08fe0    	ldr	q0, [sp, #0x230]
101430f10: 3c9803a0    	stur	q0, [x29, #-0x80]
101430f14: f94123e8    	ldr	x8, [sp, #0x240]
101430f18: f81903a8    	stur	x8, [x29, #-0x70]
101430f1c: ad4f87e0    	ldp	q0, q1, [sp, #0x1f0]
101430f20: ad3a07a0    	stp	q0, q1, [x29, #-0xc0]
101430f24: 14000009    	b	0x101430f48 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x20cc>
101430f28: 52800308    	mov	w8, #0x18               ; =24
101430f2c: f900f3e8    	str	x8, [sp, #0x1e0]
101430f30: 910783e1    	add	x1, sp, #0x1e0
101430f34: aa1403e0    	mov	x0, x20
101430f38: 9419787c    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
101430f3c: 140000df    	b	0x1014312b8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x243c>
101430f40: aa1903fb    	mov	x27, x25
101430f44: 528000bc    	mov	w28, #0x5               ; =5
101430f48: ad7b07a0    	ldp	q0, q1, [x29, #-0xa0]
101430f4c: ad1007e0    	stp	q0, q1, [sp, #0x200]
101430f50: 3cd803a0    	ldur	q0, [x29, #-0x80]
101430f54: 3d808be0    	str	q0, [sp, #0x220]
101430f58: f85903a8    	ldur	x8, [x29, #-0x70]
101430f5c: f9011be8    	str	x8, [sp, #0x230]
101430f60: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
101430f64: ad0f07e0    	stp	q0, q1, [sp, #0x1e0]
101430f68: f100179f    	cmp	x28, #0x5
101430f6c: 54000061    	b.ne	0x101430f78 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x20fc>
101430f70: 5280009c    	mov	w28, #0x4               ; =4
101430f74: 1400000b    	b	0x101430fa0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2124>
101430f78: ad5007e0    	ldp	q0, q1, [sp, #0x200]
101430f7c: ad1807e0    	stp	q0, q1, [sp, #0x300]
101430f80: 3dc08be0    	ldr	q0, [sp, #0x220]
101430f84: 3d80cbe0    	str	q0, [sp, #0x320]
101430f88: f9411be8    	ldr	x8, [sp, #0x230]
101430f8c: f9019be8    	str	x8, [sp, #0x330]
101430f90: ad4f07e0    	ldp	q0, q1, [sp, #0x1e0]
101430f94: ad1707e0    	stp	q0, q1, [sp, #0x2e0]
101430f98: f90027f9    	str	x25, [sp, #0x48]
101430f9c: f9016ff9    	str	x25, [sp, #0x2d8]
101430fa0: f9016bfc    	str	x28, [sp, #0x2d0]
101430fa4: d10303a0    	sub	x0, x29, #0xc0
101430fa8: d10403a1    	sub	x1, x29, #0x100
101430fac: 9400ef79    	bl	0x10146cd90 <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x5a4>
101430fb0: 385403a8    	ldurb	w8, [x29, #-0xc0]
101430fb4: 7100051f    	cmp	w8, #0x1
101430fb8: 54001521    	b.ne	0x10143125c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x23e0>
101430fbc: f85483b9    	ldur	x25, [x29, #-0xb8]
101430fc0: 910b43e0    	add	x0, sp, #0x2d0
101430fc4: 9400828d    	bl	0x1014519f8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x4570>
101430fc8: f94033f3    	ldr	x19, [sp, #0x60]
101430fcc: f9402bfc    	ldr	x28, [sp, #0x50]
101430fd0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101430fd4: eb08027f    	cmp	x19, x8
101430fd8: 540000c1    	b.ne	0x101430ff0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2174>
101430fdc: aa1903e8    	mov	x8, x25
101430fe0: aa1b03f9    	mov	x25, x27
101430fe4: aa0803fb    	mov	x27, x8
101430fe8: b9406bfc    	ldr	w28, [sp, #0x68]
101430fec: 14000012    	b	0x101431034 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21b8>
101430ff0: b40000fc    	cbz	x28, 0x10143100c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2190>
101430ff4: f9402ffa    	ldr	x26, [sp, #0x58]
101430ff8: aa1a03e0    	mov	x0, x26
101430ffc: 94008c0a    	bl	0x101454024 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6b9c>
101431000: 9102635a    	add	x26, x26, #0x98
101431004: f100079c    	subs	x28, x28, #0x1
101431008: 54ffff81    	b.ne	0x101430ff8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x217c>
10143100c: b9406bfc    	ldr	w28, [sp, #0x68]
101431010: b40000d3    	cbz	x19, 0x101431028 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21ac>
101431014: 52801308    	mov	w8, #0x98               ; =152
101431018: 9b087e61    	mul	x1, x19, x8
10143101c: f9402fe0    	ldr	x0, [sp, #0x58]
101431020: 52800102    	mov	w2, #0x8                ; =8
101431024: 97d9b5ae    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431028: aa1903e8    	mov	x8, x25
10143102c: aa1b03f9    	mov	x25, x27
101431030: aa0803fb    	mov	x27, x8
101431034: 3700007c    	tbnz	w28, #0x0, 0x101431040 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21c4>
101431038: d103c3a0    	sub	x0, x29, #0xf0
10143103c: 940093a5    	bl	0x101455ed0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8a48>
101431040: f240fb1f    	tst	x24, #0x7fffffffffffffff
101431044: 540000a0    	b.eq	0x101431058 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21dc>
101431048: aa1703e0    	mov	x0, x23
10143104c: aa1803e1    	mov	x1, x24
101431050: 52800022    	mov	w2, #0x1                ; =1
101431054: 97d9b5a2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431058: aa1b03f7    	mov	x23, x27
10143105c: aa1903fb    	mov	x27, x25
101431060: f240fabf    	tst	x21, #0x7fffffffffffffff
101431064: 540000a0    	b.eq	0x101431078 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x21fc>
101431068: aa1603e0    	mov	x0, x22
10143106c: aa1503e1    	mov	x1, x21
101431070: 52800022    	mov	w2, #0x1                ; =1
101431074: 97d9b59a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431078: 528000bc    	mov	w28, #0x5               ; =5
10143107c: aa1703e0    	mov	x0, x23
101431080: 3940c28a    	ldrb	w10, [x20, #0x30]
101431084: 1100054a    	add	w10, w10, #0x1
101431088: 3900c28a    	strb	w10, [x20, #0x30]
10143108c: f9016bfc    	str	x28, [sp, #0x2d0]
101431090: f9016fe0    	str	x0, [sp, #0x2d8]
101431094: ad4d07e0    	ldp	q0, q1, [sp, #0x1a0]
101431098: ad1807e0    	stp	q0, q1, [sp, #0x300]
10143109c: 3dc073e0    	ldr	q0, [sp, #0x1c0]
1014310a0: 3d80cbe0    	str	q0, [sp, #0x320]
1014310a4: f940ebea    	ldr	x10, [sp, #0x1d0]
1014310a8: ad4c07e0    	ldp	q0, q1, [sp, #0x180]
1014310ac: ad1707e0    	stp	q0, q1, [sp, #0x2e0]
1014310b0: f9019bea    	str	x10, [sp, #0x330]
1014310b4: f9019ff5    	str	x21, [sp, #0x338]
1014310b8: f901a3f6    	str	x22, [sp, #0x340]
1014310bc: f901a7f3    	str	x19, [sp, #0x348]
1014310c0: f901abf8    	str	x24, [sp, #0x350]
1014310c4: f901aff7    	str	x23, [sp, #0x358]
1014310c8: 3dc05be0    	ldr	q0, [sp, #0x160]
1014310cc: 910b43ea    	add	x10, sp, #0x2d0
1014310d0: 3c898140    	stur	q0, [x10, #0x98]
1014310d4: f940bbea    	ldr	x10, [sp, #0x170]
1014310d8: f901b3fa    	str	x26, [sp, #0x360]
1014310dc: f901bfea    	str	x10, [sp, #0x378]
1014310e0: 3dc053e0    	ldr	q0, [sp, #0x140]
1014310e4: 3d80e3e0    	str	q0, [sp, #0x380]
1014310e8: f940abea    	ldr	x10, [sp, #0x150]
1014310ec: f901cbea    	str	x10, [sp, #0x390]
1014310f0: f901cfe9    	str	x9, [sp, #0x398]
1014310f4: f901d3f9    	str	x25, [sp, #0x3a0]
1014310f8: f901d7e8    	str	x8, [sp, #0x3a8]
1014310fc: aa1403e0    	mov	x0, x20
101431100: 97ff4e26    	bl	0x101404998 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x394c>
101431104: aa0003f6    	mov	x22, x0
101431108: ad5b87e0    	ldp	q0, q1, [sp, #0x370]
10143110c: ad1407e0    	stp	q0, q1, [sp, #0x280]
101431110: ad5c87e0    	ldp	q0, q1, [sp, #0x390]
101431114: ad1507e0    	stp	q0, q1, [sp, #0x2a0]
101431118: ad5987e0    	ldp	q0, q1, [sp, #0x330]
10143111c: ad1207e0    	stp	q0, q1, [sp, #0x240]
101431120: ad5a87e0    	ldp	q0, q1, [sp, #0x350]
101431124: ad1307e0    	stp	q0, q1, [sp, #0x260]
101431128: ad5787e0    	ldp	q0, q1, [sp, #0x2f0]
10143112c: ad1007e0    	stp	q0, q1, [sp, #0x200]
101431130: ad5887e0    	ldp	q0, q1, [sp, #0x310]
101431134: ad1107e0    	stp	q0, q1, [sp, #0x220]
101431138: ad5687e0    	ldp	q0, q1, [sp, #0x2d0]
10143113c: ad0f07e0    	stp	q0, q1, [sp, #0x1e0]
101431140: f90163e0    	str	x0, [sp, #0x2c0]
101431144: f940f3e8    	ldr	x8, [sp, #0x1e0]
101431148: f100151f    	cmp	x8, #0x5
10143114c: aa1b03f9    	mov	x25, x27
101431150: 540001a1    	b.ne	0x101431184 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2308>
101431154: f940f7f5    	ldr	x21, [sp, #0x1e8]
101431158: b40004f6    	cbz	x22, 0x1014311f4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2378>
10143115c: f94002c8    	ldr	x8, [x22]
101431160: f100051f    	cmp	x8, #0x1
101431164: 540003c0    	b.eq	0x1014311dc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2360>
101431168: b50003e8    	cbnz	x8, 0x1014311e4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2368>
10143116c: f9400ac1    	ldr	x1, [x22, #0x10]
101431170: b40003a1    	cbz	x1, 0x1014311e4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2368>
101431174: f94006c0    	ldr	x0, [x22, #0x8]
101431178: 52800022    	mov	w2, #0x1                ; =1
10143117c: 97d9b558    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431180: 14000019    	b	0x1014311e4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2368>
101431184: b40000d6    	cbz	x22, 0x10143119c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2320>
101431188: 910783e0    	add	x0, sp, #0x1e0
10143118c: 94008d7b    	bl	0x101454778 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x72f0>
101431190: 528000a8    	mov	w8, #0x5                ; =5
101431194: aa1603f5    	mov	x21, x22
101431198: 14000018    	b	0x1014311f8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x237c>
10143119c: f940f7f5    	ldr	x21, [sp, #0x1e8]
1014311a0: ad5487e0    	ldp	q0, q1, [sp, #0x290]
1014311a4: ad0887e0    	stp	q0, q1, [sp, #0x110]
1014311a8: 3dc0afe0    	ldr	q0, [sp, #0x2b0]
1014311ac: 3d804fe0    	str	q0, [sp, #0x130]
1014311b0: ad5287e0    	ldp	q0, q1, [sp, #0x250]
1014311b4: ad0687e0    	stp	q0, q1, [sp, #0xd0]
1014311b8: ad5383e1    	ldp	q1, q0, [sp, #0x270]
1014311bc: ad0783e1    	stp	q1, q0, [sp, #0xf0]
1014311c0: ad5087e0    	ldp	q0, q1, [sp, #0x210]
1014311c4: ad0487e0    	stp	q0, q1, [sp, #0x90]
1014311c8: ad5183e1    	ldp	q1, q0, [sp, #0x230]
1014311cc: ad0583e1    	stp	q1, q0, [sp, #0xb0]
1014311d0: ad4f83e1    	ldp	q1, q0, [sp, #0x1f0]
1014311d4: ad0383e1    	stp	q1, q0, [sp, #0x70]
1014311d8: 14000008    	b	0x1014311f8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x237c>
1014311dc: 910022c0    	add	x0, x22, #0x8
1014311e0: 94008827    	bl	0x10145327c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5df4>
1014311e4: aa1603e0    	mov	x0, x22
1014311e8: 52800501    	mov	w1, #0x28               ; =40
1014311ec: 52800102    	mov	w2, #0x8                ; =8
1014311f0: 97d9b53b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014311f4: 528000a8    	mov	w8, #0x5                ; =5
1014311f8: f100151f    	cmp	x8, #0x5
1014311fc: 54000580    	b.eq	0x1014312ac <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2430>
101431200: ad4887e0    	ldp	q0, q1, [sp, #0x110]
101431204: ad058720    	stp	q0, q1, [x25, #0xb0]
101431208: 3dc04fe0    	ldr	q0, [sp, #0x130]
10143120c: 3d803720    	str	q0, [x25, #0xd0]
101431210: ad4687e0    	ldp	q0, q1, [sp, #0xd0]
101431214: ad038720    	stp	q0, q1, [x25, #0x70]
101431218: ad4783e1    	ldp	q1, q0, [sp, #0xf0]
10143121c: ad048321    	stp	q1, q0, [x25, #0x90]
101431220: ad4487e0    	ldp	q0, q1, [sp, #0x90]
101431224: ad018720    	stp	q0, q1, [x25, #0x30]
101431228: ad4583e1    	ldp	q1, q0, [sp, #0xb0]
10143122c: ad028321    	stp	q1, q0, [x25, #0x50]
101431230: ad4383e1    	ldp	q1, q0, [sp, #0x70]
101431234: ad008321    	stp	q1, q0, [x25, #0x10]
101431238: a9005728    	stp	x8, x21, [x25]
10143123c: 9113c3ff    	add	sp, sp, #0x4f0
101431240: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101431244: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101431248: a94357f6    	ldp	x22, x21, [sp, #0x30]
10143124c: a9425ff8    	ldp	x24, x23, [sp, #0x20]
101431250: a94167fa    	ldp	x26, x25, [sp, #0x10]
101431254: a8c66ffc    	ldp	x28, x27, [sp], #0x60
101431258: d65f03c0    	ret
10143125c: 385413a8    	ldurb	w8, [x29, #-0xbf]
101431260: b24107eb    	mov	x11, #-0x7fffffffffffffff ; =-9223372036854775807
101431264: 7100051f    	cmp	w8, #0x1
101431268: 540002e1    	b.ne	0x1014312c4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2448>
10143126c: f85003a1    	ldur	x1, [x29, #-0x100]
101431270: d10303a0    	sub	x0, x29, #0xc0
101431274: 9401029a    	bl	0x101471cdc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x494c>
101431278: a97467a9    	ldp	x9, x25, [x29, #-0xc0]
10143127c: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101431280: eb08013f    	cmp	x9, x8
101431284: 54ffe9e0    	b.eq	0x101430fc0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2144>
101431288: f85503a8    	ldur	x8, [x29, #-0xb0]
10143128c: b24107eb    	mov	x11, #-0x7fffffffffffffff ; =-9223372036854775807
101431290: 1400000e    	b	0x1014312c8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x244c>
101431294: f00071a2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101431298: 9115e042    	add	x2, x2, #0x578
10143129c: 910783e1    	add	x1, sp, #0x1e0
1014312a0: aa1403e0    	mov	x0, x20
1014312a4: 941977b5    	bl	0x101a8f178 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x298>
1014312a8: aa0003f5    	mov	x21, x0
1014312ac: aa1503e0    	mov	x0, x21
1014312b0: aa1403e1    	mov	x1, x20
1014312b4: 94197982    	bl	0x101a8f8bc <__ZN10serde_json2de21Deserializer$LT$R$GT$23parse_exponent_overflow17h8d2c34d8b104f113E+0x130>
1014312b8: 528000a8    	mov	w8, #0x5                ; =5
1014312bc: a9000328    	stp	x8, x0, [x25]
1014312c0: 17ffffdf    	b	0x10143123c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x23c0>
1014312c4: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
1014312c8: d2f0000a    	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
1014312cc: 3cd103a0    	ldur	q0, [x29, #-0xf0]
1014312d0: eb0b013f    	cmp	x9, x11
1014312d4: 9a890149    	csel	x9, x10, x9, eq
1014312d8: 3d805be0    	str	q0, [sp, #0x160]
1014312dc: f85203aa    	ldur	x10, [x29, #-0xe0]
1014312e0: f900bbea    	str	x10, [sp, #0x170]
1014312e4: 3cd283a0    	ldur	q0, [x29, #-0xd8]
1014312e8: 3d8053e0    	str	q0, [sp, #0x140]
1014312ec: f85383aa    	ldur	x10, [x29, #-0xc8]
1014312f0: f900abea    	str	x10, [sp, #0x150]
1014312f4: ad5807e0    	ldp	q0, q1, [sp, #0x300]
1014312f8: ad0d07e0    	stp	q0, q1, [sp, #0x1a0]
1014312fc: 3dc0cbe0    	ldr	q0, [sp, #0x320]
101431300: 3d8073e0    	str	q0, [sp, #0x1c0]
101431304: f9419bea    	ldr	x10, [sp, #0x330]
101431308: f900ebea    	str	x10, [sp, #0x1d0]
10143130c: ad5707e0    	ldp	q0, q1, [sp, #0x2e0]
101431310: ad0c07e0    	stp	q0, q1, [sp, #0x180]
101431314: f94027e0    	ldr	x0, [sp, #0x48]
101431318: 17ffff5a    	b	0x101431080 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2204>
10143131c: f94037e8    	ldr	x8, [sp, #0x68]
101431320: a9186fe8    	stp	x8, x27, [sp, #0x180]
101431324: f900cbf5    	str	x21, [sp, #0x190]
101431328: a942a3e9    	ldp	x9, x8, [sp, #0x28]
10143132c: f9016be9    	str	x9, [sp, #0x2d0]
101431330: f9016fe8    	str	x8, [sp, #0x2d8]
101431334: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101431338: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
10143133c: f81203b9    	stur	x25, [x29, #-0xe0]
101431340: 90004588    	adrp	x8, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101431344: 91105d08    	add	x8, x8, #0x417
101431348: 528000e9    	mov	w9, #0x7                ; =7
10143134c: a933a3b6    	stp	x22, x8, [x29, #-0xc8]
101431350: f81483a9    	stur	x9, [x29, #-0xb8]
101431354: d10303a8    	sub	x8, x29, #0xc0
101431358: d00000e9    	adrp	x9, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
10143135c: 91117129    	add	x9, x9, #0x45c
101431360: a91e27e8    	stp	x8, x9, [sp, #0x1e0]
101431364: 90004de0    	adrp	x0, 0x101ded000 <_writev+0x101ded000>
101431368: 912fec00    	add	x0, x0, #0xbfb
10143136c: 910783e1    	add	x1, sp, #0x1e0
101431370: f94027f7    	ldr	x23, [sp, #0x48]
101431374: aa0a03f9    	mov	x25, x10
101431378: f9401ff6    	ldr	x22, [sp, #0x38]
10143137c: 9417dd6f    	bl	0x101a28938 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x214>
101431380: aa0003e4    	mov	x4, x0
101431384: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101431388: eb08033f    	cmp	x25, x8
10143138c: 54ffb620    	b.eq	0x101430a50 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1bd4>
101431390: 17fffd9b    	b	0x1014309fc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1b80>
101431394: f94037e8    	ldr	x8, [sp, #0x68]
101431398: a9186fe8    	stp	x8, x27, [sp, #0x180]
10143139c: f900cbf5    	str	x21, [sp, #0x190]
1014313a0: a942a3e9    	ldp	x9, x8, [sp, #0x28]
1014313a4: f9016be9    	str	x9, [sp, #0x2d0]
1014313a8: f9016fe8    	str	x8, [sp, #0x2d8]
1014313ac: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
1014313b0: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
1014313b4: f81203b9    	stur	x25, [x29, #-0xe0]
1014313b8: b0003768    	adrp	x8, 0x101b1e000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x17014>
1014313bc: 9112a108    	add	x8, x8, #0x4a8
1014313c0: 52800089    	mov	w9, #0x4                ; =4
1014313c4: a933a3b6    	stp	x22, x8, [x29, #-0xc8]
1014313c8: f81483a9    	stur	x9, [x29, #-0xb8]
1014313cc: d10303a8    	sub	x8, x29, #0xc0
1014313d0: d00000e9    	adrp	x9, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
1014313d4: 91117129    	add	x9, x9, #0x45c
1014313d8: a91e27e8    	stp	x8, x9, [sp, #0x1e0]
1014313dc: 90004de0    	adrp	x0, 0x101ded000 <_writev+0x101ded000>
1014313e0: 912fec00    	add	x0, x0, #0xbfb
1014313e4: 910783e1    	add	x1, sp, #0x1e0
1014313e8: a9445ff9    	ldp	x25, x23, [sp, #0x40]
1014313ec: f9401ff6    	ldr	x22, [sp, #0x38]
1014313f0: 9417dd52    	bl	0x101a28938 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x214>
1014313f4: 17fffd21    	b	0x101430878 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19fc>
1014313f8: f94037e8    	ldr	x8, [sp, #0x68]
1014313fc: a9186fe8    	stp	x8, x27, [sp, #0x180]
101431400: f900cbf5    	str	x21, [sp, #0x190]
101431404: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101431408: f9016be9    	str	x9, [sp, #0x2d0]
10143140c: f9016fe8    	str	x8, [sp, #0x2d8]
101431410: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101431414: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101431418: f81203b9    	stur	x25, [x29, #-0xe0]
10143141c: d0004568    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101431420: 9125f108    	add	x8, x8, #0x97c
101431424: 52800169    	mov	w9, #0xb                ; =11
101431428: a933a3b6    	stp	x22, x8, [x29, #-0xc8]
10143142c: f81483a9    	stur	x9, [x29, #-0xb8]
101431430: d10303a8    	sub	x8, x29, #0xc0
101431434: d00000e9    	adrp	x9, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101431438: 91117129    	add	x9, x9, #0x45c
10143143c: a91e27e8    	stp	x8, x9, [sp, #0x1e0]
101431440: 90004de0    	adrp	x0, 0x101ded000 <_writev+0x101ded000>
101431444: 912fec00    	add	x0, x0, #0xbfb
101431448: 910783e1    	add	x1, sp, #0x1e0
10143144c: a9445ff9    	ldp	x25, x23, [sp, #0x40]
101431450: f9401ff6    	ldr	x22, [sp, #0x38]
101431454: 9417dd39    	bl	0x101a28938 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x214>
101431458: 17fffd08    	b	0x101430878 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19fc>
10143145c: f94037e8    	ldr	x8, [sp, #0x68]
101431460: a9186fe8    	stp	x8, x27, [sp, #0x180]
101431464: f900cbf5    	str	x21, [sp, #0x190]
101431468: a942a3e9    	ldp	x9, x8, [sp, #0x28]
10143146c: f9016be9    	str	x9, [sp, #0x2d0]
101431470: f9016fe8    	str	x8, [sp, #0x2d8]
101431474: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101431478: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
10143147c: f81203b9    	stur	x25, [x29, #-0xe0]
101431480: d0004568    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101431484: 91267108    	add	x8, x8, #0x99c
101431488: 52800169    	mov	w9, #0xb                ; =11
10143148c: a933a3b6    	stp	x22, x8, [x29, #-0xc8]
101431490: f81483a9    	stur	x9, [x29, #-0xb8]
101431494: d10303a8    	sub	x8, x29, #0xc0
101431498: d00000e9    	adrp	x9, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
10143149c: 91117129    	add	x9, x9, #0x45c
1014314a0: a91e27e8    	stp	x8, x9, [sp, #0x1e0]
1014314a4: 90004de0    	adrp	x0, 0x101ded000 <_writev+0x101ded000>
1014314a8: 912fec00    	add	x0, x0, #0xbfb
1014314ac: 910783e1    	add	x1, sp, #0x1e0
1014314b0: a9445ff9    	ldp	x25, x23, [sp, #0x40]
1014314b4: aa0a03f6    	mov	x22, x10
1014314b8: 9417dd20    	bl	0x101a28938 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x214>
1014314bc: 17fffcef    	b	0x101430878 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19fc>
1014314c0: f94037e8    	ldr	x8, [sp, #0x68]
1014314c4: a9186fe8    	stp	x8, x27, [sp, #0x180]
1014314c8: f900cbf5    	str	x21, [sp, #0x190]
1014314cc: a942a3e9    	ldp	x9, x8, [sp, #0x28]
1014314d0: f9016be9    	str	x9, [sp, #0x2d0]
1014314d4: f9016fe8    	str	x8, [sp, #0x2d8]
1014314d8: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
1014314dc: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
1014314e0: f81203b9    	stur	x25, [x29, #-0xe0]
1014314e4: b0003768    	adrp	x8, 0x101b1e000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x17014>
1014314e8: 910f4108    	add	x8, x8, #0x3d0
1014314ec: 52800089    	mov	w9, #0x4                ; =4
1014314f0: a933a3b6    	stp	x22, x8, [x29, #-0xc8]
1014314f4: f81483a9    	stur	x9, [x29, #-0xb8]
1014314f8: d10303a8    	sub	x8, x29, #0xc0
1014314fc: d00000e9    	adrp	x9, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101431500: 91117129    	add	x9, x9, #0x45c
101431504: a91e27e8    	stp	x8, x9, [sp, #0x1e0]
101431508: 90004de0    	adrp	x0, 0x101ded000 <_writev+0x101ded000>
10143150c: 912fec00    	add	x0, x0, #0xbfb
101431510: 910783e1    	add	x1, sp, #0x1e0
101431514: a9445ff9    	ldp	x25, x23, [sp, #0x40]
101431518: f9401ff6    	ldr	x22, [sp, #0x38]
10143151c: 9417dd07    	bl	0x101a28938 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x214>
101431520: 17fffcd6    	b	0x101430878 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19fc>
101431524: f94037e8    	ldr	x8, [sp, #0x68]
101431528: a9186fe8    	stp	x8, x27, [sp, #0x180]
10143152c: f900cbf5    	str	x21, [sp, #0x190]
101431530: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101431534: f9016be9    	str	x9, [sp, #0x2d0]
101431538: f9016fe8    	str	x8, [sp, #0x2d8]
10143153c: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101431540: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101431544: f81203b9    	stur	x25, [x29, #-0xe0]
101431548: d0004568    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
10143154c: 91265508    	add	x8, x8, #0x995
101431550: 528000e9    	mov	w9, #0x7                ; =7
101431554: a933a3b6    	stp	x22, x8, [x29, #-0xc8]
101431558: f81483a9    	stur	x9, [x29, #-0xb8]
10143155c: d10303a8    	sub	x8, x29, #0xc0
101431560: d00000e9    	adrp	x9, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101431564: 91117129    	add	x9, x9, #0x45c
101431568: a91e27e8    	stp	x8, x9, [sp, #0x1e0]
10143156c: 90004de0    	adrp	x0, 0x101ded000 <_writev+0x101ded000>
101431570: 912fec00    	add	x0, x0, #0xbfb
101431574: 910783e1    	add	x1, sp, #0x1e0
101431578: aa0a03f7    	mov	x23, x10
10143157c: a943e7f6    	ldp	x22, x25, [sp, #0x38]
101431580: 9417dcee    	bl	0x101a28938 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x214>
101431584: 17fffcbd    	b	0x101430878 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19fc>
101431588: f94037e8    	ldr	x8, [sp, #0x68]
10143158c: a9186fe8    	stp	x8, x27, [sp, #0x180]
101431590: f900cbf5    	str	x21, [sp, #0x190]
101431594: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101431598: f9016be9    	str	x9, [sp, #0x2d0]
10143159c: f9016fe8    	str	x8, [sp, #0x2d8]
1014315a0: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
1014315a4: f81383b6    	stur	x22, [x29, #-0xc8]
1014315a8: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
1014315ac: f81203b9    	stur	x25, [x29, #-0xe0]
1014315b0: 528000c8    	mov	w8, #0x6                ; =6
1014315b4: b24107f7    	mov	x23, #-0x7fffffffffffffff ; =-9223372036854775807
1014315b8: f900f3e8    	str	x8, [sp, #0x1e0]
1014315bc: 910783e1    	add	x1, sp, #0x1e0
1014315c0: aa1a03e0    	mov	x0, x26
1014315c4: a943e7f6    	ldp	x22, x25, [sp, #0x38]
1014315c8: 941976d8    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
1014315cc: 17fffcab    	b	0x101430878 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19fc>
1014315d0: f94037e8    	ldr	x8, [sp, #0x68]
1014315d4: a9186fe8    	stp	x8, x27, [sp, #0x180]
1014315d8: f900cbf5    	str	x21, [sp, #0x190]
1014315dc: a942a3e9    	ldp	x9, x8, [sp, #0x28]
1014315e0: f9016be9    	str	x9, [sp, #0x2d0]
1014315e4: f9016fe8    	str	x8, [sp, #0x2d8]
1014315e8: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
1014315ec: f81383b6    	stur	x22, [x29, #-0xc8]
1014315f0: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
1014315f4: f81203b9    	stur	x25, [x29, #-0xe0]
1014315f8: 528000c8    	mov	w8, #0x6                ; =6
1014315fc: b24107f9    	mov	x25, #-0x7fffffffffffffff ; =-9223372036854775807
101431600: f900f3e8    	str	x8, [sp, #0x1e0]
101431604: 910783e1    	add	x1, sp, #0x1e0
101431608: aa1a03e0    	mov	x0, x26
10143160c: f94027f7    	ldr	x23, [sp, #0x48]
101431610: f9401ff6    	ldr	x22, [sp, #0x38]
101431614: 941976c5    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
101431618: 17fffc5b    	b	0x101430784 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1908>
10143161c: f94037e8    	ldr	x8, [sp, #0x68]
101431620: a9186fe8    	stp	x8, x27, [sp, #0x180]
101431624: f900cbf5    	str	x21, [sp, #0x190]
101431628: a942a3e9    	ldp	x9, x8, [sp, #0x28]
10143162c: f9016be9    	str	x9, [sp, #0x2d0]
101431630: f9016fe8    	str	x8, [sp, #0x2d8]
101431634: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101431638: f81383b6    	stur	x22, [x29, #-0xc8]
10143163c: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101431640: f81203b9    	stur	x25, [x29, #-0xe0]
101431644: 528000c8    	mov	w8, #0x6                ; =6
101431648: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
10143164c: f9002be9    	str	x9, [sp, #0x50]
101431650: f900f3e8    	str	x8, [sp, #0x1e0]
101431654: 910783e1    	add	x1, sp, #0x1e0
101431658: aa1a03e0    	mov	x0, x26
10143165c: a9445ff9    	ldp	x25, x23, [sp, #0x40]
101431660: f9401ff6    	ldr	x22, [sp, #0x38]
101431664: 941976b1    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
101431668: 17fffc6e    	b	0x101430820 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19a4>
10143166c: f94037e8    	ldr	x8, [sp, #0x68]
101431670: a9186fe8    	stp	x8, x27, [sp, #0x180]
101431674: f900cbf5    	str	x21, [sp, #0x190]
101431678: a942a3e9    	ldp	x9, x8, [sp, #0x28]
10143167c: f9016be9    	str	x9, [sp, #0x2d0]
101431680: f9016fe8    	str	x8, [sp, #0x2d8]
101431684: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101431688: f81383b6    	stur	x22, [x29, #-0xc8]
10143168c: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101431690: f81203b9    	stur	x25, [x29, #-0xe0]
101431694: 528000c8    	mov	w8, #0x6                ; =6
101431698: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
10143169c: f9002fe9    	str	x9, [sp, #0x58]
1014316a0: f900f3e8    	str	x8, [sp, #0x1e0]
1014316a4: 910783e1    	add	x1, sp, #0x1e0
1014316a8: aa1a03e0    	mov	x0, x26
1014316ac: a9445ff9    	ldp	x25, x23, [sp, #0x40]
1014316b0: f9401ff6    	ldr	x22, [sp, #0x38]
1014316b4: 9419769d    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
1014316b8: 17fffc1c    	b	0x101430728 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x18ac>
1014316bc: f94037e8    	ldr	x8, [sp, #0x68]
1014316c0: a9186fe8    	stp	x8, x27, [sp, #0x180]
1014316c4: f900cbf5    	str	x21, [sp, #0x190]
1014316c8: a942a3e9    	ldp	x9, x8, [sp, #0x28]
1014316cc: f9016be9    	str	x9, [sp, #0x2d0]
1014316d0: f9016fe8    	str	x8, [sp, #0x2d8]
1014316d4: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
1014316d8: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
1014316dc: f81203b9    	stur	x25, [x29, #-0xe0]
1014316e0: 528000c8    	mov	w8, #0x6                ; =6
1014316e4: 528000a9    	mov	w9, #0x5                ; =5
1014316e8: f90033e9    	str	x9, [sp, #0x60]
1014316ec: a933a3b6    	stp	x22, x8, [x29, #-0xc8]
1014316f0: d10303a1    	sub	x1, x29, #0xc0
1014316f4: aa1a03e0    	mov	x0, x26
1014316f8: a9445ff9    	ldp	x25, x23, [sp, #0x40]
1014316fc: f9401ff6    	ldr	x22, [sp, #0x38]
101431700: 9419768a    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
101431704: 17fffc71    	b	0x1014308c8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x1a4c>
101431708: f94037e8    	ldr	x8, [sp, #0x68]
10143170c: a9186fe8    	stp	x8, x27, [sp, #0x180]
101431710: f900cbf5    	str	x21, [sp, #0x190]
101431714: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101431718: f9016be9    	str	x9, [sp, #0x2d0]
10143171c: f9016fe8    	str	x8, [sp, #0x2d8]
101431720: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
101431724: f81383b6    	stur	x22, [x29, #-0xc8]
101431728: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
10143172c: f81203b9    	stur	x25, [x29, #-0xe0]
101431730: 528000c8    	mov	w8, #0x6                ; =6
101431734: b24107f6    	mov	x22, #-0x7fffffffffffffff ; =-9223372036854775807
101431738: f900f3e8    	str	x8, [sp, #0x1e0]
10143173c: 910783e1    	add	x1, sp, #0x1e0
101431740: aa1a03e0    	mov	x0, x26
101431744: a9445ff9    	ldp	x25, x23, [sp, #0x40]
101431748: 94197678    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
10143174c: 17fffc4b    	b	0x101430878 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19fc>
101431750: f94037e8    	ldr	x8, [sp, #0x68]
101431754: a9186fe8    	stp	x8, x27, [sp, #0x180]
101431758: f900cbf5    	str	x21, [sp, #0x190]
10143175c: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101431760: f9016be9    	str	x9, [sp, #0x2d0]
101431764: f9016fe8    	str	x8, [sp, #0x2d8]
101431768: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
10143176c: f81383b6    	stur	x22, [x29, #-0xc8]
101431770: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101431774: f81203b9    	stur	x25, [x29, #-0xe0]
101431778: 52800128    	mov	w8, #0x9                ; =9
10143177c: b24107f6    	mov	x22, #-0x7fffffffffffffff ; =-9223372036854775807
101431780: f900f3e8    	str	x8, [sp, #0x1e0]
101431784: 910783e1    	add	x1, sp, #0x1e0
101431788: aa1a03e0    	mov	x0, x26
10143178c: a9445ff9    	ldp	x25, x23, [sp, #0x40]
101431790: 94197823    	bl	0x101a8f81c <__ZN10serde_json2de21Deserializer$LT$R$GT$23parse_exponent_overflow17h8d2c34d8b104f113E+0x90>
101431794: 17fffc39    	b	0x101430878 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x19fc>
101431798: aa0003f4    	mov	x20, x0
10143179c: 910b43e0    	add	x0, sp, #0x2d0
1014317a0: 94008096    	bl	0x1014519f8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x4570>
1014317a4: 14000002    	b	0x1014317ac <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2930>
1014317a8: aa0003f4    	mov	x20, x0
1014317ac: d10363a0    	sub	x0, x29, #0xd8
1014317b0: 94007c3b    	bl	0x10145089c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x3414>
1014317b4: 14000003    	b	0x1014317c0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2944>
1014317b8: b9006bfc    	str	w28, [sp, #0x68]
1014317bc: aa0003f4    	mov	x20, x0
1014317c0: b9406be8    	ldr	w8, [sp, #0x68]
1014317c4: 370000c8    	tbnz	w8, #0x0, 0x1014317dc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2960>
1014317c8: d103c3a0    	sub	x0, x29, #0xf0
1014317cc: 940091c1    	bl	0x101455ed0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8a48>
1014317d0: 14000003    	b	0x1014317dc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2960>
1014317d4: 941a4954    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014317d8: aa0003f4    	mov	x20, x0
1014317dc: f240fb1f    	tst	x24, #0x7fffffffffffffff
1014317e0: 540001a0    	b.eq	0x101431814 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2998>
1014317e4: aa1703e0    	mov	x0, x23
1014317e8: aa1803e1    	mov	x1, x24
1014317ec: 52800022    	mov	w2, #0x1                ; =1
1014317f0: 97d9b3bb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014317f4: 14000008    	b	0x101431814 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2998>
1014317f8: 14000001    	b	0x1014317fc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2980>
1014317fc: aa0003f4    	mov	x20, x0
101431800: aa1603e0    	mov	x0, x22
101431804: 52800501    	mov	w1, #0x28               ; =40
101431808: 52800102    	mov	w2, #0x8                ; =8
10143180c: 1400005b    	b	0x101431978 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2afc>
101431810: aa0003f4    	mov	x20, x0
101431814: f240fabf    	tst	x21, #0x7fffffffffffffff
101431818: 54000b20    	b.eq	0x10143197c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2b00>
10143181c: aa1603e0    	mov	x0, x22
101431820: aa1503e1    	mov	x1, x21
101431824: 14000054    	b	0x101431974 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2af8>
101431828: a903e7f6    	stp	x22, x25, [sp, #0x38]
10143182c: f90027f7    	str	x23, [sp, #0x48]
101431830: aa0003f4    	mov	x20, x0
101431834: 14000015    	b	0x101431888 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2a0c>
101431838: aa0003f4    	mov	x20, x0
10143183c: 910b43e0    	add	x0, sp, #0x2d0
101431840: 94007eb9    	bl	0x101451324 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x3e9c>
101431844: 1400004e    	b	0x10143197c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2b00>
101431848: aa0003f4    	mov	x20, x0
10143184c: 910b43e0    	add	x0, sp, #0x2d0
101431850: 94007eb5    	bl	0x101451324 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x3e9c>
101431854: 1400004a    	b	0x10143197c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2b00>
101431858: 941a4933    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
10143185c: aa0003f4    	mov	x20, x0
101431860: f94037e8    	ldr	x8, [sp, #0x68]
101431864: a9186fe8    	stp	x8, x27, [sp, #0x180]
101431868: f900cbf5    	str	x21, [sp, #0x190]
10143186c: a942a3e9    	ldp	x9, x8, [sp, #0x28]
101431870: f9016be9    	str	x9, [sp, #0x2d0]
101431874: f9016fe8    	str	x8, [sp, #0x2d8]
101431878: a932e3b3    	stp	x19, x24, [x29, #-0xd8]
10143187c: f81383b6    	stur	x22, [x29, #-0xc8]
101431880: a9315fbc    	stp	x28, x23, [x29, #-0xf0]
101431884: f81203b9    	stur	x25, [x29, #-0xe0]
101431888: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10143188c: f94023e9    	ldr	x9, [sp, #0x40]
101431890: eb08013f    	cmp	x9, x8
101431894: 54000060    	b.eq	0x1014318a0 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2a24>
101431898: 910603e0    	add	x0, sp, #0x180
10143189c: 97d467a5    	bl	0x10094b730 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x38708>
1014318a0: f94033e8    	ldr	x8, [sp, #0x60]
1014318a4: f100151f    	cmp	x8, #0x5
1014318a8: 54000060    	b.eq	0x1014318b4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2a38>
1014318ac: 910b43e0    	add	x0, sp, #0x2d0
1014318b0: 94008052    	bl	0x1014519f8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x4570>
1014318b4: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
1014318b8: f94027e9    	ldr	x9, [sp, #0x48]
1014318bc: eb08013f    	cmp	x9, x8
1014318c0: 54000060    	b.eq	0x1014318cc <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2a50>
1014318c4: d10363a0    	sub	x0, x29, #0xd8
1014318c8: 94007bf5    	bl	0x10145089c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x3414>
1014318cc: d2800048    	mov	x8, #0x2                ; =2
1014318d0: f2f00008    	movk	x8, #0x8000, lsl #48
1014318d4: f9401fe9    	ldr	x9, [sp, #0x38]
1014318d8: eb08013f    	cmp	x9, x8
1014318dc: 5400028b    	b.lt	0x10143192c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2ab0>
1014318e0: d103c3a0    	sub	x0, x29, #0xf0
1014318e4: 9400917b    	bl	0x101455ed0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8a48>
1014318e8: 14000011    	b	0x10143192c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2ab0>
1014318ec: 941a490e    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014318f0: aa1603f8    	mov	x24, x22
1014318f4: aa0003f4    	mov	x20, x0
1014318f8: f1000673    	subs	x19, x19, #0x1
1014318fc: 540000c0    	b.eq	0x101431914 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2a98>
101431900: 91038375    	add	x21, x27, #0xe0
101431904: aa1b03e0    	mov	x0, x27
101431908: 94008b9c    	bl	0x101454778 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x72f0>
10143190c: aa1503fb    	mov	x27, x21
101431910: 17fffffa    	b	0x1014318f8 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2a7c>
101431914: b40000d8    	cbz	x24, 0x10143192c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2ab0>
101431918: d378df08    	lsl	x8, x24, #8
10143191c: cb181501    	sub	x1, x8, x24, lsl #5
101431920: aa1a03e0    	mov	x0, x26
101431924: 52800102    	mov	w2, #0x8                ; =8
101431928: 97d9b36d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143192c: d2800053    	mov	x19, #0x2               ; =2
101431930: f2f00013    	movk	x19, #0x8000, lsl #48
101431934: f9402be8    	ldr	x8, [sp, #0x50]
101431938: eb13011f    	cmp	x8, x19
10143193c: 540000eb    	b.lt	0x101431958 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2adc>
101431940: f9402be8    	ldr	x8, [sp, #0x50]
101431944: b40000a8    	cbz	x8, 0x101431958 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2adc>
101431948: f9400be0    	ldr	x0, [sp, #0x10]
10143194c: f9402be1    	ldr	x1, [sp, #0x50]
101431950: 52800022    	mov	w2, #0x1                ; =1
101431954: 97d9b362    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431958: f9402fe8    	ldr	x8, [sp, #0x58]
10143195c: eb13011f    	cmp	x8, x19
101431960: 540000eb    	b.lt	0x10143197c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2b00>
101431964: f9402fe8    	ldr	x8, [sp, #0x58]
101431968: b40000a8    	cbz	x8, 0x10143197c <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0x2b00>
10143196c: f9400fe0    	ldr	x0, [sp, #0x18]
101431970: f9402fe1    	ldr	x1, [sp, #0x58]
101431974: 52800022    	mov	w2, #0x1                ; =1
101431978: 97d9b359    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143197c: aa1403e0    	mov	x0, x20
101431980: 941a5f15    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101431984: 941a48e8    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>

0000000101431988 <__ZN17otty_autocomplete5paths12user_data_db17hddf6880288196dbdE>:
101431988: d10103ff    	sub	sp, sp, #0x40
10143198c: a9024ff4    	stp	x20, x19, [sp, #0x20]
101431990: a9037bfd    	stp	x29, x30, [sp, #0x30]
101431994: 9100c3fd    	add	x29, sp, #0x30
101431998: aa0803f4    	mov	x20, x8
10143199c: 910023e8    	add	x8, sp, #0x8
1014319a0: 9400003e    	bl	0x101431a98 <__ZN17otty_autocomplete5paths15app_support_dir17hf0f36c52dec0652bE>
1014319a4: a94107f3    	ldp	x19, x1, [sp, #0x10]
1014319a8: 90004582    	adrp	x2, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
1014319ac: 9125d442    	add	x2, x2, #0x975
1014319b0: aa1403e8    	mov	x8, x20
1014319b4: aa1303e0    	mov	x0, x19
1014319b8: 52800183    	mov	w3, #0xc                ; =12
1014319bc: 940e4a38    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
1014319c0: f94007e1    	ldr	x1, [sp, #0x8]
1014319c4: b40000e1    	cbz	x1, 0x1014319e0 <__ZN17otty_autocomplete5paths12user_data_db17hddf6880288196dbdE+0x58>
1014319c8: aa1303e0    	mov	x0, x19
1014319cc: 52800022    	mov	w2, #0x1                ; =1
1014319d0: a9437bfd    	ldp	x29, x30, [sp, #0x30]
1014319d4: a9424ff4    	ldp	x20, x19, [sp, #0x20]
1014319d8: 910103ff    	add	sp, sp, #0x40
1014319dc: 17d9b340    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014319e0: a9437bfd    	ldp	x29, x30, [sp, #0x30]
1014319e4: a9424ff4    	ldp	x20, x19, [sp, #0x20]
1014319e8: 910103ff    	add	sp, sp, #0x40
1014319ec: d65f03c0    	ret
1014319f0: aa0003f4    	mov	x20, x0
1014319f4: f94007e1    	ldr	x1, [sp, #0x8]
1014319f8: b4000081    	cbz	x1, 0x101431a08 <__ZN17otty_autocomplete5paths12user_data_db17hddf6880288196dbdE+0x80>
1014319fc: aa1303e0    	mov	x0, x19
101431a00: 52800022    	mov	w2, #0x1                ; =1
101431a04: 97d9b336    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431a08: aa1403e0    	mov	x0, x20
101431a0c: 941a5ef2    	bl	0x101ac95d4 <_writev+0x101ac95d4>

0000000101431a10 <__ZN17otty_autocomplete5paths14completions_db17h4e644097f1fd8ed1E>:
101431a10: d10103ff    	sub	sp, sp, #0x40
101431a14: a9024ff4    	stp	x20, x19, [sp, #0x20]
101431a18: a9037bfd    	stp	x29, x30, [sp, #0x30]
101431a1c: 9100c3fd    	add	x29, sp, #0x30
101431a20: aa0803f4    	mov	x20, x8
101431a24: 910023e8    	add	x8, sp, #0x8
101431a28: 9400001c    	bl	0x101431a98 <__ZN17otty_autocomplete5paths15app_support_dir17hf0f36c52dec0652bE>
101431a2c: a94107f3    	ldp	x19, x1, [sp, #0x10]
101431a30: 90004582    	adrp	x2, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101431a34: 91260442    	add	x2, x2, #0x981
101431a38: aa1403e8    	mov	x8, x20
101431a3c: aa1303e0    	mov	x0, x19
101431a40: 528001c3    	mov	w3, #0xe                ; =14
101431a44: 940e4a16    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101431a48: f94007e1    	ldr	x1, [sp, #0x8]
101431a4c: b40000e1    	cbz	x1, 0x101431a68 <__ZN17otty_autocomplete5paths14completions_db17h4e644097f1fd8ed1E+0x58>
101431a50: aa1303e0    	mov	x0, x19
101431a54: 52800022    	mov	w2, #0x1                ; =1
101431a58: a9437bfd    	ldp	x29, x30, [sp, #0x30]
101431a5c: a9424ff4    	ldp	x20, x19, [sp, #0x20]
101431a60: 910103ff    	add	sp, sp, #0x40
101431a64: 17d9b31e    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431a68: a9437bfd    	ldp	x29, x30, [sp, #0x30]
101431a6c: a9424ff4    	ldp	x20, x19, [sp, #0x20]
101431a70: 910103ff    	add	sp, sp, #0x40
101431a74: d65f03c0    	ret
101431a78: aa0003f4    	mov	x20, x0
101431a7c: f94007e1    	ldr	x1, [sp, #0x8]
101431a80: b4000081    	cbz	x1, 0x101431a90 <__ZN17otty_autocomplete5paths14completions_db17h4e644097f1fd8ed1E+0x80>
101431a84: aa1303e0    	mov	x0, x19
101431a88: 52800022    	mov	w2, #0x1                ; =1
101431a8c: 97d9b314    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431a90: aa1403e0    	mov	x0, x20
101431a94: 941a5ed0    	bl	0x101ac95d4 <_writev+0x101ac95d4>

0000000101431a98 <__ZN17otty_autocomplete5paths15app_support_dir17hf0f36c52dec0652bE>:
101431a98: d10183ff    	sub	sp, sp, #0x60
101431a9c: a9025ff8    	stp	x24, x23, [sp, #0x20]
101431aa0: a90357f6    	stp	x22, x21, [sp, #0x30]
101431aa4: a9044ff4    	stp	x20, x19, [sp, #0x40]
101431aa8: a9057bfd    	stp	x29, x30, [sp, #0x50]
101431aac: 910143fd    	add	x29, sp, #0x50
101431ab0: aa0803f4    	mov	x20, x8
101431ab4: 910003e8    	mov	x8, sp
101431ab8: 9405a612    	bl	0x10159b300 <__ZN11otty_config6Config15app_support_dir17h7e5345c1919e313bE>
101431abc: 52803fe8    	mov	w8, #0x1ff              ; =511
101431ac0: 79003be8    	strh	w8, [sp, #0x1c]
101431ac4: 52800028    	mov	w8, #0x1                ; =1
101431ac8: 39007be8    	strb	w8, [sp, #0x1e]
101431acc: a9408bf3    	ldp	x19, x2, [sp, #0x8]
101431ad0: 910073e0    	add	x0, sp, #0x1c
101431ad4: aa1303e1    	mov	x1, x19
101431ad8: 940dfa97    	bl	0x1017b0534 <__ZN3std2fs10DirBuilder7_create17h169d1d44c8cfed7fE>
101431adc: aa0003f5    	mov	x21, x0
101431ae0: 92400408    	and	x8, x0, #0x3
101431ae4: f100051f    	cmp	x8, #0x1
101431ae8: 54000160    	b.eq	0x101431b14 <__ZN17otty_autocomplete5paths15app_support_dir17hf0f36c52dec0652bE+0x7c>
101431aec: 3dc003e0    	ldr	q0, [sp]
101431af0: 3d800280    	str	q0, [x20]
101431af4: f9400be8    	ldr	x8, [sp, #0x10]
101431af8: f9000a88    	str	x8, [x20, #0x10]
101431afc: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101431b00: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101431b04: a94357f6    	ldp	x22, x21, [sp, #0x30]
101431b08: a9425ff8    	ldp	x24, x23, [sp, #0x20]
101431b0c: 910183ff    	add	sp, sp, #0x60
101431b10: d65f03c0    	ret
101431b14: f85ffeb6    	ldr	x22, [x21, #-0x1]!
101431b18: f94006b7    	ldr	x23, [x21, #0x8]
101431b1c: f94002e8    	ldr	x8, [x23]
101431b20: b4000068    	cbz	x8, 0x101431b2c <__ZN17otty_autocomplete5paths15app_support_dir17hf0f36c52dec0652bE+0x94>
101431b24: aa1603e0    	mov	x0, x22
101431b28: d63f0100    	blr	x8
101431b2c: f94006e1    	ldr	x1, [x23, #0x8]
101431b30: b4000081    	cbz	x1, 0x101431b40 <__ZN17otty_autocomplete5paths15app_support_dir17hf0f36c52dec0652bE+0xa8>
101431b34: f9400ae2    	ldr	x2, [x23, #0x10]
101431b38: aa1603e0    	mov	x0, x22
101431b3c: 97d9b2e8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431b40: aa1503e0    	mov	x0, x21
101431b44: 52800301    	mov	w1, #0x18               ; =24
101431b48: 52800102    	mov	w2, #0x8                ; =8
101431b4c: 97d9b2e4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431b50: 17ffffe7    	b	0x101431aec <__ZN17otty_autocomplete5paths15app_support_dir17hf0f36c52dec0652bE+0x54>
101431b54: aa0003f4    	mov	x20, x0
101431b58: f94006e1    	ldr	x1, [x23, #0x8]
101431b5c: b4000081    	cbz	x1, 0x101431b6c <__ZN17otty_autocomplete5paths15app_support_dir17hf0f36c52dec0652bE+0xd4>
101431b60: f9400ae2    	ldr	x2, [x23, #0x10]
101431b64: aa1603e0    	mov	x0, x22
101431b68: 97d9b2dd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431b6c: aa1503e0    	mov	x0, x21
101431b70: 52800301    	mov	w1, #0x18               ; =24
101431b74: 52800102    	mov	w2, #0x8                ; =8
101431b78: 97d9b2d9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431b7c: 14000002    	b	0x101431b84 <__ZN17otty_autocomplete5paths15app_support_dir17hf0f36c52dec0652bE+0xec>
101431b80: aa0003f4    	mov	x20, x0
101431b84: f94003e1    	ldr	x1, [sp]
101431b88: b4000081    	cbz	x1, 0x101431b98 <__ZN17otty_autocomplete5paths15app_support_dir17hf0f36c52dec0652bE+0x100>
101431b8c: aa1303e0    	mov	x0, x19
101431b90: 52800022    	mov	w2, #0x1                ; =1
101431b94: 97d9b2d2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431b98: aa1403e0    	mov	x0, x20
101431b9c: 941a5e8e    	bl	0x101ac95d4 <_writev+0x101ac95d4>

0000000101431ba0 <__ZN17otty_autocomplete5paths15shell_dump_file17hc7f94dc49010b61aE>:
101431ba0: d10243ff    	sub	sp, sp, #0x90
101431ba4: a9055ff8    	stp	x24, x23, [sp, #0x50]
101431ba8: a90657f6    	stp	x22, x21, [sp, #0x60]
101431bac: a9074ff4    	stp	x20, x19, [sp, #0x70]
101431bb0: a9087bfd    	stp	x29, x30, [sp, #0x80]
101431bb4: 910203fd    	add	x29, sp, #0x80
101431bb8: aa0803f5    	mov	x21, x8
101431bbc: a90007e0    	stp	x0, x1, [sp]
101431bc0: 90004580    	adrp	x0, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101431bc4: 91263c00    	add	x0, x0, #0x98f
101431bc8: 9100c3e8    	add	x8, sp, #0x30
101431bcc: 528000c1    	mov	w1, #0x6                ; =6
101431bd0: 940e0fe0    	bl	0x1017b5b50 <__ZN3std3env7_var_os17h289066a7989eb522E>
101431bd4: f9401bf3    	ldr	x19, [sp, #0x30]
101431bd8: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101431bdc: eb08027f    	cmp	x19, x8
101431be0: 540001a1    	b.ne	0x101431c14 <__ZN17otty_autocomplete5paths15shell_dump_file17hc7f94dc49010b61aE+0x74>
101431be4: 97d9b2c3    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101431be8: 52800080    	mov	w0, #0x4                ; =4
101431bec: 52800021    	mov	w1, #0x1                ; =1
101431bf0: 97d9b2ba    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101431bf4: b40006a0    	cbz	x0, 0x101431cc8 <__ZN17otty_autocomplete5paths15shell_dump_file17hc7f94dc49010b61aE+0x128>
101431bf8: aa0003f4    	mov	x20, x0
101431bfc: 528e85e8    	mov	w8, #0x742f             ; =29743
101431c00: 72ae0da8    	movk	w8, #0x706d, lsl #16
101431c04: b9000008    	str	w8, [x0]
101431c08: 52800093    	mov	w19, #0x4               ; =4
101431c0c: 52800096    	mov	w22, #0x4               ; =4
101431c10: 14000003    	b	0x101431c1c <__ZN17otty_autocomplete5paths15shell_dump_file17hc7f94dc49010b61aE+0x7c>
101431c14: a943dbf4    	ldp	x20, x22, [sp, #0x38]
101431c18: b40004d6    	cbz	x22, 0x101431cb0 <__ZN17otty_autocomplete5paths15shell_dump_file17hc7f94dc49010b61aE+0x110>
101431c1c: 941a5fc1    	bl	0x101ac9b20 <_writev+0x101ac9b20>
101431c20: b9002fe0    	str	w0, [sp, #0x2c]
101431c24: 910003e8    	mov	x8, sp
101431c28: d00000e9    	adrp	x9, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101431c2c: 91117129    	add	x9, x9, #0x45c
101431c30: a90327e8    	stp	x8, x9, [sp, #0x30]
101431c34: 9100b3e8    	add	x8, sp, #0x2c
101431c38: b0001f09    	adrp	x9, 0x101812000 <__ZN4core3fmt3num3imp21_$LT$impl$u20$u16$GT$4_fmt17h854634ad1f871bf4E+0x288>
101431c3c: 911e2129    	add	x9, x9, #0x788
101431c40: a90427e8    	stp	x8, x9, [sp, #0x40]
101431c44: b0004ee0    	adrp	x0, 0x101e0e000 <_writev+0x101e0e000>
101431c48: 910ec400    	add	x0, x0, #0x3b1
101431c4c: 910043e8    	add	x8, sp, #0x10
101431c50: 9100c3e1    	add	x1, sp, #0x30
101431c54: 940f664b    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
101431c58: a9418ff7    	ldp	x23, x3, [sp, #0x18]
101431c5c: aa1503e8    	mov	x8, x21
101431c60: aa1403e0    	mov	x0, x20
101431c64: aa1603e1    	mov	x1, x22
101431c68: aa1703e2    	mov	x2, x23
101431c6c: 940e498c    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101431c70: f9400be1    	ldr	x1, [sp, #0x10]
101431c74: b4000081    	cbz	x1, 0x101431c84 <__ZN17otty_autocomplete5paths15shell_dump_file17hc7f94dc49010b61aE+0xe4>
101431c78: aa1703e0    	mov	x0, x23
101431c7c: 52800022    	mov	w2, #0x1                ; =1
101431c80: 97d9b297    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431c84: b40000b3    	cbz	x19, 0x101431c98 <__ZN17otty_autocomplete5paths15shell_dump_file17hc7f94dc49010b61aE+0xf8>
101431c88: aa1403e0    	mov	x0, x20
101431c8c: aa1303e1    	mov	x1, x19
101431c90: 52800022    	mov	w2, #0x1                ; =1
101431c94: 97d9b292    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431c98: a9487bfd    	ldp	x29, x30, [sp, #0x80]
101431c9c: a9474ff4    	ldp	x20, x19, [sp, #0x70]
101431ca0: a94657f6    	ldp	x22, x21, [sp, #0x60]
101431ca4: a9455ff8    	ldp	x24, x23, [sp, #0x50]
101431ca8: 910243ff    	add	sp, sp, #0x90
101431cac: d65f03c0    	ret
101431cb0: b4fff9b3    	cbz	x19, 0x101431be4 <__ZN17otty_autocomplete5paths15shell_dump_file17hc7f94dc49010b61aE+0x44>
101431cb4: aa1403e0    	mov	x0, x20
101431cb8: aa1303e1    	mov	x1, x19
101431cbc: 52800022    	mov	w2, #0x1                ; =1
101431cc0: 97d9b287    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431cc4: 17ffffc8    	b	0x101431be4 <__ZN17otty_autocomplete5paths15shell_dump_file17hc7f94dc49010b61aE+0x44>
101431cc8: 52800020    	mov	w0, #0x1                ; =1
101431ccc: 52800081    	mov	w1, #0x4                ; =4
101431cd0: 941a45a9    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101431cd4: aa0003f5    	mov	x21, x0
101431cd8: f9400be1    	ldr	x1, [sp, #0x10]
101431cdc: b40000c1    	cbz	x1, 0x101431cf4 <__ZN17otty_autocomplete5paths15shell_dump_file17hc7f94dc49010b61aE+0x154>
101431ce0: aa1703e0    	mov	x0, x23
101431ce4: 52800022    	mov	w2, #0x1                ; =1
101431ce8: 97d9b27d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431cec: 14000002    	b	0x101431cf4 <__ZN17otty_autocomplete5paths15shell_dump_file17hc7f94dc49010b61aE+0x154>
101431cf0: aa0003f5    	mov	x21, x0
101431cf4: b40000b3    	cbz	x19, 0x101431d08 <__ZN17otty_autocomplete5paths15shell_dump_file17hc7f94dc49010b61aE+0x168>
101431cf8: aa1403e0    	mov	x0, x20
101431cfc: aa1303e1    	mov	x1, x19
101431d00: 52800022    	mov	w2, #0x1                ; =1
101431d04: 97d9b276    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431d08: aa1503e0    	mov	x0, x21
101431d0c: 941a5e32    	bl	0x101ac95d4 <_writev+0x101ac95d4>

0000000101431d10 <__ZN17otty_autocomplete5paths16runtime_dump_dir17hcf42c6cb0762b91dE>:
101431d10: d10103ff    	sub	sp, sp, #0x40
101431d14: a9024ff4    	stp	x20, x19, [sp, #0x20]
101431d18: a9037bfd    	stp	x29, x30, [sp, #0x30]
101431d1c: 9100c3fd    	add	x29, sp, #0x30
101431d20: aa0803f3    	mov	x19, x8
101431d24: 90004580    	adrp	x0, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101431d28: 91263c00    	add	x0, x0, #0x98f
101431d2c: 910023e8    	add	x8, sp, #0x8
101431d30: 528000c1    	mov	w1, #0x6                ; =6
101431d34: 940e0f87    	bl	0x1017b5b50 <__ZN3std3env7_var_os17h289066a7989eb522E>
101431d38: f94007e1    	ldr	x1, [sp, #0x8]
101431d3c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101431d40: eb08003f    	cmp	x1, x8
101431d44: 54000181    	b.ne	0x101431d74 <__ZN17otty_autocomplete5paths16runtime_dump_dir17hcf42c6cb0762b91dE+0x64>
101431d48: 97d9b26a    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101431d4c: 52800080    	mov	w0, #0x4                ; =4
101431d50: 52800021    	mov	w1, #0x1                ; =1
101431d54: 97d9b261    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101431d58: b4000260    	cbz	x0, 0x101431da4 <__ZN17otty_autocomplete5paths16runtime_dump_dir17hcf42c6cb0762b91dE+0x94>
101431d5c: 528e85e8    	mov	w8, #0x742f             ; =29743
101431d60: 72ae0da8    	movk	w8, #0x706d, lsl #16
101431d64: b9000008    	str	w8, [x0]
101431d68: 52800081    	mov	w1, #0x4                ; =4
101431d6c: 52800088    	mov	w8, #0x4                ; =4
101431d70: 14000003    	b	0x101431d7c <__ZN17otty_autocomplete5paths16runtime_dump_dir17hcf42c6cb0762b91dE+0x6c>
101431d74: a94123e0    	ldp	x0, x8, [sp, #0x10]
101431d78: b40000e8    	cbz	x8, 0x101431d94 <__ZN17otty_autocomplete5paths16runtime_dump_dir17hcf42c6cb0762b91dE+0x84>
101431d7c: a9000261    	stp	x1, x0, [x19]
101431d80: f9000a68    	str	x8, [x19, #0x10]
101431d84: a9437bfd    	ldp	x29, x30, [sp, #0x30]
101431d88: a9424ff4    	ldp	x20, x19, [sp, #0x20]
101431d8c: 910103ff    	add	sp, sp, #0x40
101431d90: d65f03c0    	ret
101431d94: b4fffda1    	cbz	x1, 0x101431d48 <__ZN17otty_autocomplete5paths16runtime_dump_dir17hcf42c6cb0762b91dE+0x38>
101431d98: 52800022    	mov	w2, #0x1                ; =1
101431d9c: 97d9b250    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431da0: 17ffffea    	b	0x101431d48 <__ZN17otty_autocomplete5paths16runtime_dump_dir17hcf42c6cb0762b91dE+0x38>
101431da4: 52800020    	mov	w0, #0x1                ; =1
101431da8: 52800081    	mov	w1, #0x4                ; =4
101431dac: 941a4572    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>

0000000101431db0 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE>:
101431db0: d102c3ff    	sub	sp, sp, #0xb0
101431db4: a9056ffc    	stp	x28, x27, [sp, #0x50]
101431db8: a90667fa    	stp	x26, x25, [sp, #0x60]
101431dbc: a9075ff8    	stp	x24, x23, [sp, #0x70]
101431dc0: a90857f6    	stp	x22, x21, [sp, #0x80]
101431dc4: a9094ff4    	stp	x20, x19, [sp, #0x90]
101431dc8: a90a7bfd    	stp	x29, x30, [sp, #0xa0]
101431dcc: 910283fd    	add	x29, sp, #0xa0
101431dd0: aa0803f5    	mov	x21, x8
101431dd4: 90004580    	adrp	x0, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101431dd8: 91265400    	add	x0, x0, #0x995
101431ddc: 9100c3e8    	add	x8, sp, #0x30
101431de0: 52800261    	mov	w1, #0x13               ; =19
101431de4: 940e0f5b    	bl	0x1017b5b50 <__ZN3std3env7_var_os17h289066a7989eb522E>
101431de8: f9401bf3    	ldr	x19, [sp, #0x30]
101431dec: d2f00014    	mov	x20, #-0x8000000000000000 ; =-9223372036854775808
101431df0: eb14027f    	cmp	x19, x20
101431df4: 540003a1    	b.ne	0x101431e68 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0xb8>
101431df8: 9100c3e8    	add	x8, sp, #0x30
101431dfc: 940e0efa    	bl	0x1017b59e4 <__ZN3std3env11current_exe17h77452ccd7be87975E>
101431e00: f9401bf8    	ldr	x24, [sp, #0x30]
101431e04: eb14031f    	cmp	x24, x20
101431e08: 54000401    	b.ne	0x101431e88 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0xd8>
101431e0c: f9401ff4    	ldr	x20, [sp, #0x38]
101431e10: 92400688    	and	x8, x20, #0x3
101431e14: f100051f    	cmp	x8, #0x1
101431e18: 54000201    	b.ne	0x101431e58 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0xa8>
101431e1c: f85ffe96    	ldr	x22, [x20, #-0x1]!
101431e20: f9400693    	ldr	x19, [x20, #0x8]
101431e24: f9400268    	ldr	x8, [x19]
101431e28: b4000068    	cbz	x8, 0x101431e34 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x84>
101431e2c: aa1603e0    	mov	x0, x22
101431e30: d63f0100    	blr	x8
101431e34: f9400661    	ldr	x1, [x19, #0x8]
101431e38: b4000081    	cbz	x1, 0x101431e48 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x98>
101431e3c: f9400a62    	ldr	x2, [x19, #0x10]
101431e40: aa1603e0    	mov	x0, x22
101431e44: 97d9b226    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431e48: aa1403e0    	mov	x0, x20
101431e4c: 52800301    	mov	w1, #0x18               ; =24
101431e50: 52800102    	mov	w2, #0x8                ; =8
101431e54: 97d9b222    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101431e58: 52800108    	mov	w8, #0x8                ; =8
101431e5c: a901a3ff    	stp	xzr, x8, [sp, #0x18]
101431e60: f90017ff    	str	xzr, [sp, #0x28]
101431e64: 14000054    	b	0x101431fb4 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x204>
101431e68: a943dbf4    	ldp	x20, x22, [sp, #0x38]
101431e6c: aa1403e0    	mov	x0, x20
101431e70: aa1603e1    	mov	x1, x22
101431e74: 940e49fa    	bl	0x1017c465c <__ZN3std4path4Path7is_file17hb9783ece3b71780eE>
101431e78: 36001440    	tbz	w0, #0x0, 0x101432100 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x350>
101431e7c: a90052b3    	stp	x19, x20, [x21]
101431e80: f9000ab6    	str	x22, [x21, #0x10]
101431e84: 140000cd    	b	0x1014321b8 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x408>
101431e88: a94387f3    	ldp	x19, x1, [sp, #0x38]
101431e8c: aa1303e0    	mov	x0, x19
101431e90: f90007f3    	str	x19, [sp, #0x8]
101431e94: 940e49d5    	bl	0x1017c45e8 <__ZN3std4path4Path6parent17h81615573672c555dE>
101431e98: aa0003f6    	mov	x22, x0
101431e9c: 52800108    	mov	w8, #0x8                ; =8
101431ea0: a901a3ff    	stp	xzr, x8, [sp, #0x18]
101431ea4: f90017ff    	str	xzr, [sp, #0x28]
101431ea8: b4000860    	cbz	x0, 0x101431fb4 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x204>
101431eac: aa0103f7    	mov	x23, x1
101431eb0: 90004582    	adrp	x2, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101431eb4: 9126a042    	add	x2, x2, #0x9a8
101431eb8: 9100c3e8    	add	x8, sp, #0x30
101431ebc: aa1603e0    	mov	x0, x22
101431ec0: 528002a3    	mov	w3, #0x15               ; =21
101431ec4: 940e48f6    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101431ec8: f94017f3    	ldr	x19, [sp, #0x28]
101431ecc: f9400fe8    	ldr	x8, [sp, #0x18]
101431ed0: eb08027f    	cmp	x19, x8
101431ed4: 54000061    	b.ne	0x101431ee0 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x130>
101431ed8: 910063e0    	add	x0, sp, #0x18
101431edc: 941a05b7    	bl	0x101ab35b8 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hf16ba54f53b72f04E>
101431ee0: f94013e8    	ldr	x8, [sp, #0x20]
101431ee4: 52800309    	mov	w9, #0x18               ; =24
101431ee8: 9b092268    	madd	x8, x19, x9, x8
101431eec: 3dc00fe0    	ldr	q0, [sp, #0x30]
101431ef0: 3d800100    	str	q0, [x8]
101431ef4: f94023e9    	ldr	x9, [sp, #0x40]
101431ef8: f9000909    	str	x9, [x8, #0x10]
101431efc: 91000668    	add	x8, x19, #0x1
101431f00: f90017e8    	str	x8, [sp, #0x28]
101431f04: 90004582    	adrp	x2, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101431f08: 9126f442    	add	x2, x2, #0x9bd
101431f0c: 9100c3e8    	add	x8, sp, #0x30
101431f10: aa1603e0    	mov	x0, x22
101431f14: aa1703e1    	mov	x1, x23
101431f18: 52800463    	mov	w3, #0x23               ; =35
101431f1c: 940e48e0    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101431f20: f94017f3    	ldr	x19, [sp, #0x28]
101431f24: f9400fe8    	ldr	x8, [sp, #0x18]
101431f28: eb08027f    	cmp	x19, x8
101431f2c: 54000061    	b.ne	0x101431f38 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x188>
101431f30: 910063e0    	add	x0, sp, #0x18
101431f34: 941a05a1    	bl	0x101ab35b8 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hf16ba54f53b72f04E>
101431f38: f94013e8    	ldr	x8, [sp, #0x20]
101431f3c: 52800309    	mov	w9, #0x18               ; =24
101431f40: 9b092268    	madd	x8, x19, x9, x8
101431f44: 3dc00fe0    	ldr	q0, [sp, #0x30]
101431f48: 3d800100    	str	q0, [x8]
101431f4c: f94023e9    	ldr	x9, [sp, #0x40]
101431f50: f9000909    	str	x9, [x8, #0x10]
101431f54: 91000668    	add	x8, x19, #0x1
101431f58: f90017e8    	str	x8, [sp, #0x28]
101431f5c: 90004582    	adrp	x2, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101431f60: 91278042    	add	x2, x2, #0x9e0
101431f64: 9100c3e8    	add	x8, sp, #0x30
101431f68: aa1603e0    	mov	x0, x22
101431f6c: aa1703e1    	mov	x1, x23
101431f70: 52800743    	mov	w3, #0x3a               ; =58
101431f74: 940e48ca    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101431f78: f94017f3    	ldr	x19, [sp, #0x28]
101431f7c: f9400fe8    	ldr	x8, [sp, #0x18]
101431f80: eb08027f    	cmp	x19, x8
101431f84: 54000061    	b.ne	0x101431f90 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x1e0>
101431f88: 910063e0    	add	x0, sp, #0x18
101431f8c: 941a058b    	bl	0x101ab35b8 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hf16ba54f53b72f04E>
101431f90: f94013e8    	ldr	x8, [sp, #0x20]
101431f94: 52800309    	mov	w9, #0x18               ; =24
101431f98: 9b092268    	madd	x8, x19, x9, x8
101431f9c: 3dc00fe0    	ldr	q0, [sp, #0x30]
101431fa0: 3d800100    	str	q0, [x8]
101431fa4: f94023e9    	ldr	x9, [sp, #0x40]
101431fa8: f9000909    	str	x9, [x8, #0x10]
101431fac: 91000668    	add	x8, x19, #0x1
101431fb0: f90017e8    	str	x8, [sp, #0x28]
101431fb4: 97d9b1cf    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101431fb8: 528004b7    	mov	w23, #0x25              ; =37
101431fbc: 528004a0    	mov	w0, #0x25               ; =37
101431fc0: 52800021    	mov	w1, #0x1                ; =1
101431fc4: 97d9b1c5    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101431fc8: b4001080    	cbz	x0, 0x1014321d8 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x428>
101431fcc: aa0003f6    	mov	x22, x0
101431fd0: 90004588    	adrp	x8, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101431fd4: 91286908    	add	x8, x8, #0xa1a
101431fd8: ad400500    	ldp	q0, q1, [x8]
101431fdc: ad000400    	stp	q0, q1, [x0]
101431fe0: f841d108    	ldur	x8, [x8, #0x1d]
101431fe4: f801d008    	stur	x8, [x0, #0x1d]
101431fe8: f94017f3    	ldr	x19, [sp, #0x28]
101431fec: f9400fe8    	ldr	x8, [sp, #0x18]
101431ff0: eb08027f    	cmp	x19, x8
101431ff4: 54000061    	b.ne	0x101432000 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x250>
101431ff8: 910063e0    	add	x0, sp, #0x18
101431ffc: 941a056f    	bl	0x101ab35b8 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hf16ba54f53b72f04E>
101432000: f94013e8    	ldr	x8, [sp, #0x20]
101432004: 52800309    	mov	w9, #0x18               ; =24
101432008: 9b092268    	madd	x8, x19, x9, x8
10143200c: 528004a9    	mov	w9, #0x25               ; =37
101432010: a9005909    	stp	x9, x22, [x8]
101432014: f9000909    	str	x9, [x8, #0x10]
101432018: 91000668    	add	x8, x19, #0x1
10143201c: f90017e8    	str	x8, [sp, #0x28]
101432020: 97d9b1b4    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101432024: 52800577    	mov	w23, #0x2b              ; =43
101432028: 52800560    	mov	w0, #0x2b               ; =43
10143202c: 52800021    	mov	w1, #0x1                ; =1
101432030: 97d9b1aa    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101432034: b4000d20    	cbz	x0, 0x1014321d8 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x428>
101432038: aa0003f6    	mov	x22, x0
10143203c: f0004568    	adrp	x8, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101432040: 9128fd08    	add	x8, x8, #0xa3f
101432044: ad400500    	ldp	q0, q1, [x8]
101432048: ad000400    	stp	q0, q1, [x0]
10143204c: 3cc1b100    	ldur	q0, [x8, #0x1b]
101432050: 3c81b000    	stur	q0, [x0, #0x1b]
101432054: f94017f4    	ldr	x20, [sp, #0x28]
101432058: f9400fe8    	ldr	x8, [sp, #0x18]
10143205c: eb08029f    	cmp	x20, x8
101432060: 54000061    	b.ne	0x10143206c <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x2bc>
101432064: 910063e0    	add	x0, sp, #0x18
101432068: 941a0554    	bl	0x101ab35b8 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hf16ba54f53b72f04E>
10143206c: f94013e8    	ldr	x8, [sp, #0x20]
101432070: 52800309    	mov	w9, #0x18               ; =24
101432074: 9b092288    	madd	x8, x20, x9, x8
101432078: 5280056a    	mov	w10, #0x2b              ; =43
10143207c: a900590a    	stp	x10, x22, [x8]
101432080: f900090a    	str	x10, [x8, #0x10]
101432084: a941cffa    	ldp	x26, x19, [sp, #0x18]
101432088: a9034ff3    	stp	x19, x19, [sp, #0x30]
10143208c: aa1303f6    	mov	x22, x19
101432090: b1000688    	adds	x8, x20, #0x1
101432094: f90017e8    	str	x8, [sp, #0x28]
101432098: 9b094d1c    	madd	x28, x8, x9, x19
10143209c: a90473fa    	stp	x26, x28, [sp, #0x40]
1014320a0: 54000422    	b.hs	0x101432124 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x374>
1014320a4: f9000bf8    	str	x24, [sp, #0x10]
1014320a8: 91006276    	add	x22, x19, #0x18
1014320ac: d2f00014    	mov	x20, #-0x8000000000000000 ; =-9223372036854775808
1014320b0: 14000007    	b	0x1014320cc <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x31c>
1014320b4: eb1402ff    	cmp	x23, x20
1014320b8: 540005c1    	b.ne	0x101432170 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x3c0>
1014320bc: 910062d6    	add	x22, x22, #0x18
1014320c0: 91006368    	add	x8, x27, #0x18
1014320c4: eb1c011f    	cmp	x8, x28
1014320c8: 54000280    	b.eq	0x101432118 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x368>
1014320cc: aa1603fb    	mov	x27, x22
1014320d0: a9fee377    	ldp	x23, x24, [x27, #-0x18]!
1014320d4: f9400b79    	ldr	x25, [x27, #0x10]
1014320d8: aa1803e0    	mov	x0, x24
1014320dc: aa1903e1    	mov	x1, x25
1014320e0: 940e495f    	bl	0x1017c465c <__ZN3std4path4Path7is_file17hb9783ece3b71780eE>
1014320e4: 3707fe80    	tbnz	w0, #0x0, 0x1014320b4 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x304>
1014320e8: b4fffeb7    	cbz	x23, 0x1014320bc <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x30c>
1014320ec: aa1803e0    	mov	x0, x24
1014320f0: aa1703e1    	mov	x1, x23
1014320f4: 52800022    	mov	w2, #0x1                ; =1
1014320f8: 97d9b179    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014320fc: 17fffff0    	b	0x1014320bc <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x30c>
101432100: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101432104: f90002a8    	str	x8, [x21]
101432108: b4000593    	cbz	x19, 0x1014321b8 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x408>
10143210c: aa1403e0    	mov	x0, x20
101432110: aa1303e1    	mov	x1, x19
101432114: 14000027    	b	0x1014321b0 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x400>
101432118: f9001ffc    	str	x28, [sp, #0x38]
10143211c: aa1c03f6    	mov	x22, x28
101432120: f9400bf8    	ldr	x24, [sp, #0x10]
101432124: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101432128: f90002a8    	str	x8, [x21]
10143212c: eb160388    	subs	x8, x28, x22
101432130: 540002c0    	b.eq	0x101432188 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x3d8>
101432134: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
101432138: f2955569    	movk	x9, #0xaaab
10143213c: 9bc97d08    	umulh	x8, x8, x9
101432140: d344fd14    	lsr	x20, x8, #4
101432144: 910022d5    	add	x21, x22, #0x8
101432148: 14000004    	b	0x101432158 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x3a8>
10143214c: 910062b5    	add	x21, x21, #0x18
101432150: f1000694    	subs	x20, x20, #0x1
101432154: 540001a0    	b.eq	0x101432188 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x3d8>
101432158: f85f82a1    	ldur	x1, [x21, #-0x8]
10143215c: b4ffff81    	cbz	x1, 0x10143214c <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x39c>
101432160: f94002a0    	ldr	x0, [x21]
101432164: 52800022    	mov	w2, #0x1                ; =1
101432168: 97d9b15d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143216c: 17fffff8    	b	0x10143214c <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x39c>
101432170: f9001ff6    	str	x22, [sp, #0x38]
101432174: a90062b7    	stp	x23, x24, [x21]
101432178: f9000ab9    	str	x25, [x21, #0x10]
10143217c: f9400bf8    	ldr	x24, [sp, #0x10]
101432180: eb160388    	subs	x8, x28, x22
101432184: 54fffd81    	b.ne	0x101432134 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x384>
101432188: b40000da    	cbz	x26, 0x1014321a0 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x3f0>
10143218c: 8b1a0748    	add	x8, x26, x26, lsl #1
101432190: d37df101    	lsl	x1, x8, #3
101432194: aa1303e0    	mov	x0, x19
101432198: 52800102    	mov	w2, #0x8                ; =8
10143219c: 97d9b150    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014321a0: f240fb1f    	tst	x24, #0x7fffffffffffffff
1014321a4: 540000a0    	b.eq	0x1014321b8 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x408>
1014321a8: f94007e0    	ldr	x0, [sp, #0x8]
1014321ac: aa1803e1    	mov	x1, x24
1014321b0: 52800022    	mov	w2, #0x1                ; =1
1014321b4: 97d9b14a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014321b8: a94a7bfd    	ldp	x29, x30, [sp, #0xa0]
1014321bc: a9494ff4    	ldp	x20, x19, [sp, #0x90]
1014321c0: a94857f6    	ldp	x22, x21, [sp, #0x80]
1014321c4: a9475ff8    	ldp	x24, x23, [sp, #0x70]
1014321c8: a94667fa    	ldp	x26, x25, [sp, #0x60]
1014321cc: a9456ffc    	ldp	x28, x27, [sp, #0x50]
1014321d0: 9102c3ff    	add	sp, sp, #0xb0
1014321d4: d65f03c0    	ret
1014321d8: 52800020    	mov	w0, #0x1                ; =1
1014321dc: aa1703e1    	mov	x1, x23
1014321e0: 941a4465    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014321e4: d4200020    	brk	#0x1
1014321e8: aa0003f5    	mov	x21, x0
1014321ec: f9400661    	ldr	x1, [x19, #0x8]
1014321f0: b4000081    	cbz	x1, 0x101432200 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x450>
1014321f4: f9400a62    	ldr	x2, [x19, #0x10]
1014321f8: aa1603e0    	mov	x0, x22
1014321fc: 97d9b138    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101432200: aa1403e0    	mov	x0, x20
101432204: 52800301    	mov	w1, #0x18               ; =24
101432208: 52800102    	mov	w2, #0x8                ; =8
10143220c: 14000030    	b	0x1014322cc <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x51c>
101432210: 14000002    	b	0x101432218 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x468>
101432214: 14000001    	b	0x101432218 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x468>
101432218: f9000bf8    	str	x24, [sp, #0x10]
10143221c: aa0003f5    	mov	x21, x0
101432220: f9401be1    	ldr	x1, [sp, #0x30]
101432224: b4000321    	cbz	x1, 0x101432288 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x4d8>
101432228: f9401fe0    	ldr	x0, [sp, #0x38]
10143222c: 1400000a    	b	0x101432254 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x4a4>
101432230: f9000bf8    	str	x24, [sp, #0x10]
101432234: aa0003f5    	mov	x21, x0
101432238: aa1603e0    	mov	x0, x22
10143223c: 52800561    	mov	w1, #0x2b               ; =43
101432240: 14000005    	b	0x101432254 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x4a4>
101432244: f9000bf8    	str	x24, [sp, #0x10]
101432248: aa0003f5    	mov	x21, x0
10143224c: aa1603e0    	mov	x0, x22
101432250: 528004a1    	mov	w1, #0x25               ; =37
101432254: 52800022    	mov	w2, #0x1                ; =1
101432258: 97d9b121    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143225c: 1400000b    	b	0x101432288 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x4d8>
101432260: f9000bf8    	str	x24, [sp, #0x10]
101432264: aa0003f5    	mov	x21, x0
101432268: 14000014    	b	0x1014322b8 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x508>
10143226c: aa0003f5    	mov	x21, x0
101432270: b4000313    	cbz	x19, 0x1014322d0 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x520>
101432274: aa1403e0    	mov	x0, x20
101432278: aa1303e1    	mov	x1, x19
10143227c: 14000013    	b	0x1014322c8 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x518>
101432280: f9000bf8    	str	x24, [sp, #0x10]
101432284: aa0003f5    	mov	x21, x0
101432288: 910063e0    	add	x0, sp, #0x18
10143228c: 97d44220    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101432290: 1400000a    	b	0x1014322b8 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x508>
101432294: aa0003f5    	mov	x21, x0
101432298: f9001ff6    	str	x22, [sp, #0x38]
10143229c: b40000b7    	cbz	x23, 0x1014322b0 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x500>
1014322a0: aa1803e0    	mov	x0, x24
1014322a4: aa1703e1    	mov	x1, x23
1014322a8: 52800022    	mov	w2, #0x1                ; =1
1014322ac: 97d9b10c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014322b0: 9100c3e0    	add	x0, sp, #0x30
1014322b4: 97d3fb55    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
1014322b8: f9400be8    	ldr	x8, [sp, #0x10]
1014322bc: f240f91f    	tst	x8, #0x7fffffffffffffff
1014322c0: 54000080    	b.eq	0x1014322d0 <__ZN17otty_autocomplete5paths22bundled_completions_db17h460558c6237f49deE+0x520>
1014322c4: a94087e0    	ldp	x0, x1, [sp, #0x8]
1014322c8: 52800022    	mov	w2, #0x1                ; =1
1014322cc: 97d9b104    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014322d0: aa1503e0    	mov	x0, x21
1014322d4: 941a5cc0    	bl	0x101ac95d4 <_writev+0x101ac95d4>

00000001014322d8 <__ZN17otty_autocomplete5paths8state_db17haec3b56e125859adE>:
1014322d8: d10103ff    	sub	sp, sp, #0x40
1014322dc: a9024ff4    	stp	x20, x19, [sp, #0x20]
1014322e0: a9037bfd    	stp	x29, x30, [sp, #0x30]
1014322e4: 9100c3fd    	add	x29, sp, #0x30
1014322e8: aa0803f4    	mov	x20, x8
1014322ec: 910023e8    	add	x8, sp, #0x8
1014322f0: 97fffdea    	bl	0x101431a98 <__ZN17otty_autocomplete5paths15app_support_dir17hf0f36c52dec0652bE>
1014322f4: a94107f3    	ldp	x19, x1, [sp, #0x10]
1014322f8: b00036a2    	adrp	x2, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
1014322fc: 912a4042    	add	x2, x2, #0xa90
101432300: aa1403e8    	mov	x8, x20
101432304: aa1303e0    	mov	x0, x19
101432308: 52800103    	mov	w3, #0x8                ; =8
10143230c: 940e47e4    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101432310: f94007e1    	ldr	x1, [sp, #0x8]
101432314: b40000e1    	cbz	x1, 0x101432330 <__ZN17otty_autocomplete5paths8state_db17haec3b56e125859adE+0x58>
101432318: aa1303e0    	mov	x0, x19
10143231c: 52800022    	mov	w2, #0x1                ; =1
101432320: a9437bfd    	ldp	x29, x30, [sp, #0x30]
101432324: a9424ff4    	ldp	x20, x19, [sp, #0x20]
101432328: 910103ff    	add	sp, sp, #0x40
10143232c: 17d9b0ec    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101432330: a9437bfd    	ldp	x29, x30, [sp, #0x30]
101432334: a9424ff4    	ldp	x20, x19, [sp, #0x20]
101432338: 910103ff    	add	sp, sp, #0x40
10143233c: d65f03c0    	ret
101432340: aa0003f4    	mov	x20, x0
101432344: f94007e1    	ldr	x1, [sp, #0x8]
101432348: b4000081    	cbz	x1, 0x101432358 <__ZN17otty_autocomplete5paths8state_db17haec3b56e125859adE+0x80>
10143234c: aa1303e0    	mov	x0, x19
101432350: 52800022    	mov	w2, #0x1                ; =1
101432354: 97d9b0e2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101432358: aa1403e0    	mov	x0, x20
10143235c: 941a5c9e    	bl	0x101ac95d4 <_writev+0x101ac95d4>
