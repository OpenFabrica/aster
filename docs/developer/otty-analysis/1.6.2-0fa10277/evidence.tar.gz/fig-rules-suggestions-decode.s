
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010146d390 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E>:
101472488: d106c3ff    	sub	sp, sp, #0x1b0
10147248c: a9156ffc    	stp	x28, x27, [sp, #0x150]
101472490: a91667fa    	stp	x26, x25, [sp, #0x160]
101472494: a9175ff8    	stp	x24, x23, [sp, #0x170]
101472498: a91857f6    	stp	x22, x21, [sp, #0x180]
10147249c: a9194ff4    	stp	x20, x19, [sp, #0x190]
1014724a0: a91a7bfd    	stp	x29, x30, [sp, #0x1a0]
1014724a4: 910683fd    	add	x29, sp, #0x1a0
1014724a8: aa0003fc    	mov	x28, x0
1014724ac: 39400028    	ldrb	w8, [x1]
1014724b0: 7100511f    	cmp	w8, #0x14
1014724b4: 540051c1    	b.ne	0x101472eec <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5b5c>
1014724b8: a9412034    	ldp	x20, x8, [x1, #0x10]
1014724bc: d37be913    	lsl	x19, x8, #5
1014724c0: 8b13029b    	add	x27, x20, x19
1014724c4: 528aaaa9    	mov	w9, #0x5555             ; =21845
1014724c8: eb09011f    	cmp	x8, x9
1014724cc: 9a893116    	csel	x22, x8, x9, lo
1014724d0: b4002f68    	cbz	x8, 0x101472abc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x572c>
1014724d4: 8b1606c8    	add	x8, x22, x22, lsl #1
1014724d8: d37ced15    	lsl	x21, x8, #4
1014724dc: 97d8b085    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014724e0: aa1503e0    	mov	x0, x21
1014724e4: 52800101    	mov	w1, #0x8                ; =8
1014724e8: 97d8b07c    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014724ec: b40055c0    	cbz	x0, 0x101472fa4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5c14>
1014724f0: d10303b7    	sub	x23, x29, #0xc0
1014724f4: b24002e8    	orr	x8, x23, #0x1
1014724f8: a9035be8    	stp	x8, x22, [sp, #0x30]
1014724fc: 910303e8    	add	x8, sp, #0xc0
101472500: b240011a    	orr	x26, x8, #0x1
101472504: a9047fe0    	stp	x0, xzr, [sp, #0x40]
101472508: d1008268    	sub	x8, x19, #0x20
10147250c: d345fd08    	lsr	x8, x8, #5
101472510: 91000508    	add	x8, x8, #0x1
101472514: f90007e8    	str	x8, [sp, #0x8]
101472518: 1400000f    	b	0x101472554 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x51c4>
10147251c: 91008294    	add	x20, x20, #0x20
101472520: f94023e8    	ldr	x8, [sp, #0x40]
101472524: 52800609    	mov	w9, #0x30               ; =48
101472528: 9b092268    	madd	x8, x19, x9, x8
10147252c: 3dc01fe0    	ldr	q0, [sp, #0x70]
101472530: 3d800100    	str	q0, [x8]
101472534: 3dc023e0    	ldr	q0, [sp, #0x80]
101472538: 3d800500    	str	q0, [x8, #0x10]
10147253c: 3dc027e0    	ldr	q0, [sp, #0x90]
101472540: 3d800900    	str	q0, [x8, #0x20]
101472544: 91000668    	add	x8, x19, #0x1
101472548: f90027e8    	str	x8, [sp, #0x48]
10147254c: eb1b029f    	cmp	x20, x27
101472550: 54002e60    	b.eq	0x101472b1c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x578c>
101472554: d10303a8    	sub	x8, x29, #0xc0
101472558: aa1403e0    	mov	x0, x20
10147255c: 940cc11e    	bl	0x1017a29d4 <__ZN5serde7private2de7content13content_clone17h04d54a4c93e26ddaE>
101472560: 385403b8    	ldurb	w24, [x29, #-0xc0]
101472564: 71005b1f    	cmp	w24, #0x16
101472568: 54002d60    	b.eq	0x101472b14 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5784>
10147256c: b24107f6    	mov	x22, #-0x7fffffffffffffff ; =-9223372036854775807
101472570: f9401be9    	ldr	x9, [sp, #0x30]
101472574: b9400128    	ldr	w8, [x9]
101472578: b9000348    	str	w8, [x26]
10147257c: b8403128    	ldur	w8, [x9, #0x3]
101472580: b8003348    	stur	w8, [x26, #0x3]
101472584: f85483b3    	ldur	x19, [x29, #-0xb8]
101472588: 3cc102e0    	ldur	q0, [x23, #0x10]
10147258c: 910303e8    	add	x8, sp, #0xc0
101472590: 3c810100    	stur	q0, [x8, #0x10]
101472594: 390303f8    	strb	w24, [sp, #0xc0]
101472598: f90067f3    	str	x19, [sp, #0xc8]
10147259c: d10223a0    	sub	x0, x29, #0x88
1014725a0: 910303e1    	add	x1, sp, #0xc0
1014725a4: 97fe3c39    	bl	0x101401688 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x63c>
1014725a8: f85783a8    	ldur	x8, [x29, #-0x88]
1014725ac: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1014725b0: eb09011f    	cmp	x8, x9
1014725b4: 54000201    	b.ne	0x1014725f4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5264>
1014725b8: d2f00017    	mov	x23, #-0x8000000000000000 ; =-9223372036854775808
1014725bc: f85803a8    	ldur	x8, [x29, #-0x80]
1014725c0: a93423b6    	stp	x22, x8, [x29, #-0xc0]
1014725c4: d10303a0    	sub	x0, x29, #0xc0
1014725c8: 97ff7c3e    	bl	0x1014516c0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x4238>
1014725cc: b000436a    	adrp	x10, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014725d0: 9111614a    	add	x10, x10, #0x458
1014725d4: 10000088    	adr	x8, 0x1014725e4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5254>
1014725d8: 78787949    	ldrh	w9, [x10, x24, lsl #1]
1014725dc: 8b090908    	add	x8, x8, x9, lsl #2
1014725e0: d61f0100    	br	x8
1014725e4: b940c7e1    	ldr	w1, [sp, #0xc4]
1014725e8: d10303a0    	sub	x0, x29, #0xc0
1014725ec: 94187283    	bl	0x101a8eff8 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x118>
1014725f0: 140000e7    	b	0x10147298c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x55fc>
1014725f4: 3cd783a0    	ldur	q0, [x29, #-0x88]
1014725f8: d10303b7    	sub	x23, x29, #0xc0
1014725fc: 3c8082e0    	stur	q0, [x23, #0x8]
101472600: f85883a8    	ldur	x8, [x29, #-0x78]
101472604: f80182e8    	stur	x8, [x23, #0x18]
101472608: f85483b8    	ldur	x24, [x29, #-0xb8]
10147260c: ad4086e0    	ldp	q0, q1, [x23, #0x10]
101472610: ad0507e0    	stp	q0, q1, [sp, #0xa0]
101472614: d2f00013    	mov	x19, #-0x8000000000000000 ; =-9223372036854775808
101472618: 140000e5    	b	0x1014729ac <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x561c>
10147261c: f9000ffb    	str	x27, [sp, #0x18]
101472620: f9406fe8    	ldr	x8, [sp, #0xd8]
101472624: b4001748    	cbz	x8, 0x10147290c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x557c>
101472628: f90003fc    	str	x28, [sp]
10147262c: d2800018    	mov	x24, #0x0               ; =0
101472630: f9406bf3    	ldr	x19, [sp, #0xd0]
101472634: d37ae51c    	lsl	x28, x8, #6
101472638: b24107fb    	mov	x27, #-0x7fffffffffffffff ; =-9223372036854775807
10147263c: d2f00019    	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
101472640: 14000011    	b	0x101472684 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52f4>
101472644: f9400109    	ldr	x9, [x8]
101472648: f8403108    	ldur	x8, [x8, #0x3]
10147264c: d28cac8a    	mov	x10, #0x6564            ; =25956
101472650: f2ac6e6a    	movk	x10, #0x6373, lsl #16
101472654: f2cd2e4a    	movk	x10, #0x6972, lsl #32
101472658: f2ee8e0a    	movk	x10, #0x7470, lsl #48
10147265c: eb0a013f    	cmp	x9, x10
101472660: d28e4c69    	mov	x9, #0x7263             ; =29283
101472664: f2ae0d29    	movk	x9, #0x7069, lsl #16
101472668: f2cd2e89    	movk	x9, #0x6974, lsl #32
10147266c: f2edcde9    	movk	x9, #0x6e6f, lsl #48
101472670: fa490100    	ccmp	x8, x9, #0x0, eq
101472674: 54000c40    	b.eq	0x1014727fc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x546c>
101472678: 91010318    	add	x24, x24, #0x40
10147267c: eb18039f    	cmp	x28, x24
101472680: 540012c0    	b.eq	0x1014728d8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5548>
101472684: 8b180261    	add	x1, x19, x24
101472688: 38420428    	ldrb	w8, [x1], #0x20
10147268c: 7100311f    	cmp	w8, #0xc
101472690: 5400018c    	b.gt	0x1014726c0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5330>
101472694: 7100051f    	cmp	w8, #0x1
101472698: 54000a00    	b.eq	0x1014727d8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5448>
10147269c: 7100111f    	cmp	w8, #0x4
1014726a0: 54000680    	b.eq	0x101472770 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x53e0>
1014726a4: 7100311f    	cmp	w8, #0xc
1014726a8: 54001de1    	b.ne	0x101472a64 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x56d4>
1014726ac: 8b180269    	add	x9, x19, x24
1014726b0: a9412528    	ldp	x8, x9, [x9, #0x10]
1014726b4: f1002d3f    	cmp	x9, #0xb
1014726b8: 54000c61    	b.ne	0x101472844 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x54b4>
1014726bc: 17ffffe2    	b	0x101472644 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52b4>
1014726c0: 7100351f    	cmp	w8, #0xd
1014726c4: 54000b80    	b.eq	0x101472834 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x54a4>
1014726c8: 7100391f    	cmp	w8, #0xe
1014726cc: 54000600    	b.eq	0x10147278c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x53fc>
1014726d0: 71003d1f    	cmp	w8, #0xf
1014726d4: 54001c81    	b.ne	0x101472a64 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x56d4>
1014726d8: 8b180269    	add	x9, x19, x24
1014726dc: a940a528    	ldp	x8, x9, [x9, #0x8]
1014726e0: f1002d3f    	cmp	x9, #0xb
1014726e4: 540005c1    	b.ne	0x10147279c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x540c>
1014726e8: 39400109    	ldrb	w9, [x8]
1014726ec: 7101913f    	cmp	w9, #0x64
1014726f0: 54fffc41    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
1014726f4: 39400509    	ldrb	w9, [x8, #0x1]
1014726f8: 7101953f    	cmp	w9, #0x65
1014726fc: 54fffbe1    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
101472700: 39400909    	ldrb	w9, [x8, #0x2]
101472704: 7101cd3f    	cmp	w9, #0x73
101472708: 54fffb81    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
10147270c: 39400d09    	ldrb	w9, [x8, #0x3]
101472710: 71018d3f    	cmp	w9, #0x63
101472714: 54fffb21    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
101472718: 39401109    	ldrb	w9, [x8, #0x4]
10147271c: 7101c93f    	cmp	w9, #0x72
101472720: 54fffac1    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
101472724: 39401509    	ldrb	w9, [x8, #0x5]
101472728: 7101a53f    	cmp	w9, #0x69
10147272c: 54fffa61    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
101472730: 39401909    	ldrb	w9, [x8, #0x6]
101472734: 7101c13f    	cmp	w9, #0x70
101472738: 54fffa01    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
10147273c: 39401d09    	ldrb	w9, [x8, #0x7]
101472740: 7101d13f    	cmp	w9, #0x74
101472744: 54fff9a1    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
101472748: 39402109    	ldrb	w9, [x8, #0x8]
10147274c: 7101a53f    	cmp	w9, #0x69
101472750: 54fff941    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
101472754: 39402509    	ldrb	w9, [x8, #0x9]
101472758: 7101bd3f    	cmp	w9, #0x6f
10147275c: 54fff8e1    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
101472760: 39402908    	ldrb	w8, [x8, #0xa]
101472764: 7101b91f    	cmp	w8, #0x6e
101472768: 54fff881    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
10147276c: 14000024    	b	0x1014727fc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x546c>
101472770: 8b180268    	add	x8, x19, x24
101472774: f9400509    	ldr	x9, [x8, #0x8]
101472778: f100053f    	cmp	x9, #0x1
10147277c: 52800028    	mov	w8, #0x1                ; =1
101472780: 1a880508    	cinc	w8, w8, ne
101472784: b5000369    	cbnz	x9, 0x1014727f0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5460>
101472788: 14000036    	b	0x101472860 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x54d0>
10147278c: 8b180269    	add	x9, x19, x24
101472790: a9412528    	ldp	x8, x9, [x9, #0x10]
101472794: f1002d3f    	cmp	x9, #0xb
101472798: 54fffa80    	b.eq	0x1014726e8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5358>
10147279c: f100113f    	cmp	x9, #0x4
1014727a0: 54fff6c1    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
1014727a4: 39400109    	ldrb	w9, [x8]
1014727a8: 7101b93f    	cmp	w9, #0x6e
1014727ac: 54fff661    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
1014727b0: 39400509    	ldrb	w9, [x8, #0x1]
1014727b4: 7101853f    	cmp	w9, #0x61
1014727b8: 54fff601    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
1014727bc: 39400909    	ldrb	w9, [x8, #0x2]
1014727c0: 7101b53f    	cmp	w9, #0x6d
1014727c4: 54fff5a1    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
1014727c8: 39400d08    	ldrb	w8, [x8, #0x3]
1014727cc: 7101951f    	cmp	w8, #0x65
1014727d0: 54fff541    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
1014727d4: 14000023    	b	0x101472860 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x54d0>
1014727d8: 8b180268    	add	x8, x19, x24
1014727dc: 39400509    	ldrb	w9, [x8, #0x1]
1014727e0: 7100053f    	cmp	w9, #0x1
1014727e4: 52800028    	mov	w8, #0x1                ; =1
1014727e8: 1a880508    	cinc	w8, w8, ne
1014727ec: 340003a9    	cbz	w9, 0x101472860 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x54d0>
1014727f0: 12001d08    	and	w8, w8, #0xff
1014727f4: 7100091f    	cmp	w8, #0x2
1014727f8: 54fff400    	b.eq	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
1014727fc: eb16037f    	cmp	x27, x22
101472800: 54001401    	b.ne	0x101472a80 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x56f0>
101472804: 39400028    	ldrb	w8, [x1]
101472808: d2f0001b    	mov	x27, #-0x8000000000000000 ; =-9223372036854775808
10147280c: 7100411f    	cmp	w8, #0x10
101472810: 54fff340    	b.eq	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
101472814: 7100451f    	cmp	w8, #0x11
101472818: 540003a0    	b.eq	0x10147288c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x54fc>
10147281c: 7100491f    	cmp	w8, #0x12
101472820: 54fff2c0    	b.eq	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
101472824: b24107fb    	mov	x27, #-0x7fffffffffffffff ; =-9223372036854775807
101472828: d10223a0    	sub	x0, x29, #0x88
10147282c: 97fe3b97    	bl	0x101401688 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x63c>
101472830: 1400001c    	b	0x1014728a0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5510>
101472834: 8b180269    	add	x9, x19, x24
101472838: a940a528    	ldp	x8, x9, [x9, #0x8]
10147283c: f1002d3f    	cmp	x9, #0xb
101472840: 54fff020    	b.eq	0x101472644 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52b4>
101472844: f100113f    	cmp	x9, #0x4
101472848: 54fff181    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
10147284c: b9400108    	ldr	w8, [x8]
101472850: 528c2dc9    	mov	w9, #0x616e             ; =24942
101472854: 72acada9    	movk	w9, #0x656d, lsl #16
101472858: 6b09011f    	cmp	w8, w9
10147285c: 54fff0e1    	b.ne	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
101472860: eb17033f    	cmp	x25, x23
101472864: 54000e21    	b.ne	0x101472a28 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5698>
101472868: d2f00019    	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
10147286c: d10223a0    	sub	x0, x29, #0x88
101472870: 97fe3b86    	bl	0x101401688 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x63c>
101472874: a97783b9    	ldp	x25, x0, [x29, #-0x88]
101472878: eb17033f    	cmp	x25, x23
10147287c: 54000be0    	b.eq	0x1014729f8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5668>
101472880: f85883b5    	ldur	x21, [x29, #-0x78]
101472884: f90017e0    	str	x0, [sp, #0x28]
101472888: 17ffff7c    	b	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
10147288c: 8b180268    	add	x8, x19, x24
101472890: f9401501    	ldr	x1, [x8, #0x28]
101472894: b24107fb    	mov	x27, #-0x7fffffffffffffff ; =-9223372036854775807
101472898: d10223a0    	sub	x0, x29, #0x88
10147289c: 97fe3b7b    	bl	0x101401688 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x63c>
1014728a0: a977a7a8    	ldp	x8, x9, [x29, #-0x88]
1014728a4: f9000be9    	str	x9, [sp, #0x10]
1014728a8: f85883a9    	ldur	x9, [x29, #-0x78]
1014728ac: b24107ea    	mov	x10, #-0x7fffffffffffffff ; =-9223372036854775807
1014728b0: eb0a011f    	cmp	x8, x10
1014728b4: 9a8ac11b    	csel	x27, x8, x10, gt
1014728b8: eb17011f    	cmp	x8, x23
1014728bc: f94013e8    	ldr	x8, [sp, #0x20]
1014728c0: 9a890108    	csel	x8, x8, x9, eq
1014728c4: b24107f6    	mov	x22, #-0x7fffffffffffffff ; =-9223372036854775807
1014728c8: eb0a037f    	cmp	x27, x10
1014728cc: 54000a60    	b.eq	0x101472a18 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5688>
1014728d0: f90013e8    	str	x8, [sp, #0x20]
1014728d4: 17ffff69    	b	0x101472678 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x52e8>
1014728d8: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014728dc: eb08033f    	cmp	x25, x8
1014728e0: f94003fc    	ldr	x28, [sp]
1014728e4: 54000160    	b.eq	0x101472910 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5580>
1014728e8: eb16037f    	cmp	x27, x22
1014728ec: 9a9b0108    	csel	x8, x8, x27, eq
1014728f0: f94017e9    	ldr	x9, [sp, #0x28]
1014728f4: a93427b9    	stp	x25, x9, [x29, #-0xc0]
1014728f8: a93523b5    	stp	x21, x8, [x29, #-0xb0]
1014728fc: a9416fe9    	ldp	x9, x27, [sp, #0x10]
101472900: f94013e8    	ldr	x8, [sp, #0x20]
101472904: a93623a9    	stp	x9, x8, [x29, #-0xa0]
101472908: 14000021    	b	0x10147298c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x55fc>
10147290c: b24107fb    	mov	x27, #-0x7fffffffffffffff ; =-9223372036854775807
101472910: 90003568    	adrp	x8, 0x101b1e000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x17014>
101472914: 910f4109    	add	x9, x8, #0x3d0
101472918: 52800088    	mov	w8, #0x4                ; =4
10147291c: a93923a9    	stp	x9, x8, [x29, #-0x70]
101472920: d2f00019    	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
101472924: d101c3a8    	sub	x8, x29, #0x70
101472928: f81783a8    	stur	x8, [x29, #-0x88]
10147292c: b0fffee8    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101472930: 91117108    	add	x8, x8, #0x45c
101472934: f81803a8    	stur	x8, [x29, #-0x80]
101472938: d10223a1    	sub	x1, x29, #0x88
10147293c: f0004bc0    	adrp	x0, 0x101ded000 <_writev+0x101ded000>
101472940: 912ea000    	add	x0, x0, #0xba8
101472944: 9416d7fd    	bl	0x101a28938 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x214>
101472948: a93403b6    	stp	x22, x0, [x29, #-0xc0]
10147294c: d2800048    	mov	x8, #0x2                ; =2
101472950: f2f00008    	movk	x8, #0x8000, lsl #48
101472954: eb08037f    	cmp	x27, x8
101472958: 540000cb    	b.lt	0x101472970 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x55e0>
10147295c: b40000bb    	cbz	x27, 0x101472970 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x55e0>
101472960: f9400be0    	ldr	x0, [sp, #0x10]
101472964: aa1b03e1    	mov	x1, x27
101472968: 52800022    	mov	w2, #0x1                ; =1
10147296c: 97d8af5c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101472970: f94017e0    	ldr	x0, [sp, #0x28]
101472974: f240fb3f    	tst	x25, #0x7fffffffffffffff
101472978: f9400ffb    	ldr	x27, [sp, #0x18]
10147297c: 54000080    	b.eq	0x10147298c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x55fc>
101472980: aa1903e1    	mov	x1, x25
101472984: 52800022    	mov	w2, #0x1                ; =1
101472988: 97d8af55    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147298c: f85403b3    	ldur	x19, [x29, #-0xc0]
101472990: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101472994: eb08027f    	cmp	x19, x8
101472998: 54002400    	b.eq	0x101472e18 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a88>
10147299c: f85483b8    	ldur	x24, [x29, #-0xb8]
1014729a0: d10303b7    	sub	x23, x29, #0xc0
1014729a4: ad4086e0    	ldp	q0, q1, [x23, #0x10]
1014729a8: ad0507e0    	stp	q0, q1, [sp, #0xa0]
1014729ac: 910303e0    	add	x0, sp, #0xc0
1014729b0: 97ff8677    	bl	0x10145438c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6f04>
1014729b4: ad4507e0    	ldp	q0, q1, [sp, #0xa0]
1014729b8: ad0287e0    	stp	q0, q1, [sp, #0x50]
1014729bc: d2800048    	mov	x8, #0x2                ; =2
1014729c0: f2f00008    	movk	x8, #0x8000, lsl #48
1014729c4: eb08027f    	cmp	x19, x8
1014729c8: 540023a0    	b.eq	0x101472e3c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5aac>
1014729cc: a90763f3    	stp	x19, x24, [sp, #0x70]
1014729d0: ad4287e0    	ldp	q0, q1, [sp, #0x50]
1014729d4: 9101c3e8    	add	x8, sp, #0x70
1014729d8: ad008500    	stp	q0, q1, [x8, #0x10]
1014729dc: f94027f3    	ldr	x19, [sp, #0x48]
1014729e0: f9401fe8    	ldr	x8, [sp, #0x38]
1014729e4: eb08027f    	cmp	x19, x8
1014729e8: 54ffd9a1    	b.ne	0x10147251c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x518c>
1014729ec: 9100e3e0    	add	x0, sp, #0x38
1014729f0: 94187557    	bl	0x101a8ff4c <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hccc1c94ee648454fE>
1014729f4: 17fffeca    	b	0x10147251c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x518c>
1014729f8: d2f00019    	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
1014729fc: f94003fc    	ldr	x28, [sp]
101472a00: a93403b6    	stp	x22, x0, [x29, #-0xc0]
101472a04: d2800048    	mov	x8, #0x2                ; =2
101472a08: f2f00008    	movk	x8, #0x8000, lsl #48
101472a0c: eb08037f    	cmp	x27, x8
101472a10: 54fffa6a    	b.ge	0x10147295c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x55cc>
101472a14: 17ffffd7    	b	0x101472970 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x55e0>
101472a18: f9400be8    	ldr	x8, [sp, #0x10]
101472a1c: a93423b6    	stp	x22, x8, [x29, #-0xc0]
101472a20: f94003fc    	ldr	x28, [sp]
101472a24: 17ffffd3    	b	0x101472970 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x55e0>
101472a28: 90003568    	adrp	x8, 0x101b1e000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x17014>
101472a2c: 910f4109    	add	x9, x8, #0x3d0
101472a30: 52800088    	mov	w8, #0x4                ; =4
101472a34: a93923a9    	stp	x9, x8, [x29, #-0x70]
101472a38: d101c3a8    	sub	x8, x29, #0x70
101472a3c: f81783a8    	stur	x8, [x29, #-0x88]
101472a40: b0fffee8    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101472a44: 91117108    	add	x8, x8, #0x45c
101472a48: f81803a8    	stur	x8, [x29, #-0x80]
101472a4c: d10223a1    	sub	x1, x29, #0x88
101472a50: f0004bc0    	adrp	x0, 0x101ded000 <_writev+0x101ded000>
101472a54: 912fec00    	add	x0, x0, #0xbfb
101472a58: 9416d7b8    	bl	0x101a28938 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x214>
101472a5c: f94003fc    	ldr	x28, [sp]
101472a60: 17ffffba    	b	0x101472948 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x55b8>
101472a64: 8b180260    	add	x0, x19, x24
101472a68: d101c3a1    	sub	x1, x29, #0x70
101472a6c: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472a70: 9111a042    	add	x2, x2, #0x468
101472a74: 94187652    	bl	0x101a903bc <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17heef390515a9a8b1cE+0x200>
101472a78: f94003fc    	ldr	x28, [sp]
101472a7c: 17ffffb3    	b	0x101472948 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x55b8>
101472a80: b0004368    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101472a84: 9125f109    	add	x9, x8, #0x97c
101472a88: 52800168    	mov	w8, #0xb                ; =11
101472a8c: a93923a9    	stp	x9, x8, [x29, #-0x70]
101472a90: d101c3a8    	sub	x8, x29, #0x70
101472a94: f81783a8    	stur	x8, [x29, #-0x88]
101472a98: b0fffee8    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101472a9c: 91117108    	add	x8, x8, #0x45c
101472aa0: f81803a8    	stur	x8, [x29, #-0x80]
101472aa4: d10223a1    	sub	x1, x29, #0x88
101472aa8: f0004bc0    	adrp	x0, 0x101ded000 <_writev+0x101ded000>
101472aac: 912fec00    	add	x0, x0, #0xbfb
101472ab0: 9416d7a2    	bl	0x101a28938 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x214>
101472ab4: f94003fc    	ldr	x28, [sp]
101472ab8: 17ffffa4    	b	0x101472948 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x55b8>
101472abc: d280000a    	mov	x10, #0x0               ; =0
101472ac0: 52800108    	mov	w8, #0x8                ; =8
101472ac4: a903a3ff    	stp	xzr, x8, [sp, #0x38]
101472ac8: f90027ff    	str	xzr, [sp, #0x48]
101472acc: d10303a8    	sub	x8, x29, #0xc0
101472ad0: 3cc383e0    	ldur	q0, [sp, #0x38]
101472ad4: 3d800100    	str	q0, [x8]
101472ad8: f94027e9    	ldr	x9, [sp, #0x48]
101472adc: f81503a9    	stur	x9, [x29, #-0xb0]
101472ae0: a97457b3    	ldp	x19, x21, [x29, #-0xc0]
101472ae4: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101472ae8: eb09027f    	cmp	x19, x9
101472aec: 54000061    	b.ne	0x101472af8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5768>
101472af0: aa1503f8    	mov	x24, x21
101472af4: 140000f4    	b	0x101472ec4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5b34>
101472af8: eb140369    	subs	x9, x27, x20
101472afc: 54002061    	b.ne	0x101472f08 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5b78>
101472b00: 3dc00100    	ldr	q0, [x8]
101472b04: 3d800380    	str	q0, [x28]
101472b08: f85503a8    	ldur	x8, [x29, #-0xb0]
101472b0c: f9000b88    	str	x8, [x28, #0x10]
101472b10: 140000ef    	b	0x101472ecc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5b3c>
101472b14: f85483b8    	ldur	x24, [x29, #-0xb8]
101472b18: 140000c9    	b	0x101472e3c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5aac>
101472b1c: aa1b03f4    	mov	x20, x27
101472b20: f94007ea    	ldr	x10, [sp, #0x8]
101472b24: 17ffffea    	b	0x101472acc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x573c>
101472b28: 52800148    	mov	w8, #0xa                ; =10
101472b2c: 381783a8    	sturb	w8, [x29, #-0x88]
101472b30: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472b34: 91122042    	add	x2, x2, #0x488
101472b38: d10223a0    	sub	x0, x29, #0x88
101472b3c: d101c3a1    	sub	x1, x29, #0x70
101472b40: 94190d3b    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472b44: 140000b3    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472b48: f9406be8    	ldr	x8, [sp, #0xd0]
101472b4c: a93823b3    	stp	x19, x8, [x29, #-0x80]
101472b50: 528000a8    	mov	w8, #0x5                ; =5
101472b54: 381783a8    	sturb	w8, [x29, #-0x88]
101472b58: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472b5c: 91122042    	add	x2, x2, #0x488
101472b60: d10223a0    	sub	x0, x29, #0x88
101472b64: d101c3a1    	sub	x1, x29, #0x70
101472b68: 94190d31    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472b6c: 140000a9    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472b70: 52800108    	mov	w8, #0x8                ; =8
101472b74: 381783a8    	sturb	w8, [x29, #-0x88]
101472b78: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472b7c: 91122042    	add	x2, x2, #0x488
101472b80: d10223a0    	sub	x0, x29, #0x88
101472b84: d101c3a1    	sub	x1, x29, #0x70
101472b88: 94190d29    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472b8c: 140000a1    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472b90: 52800108    	mov	w8, #0x8                ; =8
101472b94: 381783a8    	sturb	w8, [x29, #-0x88]
101472b98: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472b9c: 91122042    	add	x2, x2, #0x488
101472ba0: d10223a0    	sub	x0, x29, #0x88
101472ba4: d101c3a1    	sub	x1, x29, #0x70
101472ba8: 94190d21    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472bac: 14000099    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472bb0: f81803b3    	stur	x19, [x29, #-0x80]
101472bb4: 52800068    	mov	w8, #0x3                ; =3
101472bb8: 381783a8    	sturb	w8, [x29, #-0x88]
101472bbc: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472bc0: 91122042    	add	x2, x2, #0x488
101472bc4: d10223a0    	sub	x0, x29, #0x88
101472bc8: d101c3a1    	sub	x1, x29, #0x70
101472bcc: 94190d18    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472bd0: 14000090    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472bd4: 798187e8    	ldrsh	x8, [sp, #0xc2]
101472bd8: f81803a8    	stur	x8, [x29, #-0x80]
101472bdc: 52800048    	mov	w8, #0x2                ; =2
101472be0: 381783a8    	sturb	w8, [x29, #-0x88]
101472be4: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472be8: 91122042    	add	x2, x2, #0x488
101472bec: d10223a0    	sub	x0, x29, #0x88
101472bf0: d101c3a1    	sub	x1, x29, #0x70
101472bf4: 94190d0e    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472bf8: 14000086    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472bfc: f81803b3    	stur	x19, [x29, #-0x80]
101472c00: 52800028    	mov	w8, #0x1                ; =1
101472c04: 381783a8    	sturb	w8, [x29, #-0x88]
101472c08: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472c0c: 91122042    	add	x2, x2, #0x488
101472c10: d10223a0    	sub	x0, x29, #0x88
101472c14: d101c3a1    	sub	x1, x29, #0x70
101472c18: 94190d05    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472c1c: 1400007d    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472c20: b940c7e8    	ldr	w8, [sp, #0xc4]
101472c24: f81803a8    	stur	x8, [x29, #-0x80]
101472c28: 52800028    	mov	w8, #0x1                ; =1
101472c2c: 381783a8    	sturb	w8, [x29, #-0x88]
101472c30: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472c34: 91122042    	add	x2, x2, #0x488
101472c38: d10223a0    	sub	x0, x29, #0x88
101472c3c: d101c3a1    	sub	x1, x29, #0x70
101472c40: 94190cfb    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472c44: 14000073    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472c48: a94d27e8    	ldp	x8, x9, [sp, #0xd0]
101472c4c: a93827a8    	stp	x8, x9, [x29, #-0x80]
101472c50: 528000c8    	mov	w8, #0x6                ; =6
101472c54: 381783a8    	sturb	w8, [x29, #-0x88]
101472c58: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472c5c: 91122042    	add	x2, x2, #0x488
101472c60: d10223a0    	sub	x0, x29, #0x88
101472c64: d101c3a1    	sub	x1, x29, #0x70
101472c68: 94190cf1    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472c6c: 14000069    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472c70: 794187e8    	ldrh	w8, [sp, #0xc2]
101472c74: f81803a8    	stur	x8, [x29, #-0x80]
101472c78: 52800028    	mov	w8, #0x1                ; =1
101472c7c: 381783a8    	sturb	w8, [x29, #-0x88]
101472c80: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472c84: 91122042    	add	x2, x2, #0x488
101472c88: d10223a0    	sub	x0, x29, #0x88
101472c8c: d101c3a1    	sub	x1, x29, #0x70
101472c90: 94190ce7    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472c94: 1400005f    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472c98: f81803b3    	stur	x19, [x29, #-0x80]
101472c9c: 52800048    	mov	w8, #0x2                ; =2
101472ca0: 381783a8    	sturb	w8, [x29, #-0x88]
101472ca4: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472ca8: 91122042    	add	x2, x2, #0x488
101472cac: d10223a0    	sub	x0, x29, #0x88
101472cb0: d101c3a1    	sub	x1, x29, #0x70
101472cb4: 94190cde    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472cb8: 14000056    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472cbc: bd40c7e0    	ldr	s0, [sp, #0xc4]
101472cc0: 1e22c000    	fcvt	d0, s0
101472cc4: fc1803a0    	stur	d0, [x29, #-0x80]
101472cc8: 52800068    	mov	w8, #0x3                ; =3
101472ccc: 381783a8    	sturb	w8, [x29, #-0x88]
101472cd0: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472cd4: 91122042    	add	x2, x2, #0x488
101472cd8: d10223a0    	sub	x0, x29, #0x88
101472cdc: d101c3a1    	sub	x1, x29, #0x70
101472ce0: 94190cd3    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472ce4: 1400004b    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472ce8: 398307e8    	ldrsb	x8, [sp, #0xc1]
101472cec: f81803a8    	stur	x8, [x29, #-0x80]
101472cf0: 52800048    	mov	w8, #0x2                ; =2
101472cf4: 381783a8    	sturb	w8, [x29, #-0x88]
101472cf8: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472cfc: 91122042    	add	x2, x2, #0x488
101472d00: d10223a0    	sub	x0, x29, #0x88
101472d04: d101c3a1    	sub	x1, x29, #0x70
101472d08: 94190cc9    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472d0c: 14000041    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472d10: 528000e8    	mov	w8, #0x7                ; =7
101472d14: 381783a8    	sturb	w8, [x29, #-0x88]
101472d18: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472d1c: 91122042    	add	x2, x2, #0x488
101472d20: d10223a0    	sub	x0, x29, #0x88
101472d24: d101c3a1    	sub	x1, x29, #0x70
101472d28: 94190cc1    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472d2c: 14000039    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472d30: 394307e8    	ldrb	w8, [sp, #0xc1]
101472d34: 381793a8    	sturb	w8, [x29, #-0x87]
101472d38: 381783bf    	sturb	wzr, [x29, #-0x88]
101472d3c: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472d40: 91122042    	add	x2, x2, #0x488
101472d44: d10223a0    	sub	x0, x29, #0x88
101472d48: d101c3a1    	sub	x1, x29, #0x70
101472d4c: 94190cb8    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472d50: 14000030    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472d54: 394307e8    	ldrb	w8, [sp, #0xc1]
101472d58: f81803a8    	stur	x8, [x29, #-0x80]
101472d5c: 52800028    	mov	w8, #0x1                ; =1
101472d60: 381783a8    	sturb	w8, [x29, #-0x88]
101472d64: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472d68: 91122042    	add	x2, x2, #0x488
101472d6c: d10223a0    	sub	x0, x29, #0x88
101472d70: d101c3a1    	sub	x1, x29, #0x70
101472d74: 94190cae    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472d78: 14000026    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472d7c: b980c7e8    	ldrsw	x8, [sp, #0xc4]
101472d80: f81803a8    	stur	x8, [x29, #-0x80]
101472d84: 52800048    	mov	w8, #0x2                ; =2
101472d88: 381783a8    	sturb	w8, [x29, #-0x88]
101472d8c: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472d90: 91122042    	add	x2, x2, #0x488
101472d94: d10223a0    	sub	x0, x29, #0x88
101472d98: d101c3a1    	sub	x1, x29, #0x70
101472d9c: 94190ca4    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472da0: 1400001c    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472da4: 52800128    	mov	w8, #0x9                ; =9
101472da8: 381783a8    	sturb	w8, [x29, #-0x88]
101472dac: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472db0: 91122042    	add	x2, x2, #0x488
101472db4: d10223a0    	sub	x0, x29, #0x88
101472db8: d101c3a1    	sub	x1, x29, #0x70
101472dbc: 94190c9c    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472dc0: 14000014    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472dc4: f9406be8    	ldr	x8, [sp, #0xd0]
101472dc8: a93823b3    	stp	x19, x8, [x29, #-0x80]
101472dcc: 528000c8    	mov	w8, #0x6                ; =6
101472dd0: 381783a8    	sturb	w8, [x29, #-0x88]
101472dd4: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472dd8: 91122042    	add	x2, x2, #0x488
101472ddc: d10223a0    	sub	x0, x29, #0x88
101472de0: d101c3a1    	sub	x1, x29, #0x70
101472de4: 94190c92    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472de8: 1400000a    	b	0x101472e10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5a80>
101472dec: a94d27e8    	ldp	x8, x9, [sp, #0xd0]
101472df0: a93827a8    	stp	x8, x9, [x29, #-0x80]
101472df4: 528000a8    	mov	w8, #0x5                ; =5
101472df8: 381783a8    	sturb	w8, [x29, #-0x88]
101472dfc: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472e00: 91122042    	add	x2, x2, #0x488
101472e04: d10223a0    	sub	x0, x29, #0x88
101472e08: d101c3a1    	sub	x1, x29, #0x70
101472e0c: 94190c88    	bl	0x101ab602c <__ZN66_$LT$serde_json..error..Error$u20$as$u20$serde_core..de..Error$GT$12invalid_type17hbc5190ae298b2918E>
101472e10: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101472e14: a93403a8    	stp	x8, x0, [x29, #-0xc0]
101472e18: d10303a0    	sub	x0, x29, #0xc0
101472e1c: 97ff7a29    	bl	0x1014516c0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x4238>
101472e20: f0004360    	adrp	x0, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101472e24: 9124a000    	add	x0, x0, #0x928
101472e28: 52800841    	mov	w1, #0x42               ; =66
101472e2c: 9417e221    	bl	0x101a6b6b0 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17he5b52ce8130d4e41E+0x2bc>
101472e30: aa0003f8    	mov	x24, x0
101472e34: 910303e0    	add	x0, sp, #0xc0
101472e38: 97ff8555    	bl	0x10145438c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6f04>
101472e3c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101472e40: b4000353    	cbz	x19, 0x101472ea8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5b18>
101472e44: d2f00015    	mov	x21, #-0x8000000000000000 ; =-9223372036854775808
101472e48: aa1403f6    	mov	x22, x20
101472e4c: 14000007    	b	0x101472e68 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5ad8>
101472e50: f8686ac0    	ldr	x0, [x22, x8]
101472e54: 52800022    	mov	w2, #0x1                ; =1
101472e58: 97d8ae21    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101472e5c: 9100c2d6    	add	x22, x22, #0x30
101472e60: f1000673    	subs	x19, x19, #0x1
101472e64: 54000220    	b.eq	0x101472ea8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5b18>
101472e68: f94002c1    	ldr	x1, [x22]
101472e6c: eb15003f    	cmp	x1, x21
101472e70: 540000a1    	b.ne	0x101472e84 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5af4>
101472e74: f94006c1    	ldr	x1, [x22, #0x8]
101472e78: b4ffff21    	cbz	x1, 0x101472e5c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5acc>
101472e7c: 52800208    	mov	w8, #0x10               ; =16
101472e80: 17fffff4    	b	0x101472e50 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5ac0>
101472e84: b4000081    	cbz	x1, 0x101472e94 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5b04>
101472e88: f94006c0    	ldr	x0, [x22, #0x8]
101472e8c: 52800022    	mov	w2, #0x1                ; =1
101472e90: 97d8ae13    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101472e94: f9400ec1    	ldr	x1, [x22, #0x18]
101472e98: f240f83f    	tst	x1, #0x7fffffffffffffff
101472e9c: 54fffe00    	b.eq	0x101472e5c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5acc>
101472ea0: 52800408    	mov	w8, #0x20               ; =32
101472ea4: 17ffffeb    	b	0x101472e50 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5ac0>
101472ea8: f9401fe8    	ldr	x8, [sp, #0x38]
101472eac: b40000c8    	cbz	x8, 0x101472ec4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5b34>
101472eb0: 8b080508    	add	x8, x8, x8, lsl #1
101472eb4: d37ced01    	lsl	x1, x8, #4
101472eb8: aa1403e0    	mov	x0, x20
101472ebc: 52800102    	mov	w2, #0x8                ; =8
101472ec0: 97d8ae07    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101472ec4: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101472ec8: a9006388    	stp	x8, x24, [x28]
101472ecc: a95a7bfd    	ldp	x29, x30, [sp, #0x1a0]
101472ed0: a9594ff4    	ldp	x20, x19, [sp, #0x190]
101472ed4: a95857f6    	ldp	x22, x21, [sp, #0x180]
101472ed8: a9575ff8    	ldp	x24, x23, [sp, #0x170]
101472edc: a95667fa    	ldp	x26, x25, [sp, #0x160]
101472ee0: a9556ffc    	ldp	x28, x27, [sp, #0x150]
101472ee4: 9106c3ff    	add	sp, sp, #0x1b0
101472ee8: d65f03c0    	ret
101472eec: d0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101472ef0: 910fa042    	add	x2, x2, #0x3e8
101472ef4: aa0103e0    	mov	x0, x1
101472ef8: d101c3a1    	sub	x1, x29, #0x70
101472efc: 94187530    	bl	0x101a903bc <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17heef390515a9a8b1cE+0x200>
101472f00: aa0003f8    	mov	x24, x0
101472f04: 17fffff0    	b	0x101472ec4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5b34>
101472f08: f85503b4    	ldur	x20, [x29, #-0xb0]
101472f0c: 8b491540    	add	x0, x10, x9, lsr #5
101472f10: f9003bea    	str	x10, [sp, #0x70]
101472f14: 90006fc2    	adrp	x2, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
101472f18: 910fa042    	add	x2, x2, #0x3e8
101472f1c: 9101c3e1    	add	x1, sp, #0x70
101472f20: 94187022    	bl	0x101a8efa8 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0xc8>
101472f24: aa0003f8    	mov	x24, x0
101472f28: b4000354    	cbz	x20, 0x101472f90 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5c00>
101472f2c: d2f00016    	mov	x22, #-0x8000000000000000 ; =-9223372036854775808
101472f30: aa1503f7    	mov	x23, x21
101472f34: 14000007    	b	0x101472f50 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5bc0>
101472f38: f8686ae0    	ldr	x0, [x23, x8]
101472f3c: 52800022    	mov	w2, #0x1                ; =1
101472f40: 97d8ade7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101472f44: 9100c2f7    	add	x23, x23, #0x30
101472f48: f1000694    	subs	x20, x20, #0x1
101472f4c: 54000220    	b.eq	0x101472f90 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5c00>
101472f50: f94002e1    	ldr	x1, [x23]
101472f54: eb16003f    	cmp	x1, x22
101472f58: 540000a1    	b.ne	0x101472f6c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5bdc>
101472f5c: f94006e1    	ldr	x1, [x23, #0x8]
101472f60: b4ffff21    	cbz	x1, 0x101472f44 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5bb4>
101472f64: 52800208    	mov	w8, #0x10               ; =16
101472f68: 17fffff4    	b	0x101472f38 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5ba8>
101472f6c: b4000081    	cbz	x1, 0x101472f7c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5bec>
101472f70: f94006e0    	ldr	x0, [x23, #0x8]
101472f74: 52800022    	mov	w2, #0x1                ; =1
101472f78: 97d8add9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101472f7c: f9400ee1    	ldr	x1, [x23, #0x18]
101472f80: f240f83f    	tst	x1, #0x7fffffffffffffff
101472f84: 54fffe00    	b.eq	0x101472f44 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5bb4>
101472f88: 52800408    	mov	w8, #0x20               ; =32
101472f8c: 17ffffeb    	b	0x101472f38 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5ba8>
101472f90: b4fff9b3    	cbz	x19, 0x101472ec4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5b34>
101472f94: 8b130668    	add	x8, x19, x19, lsl #1
101472f98: d37ced01    	lsl	x1, x8, #4
101472f9c: aa1503e0    	mov	x0, x21
101472fa0: 17ffffc7    	b	0x101472ebc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5b2c>
101472fa4: 52800100    	mov	w0, #0x8                ; =8
101472fa8: aa1503e1    	mov	x1, x21
101472fac: 941940f2    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101472fb0: aa0003f3    	mov	x19, x0
101472fb4: d10303a0    	sub	x0, x29, #0xc0
101472fb8: 97ff8c9b    	bl	0x101456224 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8d9c>
101472fbc: aa1303e0    	mov	x0, x19
101472fc0: 94195985    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101472fc4: 1400000a    	b	0x101472fec <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5c5c>
101472fc8: 1400001f    	b	0x101473044 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5cb4>
101472fcc: 14000019    	b	0x101473030 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5ca0>
101472fd0: aa0003f3    	mov	x19, x0
101472fd4: 9101c3e0    	add	x0, sp, #0x70
101472fd8: 97ff87f6    	bl	0x101454fb0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7b28>
101472fdc: 9100e3e0    	add	x0, sp, #0x38
101472fe0: 97ff8c91    	bl	0x101456224 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8d9c>
101472fe4: aa1303e0    	mov	x0, x19
101472fe8: 9419597b    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101472fec: aa0003f3    	mov	x19, x0
101472ff0: d2800048    	mov	x8, #0x2                ; =2
101472ff4: f2f00008    	movk	x8, #0x8000, lsl #48
101472ff8: eb08037f    	cmp	x27, x8
101472ffc: 540000cb    	b.lt	0x101473014 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5c84>
101473000: b40000bb    	cbz	x27, 0x101473014 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5c84>
101473004: f9400be0    	ldr	x0, [sp, #0x10]
101473008: aa1b03e1    	mov	x1, x27
10147300c: 52800022    	mov	w2, #0x1                ; =1
101473010: 97d8adb3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101473014: f240fb3f    	tst	x25, #0x7fffffffffffffff
101473018: 540000e0    	b.eq	0x101473034 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5ca4>
10147301c: f94017e0    	ldr	x0, [sp, #0x28]
101473020: aa1903e1    	mov	x1, x25
101473024: 52800022    	mov	w2, #0x1                ; =1
101473028: 97d8adad    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147302c: 14000002    	b	0x101473034 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5ca4>
101473030: aa0003f3    	mov	x19, x0
101473034: 910303e0    	add	x0, sp, #0xc0
101473038: 97ff84d5    	bl	0x10145438c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6f04>
10147303c: 14000003    	b	0x101473048 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5cb8>
101473040: 94194339    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101473044: aa0003f3    	mov	x19, x0
101473048: 9100e3e0    	add	x0, sp, #0x38
10147304c: 97ff8c76    	bl	0x101456224 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8d9c>
101473050: aa1303e0    	mov	x0, x19
101473054: 94195960    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101473058: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10147305c: a90167fa    	stp	x26, x25, [sp, #0x10]
101473060: a9025ff8    	stp	x24, x23, [sp, #0x20]
101473064: a90357f6    	stp	x22, x21, [sp, #0x30]
101473068: a9044ff4    	stp	x20, x19, [sp, #0x40]
10147306c: a9057bfd    	stp	x29, x30, [sp, #0x50]
101473070: 910143fd    	add	x29, sp, #0x50
101473074: d10803ff    	sub	sp, sp, #0x200
101473078: aa0103f4    	mov	x20, x1
10147307c: aa0003f3    	mov	x19, x0
101473080: a9422029    	ldp	x9, x8, [x1, #0x20]
101473084: eb09011f    	cmp	x8, x9
101473088: 54000202    	b.hs	0x1014730c8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5d38>
10147308c: 9100c3f7    	add	x23, sp, #0x30
101473090: f9400e8a    	ldr	x10, [x20, #0x18]
101473094: 5280002b    	mov	w11, #0x1               ; =1
101473098: d284c00c    	mov	x12, #0x2600            ; =9728
10147309c: f2c0002c    	movk	x12, #0x1, lsl #32
1014730a0: 3868694d    	ldrb	w13, [x10, x8]
1014730a4: 710081bf    	cmp	w13, #0x20
1014730a8: 9acd216e    	lsl	x14, x11, x13
1014730ac: 8a0c01ce    	and	x14, x14, x12
1014730b0: fa4099c4    	ccmp	x14, #0x0, #0x4, ls
1014730b4: 54000160    	b.eq	0x1014730e0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5d50>
1014730b8: 91000508    	add	x8, x8, #0x1
1014730bc: f9001688    	str	x8, [x20, #0x28]
1014730c0: eb08013f    	cmp	x9, x8
1014730c4: 54fffee1    	b.ne	0x1014730a0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5d10>
1014730c8: 528000a8    	mov	w8, #0x5                ; =5
1014730cc: f9008be8    	str	x8, [sp, #0x110]
1014730d0: 910443e1    	add	x1, sp, #0x110
1014730d4: aa1403e0    	mov	x0, x20
1014730d8: 94187014    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
1014730dc: 1400009e    	b	0x101473354 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5fc4>
1014730e0: 71016dbf    	cmp	w13, #0x5b
1014730e4: 540013e1    	b.ne	0x101473360 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5fd0>
1014730e8: 3940c289    	ldrb	w9, [x20, #0x30]
1014730ec: 51000529    	sub	w9, w9, #0x1
1014730f0: 3900c289    	strb	w9, [x20, #0x30]
1014730f4: 72001d3f    	tst	w9, #0xff
1014730f8: 54001420    	b.eq	0x10147337c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5fec>
1014730fc: d280001a    	mov	x26, #0x0               ; =0
101473100: 91000508    	add	x8, x8, #0x1
101473104: f9001688    	str	x8, [x20, #0x28]
101473108: f90007f4    	str	x20, [sp, #0x8]
10147310c: 52800038    	mov	w24, #0x1               ; =1
101473110: 390043f8    	strb	w24, [sp, #0x10]
101473114: 52800116    	mov	w22, #0x8               ; =8
101473118: a901dbff    	stp	xzr, x22, [sp, #0x18]
10147311c: 910443fb    	add	x27, sp, #0x110
101473120: 9100c3fc    	add	x28, sp, #0x30
101473124: f90017ff    	str	xzr, [sp, #0x28]
101473128: 14000014    	b	0x101473178 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5de8>
10147312c: f94013f6    	ldr	x22, [sp, #0x20]
101473130: 8b1a02c8    	add	x8, x22, x26
101473134: ad4187e0    	ldp	q0, q1, [sp, #0x30]
101473138: ad000500    	stp	q0, q1, [x8]
10147313c: ad4287e0    	ldp	q0, q1, [sp, #0x50]
101473140: ad438fe2    	ldp	q2, q3, [sp, #0x70]
101473144: ad020d02    	stp	q2, q3, [x8, #0x40]
101473148: ad010500    	stp	q0, q1, [x8, #0x20]
10147314c: ad4306e0    	ldp	q0, q1, [x23, #0x60]
101473150: ad440ee2    	ldp	q2, q3, [x23, #0x80]
101473154: ad040d02    	stp	q2, q3, [x8, #0x80]
101473158: ad030500    	stp	q0, q1, [x8, #0x60]
10147315c: ad4506e0    	ldp	q0, q1, [x23, #0xa0]
101473160: ad460ee2    	ldp	q2, q3, [x23, #0xc0]
101473164: ad060d02    	stp	q2, q3, [x8, #0xc0]
101473168: ad050500    	stp	q0, q1, [x8, #0xa0]
10147316c: f90017f8    	str	x24, [sp, #0x28]
101473170: 91000718    	add	x24, x24, #0x1
101473174: 9103835a    	add	x26, x26, #0xe0
101473178: 910443e0    	add	x0, sp, #0x110
10147317c: 910023e1    	add	x1, sp, #0x8
101473180: 97ffe704    	bl	0x10146cd90 <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x5a4>
101473184: d1000719    	sub	x25, x24, #0x1
101473188: 394443e8    	ldrb	w8, [sp, #0x110]
10147318c: 7100051f    	cmp	w8, #0x1
101473190: 540003e0    	b.eq	0x10147320c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5e7c>
101473194: 394447e8    	ldrb	w8, [sp, #0x111]
101473198: 7100051f    	cmp	w8, #0x1
10147319c: 540005e1    	b.ne	0x101473258 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5ec8>
1014731a0: f94007e1    	ldr	x1, [sp, #0x8]
1014731a4: 910443e0    	add	x0, sp, #0x110
1014731a8: 97fef2cb    	bl	0x10142fcd4 <__ZN17otty_autocomplete4spec14CompletionSpec9is_hidden17hdc1d30ea3778a517E+0xe58>
1014731ac: a95157e8    	ldp	x8, x21, [sp, #0x110]
1014731b0: f100151f    	cmp	x8, #0x5
1014731b4: 540002e0    	b.eq	0x101473210 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5e80>
1014731b8: ad458760    	ldp	q0, q1, [x27, #0xb0]
1014731bc: ad058780    	stp	q0, q1, [x28, #0xb0]
1014731c0: 3ccd0360    	ldur	q0, [x27, #0xd0]
1014731c4: 3c8d0380    	stur	q0, [x28, #0xd0]
1014731c8: ad438760    	ldp	q0, q1, [x27, #0x70]
1014731cc: ad038780    	stp	q0, q1, [x28, #0x70]
1014731d0: ad448361    	ldp	q1, q0, [x27, #0x90]
1014731d4: ad048381    	stp	q1, q0, [x28, #0x90]
1014731d8: ad418760    	ldp	q0, q1, [x27, #0x30]
1014731dc: ad018780    	stp	q0, q1, [x28, #0x30]
1014731e0: ad428361    	ldp	q1, q0, [x27, #0x50]
1014731e4: ad028381    	stp	q1, q0, [x28, #0x50]
1014731e8: ad408361    	ldp	q1, q0, [x27, #0x10]
1014731ec: ad008381    	stp	q1, q0, [x28, #0x10]
1014731f0: a90357e8    	stp	x8, x21, [sp, #0x30]
1014731f4: f9400fe8    	ldr	x8, [sp, #0x18]
1014731f8: eb08033f    	cmp	x25, x8
1014731fc: 54fff9a1    	b.ne	0x101473130 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5da0>
101473200: 910063e0    	add	x0, sp, #0x18
101473204: 9418731e    	bl	0x101a8fe7c <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h2a2cd1f5df5bfae6E>
101473208: 17ffffc9    	b	0x10147312c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5d9c>
10147320c: f9408ff5    	ldr	x21, [sp, #0x118]
101473210: d280001a    	mov	x26, #0x0               ; =0
101473214: aa1603e0    	mov	x0, x22
101473218: eb1a033f    	cmp	x25, x26
10147321c: 540000c0    	b.eq	0x101473234 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5ea4>
101473220: 9100075a    	add	x26, x26, #0x1
101473224: 91038017    	add	x23, x0, #0xe0
101473228: 97ff8554    	bl	0x101454778 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x72f0>
10147322c: aa1703e0    	mov	x0, x23
101473230: 17fffffa    	b	0x101473218 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5e88>
101473234: f9400fe8    	ldr	x8, [sp, #0x18]
101473238: b40000c8    	cbz	x8, 0x101473250 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5ec0>
10147323c: d378dd09    	lsl	x9, x8, #8
101473240: cb081521    	sub	x1, x9, x8, lsl #5
101473244: aa1603e0    	mov	x0, x22
101473248: 52800102    	mov	w2, #0x8                ; =8
10147324c: 97d8ad24    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101473250: d2f00017    	mov	x23, #-0x8000000000000000 ; =-9223372036854775808
101473254: 14000003    	b	0x101473260 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5ed0>
101473258: f9400ff7    	ldr	x23, [sp, #0x18]
10147325c: aa1603f5    	mov	x21, x22
101473260: 3940c288    	ldrb	w8, [x20, #0x30]
101473264: 11000508    	add	w8, w8, #0x1
101473268: 3900c288    	strb	w8, [x20, #0x30]
10147326c: a91157f7    	stp	x23, x21, [sp, #0x110]
101473270: f90093f9    	str	x25, [sp, #0x120]
101473274: aa1403e0    	mov	x0, x20
101473278: 97fe45c8    	bl	0x101404998 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x394c>
10147327c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101473280: eb0802ff    	cmp	x23, x8
101473284: 54000180    	b.eq	0x1014732b4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5f24>
101473288: b50002e0    	cbnz	x0, 0x1014732e4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5f54>
10147328c: a9005677    	stp	x23, x21, [x19]
101473290: f9000a79    	str	x25, [x19, #0x10]
101473294: 910803ff    	add	sp, sp, #0x200
101473298: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10147329c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1014732a0: a94357f6    	ldp	x22, x21, [sp, #0x30]
1014732a4: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1014732a8: a94167fa    	ldp	x26, x25, [sp, #0x10]
1014732ac: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1014732b0: d65f03c0    	ret
1014732b4: b40004a0    	cbz	x0, 0x101473348 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5fb8>
1014732b8: f9400008    	ldr	x8, [x0]
1014732bc: f100051f    	cmp	x8, #0x1
1014732c0: 54000360    	b.eq	0x10147332c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5f9c>
1014732c4: aa0003f6    	mov	x22, x0
1014732c8: b5000388    	cbnz	x8, 0x101473338 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5fa8>
1014732cc: f9400ac1    	ldr	x1, [x22, #0x10]
1014732d0: b4000341    	cbz	x1, 0x101473338 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5fa8>
1014732d4: f94006c0    	ldr	x0, [x22, #0x8]
1014732d8: 52800022    	mov	w2, #0x1                ; =1
1014732dc: 97d8ad00    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014732e0: 14000016    	b	0x101473338 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5fa8>
1014732e4: aa0003f9    	mov	x25, x0
1014732e8: aa1503e0    	mov	x0, x21
1014732ec: f1000718    	subs	x24, x24, #0x1
1014732f0: 540000a0    	b.eq	0x101473304 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5f74>
1014732f4: 91038016    	add	x22, x0, #0xe0
1014732f8: 97ff8520    	bl	0x101454778 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x72f0>
1014732fc: aa1603e0    	mov	x0, x22
101473300: 17fffffb    	b	0x1014732ec <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5f5c>
101473304: b5000077    	cbnz	x23, 0x101473310 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5f80>
101473308: aa1903f5    	mov	x21, x25
10147330c: 1400000f    	b	0x101473348 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5fb8>
101473310: d378dee8    	lsl	x8, x23, #8
101473314: cb171501    	sub	x1, x8, x23, lsl #5
101473318: aa1503e0    	mov	x0, x21
10147331c: 52800102    	mov	w2, #0x8                ; =8
101473320: 97d8acef    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101473324: aa1903f5    	mov	x21, x25
101473328: 14000008    	b	0x101473348 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5fb8>
10147332c: aa0003f6    	mov	x22, x0
101473330: 91002000    	add	x0, x0, #0x8
101473334: 97ff7fd2    	bl	0x10145327c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5df4>
101473338: aa1603e0    	mov	x0, x22
10147333c: 52800501    	mov	w1, #0x28               ; =40
101473340: 52800102    	mov	w2, #0x8                ; =8
101473344: 97d8ace6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101473348: aa1503e0    	mov	x0, x21
10147334c: aa1403e1    	mov	x1, x20
101473350: 9418715b    	bl	0x101a8f8bc <__ZN10serde_json2de21Deserializer$LT$R$GT$23parse_exponent_overflow17h8d2c34d8b104f113E+0x130>
101473354: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101473358: a9000268    	stp	x8, x0, [x19]
10147335c: 17ffffce    	b	0x101473294 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5f04>
101473360: b0006fa2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101473364: 9114e042    	add	x2, x2, #0x538
101473368: d10167a1    	sub	x1, x29, #0x59
10147336c: aa1403e0    	mov	x0, x20
101473370: 94186f82    	bl	0x101a8f178 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x298>
101473374: aa0003f5    	mov	x21, x0
101473378: 17fffff4    	b	0x101473348 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5fb8>
10147337c: 52800308    	mov	w8, #0x18               ; =24
101473380: 17ffff53    	b	0x1014730cc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x5d3c>
101473384: aa0003f3    	mov	x19, x0
101473388: aa1603e0    	mov	x0, x22
10147338c: 52800501    	mov	w1, #0x28               ; =40
101473390: 52800102    	mov	w2, #0x8                ; =8
101473394: 97d8acd2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101473398: aa1303e0    	mov	x0, x19
10147339c: 9419588e    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014733a0: aa0003f3    	mov	x19, x0
1014733a4: 910443e0    	add	x0, sp, #0x110
1014733a8: 97ff7aca    	bl	0x101451ed0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x4a48>
1014733ac: 14000028    	b	0x10147344c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x60bc>
1014733b0: 9419425d    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014733b4: aa0003f3    	mov	x19, x0
1014733b8: 9100c3e0    	add	x0, sp, #0x30
1014733bc: 97ff84ef    	bl	0x101454778 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x72f0>
1014733c0: 14000016    	b	0x101473418 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x6088>
1014733c4: 94194258    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014733c8: aa0003f3    	mov	x19, x0
1014733cc: cb1a0314    	sub	x20, x24, x26
1014733d0: f1000694    	subs	x20, x20, #0x1
1014733d4: 540000c0    	b.eq	0x1014733ec <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x605c>
1014733d8: 910382f5    	add	x21, x23, #0xe0
1014733dc: aa1703e0    	mov	x0, x23
1014733e0: 97ff84e6    	bl	0x101454778 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x72f0>
1014733e4: aa1503f7    	mov	x23, x21
1014733e8: 17fffffa    	b	0x1014733d0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x6040>
1014733ec: f9400fe8    	ldr	x8, [sp, #0x18]
1014733f0: b40002e8    	cbz	x8, 0x10147344c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x60bc>
1014733f4: d378dd09    	lsl	x9, x8, #8
1014733f8: cb081521    	sub	x1, x9, x8, lsl #5
1014733fc: aa1603e0    	mov	x0, x22
101473400: 52800102    	mov	w2, #0x8                ; =8
101473404: 97d8acb6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101473408: aa1303e0    	mov	x0, x19
10147340c: 94195872    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101473410: 94194245    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101473414: aa0003f3    	mov	x19, x0
101473418: 910063e0    	add	x0, sp, #0x18
10147341c: 97ff8aad    	bl	0x101455ed0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8a48>
101473420: 1400000b    	b	0x10147344c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x60bc>
101473424: 94194240    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101473428: aa0003f3    	mov	x19, x0
10147342c: f1000718    	subs	x24, x24, #0x1
101473430: 540000c0    	b.eq	0x101473448 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x60b8>
101473434: 910382d4    	add	x20, x22, #0xe0
101473438: aa1603e0    	mov	x0, x22
10147343c: 97ff84cf    	bl	0x101454778 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x72f0>
101473440: aa1403f6    	mov	x22, x20
101473444: 17fffffa    	b	0x10147342c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x609c>
101473448: b5000077    	cbnz	x23, 0x101473454 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x60c4>
10147344c: aa1303e0    	mov	x0, x19
101473450: 94195861    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101473454: d378dee8    	lsl	x8, x23, #8
101473458: cb171501    	sub	x1, x8, x23, lsl #5
10147345c: aa1503e0    	mov	x0, x21
101473460: 52800102    	mov	w2, #0x8                ; =8
101473464: 97d8ac9e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101473468: aa1303e0    	mov	x0, x19
10147346c: 9419585a    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101473470: 9419422d    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101473474: d101c3ff    	sub	sp, sp, #0x70
101473478: a9035ff8    	stp	x24, x23, [sp, #0x30]
10147347c: a90457f6    	stp	x22, x21, [sp, #0x40]
101473480: a9054ff4    	stp	x20, x19, [sp, #0x50]
101473484: a9067bfd    	stp	x29, x30, [sp, #0x60]
