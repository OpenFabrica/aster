
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001001964f8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg>:
1001967d0: 913e8000    	add	x0, x0, #0xfa0
1001967d4: d65f03c0    	ret
1001967d8: b000ca80    	adrp	x0, 0x101ae7000 <_$s4Otty16SleepHelperNamesO9plistNameSSvpZMV+0x10a0>
1001967dc: 913ea000    	add	x0, x0, #0xfa8
1001967e0: d65f03c0    	ret
1001967e4: d2e80dc8    	mov	x8, #0x406e000000000000 ; =4642648265865560064
1001967e8: 9e670100    	fmov	d0, x8
1001967ec: d65f03c0    	ret
1001967f0: b000ca80    	adrp	x0, 0x101ae7000 <_$s4Otty16SleepHelperNamesO9plistNameSSvpZMV+0x10a0>
1001967f4: 913ec000    	add	x0, x0, #0xfb0
1001967f8: d65f03c0    	ret
1001967fc: b000ca80    	adrp	x0, 0x101ae7000 <_$s4Otty16SleepHelperNamesO9plistNameSSvpZMV+0x10a0>
100196800: 913ee000    	add	x0, x0, #0xfb8
100196804: d65f03c0    	ret
100196808: b000ca80    	adrp	x0, 0x101ae7000 <_$s4Otty16SleepHelperNamesO9plistNameSSvpZMV+0x10a0>
10019680c: 913f0000    	add	x0, x0, #0xfc0
100196810: d65f03c0    	ret
100196814: a9bf7bfd    	stp	x29, x30, [sp, #-0x10]!
100196818: 910003fd    	mov	x29, sp
10019681c: f9400a80    	ldr	x0, [x20, #0x10]
100196820: b4000040    	cbz	x0, 0x100196828 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x330>
100196824: 9464e227    	bl	0x101acf0c0 <_writev+0x101acf0c0>
100196828: a8c17bfd    	ldp	x29, x30, [sp], #0x10
10019682c: d65f03c0    	ret
100196830: d10583ff    	sub	sp, sp, #0x160
100196834: a9125ff8    	stp	x24, x23, [sp, #0x120]
100196838: a91357f6    	stp	x22, x21, [sp, #0x130]
10019683c: a9144ff4    	stp	x20, x19, [sp, #0x140]
100196840: a9157bfd    	stp	x29, x30, [sp, #0x150]
100196844: 910543fd    	add	x29, sp, #0x150
100196848: aa0803f3    	mov	x19, x8
10019684c: 9100c280    	add	x0, x20, #0x30
100196850: d10123a1    	sub	x1, x29, #0x48
100196854: d2800002    	mov	x2, #0x0                ; =0
100196858: d2800003    	mov	x3, #0x0                ; =0
10019685c: 9464cf69    	bl	0x101aca600 <_writev+0x101aca600>
100196860: f9401a88    	ldr	x8, [x20, #0x30]
100196864: b7f80388    	tbnz	x8, #0x3f, 0x1001968d4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3dc>
100196868: f9401689    	ldr	x9, [x20, #0x28]
10019686c: f940092a    	ldr	x10, [x9, #0x10]
100196870: eb0a011f    	cmp	x8, x10
100196874: 54000302    	b.hs	0x1001968d4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3dc>
100196878: 52800c0a    	mov	w10, #0x60              ; =96
10019687c: 9b0a2508    	madd	x8, x8, x10, x9
100196880: ad410500    	ldp	q0, q1, [x8, #0x20]
100196884: ad0507e0    	stp	q0, q1, [sp, #0xa0]
100196888: 3cc69100    	ldur	q0, [x8, #0x69]
10019688c: ad428503    	ldp	q3, q1, [x8, #0x50]
100196890: 3dc01102    	ldr	q2, [x8, #0x40]
100196894: ad060fe2    	stp	q2, q3, [sp, #0xc0]
100196898: 3d803be1    	str	q1, [sp, #0xe0]
10019689c: 3c8e93e0    	stur	q0, [sp, #0xe9]
1001968a0: ad4507e0    	ldp	q0, q1, [sp, #0xa0]
1001968a4: ad0107e0    	stp	q0, q1, [sp, #0x20]
1001968a8: ad4607e0    	ldp	q0, q1, [sp, #0xc0]
1001968ac: ad0007e0    	stp	q0, q1, [sp]
1001968b0: a94e57f4    	ldp	x20, x21, [sp, #0xe0]
1001968b4: f9407bf6    	ldr	x22, [sp, #0xf0]
1001968b8: 3943e3f7    	ldrb	w23, [sp, #0xf8]
1001968bc: 910283e0    	add	x0, sp, #0xa0
1001968c0: 910103e1    	add	x1, sp, #0x40
1001968c4: 97ff10b5    	bl	0x10015ab98 <_$s11_RopeModule0A0V7BuilderV12_prefixTreesSayACyxGGvg+0x50c8>
1001968c8: ad400fe2    	ldp	q2, q3, [sp]
1001968cc: ad4107e0    	ldp	q0, q1, [sp, #0x20]
1001968d0: 14000009    	b	0x1001968f4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3fc>
1001968d4: d2800014    	mov	x20, #0x0               ; =0
1001968d8: d2800015    	mov	x21, #0x0               ; =0
1001968dc: d2800016    	mov	x22, #0x0               ; =0
1001968e0: 52800017    	mov	w23, #0x0               ; =0
1001968e4: 6f00e400    	movi.2d	v0, #0000000000000000
1001968e8: 6f00e401    	movi.2d	v1, #0000000000000000
1001968ec: 6f00e402    	movi.2d	v2, #0000000000000000
1001968f0: 6f00e403    	movi.2d	v3, #0000000000000000
1001968f4: ad000660    	stp	q0, q1, [x19]
1001968f8: ad010e62    	stp	q2, q3, [x19, #0x20]
1001968fc: a9045674    	stp	x20, x21, [x19, #0x40]
100196900: f9002a76    	str	x22, [x19, #0x50]
100196904: 39016277    	strb	w23, [x19, #0x58]
100196908: a9557bfd    	ldp	x29, x30, [sp, #0x150]
10019690c: a9544ff4    	ldp	x20, x19, [sp, #0x140]
100196910: a95357f6    	ldp	x22, x21, [sp, #0x130]
100196914: a9525ff8    	ldp	x24, x23, [sp, #0x120]
100196918: 910583ff    	add	sp, sp, #0x160
10019691c: d65f03c0    	ret
100196920: 6db733ed    	stp	d13, d12, [sp, #-0x90]!
100196924: 6d012beb    	stp	d11, d10, [sp, #0x10]
100196928: 6d0223e9    	stp	d9, d8, [sp, #0x20]
10019692c: a9036ffc    	stp	x28, x27, [sp, #0x30]
100196930: a90467fa    	stp	x26, x25, [sp, #0x40]
100196934: a9055ff8    	stp	x24, x23, [sp, #0x50]
100196938: a90657f6    	stp	x22, x21, [sp, #0x60]
10019693c: a9074ff4    	stp	x20, x19, [sp, #0x70]
100196940: a9087bfd    	stp	x29, x30, [sp, #0x80]
100196944: 910203fd    	add	x29, sp, #0x80
100196948: d10603ff    	sub	sp, sp, #0x180
10019694c: aa1403fa    	mov	x26, x20
100196950: f9400813    	ldr	x19, [x0, #0x10]
100196954: b40002d3    	cbz	x19, 0x1001969ac <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x4b4>
100196958: aa0203f4    	mov	x20, x2
10019695c: 4ea21c4b    	mov.16b	v11, v2
100196960: 4ea11c29    	mov.16b	v9, v1
100196964: 4ea01c0a    	mov.16b	v10, v0
100196968: aa0103f7    	mov	x23, x1
10019696c: aa0003f5    	mov	x21, x0
100196970: aa0103e0    	mov	x0, x1
100196974: 9464fe23    	bl	0x101ad6200 <_writev+0x101ad6200>
100196978: aa1d03fd    	mov	x29, x29
10019697c: 9464ccf6    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100196980: b4000160    	cbz	x0, 0x1001969ac <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x4b4>
100196984: aa0003f8    	mov	x24, x0
100196988: 9464e1ce    	bl	0x101acf0c0 <_writev+0x101acf0c0>
10019698c: 34000dc0    	cbz	w0, 0x100196b44 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x64c>
100196990: aa1803e0    	mov	x0, x24
100196994: 9464d3b3    	bl	0x101acb860 <_writev+0x101acb860>
100196998: aa1d03fd    	mov	x29, x29
10019699c: 9464ccee    	bl	0x101ac9d54 <_writev+0x101ac9d54>
1001969a0: b40001c0    	cbz	x0, 0x1001969d8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x4e0>
1001969a4: 9464cce3    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001969a8: 14000067    	b	0x100196b44 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x64c>
1001969ac: 910603ff    	add	sp, sp, #0x180
1001969b0: a9487bfd    	ldp	x29, x30, [sp, #0x80]
1001969b4: a9474ff4    	ldp	x20, x19, [sp, #0x70]
1001969b8: a94657f6    	ldp	x22, x21, [sp, #0x60]
1001969bc: a9455ff8    	ldp	x24, x23, [sp, #0x50]
1001969c0: a94467fa    	ldp	x26, x25, [sp, #0x40]
1001969c4: a9436ffc    	ldp	x28, x27, [sp, #0x30]
1001969c8: 6d4223e9    	ldp	d9, d8, [sp, #0x20]
1001969cc: 6d412beb    	ldp	d11, d10, [sp, #0x10]
