1004b6770:	blr	x8
1004b6774:	mov	x0, x21
1004b6778:	mov	x2, x22
1004b677c:	bl	0x101acb460 ; selector addSubview:
1004b6780:	add	x0, x19, x28
1004b6784:	add	x1, sp, #0x8
1004b6788:	mov	w2, #0x21
1004b678c:	mov	x3, #0x0
1004b6790:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b6794:	add	x20, x19, x28
1004b6798:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b679c:	ldr	x8, [x19, x28]
1004b67a0:	and	x8, x8, #0xffffffffffffff8
1004b67a4:	ldp	x21, x8, [x8, #0x10]
1004b67a8:	cmp	x21, x8, lsr #1
1004b67ac:	b.hs	0x1004b684c
1004b67b0:	mov	x0, x22
1004b67b4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b67b8:	mov	x22, x0
1004b67bc:	add	x20, x19, x28
1004b67c0:	mov	x0, x21
1004b67c4:	mov	x1, x22
1004b67c8:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b67cc:	add	x0, sp, #0x8
1004b67d0:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b67d4:	mov	x0, x22
1004b67d8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b67dc:	mov	x0, x24
1004b67e0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b67e4:	fmov	d0, #28.00000000
1004b67e8:	fadd	d0, d8, d0
1004b67ec:	ldp	x29, x30, [sp, #0x90]
1004b67f0:	ldp	x20, x19, [sp, #0x80]
1004b67f4:	ldp	x22, x21, [sp, #0x70]
1004b67f8:	ldp	x24, x23, [sp, #0x60]
1004b67fc:	ldp	x26, x25, [sp, #0x50]
1004b6800:	ldp	x28, x27, [sp, #0x40]
1004b6804:	ldp	d9, d8, [sp, #0x30]
1004b6808:	ldp	d11, d10, [sp, #0x20]
1004b680c:	add	sp, sp, #0xa0
1004b6810:	ret
1004b6814:	cmp	x8, #0x1
1004b6818:	cset	w0, hi
1004b681c:	add	x1, x27, #0x1
1004b6820:	add	x20, x19, x28
1004b6824:	mov	w2, #0x1
1004b6828:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b682c:	b	0x1004b6544
1004b6830:	cmp	x8, #0x1
1004b6834:	cset	w0, hi
1004b6838:	add	x1, x27, #0x1
1004b683c:	add	x20, x19, x28
1004b6840:	mov	w2, #0x1
1004b6844:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b6848:	b	0x1004b6690
1004b684c:	cmp	x8, #0x1
1004b6850:	cset	w0, hi
1004b6854:	add	x1, x21, #0x1
1004b6858:	add	x20, x19, x28
1004b685c:	mov	w2, #0x1
1004b6860:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b6864:	b	0x1004b67b0
1004b6868:	stp	x28, x27, [sp, #-0x60]!
1004b686c:	stp	x26, x25, [sp, #0x10]
1004b6870:	stp	x24, x23, [sp, #0x20]
1004b6874:	stp	x22, x21, [sp, #0x30]
1004b6878:	stp	x20, x19, [sp, #0x40]
1004b687c:	stp	x29, x30, [sp, #0x50]
1004b6880:	add	x29, sp, #0x50
1004b6884:	sub	sp, sp, #0x1d0
1004b6888:	mov	x19, sp
1004b688c:	stp	x2, x3, [x19, #0x70]
1004b6890:	mov	x22, x1
1004b6894:	mov	x27, x0
1004b6898:	mov	w24, #0x2d2d
1004b689c:	movk	w24, #0x2d, lsl #16
1004b68a0:	mov	x0, #0x0
1004b68a4:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004b68a8:	mov	x23, x0
1004b68ac:	ldur	x8, [x0, #-0x8]
1004b68b0:	str	x8, [x19, #0x50]
1004b68b4:	ldr	x20, [x8, #0x40]
1004b68b8:	mov	x9, x20
1004b68bc:	adrp	x16, 7701 ; 0x1022cb000
1004b68c0:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b68c4:	blr	x16
1004b68c8:	mov	x8, sp
1004b68cc:	add	x9, x20, #0xf
1004b68d0:	and	x12, x9, #0xfffffffffffffff0
1004b68d4:	sub	x8, x8, x12
1004b68d8:	str	x8, [x19, #0x8]
1004b68dc:	mov	sp, x8
1004b68e0:	mov	x9, x20
1004b68e4:	adrp	x16, 7701 ; 0x1022cb000
1004b68e8:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b68ec:	blr	x16
1004b68f0:	mov	x8, sp
1004b68f4:	sub	x21, x8, x12
1004b68f8:	mov	sp, x21
1004b68fc:	mov	x9, x20
1004b6900:	adrp	x16, 7701 ; 0x1022cb000
1004b6904:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b6908:	blr	x16
1004b690c:	mov	x8, sp
1004b6910:	sub	x8, x8, x12
1004b6914:	str	x8, [x19, #0x20]
1004b6918:	mov	sp, x8
1004b691c:	mov	x9, x20
1004b6920:	adrp	x16, 7701 ; 0x1022cb000
1004b6924:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b6928:	blr	x16
1004b692c:	mov	x8, sp
1004b6930:	sub	x8, x8, x12
1004b6934:	str	x8, [x19, #0x18]
1004b6938:	mov	sp, x8
1004b693c:	adrp	x0, 7821 ; 0x102343000
1004b6940:	add	x0, x0, #0x230
1004b6944:	adrp	x1, 5677 ; 0x101ae3000
1004b6948:	add	x1, x1, #0x460
1004b694c:	bl	0x100003c4c
1004b6950:	str	x0, [x19, #0x40]
1004b6954:	ldur	x8, [x0, #-0x8]
1004b6958:	ldr	x9, [x8, #0x40]
1004b695c:	add	x8, x9, #0xf
1004b6960:	and	x8, x8, #0xfffffffffffffff0
1004b6964:	adrp	x16, 7701 ; 0x1022cb000
1004b6968:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b696c:	blr	x16
1004b6970:	mov	x9, sp
1004b6974:	sub	x25, x9, x8
1004b6978:	mov	sp, x25
1004b697c:	adrp	x0, 7821 ; 0x102343000
1004b6980:	add	x0, x0, #0x20
1004b6984:	adrp	x1, 5676 ; 0x101ae2000
1004b6988:	add	x1, x1, #0x680
1004b698c:	bl	0x100003c4c
1004b6990:	ldur	x8, [x0, #-0x8]
1004b6994:	ldr	x8, [x8, #0x40]
1004b6998:	mov	x9, x8
1004b699c:	adrp	x16, 7701 ; 0x1022cb000
1004b69a0:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b69a4:	blr	x16
1004b69a8:	mov	x9, sp
1004b69ac:	add	x10, x8, #0xf
1004b69b0:	and	x12, x10, #0xfffffffffffffff0
1004b69b4:	sub	x9, x9, x12
1004b69b8:	str	x9, [x19, #0x30]
1004b69bc:	mov	sp, x9
1004b69c0:	mov	x9, x8
1004b69c4:	adrp	x16, 7701 ; 0x1022cb000
1004b69c8:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b69cc:	blr	x16
1004b69d0:	mov	x9, sp
1004b69d4:	sub	x9, x9, x12
1004b69d8:	str	x9, [x19, #0x88]
1004b69dc:	mov	sp, x9
1004b69e0:	mov	x9, x8
1004b69e4:	adrp	x16, 7701 ; 0x1022cb000
1004b69e8:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b69ec:	blr	x16
1004b69f0:	mov	x8, sp
1004b69f4:	sub	x26, x8, x12
1004b69f8:	mov	sp, x26
1004b69fc:	ldr	x10, [x27, #0x8]
1004b6a00:	stp	x23, x10, [x19, #0x58]
1004b6a04:	str	x21, [x19, #0x10]
1004b6a08:	str	x20, [x19]
1004b6a0c:	str	x25, [x19, #0x80]
1004b6a10:	str	x26, [x19, #0x48]
1004b6a14:	str	x27, [x19, #0x38]
1004b6a18:	cbz	x10, 0x1004b6a84
1004b6a1c:	add	x8, x19, #0x118
1004b6a20:	ldr	x9, [x27]
1004b6a24:	stp	x9, x10, [x19, #0x118]
1004b6a28:	ldp	q0, q1, [x27, #0x30]
1004b6a2c:	stp	q0, q1, [x8, #0x30]
1004b6a30:	ldrb	w9, [x27, #0x50]
1004b6a34:	strb	w9, [x19, #0x168]
1004b6a38:	ldp	q1, q0, [x27, #0x10]
1004b6a3c:	stp	q1, q0, [x8, #0x10]
1004b6a40:	ldr	q0, [x8]
1004b6a44:	stp	q0, q0, [x29, #-0xb0]
1004b6a48:	ldrb	w8, [x19, #0x128]
1004b6a4c:	tbz	w8, #0x0, 0x1004b6a90
1004b6a50:	sub	x0, x29, #0xb0
1004b6a54:	add	x1, x19, #0x100
1004b6a58:	bl	0x1000589e8
1004b6a5c:	mov	x0, #0x2820
1004b6a60:	movk	x0, #0x6f77, lsl #16
1004b6a64:	movk	x0, #0x6b72, lsl #32
1004b6a68:	movk	x0, #0x7274, lsl #48
1004b6a6c:	mov	x1, #0x6565
1004b6a70:	movk	x1, #0x29, lsl #16
1004b6a74:	movk	x1, #0xeb00, lsl #48
1004b6a78:	sub	x20, x29, #0xa0
1004b6a7c:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004b6a80:	b	0x1004b6a9c
1004b6a84:	adrp	x28, 7705 ; 0x1022cf000
1004b6a88:	ldr	x28, [x28, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004b6a8c:	b	0x1004b6bc4
1004b6a90:	sub	x0, x29, #0xb0
1004b6a94:	add	x1, x19, #0x100
1004b6a98:	bl	0x1000589e8
1004b6a9c:	add	x20, x19, #0x118
1004b6aa0:	bl	0x1005903c4
1004b6aa4:	mov	x20, x0
1004b6aa8:	mov	x21, x1
1004b6aac:	mov	x0, x1
1004b6ab0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b6ab4:	and	x8, x20, #0xffffffffffff
1004b6ab8:	ubfx	x9, x21, #56, #4
1004b6abc:	tst	x21, #0x2000000000000000
1004b6ac0:	csel	x8, x8, x9, eq
1004b6ac4:	cbz	x8, 0x1004b6b10
1004b6ac8:	add	x20, x19, #0x118
1004b6acc:	bl	0x1005903c4
1004b6ad0:	mov	x21, x1
1004b6ad4:	mov	x8, #0x2020
1004b6ad8:	movk	x8, #0xb7c2, lsl #16
1004b6adc:	movk	x8, #0x2020, lsl #32
1004b6ae0:	mov	x9, #-0x5a00000000000000
1004b6ae4:	stp	x8, x9, [x19, #0x100]
1004b6ae8:	add	x20, x19, #0x100
1004b6aec:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004b6af0:	mov	x0, x21
1004b6af4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b6af8:	ldp	x0, x21, [x19, #0x100]
1004b6afc:	sub	x20, x29, #0xa0
1004b6b00:	mov	x1, x21
1004b6b04:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004b6b08:	mov	x0, x21
1004b6b0c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b6b10:	ldp	x25, x20, [x29, #-0xa0]
1004b6b14:	bl	0x1004a9938
1004b6b18:	ldp	x26, x27, [x0]
1004b6b1c:	mov	x0, x27
1004b6b20:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b6b24:	mov	x0, x20
1004b6b28:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b6b2c:	adrp	x3, 7705 ; 0x1022cf000
1004b6b30:	ldr	x3, [x3, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004b6b34:	adrp	x4, 7705 ; 0x1022cf000
1004b6b38:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b6b3c:	mov	w0, #0x0
1004b6b40:	mov	w1, #0x1
1004b6b44:	mov	w2, #0x1
1004b6b48:	bl	0x1004bfb6c
1004b6b4c:	mov	x28, x0
1004b6b50:	ldp	x23, x8, [x0, #0x10]
1004b6b54:	lsr	x9, x8, #1
1004b6b58:	add	x21, x23, #0x1
1004b6b5c:	cmp	x9, x23
1004b6b60:	b.ls	0x1004b7a7c
1004b6b64:	str	x21, [x28, #0x10]
1004b6b68:	mov	w10, #0x38
1004b6b6c:	madd	x10, x23, x10, x28
1004b6b70:	stp	x25, x20, [x10, #0x20]
1004b6b74:	adrp	x11, -1203 ; 0x100003000
1004b6b78:	add	x11, x11, #0xf40
1004b6b7c:	stp	x26, x27, [x10, #0x30]
1004b6b80:	stp	xzr, x11, [x10, #0x40]
1004b6b84:	str	xzr, [x10, #0x50]
1004b6b88:	add	x27, x23, #0x2
1004b6b8c:	cmp	x9, x27
1004b6b90:	b.lt	0x1004b7aac
1004b6b94:	str	x27, [x28, #0x10]
1004b6b98:	mov	w8, #0x38
1004b6b9c:	madd	x8, x21, x8, x28
1004b6ba0:	mov	x9, #-0x1d00000000000000
1004b6ba4:	stp	x24, x9, [x8, #0x20]
1004b6ba8:	stp	xzr, xzr, [x8, #0x30]
1004b6bac:	adrp	x9, -1203 ; 0x100003000
1004b6bb0:	add	x9, x9, #0xf40
1004b6bb4:	stp	xzr, x9, [x8, #0x40]
1004b6bb8:	str	xzr, [x8, #0x50]
1004b6bbc:	mov	x0, x20
1004b6bc0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b6bc4:	adrp	x0, 7460 ; 0x1021da000
1004b6bc8:	add	x0, x0, #0x978
1004b6bcc:	mov	w1, #0x18
1004b6bd0:	mov	w2, #0x7
1004b6bd4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b6bd8:	mov	x20, x0
1004b6bdc:	add	x0, x22, #0x10
1004b6be0:	add	x1, x19, #0x100
1004b6be4:	mov	x2, #0x0
1004b6be8:	mov	x3, #0x0
1004b6bec:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b6bf0:	add	x0, x22, #0x10
1004b6bf4:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004b6bf8:	mov	x21, x0
1004b6bfc:	add	x0, x20, #0x10
1004b6c00:	mov	x1, x21
1004b6c04:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b6c08:	mov	x0, x21
1004b6c0c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6c10:	adrp	x0, 7461 ; 0x1021db000
1004b6c14:	add	x0, x0, #0xd50
1004b6c18:	mov	w1, #0x28
1004b6c1c:	mov	w2, #0x7
1004b6c20:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b6c24:	mov	x27, x0
1004b6c28:	ldp	x8, x23, [x19, #0x70]
1004b6c2c:	stp	x20, x8, [x0, #0x10]
1004b6c30:	str	x23, [x0, #0x20]
1004b6c34:	adrp	x0, 7461 ; 0x1021db000
1004b6c38:	add	x0, x0, #0xd78
1004b6c3c:	mov	w1, #0x20
1004b6c40:	mov	w2, #0x7
1004b6c44:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b6c48:	mov	x21, x0
1004b6c4c:	adrp	x8, 16 ; 0x1004c6000
1004b6c50:	add	x8, x8, #0x16c
1004b6c54:	stp	x8, x27, [x0, #0x10]
1004b6c58:	mov	x0, x20
1004b6c5c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b6c60:	mov	x0, x23
1004b6c64:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b6c68:	mov	x0, x28
1004b6c6c:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004b6c70:	tbz	w0, #0x0, 0x1004b78bc
1004b6c74:	ldp	x23, x8, [x28, #0x10]
1004b6c78:	add	x27, x23, #0x1
1004b6c7c:	cmp	x23, x8, lsr #1
1004b6c80:	b.hs	0x1004b78e4
1004b6c84:	mov	x10, #0x2e
1004b6c88:	movk	x10, #0xe900, lsl #48
1004b6c8c:	str	x27, [x28, #0x10]
1004b6c90:	mov	w8, #0x38
1004b6c94:	madd	x8, x23, x8, x28
1004b6c98:	mov	x9, #0x6f43
1004b6c9c:	movk	x9, #0x6d6d, lsl #16
1004b6ca0:	movk	x9, #0x7469, lsl #32
1004b6ca4:	movk	x9, #0x2e2e, lsl #48
1004b6ca8:	stp	x9, x10, [x8, #0x20]
1004b6cac:	stp	xzr, xzr, [x8, #0x30]
1004b6cb0:	adrp	x9, -1202 ; 0x100004000
1004b6cb4:	add	x9, x9, #0xcc
1004b6cb8:	stp	xzr, x9, [x8, #0x40]
1004b6cbc:	str	x21, [x8, #0x50]
1004b6cc0:	mov	x0, x20
1004b6cc4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b6cc8:	adrp	x0, 7460 ; 0x1021da000
1004b6ccc:	add	x0, x0, #0x978
1004b6cd0:	mov	w1, #0x18
1004b6cd4:	mov	w2, #0x7
1004b6cd8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b6cdc:	mov	x20, x0
1004b6ce0:	add	x0, x22, #0x10
1004b6ce4:	add	x1, x19, #0xe8
1004b6ce8:	mov	x2, #0x0
1004b6cec:	mov	x3, #0x0
1004b6cf0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b6cf4:	add	x0, x22, #0x10
1004b6cf8:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004b6cfc:	mov	x21, x0
1004b6d00:	add	x0, x20, #0x10
1004b6d04:	mov	x1, x21
1004b6d08:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b6d0c:	mov	x0, x21
1004b6d10:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6d14:	adrp	x0, 7461 ; 0x1021db000
1004b6d18:	add	x0, x0, #0xda0
1004b6d1c:	mov	w1, #0x28
1004b6d20:	mov	w2, #0x7
1004b6d24:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b6d28:	mov	x27, x0
1004b6d2c:	ldp	x8, x26, [x19, #0x70]
1004b6d30:	stp	x20, x8, [x0, #0x10]
1004b6d34:	str	x26, [x0, #0x20]
1004b6d38:	adrp	x0, 7461 ; 0x1021db000
1004b6d3c:	add	x0, x0, #0xdc8
1004b6d40:	mov	w1, #0x20
1004b6d44:	mov	w2, #0x7
1004b6d48:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b6d4c:	mov	x21, x0
1004b6d50:	adrp	x8, 16 ; 0x1004c6000
1004b6d54:	add	x8, x8, #0x244
1004b6d58:	stp	x8, x27, [x0, #0x10]
1004b6d5c:	ldp	x23, x25, [x28, #0x10]
1004b6d60:	add	x27, x23, #0x1
1004b6d64:	mov	x0, x26
1004b6d68:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b6d6c:	mov	x0, x20
1004b6d70:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b6d74:	cmp	x23, x25, lsr #1
1004b6d78:	b.hs	0x1004b790c
1004b6d7c:	adrp	x8, 6435 ; 0x101dd9000
1004b6d80:	add	x8, x8, #0x510 ; literal pool for: "Create Branch..."
1004b6d84:	sub	x8, x8, #0x20
1004b6d88:	orr	x8, x8, #0x8000000000000000
1004b6d8c:	str	x27, [x28, #0x10]
1004b6d90:	mov	w9, #0x38
1004b6d94:	madd	x9, x23, x9, x28
1004b6d98:	mov	x10, #0x10
1004b6d9c:	movk	x10, #0xd000, lsl #48
1004b6da0:	stp	x10, x8, [x9, #0x20]
1004b6da4:	stp	xzr, xzr, [x9, #0x30]
1004b6da8:	adrp	x8, -1202 ; 0x100004000
1004b6dac:	add	x8, x8, #0xcc
1004b6db0:	stp	xzr, x8, [x9, #0x40]
1004b6db4:	str	x21, [x9, #0x50]
1004b6db8:	mov	x0, x20
1004b6dbc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b6dc0:	ldp	x21, x8, [x28, #0x10]
1004b6dc4:	add	x20, x21, #0x1
1004b6dc8:	cmp	x21, x8, lsr #1
1004b6dcc:	b.hs	0x1004b7934
1004b6dd0:	str	x20, [x28, #0x10]
1004b6dd4:	mov	w8, #0x38
1004b6dd8:	madd	x8, x21, x8, x28
1004b6ddc:	mov	x9, #-0x1d00000000000000
1004b6de0:	stp	x24, x9, [x8, #0x20]
1004b6de4:	stp	xzr, xzr, [x8, #0x30]
1004b6de8:	adrp	x9, -1203 ; 0x100003000
1004b6dec:	add	x9, x9, #0xf40
1004b6df0:	stp	xzr, x9, [x8, #0x40]
1004b6df4:	str	xzr, [x8, #0x50]
1004b6df8:	adrp	x0, 7461 ; 0x1021db000
1004b6dfc:	add	x0, x0, #0xdf0
1004b6e00:	mov	w1, #0x20
1004b6e04:	mov	w2, #0x7
1004b6e08:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b6e0c:	mov	x21, x0
1004b6e10:	ldp	x8, x26, [x19, #0x70]
1004b6e14:	stp	x8, x26, [x0, #0x10]
1004b6e18:	adrp	x0, 7461 ; 0x1021db000
1004b6e1c:	add	x0, x0, #0xe18
1004b6e20:	mov	w1, #0x20
1004b6e24:	mov	w2, #0x7
1004b6e28:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b6e2c:	mov	x20, x0
1004b6e30:	adrp	x8, 16 ; 0x1004c6000
1004b6e34:	add	x8, x8, #0x380
1004b6e38:	stp	x8, x21, [x0, #0x10]
1004b6e3c:	ldp	x23, x25, [x28, #0x10]
1004b6e40:	add	x21, x23, #0x1
1004b6e44:	mov	x0, x26
1004b6e48:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b6e4c:	cmp	x23, x25, lsr #1
1004b6e50:	b.hs	0x1004b795c
1004b6e54:	str	x21, [x28, #0x10]
1004b6e58:	mov	w8, #0x38
1004b6e5c:	madd	x8, x23, x8, x28
1004b6e60:	mov	w9, #0x7550
1004b6e64:	movk	w9, #0x6873, lsl #16
1004b6e68:	mov	x25, #-0x1c00000000000000
1004b6e6c:	stp	x9, x25, [x8, #0x20]
1004b6e70:	stp	xzr, xzr, [x8, #0x30]
1004b6e74:	adrp	x9, -1202 ; 0x100004000
1004b6e78:	add	x9, x9, #0xcc
1004b6e7c:	stp	xzr, x9, [x8, #0x40]
1004b6e80:	str	x20, [x8, #0x50]
1004b6e84:	adrp	x0, 7460 ; 0x1021da000
1004b6e88:	add	x0, x0, #0x978
1004b6e8c:	mov	w1, #0x18
1004b6e90:	mov	w2, #0x7
1004b6e94:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b6e98:	mov	x20, x0
1004b6e9c:	add	x0, x22, #0x10
1004b6ea0:	add	x1, x19, #0xd0
1004b6ea4:	mov	x2, #0x0
1004b6ea8:	mov	x3, #0x0
1004b6eac:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b6eb0:	add	x0, x22, #0x10
1004b6eb4:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004b6eb8:	mov	x21, x0
1004b6ebc:	add	x0, x20, #0x10
1004b6ec0:	mov	x1, x21
1004b6ec4:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b6ec8:	mov	x0, x21
1004b6ecc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6ed0:	adrp	x0, 7461 ; 0x1021db000
1004b6ed4:	add	x0, x0, #0xe40
1004b6ed8:	mov	w1, #0x28
1004b6edc:	mov	w2, #0x7
1004b6ee0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b6ee4:	mov	x27, x0
1004b6ee8:	ldr	x8, [x19, #0x70]
1004b6eec:	mov	x26, x28
1004b6ef0:	ldr	x28, [x19, #0x78]
1004b6ef4:	stp	x8, x28, [x0, #0x10]
1004b6ef8:	str	x20, [x0, #0x20]
1004b6efc:	adrp	x0, 7461 ; 0x1021db000
1004b6f00:	add	x0, x0, #0xe68
1004b6f04:	mov	w1, #0x20
1004b6f08:	mov	w2, #0x7
1004b6f0c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b6f10:	mov	x21, x0
1004b6f14:	adrp	x8, 16 ; 0x1004c6000
1004b6f18:	add	x8, x8, #0x388
1004b6f1c:	stp	x8, x27, [x0, #0x10]
1004b6f20:	mov	x24, x26
1004b6f24:	ldp	x23, x26, [x26, #0x10]
1004b6f28:	add	x27, x23, #0x1
1004b6f2c:	mov	x0, x28
1004b6f30:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b6f34:	mov	x0, x20
1004b6f38:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b6f3c:	cmp	x23, x26, lsr #1
1004b6f40:	b.hs	0x1004b7984
1004b6f44:	mov	x28, x24
1004b6f48:	str	x27, [x28, #0x10]
1004b6f4c:	mov	w8, #0x38
1004b6f50:	madd	x8, x23, x8, x28
1004b6f54:	mov	w9, #0x7550
1004b6f58:	movk	w9, #0x6c6c, lsl #16
1004b6f5c:	stp	x9, x25, [x8, #0x20]
1004b6f60:	stp	xzr, xzr, [x8, #0x30]
1004b6f64:	adrp	x9, -1202 ; 0x100004000
1004b6f68:	add	x9, x9, #0xcc
1004b6f6c:	stp	xzr, x9, [x8, #0x40]
1004b6f70:	str	x21, [x8, #0x50]
1004b6f74:	mov	x0, x20
1004b6f78:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b6f7c:	adrp	x0, 7461 ; 0x1021db000
1004b6f80:	add	x0, x0, #0xe90
1004b6f84:	mov	w1, #0x20
1004b6f88:	mov	w2, #0x7
1004b6f8c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b6f90:	mov	x20, x0
1004b6f94:	ldp	x8, x27, [x19, #0x70]
1004b6f98:	stp	x8, x27, [x0, #0x10]
1004b6f9c:	adrp	x0, 7461 ; 0x1021db000
1004b6fa0:	add	x0, x0, #0xeb8
1004b6fa4:	mov	w1, #0x20
1004b6fa8:	mov	w2, #0x7
1004b6fac:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b6fb0:	mov	x21, x0
1004b6fb4:	adrp	x8, 16 ; 0x1004c6000
1004b6fb8:	add	x8, x8, #0x394
1004b6fbc:	stp	x8, x20, [x0, #0x10]
1004b6fc0:	ldp	x25, x23, [x28, #0x10]
1004b6fc4:	lsr	x26, x23, #1
1004b6fc8:	add	x20, x25, #0x1
1004b6fcc:	mov	x0, x27
1004b6fd0:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b6fd4:	cmp	x26, x25
1004b6fd8:	mov	w27, #0x2d2d
1004b6fdc:	movk	w27, #0x2d, lsl #16
1004b6fe0:	mov	x24, #0x2e
1004b6fe4:	movk	x24, #0xe900, lsl #48
1004b6fe8:	b.ls	0x1004b79ac
1004b6fec:	str	x20, [x28, #0x10]
1004b6ff0:	mov	w8, #0x38
1004b6ff4:	madd	x8, x25, x8, x28
1004b6ff8:	mov	x9, #0x6546
1004b6ffc:	movk	x9, #0x6374, lsl #16
1004b7000:	movk	x9, #0x68, lsl #32
1004b7004:	mov	x10, #-0x1b00000000000000
1004b7008:	stp	x9, x10, [x8, #0x20]
1004b700c:	adrp	x9, -1203 ; 0x100004000
1004b7010:	add	x9, x9, #0xcc
1004b7014:	stp	xzr, xzr, [x8, #0x30]
1004b7018:	stp	xzr, x9, [x8, #0x40]
1004b701c:	str	x21, [x8, #0x50]
1004b7020:	add	x21, x25, #0x2
1004b7024:	cmp	x26, x21
1004b7028:	b.lt	0x1004b79dc
1004b702c:	str	x21, [x28, #0x10]
1004b7030:	mov	w8, #0x38
1004b7034:	madd	x8, x20, x8, x28
1004b7038:	mov	x9, #-0x1d00000000000000
1004b703c:	stp	x27, x9, [x8, #0x20]
1004b7040:	stp	xzr, xzr, [x8, #0x30]
1004b7044:	adrp	x9, -1204 ; 0x100003000
1004b7048:	add	x9, x9, #0xf40
1004b704c:	stp	xzr, x9, [x8, #0x40]
1004b7050:	str	xzr, [x8, #0x50]
1004b7054:	adrp	x0, 7459 ; 0x1021da000
1004b7058:	add	x0, x0, #0x978
1004b705c:	mov	w1, #0x18
1004b7060:	mov	w2, #0x7
1004b7064:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b7068:	mov	x20, x0
1004b706c:	add	x0, x22, #0x10
1004b7070:	add	x1, x19, #0xb8
1004b7074:	mov	x2, #0x0
1004b7078:	mov	x3, #0x0
1004b707c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b7080:	add	x0, x22, #0x10
1004b7084:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004b7088:	mov	x21, x0
1004b708c:	add	x0, x20, #0x10
1004b7090:	mov	x1, x21
1004b7094:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b7098:	mov	x0, x21
1004b709c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b70a0:	adrp	x0, 7460 ; 0x1021db000
1004b70a4:	add	x0, x0, #0xee0
1004b70a8:	mov	w1, #0x28
1004b70ac:	mov	w2, #0x7
1004b70b0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b70b4:	mov	x27, x0
1004b70b8:	ldp	x8, x26, [x19, #0x70]
1004b70bc:	stp	x8, x26, [x0, #0x10]
1004b70c0:	str	x20, [x0, #0x20]
1004b70c4:	adrp	x0, 7460 ; 0x1021db000
1004b70c8:	add	x0, x0, #0xf08
1004b70cc:	mov	w1, #0x20
1004b70d0:	mov	w2, #0x7
1004b70d4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b70d8:	mov	x21, x0
1004b70dc:	adrp	x8, 15 ; 0x1004c6000
1004b70e0:	add	x8, x8, #0x39c
1004b70e4:	stp	x8, x27, [x0, #0x10]
1004b70e8:	ldp	x23, x25, [x28, #0x10]
1004b70ec:	add	x27, x23, #0x1
1004b70f0:	mov	x0, x26
1004b70f4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b70f8:	mov	x0, x20
1004b70fc:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b7100:	cmp	x23, x25, lsr #1
1004b7104:	b.hs	0x1004b7a04
1004b7108:	str	x27, [x28, #0x10]
1004b710c:	mov	w8, #0x38
1004b7110:	madd	x8, x23, x8, x28
1004b7114:	mov	x9, #0x654d
1004b7118:	movk	x9, #0x6772, lsl #16
1004b711c:	movk	x9, #0x2e65, lsl #32
1004b7120:	movk	x9, #0x2e2e, lsl #48
1004b7124:	mov	x10, #-0x1800000000000000
1004b7128:	stp	x9, x10, [x8, #0x20]
1004b712c:	stp	xzr, xzr, [x8, #0x30]
1004b7130:	adrp	x9, -1203 ; 0x100004000
1004b7134:	add	x9, x9, #0xcc
1004b7138:	stp	xzr, x9, [x8, #0x40]
1004b713c:	str	x21, [x8, #0x50]
1004b7140:	mov	x0, x20
1004b7144:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7148:	adrp	x0, 7459 ; 0x1021da000
1004b714c:	add	x0, x0, #0x978
1004b7150:	mov	w1, #0x18
1004b7154:	mov	w2, #0x7
1004b7158:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b715c:	mov	x20, x0
1004b7160:	add	x0, x22, #0x10
1004b7164:	add	x1, x19, #0xa0
1004b7168:	mov	x2, #0x0
1004b716c:	mov	x3, #0x0
1004b7170:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b7174:	add	x0, x22, #0x10
1004b7178:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004b717c:	mov	x21, x0
1004b7180:	add	x0, x20, #0x10
1004b7184:	mov	x1, x21
1004b7188:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b718c:	mov	x0, x21
1004b7190:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b7194:	adrp	x0, 7460 ; 0x1021db000
1004b7198:	add	x0, x0, #0xf30
1004b719c:	mov	w1, #0x28
1004b71a0:	mov	w2, #0x7
1004b71a4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b71a8:	mov	x22, x0
1004b71ac:	ldp	x8, x26, [x19, #0x70]
1004b71b0:	stp	x8, x26, [x0, #0x10]
1004b71b4:	str	x20, [x0, #0x20]
1004b71b8:	adrp	x0, 7460 ; 0x1021db000
1004b71bc:	add	x0, x0, #0xf58
1004b71c0:	mov	w1, #0x20
1004b71c4:	mov	w2, #0x7
1004b71c8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b71cc:	mov	x21, x0
1004b71d0:	adrp	x8, 15 ; 0x1004c6000
1004b71d4:	add	x8, x8, #0x3e0
1004b71d8:	stp	x8, x22, [x0, #0x10]
1004b71dc:	ldp	x23, x25, [x28, #0x10]
1004b71e0:	add	x22, x23, #0x1
1004b71e4:	mov	x0, x26
1004b71e8:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b71ec:	mov	x0, x20
1004b71f0:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b71f4:	cmp	x23, x25, lsr #1
1004b71f8:	b.hs	0x1004b7a2c
1004b71fc:	ldp	x27, x25, [x19, #0x48]
1004b7200:	ldr	x26, [x19, #0x80]
1004b7204:	str	x22, [x28, #0x10]
1004b7208:	mov	w8, #0x38
1004b720c:	madd	x8, x23, x8, x28
1004b7210:	mov	x9, #0x6552
1004b7214:	movk	x9, #0x6162, lsl #16
1004b7218:	movk	x9, #0x6573, lsl #32
1004b721c:	movk	x9, #0x2e2e, lsl #48
1004b7220:	stp	x9, x24, [x8, #0x20]
1004b7224:	stp	xzr, xzr, [x8, #0x30]
1004b7228:	adrp	x9, -1203 ; 0x100004000
1004b722c:	add	x9, x9, #0xcc
1004b7230:	stp	xzr, x9, [x8, #0x40]
1004b7234:	str	x21, [x8, #0x50]
1004b7238:	mov	x0, x20
1004b723c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7240:	ldr	x8, [x19, #0x60]
1004b7244:	cbz	x8, 0x1004b7314
1004b7248:	ldr	x22, [x19, #0x38]
1004b724c:	ldr	x8, [x22, #0x38]
1004b7250:	ldr	x8, [x8, #0x10]
1004b7254:	cmp	x8, #0x2
1004b7258:	ldr	x23, [x19, #0x58]
1004b725c:	b.lo	0x1004b72e8
1004b7260:	ldp	x21, x8, [x28, #0x10]
1004b7264:	lsr	x9, x8, #1
1004b7268:	add	x20, x21, #0x1
1004b726c:	cmp	x9, x21
1004b7270:	b.ls	0x1004b7ad4
1004b7274:	str	x20, [x28, #0x10]
1004b7278:	mov	w10, #0x38
1004b727c:	madd	x10, x21, x10, x28
1004b7280:	mov	x11, #-0x1d00000000000000
1004b7284:	mov	w12, #0x2d2d
1004b7288:	movk	w12, #0x2d, lsl #16
1004b728c:	stp	x12, x11, [x10, #0x20]
1004b7290:	adrp	x11, -1204 ; 0x100003000
1004b7294:	add	x11, x11, #0xf40
1004b7298:	stp	xzr, xzr, [x10, #0x30]
1004b729c:	stp	xzr, x11, [x10, #0x40]
1004b72a0:	str	xzr, [x10, #0x50]
1004b72a4:	add	x21, x21, #0x2
1004b72a8:	cmp	x9, x21
1004b72ac:	b.lt	0x1004b7b04
1004b72b0:	str	x21, [x28, #0x10]
1004b72b4:	mov	w8, #0x38
1004b72b8:	madd	x8, x20, x8, x28
1004b72bc:	mov	x9, #0x7753
1004b72c0:	movk	x9, #0x7469, lsl #16
1004b72c4:	movk	x9, #0x6863, lsl #32
1004b72c8:	movk	x9, #0x7420, lsl #48
1004b72cc:	add	x10, x24, #0x41
1004b72d0:	stp	x9, x10, [x8, #0x20]
1004b72d4:	stp	xzr, xzr, [x8, #0x30]
1004b72d8:	adrp	x9, -1204 ; 0x100003000
1004b72dc:	add	x9, x9, #0xf40
1004b72e0:	stp	xzr, x9, [x8, #0x40]
1004b72e4:	str	xzr, [x8, #0x50]
1004b72e8:	ldr	x21, [x19, #0x40]
1004b72ec:	bl	0x100579928
1004b72f0:	str	x0, [x19, #0x68]
1004b72f4:	ldp	x0, x1, [x22, #0x28]
1004b72f8:	str	x0, [x19, #0x28]
1004b72fc:	cbz	x1, 0x1004b7350
1004b7300:	mov	x8, x27
1004b7304:	str	x1, [x19, #0x38]
1004b7308:	bl	0x101ac4e10 ; symbol stub for: _$s10Foundation3URLV6stringACSgSSh_tcfC
1004b730c:	ldr	x20, [x25, #0x38]
1004b7310:	b	0x1004b736c
1004b7314:	bl	0x100579928
1004b7318:	str	x0, [x19, #0x68]
1004b731c:	ldr	x8, [x19, #0x38]
1004b7320:	ldp	x9, x8, [x8, #0x28]
1004b7324:	str	x9, [x19, #0x28]
1004b7328:	str	x8, [x19, #0x38]
1004b732c:	ldr	x20, [x25, #0x38]
1004b7330:	mov	x0, x27
1004b7334:	mov	w1, #0x1
1004b7338:	mov	w2, #0x1
1004b733c:	ldr	x23, [x19, #0x58]
1004b7340:	mov	x3, x23
1004b7344:	blr	x20
1004b7348:	ldr	x21, [x19, #0x40]
1004b734c:	b	0x1004b736c
1004b7350:	ldr	x20, [x25, #0x38]
1004b7354:	mov	x0, x27
1004b7358:	mov	w1, #0x1
1004b735c:	mov	w2, #0x1
1004b7360:	mov	x3, x23
1004b7364:	blr	x20
1004b7368:	str	xzr, [x19, #0x38]
1004b736c:	ldr	x24, [x19, #0x88]
1004b7370:	mov	x0, x24
1004b7374:	mov	w1, #0x1
1004b7378:	mov	w2, #0x1
1004b737c:	mov	x3, x23
1004b7380:	blr	x20
1004b7384:	ldrsw	x22, [x21, #0x30]
1004b7388:	adrp	x20, 7820 ; 0x102343000
1004b738c:	add	x20, x20, #0x20
1004b7390:	adrp	x21, 5675 ; 0x101ae2000
1004b7394:	add	x21, x21, #0x680
1004b7398:	mov	x0, x27
1004b739c:	mov	x1, x26
1004b73a0:	mov	x2, x20
1004b73a4:	mov	x3, x21
1004b73a8:	bl	0x10002d8f4
1004b73ac:	add	x1, x26, x22
1004b73b0:	mov	x0, x24
1004b73b4:	mov	x2, x20
1004b73b8:	mov	x3, x21
1004b73bc:	bl	0x10002d8f4
1004b73c0:	ldr	x21, [x25, #0x30]
1004b73c4:	mov	x0, x26
1004b73c8:	mov	w1, #0x1
1004b73cc:	mov	x2, x23
1004b73d0:	blr	x21
1004b73d4:	cmp	w0, #0x1
1004b73d8:	str	x21, [x19, #0x40]
1004b73dc:	b.ne	0x1004b744c
1004b73e0:	mov	x25, x21
1004b73e4:	adrp	x21, 5675 ; 0x101ae2000
1004b73e8:	add	x21, x21, #0x680
1004b73ec:	mov	x0, x24
1004b73f0:	mov	x1, x20
1004b73f4:	mov	x2, x21
1004b73f8:	bl	0x10002d870
1004b73fc:	mov	x0, x27
1004b7400:	mov	x1, x20
1004b7404:	mov	x2, x21
1004b7408:	bl	0x10002d870
1004b740c:	add	x0, x26, x22
1004b7410:	mov	w1, #0x1
1004b7414:	mov	x2, x23
1004b7418:	blr	x25
1004b741c:	cmp	w0, #0x1
1004b7420:	b.ne	0x1004b748c
1004b7424:	adrp	x1, 7820 ; 0x102343000
1004b7428:	add	x1, x1, #0x20
1004b742c:	adrp	x2, 5675 ; 0x101ae2000
1004b7430:	add	x2, x2, #0x680
1004b7434:	mov	x0, x26
1004b7438:	bl	0x10002d870
1004b743c:	mov	w8, #0x0
1004b7440:	mov	w24, #0x2d2d
1004b7444:	movk	w24, #0x2d, lsl #16
1004b7448:	b	0x1004b7784
1004b744c:	add	x0, x26, x22
1004b7450:	mov	w1, #0x1
1004b7454:	mov	x2, x23
1004b7458:	blr	x21
1004b745c:	cmp	w0, #0x1
1004b7460:	b.ne	0x1004b76b4
1004b7464:	adrp	x21, 5675 ; 0x101ae2000
1004b7468:	add	x21, x21, #0x680
1004b746c:	ldr	x0, [x19, #0x88]
1004b7470:	mov	x1, x20
1004b7474:	mov	x2, x21
1004b7478:	bl	0x10002d870
1004b747c:	mov	x0, x27
1004b7480:	mov	x1, x20
1004b7484:	mov	x2, x21
1004b7488:	bl	0x10002d870
1004b748c:	adrp	x1, 7820 ; 0x102343000
1004b7490:	add	x1, x1, #0x230
1004b7494:	adrp	x2, 5676 ; 0x101ae3000
1004b7498:	add	x2, x2, #0x460
1004b749c:	mov	x0, x26
1004b74a0:	bl	0x10002d870
1004b74a4:	ldr	x8, [x19, #0x68]
1004b74a8:	ldr	x26, [x8, #0x10]
1004b74ac:	cmp	x26, #0x0
1004b74b0:	cset	w21, ne
1004b74b4:	mov	w24, #0x2d2d
1004b74b8:	movk	w24, #0x2d, lsl #16
1004b74bc:	ldp	x22, x8, [x28, #0x10]
1004b74c0:	add	x20, x22, #0x1
1004b74c4:	cmp	x22, x8, lsr #1
1004b74c8:	b.hs	0x1004b7a54
1004b74cc:	str	x20, [x28, #0x10]
1004b74d0:	mov	w8, #0x38
1004b74d4:	madd	x8, x22, x8, x28
1004b74d8:	mov	x9, #-0x1d00000000000000
1004b74dc:	stp	x24, x9, [x8, #0x20]
1004b74e0:	stp	xzr, xzr, [x8, #0x30]
1004b74e4:	adrp	x9, -1204 ; 0x100003000
1004b74e8:	add	x9, x9, #0xf40
1004b74ec:	stp	xzr, x9, [x8, #0x40]
1004b74f0:	str	xzr, [x8, #0x50]
1004b74f4:	cbz	w21, 0x1004b7654
1004b74f8:	ldr	x8, [x19, #0x68]
1004b74fc:	add	x25, x8, #0x30
1004b7500:	ldrb	w8, [x25, #0x10]
1004b7504:	ldp	q1, q0, [x25, #-0x10]
1004b7508:	sturb	w8, [x29, #-0x80]
1004b750c:	stp	q1, q0, [x29, #-0xa0]
1004b7510:	ldp	x24, x22, [x29, #-0xa0]
1004b7514:	ldr	q0, [x25]
1004b7518:	stur	q0, [x29, #-0x70]
1004b751c:	mov	x0, x22
1004b7520:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b7524:	sub	x0, x29, #0x70
1004b7528:	add	x1, x19, #0x90
1004b752c:	bl	0x1000589e8
1004b7530:	bl	0x1000ace0c
1004b7534:	sub	x0, x29, #0xa0
1004b7538:	bl	0x10057b218
1004b753c:	mov	x8, #0x704f
1004b7540:	movk	x8, #0x6e65, lsl #16
1004b7544:	movk	x8, #0x6920, lsl #32
1004b7548:	movk	x8, #0x206e, lsl #48
1004b754c:	stp	x0, x8, [x19, #0x88]
1004b7550:	mov	x8, #-0x1800000000000000
1004b7554:	str	x8, [x19, #0x98]
1004b7558:	mov	x0, x22
1004b755c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b7560:	add	x20, x19, #0x90
1004b7564:	mov	x0, x24
1004b7568:	mov	x1, x22
1004b756c:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004b7570:	mov	x0, x22
1004b7574:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b7578:	ldp	x8, x27, [x19, #0x90]
1004b757c:	str	x8, [x19, #0x80]
1004b7580:	adrp	x0, 7460 ; 0x1021db000
1004b7584:	add	x0, x0, #0xf80
1004b7588:	mov	w1, #0x41
1004b758c:	mov	w2, #0x7
1004b7590:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b7594:	mov	x22, x0
1004b7598:	ldp	x8, x21, [x19, #0x70]
1004b759c:	stp	x8, x21, [x0, #0x10]
1004b75a0:	ldp	q0, q1, [x29, #-0xa0]
1004b75a4:	stp	q0, q1, [x0, #0x20]
1004b75a8:	ldurb	w8, [x29, #-0x80]
1004b75ac:	strb	w8, [x0, #0x40]
1004b75b0:	adrp	x0, 7460 ; 0x1021db000
1004b75b4:	add	x0, x0, #0xfa8
1004b75b8:	mov	w1, #0x20
1004b75bc:	mov	w2, #0x7
1004b75c0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b75c4:	mov	x20, x0
1004b75c8:	adrp	x8, 15 ; 0x1004c6000
1004b75cc:	add	x8, x8, #0x4bc
1004b75d0:	stp	x8, x22, [x0, #0x10]
1004b75d4:	mov	x23, x28
1004b75d8:	ldp	x22, x28, [x28, #0x10]
1004b75dc:	add	x24, x22, #0x1
1004b75e0:	mov	x0, x21
1004b75e4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b75e8:	cmp	x22, x28, lsr #1
1004b75ec:	b.hs	0x1004b762c
1004b75f0:	mov	x28, x23
1004b75f4:	str	x24, [x28, #0x10]
1004b75f8:	mov	w8, #0x38
1004b75fc:	madd	x8, x22, x8, x28
1004b7600:	ldp	x10, x11, [x19, #0x80]
1004b7604:	stp	x10, x27, [x8, #0x20]
1004b7608:	stp	xzr, xzr, [x8, #0x30]
1004b760c:	adrp	x9, -1203 ; 0x100004000
1004b7610:	add	x9, x9, #0xcc
1004b7614:	stp	x11, x9, [x8, #0x40]
1004b7618:	str	x20, [x8, #0x50]
1004b761c:	add	x25, x25, #0x28
1004b7620:	subs	x26, x26, #0x1
1004b7624:	b.ne	0x1004b7500
1004b7628:	b	0x1004b7654
1004b762c:	cmp	x28, #0x1
1004b7630:	cset	w0, hi
1004b7634:	mov	x1, x24
1004b7638:	mov	w2, #0x1
1004b763c:	mov	x3, x23
1004b7640:	adrp	x4, 7704 ; 0x1022cf000
1004b7644:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b7648:	bl	0x1004bfb6c
1004b764c:	mov	x28, x0
1004b7650:	b	0x1004b75f4
1004b7654:	ldr	x0, [x19, #0x68]
1004b7658:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b765c:	ldr	x8, [x19, #0x60]
1004b7660:	cbz	x8, 0x1004b7898
1004b7664:	ldr	x1, [x19, #0x38]
1004b7668:	cbz	x1, 0x1004b7898
1004b766c:	ldp	x0, x20, [x19, #0x28]
1004b7670:	mov	x8, x20
1004b7674:	bl	0x101ac4e10 ; symbol stub for: _$s10Foundation3URLV6stringACSgSSh_tcfC
1004b7678:	mov	x0, x20
1004b767c:	mov	w1, #0x1
1004b7680:	ldr	x23, [x19, #0x58]
1004b7684:	mov	x2, x23
1004b7688:	ldr	x8, [x19, #0x40]
1004b768c:	blr	x8
1004b7690:	cmp	w0, #0x1
1004b7694:	b.ne	0x1004b77a8
1004b7698:	adrp	x1, 7820 ; 0x102343000
1004b769c:	add	x1, x1, #0x20
1004b76a0:	adrp	x2, 5675 ; 0x101ae2000
1004b76a4:	add	x2, x2, #0x680
1004b76a8:	mov	x0, x20
1004b76ac:	bl	0x10002d870
1004b76b0:	b	0x1004b7898
1004b76b4:	ldr	x8, [x25, #0x10]
1004b76b8:	ldr	x24, [x19, #0x18]
1004b76bc:	mov	x0, x24
1004b76c0:	mov	x1, x26
1004b76c4:	mov	x2, x23
1004b76c8:	blr	x8
1004b76cc:	ldr	x8, [x25, #0x20]
1004b76d0:	add	x1, x26, x22
1004b76d4:	ldr	x22, [x19, #0x20]
1004b76d8:	mov	x0, x22
1004b76dc:	mov	x2, x23
1004b76e0:	blr	x8
1004b76e4:	adrp	x0, 7831 ; 0x10234e000
1004b76e8:	add	x0, x0, #0x1e0
1004b76ec:	adrp	x1, 7701 ; 0x1022cc000
1004b76f0:	ldr	x1, [x1, #0x7f8] ; literal pool symbol address: _$s10Foundation3URLVMa
1004b76f4:	adrp	x2, 7701 ; 0x1022cc000
1004b76f8:	ldr	x2, [x2, #0x810] ; literal pool symbol address: _$s10Foundation3URLVSQAAMc
1004b76fc:	bl	0x10002c7c4
1004b7700:	mov	x3, x0
1004b7704:	mov	x0, x24
1004b7708:	mov	x1, x22
1004b770c:	mov	x20, x23
1004b7710:	mov	x2, x23
1004b7714:	bl	0x101ac619c ; symbol stub for: _$sSQ2eeoiySbx_xtFZTj
1004b7718:	mov	x20, x0
1004b771c:	ldr	x21, [x25, #0x8]
1004b7720:	mov	x0, x22
1004b7724:	mov	x1, x23
1004b7728:	blr	x21
1004b772c:	mov	x0, x24
1004b7730:	mov	x1, x23
1004b7734:	blr	x21
1004b7738:	adrp	x21, 7820 ; 0x102343000
1004b773c:	add	x21, x21, #0x20
1004b7740:	adrp	x24, 5675 ; 0x101ae2000
1004b7744:	add	x24, x24, #0x680
1004b7748:	ldr	x0, [x19, #0x88]
1004b774c:	mov	x1, x21
1004b7750:	mov	x2, x24
1004b7754:	bl	0x10002d870
1004b7758:	mov	x0, x27
1004b775c:	mov	x1, x21
1004b7760:	mov	x2, x24
1004b7764:	bl	0x10002d870
1004b7768:	mov	x0, x26
1004b776c:	mov	x1, x21
1004b7770:	mov	x2, x24
1004b7774:	mov	w24, #0x2d2d
1004b7778:	movk	w24, #0x2d, lsl #16
1004b777c:	bl	0x10002d870
1004b7780:	eor	w8, w20, #0x1
1004b7784:	ldr	x9, [x19, #0x68]
1004b7788:	ldr	x26, [x9, #0x10]
1004b778c:	cmp	x26, #0x0
1004b7790:	cset	w21, ne
1004b7794:	cbnz	x26, 0x1004b74bc
1004b7798:	tbnz	w8, #0x0, 0x1004b74bc
1004b779c:	ldr	x0, [x19, #0x68]
1004b77a0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b77a4:	b	0x1004b7898
1004b77a8:	ldr	x24, [x19, #0x50]
1004b77ac:	ldr	x21, [x24, #0x20]
1004b77b0:	ldr	x25, [x19, #0x10]
1004b77b4:	mov	x0, x25
1004b77b8:	mov	x1, x20
1004b77bc:	mov	x2, x23
1004b77c0:	blr	x21
1004b77c4:	ldr	x8, [x24, #0x10]
1004b77c8:	ldr	x26, [x19, #0x8]
1004b77cc:	mov	x0, x26
1004b77d0:	mov	x1, x25
1004b77d4:	mov	x2, x23
1004b77d8:	blr	x8
1004b77dc:	ldrb	w8, [x24, #0x50]
1004b77e0:	add	x9, x8, #0x10
1004b77e4:	bic	x22, x9, x8
1004b77e8:	adrp	x0, 7460 ; 0x1021db000
1004b77ec:	add	x0, x0, #0xfd0
1004b77f0:	ldr	x9, [x19]
1004b77f4:	add	x1, x22, x9
1004b77f8:	orr	x2, x8, #0x7
1004b77fc:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b7800:	mov	x20, x0
1004b7804:	add	x0, x0, x22
1004b7808:	mov	x1, x26
1004b780c:	mov	x2, x23
1004b7810:	blr	x21
1004b7814:	adrp	x0, 7460 ; 0x1021db000
1004b7818:	add	x0, x0, #0xff8
1004b781c:	mov	w1, #0x20
1004b7820:	mov	w2, #0x7
1004b7824:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b7828:	adrp	x8, 15 ; 0x1004c6000
1004b782c:	add	x8, x8, #0x524
1004b7830:	stp	x8, x20, [x0, #0x10]
1004b7834:	ldp	x21, x8, [x28, #0x10]
1004b7838:	add	x20, x21, #0x1
1004b783c:	cmp	x21, x8, lsr #1
1004b7840:	b.hs	0x1004b7b2c
1004b7844:	str	x20, [x28, #0x10]
1004b7848:	mov	w8, #0x38
1004b784c:	madd	x8, x21, x8, x28
1004b7850:	mov	x9, #0x704f
1004b7854:	movk	x9, #0x6e65, lsl #16
1004b7858:	movk	x9, #0x5220, lsl #32
1004b785c:	movk	x9, #0x6d65, lsl #48
1004b7860:	mov	x10, #0x746f
1004b7864:	movk	x10, #0x2065, lsl #16
1004b7868:	movk	x10, #0x5255, lsl #32
1004b786c:	movk	x10, #0xef4c, lsl #48
1004b7870:	stp	x9, x10, [x8, #0x20]
1004b7874:	stp	xzr, xzr, [x8, #0x30]
1004b7878:	adrp	x9, -1203 ; 0x100004000
1004b787c:	add	x9, x9, #0xcc
1004b7880:	stp	xzr, x9, [x8, #0x40]
1004b7884:	str	x0, [x8, #0x50]
1004b7888:	ldr	x8, [x24, #0x8]
1004b788c:	mov	x0, x25
1004b7890:	mov	x1, x23
1004b7894:	blr	x8
1004b7898:	mov	x0, x28
1004b789c:	sub	sp, x29, #0x50
1004b78a0:	ldp	x29, x30, [sp, #0x50]
1004b78a4:	ldp	x20, x19, [sp, #0x40]
1004b78a8:	ldp	x22, x21, [sp, #0x30]
1004b78ac:	ldp	x24, x23, [sp, #0x20]
1004b78b0:	ldp	x26, x25, [sp, #0x10]
1004b78b4:	ldp	x28, x27, [sp], #0x60
1004b78b8:	ret
1004b78bc:	ldr	x8, [x28, #0x10]
1004b78c0:	adrp	x4, 7704 ; 0x1022cf000
1004b78c4:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b78c8:	add	x1, x8, #0x1
1004b78cc:	mov	w0, #0x0
1004b78d0:	mov	w2, #0x1
1004b78d4:	mov	x3, x28
1004b78d8:	bl	0x1004bfb6c
1004b78dc:	mov	x28, x0
1004b78e0:	b	0x1004b6c74
1004b78e4:	cmp	x8, #0x1
1004b78e8:	cset	w0, hi
1004b78ec:	adrp	x4, 7704 ; 0x1022cf000
1004b78f0:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b78f4:	mov	x1, x27
1004b78f8:	mov	w2, #0x1
1004b78fc:	mov	x3, x28
1004b7900:	bl	0x1004bfb6c
1004b7904:	mov	x28, x0
1004b7908:	b	0x1004b6c84
1004b790c:	cmp	x25, #0x1
1004b7910:	cset	w0, hi
1004b7914:	adrp	x4, 7704 ; 0x1022cf000
1004b7918:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b791c:	mov	x1, x27
1004b7920:	mov	w2, #0x1
1004b7924:	mov	x3, x28
1004b7928:	bl	0x1004bfb6c
1004b792c:	mov	x28, x0
1004b7930:	b	0x1004b6d7c
1004b7934:	cmp	x8, #0x1
1004b7938:	cset	w0, hi
1004b793c:	adrp	x4, 7704 ; 0x1022cf000
1004b7940:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b7944:	mov	x1, x20
1004b7948:	mov	w2, #0x1
1004b794c:	mov	x3, x28
1004b7950:	bl	0x1004bfb6c
1004b7954:	mov	x28, x0
1004b7958:	b	0x1004b6dd0
1004b795c:	cmp	x25, #0x1
1004b7960:	cset	w0, hi
1004b7964:	adrp	x4, 7704 ; 0x1022cf000
1004b7968:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b796c:	mov	x1, x21
1004b7970:	mov	w2, #0x1
1004b7974:	mov	x3, x28
1004b7978:	bl	0x1004bfb6c
1004b797c:	mov	x28, x0
1004b7980:	b	0x1004b6e54
1004b7984:	cmp	x26, #0x1
1004b7988:	cset	w0, hi
1004b798c:	adrp	x4, 7704 ; 0x1022cf000
1004b7990:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b7994:	mov	x1, x27
1004b7998:	mov	w2, #0x1
1004b799c:	mov	x3, x24
1004b79a0:	bl	0x1004bfb6c
1004b79a4:	mov	x28, x0
1004b79a8:	b	0x1004b6f48
1004b79ac:	cmp	x23, #0x1
1004b79b0:	cset	w0, hi
1004b79b4:	adrp	x4, 7704 ; 0x1022cf000
1004b79b8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b79bc:	mov	x1, x20
1004b79c0:	mov	w2, #0x1
1004b79c4:	mov	x3, x28
1004b79c8:	bl	0x1004bfb6c
1004b79cc:	mov	x28, x0
1004b79d0:	ldr	x23, [x0, #0x18]
1004b79d4:	lsr	x26, x23, #1
1004b79d8:	b	0x1004b6fec
1004b79dc:	cmp	x23, #0x1
1004b79e0:	cset	w0, hi
1004b79e4:	adrp	x4, 7704 ; 0x1022cf000
1004b79e8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b79ec:	mov	x1, x21
1004b79f0:	mov	w2, #0x1
1004b79f4:	mov	x3, x28
1004b79f8:	bl	0x1004bfb6c
1004b79fc:	mov	x28, x0
1004b7a00:	b	0x1004b702c
1004b7a04:	cmp	x25, #0x1
1004b7a08:	cset	w0, hi
1004b7a0c:	adrp	x4, 7704 ; 0x1022cf000
1004b7a10:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b7a14:	mov	x1, x27
1004b7a18:	mov	w2, #0x1
1004b7a1c:	mov	x3, x28
1004b7a20:	bl	0x1004bfb6c
1004b7a24:	mov	x28, x0
1004b7a28:	b	0x1004b7108
1004b7a2c:	cmp	x25, #0x1
1004b7a30:	cset	w0, hi
1004b7a34:	adrp	x4, 7704 ; 0x1022cf000
1004b7a38:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b7a3c:	mov	x1, x22
1004b7a40:	mov	w2, #0x1
1004b7a44:	mov	x3, x28
1004b7a48:	bl	0x1004bfb6c
1004b7a4c:	mov	x28, x0
1004b7a50:	b	0x1004b71fc
1004b7a54:	cmp	x8, #0x1
1004b7a58:	cset	w0, hi
1004b7a5c:	adrp	x4, 7704 ; 0x1022cf000
1004b7a60:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b7a64:	mov	x1, x20
1004b7a68:	mov	w2, #0x1
1004b7a6c:	mov	x3, x28
1004b7a70:	bl	0x1004bfb6c
1004b7a74:	mov	x28, x0
1004b7a78:	b	0x1004b74cc
1004b7a7c:	cmp	x8, #0x1
1004b7a80:	cset	w0, hi
1004b7a84:	adrp	x4, 7704 ; 0x1022cf000
1004b7a88:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b7a8c:	mov	x1, x21
1004b7a90:	mov	w2, #0x1
1004b7a94:	mov	x3, x28
1004b7a98:	bl	0x1004bfb6c
1004b7a9c:	mov	x28, x0
1004b7aa0:	ldr	x8, [x0, #0x18]
1004b7aa4:	lsr	x9, x8, #1
1004b7aa8:	b	0x1004b6b64
1004b7aac:	cmp	x8, #0x1
1004b7ab0:	cset	w0, hi
1004b7ab4:	adrp	x4, 7704 ; 0x1022cf000
1004b7ab8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b7abc:	mov	x1, x27
1004b7ac0:	mov	w2, #0x1
1004b7ac4:	mov	x3, x28
1004b7ac8:	bl	0x1004bfb6c
1004b7acc:	mov	x28, x0
1004b7ad0:	b	0x1004b6b94
1004b7ad4:	cmp	x8, #0x1
1004b7ad8:	cset	w0, hi
1004b7adc:	adrp	x4, 7704 ; 0x1022cf000
1004b7ae0:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b7ae4:	mov	x1, x20
1004b7ae8:	mov	w2, #0x1
1004b7aec:	mov	x3, x28
1004b7af0:	bl	0x1004bfb6c
1004b7af4:	mov	x28, x0
1004b7af8:	ldr	x8, [x0, #0x18]
1004b7afc:	lsr	x9, x8, #1
1004b7b00:	b	0x1004b7274
1004b7b04:	cmp	x8, #0x1
1004b7b08:	cset	w0, hi
1004b7b0c:	adrp	x4, 7704 ; 0x1022cf000
1004b7b10:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b7b14:	mov	x1, x21
1004b7b18:	mov	w2, #0x1
1004b7b1c:	mov	x3, x28
1004b7b20:	bl	0x1004bfb6c
1004b7b24:	mov	x28, x0
1004b7b28:	b	0x1004b72b0
1004b7b2c:	cmp	x8, #0x1
1004b7b30:	cset	w8, hi
1004b7b34:	adrp	x4, 7704 ; 0x1022cf000
1004b7b38:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b7b3c:	mov	x22, x0
1004b7b40:	mov	x0, x8
1004b7b44:	mov	x1, x20
1004b7b48:	mov	w2, #0x1
1004b7b4c:	mov	x3, x28
1004b7b50:	bl	0x1004bfb6c
1004b7b54:	mov	x28, x0
1004b7b58:	mov	x0, x22
1004b7b5c:	b	0x1004b7844
1004b7b60:	sub	sp, sp, #0xa0
1004b7b64:	stp	d11, d10, [sp, #0x20]
1004b7b68:	stp	d9, d8, [sp, #0x30]
1004b7b6c:	stp	x28, x27, [sp, #0x40]
1004b7b70:	stp	x26, x25, [sp, #0x50]
1004b7b74:	stp	x24, x23, [sp, #0x60]
1004b7b78:	stp	x22, x21, [sp, #0x70]
1004b7b7c:	stp	x20, x19, [sp, #0x80]
1004b7b80:	stp	x29, x30, [sp, #0x90]
1004b7b84:	add	x29, sp, #0x90
1004b7b88:	mov.16b	v8, v0
1004b7b8c:	mov	x19, x0
1004b7b90:	bl	0x1001c1650
1004b7b94:	tbz	w0, #0x0, 0x1004b7d7c
1004b7b98:	adrp	x8, 7910 ; 0x10239d000
1004b7b9c:	ldr	x8, [x8, #0x248]
1004b7ba0:	add	x0, x20, x8
1004b7ba4:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b7ba8:	cbz	x0, 0x1004b7d7c
1004b7bac:	mov	x26, x20
1004b7bb0:	ldr	x8, [x0]
1004b7bb4:	ldr	x8, [x8, #0x260]
1004b7bb8:	mov	x20, x0
1004b7bbc:	mov	x21, x0
1004b7bc0:	blr	x8
1004b7bc4:	mov	x20, x0
1004b7bc8:	mov	x0, x21
1004b7bcc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7bd0:	cbz	x20, 0x1004b7d7c
1004b7bd4:	ldr	x21, [x20, #0x18]
1004b7bd8:	mov	x0, x21
1004b7bdc:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b7be0:	mov	x0, x20
1004b7be4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7be8:	ldr	x8, [x21]
1004b7bec:	ldr	x8, [x8, #0x78]
1004b7bf0:	mov	x20, x21
1004b7bf4:	blr	x8
1004b7bf8:	mov	x20, x0
1004b7bfc:	mov	x0, x21
1004b7c00:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7c04:	ldr	x8, [x20]
1004b7c08:	ldr	x8, [x8, #0x90]
1004b7c0c:	blr	x8
1004b7c10:	mov	x24, x0
1004b7c14:	mov	x25, x1
1004b7c18:	mov	x0, x20
1004b7c1c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7c20:	adrp	x8, 6434 ; 0x101dd9000
1004b7c24:	add	x8, x8, #0x310 ; literal pool for: "Handover This Session"
1004b7c28:	sub	x27, x8, #0x20
1004b7c2c:	adrp	x0, 7459 ; 0x1021da000
1004b7c30:	add	x0, x0, #0x978
1004b7c34:	mov	w1, #0x18
1004b7c38:	mov	w2, #0x7
1004b7c3c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b7c40:	mov	x21, x0
1004b7c44:	add	x0, x0, #0x10
1004b7c48:	mov	x1, x26
1004b7c4c:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b7c50:	adrp	x0, 7460 ; 0x1021db000
1004b7c54:	add	x0, x0, #0x6c0
1004b7c58:	mov	w1, #0x28
1004b7c5c:	mov	w2, #0x7
1004b7c60:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b7c64:	mov	x22, x0
1004b7c68:	stp	x21, x24, [x0, #0x10]
1004b7c6c:	str	x25, [x0, #0x20]
1004b7c70:	mov	x0, #0x0
1004b7c74:	bl	0x1004ad03c
1004b7c78:	mov	x20, x0
1004b7c7c:	mov	x0, x21
1004b7c80:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b7c84:	mov	x8, #0x800000000000
1004b7c88:	movk	x8, #0x4071, lsl #48
1004b7c8c:	fmov	d9, x8
1004b7c90:	fmov	d10, #28.00000000
1004b7c94:	movi.2d	v0, #0000000000000000
1004b7c98:	fmov	d3, #28.00000000
1004b7c9c:	mov.16b	v1, v8
1004b7ca0:	mov.16b	v2, v9
1004b7ca4:	bl	0x100096d60
1004b7ca8:	mov	x24, x0
1004b7cac:	ldr	x8, [x0]
1004b7cb0:	adrp	x9, 7704 ; 0x1022cf000
1004b7cb4:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b7cb8:	ldr	x9, [x9]
1004b7cbc:	and	x8, x9, x8
1004b7cc0:	ldr	x8, [x8, #0x198]
1004b7cc4:	adrp	x3, 11 ; 0x1004c2000
1004b7cc8:	add	x3, x3, #0xf38
1004b7ccc:	orr	x1, x27, #0x8000000000000000
1004b7cd0:	mov	x0, #0x15
1004b7cd4:	movk	x0, #0xd000, lsl #48
1004b7cd8:	mov.16b	v0, v9
1004b7cdc:	mov	x2, x26
1004b7ce0:	mov	x4, x22
1004b7ce4:	mov	x5, #0x0
1004b7ce8:	mov	x6, #0x0
1004b7cec:	mov	x20, x24
1004b7cf0:	blr	x8
1004b7cf4:	mov	x0, x19
1004b7cf8:	mov	x2, x24
1004b7cfc:	bl	0x101acb460 ; selector addSubview:
1004b7d00:	adrp	x8, 7910 ; 0x10239d000
1004b7d04:	ldr	x25, [x8, #0x270]
1004b7d08:	add	x0, x26, x25
1004b7d0c:	add	x1, sp, #0x8
1004b7d10:	mov	w2, #0x21
1004b7d14:	mov	x3, #0x0
1004b7d18:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b7d1c:	add	x20, x26, x25
1004b7d20:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b7d24:	mov	x20, x26
1004b7d28:	ldr	x8, [x26, x25]
1004b7d2c:	and	x8, x8, #0xffffffffffffff8
1004b7d30:	ldp	x19, x8, [x8, #0x10]
1004b7d34:	cmp	x19, x8, lsr #1
1004b7d38:	b.hs	0x1004b7da8
1004b7d3c:	mov	x0, x24
1004b7d40:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b7d44:	mov	x23, x0
1004b7d48:	add	x20, x20, x25
1004b7d4c:	mov	x0, x19
1004b7d50:	mov	x1, x23
1004b7d54:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b7d58:	add	x0, sp, #0x8
1004b7d5c:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b7d60:	mov	x0, x21
1004b7d64:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7d68:	mov	x0, x23
1004b7d6c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b7d70:	mov	x0, x22
1004b7d74:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7d78:	fadd	d8, d8, d10
1004b7d7c:	mov.16b	v0, v8
1004b7d80:	ldp	x29, x30, [sp, #0x90]
1004b7d84:	ldp	x20, x19, [sp, #0x80]
1004b7d88:	ldp	x22, x21, [sp, #0x70]
1004b7d8c:	ldp	x24, x23, [sp, #0x60]
1004b7d90:	ldp	x26, x25, [sp, #0x50]
1004b7d94:	ldp	x28, x27, [sp, #0x40]
1004b7d98:	ldp	d9, d8, [sp, #0x30]
1004b7d9c:	ldp	d11, d10, [sp, #0x20]
1004b7da0:	add	sp, sp, #0xa0
1004b7da4:	ret
1004b7da8:	cmp	x8, #0x1
1004b7dac:	cset	w0, hi
1004b7db0:	add	x1, x19, #0x1
1004b7db4:	add	x20, x26, x25
1004b7db8:	mov	w2, #0x1
1004b7dbc:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b7dc0:	mov	x20, x26
1004b7dc4:	b	0x1004b7d3c
1004b7dc8:	sub	sp, sp, #0xa0
1004b7dcc:	stp	d11, d10, [sp, #0x20]
1004b7dd0:	stp	d9, d8, [sp, #0x30]
1004b7dd4:	stp	x28, x27, [sp, #0x40]
1004b7dd8:	stp	x26, x25, [sp, #0x50]
1004b7ddc:	stp	x24, x23, [sp, #0x60]
1004b7de0:	stp	x22, x21, [sp, #0x70]
1004b7de4:	stp	x20, x19, [sp, #0x80]
1004b7de8:	stp	x29, x30, [sp, #0x90]
1004b7dec:	add	x29, sp, #0x90
1004b7df0:	mov	x19, x20
1004b7df4:	mov.16b	v8, v0
1004b7df8:	mov	x23, x0
1004b7dfc:	adrp	x8, 7910 ; 0x10239d000
1004b7e00:	ldr	x8, [x8, #0x248]
1004b7e04:	add	x0, x20, x8
1004b7e08:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b7e0c:	cbz	x0, 0x1004b8000
1004b7e10:	ldr	x8, [x0]
1004b7e14:	ldr	x8, [x8, #0x260]
1004b7e18:	mov	x20, x0
1004b7e1c:	mov	x21, x0
1004b7e20:	blr	x8
1004b7e24:	mov	x20, x0
1004b7e28:	mov	x0, x21
1004b7e2c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7e30:	cbz	x20, 0x1004b8000
1004b7e34:	ldr	x22, [x20, #0x18]
1004b7e38:	mov	x0, x22
1004b7e3c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b7e40:	mov	x0, x20
1004b7e44:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7e48:	ldr	x8, [x22]
1004b7e4c:	ldr	x8, [x8, #0x128]
1004b7e50:	mov	x20, x22
1004b7e54:	blr	x8
1004b7e58:	mov	x21, x0
1004b7e5c:	mov	x0, x22
1004b7e60:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7e64:	cbz	x21, 0x1004b8000
1004b7e68:	adrp	x0, 7459 ; 0x1021da000
1004b7e6c:	add	x0, x0, #0x978
1004b7e70:	mov	w1, #0x18
1004b7e74:	mov	w2, #0x7
1004b7e78:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b7e7c:	mov	x22, x0
1004b7e80:	add	x0, x0, #0x10
1004b7e84:	mov	x1, x19
1004b7e88:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b7e8c:	adrp	x0, 7460 ; 0x1021db000
1004b7e90:	add	x0, x0, #0x620
1004b7e94:	mov	w1, #0x18
1004b7e98:	mov	w2, #0x7
1004b7e9c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b7ea0:	mov	x24, x0
1004b7ea4:	add	x0, x0, #0x10
1004b7ea8:	mov	x1, x21
1004b7eac:	bl	0x101acab58 ; symbol stub for: _swift_weakInit
1004b7eb0:	adrp	x0, 7460 ; 0x1021db000
1004b7eb4:	add	x0, x0, #0x648
1004b7eb8:	mov	w1, #0x20
1004b7ebc:	mov	w2, #0x7
1004b7ec0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b7ec4:	mov	x25, x0
1004b7ec8:	stp	x24, x22, [x0, #0x10]
1004b7ecc:	mov	x0, #0x0
1004b7ed0:	bl	0x1004ad03c
1004b7ed4:	mov	x20, x0
1004b7ed8:	mov	x0, x24
1004b7edc:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b7ee0:	mov	x0, x22
1004b7ee4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b7ee8:	mov	x8, #0x800000000000
1004b7eec:	movk	x8, #0x4071, lsl #48
1004b7ef0:	fmov	d9, x8
1004b7ef4:	fmov	d10, #28.00000000
1004b7ef8:	movi.2d	v0, #0000000000000000
1004b7efc:	fmov	d3, #28.00000000
1004b7f00:	mov.16b	v1, v8
1004b7f04:	mov.16b	v2, v9
1004b7f08:	bl	0x100096d60
1004b7f0c:	mov	x26, x0
1004b7f10:	ldr	x8, [x0]
1004b7f14:	adrp	x9, 7704 ; 0x1022cf000
1004b7f18:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b7f1c:	ldr	x9, [x9]
1004b7f20:	and	x8, x9, x8
1004b7f24:	ldr	x8, [x8, #0x198]
1004b7f28:	adrp	x3, 11 ; 0x1004c2000
1004b7f2c:	add	x3, x3, #0xad8
1004b7f30:	mov	x0, #0x6241
1004b7f34:	movk	x0, #0x756f, lsl #16
1004b7f38:	movk	x0, #0x2074, lsl #32
1004b7f3c:	movk	x0, #0x6874, lsl #48
1004b7f40:	mov	x1, #0x7369
1004b7f44:	movk	x1, #0x5020, lsl #16
1004b7f48:	movk	x1, #0x6e61, lsl #32
1004b7f4c:	movk	x1, #0xef65, lsl #48
1004b7f50:	mov.16b	v0, v9
1004b7f54:	mov	x2, x19
1004b7f58:	mov	x4, x25
1004b7f5c:	mov	x5, #0x0
1004b7f60:	mov	x6, #0x0
1004b7f64:	mov	x20, x26
1004b7f68:	blr	x8
1004b7f6c:	mov	x0, x23
1004b7f70:	mov	x2, x26
1004b7f74:	bl	0x101acb460 ; selector addSubview:
1004b7f78:	adrp	x8, 7910 ; 0x10239d000
1004b7f7c:	ldr	x27, [x8, #0x270]
1004b7f80:	add	x0, x19, x27
1004b7f84:	add	x1, sp, #0x8
1004b7f88:	mov	w2, #0x21
1004b7f8c:	mov	x3, #0x0
1004b7f90:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b7f94:	add	x20, x19, x27
1004b7f98:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b7f9c:	ldr	x8, [x19, x27]
1004b7fa0:	and	x8, x8, #0xffffffffffffff8
1004b7fa4:	ldp	x23, x8, [x8, #0x10]
1004b7fa8:	cmp	x23, x8, lsr #1
1004b7fac:	b.hs	0x1004b802c
1004b7fb0:	mov	x0, x26
1004b7fb4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b7fb8:	mov	x26, x0
1004b7fbc:	add	x20, x19, x27
1004b7fc0:	mov	x0, x23
1004b7fc4:	mov	x1, x26
1004b7fc8:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b7fcc:	add	x0, sp, #0x8
1004b7fd0:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b7fd4:	mov	x0, x22
1004b7fd8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7fdc:	mov	x0, x24
1004b7fe0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7fe4:	mov	x0, x26
1004b7fe8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b7fec:	mov	x0, x21
1004b7ff0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7ff4:	mov	x0, x25
1004b7ff8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b7ffc:	fadd	d8, d8, d10
1004b8000:	mov.16b	v0, v8
1004b8004:	ldp	x29, x30, [sp, #0x90]
1004b8008:	ldp	x20, x19, [sp, #0x80]
1004b800c:	ldp	x22, x21, [sp, #0x70]
1004b8010:	ldp	x24, x23, [sp, #0x60]
1004b8014:	ldp	x26, x25, [sp, #0x50]
1004b8018:	ldp	x28, x27, [sp, #0x40]
1004b801c:	ldp	d9, d8, [sp, #0x30]
1004b8020:	ldp	d11, d10, [sp, #0x20]
1004b8024:	add	sp, sp, #0xa0
1004b8028:	ret
1004b802c:	cmp	x8, #0x1
1004b8030:	cset	w0, hi
1004b8034:	add	x1, x23, #0x1
1004b8038:	add	x20, x19, x27
1004b803c:	mov	w2, #0x1
1004b8040:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b8044:	b	0x1004b7fb0
1004b8048:	stp	d11, d10, [sp, #-0x80]!
1004b804c:	stp	d9, d8, [sp, #0x10]
1004b8050:	stp	x28, x27, [sp, #0x20]
1004b8054:	stp	x26, x25, [sp, #0x30]
1004b8058:	stp	x24, x23, [sp, #0x40]
1004b805c:	stp	x22, x21, [sp, #0x50]
1004b8060:	stp	x20, x19, [sp, #0x60]
1004b8064:	stp	x29, x30, [sp, #0x70]
1004b8068:	add	x29, sp, #0x70
1004b806c:	sub	sp, sp, #0x100
1004b8070:	stp	x0, x20, [x29, #-0xf0]
1004b8074:	mov	x19, x1
1004b8078:	mov.16b	v8, v0
1004b807c:	mov	x0, #0x0
1004b8080:	bl	0x10068c780
1004b8084:	ldur	x8, [x0, #-0x8]
1004b8088:	ldr	x8, [x8, #0x40]
1004b808c:	mov	x9, x8
1004b8090:	adrp	x16, 7699 ; 0x1022cb000
1004b8094:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b8098:	blr	x16
1004b809c:	mov	x9, sp
1004b80a0:	add	x8, x8, #0xf
1004b80a4:	and	x8, x8, #0xfffffffffffffff0
1004b80a8:	sub	x21, x9, x8
1004b80ac:	mov	sp, x21
1004b80b0:	mov	x0, #0x0
1004b80b4:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004b80b8:	sub	x8, x29, #0x58
1004b80bc:	stur	x0, [x8, #-0x100]
1004b80c0:	ldur	x8, [x0, #-0x8]
1004b80c4:	sub	x9, x29, #0x60
1004b80c8:	stur	x8, [x9, #-0x100]
1004b80cc:	ldr	x8, [x8, #0x40]
1004b80d0:	mov	x9, x8
1004b80d4:	adrp	x16, 7699 ; 0x1022cb000
1004b80d8:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b80dc:	blr	x16
1004b80e0:	mov	x9, sp
1004b80e4:	add	x8, x8, #0xf
1004b80e8:	and	x8, x8, #0xfffffffffffffff0
1004b80ec:	sub	x8, x9, x8
1004b80f0:	sub	x9, x29, #0x68
1004b80f4:	stur	x8, [x9, #-0x100]
1004b80f8:	mov	sp, x8
1004b80fc:	mov	x0, #0x0
1004b8100:	bl	0x10068c76c
1004b8104:	sub	x8, x29, #0x40
1004b8108:	stur	x0, [x8, #-0x100]
1004b810c:	ldur	x8, [x0, #-0x8]
1004b8110:	ldr	x8, [x8, #0x40]
1004b8114:	mov	x9, x8
1004b8118:	adrp	x16, 7699 ; 0x1022cb000
1004b811c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b8120:	blr	x16
1004b8124:	mov	x9, sp
1004b8128:	add	x8, x8, #0xf
1004b812c:	and	x8, x8, #0xfffffffffffffff0
1004b8130:	sub	x22, x9, x8
1004b8134:	mov	sp, x22
1004b8138:	mov	x0, #0x0
1004b813c:	bl	0x10068c794
1004b8140:	ldur	x8, [x0, #-0x8]
1004b8144:	stp	x8, x0, [x29, #-0x100]
1004b8148:	ldr	x8, [x8, #0x40]
1004b814c:	mov	x9, x8
1004b8150:	adrp	x16, 7699 ; 0x1022cb000
1004b8154:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b8158:	blr	x16
1004b815c:	mov	x9, sp
1004b8160:	add	x10, x8, #0xf
1004b8164:	and	x12, x10, #0xfffffffffffffff0
1004b8168:	sub	x9, x9, x12
1004b816c:	sub	x10, x29, #0x8
1004b8170:	stur	x9, [x10, #-0x100]
1004b8174:	mov	sp, x9
1004b8178:	mov	x9, x8
1004b817c:	adrp	x16, 7699 ; 0x1022cb000
1004b8180:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b8184:	blr	x16
1004b8188:	mov	x8, sp
1004b818c:	sub	x24, x8, x12
1004b8190:	mov	sp, x24
1004b8194:	ldr	x25, [x19, #0x18]
1004b8198:	ldr	x8, [x25]
1004b819c:	ldr	x19, [x8, #0x78]
1004b81a0:	mov	x20, x25
1004b81a4:	blr	x19
1004b81a8:	mov	x20, x0
1004b81ac:	ldr	x8, [x0]
1004b81b0:	ldr	x8, [x8, #0x110]
1004b81b4:	blr	x8
1004b81b8:	mov	x27, x0
1004b81bc:	mov	x0, x20
1004b81c0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b81c4:	mov	x20, x25
1004b81c8:	blr	x19
1004b81cc:	mov	x20, x0
1004b81d0:	ldr	x8, [x0]
1004b81d4:	ldr	x8, [x8, #0x90]
1004b81d8:	blr	x8
1004b81dc:	stur	x0, [x29, #-0xe0]
1004b81e0:	mov	x28, x1
1004b81e4:	mov	x0, x20
1004b81e8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b81ec:	ldr	x26, [x27, #0x10]
1004b81f0:	cbz	x26, 0x1004b8880
1004b81f4:	sub	x8, x29, #0x30
1004b81f8:	stur	x22, [x8, #-0x100]
1004b81fc:	sub	x8, x29, #0x48
1004b8200:	stur	x21, [x8, #-0x100]
1004b8204:	adrp	x8, 7909 ; 0x10239d000
1004b8208:	ldr	x8, [x8, #0x270]
1004b820c:	ldur	x9, [x29, #-0xe8]
1004b8210:	add	x21, x9, x8
1004b8214:	ldr	x8, [x25]
1004b8218:	ldr	x19, [x8, #0x90]
1004b821c:	sub	x8, x29, #0x70
1004b8220:	stur	x27, [x8, #-0x100]
1004b8224:	add	x27, x27, #0x28
1004b8228:	mov	x8, #0x800000000000
1004b822c:	movk	x8, #0x4071, lsl #48
1004b8230:	fmov	d9, x8
1004b8234:	fmov	d10, #28.00000000
1004b8238:	sub	x8, x29, #0x10
1004b823c:	stur	x24, [x8, #-0x100]
1004b8240:	sub	x8, x29, #0x18
1004b8244:	stur	x25, [x8, #-0x100]
1004b8248:	sub	x8, x29, #0x20
1004b824c:	stur	x28, [x8, #-0x100]
1004b8250:	sub	x8, x29, #0x38
1004b8254:	stur	x21, [x8, #-0x100]
1004b8258:	sub	x8, x29, #0x28
1004b825c:	stur	x19, [x8, #-0x100]
1004b8260:	b	0x1004b8278
1004b8264:	mov	x0, x20
1004b8268:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b826c:	add	x27, x27, #0x10
1004b8270:	subs	x26, x26, #0x1
1004b8274:	b.eq	0x1004b886c
1004b8278:	ldp	x23, x22, [x27, #-0x8]
1004b827c:	mov	x20, x25
1004b8280:	blr	x19
1004b8284:	mov	x20, x0
1004b8288:	ldr	x8, [x0, #0x10]
1004b828c:	cbz	x8, 0x1004b8264
1004b8290:	mov	x0, x23
1004b8294:	mov	x1, x22
1004b8298:	bl	0x1000240a8
1004b829c:	tbz	w1, #0x0, 0x1004b8264
1004b82a0:	ldr	x8, [x20, #0x38]
1004b82a4:	ldur	x9, [x29, #-0x100]
1004b82a8:	ldr	x9, [x9, #0x48]
1004b82ac:	madd	x0, x9, x0, x8
1004b82b0:	sub	x8, x29, #0x8
1004b82b4:	ldur	x19, [x8, #-0x100]
1004b82b8:	mov	x1, x19
1004b82bc:	adrp	x25, 468 ; 0x10068c000
1004b82c0:	add	x25, x25, #0x794
1004b82c4:	mov	x2, x25
1004b82c8:	bl	0x1000e73b0
1004b82cc:	mov	x0, x20
1004b82d0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b82d4:	mov	x0, x19
1004b82d8:	mov	x1, x24
1004b82dc:	mov	x2, x25
1004b82e0:	bl	0x1000840ec
1004b82e4:	ldur	x8, [x29, #-0xe0]
1004b82e8:	cmp	x23, x8
1004b82ec:	stur	x23, [x29, #-0xc8]
1004b82f0:	b.ne	0x1004b8308
1004b82f4:	cmp	x22, x28
1004b82f8:	b.ne	0x1004b8308
1004b82fc:	mov	w8, #0x1
1004b8300:	stur	w8, [x29, #-0xcc]
1004b8304:	b	0x1004b8324
1004b8308:	mov	x0, x23
1004b830c:	mov	x1, x22
1004b8310:	ldur	x2, [x29, #-0xe0]
1004b8314:	mov	x3, x28
1004b8318:	mov	w4, #0x0
1004b831c:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004b8320:	stur	w0, [x29, #-0xcc]
1004b8324:	adrp	x19, 468 ; 0x10068c000
1004b8328:	add	x19, x19, #0x76c
1004b832c:	mov	x0, x24
1004b8330:	ldur	x1, [x29, #-0xf8]
1004b8334:	bl	0x101aca78c ; symbol stub for: _swift_getEnumCaseMultiPayload
1004b8338:	cmp	w0, #0x1
1004b833c:	b.gt	0x1004b83d8
1004b8340:	cbnz	w0, 0x1004b8424
1004b8344:	ldr	x24, [x24]
1004b8348:	ldr	x8, [x24]
1004b834c:	ldr	x19, [x8, #0x2d0]
1004b8350:	mov	x0, x24
1004b8354:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b8358:	mov	x20, x24
1004b835c:	blr	x19
1004b8360:	mov	x28, x0
1004b8364:	mov	x25, x1
1004b8368:	ldr	x8, [x24]
1004b836c:	ldr	x8, [x8, #0x408]
1004b8370:	blr	x8
1004b8374:	mov	x20, x1
1004b8378:	bl	0x10006aee0
1004b837c:	mov	x23, x0
1004b8380:	mov	x19, x1
1004b8384:	mov	x0, x20
1004b8388:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b838c:	and	x8, x28, #0xffffffffffff
1004b8390:	ubfx	x9, x25, #56, #4
1004b8394:	tst	x25, #0x2000000000000000
1004b8398:	csel	x8, x8, x9, eq
1004b839c:	cbz	x8, 0x1004b85b4
1004b83a0:	stp	x28, x25, [x29, #-0xc0]
1004b83a4:	sub	x20, x29, #0xc0
1004b83a8:	mov	x0, #0xe220
1004b83ac:	movk	x0, #0x9480, lsl #16
1004b83b0:	movk	x0, #0x20, lsl #32
1004b83b4:	mov	x1, #-0x5b00000000000000
1004b83b8:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004b83bc:	mov	x0, x23
1004b83c0:	mov	x1, x19
1004b83c4:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004b83c8:	mov	x0, x19
1004b83cc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b83d0:	mov	x0, x24
1004b83d4:	b	0x1004b85a4
1004b83d8:	cmp	w0, #0x2
1004b83dc:	b.ne	0x1004b8528
1004b83e0:	mov	x0, x24
1004b83e4:	sub	x8, x29, #0x48
1004b83e8:	ldur	x20, [x8, #-0x100]
1004b83ec:	mov	x1, x20
1004b83f0:	adrp	x2, 468 ; 0x10068c000
1004b83f4:	add	x2, x2, #0x780
1004b83f8:	bl	0x1000e73b0
1004b83fc:	bl	0x101ac4dec ; symbol stub for: _$s10Foundation3URLV4hostSSSgvg
1004b8400:	cbnz	x1, 0x1004b8408
1004b8404:	bl	0x101ac4d38 ; symbol stub for: _$s10Foundation3URLV14absoluteStringSSvg
1004b8408:	mov	x19, x1
1004b840c:	stur	x0, [x29, #-0xd8]
1004b8410:	mov	x0, x20
1004b8414:	adrp	x1, 468 ; 0x10068c000
1004b8418:	add	x1, x1, #0x780
1004b841c:	bl	0x100059058
1004b8420:	b	0x1004b8698
1004b8424:	mov	x0, x24
1004b8428:	sub	x8, x29, #0x30
1004b842c:	ldur	x20, [x8, #-0x100]
1004b8430:	mov	x1, x20
1004b8434:	mov	x2, x19
1004b8438:	bl	0x1000e73b0
1004b843c:	sub	x8, x29, #0x40
1004b8440:	ldur	x8, [x8, #-0x100]
1004b8444:	ldrsw	x8, [x8, #0x18]
1004b8448:	add	x8, x20, x8
1004b844c:	ldr	x24, [x8, #0x18]
1004b8450:	cbz	x24, 0x1004b85cc
1004b8454:	ldp	x4, x25, [x8, #0x20]
1004b8458:	ldp	x28, x23, [x8, #0x8]
1004b845c:	ldr	x21, [x8]
1004b8460:	stp	x21, x28, [x29, #-0xa8]
1004b8464:	stp	x23, x24, [x29, #-0x98]
1004b8468:	stp	x4, x25, [x29, #-0x88]
1004b846c:	mov	x0, x21
1004b8470:	mov	x1, x28
1004b8474:	mov	x2, x23
1004b8478:	mov	x3, x24
1004b847c:	mov	x19, x4
1004b8480:	sub	x8, x29, #0x50
1004b8484:	stur	x4, [x8, #-0x100]
1004b8488:	mov	x5, x25
1004b848c:	bl	0x1000db8bc
1004b8490:	mov	x0, x21
1004b8494:	mov	x1, x28
1004b8498:	mov	x2, x23
1004b849c:	mov	x3, x24
1004b84a0:	mov	x4, x19
1004b84a4:	mov	x5, x25
1004b84a8:	bl	0x1000db8bc
1004b84ac:	sub	x20, x29, #0xa8
1004b84b0:	bl	0x1001ded98
1004b84b4:	stur	x0, [x29, #-0xd8]
1004b84b8:	mov	x19, x1
1004b84bc:	mov	x0, x25
1004b84c0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b84c4:	mov	x0, x24
1004b84c8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b84cc:	mov	x0, x28
1004b84d0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b84d4:	sub	x8, x29, #0x30
1004b84d8:	ldur	x0, [x8, #-0x100]
1004b84dc:	adrp	x1, 468 ; 0x10068c000
1004b84e0:	add	x1, x1, #0x76c
1004b84e4:	bl	0x100059058
1004b84e8:	mov	x0, x21
1004b84ec:	mov	x1, x28
1004b84f0:	mov	x2, x23
1004b84f4:	mov	x3, x24
1004b84f8:	sub	x8, x29, #0x50
1004b84fc:	ldur	x4, [x8, #-0x100]
1004b8500:	mov	x5, x25
1004b8504:	bl	0x1000db95c
1004b8508:	mov	x0, #0x0
1004b850c:	mov	x1, #0x0
1004b8510:	mov	x2, #0x0
1004b8514:	mov	x3, #0x0
1004b8518:	mov	x4, #0x0
1004b851c:	mov	x5, #0x0
1004b8520:	bl	0x1000db95c
1004b8524:	b	0x1004b8690
1004b8528:	ldr	x19, [x24]
1004b852c:	mov	x0, x19
1004b8530:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b8534:	mov	x20, x19
1004b8538:	bl	0x100495448
1004b853c:	stp	x0, x1, [x29, #-0xc0]
1004b8540:	sub	x20, x29, #0xc0
1004b8544:	mov	x0, #0xe220
1004b8548:	movk	x0, #0x9480, lsl #16
1004b854c:	movk	x0, #0x20, lsl #32
1004b8550:	mov	x1, #-0x5b00000000000000
1004b8554:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004b8558:	ldp	x20, x21, [x19, #0x10]
1004b855c:	mov	x0, x21
1004b8560:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b8564:	mov	x0, x20
1004b8568:	mov	x1, x21
1004b856c:	bl	0x10006aee0
1004b8570:	mov	x24, x0
1004b8574:	mov	x23, x1
1004b8578:	mov	x0, x21
1004b857c:	sub	x8, x29, #0x38
1004b8580:	ldur	x21, [x8, #-0x100]
1004b8584:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b8588:	sub	x20, x29, #0xc0
1004b858c:	mov	x0, x24
1004b8590:	mov	x1, x23
1004b8594:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004b8598:	mov	x0, x23
1004b859c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b85a0:	mov	x0, x19
1004b85a4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b85a8:	ldp	x8, x19, [x29, #-0xc0]
1004b85ac:	stur	x8, [x29, #-0xd8]
1004b85b0:	b	0x1004b8698
1004b85b4:	mov	x0, x25
1004b85b8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b85bc:	mov	x0, x24
1004b85c0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b85c4:	stur	x23, [x29, #-0xd8]
1004b85c8:	b	0x1004b8698
1004b85cc:	bl	0x101ac4d74 ; symbol stub for: _$s10Foundation3URLV17lastPathComponentSSvg
1004b85d0:	mov	x23, x0
1004b85d4:	mov	x19, x1
1004b85d8:	sub	x8, x29, #0x68
1004b85dc:	ldur	x21, [x8, #-0x100]
1004b85e0:	mov	x8, x21
1004b85e4:	bl	0x101ac4dc8 ; symbol stub for: _$s10Foundation3URLV25deletingLastPathComponentACyF
1004b85e8:	mov	x20, x21
1004b85ec:	bl	0x101ac4df8 ; symbol stub for: _$s10Foundation3URLV4pathSSvg
1004b85f0:	mov	x20, x0
1004b85f4:	mov	x28, x1
1004b85f8:	sub	x8, x29, #0x60
1004b85fc:	ldur	x8, [x8, #-0x100]
1004b8600:	ldr	x8, [x8, #0x8]
1004b8604:	mov	x0, x21
1004b8608:	sub	x9, x29, #0x58
1004b860c:	ldur	x1, [x9, #-0x100]
1004b8610:	blr	x8
1004b8614:	mov	x0, x20
1004b8618:	mov	x1, x28
1004b861c:	bl	0x10006aee0
1004b8620:	mov	x25, x0
1004b8624:	mov	x24, x1
1004b8628:	mov	x0, x28
1004b862c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b8630:	and	x8, x25, #0xffffffffffff
1004b8634:	ubfx	x9, x24, #56, #4
1004b8638:	tst	x24, #0x2000000000000000
1004b863c:	csel	x8, x8, x9, eq
1004b8640:	cbz	x8, 0x1004b8828
1004b8644:	stp	x23, x19, [x29, #-0xc0]
1004b8648:	sub	x20, x29, #0xc0
1004b864c:	mov	x0, #0xe220
1004b8650:	movk	x0, #0x9480, lsl #16
1004b8654:	movk	x0, #0x20, lsl #32
1004b8658:	mov	x1, #-0x5b00000000000000
1004b865c:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004b8660:	mov	x0, x25
1004b8664:	mov	x1, x24
1004b8668:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004b866c:	mov	x0, x24
1004b8670:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b8674:	sub	x8, x29, #0x30
1004b8678:	ldur	x0, [x8, #-0x100]
1004b867c:	adrp	x1, 468 ; 0x10068c000
1004b8680:	add	x1, x1, #0x76c
1004b8684:	bl	0x100059058
1004b8688:	ldp	x8, x19, [x29, #-0xc0]
1004b868c:	stur	x8, [x29, #-0xd8]
1004b8690:	sub	x8, x29, #0x38
1004b8694:	ldur	x21, [x8, #-0x100]
1004b8698:	mov	x0, x19
1004b869c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b86a0:	adrp	x0, 7458 ; 0x1021da000
1004b86a4:	add	x0, x0, #0x978
1004b86a8:	mov	w1, #0x18
1004b86ac:	mov	w2, #0x7
1004b86b0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b86b4:	mov	x28, x0
1004b86b8:	add	x0, x0, #0x10
1004b86bc:	ldur	x1, [x29, #-0xe8]
1004b86c0:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b86c4:	adrp	x0, 7459 ; 0x1021db000
1004b86c8:	add	x0, x0, #0x5f8
1004b86cc:	mov	w1, #0x28
1004b86d0:	mov	w2, #0x7
1004b86d4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b86d8:	mov	x24, x0
1004b86dc:	ldur	x23, [x29, #-0xc8]
1004b86e0:	stp	x28, x23, [x0, #0x10]
1004b86e4:	str	x22, [x0, #0x20]
1004b86e8:	mov	x0, #0x0
1004b86ec:	bl	0x1004af7b4
1004b86f0:	mov	x20, x0
1004b86f4:	mov	x0, x28
1004b86f8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b86fc:	mov	x0, x22
1004b8700:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b8704:	movi.2d	v0, #0000000000000000
1004b8708:	fmov	d3, #28.00000000
1004b870c:	mov.16b	v1, v8
1004b8710:	mov.16b	v2, v9
1004b8714:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b8718:	mov	x25, x0
1004b871c:	ldr	x8, [x0]
1004b8720:	adrp	x9, 7703 ; 0x1022cf000
1004b8724:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b8728:	ldr	x9, [x9]
1004b872c:	and	x8, x9, x8
1004b8730:	ldr	x8, [x8, #0x148]
1004b8734:	str	x24, [sp, #-0x10]!
1004b8738:	ldur	w9, [x29, #-0xcc]
1004b873c:	and	w4, w9, #0x1
1004b8740:	ldur	x0, [x29, #-0xd8]
1004b8744:	mov	x1, x19
1004b8748:	mov	x2, #0x0
1004b874c:	mov	x3, #0x0
1004b8750:	mov	x5, x23
1004b8754:	mov	x6, x22
1004b8758:	adrp	x7, 10 ; 0x1004c2000
1004b875c:	add	x7, x7, #0x91c
1004b8760:	mov	x20, x25
1004b8764:	blr	x8
1004b8768:	add	sp, sp, #0x10
1004b876c:	ldur	x0, [x29, #-0xf0]
1004b8770:	mov	x2, x25
1004b8774:	bl	0x101acb460 ; selector addSubview:
1004b8778:	sub	x1, x29, #0xc0
1004b877c:	mov	x0, x21
1004b8780:	mov	w2, #0x21
1004b8784:	mov	x3, #0x0
1004b8788:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b878c:	mov	x20, x21
1004b8790:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b8794:	ldr	x8, [x21]
1004b8798:	and	x8, x8, #0xffffffffffffff8
1004b879c:	ldp	x21, x8, [x8, #0x10]
1004b87a0:	cmp	x21, x8, lsr #1
1004b87a4:	b.hs	0x1004b8854
1004b87a8:	mov	x0, x25
1004b87ac:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b87b0:	mov	x22, x0
1004b87b4:	mov	x0, x21
1004b87b8:	mov	x1, x22
1004b87bc:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b87c0:	sub	x0, x29, #0xc0
1004b87c4:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b87c8:	mov	x0, x22
1004b87cc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b87d0:	mov	x0, x24
1004b87d4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b87d8:	mov	x0, x19
1004b87dc:	mov	w1, #0x2
1004b87e0:	bl	0x101aca618 ; symbol stub for: _swift_bridgeObjectRelease_n
1004b87e4:	fadd	d8, d8, d10
1004b87e8:	sub	x8, x29, #0x10
1004b87ec:	ldur	x24, [x8, #-0x100]
1004b87f0:	mov	x0, x24
1004b87f4:	adrp	x1, 468 ; 0x10068c000
1004b87f8:	add	x1, x1, #0x794
1004b87fc:	bl	0x100059058
1004b8800:	mov	x0, x28
1004b8804:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b8808:	sub	x8, x29, #0x18
1004b880c:	ldur	x25, [x8, #-0x100]
1004b8810:	sub	x8, x29, #0x20
1004b8814:	ldur	x28, [x8, #-0x100]
1004b8818:	mov	x21, x20
1004b881c:	sub	x8, x29, #0x28
1004b8820:	ldur	x19, [x8, #-0x100]
1004b8824:	b	0x1004b826c
1004b8828:	sub	x8, x29, #0x30
1004b882c:	ldur	x0, [x8, #-0x100]
1004b8830:	adrp	x1, 468 ; 0x10068c000
1004b8834:	add	x1, x1, #0x76c
1004b8838:	bl	0x100059058
1004b883c:	mov	x0, x24
1004b8840:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b8844:	sub	x8, x29, #0x38
1004b8848:	ldur	x21, [x8, #-0x100]
1004b884c:	stur	x23, [x29, #-0xd8]
1004b8850:	b	0x1004b8698
1004b8854:	cmp	x8, #0x1
1004b8858:	cset	w0, hi
1004b885c:	add	x1, x21, #0x1
1004b8860:	mov	w2, #0x1
1004b8864:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b8868:	b	0x1004b87a8
1004b886c:	mov	x0, x28
1004b8870:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b8874:	sub	x8, x29, #0x70
1004b8878:	ldur	x0, [x8, #-0x100]
1004b887c:	b	0x1004b888c
1004b8880:	mov	x0, x28
1004b8884:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b8888:	mov	x0, x27
1004b888c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b8890:	mov.16b	v0, v8
1004b8894:	sub	sp, x29, #0x70
1004b8898:	ldp	x29, x30, [sp, #0x70]
1004b889c:	ldp	x20, x19, [sp, #0x60]
1004b88a0:	ldp	x22, x21, [sp, #0x50]
1004b88a4:	ldp	x24, x23, [sp, #0x40]
1004b88a8:	ldp	x26, x25, [sp, #0x30]
1004b88ac:	ldp	x28, x27, [sp, #0x20]
1004b88b0:	ldp	d9, d8, [sp, #0x10]
1004b88b4:	ldp	d11, d10, [sp], #0x80
1004b88b8:	ret
1004b88bc:	sub	sp, sp, #0x80
1004b88c0:	stp	x26, x25, [sp, #0x30]
1004b88c4:	stp	x24, x23, [sp, #0x40]
1004b88c8:	stp	x22, x21, [sp, #0x50]
1004b88cc:	stp	x20, x19, [sp, #0x60]
1004b88d0:	stp	x29, x30, [sp, #0x70]
1004b88d4:	add	x29, sp, #0x70
1004b88d8:	mov	x19, x0
1004b88dc:	adrp	x8, 7909 ; 0x10239d000
1004b88e0:	ldr	x23, [x8, #0x278]
1004b88e4:	ldr	x21, [x20, x23]
1004b88e8:	tbnz	x21, #0x3f, 0x1004b89b4
1004b88ec:	adrp	x8, 7909 ; 0x10239d000
1004b88f0:	ldr	x22, [x8, #0x270]
1004b88f4:	add	x0, x20, x22
1004b88f8:	mov	x1, sp
1004b88fc:	mov	x2, #0x0
1004b8900:	mov	x3, #0x0
1004b8904:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b8908:	ldr	x22, [x20, x22]
1004b890c:	tst	x22, #0xc000000000000001
1004b8910:	b.ne	0x1004b8b78
1004b8914:	and	x8, x22, #0xffffffffffffff8
1004b8918:	ldr	x8, [x8, #0x10]
1004b891c:	cmp	x21, x8
1004b8920:	b.hs	0x1004b8b9c
1004b8924:	add	x8, x22, x21, lsl #3
1004b8928:	ldr	x0, [x8, #0x20]
1004b892c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b8930:	mov	x21, x0
1004b8934:	mov	x0, #0x0
1004b8938:	bl	0x1004a7e0c
1004b893c:	mov	x1, x0
1004b8940:	mov	x0, x21
1004b8944:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b8948:	cbz	x0, 0x1004b89a8
1004b894c:	mov	x22, x0
1004b8950:	ldr	x8, [x0]
1004b8954:	adrp	x24, 7703 ; 0x1022cf000
1004b8958:	ldr	x24, [x24, #0x718] ; literal pool symbol address: _swift_isaMask
1004b895c:	ldr	x9, [x24]
1004b8960:	and	x8, x9, x8
1004b8964:	ldr	x8, [x8, #0x1d0]
1004b8968:	mov	x25, x20
1004b896c:	mov	x20, x0
1004b8970:	blr	x8
1004b8974:	mov	x20, x25
1004b8978:	tbz	w0, #0x0, 0x1004b89a8
1004b897c:	ldr	x8, [x22]
1004b8980:	ldr	x9, [x24]
1004b8984:	and	x8, x9, x8
1004b8988:	ldr	x8, [x8, #0x218]
1004b898c:	mov	x0, x19
1004b8990:	mov	x20, x22
1004b8994:	blr	x8
1004b8998:	mov	x22, x0
1004b899c:	mov	x0, x21
1004b89a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b89a4:	b	0x1004b8b48
1004b89a8:	mov	x0, x21
1004b89ac:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b89b0:	ldr	x21, [x20, x23]
1004b89b4:	cmn	x21, #0x1
1004b89b8:	b.eq	0x1004b89f8
1004b89bc:	mov	w22, #0x0
1004b89c0:	and	w8, w19, #0xffff
1004b89c4:	cmp	w8, #0x7b
1004b89c8:	b.gt	0x1004b8a0c
1004b89cc:	cmp	w8, #0x24
1004b89d0:	b.eq	0x1004b8a34
1004b89d4:	cmp	w8, #0x4c
1004b89d8:	b.eq	0x1004b8a34
1004b89dc:	cmp	w8, #0x7b
1004b89e0:	b.ne	0x1004b8b48
1004b89e4:	mov	x0, #0x0
1004b89e8:	bl	0x1004ad03c
1004b89ec:	mov	x20, x0
1004b89f0:	bl	0x1004a9cc4
1004b89f4:	b	0x1004b8b44
1004b89f8:	and	w8, w19, #0xffff
1004b89fc:	cmp	w8, #0x7d
1004b8a00:	b.eq	0x1004b8a24
1004b8a04:	mov	w22, #0x0
1004b8a08:	b	0x1004b8b48
1004b8a0c:	cmp	w8, #0x7c
1004b8a10:	b.eq	0x1004b8a3c
1004b8a14:	cmp	w8, #0x7e
1004b8a18:	b.eq	0x1004b8abc
1004b8a1c:	cmp	w8, #0x7d
1004b8a20:	b.ne	0x1004b8b48
1004b8a24:	mov	w22, #0x1
1004b8a28:	mov	w0, #0x1
1004b8a2c:	bl	0x1004b8bf4
1004b8a30:	b	0x1004b8b48
1004b8a34:	bl	0x1004b9238
1004b8a38:	b	0x1004b8b44
1004b8a3c:	tbnz	x21, #0x3f, 0x1004b8a04
1004b8a40:	adrp	x8, 7909 ; 0x10239d000
1004b8a44:	ldr	x24, [x8, #0x270]
1004b8a48:	add	x0, x20, x24
1004b8a4c:	add	x1, sp, #0x18
1004b8a50:	mov	x2, #0x0
1004b8a54:	mov	x3, #0x0
1004b8a58:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b8a5c:	ldr	x22, [x20, x24]
1004b8a60:	tst	x22, #0xc000000000000001
1004b8a64:	b.ne	0x1004b8ba0
1004b8a68:	and	x8, x22, #0xffffffffffffff8
1004b8a6c:	ldr	x8, [x8, #0x10]
1004b8a70:	cmp	x21, x8
1004b8a74:	b.hs	0x1004b8bc4
1004b8a78:	add	x8, x22, x21, lsl #3
1004b8a7c:	ldr	x0, [x8, #0x20]
1004b8a80:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b8a84:	mov	x19, x0
1004b8a88:	mov	x0, #0x0
1004b8a8c:	bl	0x1004ad03c
1004b8a90:	mov	x1, x0
1004b8a94:	mov	x0, x19
1004b8a98:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b8a9c:	cbz	x0, 0x1004b8ac8
1004b8aa0:	ldr	x8, [x0]
1004b8aa4:	adrp	x9, 7703 ; 0x1022cf000
1004b8aa8:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b8aac:	ldr	x9, [x9]
1004b8ab0:	and	x8, x9, x8
1004b8ab4:	ldr	x8, [x8, #0x1b8]
1004b8ab8:	b	0x1004b8b34
1004b8abc:	mov	x0, #-0x1
1004b8ac0:	bl	0x1004b8bf4
1004b8ac4:	b	0x1004b8b44
1004b8ac8:	mov	x0, x19
1004b8acc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b8ad0:	ldr	x19, [x20, x23]
1004b8ad4:	ldr	x20, [x20, x24]
1004b8ad8:	tst	x20, #0xc000000000000001
1004b8adc:	b.ne	0x1004b8bc8
1004b8ae0:	tbnz	x19, #0x3f, 0x1004b8bec
1004b8ae4:	and	x8, x20, #0xffffffffffffff8
1004b8ae8:	ldr	x8, [x8, #0x10]
1004b8aec:	cmp	x19, x8
1004b8af0:	b.hs	0x1004b8bf0
1004b8af4:	add	x8, x20, x19, lsl #3
1004b8af8:	ldr	x0, [x8, #0x20]
1004b8afc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b8b00:	mov	x19, x0
1004b8b04:	mov	x0, #0x0
1004b8b08:	bl	0x1004a7e0c
1004b8b0c:	mov	x1, x0
1004b8b10:	mov	x0, x19
1004b8b14:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b8b18:	cbz	x0, 0x1004b8b68
1004b8b1c:	ldr	x8, [x0]
1004b8b20:	adrp	x9, 7703 ; 0x1022cf000
1004b8b24:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b8b28:	ldr	x9, [x9]
1004b8b2c:	and	x8, x9, x8
1004b8b30:	ldr	x8, [x8, #0x208]
1004b8b34:	mov	x20, x0
1004b8b38:	blr	x8
1004b8b3c:	mov	x0, x19
1004b8b40:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b8b44:	mov	w22, #0x1
1004b8b48:	and	w0, w22, #0x1
1004b8b4c:	ldp	x29, x30, [sp, #0x70]
1004b8b50:	ldp	x20, x19, [sp, #0x60]
1004b8b54:	ldp	x22, x21, [sp, #0x50]
1004b8b58:	ldp	x24, x23, [sp, #0x40]
1004b8b5c:	ldp	x26, x25, [sp, #0x30]
1004b8b60:	add	sp, sp, #0x80
1004b8b64:	ret
1004b8b68:	mov	x0, x19
1004b8b6c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b8b70:	mov	w22, #0x0
1004b8b74:	b	0x1004b8b48
1004b8b78:	mov	x0, x22
1004b8b7c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b8b80:	mov	x0, x21
1004b8b84:	mov	x1, x22
1004b8b88:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b8b8c:	mov	x21, x0
1004b8b90:	mov	x0, x22
1004b8b94:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b8b98:	b	0x1004b8934
1004b8b9c:	brk	#0x1
1004b8ba0:	mov	x0, x22
1004b8ba4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b8ba8:	mov	x0, x21
1004b8bac:	mov	x1, x22
1004b8bb0:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b8bb4:	mov	x19, x0
1004b8bb8:	mov	x0, x22
1004b8bbc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b8bc0:	b	0x1004b8a88
1004b8bc4:	brk	#0x1
1004b8bc8:	mov	x0, x20
1004b8bcc:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b8bd0:	mov	x0, x19
1004b8bd4:	mov	x1, x20
1004b8bd8:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b8bdc:	mov	x19, x0
1004b8be0:	mov	x0, x20
1004b8be4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b8be8:	b	0x1004b8b04
1004b8bec:	brk	#0x1
1004b8bf0:	brk	#0x1
1004b8bf4:	sub	sp, sp, #0x60
1004b8bf8:	stp	x24, x23, [sp, #0x20]
1004b8bfc:	stp	x22, x21, [sp, #0x30]
1004b8c00:	stp	x20, x19, [sp, #0x40]
1004b8c04:	stp	x29, x30, [sp, #0x50]
1004b8c08:	add	x29, sp, #0x50
1004b8c0c:	mov	x19, x0
1004b8c10:	adrp	x8, 7909 ; 0x10239d000
1004b8c14:	ldr	x24, [x8, #0x278]
1004b8c18:	ldr	x21, [x20, x24]
1004b8c1c:	adrp	x8, 7909 ; 0x10239d000
1004b8c20:	ldr	x23, [x8, #0x270]
1004b8c24:	add	x0, x20, x23
1004b8c28:	add	x1, sp, #0x8
1004b8c2c:	mov	x2, #0x0
1004b8c30:	mov	x3, #0x0
1004b8c34:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b8c38:	ldr	x8, [x20, x23]
1004b8c3c:	lsr	x9, x8, #62
1004b8c40:	cbnz	x9, 0x1004b9070
1004b8c44:	and	x8, x8, #0xffffffffffffff8
1004b8c48:	ldr	x0, [x8, #0x10]
1004b8c4c:	subs	x8, x0, #0x1
1004b8c50:	b.vs	0x1004b9088
1004b8c54:	ldr	x9, [x20, x24]
1004b8c58:	adds	x9, x9, x19
1004b8c5c:	b.vs	0x1004b908c
1004b8c60:	cmp	x9, x8
1004b8c64:	csel	x19, x9, x8, lt
1004b8c68:	cmn	x19, #0x2
1004b8c6c:	b.le	0x1004b8c80
1004b8c70:	cmp	x19, x21
1004b8c74:	b.eq	0x1004b8fe0
1004b8c78:	tbz	x21, #0x3f, 0x1004b8c90
1004b8c7c:	b	0x1004b8e38
1004b8c80:	cmn	x21, #0x1
1004b8c84:	b.eq	0x1004b8fe0
1004b8c88:	mov	x19, #-0x1
1004b8c8c:	tbnz	x21, #0x3f, 0x1004b8cfc
1004b8c90:	ldr	x8, [x20, x23]
1004b8c94:	lsr	x9, x8, #62
1004b8c98:	cbnz	x9, 0x1004b9090
1004b8c9c:	and	x8, x8, #0xffffffffffffff8
1004b8ca0:	ldr	x0, [x8, #0x10]
1004b8ca4:	cmp	x21, x0
1004b8ca8:	b.ge	0x1004b8e38
1004b8cac:	ldr	x8, [x20, x23]
1004b8cb0:	tst	x8, #0xc000000000000001
1004b8cb4:	b.ne	0x1004b90c8
1004b8cb8:	and	x9, x8, #0xffffffffffffff8
1004b8cbc:	ldr	x9, [x9, #0x10]
1004b8cc0:	cmp	x21, x9
1004b8cc4:	b.hs	0x1004b90f8
1004b8cc8:	add	x8, x8, x21, lsl #3
1004b8ccc:	ldr	x0, [x8, #0x20]
1004b8cd0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b8cd4:	mov	x22, x0
1004b8cd8:	mov	x0, #0x0
1004b8cdc:	bl	0x1004aede4
1004b8ce0:	mov	x1, x0
1004b8ce4:	mov	x0, x22
1004b8ce8:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b8cec:	cbz	x0, 0x1004b8d04
1004b8cf0:	mov	x21, x20
1004b8cf4:	mov	w8, #0x148
1004b8cf8:	b	0x1004b8e08
1004b8cfc:	str	x19, [x20, x24]
1004b8d00:	b	0x1004b8ed8
1004b8d04:	mov	x0, x22
1004b8d08:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b8d0c:	ldr	x8, [x20, x23]
1004b8d10:	tst	x8, #0xc000000000000001
1004b8d14:	b.ne	0x1004b9124
1004b8d18:	and	x9, x8, #0xffffffffffffff8
1004b8d1c:	ldr	x9, [x9, #0x10]
1004b8d20:	cmp	x21, x9
1004b8d24:	b.hs	0x1004b9154
1004b8d28:	add	x8, x8, x21, lsl #3
1004b8d2c:	ldr	x0, [x8, #0x20]
1004b8d30:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b8d34:	mov	x22, x0
1004b8d38:	mov	x0, #0x0
1004b8d3c:	bl	0x1004ad03c
1004b8d40:	mov	x1, x0
1004b8d44:	mov	x0, x22
1004b8d48:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b8d4c:	cbz	x0, 0x1004b8d5c
1004b8d50:	mov	x21, x20
1004b8d54:	mov	w8, #0x1b0
1004b8d58:	b	0x1004b8e08
1004b8d5c:	mov	x0, x22
1004b8d60:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b8d64:	ldr	x8, [x20, x23]
1004b8d68:	tst	x8, #0xc000000000000001
1004b8d6c:	b.ne	0x1004b9180
1004b8d70:	and	x9, x8, #0xffffffffffffff8
1004b8d74:	ldr	x9, [x9, #0x10]
1004b8d78:	cmp	x21, x9
1004b8d7c:	b.hs	0x1004b91b0
1004b8d80:	add	x8, x8, x21, lsl #3
1004b8d84:	ldr	x0, [x8, #0x20]
1004b8d88:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b8d8c:	mov	x22, x0
1004b8d90:	mov	x0, #0x0
1004b8d94:	bl	0x1004af7b4
1004b8d98:	mov	x1, x0
1004b8d9c:	mov	x0, x22
1004b8da0:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b8da4:	cbz	x0, 0x1004b8db4
1004b8da8:	mov	x21, x20
1004b8dac:	mov	w8, #0x150
1004b8db0:	b	0x1004b8e08
1004b8db4:	mov	x0, x22
1004b8db8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b8dbc:	ldr	x8, [x20, x23]
1004b8dc0:	tst	x8, #0xc000000000000001
1004b8dc4:	b.ne	0x1004b91dc
1004b8dc8:	and	x9, x8, #0xffffffffffffff8
1004b8dcc:	ldr	x9, [x9, #0x10]
1004b8dd0:	cmp	x21, x9
1004b8dd4:	b.hs	0x1004b920c
1004b8dd8:	add	x8, x8, x21, lsl #3
1004b8ddc:	ldr	x0, [x8, #0x20]
1004b8de0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b8de4:	mov	x22, x0
1004b8de8:	mov	x0, #0x0
1004b8dec:	bl	0x1004a7e0c
1004b8df0:	mov	x1, x0
1004b8df4:	mov	x0, x22
1004b8df8:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b8dfc:	cbz	x0, 0x1004b8e30
1004b8e00:	mov	x21, x20
1004b8e04:	mov	w8, #0x200
1004b8e08:	ldr	x9, [x0]
1004b8e0c:	adrp	x10, 7703 ; 0x1022cf000
1004b8e10:	ldr	x10, [x10, #0x718] ; literal pool symbol address: _swift_isaMask
1004b8e14:	ldr	x10, [x10]
1004b8e18:	and	x9, x10, x9
1004b8e1c:	ldr	x8, [x9, x8]
1004b8e20:	mov	x20, x0
1004b8e24:	mov	w0, #0x0
1004b8e28:	blr	x8
1004b8e2c:	mov	x20, x21
1004b8e30:	mov	x0, x22
1004b8e34:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b8e38:	str	x19, [x20, x24]
1004b8e3c:	cmn	x19, #0x1
1004b8e40:	b.eq	0x1004b8ed8
1004b8e44:	adrp	x8, 7837 ; 0x102355000
1004b8e48:	ldr	x8, [x8, #0xd0]
1004b8e4c:	ldr	x0, [x20, x8]
1004b8e50:	cbz	x0, 0x1004b8e5c
1004b8e54:	mov	x2, #0x0
1004b8e58:	bl	0x101acf6e0 ; selector makeFirstResponder:
1004b8e5c:	ldr	x8, [x20, x23]
1004b8e60:	lsr	x9, x8, #62
1004b8e64:	cbnz	x9, 0x1004b90ac
1004b8e68:	and	x8, x8, #0xffffffffffffff8
1004b8e6c:	ldr	x0, [x8, #0x10]
1004b8e70:	cmp	x19, x0
1004b8e74:	b.ge	0x1004b8fe0
1004b8e78:	ldr	x22, [x20, x23]
1004b8e7c:	tst	x22, #0xc000000000000001
1004b8e80:	b.ne	0x1004b90fc
1004b8e84:	and	x8, x22, #0xffffffffffffff8
1004b8e88:	ldr	x8, [x8, #0x10]
1004b8e8c:	cmp	x19, x8
1004b8e90:	b.hs	0x1004b9120
1004b8e94:	add	x8, x22, x19, lsl #3
1004b8e98:	ldr	x0, [x8, #0x20]
1004b8e9c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b8ea0:	mov	x21, x0
1004b8ea4:	mov	x0, #0x0
1004b8ea8:	bl	0x1004aede4
1004b8eac:	mov	x1, x0
1004b8eb0:	mov	x0, x21
1004b8eb4:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b8eb8:	cbz	x0, 0x1004b8f00
1004b8ebc:	ldr	x8, [x0]
1004b8ec0:	adrp	x9, 7703 ; 0x1022cf000
1004b8ec4:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b8ec8:	ldr	x9, [x9]
1004b8ecc:	and	x8, x9, x8
1004b8ed0:	ldr	x8, [x8, #0x148]
1004b8ed4:	b	0x1004b8fcc
1004b8ed8:	adrp	x8, 7837 ; 0x102355000
1004b8edc:	ldr	x8, [x8, #0xe8]
1004b8ee0:	ldr	x2, [x20, x8]
1004b8ee4:	cbz	x2, 0x1004b8fe0
1004b8ee8:	adrp	x8, 7837 ; 0x102355000
1004b8eec:	ldr	x8, [x8, #0xd0]
1004b8ef0:	ldr	x0, [x20, x8]
1004b8ef4:	cbz	x0, 0x1004b8fe0
1004b8ef8:	bl	0x101acf6e0 ; selector makeFirstResponder:
1004b8efc:	b	0x1004b8fe0
1004b8f00:	mov	x0, x21
1004b8f04:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b8f08:	ldr	x22, [x20, x23]
1004b8f0c:	tst	x22, #0xc000000000000001
1004b8f10:	b.ne	0x1004b9158
1004b8f14:	and	x8, x22, #0xffffffffffffff8
1004b8f18:	ldr	x8, [x8, #0x10]
1004b8f1c:	cmp	x19, x8
1004b8f20:	b.hs	0x1004b917c
1004b8f24:	add	x8, x22, x19, lsl #3
1004b8f28:	ldr	x0, [x8, #0x20]
1004b8f2c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b8f30:	mov	x21, x0
1004b8f34:	mov	x0, #0x0
1004b8f38:	bl	0x1004ad03c
1004b8f3c:	mov	x1, x0
1004b8f40:	mov	x0, x21
1004b8f44:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b8f48:	cbz	x0, 0x1004b8f68
1004b8f4c:	ldr	x8, [x0]
1004b8f50:	adrp	x9, 7703 ; 0x1022cf000
1004b8f54:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b8f58:	ldr	x9, [x9]
1004b8f5c:	and	x8, x9, x8
1004b8f60:	ldr	x8, [x8, #0x1b0]
1004b8f64:	b	0x1004b8fcc
1004b8f68:	mov	x0, x21
1004b8f6c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b8f70:	ldr	x22, [x20, x23]
1004b8f74:	tst	x22, #0xc000000000000001
1004b8f78:	b.ne	0x1004b91b4
1004b8f7c:	and	x8, x22, #0xffffffffffffff8
1004b8f80:	ldr	x8, [x8, #0x10]
1004b8f84:	cmp	x19, x8
1004b8f88:	b.hs	0x1004b91d8
1004b8f8c:	add	x8, x22, x19, lsl #3
1004b8f90:	ldr	x0, [x8, #0x20]
1004b8f94:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b8f98:	mov	x21, x0
1004b8f9c:	mov	x0, #0x0
1004b8fa0:	bl	0x1004af7b4
1004b8fa4:	mov	x1, x0
1004b8fa8:	mov	x0, x21
1004b8fac:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b8fb0:	cbz	x0, 0x1004b8ff8
1004b8fb4:	ldr	x8, [x0]
1004b8fb8:	adrp	x9, 7703 ; 0x1022cf000
1004b8fbc:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b8fc0:	ldr	x9, [x9]
1004b8fc4:	and	x8, x9, x8
1004b8fc8:	ldr	x8, [x8, #0x150]
1004b8fcc:	mov	x20, x0
1004b8fd0:	mov	w0, #0x1
1004b8fd4:	blr	x8
1004b8fd8:	mov	x0, x21
1004b8fdc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b8fe0:	ldp	x29, x30, [sp, #0x50]
1004b8fe4:	ldp	x20, x19, [sp, #0x40]
1004b8fe8:	ldp	x22, x21, [sp, #0x30]
1004b8fec:	ldp	x24, x23, [sp, #0x20]
1004b8ff0:	add	sp, sp, #0x60
1004b8ff4:	ret
1004b8ff8:	mov	x0, x21
1004b8ffc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b9000:	ldr	x20, [x20, x23]
1004b9004:	tst	x20, #0xc000000000000001
1004b9008:	b.ne	0x1004b9210
1004b900c:	and	x8, x20, #0xffffffffffffff8
1004b9010:	ldr	x8, [x8, #0x10]
1004b9014:	cmp	x19, x8
1004b9018:	b.hs	0x1004b9234
1004b901c:	add	x8, x20, x19, lsl #3
1004b9020:	ldr	x0, [x8, #0x20]
1004b9024:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b9028:	mov	x19, x0
1004b902c:	mov	x0, #0x0
1004b9030:	bl	0x1004a7e0c
1004b9034:	mov	x1, x0
1004b9038:	mov	x0, x19
1004b903c:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b9040:	cbz	x0, 0x1004b9068
1004b9044:	mov	x20, x0
1004b9048:	ldr	x8, [x0]
1004b904c:	adrp	x9, 7702 ; 0x1022cf000
1004b9050:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b9054:	ldr	x9, [x9]
1004b9058:	and	x8, x9, x8
1004b905c:	ldr	x8, [x8, #0x200]
1004b9060:	mov	w0, #0x1
1004b9064:	blr	x8
1004b9068:	mov	x0, x19
1004b906c:	b	0x1004b8fdc
1004b9070:	and	x9, x8, #0xffffffffffffff8
1004b9074:	cmn	x8, #0x1
1004b9078:	csel	x0, x9, x8, gt
1004b907c:	bl	0x101ac7900 ; symbol stub for: _$ss18_CocoaArrayWrapperV8endIndexSivg
1004b9080:	subs	x8, x0, #0x1
1004b9084:	b.vc	0x1004b8c54
1004b9088:	brk	#0x1
1004b908c:	brk	#0x1
1004b9090:	and	x9, x8, #0xffffffffffffff8
1004b9094:	cmn	x8, #0x1
1004b9098:	csel	x0, x9, x8, gt
1004b909c:	bl	0x101ac7900 ; symbol stub for: _$ss18_CocoaArrayWrapperV8endIndexSivg
1004b90a0:	cmp	x21, x0
1004b90a4:	b.lt	0x1004b8cac
1004b90a8:	b	0x1004b8e38
1004b90ac:	and	x9, x8, #0xffffffffffffff8
1004b90b0:	cmn	x8, #0x1
1004b90b4:	csel	x0, x9, x8, gt
1004b90b8:	bl	0x101ac7900 ; symbol stub for: _$ss18_CocoaArrayWrapperV8endIndexSivg
1004b90bc:	cmp	x19, x0
1004b90c0:	b.lt	0x1004b8e78
1004b90c4:	b	0x1004b8fe0
1004b90c8:	str	x23, [sp]
1004b90cc:	mov	x23, x8
1004b90d0:	mov	x0, x8
1004b90d4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b90d8:	mov	x0, x21
1004b90dc:	mov	x1, x23
1004b90e0:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b90e4:	mov	x22, x0
1004b90e8:	mov	x0, x23
1004b90ec:	ldr	x23, [sp]
1004b90f0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b90f4:	b	0x1004b8cd8
1004b90f8:	brk	#0x1
1004b90fc:	mov	x0, x22
1004b9100:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b9104:	mov	x0, x19
1004b9108:	mov	x1, x22
1004b910c:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b9110:	mov	x21, x0
1004b9114:	mov	x0, x22
1004b9118:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b911c:	b	0x1004b8ea4
1004b9120:	brk	#0x1
1004b9124:	str	x23, [sp]
1004b9128:	mov	x23, x8
1004b912c:	mov	x0, x8
1004b9130:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b9134:	mov	x0, x21
1004b9138:	mov	x1, x23
1004b913c:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b9140:	mov	x22, x0
1004b9144:	mov	x0, x23
1004b9148:	ldr	x23, [sp]
1004b914c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b9150:	b	0x1004b8d38
1004b9154:	brk	#0x1
1004b9158:	mov	x0, x22
1004b915c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b9160:	mov	x0, x19
1004b9164:	mov	x1, x22
1004b9168:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b916c:	mov	x21, x0
1004b9170:	mov	x0, x22
1004b9174:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b9178:	b	0x1004b8f34
1004b917c:	brk	#0x1
1004b9180:	str	x23, [sp]
1004b9184:	mov	x23, x8
1004b9188:	mov	x0, x8
1004b918c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b9190:	mov	x0, x21
1004b9194:	mov	x1, x23
1004b9198:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b919c:	mov	x22, x0
1004b91a0:	mov	x0, x23
1004b91a4:	ldr	x23, [sp]
1004b91a8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b91ac:	b	0x1004b8d90
1004b91b0:	brk	#0x1
1004b91b4:	mov	x0, x22
1004b91b8:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b91bc:	mov	x0, x19
1004b91c0:	mov	x1, x22
1004b91c4:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b91c8:	mov	x21, x0
1004b91cc:	mov	x0, x22
1004b91d0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b91d4:	b	0x1004b8f9c
1004b91d8:	brk	#0x1
1004b91dc:	str	x23, [sp]
1004b91e0:	mov	x23, x8
1004b91e4:	mov	x0, x8
1004b91e8:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b91ec:	mov	x0, x21
1004b91f0:	mov	x1, x23
1004b91f4:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b91f8:	mov	x22, x0
1004b91fc:	mov	x0, x23
1004b9200:	ldr	x23, [sp]
1004b9204:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b9208:	b	0x1004b8de8
1004b920c:	brk	#0x1
1004b9210:	mov	x0, x20
1004b9214:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b9218:	mov	x0, x19
1004b921c:	mov	x1, x20
1004b9220:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b9224:	mov	x19, x0
1004b9228:	mov	x0, x20
1004b922c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b9230:	b	0x1004b902c
1004b9234:	brk	#0x1
1004b9238:	sub	sp, sp, #0x60
1004b923c:	stp	x24, x23, [sp, #0x20]
1004b9240:	stp	x22, x21, [sp, #0x30]
1004b9244:	stp	x20, x19, [sp, #0x40]
1004b9248:	stp	x29, x30, [sp, #0x50]
1004b924c:	add	x29, sp, #0x50
1004b9250:	adrp	x8, 7908 ; 0x10239d000
1004b9254:	ldr	x22, [x8, #0x278]
1004b9258:	ldr	x19, [x20, x22]
1004b925c:	tbnz	x19, #0x3f, 0x1004b9424
1004b9260:	adrp	x8, 7908 ; 0x10239d000
1004b9264:	ldr	x23, [x8, #0x270]
1004b9268:	add	x0, x20, x23
1004b926c:	add	x1, sp, #0x8
1004b9270:	mov	x2, #0x0
1004b9274:	mov	x3, #0x0
1004b9278:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b927c:	ldr	x8, [x20, x23]
1004b9280:	lsr	x9, x8, #62
1004b9284:	cbnz	x9, 0x1004b943c
1004b9288:	and	x8, x8, #0xffffffffffffff8
1004b928c:	ldr	x0, [x8, #0x10]
1004b9290:	cmp	x19, x0
1004b9294:	b.ge	0x1004b9424
1004b9298:	ldr	x19, [x20, x22]
1004b929c:	ldr	x21, [x20, x23]
1004b92a0:	tst	x21, #0xc000000000000001
1004b92a4:	b.ne	0x1004b9458
1004b92a8:	tbnz	x19, #0x3f, 0x1004b947c
1004b92ac:	and	x8, x21, #0xffffffffffffff8
1004b92b0:	ldr	x8, [x8, #0x10]
1004b92b4:	cmp	x19, x8
1004b92b8:	b.hs	0x1004b9480
1004b92bc:	add	x8, x21, x19, lsl #3
1004b92c0:	ldr	x0, [x8, #0x20]
1004b92c4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b92c8:	mov	x19, x0
1004b92cc:	mov	x0, #0x0
1004b92d0:	bl	0x1004aede4
1004b92d4:	mov	x1, x0
1004b92d8:	mov	x0, x19
1004b92dc:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b92e0:	cbz	x0, 0x1004b92ec
1004b92e4:	mov	w8, #0x150
1004b92e8:	b	0x1004b93fc
1004b92ec:	mov	x0, x19
1004b92f0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b92f4:	ldr	x19, [x20, x22]
1004b92f8:	ldr	x21, [x20, x23]
1004b92fc:	tst	x21, #0xc000000000000001
1004b9300:	b.ne	0x1004b9484
1004b9304:	tbnz	x19, #0x3f, 0x1004b94a8
1004b9308:	and	x8, x21, #0xffffffffffffff8
1004b930c:	ldr	x8, [x8, #0x10]
1004b9310:	cmp	x19, x8
1004b9314:	b.hs	0x1004b94ac
1004b9318:	add	x8, x21, x19, lsl #3
1004b931c:	ldr	x0, [x8, #0x20]
1004b9320:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b9324:	mov	x19, x0
1004b9328:	mov	x0, #0x0
1004b932c:	bl	0x1004ad03c
1004b9330:	mov	x1, x0
1004b9334:	mov	x0, x19
1004b9338:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b933c:	cbz	x0, 0x1004b9348
1004b9340:	mov	w8, #0x1b8
1004b9344:	b	0x1004b93fc
1004b9348:	mov	x0, x19
1004b934c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b9350:	ldr	x19, [x20, x22]
1004b9354:	ldr	x21, [x20, x23]
1004b9358:	tst	x21, #0xc000000000000001
1004b935c:	b.ne	0x1004b94b0
1004b9360:	tbnz	x19, #0x3f, 0x1004b94d4
1004b9364:	and	x8, x21, #0xffffffffffffff8
1004b9368:	ldr	x8, [x8, #0x10]
1004b936c:	cmp	x19, x8
1004b9370:	b.hs	0x1004b94d8
1004b9374:	add	x8, x21, x19, lsl #3
1004b9378:	ldr	x0, [x8, #0x20]
1004b937c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b9380:	mov	x19, x0
1004b9384:	mov	x0, #0x0
1004b9388:	bl	0x1004af7b4
1004b938c:	mov	x1, x0
1004b9390:	mov	x0, x19
1004b9394:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b9398:	cbz	x0, 0x1004b93a4
1004b939c:	mov	w8, #0x158
1004b93a0:	b	0x1004b93fc
1004b93a4:	mov	x0, x19
1004b93a8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b93ac:	ldr	x19, [x20, x22]
1004b93b0:	ldr	x20, [x20, x23]
1004b93b4:	tst	x20, #0xc000000000000001
1004b93b8:	b.ne	0x1004b94dc
1004b93bc:	tbnz	x19, #0x3f, 0x1004b9500
1004b93c0:	and	x8, x20, #0xffffffffffffff8
1004b93c4:	ldr	x8, [x8, #0x10]
1004b93c8:	cmp	x19, x8
1004b93cc:	b.hs	0x1004b9504
1004b93d0:	add	x8, x20, x19, lsl #3
1004b93d4:	ldr	x0, [x8, #0x20]
1004b93d8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b93dc:	mov	x19, x0
1004b93e0:	mov	x0, #0x0
1004b93e4:	bl	0x1004a7e0c
1004b93e8:	mov	x1, x0
1004b93ec:	mov	x0, x19
1004b93f0:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004b93f4:	cbz	x0, 0x1004b941c
1004b93f8:	mov	w8, #0x208
1004b93fc:	ldr	x9, [x0]
1004b9400:	adrp	x10, 7702 ; 0x1022cf000
1004b9404:	ldr	x10, [x10, #0x718] ; literal pool symbol address: _swift_isaMask
1004b9408:	ldr	x10, [x10]
1004b940c:	and	x9, x10, x9
1004b9410:	ldr	x8, [x9, x8]
1004b9414:	mov	x20, x0
1004b9418:	blr	x8
1004b941c:	mov	x0, x19
1004b9420:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b9424:	ldp	x29, x30, [sp, #0x50]
1004b9428:	ldp	x20, x19, [sp, #0x40]
1004b942c:	ldp	x22, x21, [sp, #0x30]
1004b9430:	ldp	x24, x23, [sp, #0x20]
1004b9434:	add	sp, sp, #0x60
1004b9438:	ret
1004b943c:	and	x9, x8, #0xffffffffffffff8
1004b9440:	cmn	x8, #0x1
1004b9444:	csel	x0, x9, x8, gt
1004b9448:	bl	0x101ac7900 ; symbol stub for: _$ss18_CocoaArrayWrapperV8endIndexSivg
1004b944c:	cmp	x19, x0
1004b9450:	b.lt	0x1004b9298
1004b9454:	b	0x1004b9424
1004b9458:	mov	x0, x21
1004b945c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b9460:	mov	x0, x19
1004b9464:	mov	x1, x21
1004b9468:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b946c:	mov	x19, x0
1004b9470:	mov	x0, x21
1004b9474:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b9478:	b	0x1004b92cc
1004b947c:	brk	#0x1
1004b9480:	brk	#0x1
1004b9484:	mov	x0, x21
1004b9488:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b948c:	mov	x0, x19
1004b9490:	mov	x1, x21
1004b9494:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b9498:	mov	x19, x0
1004b949c:	mov	x0, x21
1004b94a0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b94a4:	b	0x1004b9328
1004b94a8:	brk	#0x1
1004b94ac:	brk	#0x1
1004b94b0:	mov	x0, x21
1004b94b4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b94b8:	mov	x0, x19
1004b94bc:	mov	x1, x21
1004b94c0:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b94c4:	mov	x19, x0
1004b94c8:	mov	x0, x21
1004b94cc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b94d0:	b	0x1004b9384
1004b94d4:	brk	#0x1
1004b94d8:	brk	#0x1
1004b94dc:	mov	x0, x20
1004b94e0:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b94e4:	mov	x0, x19
1004b94e8:	mov	x1, x20
1004b94ec:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b94f0:	mov	x19, x0
1004b94f4:	mov	x0, x20
1004b94f8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b94fc:	b	0x1004b93e0
1004b9500:	brk	#0x1
1004b9504:	brk	#0x1
1004b9508:	sub	sp, sp, #0x70
1004b950c:	stp	x28, x27, [sp, #0x10]
1004b9510:	stp	x26, x25, [sp, #0x20]
1004b9514:	stp	x24, x23, [sp, #0x30]
1004b9518:	stp	x22, x21, [sp, #0x40]
1004b951c:	stp	x20, x19, [sp, #0x50]
1004b9520:	stp	x29, x30, [sp, #0x60]
1004b9524:	add	x29, sp, #0x60
1004b9528:	mov	x21, x20
1004b952c:	adrp	x0, 7836 ; 0x102355000
1004b9530:	add	x0, x0, #0x198
1004b9534:	adrp	x1, 5692 ; 0x101af5000
1004b9538:	add	x1, x1, #0xe48
1004b953c:	bl	0x100003c4c
1004b9540:	mov	w1, #0x100
1004b9544:	mov	w2, #0x7
1004b9548:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b954c:	mov	x19, x0
1004b9550:	adrp	x8, 5672 ; 0x101ae1000
1004b9554:	ldr	q0, [x8, #0x120]
1004b9558:	str	q0, [x0, #0x10]
1004b955c:	bl	0x100609210
1004b9560:	mov	x23, x0
1004b9564:	ldr	x20, [x0]
1004b9568:	ldr	x8, [x20]
1004b956c:	ldr	x22, [x8, #0x108]
1004b9570:	mov	x0, x20
1004b9574:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b9578:	mov	w0, #0x1b
1004b957c:	blr	x22
1004b9580:	mov	x22, x0
1004b9584:	mov	x0, x20
1004b9588:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b958c:	ldr	x8, [x22, #0x10]
1004b9590:	cbz	x8, 0x1004b9600
1004b9594:	str	x22, [sp, #0x8]
1004b9598:	adrp	x20, 7817 ; 0x102342000
1004b959c:	add	x20, x20, #0xa20
1004b95a0:	adrp	x24, 5673 ; 0x101ae2000
1004b95a4:	add	x24, x24, #0x2f0
1004b95a8:	mov	x0, x20
1004b95ac:	mov	x1, x24
1004b95b0:	bl	0x100003c4c
1004b95b4:	mov	x25, x0
1004b95b8:	adrp	x0, 7816 ; 0x102341000
1004b95bc:	add	x0, x0, #0x7a0
1004b95c0:	adrp	x3, 7701 ; 0x1022ce000
1004b95c4:	ldr	x3, [x3, #0x220] ; literal pool symbol address: _$sSayxGSKsMc
1004b95c8:	mov	x1, x20
1004b95cc:	mov	x2, x24
1004b95d0:	bl	0x10002b714
1004b95d4:	mov	x3, x0
1004b95d8:	add	x20, sp, #0x8
1004b95dc:	mov	x0, #0x0
1004b95e0:	mov	x1, #-0x2000000000000000
1004b95e4:	mov	x2, x25
1004b95e8:	bl	0x101ac60b8 ; symbol stub for: _$sSKsSS7ElementRtzrlE6joined9separatorS2S_tF
1004b95ec:	mov	x20, x0
1004b95f0:	mov	x24, x1
1004b95f4:	mov	x0, x22
1004b95f8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b95fc:	b	0x1004b9610
1004b9600:	mov	x0, x22
1004b9604:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b9608:	mov	x20, #0x0
1004b960c:	mov	x24, #0x0
1004b9610:	adrp	x0, 7457 ; 0x1021da000
1004b9614:	add	x0, x0, #0x978
1004b9618:	mov	w1, #0x18
1004b961c:	mov	w2, #0x7
1004b9620:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b9624:	mov	x22, x0
1004b9628:	add	x0, x0, #0x10
1004b962c:	mov	x1, x21
1004b9630:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b9634:	adrp	x0, 7458 ; 0x1021db000
1004b9638:	add	x0, x0, #0x558
1004b963c:	mov	w1, #0x20
1004b9640:	mov	w2, #0x7
1004b9644:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b9648:	adrp	x8, 9 ; 0x1004c2000
1004b964c:	add	x8, x8, #0x8fc
1004b9650:	stp	x8, x22, [x0, #0x10]
1004b9654:	mov	x8, #0x7053
1004b9658:	movk	x8, #0x696c, lsl #16
1004b965c:	movk	x8, #0x2074, lsl #32
1004b9660:	movk	x8, #0x6952, lsl #48
1004b9664:	mov	x9, #0x6867
1004b9668:	movk	x9, #0x74, lsl #16
1004b966c:	movk	x9, #0xeb00, lsl #48
1004b9670:	stp	x8, x9, [x19, #0x20]
1004b9674:	stp	x20, x24, [x19, #0x30]
1004b9678:	adrp	x8, -1205 ; 0x100004000
1004b967c:	add	x8, x8, #0xcc
1004b9680:	stp	xzr, x8, [x19, #0x40]
1004b9684:	str	x0, [x19, #0x50]
1004b9688:	ldr	x20, [x23]
1004b968c:	ldr	x8, [x20]
1004b9690:	ldr	x24, [x8, #0x108]
1004b9694:	mov	x0, x20
1004b9698:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b969c:	mov	w0, #0x1c
1004b96a0:	blr	x24
1004b96a4:	mov	x24, x0
1004b96a8:	mov	x0, x22
1004b96ac:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b96b0:	mov	x0, x20
1004b96b4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b96b8:	ldr	x8, [x24, #0x10]
1004b96bc:	cbz	x8, 0x1004b972c
1004b96c0:	str	x24, [sp, #0x8]
1004b96c4:	adrp	x20, 7817 ; 0x102342000
1004b96c8:	add	x20, x20, #0xa20
1004b96cc:	adrp	x25, 5673 ; 0x101ae2000
1004b96d0:	add	x25, x25, #0x2f0
1004b96d4:	mov	x0, x20
1004b96d8:	mov	x1, x25
1004b96dc:	bl	0x100003c4c
1004b96e0:	mov	x26, x0
1004b96e4:	adrp	x0, 7816 ; 0x102341000
1004b96e8:	add	x0, x0, #0x7a0
1004b96ec:	adrp	x3, 7701 ; 0x1022ce000
1004b96f0:	ldr	x3, [x3, #0x220] ; literal pool symbol address: _$sSayxGSKsMc
1004b96f4:	mov	x1, x20
1004b96f8:	mov	x2, x25
1004b96fc:	bl	0x10002b714
1004b9700:	mov	x3, x0
1004b9704:	add	x20, sp, #0x8
1004b9708:	mov	x0, #0x0
1004b970c:	mov	x1, #-0x2000000000000000
1004b9710:	mov	x2, x26
1004b9714:	bl	0x101ac60b8 ; symbol stub for: _$sSKsSS7ElementRtzrlE6joined9separatorS2S_tF
1004b9718:	mov	x20, x0
1004b971c:	mov	x25, x1
1004b9720:	mov	x0, x24
1004b9724:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b9728:	b	0x1004b973c
1004b972c:	mov	x0, x24
1004b9730:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b9734:	mov	x20, #0x0
1004b9738:	mov	x25, #0x0
1004b973c:	mov	x28, #0x6e77
1004b9740:	movk	x28, #0xea00, lsl #48
1004b9744:	adrp	x0, 7457 ; 0x1021da000
1004b9748:	add	x0, x0, #0x978
1004b974c:	mov	w1, #0x18
1004b9750:	mov	w2, #0x7
1004b9754:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b9758:	mov	x24, x0
1004b975c:	add	x0, x0, #0x10
1004b9760:	mov	x1, x21
1004b9764:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b9768:	adrp	x0, 7458 ; 0x1021db000
1004b976c:	add	x0, x0, #0x580
1004b9770:	mov	w1, #0x20
1004b9774:	mov	w2, #0x7
1004b9778:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b977c:	adrp	x8, 9 ; 0x1004c2000
1004b9780:	add	x8, x8, #0x904
1004b9784:	stp	x8, x24, [x0, #0x10]
1004b9788:	mov	x8, #0x7053
1004b978c:	movk	x8, #0x696c, lsl #16
1004b9790:	movk	x8, #0x2074, lsl #32
1004b9794:	movk	x8, #0x654c, lsl #48
1004b9798:	add	x9, x28, #0x5ef
1004b979c:	stp	x8, x9, [x19, #0x58]
1004b97a0:	stp	x20, x25, [x19, #0x68]
1004b97a4:	adrp	x8, -1205 ; 0x100004000
1004b97a8:	add	x8, x8, #0xcc
1004b97ac:	stp	xzr, x8, [x19, #0x78]
1004b97b0:	str	x0, [x19, #0x88]
1004b97b4:	ldr	x20, [x23]
1004b97b8:	ldr	x8, [x20]
1004b97bc:	ldr	x25, [x8, #0x108]
1004b97c0:	mov	x0, x20
1004b97c4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b97c8:	mov	w0, #0x1d
1004b97cc:	blr	x25
1004b97d0:	mov	x25, x0
1004b97d4:	mov	x0, x24
1004b97d8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b97dc:	mov	x0, x20
1004b97e0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b97e4:	ldr	x8, [x25, #0x10]
1004b97e8:	cbz	x8, 0x1004b9858
1004b97ec:	str	x25, [sp, #0x8]
1004b97f0:	adrp	x20, 7817 ; 0x102342000
1004b97f4:	add	x20, x20, #0xa20
1004b97f8:	adrp	x26, 5673 ; 0x101ae2000
1004b97fc:	add	x26, x26, #0x2f0
1004b9800:	mov	x0, x20
1004b9804:	mov	x1, x26
1004b9808:	bl	0x100003c4c
1004b980c:	mov	x27, x0
1004b9810:	adrp	x0, 7816 ; 0x102341000
1004b9814:	add	x0, x0, #0x7a0
1004b9818:	adrp	x3, 7701 ; 0x1022ce000
1004b981c:	ldr	x3, [x3, #0x220] ; literal pool symbol address: _$sSayxGSKsMc
1004b9820:	mov	x1, x20
1004b9824:	mov	x2, x26
1004b9828:	bl	0x10002b714
1004b982c:	mov	x3, x0
1004b9830:	add	x20, sp, #0x8
1004b9834:	mov	x0, #0x0
1004b9838:	mov	x1, #-0x2000000000000000
1004b983c:	mov	x2, x27
1004b9840:	bl	0x101ac60b8 ; symbol stub for: _$sSKsSS7ElementRtzrlE6joined9separatorS2S_tF
1004b9844:	mov	x20, x0
1004b9848:	mov	x26, x1
1004b984c:	mov	x0, x25
1004b9850:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b9854:	b	0x1004b9868
1004b9858:	mov	x0, x25
1004b985c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b9860:	mov	x20, #0x0
1004b9864:	mov	x26, #0x0
1004b9868:	adrp	x0, 7457 ; 0x1021da000
1004b986c:	add	x0, x0, #0x978
1004b9870:	mov	w1, #0x18
1004b9874:	mov	w2, #0x7
1004b9878:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b987c:	mov	x25, x0
1004b9880:	add	x0, x0, #0x10
1004b9884:	mov	x1, x21
1004b9888:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b988c:	adrp	x0, 7458 ; 0x1021db000
1004b9890:	add	x0, x0, #0x5a8
1004b9894:	mov	w1, #0x20
1004b9898:	mov	w2, #0x7
1004b989c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b98a0:	adrp	x8, 9 ; 0x1004c2000
1004b98a4:	add	x8, x8, #0x90c
1004b98a8:	stp	x8, x25, [x0, #0x10]
1004b98ac:	mov	x8, #0x7053
1004b98b0:	movk	x8, #0x696c, lsl #16
1004b98b4:	movk	x8, #0x2074, lsl #32
1004b98b8:	movk	x8, #0x6f44, lsl #48
1004b98bc:	stp	x8, x28, [x19, #0x90]
1004b98c0:	stp	x20, x26, [x19, #0xa0]
1004b98c4:	adrp	x8, -1205 ; 0x100004000
1004b98c8:	add	x8, x8, #0xcc
1004b98cc:	stp	xzr, x8, [x19, #0xb0]
1004b98d0:	str	x0, [x19, #0xc0]
1004b98d4:	ldr	x20, [x23]
1004b98d8:	ldr	x8, [x20]
1004b98dc:	ldr	x23, [x8, #0x108]
1004b98e0:	mov	x0, x20
1004b98e4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b98e8:	mov	w0, #0x1e
1004b98ec:	blr	x23
1004b98f0:	mov	x23, x0
1004b98f4:	mov	x0, x25
1004b98f8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b98fc:	mov	x0, x20
1004b9900:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b9904:	ldr	x8, [x23, #0x10]
1004b9908:	cbz	x8, 0x1004b9978
1004b990c:	str	x23, [sp, #0x8]
1004b9910:	adrp	x20, 7817 ; 0x102342000
1004b9914:	add	x20, x20, #0xa20
1004b9918:	adrp	x26, 5673 ; 0x101ae2000
1004b991c:	add	x26, x26, #0x2f0
1004b9920:	mov	x0, x20
1004b9924:	mov	x1, x26
1004b9928:	bl	0x100003c4c
1004b992c:	mov	x27, x0
1004b9930:	adrp	x0, 7816 ; 0x102341000
1004b9934:	add	x0, x0, #0x7a0
1004b9938:	adrp	x3, 7701 ; 0x1022ce000
1004b993c:	ldr	x3, [x3, #0x220] ; literal pool symbol address: _$sSayxGSKsMc
1004b9940:	mov	x1, x20
1004b9944:	mov	x2, x26
1004b9948:	bl	0x10002b714
1004b994c:	mov	x3, x0
1004b9950:	add	x20, sp, #0x8
1004b9954:	mov	x0, #0x0
1004b9958:	mov	x1, #-0x2000000000000000
1004b995c:	mov	x2, x27
1004b9960:	bl	0x101ac60b8 ; symbol stub for: _$sSKsSS7ElementRtzrlE6joined9separatorS2S_tF
1004b9964:	mov	x20, x0
1004b9968:	mov	x26, x1
1004b996c:	mov	x0, x23
1004b9970:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b9974:	b	0x1004b9988
1004b9978:	mov	x0, x23
1004b997c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b9980:	mov	x20, #0x0
1004b9984:	mov	x26, #0x0
1004b9988:	adrp	x0, 7457 ; 0x1021da000
1004b998c:	add	x0, x0, #0x978
1004b9990:	mov	w1, #0x18
1004b9994:	mov	w2, #0x7
1004b9998:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b999c:	mov	x23, x0
1004b99a0:	add	x0, x0, #0x10
1004b99a4:	mov	x1, x21
1004b99a8:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b99ac:	adrp	x0, 7458 ; 0x1021db000
1004b99b0:	add	x0, x0, #0x5d0
1004b99b4:	mov	w1, #0x20
1004b99b8:	mov	w2, #0x7
1004b99bc:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b99c0:	adrp	x8, 9 ; 0x1004c2000
1004b99c4:	add	x8, x8, #0x914
1004b99c8:	stp	x8, x23, [x0, #0x10]
1004b99cc:	mov	x8, #0x7053
1004b99d0:	movk	x8, #0x696c, lsl #16
1004b99d4:	movk	x8, #0x2074, lsl #32
1004b99d8:	movk	x8, #0x7055, lsl #48
1004b99dc:	mov	x9, #-0x1800000000000000
1004b99e0:	stp	x8, x9, [x19, #0xc8]
1004b99e4:	stp	x20, x26, [x19, #0xd8]
1004b99e8:	adrp	x8, -1205 ; 0x100004000
1004b99ec:	add	x8, x8, #0xcc
1004b99f0:	stp	xzr, x8, [x19, #0xe8]
1004b99f4:	str	x0, [x19, #0xf8]
1004b99f8:	mov	x0, x22
1004b99fc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b9a00:	mov	x0, x24
1004b9a04:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b9a08:	mov	x0, x25
1004b9a0c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b9a10:	mov	x0, x19
1004b9a14:	ldp	x29, x30, [sp, #0x60]
1004b9a18:	ldp	x20, x19, [sp, #0x50]
1004b9a1c:	ldp	x22, x21, [sp, #0x40]
1004b9a20:	ldp	x24, x23, [sp, #0x30]
1004b9a24:	ldp	x26, x25, [sp, #0x20]
1004b9a28:	ldp	x28, x27, [sp, #0x10]
1004b9a2c:	add	sp, sp, #0x70
1004b9a30:	ret
1004b9a34:	sub	sp, sp, #0xa0
1004b9a38:	stp	d11, d10, [sp, #0x20]
1004b9a3c:	stp	d9, d8, [sp, #0x30]
1004b9a40:	stp	x28, x27, [sp, #0x40]
1004b9a44:	stp	x26, x25, [sp, #0x50]
1004b9a48:	stp	x24, x23, [sp, #0x60]
1004b9a4c:	stp	x22, x21, [sp, #0x70]
1004b9a50:	stp	x20, x19, [sp, #0x80]
1004b9a54:	stp	x29, x30, [sp, #0x90]
1004b9a58:	add	x29, sp, #0x90
1004b9a5c:	mov	x21, x20
1004b9a60:	mov.16b	v8, v0
1004b9a64:	mov	x22, x0
1004b9a68:	adrp	x8, 7908 ; 0x10239d000
1004b9a6c:	ldr	x8, [x8, #0x248]
1004b9a70:	add	x0, x20, x8
1004b9a74:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b9a78:	cbz	x0, 0x1004b9e20
1004b9a7c:	mov	x20, x0
1004b9a80:	ldr	x8, [x0]
1004b9a84:	ldr	x8, [x8, #0x260]
1004b9a88:	blr	x8
1004b9a8c:	mov	x19, x0
1004b9a90:	mov	x0, x20
1004b9a94:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b9a98:	cbz	x19, 0x1004b9e20
1004b9a9c:	str	x22, [sp]
1004b9aa0:	ldr	x8, [x19]
1004b9aa4:	ldr	x8, [x8, #0x370]
1004b9aa8:	mov	x20, x19
1004b9aac:	blr	x8
1004b9ab0:	mov	x22, x0
1004b9ab4:	ldr	x8, [x0]
1004b9ab8:	ldr	x8, [x8, #0x2b0]
1004b9abc:	mov	x20, x0
1004b9ac0:	blr	x8
1004b9ac4:	adrp	x23, 7789 ; 0x102326000
1004b9ac8:	tbz	w0, #0x0, 0x1004b9b08
1004b9acc:	bl	0x1004a96cc
1004b9ad0:	ldp	x20, x24, [x0]
1004b9ad4:	ldr	x0, [x23, #0x9c8]
1004b9ad8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b9adc:	mov	x25, x0
1004b9ae0:	mov	x0, x24
1004b9ae4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b9ae8:	mov	x0, x25
1004b9aec:	bl	0x101ad58a0 ; selector tertiaryLabelColor
1004b9af0:	mov	x29, x29
1004b9af4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b9af8:	mov	x2, x0
1004b9afc:	mov	x0, x20
1004b9b00:	mov	x1, x24
1004b9b04:	b	0x1004b9b40
1004b9b08:	ldr	x8, [x22]
1004b9b0c:	ldr	x8, [x8, #0x100]
1004b9b10:	mov	x20, x22
1004b9b14:	blr	x8
1004b9b18:	tbz	w0, #0x0, 0x1004b9b24
1004b9b1c:	bl	0x1004a971c
1004b9b20:	b	0x1004b9b28
1004b9b24:	bl	0x1004a96f4
1004b9b28:	ldp	x20, x24, [x0]
1004b9b2c:	mov	x0, x24
1004b9b30:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b9b34:	mov	x0, x20
1004b9b38:	mov	x1, x24
1004b9b3c:	mov	x2, #0x0
1004b9b40:	bl	0x1004a5904
1004b9b44:	mov	x20, x0
1004b9b48:	mov	x25, x1
1004b9b4c:	mov	x26, x2
1004b9b50:	mov	x27, x3
1004b9b54:	adrp	x3, 7702 ; 0x1022cf000
1004b9b58:	ldr	x3, [x3, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004b9b5c:	mov	w0, #0x0
1004b9b60:	mov	w1, #0x1
1004b9b64:	mov	w2, #0x1
1004b9b68:	bl	0x1004bfa24
1004b9b6c:	mov	x24, x0
1004b9b70:	ldp	x23, x8, [x0, #0x10]
1004b9b74:	add	x28, x23, #0x1
1004b9b78:	cmp	x23, x8, lsr #1
1004b9b7c:	b.hs	0x1004b9e68
1004b9b80:	str	x28, [x24, #0x10]
1004b9b84:	add	x8, x24, x23, lsl #5
1004b9b88:	stp	x20, x25, [x8, #0x20]
1004b9b8c:	stp	x26, x27, [x8, #0x30]
1004b9b90:	ldr	x8, [x22]
1004b9b94:	ldr	x8, [x8, #0x2b8]
1004b9b98:	mov	x20, x22
1004b9b9c:	blr	x8
1004b9ba0:	tbz	w0, #0x0, 0x1004b9be4
1004b9ba4:	bl	0x1004a9744
1004b9ba8:	ldp	x20, x25, [x0]
1004b9bac:	adrp	x8, 7789 ; 0x102326000
1004b9bb0:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004b9bb4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b9bb8:	mov	x26, x0
1004b9bbc:	mov	x0, x25
1004b9bc0:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b9bc4:	mov	x0, x26
1004b9bc8:	bl	0x101ad58a0 ; selector tertiaryLabelColor
1004b9bcc:	mov	x29, x29
1004b9bd0:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b9bd4:	mov	x2, x0
1004b9bd8:	mov	x0, x20
1004b9bdc:	mov	x1, x25
1004b9be0:	b	0x1004b9c38
1004b9be4:	ldr	x8, [x22]
1004b9be8:	ldr	x8, [x8, #0x160]
1004b9bec:	mov	x20, x22
1004b9bf0:	blr	x8
1004b9bf4:	tbz	w0, #0x0, 0x1004b9c00
1004b9bf8:	bl	0x1004a97bc
1004b9bfc:	b	0x1004b9c20
1004b9c00:	ldr	x8, [x22]
1004b9c04:	ldr	x8, [x8, #0x130]
1004b9c08:	mov	x20, x22
1004b9c0c:	blr	x8
1004b9c10:	tbz	w0, #0x0, 0x1004b9c1c
1004b9c14:	bl	0x1004a9794
1004b9c18:	b	0x1004b9c20
1004b9c1c:	bl	0x1004a976c
1004b9c20:	ldp	x20, x25, [x0]
1004b9c24:	mov	x0, x25
1004b9c28:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b9c2c:	mov	x0, x20
1004b9c30:	mov	x1, x25
1004b9c34:	mov	x2, #0x0
1004b9c38:	bl	0x1004a5904
1004b9c3c:	ldp	x25, x8, [x24, #0x10]
1004b9c40:	add	x20, x25, #0x1
1004b9c44:	cmp	x25, x8, lsr #1
1004b9c48:	b.hs	0x1004b9e88
1004b9c4c:	str	x20, [x24, #0x10]
1004b9c50:	add	x8, x24, x25, lsl #5
1004b9c54:	stp	x0, x1, [x8, #0x20]
1004b9c58:	stp	x2, x3, [x8, #0x30]
1004b9c5c:	ldr	x8, [x19]
1004b9c60:	ldr	x8, [x8, #0x500]
1004b9c64:	mov	x20, x19
1004b9c68:	blr	x8
1004b9c6c:	tbz	w0, #0x0, 0x1004b9cb0
1004b9c70:	bl	0x1004a97e4
1004b9c74:	ldp	x20, x25, [x0]
1004b9c78:	mov	x0, x25
1004b9c7c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b9c80:	mov	x0, x20
1004b9c84:	mov	x1, x25
1004b9c88:	mov	x2, #0x0
1004b9c8c:	bl	0x1004a5904
1004b9c90:	ldp	x23, x8, [x24, #0x10]
1004b9c94:	add	x20, x23, #0x1
1004b9c98:	cmp	x23, x8, lsr #1
1004b9c9c:	b.hs	0x1004b9ec8
1004b9ca0:	str	x20, [x24, #0x10]
1004b9ca4:	add	x8, x24, x23, lsl #5
1004b9ca8:	stp	x0, x1, [x8, #0x20]
1004b9cac:	stp	x2, x3, [x8, #0x30]
1004b9cb0:	mov	x0, #0x0
1004b9cb4:	bl	0x1004a7e0c
1004b9cb8:	mov	x8, #0x800000000000
1004b9cbc:	movk	x8, #0x4071, lsl #48
1004b9cc0:	fmov	d9, x8
1004b9cc4:	fmov	d10, #28.00000000
1004b9cc8:	movi.2d	v0, #0000000000000000
1004b9ccc:	fmov	d3, #28.00000000
1004b9cd0:	mov.16b	v1, v8
1004b9cd4:	mov.16b	v2, v9
1004b9cd8:	mov	x20, x0
1004b9cdc:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b9ce0:	mov	x25, x0
1004b9ce4:	adrp	x8, 6432 ; 0x101dd9000
1004b9ce8:	add	x8, x8, #0x2f0 ; literal pool for: "Notifications & Privileges"
1004b9cec:	sub	x20, x8, #0x20
1004b9cf0:	adrp	x0, 7457 ; 0x1021da000
1004b9cf4:	add	x0, x0, #0x978
1004b9cf8:	mov	w1, #0x18
1004b9cfc:	mov	w2, #0x7
1004b9d00:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b9d04:	mov	x26, x0
1004b9d08:	add	x0, x0, #0x10
1004b9d0c:	mov	x1, x21
1004b9d10:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b9d14:	adrp	x0, 7458 ; 0x1021db000
1004b9d18:	add	x0, x0, #0x530
1004b9d1c:	mov	w1, #0x20
1004b9d20:	mov	w2, #0x7
1004b9d24:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b9d28:	mov	x27, x0
1004b9d2c:	stp	x26, x19, [x0, #0x10]
1004b9d30:	ldr	x8, [x25]
1004b9d34:	adrp	x9, 7702 ; 0x1022cf000
1004b9d38:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b9d3c:	ldr	x9, [x9]
1004b9d40:	and	x8, x9, x8
1004b9d44:	ldr	x23, [x8, #0x1e8]
1004b9d48:	mov	x0, x26
1004b9d4c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b9d50:	mov	x0, x19
1004b9d54:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b9d58:	adrp	x4, 9 ; 0x1004c2000
1004b9d5c:	add	x4, x4, #0x888
1004b9d60:	orr	x1, x20, #0x8000000000000000
1004b9d64:	mov	x0, #0x1a
1004b9d68:	movk	x0, #0xd000, lsl #48
1004b9d6c:	mov	x2, x24
1004b9d70:	mov.16b	v0, v9
1004b9d74:	mov	x3, x21
1004b9d78:	mov	x5, x27
1004b9d7c:	mov	x20, x25
1004b9d80:	blr	x23
1004b9d84:	mov	x0, x26
1004b9d88:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b9d8c:	mov	x0, x27
1004b9d90:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b9d94:	ldr	x0, [sp]
1004b9d98:	mov	x2, x25
1004b9d9c:	bl	0x101acb460 ; selector addSubview:
1004b9da0:	adrp	x8, 7908 ; 0x10239d000
1004b9da4:	ldr	x26, [x8, #0x270]
1004b9da8:	add	x0, x21, x26
1004b9dac:	add	x1, sp, #0x8
1004b9db0:	mov	w2, #0x21
1004b9db4:	mov	x3, #0x0
1004b9db8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b9dbc:	add	x20, x21, x26
1004b9dc0:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b9dc4:	ldr	x8, [x21, x26]
1004b9dc8:	and	x8, x8, #0xffffffffffffff8
1004b9dcc:	ldp	x23, x8, [x8, #0x10]
1004b9dd0:	cmp	x23, x8, lsr #1
1004b9dd4:	b.hs	0x1004b9e4c
1004b9dd8:	mov	x0, x25
1004b9ddc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b9de0:	mov	x25, x0
1004b9de4:	add	x20, x21, x26
1004b9de8:	mov	x0, x23
1004b9dec:	mov	x1, x25
1004b9df0:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b9df4:	add	x0, sp, #0x8
1004b9df8:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b9dfc:	mov	x0, x24
1004b9e00:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b9e04:	mov	x0, x25
1004b9e08:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b9e0c:	mov	x0, x22
1004b9e10:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b9e14:	mov	x0, x19
1004b9e18:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b9e1c:	fadd	d8, d8, d10
1004b9e20:	mov.16b	v0, v8
1004b9e24:	ldp	x29, x30, [sp, #0x90]
1004b9e28:	ldp	x20, x19, [sp, #0x80]
1004b9e2c:	ldp	x22, x21, [sp, #0x70]
1004b9e30:	ldp	x24, x23, [sp, #0x60]
1004b9e34:	ldp	x26, x25, [sp, #0x50]
1004b9e38:	ldp	x28, x27, [sp, #0x40]
1004b9e3c:	ldp	d9, d8, [sp, #0x30]
1004b9e40:	ldp	d11, d10, [sp, #0x20]
1004b9e44:	add	sp, sp, #0xa0
1004b9e48:	ret
1004b9e4c:	cmp	x8, #0x1
1004b9e50:	cset	w0, hi
1004b9e54:	add	x1, x23, #0x1
1004b9e58:	add	x20, x21, x26
1004b9e5c:	mov	w2, #0x1
1004b9e60:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b9e64:	b	0x1004b9dd8
1004b9e68:	cmp	x8, #0x1
1004b9e6c:	cset	w0, hi
1004b9e70:	mov	x1, x28
1004b9e74:	mov	w2, #0x1
1004b9e78:	mov	x3, x24
1004b9e7c:	bl	0x1004bfa24
1004b9e80:	mov	x24, x0
1004b9e84:	b	0x1004b9b80
1004b9e88:	mov	x23, x3
1004b9e8c:	mov	x27, x2
1004b9e90:	mov	x26, x1
1004b9e94:	mov	x28, x0
1004b9e98:	cmp	x8, #0x1
1004b9e9c:	cset	w0, hi
1004b9ea0:	mov	x1, x20
1004b9ea4:	mov	w2, #0x1
1004b9ea8:	mov	x3, x24
1004b9eac:	bl	0x1004bfa24
1004b9eb0:	mov	x24, x0
1004b9eb4:	mov	x0, x28
1004b9eb8:	mov	x1, x26
1004b9ebc:	mov	x2, x27
1004b9ec0:	mov	x3, x23
1004b9ec4:	b	0x1004b9c4c
1004b9ec8:	cmp	x8, #0x1
1004b9ecc:	cset	w8, hi
1004b9ed0:	mov	x25, x0
1004b9ed4:	mov	x0, x8
1004b9ed8:	mov	x26, x1
1004b9edc:	mov	x1, x20
1004b9ee0:	mov	x27, x2
1004b9ee4:	mov	w2, #0x1
1004b9ee8:	mov	x28, x3
1004b9eec:	mov	x3, x24
1004b9ef0:	bl	0x1004bfa24
1004b9ef4:	mov	x3, x28
1004b9ef8:	mov	x2, x27
1004b9efc:	mov	x1, x26
1004b9f00:	mov	x24, x0
1004b9f04:	mov	x0, x25
1004b9f08:	b	0x1004b9ca0
1004b9f0c:	sub	sp, sp, #0x90
1004b9f10:	stp	x28, x27, [sp, #0x30]
1004b9f14:	stp	x26, x25, [sp, #0x40]
1004b9f18:	stp	x24, x23, [sp, #0x50]
1004b9f1c:	stp	x22, x21, [sp, #0x60]
1004b9f20:	stp	x20, x19, [sp, #0x70]
1004b9f24:	stp	x29, x30, [sp, #0x80]
1004b9f28:	add	x29, sp, #0x80
1004b9f2c:	stp	x0, x20, [sp, #0x20]
1004b9f30:	ldr	x8, [x0]
1004b9f34:	ldr	x8, [x8, #0x370]
1004b9f38:	mov	x20, x0
1004b9f3c:	str	x8, [sp, #0x8]
1004b9f40:	blr	x8
1004b9f44:	mov	x19, x0
1004b9f48:	adrp	x3, 7702 ; 0x1022cf000
1004b9f4c:	ldr	x3, [x3, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004b9f50:	adrp	x4, 7702 ; 0x1022cf000
1004b9f54:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004b9f58:	mov	w0, #0x0
1004b9f5c:	mov	w1, #0x1
1004b9f60:	mov	w2, #0x1
1004b9f64:	bl	0x1004bfb6c
1004b9f68:	mov	x22, x0
1004b9f6c:	ldp	x21, x8, [x0, #0x10]
1004b9f70:	add	x20, x21, #0x1
1004b9f74:	cmp	x21, x8, lsr #1
1004b9f78:	b.hs	0x1004bb23c
1004b9f7c:	mov	w23, #0x9ce2
1004b9f80:	movk	w23, #0x93, lsl #16
1004b9f84:	str	x20, [x22, #0x10]
1004b9f88:	mov	w8, #0x38
1004b9f8c:	madd	x8, x21, x8, x22
1004b9f90:	mov	x9, #0x4f53
1004b9f94:	movk	x9, #0x4e55, lsl #16
1004b9f98:	movk	x9, #0x44, lsl #32
1004b9f9c:	mov	x10, #-0x1b00000000000000
1004b9fa0:	stp	x9, x10, [x8, #0x20]
1004b9fa4:	adrp	x9, -1206 ; 0x100003000
1004b9fa8:	add	x9, x9, #0xf40
1004b9fac:	stp	xzr, xzr, [x8, #0x30]
1004b9fb0:	stp	xzr, x9, [x8, #0x40]
1004b9fb4:	str	xzr, [x8, #0x50]
1004b9fb8:	ldr	x8, [x19]
1004b9fbc:	ldr	x8, [x8, #0x2b0]
1004b9fc0:	mov	x20, x19
1004b9fc4:	blr	x8
1004b9fc8:	tst	w0, #0x1
1004b9fcc:	csel	x21, x23, xzr, ne
1004b9fd0:	mov	x23, #-0x5d00000000000000
1004b9fd4:	csel	x27, x23, xzr, ne
1004b9fd8:	adrp	x0, 7457 ; 0x1021da000
1004b9fdc:	add	x0, x0, #0x978
1004b9fe0:	mov	w1, #0x18
1004b9fe4:	mov	w2, #0x7
1004b9fe8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b9fec:	mov	x20, x0
1004b9ff0:	add	x0, x0, #0x10
1004b9ff4:	ldr	x1, [sp, #0x28]
1004b9ff8:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b9ffc:	adrp	x0, 7457 ; 0x1021da000
1004ba000:	add	x0, x0, #0xf68
1004ba004:	mov	w1, #0x20
1004ba008:	mov	w2, #0x7
1004ba00c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba010:	mov	x25, x0
1004ba014:	stp	x19, x20, [x0, #0x10]
1004ba018:	adrp	x0, 7456 ; 0x1021da000
1004ba01c:	add	x0, x0, #0xf90
1004ba020:	mov	w1, #0x20
1004ba024:	mov	w2, #0x7
1004ba028:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba02c:	mov	x24, x0
1004ba030:	adrp	x8, 7 ; 0x1004c1000
1004ba034:	add	x8, x8, #0x704
1004ba038:	stp	x8, x25, [x0, #0x10]
1004ba03c:	ldp	x28, x26, [x22, #0x10]
1004ba040:	add	x25, x28, #0x1
1004ba044:	mov	x0, x19
1004ba048:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba04c:	mov	x0, x20
1004ba050:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba054:	cmp	x28, x26, lsr #1
1004ba058:	b.hs	0x1004bb264
1004ba05c:	mov	w10, #0x754d
1004ba060:	movk	w10, #0x6574, lsl #16
1004ba064:	str	x25, [x22, #0x10]
1004ba068:	mov	w8, #0x38
1004ba06c:	madd	x8, x28, x8, x22
1004ba070:	mov	x9, #-0x1c00000000000000
1004ba074:	stp	x10, x9, [x8, #0x20]
1004ba078:	stp	x21, x27, [x8, #0x30]
1004ba07c:	adrp	x9, -1206 ; 0x100004000
1004ba080:	add	x9, x9, #0xcc
1004ba084:	stp	xzr, x9, [x8, #0x40]
1004ba088:	str	x24, [x8, #0x50]
1004ba08c:	mov	x0, x20
1004ba090:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ba094:	ldr	x8, [x19]
1004ba098:	ldr	x8, [x8, #0xe8]
1004ba09c:	mov	x20, x19
1004ba0a0:	blr	x8
1004ba0a4:	tst	w0, #0x1
1004ba0a8:	mov	w8, #0x9ce2
1004ba0ac:	movk	w8, #0x93, lsl #16
1004ba0b0:	csel	x21, x8, xzr, ne
1004ba0b4:	csel	x23, x23, xzr, ne
1004ba0b8:	adrp	x0, 7456 ; 0x1021da000
1004ba0bc:	add	x0, x0, #0x978
1004ba0c0:	mov	w1, #0x18
1004ba0c4:	mov	w2, #0x7
1004ba0c8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba0cc:	mov	x20, x0
1004ba0d0:	add	x0, x0, #0x10
1004ba0d4:	ldr	x1, [sp, #0x28]
1004ba0d8:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004ba0dc:	adrp	x0, 7456 ; 0x1021da000
1004ba0e0:	add	x0, x0, #0xfb8
1004ba0e4:	mov	w1, #0x20
1004ba0e8:	mov	w2, #0x7
1004ba0ec:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba0f0:	mov	x25, x0
1004ba0f4:	stp	x19, x20, [x0, #0x10]
1004ba0f8:	adrp	x0, 7456 ; 0x1021da000
1004ba0fc:	add	x0, x0, #0xfe0
1004ba100:	mov	w1, #0x20
1004ba104:	mov	w2, #0x7
1004ba108:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba10c:	mov	x24, x0
1004ba110:	adrp	x8, 7 ; 0x1004c1000
1004ba114:	add	x8, x8, #0x7e4
1004ba118:	stp	x8, x25, [x0, #0x10]
1004ba11c:	ldp	x27, x28, [x22, #0x10]
1004ba120:	add	x25, x27, #0x1
1004ba124:	mov	x0, x19
1004ba128:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba12c:	mov	x0, x20
1004ba130:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba134:	cmp	x27, x28, lsr #1
1004ba138:	b.hs	0x1004bb28c
1004ba13c:	mov	x10, #0x13
1004ba140:	movk	x10, #0xd000, lsl #48
1004ba144:	adrp	x8, 6430 ; 0x101dd8000
1004ba148:	add	x8, x8, #0xfd0 ; literal pool for: "Beep on Error Exit"
1004ba14c:	sub	x8, x8, #0x20
1004ba150:	orr	x8, x8, #0x8000000000000000
1004ba154:	str	x25, [x22, #0x10]
1004ba158:	mov	w9, #0x38
1004ba15c:	madd	x9, x27, x9, x22
1004ba160:	sub	x10, x10, #0x1
1004ba164:	str	x10, [sp]
1004ba168:	stp	x10, x8, [x9, #0x20]
1004ba16c:	stp	x21, x23, [x9, #0x30]
1004ba170:	adrp	x8, -1206 ; 0x100004000
1004ba174:	add	x8, x8, #0xcc
1004ba178:	stp	xzr, x8, [x9, #0x40]
1004ba17c:	str	x24, [x9, #0x50]
1004ba180:	mov	x0, x20
1004ba184:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ba188:	ldr	x8, [x19]
1004ba18c:	ldr	x8, [x8, #0x100]
1004ba190:	mov	x20, x19
1004ba194:	blr	x8
1004ba198:	tst	w0, #0x1
1004ba19c:	mov	w8, #0x9ce2
1004ba1a0:	movk	w8, #0x93, lsl #16
1004ba1a4:	csel	x21, x8, xzr, ne
1004ba1a8:	mov	x8, #-0x5d00000000000000
1004ba1ac:	csel	x23, x8, xzr, ne
1004ba1b0:	adrp	x0, 7456 ; 0x1021da000
1004ba1b4:	add	x0, x0, #0x978
1004ba1b8:	mov	w1, #0x18
1004ba1bc:	mov	w2, #0x7
1004ba1c0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba1c4:	mov	x20, x0
1004ba1c8:	add	x0, x0, #0x10
1004ba1cc:	ldr	x1, [sp, #0x28]
1004ba1d0:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004ba1d4:	adrp	x0, 7457 ; 0x1021db000
1004ba1d8:	add	x0, x0, #0x8
1004ba1dc:	mov	w1, #0x20
1004ba1e0:	mov	w2, #0x7
1004ba1e4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba1e8:	mov	x25, x0
1004ba1ec:	stp	x19, x20, [x0, #0x10]
1004ba1f0:	adrp	x0, 7457 ; 0x1021db000
1004ba1f4:	add	x0, x0, #0x30
1004ba1f8:	mov	w1, #0x20
1004ba1fc:	mov	w2, #0x7
1004ba200:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba204:	mov	x24, x0
1004ba208:	adrp	x8, 7 ; 0x1004c1000
1004ba20c:	add	x8, x8, #0x8d4
1004ba210:	stp	x8, x25, [x0, #0x10]
1004ba214:	ldp	x27, x28, [x22, #0x10]
1004ba218:	add	x25, x27, #0x1
1004ba21c:	mov	x0, x19
1004ba220:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba224:	mov	x0, x20
1004ba228:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba22c:	cmp	x27, x28, lsr #1
1004ba230:	b.hs	0x1004bb2b4
1004ba234:	adrp	x8, 6430 ; 0x101dd8000
1004ba238:	add	x8, x8, #0xff0 ; literal pool for: "Allow Terminal Bell"
1004ba23c:	sub	x8, x8, #0x20
1004ba240:	orr	x8, x8, #0x8000000000000000
1004ba244:	str	x25, [x22, #0x10]
1004ba248:	mov	w9, #0x38
1004ba24c:	madd	x9, x27, x9, x22
1004ba250:	mov	x10, #0x13
1004ba254:	movk	x10, #0xd000, lsl #48
1004ba258:	stp	x10, x8, [x9, #0x20]
1004ba25c:	stp	x21, x23, [x9, #0x30]
1004ba260:	adrp	x8, -1206 ; 0x100004000
1004ba264:	add	x8, x8, #0xcc
1004ba268:	stp	xzr, x8, [x9, #0x40]
1004ba26c:	str	x24, [x9, #0x50]
1004ba270:	mov	x0, x20
1004ba274:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ba278:	ldp	x21, x8, [x22, #0x10]
1004ba27c:	lsr	x9, x8, #1
1004ba280:	add	x20, x21, #0x1
1004ba284:	cmp	x9, x21
1004ba288:	b.ls	0x1004bb2dc
1004ba28c:	mov	w12, #0x2d2d
1004ba290:	movk	w12, #0x2d, lsl #16
1004ba294:	str	x20, [x22, #0x10]
1004ba298:	mov	w10, #0x38
1004ba29c:	madd	x10, x21, x10, x22
1004ba2a0:	mov	x11, #-0x1d00000000000000
1004ba2a4:	stp	x12, x11, [x10, #0x20]
1004ba2a8:	adrp	x11, -1207 ; 0x100003000
1004ba2ac:	add	x11, x11, #0xf40
1004ba2b0:	stp	xzr, xzr, [x10, #0x30]
1004ba2b4:	stp	xzr, x11, [x10, #0x40]
1004ba2b8:	str	xzr, [x10, #0x50]
1004ba2bc:	add	x24, x21, #0x2
1004ba2c0:	cmp	x9, x24
1004ba2c4:	b.lt	0x1004bb30c
1004ba2c8:	str	x24, [x22, #0x10]
1004ba2cc:	mov	w8, #0x38
1004ba2d0:	madd	x8, x20, x8, x22
1004ba2d4:	mov	x9, #0x4f4e
1004ba2d8:	movk	x9, #0x4954, lsl #16
1004ba2dc:	movk	x9, #0x4946, lsl #32
1004ba2e0:	movk	x9, #0x4143, lsl #48
1004ba2e4:	mov	x10, #0x4954
1004ba2e8:	movk	x10, #0x4e4f, lsl #16
1004ba2ec:	movk	x10, #0xec00, lsl #48
1004ba2f0:	stp	x9, x10, [x8, #0x20]
1004ba2f4:	adrp	x9, -1207 ; 0x100003000
1004ba2f8:	add	x9, x9, #0xf40
1004ba2fc:	stp	xzr, xzr, [x8, #0x30]
1004ba300:	stp	xzr, x9, [x8, #0x40]
1004ba304:	str	xzr, [x8, #0x50]
1004ba308:	ldr	x8, [x19]
1004ba30c:	ldr	x8, [x8, #0x2b8]
1004ba310:	mov	x20, x19
1004ba314:	blr	x8
1004ba318:	tst	w0, #0x1
1004ba31c:	mov	w8, #0x9ce2
1004ba320:	movk	w8, #0x93, lsl #16
1004ba324:	csel	x23, x8, xzr, ne
1004ba328:	mov	x21, #-0x5d00000000000000
1004ba32c:	csel	x27, x21, xzr, ne
1004ba330:	adrp	x0, 7456 ; 0x1021da000
1004ba334:	add	x0, x0, #0x978
1004ba338:	mov	w1, #0x18
1004ba33c:	mov	w2, #0x7
1004ba340:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba344:	mov	x20, x0
1004ba348:	add	x0, x0, #0x10
1004ba34c:	ldr	x1, [sp, #0x28]
1004ba350:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004ba354:	adrp	x0, 7457 ; 0x1021db000
1004ba358:	add	x0, x0, #0x58
1004ba35c:	mov	w1, #0x20
1004ba360:	mov	w2, #0x7
1004ba364:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba368:	mov	x25, x0
1004ba36c:	stp	x19, x20, [x0, #0x10]
1004ba370:	adrp	x0, 7457 ; 0x1021db000
1004ba374:	add	x0, x0, #0x80
1004ba378:	mov	w1, #0x20
1004ba37c:	mov	w2, #0x7
1004ba380:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba384:	mov	x24, x0
1004ba388:	adrp	x8, 7 ; 0x1004c1000
1004ba38c:	add	x8, x8, #0x9c4
1004ba390:	stp	x8, x25, [x0, #0x10]
1004ba394:	ldp	x28, x26, [x22, #0x10]
1004ba398:	add	x25, x28, #0x1
1004ba39c:	mov	x0, x19
1004ba3a0:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba3a4:	mov	x0, x20
1004ba3a8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba3ac:	cmp	x28, x26, lsr #1
1004ba3b0:	b.hs	0x1004bb334
1004ba3b4:	str	x25, [x22, #0x10]
1004ba3b8:	mov	w8, #0x38
1004ba3bc:	madd	x8, x28, x8, x22
1004ba3c0:	mov	x9, #-0x1c00000000000000
1004ba3c4:	mov	w10, #0x754d
1004ba3c8:	movk	w10, #0x6574, lsl #16
1004ba3cc:	stp	x10, x9, [x8, #0x20]
1004ba3d0:	stp	x23, x27, [x8, #0x30]
1004ba3d4:	adrp	x9, -1206 ; 0x100004000
1004ba3d8:	add	x9, x9, #0xcc
1004ba3dc:	stp	xzr, x9, [x8, #0x40]
1004ba3e0:	str	x24, [x8, #0x50]
1004ba3e4:	mov	x0, x20
1004ba3e8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ba3ec:	ldr	x8, [x19]
1004ba3f0:	ldr	x8, [x8, #0x118]
1004ba3f4:	mov	x20, x19
1004ba3f8:	blr	x8
1004ba3fc:	tst	w0, #0x1
1004ba400:	mov	w8, #0x9ce2
1004ba404:	movk	w8, #0x93, lsl #16
1004ba408:	csel	x23, x8, xzr, ne
1004ba40c:	csel	x21, x21, xzr, ne
1004ba410:	adrp	x0, 7456 ; 0x1021da000
1004ba414:	add	x0, x0, #0x978
1004ba418:	mov	w1, #0x18
1004ba41c:	mov	w2, #0x7
1004ba420:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba424:	mov	x20, x0
1004ba428:	add	x0, x0, #0x10
1004ba42c:	ldr	x1, [sp, #0x28]
1004ba430:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004ba434:	adrp	x0, 7457 ; 0x1021db000
1004ba438:	add	x0, x0, #0xa8
1004ba43c:	mov	w1, #0x20
1004ba440:	mov	w2, #0x7
1004ba444:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba448:	mov	x25, x0
1004ba44c:	stp	x19, x20, [x0, #0x10]
1004ba450:	adrp	x0, 7457 ; 0x1021db000
1004ba454:	add	x0, x0, #0xd0
1004ba458:	mov	w1, #0x20
1004ba45c:	mov	w2, #0x7
1004ba460:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba464:	mov	x24, x0
1004ba468:	adrp	x8, 7 ; 0x1004c1000
1004ba46c:	add	x8, x8, #0xac4
1004ba470:	stp	x8, x25, [x0, #0x10]
1004ba474:	ldp	x26, x27, [x22, #0x10]
1004ba478:	add	x25, x26, #0x1
1004ba47c:	mov	x0, x19
1004ba480:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba484:	mov	x0, x20
1004ba488:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba48c:	cmp	x26, x27, lsr #1
1004ba490:	b.hs	0x1004bb35c
1004ba494:	adrp	x8, 6431 ; 0x101dd9000
1004ba498:	add	x8, x8, #0x10 ; literal pool for: "Notify on Command Finish"
1004ba49c:	sub	x8, x8, #0x20
1004ba4a0:	orr	x8, x8, #0x8000000000000000
1004ba4a4:	str	x25, [x22, #0x10]
1004ba4a8:	mov	w9, #0x38
1004ba4ac:	madd	x9, x26, x9, x22
1004ba4b0:	mov	x10, #0x13
1004ba4b4:	movk	x10, #0xd000, lsl #48
1004ba4b8:	add	x10, x10, #0x5
1004ba4bc:	stp	x10, x8, [x9, #0x20]
1004ba4c0:	stp	x23, x21, [x9, #0x30]
1004ba4c4:	adrp	x8, -1206 ; 0x100004000
1004ba4c8:	add	x8, x8, #0xcc
1004ba4cc:	stp	xzr, x8, [x9, #0x40]
1004ba4d0:	str	x24, [x9, #0x50]
1004ba4d4:	mov	x0, x20
1004ba4d8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ba4dc:	ldr	x8, [x19]
1004ba4e0:	ldr	x8, [x8, #0x130]
1004ba4e4:	mov	x20, x19
1004ba4e8:	blr	x8
1004ba4ec:	tst	w0, #0x1
1004ba4f0:	mov	w8, #0x9ce2
1004ba4f4:	movk	w8, #0x93, lsl #16
1004ba4f8:	csel	x21, x8, xzr, ne
1004ba4fc:	mov	x23, #-0x5d00000000000000
1004ba500:	csel	x26, x23, xzr, ne
1004ba504:	adrp	x0, 7456 ; 0x1021da000
1004ba508:	add	x0, x0, #0x978
1004ba50c:	mov	w1, #0x18
1004ba510:	mov	w2, #0x7
1004ba514:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba518:	mov	x20, x0
1004ba51c:	add	x0, x0, #0x10
1004ba520:	ldr	x1, [sp, #0x28]
1004ba524:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004ba528:	adrp	x0, 7457 ; 0x1021db000
1004ba52c:	add	x0, x0, #0xf8
1004ba530:	mov	w1, #0x20
1004ba534:	mov	w2, #0x7
1004ba538:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba53c:	mov	x25, x0
1004ba540:	stp	x19, x20, [x0, #0x10]
1004ba544:	adrp	x0, 7457 ; 0x1021db000
1004ba548:	add	x0, x0, #0x120
1004ba54c:	mov	w1, #0x20
1004ba550:	mov	w2, #0x7
1004ba554:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba558:	mov	x24, x0
1004ba55c:	adrp	x8, 7 ; 0x1004c1000
1004ba560:	add	x8, x8, #0xbb4
1004ba564:	stp	x8, x25, [x0, #0x10]
1004ba568:	ldp	x27, x28, [x22, #0x10]
1004ba56c:	add	x25, x27, #0x1
1004ba570:	mov	x0, x19
1004ba574:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba578:	mov	x0, x20
1004ba57c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba580:	cmp	x27, x28, lsr #1
1004ba584:	b.hs	0x1004bb384
1004ba588:	adrp	x8, 6431 ; 0x101dd9000
1004ba58c:	add	x8, x8, #0x30 ; literal pool for: "Notify on Error Exit"
1004ba590:	sub	x8, x8, #0x20
1004ba594:	orr	x8, x8, #0x8000000000000000
1004ba598:	str	x25, [x22, #0x10]
1004ba59c:	mov	w9, #0x38
1004ba5a0:	madd	x9, x27, x9, x22
1004ba5a4:	mov	x10, #0x13
1004ba5a8:	movk	x10, #0xd000, lsl #48
1004ba5ac:	add	x10, x10, #0x1
1004ba5b0:	stp	x10, x8, [x9, #0x20]
1004ba5b4:	stp	x21, x26, [x9, #0x30]
1004ba5b8:	adrp	x8, -1206 ; 0x100004000
1004ba5bc:	add	x8, x8, #0xcc
1004ba5c0:	stp	xzr, x8, [x9, #0x40]
1004ba5c4:	str	x24, [x9, #0x50]
1004ba5c8:	mov	x0, x20
1004ba5cc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ba5d0:	ldr	x8, [x19]
1004ba5d4:	ldr	x8, [x8, #0x148]
1004ba5d8:	mov	x20, x19
1004ba5dc:	blr	x8
1004ba5e0:	tst	w0, #0x1
1004ba5e4:	mov	w8, #0x9ce2
1004ba5e8:	movk	w8, #0x93, lsl #16
1004ba5ec:	csel	x21, x8, xzr, ne
1004ba5f0:	csel	x23, x23, xzr, ne
1004ba5f4:	adrp	x0, 7456 ; 0x1021da000
1004ba5f8:	add	x0, x0, #0x978
1004ba5fc:	mov	w1, #0x18
1004ba600:	mov	w2, #0x7
1004ba604:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba608:	mov	x20, x0
1004ba60c:	add	x0, x0, #0x10
1004ba610:	ldr	x1, [sp, #0x28]
1004ba614:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004ba618:	adrp	x0, 7457 ; 0x1021db000
1004ba61c:	add	x0, x0, #0x148
1004ba620:	mov	w1, #0x20
1004ba624:	mov	w2, #0x7
1004ba628:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba62c:	mov	x25, x0
1004ba630:	stp	x19, x20, [x0, #0x10]
1004ba634:	adrp	x0, 7457 ; 0x1021db000
1004ba638:	add	x0, x0, #0x170
1004ba63c:	mov	w1, #0x20
1004ba640:	mov	w2, #0x7
1004ba644:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba648:	mov	x24, x0
1004ba64c:	adrp	x8, 7 ; 0x1004c1000
1004ba650:	add	x8, x8, #0xca4
1004ba654:	stp	x8, x25, [x0, #0x10]
1004ba658:	ldp	x26, x27, [x22, #0x10]
1004ba65c:	add	x25, x26, #0x1
1004ba660:	mov	x0, x19
1004ba664:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba668:	mov	x0, x20
1004ba66c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba670:	cmp	x26, x27, lsr #1
1004ba674:	b.hs	0x1004bb3ac
1004ba678:	adrp	x8, 6431 ; 0x101dd9000
1004ba67c:	add	x8, x8, #0x50 ; literal pool for: "Notify on Watch Finish"
1004ba680:	sub	x8, x8, #0x20
1004ba684:	orr	x8, x8, #0x8000000000000000
1004ba688:	str	x25, [x22, #0x10]
1004ba68c:	mov	w9, #0x38
1004ba690:	madd	x9, x26, x9, x22
1004ba694:	mov	x10, #0x13
1004ba698:	movk	x10, #0xd000, lsl #48
1004ba69c:	add	x10, x10, #0x3
1004ba6a0:	stp	x10, x8, [x9, #0x20]
1004ba6a4:	stp	x21, x23, [x9, #0x30]
1004ba6a8:	adrp	x8, -1206 ; 0x100004000
1004ba6ac:	add	x8, x8, #0xcc
1004ba6b0:	stp	xzr, x8, [x9, #0x40]
1004ba6b4:	str	x24, [x9, #0x50]
1004ba6b8:	mov	x0, x20
1004ba6bc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ba6c0:	ldr	x8, [x19]
1004ba6c4:	ldr	x8, [x8, #0x160]
1004ba6c8:	mov	x20, x19
1004ba6cc:	blr	x8
1004ba6d0:	tst	w0, #0x1
1004ba6d4:	mov	w8, #0x9ce2
1004ba6d8:	movk	w8, #0x93, lsl #16
1004ba6dc:	csel	x21, x8, xzr, ne
1004ba6e0:	mov	x8, #-0x5d00000000000000
1004ba6e4:	csel	x23, x8, xzr, ne
1004ba6e8:	adrp	x0, 7456 ; 0x1021da000
1004ba6ec:	add	x0, x0, #0x978
1004ba6f0:	mov	w1, #0x18
1004ba6f4:	mov	w2, #0x7
1004ba6f8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba6fc:	mov	x20, x0
1004ba700:	add	x0, x0, #0x10
1004ba704:	ldr	x1, [sp, #0x28]
1004ba708:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004ba70c:	adrp	x0, 7457 ; 0x1021db000
1004ba710:	add	x0, x0, #0x198
1004ba714:	mov	w1, #0x20
1004ba718:	mov	w2, #0x7
1004ba71c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba720:	mov	x25, x0
1004ba724:	stp	x19, x20, [x0, #0x10]
1004ba728:	adrp	x0, 7457 ; 0x1021db000
1004ba72c:	add	x0, x0, #0x1c0
1004ba730:	mov	w1, #0x20
1004ba734:	mov	w2, #0x7
1004ba738:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba73c:	mov	x24, x0
1004ba740:	adrp	x8, 7 ; 0x1004c1000
1004ba744:	add	x8, x8, #0xd94
1004ba748:	stp	x8, x25, [x0, #0x10]
1004ba74c:	ldp	x26, x27, [x22, #0x10]
1004ba750:	add	x25, x26, #0x1
1004ba754:	mov	x0, x19
1004ba758:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba75c:	mov	x0, x20
1004ba760:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba764:	cmp	x26, x27, lsr #1
1004ba768:	b.hs	0x1004bb3d4
1004ba76c:	adrp	x8, 6431 ; 0x101dd9000
1004ba770:	add	x8, x8, #0x70 ; literal pool for: "Allow App Notifications"
1004ba774:	sub	x8, x8, #0x20
1004ba778:	orr	x8, x8, #0x8000000000000000
1004ba77c:	str	x25, [x22, #0x10]
1004ba780:	mov	w9, #0x38
1004ba784:	madd	x9, x26, x9, x22
1004ba788:	mov	x10, #0x13
1004ba78c:	movk	x10, #0xd000, lsl #48
1004ba790:	add	x10, x10, #0x4
1004ba794:	stp	x10, x8, [x9, #0x20]
1004ba798:	stp	x21, x23, [x9, #0x30]
1004ba79c:	adrp	x8, -1206 ; 0x100004000
1004ba7a0:	add	x8, x8, #0xcc
1004ba7a4:	stp	xzr, x8, [x9, #0x40]
1004ba7a8:	str	x24, [x9, #0x50]
1004ba7ac:	mov	x0, x20
1004ba7b0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ba7b4:	ldp	x21, x8, [x22, #0x10]
1004ba7b8:	lsr	x9, x8, #1
1004ba7bc:	add	x20, x21, #0x1
1004ba7c0:	cmp	x9, x21
1004ba7c4:	b.ls	0x1004bb3fc
1004ba7c8:	str	x20, [x22, #0x10]
1004ba7cc:	mov	w10, #0x38
1004ba7d0:	madd	x10, x21, x10, x22
1004ba7d4:	mov	x11, #-0x1d00000000000000
1004ba7d8:	mov	w12, #0x2d2d
1004ba7dc:	movk	w12, #0x2d, lsl #16
1004ba7e0:	stp	x12, x11, [x10, #0x20]
1004ba7e4:	adrp	x11, -1207 ; 0x100003000
1004ba7e8:	add	x11, x11, #0xf40
1004ba7ec:	stp	xzr, xzr, [x10, #0x30]
1004ba7f0:	stp	xzr, x11, [x10, #0x40]
1004ba7f4:	str	xzr, [x10, #0x50]
1004ba7f8:	add	x24, x21, #0x2
1004ba7fc:	cmp	x9, x24
1004ba800:	b.lt	0x1004bb42c
1004ba804:	ldr	x21, [sp, #0x20]
1004ba808:	str	x24, [x22, #0x10]
1004ba80c:	mov	w8, #0x38
1004ba810:	madd	x8, x20, x8, x22
1004ba814:	mov	x9, #0x4154
1004ba818:	movk	x9, #0x2042, lsl #16
1004ba81c:	movk	x9, #0x4142, lsl #32
1004ba820:	movk	x9, #0x4744, lsl #48
1004ba824:	mov	x10, #0x45
1004ba828:	movk	x10, #0xe900, lsl #48
1004ba82c:	stp	x9, x10, [x8, #0x20]
1004ba830:	adrp	x9, -1207 ; 0x100003000
1004ba834:	add	x9, x9, #0xf40
1004ba838:	stp	xzr, xzr, [x8, #0x30]
1004ba83c:	stp	xzr, x9, [x8, #0x40]
1004ba840:	str	xzr, [x8, #0x50]
1004ba844:	ldr	x8, [x21]
1004ba848:	ldr	x8, [x8, #0x420]
1004ba84c:	mov	x20, x21
1004ba850:	blr	x8
1004ba854:	str	x1, [sp, #0x18]
1004ba858:	cbz	x1, 0x1004babb8
1004ba85c:	mov	x0, x1
1004ba860:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ba864:	ldr	x8, [x19]
1004ba868:	ldr	x8, [x8, #0x1a8]
1004ba86c:	mov	x20, x19
1004ba870:	blr	x8
1004ba874:	tst	w0, #0x1
1004ba878:	mov	w8, #0x9ce2
1004ba87c:	movk	w8, #0x93, lsl #16
1004ba880:	csel	x24, x8, xzr, ne
1004ba884:	mov	x8, #-0x5d00000000000000
1004ba888:	csel	x28, x8, xzr, ne
1004ba88c:	adrp	x0, 7456 ; 0x1021da000
1004ba890:	add	x0, x0, #0x978
1004ba894:	mov	w1, #0x18
1004ba898:	mov	w2, #0x7
1004ba89c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba8a0:	mov	x20, x0
1004ba8a4:	add	x0, x0, #0x10
1004ba8a8:	ldr	x1, [sp, #0x28]
1004ba8ac:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004ba8b0:	adrp	x0, 7457 ; 0x1021db000
1004ba8b4:	add	x0, x0, #0x1e8
1004ba8b8:	mov	w1, #0x18
1004ba8bc:	mov	w2, #0x7
1004ba8c0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba8c4:	mov	x25, x0
1004ba8c8:	add	x0, x0, #0x10
1004ba8cc:	mov	x1, x21
1004ba8d0:	bl	0x101acab58 ; symbol stub for: _swift_weakInit
1004ba8d4:	adrp	x0, 7457 ; 0x1021db000
1004ba8d8:	add	x0, x0, #0x3a0
1004ba8dc:	mov	w1, #0x28
1004ba8e0:	mov	w2, #0x7
1004ba8e4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba8e8:	mov	x27, x0
1004ba8ec:	stp	x19, x25, [x0, #0x10]
1004ba8f0:	str	x20, [x0, #0x20]
1004ba8f4:	adrp	x0, 7457 ; 0x1021db000
1004ba8f8:	add	x0, x0, #0x3c8
1004ba8fc:	mov	w1, #0x20
1004ba900:	mov	w2, #0x7
1004ba904:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba908:	mov	x26, x0
1004ba90c:	adrp	x8, 8 ; 0x1004c2000
1004ba910:	add	x8, x8, #0x360
1004ba914:	stp	x8, x27, [x0, #0x10]
1004ba918:	ldp	x21, x23, [x22, #0x10]
1004ba91c:	add	x27, x21, #0x1
1004ba920:	mov	x0, x19
1004ba924:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba928:	mov	x0, x25
1004ba92c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba930:	mov	x0, x20
1004ba934:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ba938:	cmp	x21, x23, lsr #1
1004ba93c:	b.hs	0x1004bb52c
1004ba940:	adrp	x8, 6431 ; 0x101dd9000
1004ba944:	add	x8, x8, #0x130 ; literal pool for: "While Processing"
1004ba948:	sub	x8, x8, #0x20
1004ba94c:	orr	x8, x8, #0x8000000000000000
1004ba950:	str	x27, [x22, #0x10]
1004ba954:	mov	w9, #0x38
1004ba958:	madd	x9, x21, x9, x22
1004ba95c:	mov	x10, #0x13
1004ba960:	movk	x10, #0xd000, lsl #48
1004ba964:	sub	x10, x10, #0x3
1004ba968:	stp	x10, x8, [x9, #0x20]
1004ba96c:	stp	x24, x28, [x9, #0x30]
1004ba970:	adrp	x8, -1206 ; 0x100004000
1004ba974:	add	x8, x8, #0xcc
1004ba978:	stp	xzr, x8, [x9, #0x40]
1004ba97c:	str	x26, [x9, #0x50]
1004ba980:	mov	x0, x20
1004ba984:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ba988:	mov	x0, x25
1004ba98c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ba990:	ldr	x8, [x19]
1004ba994:	ldr	x8, [x8, #0x1c0]
1004ba998:	mov	x20, x19
1004ba99c:	blr	x8
1004ba9a0:	tst	w0, #0x1
1004ba9a4:	mov	w8, #0x9ce2
1004ba9a8:	movk	w8, #0x93, lsl #16
1004ba9ac:	csel	x21, x8, xzr, ne
1004ba9b0:	mov	x8, #-0x5d00000000000000
1004ba9b4:	csel	x23, x8, xzr, ne
1004ba9b8:	adrp	x0, 7456 ; 0x1021da000
1004ba9bc:	add	x0, x0, #0x978
1004ba9c0:	mov	w1, #0x18
1004ba9c4:	mov	w2, #0x7
1004ba9c8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba9cc:	mov	x20, x0
1004ba9d0:	add	x0, x0, #0x10
1004ba9d4:	ldr	x1, [sp, #0x28]
1004ba9d8:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004ba9dc:	adrp	x0, 7457 ; 0x1021db000
1004ba9e0:	add	x0, x0, #0x1e8
1004ba9e4:	mov	w1, #0x18
1004ba9e8:	mov	w2, #0x7
1004ba9ec:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ba9f0:	mov	x25, x0
1004ba9f4:	add	x0, x0, #0x10
1004ba9f8:	ldr	x1, [sp, #0x20]
1004ba9fc:	bl	0x101acab58 ; symbol stub for: _swift_weakInit
1004baa00:	adrp	x0, 7457 ; 0x1021db000
1004baa04:	add	x0, x0, #0x3f0
1004baa08:	mov	w1, #0x28
1004baa0c:	mov	w2, #0x7
1004baa10:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004baa14:	mov	x27, x0
1004baa18:	stp	x19, x25, [x0, #0x10]
1004baa1c:	str	x20, [x0, #0x20]
1004baa20:	adrp	x0, 7457 ; 0x1021db000
1004baa24:	add	x0, x0, #0x418
1004baa28:	mov	w1, #0x20
1004baa2c:	mov	w2, #0x7
1004baa30:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004baa34:	mov	x26, x0
1004baa38:	adrp	x8, 8 ; 0x1004c2000
1004baa3c:	add	x8, x8, #0x374
1004baa40:	stp	x8, x27, [x0, #0x10]
1004baa44:	ldp	x24, x28, [x22, #0x10]
1004baa48:	add	x27, x24, #0x1
1004baa4c:	mov	x0, x19
1004baa50:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004baa54:	mov	x0, x25
1004baa58:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004baa5c:	mov	x0, x20
1004baa60:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004baa64:	cmp	x24, x28, lsr #1
1004baa68:	b.hs	0x1004bb554
1004baa6c:	adrp	x8, 6431 ; 0x101dd9000
1004baa70:	add	x8, x8, #0x150 ; literal pool for: "When Task Completes"
1004baa74:	sub	x8, x8, #0x20
1004baa78:	orr	x8, x8, #0x8000000000000000
1004baa7c:	str	x27, [x22, #0x10]
1004baa80:	mov	w9, #0x38
1004baa84:	madd	x9, x24, x9, x22
1004baa88:	mov	x10, #0x13
1004baa8c:	movk	x10, #0xd000, lsl #48
1004baa90:	stp	x10, x8, [x9, #0x20]
1004baa94:	stp	x21, x23, [x9, #0x30]
1004baa98:	adrp	x8, -1206 ; 0x100004000
1004baa9c:	add	x8, x8, #0xcc
1004baaa0:	stp	xzr, x8, [x9, #0x40]
1004baaa4:	str	x26, [x9, #0x50]
1004baaa8:	mov	x0, x20
1004baaac:	bl	0x101aca960 ; symbol stub for: _swift_release
1004baab0:	mov	x0, x25
1004baab4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004baab8:	ldr	x8, [x19]
1004baabc:	ldr	x8, [x8, #0x1d8]
1004baac0:	mov	x20, x19
1004baac4:	blr	x8
1004baac8:	tst	w0, #0x1
1004baacc:	mov	w8, #0x9ce2
1004baad0:	movk	w8, #0x93, lsl #16
1004baad4:	csel	x8, x8, xzr, ne
1004baad8:	str	x8, [sp, #0x10]
1004baadc:	mov	x8, #-0x5d00000000000000
1004baae0:	csel	x24, x8, xzr, ne
1004baae4:	adrp	x0, 7456 ; 0x1021da000
1004baae8:	add	x0, x0, #0x978
1004baaec:	mov	w1, #0x18
1004baaf0:	mov	w2, #0x7
1004baaf4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004baaf8:	mov	x20, x0
1004baafc:	add	x0, x0, #0x10
1004bab00:	ldr	x1, [sp, #0x28]
1004bab04:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bab08:	adrp	x0, 7457 ; 0x1021db000
1004bab0c:	add	x0, x0, #0x1e8
1004bab10:	mov	w1, #0x18
1004bab14:	mov	w2, #0x7
1004bab18:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bab1c:	mov	x25, x0
1004bab20:	add	x0, x0, #0x10
1004bab24:	ldr	x1, [sp, #0x20]
1004bab28:	bl	0x101acab58 ; symbol stub for: _swift_weakInit
1004bab2c:	adrp	x0, 7457 ; 0x1021db000
1004bab30:	add	x0, x0, #0x440
1004bab34:	mov	w1, #0x28
1004bab38:	mov	w2, #0x7
1004bab3c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bab40:	mov	x27, x0
1004bab44:	stp	x19, x25, [x0, #0x10]
1004bab48:	str	x20, [x0, #0x20]
1004bab4c:	adrp	x0, 7457 ; 0x1021db000
1004bab50:	add	x0, x0, #0x468
1004bab54:	mov	w1, #0x20
1004bab58:	mov	w2, #0x7
1004bab5c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bab60:	mov	x26, x0
1004bab64:	adrp	x8, 8 ; 0x1004c2000
1004bab68:	add	x8, x8, #0x388
1004bab6c:	stp	x8, x27, [x0, #0x10]
1004bab70:	ldp	x23, x28, [x22, #0x10]
1004bab74:	add	x27, x23, #0x1
1004bab78:	mov	x0, x19
1004bab7c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bab80:	mov	x0, x25
1004bab84:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bab88:	mov	x0, x20
1004bab8c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bab90:	adrp	x8, 6431 ; 0x101dd9000
1004bab94:	add	x8, x8, #0x170 ; literal pool for: "When Awaiting Input"
1004bab98:	sub	x21, x8, #0x20
1004bab9c:	cmp	x23, x28, lsr #1
1004baba0:	b.hs	0x1004bb57c
1004baba4:	adrp	x8, -1206 ; 0x100004000
1004baba8:	add	x8, x8, #0xcc
1004babac:	mov	x11, #0x13
1004babb0:	movk	x11, #0xd000, lsl #48
1004babb4:	b	0x1004baddc
1004babb8:	ldr	x8, [x19]
1004babbc:	ldr	x8, [x8, #0x178]
1004babc0:	mov	x20, x19
1004babc4:	blr	x8
1004babc8:	tst	w0, #0x1
1004babcc:	mov	w8, #0x9ce2
1004babd0:	movk	w8, #0x93, lsl #16
1004babd4:	csel	x24, x8, xzr, ne
1004babd8:	mov	x8, #-0x5d00000000000000
1004babdc:	csel	x28, x8, xzr, ne
1004babe0:	adrp	x0, 7456 ; 0x1021da000
1004babe4:	add	x0, x0, #0x978
1004babe8:	mov	w1, #0x18
1004babec:	mov	w2, #0x7
1004babf0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004babf4:	mov	x20, x0
1004babf8:	add	x0, x0, #0x10
1004babfc:	ldr	x1, [sp, #0x28]
1004bac00:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bac04:	adrp	x0, 7457 ; 0x1021db000
1004bac08:	add	x0, x0, #0x1e8
1004bac0c:	mov	w1, #0x18
1004bac10:	mov	w2, #0x7
1004bac14:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bac18:	mov	x25, x0
1004bac1c:	add	x0, x0, #0x10
1004bac20:	mov	x1, x21
1004bac24:	bl	0x101acab58 ; symbol stub for: _swift_weakInit
1004bac28:	adrp	x0, 7457 ; 0x1021db000
1004bac2c:	add	x0, x0, #0x210
1004bac30:	mov	w1, #0x28
1004bac34:	mov	w2, #0x7
1004bac38:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bac3c:	mov	x27, x0
1004bac40:	stp	x19, x25, [x0, #0x10]
1004bac44:	str	x20, [x0, #0x20]
1004bac48:	adrp	x0, 7457 ; 0x1021db000
1004bac4c:	add	x0, x0, #0x238
1004bac50:	mov	w1, #0x20
1004bac54:	mov	w2, #0x7
1004bac58:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bac5c:	mov	x26, x0
1004bac60:	adrp	x8, 7 ; 0x1004c1000
1004bac64:	add	x8, x8, #0xeac
1004bac68:	stp	x8, x27, [x0, #0x10]
1004bac6c:	ldp	x21, x23, [x22, #0x10]
1004bac70:	add	x27, x21, #0x1
1004bac74:	mov	x0, x19
1004bac78:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bac7c:	mov	x0, x25
1004bac80:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bac84:	mov	x0, x20
1004bac88:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bac8c:	cmp	x21, x23, lsr #1
1004bac90:	b.hs	0x1004bb5cc
1004bac94:	adrp	x8, 6431 ; 0x101dd9000
1004bac98:	add	x8, x8, #0x90 ; literal pool for: "When Command Finishes"
1004bac9c:	sub	x8, x8, #0x20
1004baca0:	orr	x8, x8, #0x8000000000000000
1004baca4:	str	x27, [x22, #0x10]
1004baca8:	mov	w9, #0x38
1004bacac:	madd	x9, x21, x9, x22
1004bacb0:	mov	x10, #0x13
1004bacb4:	movk	x10, #0xd000, lsl #48
1004bacb8:	add	x10, x10, #0x2
1004bacbc:	stp	x10, x8, [x9, #0x20]
1004bacc0:	stp	x24, x28, [x9, #0x30]
1004bacc4:	adrp	x8, -1206 ; 0x100004000
1004bacc8:	add	x8, x8, #0xcc
1004baccc:	stp	xzr, x8, [x9, #0x40]
1004bacd0:	str	x26, [x9, #0x50]
1004bacd4:	mov	x0, x20
1004bacd8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bacdc:	mov	x0, x25
1004bace0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bace4:	ldr	x8, [x19]
1004bace8:	ldr	x8, [x8, #0x190]
1004bacec:	mov	x20, x19
1004bacf0:	blr	x8
1004bacf4:	tst	w0, #0x1
1004bacf8:	mov	w8, #0x9ce2
1004bacfc:	movk	w8, #0x93, lsl #16
1004bad00:	csel	x8, x8, xzr, ne
1004bad04:	str	x8, [sp, #0x10]
1004bad08:	mov	x8, #-0x5d00000000000000
1004bad0c:	csel	x24, x8, xzr, ne
1004bad10:	adrp	x0, 7456 ; 0x1021da000
1004bad14:	add	x0, x0, #0x978
1004bad18:	mov	w1, #0x18
1004bad1c:	mov	w2, #0x7
1004bad20:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bad24:	mov	x20, x0
1004bad28:	add	x0, x0, #0x10
1004bad2c:	ldr	x1, [sp, #0x28]
1004bad30:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bad34:	adrp	x0, 7457 ; 0x1021db000
1004bad38:	add	x0, x0, #0x1e8
1004bad3c:	mov	w1, #0x18
1004bad40:	mov	w2, #0x7
1004bad44:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bad48:	mov	x25, x0
1004bad4c:	add	x0, x0, #0x10
1004bad50:	ldr	x1, [sp, #0x20]
1004bad54:	bl	0x101acab58 ; symbol stub for: _swift_weakInit
1004bad58:	adrp	x0, 7457 ; 0x1021db000
1004bad5c:	add	x0, x0, #0x260
1004bad60:	mov	w1, #0x28
1004bad64:	mov	w2, #0x7
1004bad68:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bad6c:	mov	x27, x0
1004bad70:	stp	x19, x25, [x0, #0x10]
1004bad74:	str	x20, [x0, #0x20]
1004bad78:	adrp	x0, 7457 ; 0x1021db000
1004bad7c:	add	x0, x0, #0x288
1004bad80:	mov	w1, #0x20
1004bad84:	mov	w2, #0x7
1004bad88:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bad8c:	mov	x26, x0
1004bad90:	adrp	x8, 7 ; 0x1004c1000
1004bad94:	add	x8, x8, #0xfd8
1004bad98:	stp	x8, x27, [x0, #0x10]
1004bad9c:	ldp	x23, x28, [x22, #0x10]
1004bada0:	add	x27, x23, #0x1
1004bada4:	mov	x0, x19
1004bada8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004badac:	mov	x0, x25
1004badb0:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004badb4:	mov	x0, x20
1004badb8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004badbc:	adrp	x8, 6431 ; 0x101dd9000
1004badc0:	add	x8, x8, #0xb0 ; literal pool for: "When Command Fails"
1004badc4:	sub	x21, x8, #0x20
1004badc8:	cmp	x23, x28, lsr #1
1004badcc:	b.hs	0x1004bb5f4
1004badd0:	adrp	x8, -1206 ; 0x100004000
1004badd4:	add	x8, x8, #0xcc
1004badd8:	ldr	x11, [sp]
1004baddc:	orr	x9, x21, #0x8000000000000000
1004bade0:	str	x27, [x22, #0x10]
1004bade4:	mov	w10, #0x38
1004bade8:	madd	x10, x23, x10, x22
1004badec:	stp	x11, x9, [x10, #0x20]
1004badf0:	ldr	x9, [sp, #0x10]
1004badf4:	stp	x9, x24, [x10, #0x30]
1004badf8:	stp	xzr, x8, [x10, #0x40]
1004badfc:	str	x26, [x10, #0x50]
1004bae00:	mov	x0, x20
1004bae04:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bae08:	mov	x0, x25
1004bae0c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bae10:	ldp	x21, x8, [x22, #0x10]
1004bae14:	lsr	x9, x8, #1
1004bae18:	add	x23, x21, #0x1
1004bae1c:	cmp	x9, x21
1004bae20:	b.ls	0x1004bb454
1004bae24:	str	x23, [x22, #0x10]
1004bae28:	mov	w10, #0x38
1004bae2c:	madd	x10, x21, x10, x22
1004bae30:	mov	x11, #-0x1d00000000000000
1004bae34:	mov	w12, #0x2d2d
1004bae38:	movk	w12, #0x2d, lsl #16
1004bae3c:	stp	x12, x11, [x10, #0x20]
1004bae40:	adrp	x11, -1207 ; 0x100003000
1004bae44:	add	x11, x11, #0xf40
1004bae48:	stp	xzr, xzr, [x10, #0x30]
1004bae4c:	stp	xzr, x11, [x10, #0x40]
1004bae50:	str	xzr, [x10, #0x50]
1004bae54:	add	x25, x21, #0x2
1004bae58:	cmp	x9, x25
1004bae5c:	b.lt	0x1004bb484
1004bae60:	str	x25, [x22, #0x10]
1004bae64:	mov	w8, #0x38
1004bae68:	madd	x8, x23, x8, x22
1004bae6c:	mov	x9, #0x4143
1004bae70:	movk	x9, #0x4646, lsl #16
1004bae74:	movk	x9, #0x4945, lsl #32
1004bae78:	movk	x9, #0x414e, lsl #48
1004bae7c:	mov	x10, #0x4554
1004bae80:	movk	x10, #0xea00, lsl #48
1004bae84:	stp	x9, x10, [x8, #0x20]
1004bae88:	stp	xzr, xzr, [x8, #0x30]
1004bae8c:	adrp	x9, -1207 ; 0x100003000
1004bae90:	add	x9, x9, #0xf40
1004bae94:	stp	xzr, x9, [x8, #0x40]
1004bae98:	str	xzr, [x8, #0x50]
1004bae9c:	ldp	x8, x20, [sp, #0x18]
1004baea0:	cbz	x8, 0x1004bafa4
1004baea4:	ldr	x8, [sp, #0x8]
1004baea8:	blr	x8
1004baeac:	mov	x20, x0
1004baeb0:	ldr	x8, [x0]
1004baeb4:	ldr	x8, [x8, #0x220]
1004baeb8:	blr	x8
1004baebc:	tst	w0, #0x1
1004baec0:	mov	w8, #0x9ce2
1004baec4:	movk	w8, #0x93, lsl #16
1004baec8:	csel	x21, x8, xzr, ne
1004baecc:	mov	x8, #-0x5d00000000000000
1004baed0:	csel	x26, x8, xzr, ne
1004baed4:	adrp	x0, 7456 ; 0x1021da000
1004baed8:	add	x0, x0, #0x978
1004baedc:	mov	w1, #0x18
1004baee0:	mov	w2, #0x7
1004baee4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004baee8:	mov	x23, x0
1004baeec:	add	x0, x0, #0x10
1004baef0:	ldr	x1, [sp, #0x28]
1004baef4:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004baef8:	adrp	x0, 7457 ; 0x1021db000
1004baefc:	add	x0, x0, #0x2b0
1004baf00:	mov	w1, #0x20
1004baf04:	mov	w2, #0x7
1004baf08:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004baf0c:	mov	x25, x0
1004baf10:	stp	x20, x23, [x0, #0x10]
1004baf14:	adrp	x0, 7457 ; 0x1021db000
1004baf18:	add	x0, x0, #0x2d8
1004baf1c:	mov	w1, #0x20
1004baf20:	mov	w2, #0x7
1004baf24:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004baf28:	mov	x24, x0
1004baf2c:	adrp	x8, 8 ; 0x1004c2000
1004baf30:	add	x8, x8, #0x104
1004baf34:	stp	x8, x25, [x0, #0x10]
1004baf38:	ldp	x27, x28, [x22, #0x10]
1004baf3c:	add	x25, x27, #0x1
1004baf40:	mov	x0, x20
1004baf44:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004baf48:	mov	x0, x23
1004baf4c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004baf50:	cmp	x27, x28, lsr #1
1004baf54:	b.hs	0x1004bb5a4
1004baf58:	adrp	x8, 6431 ; 0x101dd9000
1004baf5c:	add	x8, x8, #0xd0 ; literal pool for: "Prevent Sleep While Processing"
1004baf60:	sub	x8, x8, #0x20
1004baf64:	orr	x8, x8, #0x8000000000000000
1004baf68:	str	x25, [x22, #0x10]
1004baf6c:	mov	w9, #0x38
1004baf70:	madd	x9, x27, x9, x22
1004baf74:	mov	x10, #0x13
1004baf78:	movk	x10, #0xd000, lsl #48
1004baf7c:	add	x10, x10, #0xb
1004baf80:	stp	x10, x8, [x9, #0x20]
1004baf84:	stp	x21, x26, [x9, #0x30]
1004baf88:	adrp	x8, -1206 ; 0x100004000
1004baf8c:	add	x8, x8, #0xcc
1004baf90:	stp	xzr, x8, [x9, #0x40]
1004baf94:	str	x24, [x9, #0x50]
1004baf98:	mov	x0, x23
1004baf9c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bafa0:	b	0x1004bb090
1004bafa4:	ldr	x8, [x20]
1004bafa8:	ldr	x8, [x8, #0x500]
1004bafac:	blr	x8
1004bafb0:	tst	w0, #0x1
1004bafb4:	mov	w8, #0x9ce2
1004bafb8:	movk	w8, #0x93, lsl #16
1004bafbc:	mov	x28, x20
1004bafc0:	csel	x21, x8, xzr, ne
1004bafc4:	mov	x8, #-0x5d00000000000000
1004bafc8:	csel	x23, x8, xzr, ne
1004bafcc:	adrp	x0, 7456 ; 0x1021da000
1004bafd0:	add	x0, x0, #0x978
1004bafd4:	mov	w1, #0x18
1004bafd8:	mov	w2, #0x7
1004bafdc:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bafe0:	mov	x20, x0
1004bafe4:	add	x0, x0, #0x10
1004bafe8:	ldr	x1, [sp, #0x28]
1004bafec:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004baff0:	adrp	x0, 7457 ; 0x1021db000
1004baff4:	add	x0, x0, #0x350
1004baff8:	mov	w1, #0x20
1004baffc:	mov	w2, #0x7
1004bb000:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bb004:	mov	x25, x0
1004bb008:	stp	x28, x20, [x0, #0x10]
1004bb00c:	adrp	x0, 7456 ; 0x1021db000
1004bb010:	add	x0, x0, #0x378
1004bb014:	mov	w1, #0x20
1004bb018:	mov	w2, #0x7
1004bb01c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bb020:	mov	x24, x0
1004bb024:	adrp	x8, 7 ; 0x1004c2000
1004bb028:	add	x8, x8, #0x208
1004bb02c:	stp	x8, x25, [x0, #0x10]
1004bb030:	ldp	x26, x27, [x22, #0x10]
1004bb034:	add	x25, x26, #0x1
1004bb038:	mov	x0, x28
1004bb03c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bb040:	mov	x0, x20
1004bb044:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bb048:	cmp	x26, x27, lsr #1
1004bb04c:	b.hs	0x1004bb61c
1004bb050:	adrp	x8, 6430 ; 0x101dd9000
1004bb054:	add	x8, x8, #0x110 ; literal pool for: "Keep Awake When Task Running"
1004bb058:	sub	x8, x8, #0x20
1004bb05c:	orr	x8, x8, #0x8000000000000000
1004bb060:	str	x25, [x22, #0x10]
1004bb064:	mov	w9, #0x38
1004bb068:	madd	x9, x26, x9, x22
1004bb06c:	mov	x10, #0x13
1004bb070:	movk	x10, #0xd000, lsl #48
1004bb074:	add	x10, x10, #0x9
1004bb078:	stp	x10, x8, [x9, #0x20]
1004bb07c:	stp	x21, x23, [x9, #0x30]
1004bb080:	adrp	x8, -1207 ; 0x100004000
1004bb084:	add	x8, x8, #0xcc
1004bb088:	stp	xzr, x8, [x9, #0x40]
1004bb08c:	str	x24, [x9, #0x50]
1004bb090:	mov	x0, x20
1004bb094:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bb098:	ldp	x21, x8, [x22, #0x10]
1004bb09c:	lsr	x9, x8, #1
1004bb0a0:	add	x20, x21, #0x1
1004bb0a4:	cmp	x9, x21
1004bb0a8:	b.ls	0x1004bb4ac
1004bb0ac:	str	x20, [x22, #0x10]
1004bb0b0:	mov	w10, #0x38
1004bb0b4:	madd	x10, x21, x10, x22
1004bb0b8:	mov	x11, #-0x1d00000000000000
1004bb0bc:	mov	w12, #0x2d2d
1004bb0c0:	movk	w12, #0x2d, lsl #16
1004bb0c4:	stp	x12, x11, [x10, #0x20]
1004bb0c8:	adrp	x11, -1208 ; 0x100003000
1004bb0cc:	add	x11, x11, #0xf40
1004bb0d0:	stp	xzr, xzr, [x10, #0x30]
1004bb0d4:	stp	xzr, x11, [x10, #0x40]
1004bb0d8:	str	xzr, [x10, #0x50]
1004bb0dc:	add	x23, x21, #0x2
1004bb0e0:	cmp	x9, x23
1004bb0e4:	b.lt	0x1004bb4dc
1004bb0e8:	str	x23, [x22, #0x10]
1004bb0ec:	mov	w8, #0x38
1004bb0f0:	madd	x8, x20, x8, x22
1004bb0f4:	mov	x9, #0x4f4d
1004bb0f8:	movk	x9, #0x5355, lsl #16
1004bb0fc:	movk	x9, #0x45, lsl #32
1004bb100:	mov	x10, #-0x1b00000000000000
1004bb104:	stp	x9, x10, [x8, #0x20]
1004bb108:	adrp	x9, -1208 ; 0x100003000
1004bb10c:	add	x9, x9, #0xf40
1004bb110:	stp	xzr, xzr, [x8, #0x30]
1004bb114:	stp	xzr, x9, [x8, #0x40]
1004bb118:	str	xzr, [x8, #0x50]
1004bb11c:	ldr	x8, [x19]
1004bb120:	ldr	x8, [x8, #0x250]
1004bb124:	mov	x20, x19
1004bb128:	blr	x8
1004bb12c:	mov	x23, x0
1004bb130:	adrp	x0, 7455 ; 0x1021da000
1004bb134:	add	x0, x0, #0x978
1004bb138:	mov	w1, #0x18
1004bb13c:	mov	w2, #0x7
1004bb140:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bb144:	mov	x20, x0
1004bb148:	add	x0, x0, #0x10
1004bb14c:	ldr	x1, [sp, #0x28]
1004bb150:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bb154:	adrp	x0, 7456 ; 0x1021db000
1004bb158:	add	x0, x0, #0x300
1004bb15c:	mov	w1, #0x20
1004bb160:	mov	w2, #0x7
1004bb164:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bb168:	mov	x24, x0
1004bb16c:	stp	x19, x20, [x0, #0x10]
1004bb170:	adrp	x0, 7456 ; 0x1021db000
1004bb174:	add	x0, x0, #0x328
1004bb178:	mov	w1, #0x20
1004bb17c:	mov	w2, #0x7
1004bb180:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bb184:	mov	x21, x0
1004bb188:	adrp	x8, 7 ; 0x1004c2000
1004bb18c:	add	x8, x8, #0x118
1004bb190:	stp	x8, x24, [x0, #0x10]
1004bb194:	ldp	x25, x26, [x22, #0x10]
1004bb198:	add	x24, x25, #0x1
1004bb19c:	mov	x0, x19
1004bb1a0:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bb1a4:	mov	x0, x20
1004bb1a8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bb1ac:	cmp	x25, x26, lsr #1
1004bb1b0:	b.hs	0x1004bb504
1004bb1b4:	tst	w23, #0x1
1004bb1b8:	mov	x8, #-0x5d00000000000000
1004bb1bc:	csel	x8, x8, xzr, ne
1004bb1c0:	mov	w9, #0x9ce2
1004bb1c4:	movk	w9, #0x93, lsl #16
1004bb1c8:	csel	x9, x9, xzr, ne
1004bb1cc:	adrp	x10, 6430 ; 0x101dd9000
1004bb1d0:	add	x10, x10, #0xf0 ; literal pool for: "Allow Mouse Capture"
1004bb1d4:	sub	x10, x10, #0x20
1004bb1d8:	orr	x10, x10, #0x8000000000000000
1004bb1dc:	str	x24, [x22, #0x10]
1004bb1e0:	mov	w11, #0x38
1004bb1e4:	madd	x11, x25, x11, x22
1004bb1e8:	mov	x12, #0x13
1004bb1ec:	movk	x12, #0xd000, lsl #48
1004bb1f0:	stp	x12, x10, [x11, #0x20]
1004bb1f4:	stp	x9, x8, [x11, #0x30]
1004bb1f8:	adrp	x8, -1207 ; 0x100004000
1004bb1fc:	add	x8, x8, #0xcc
1004bb200:	stp	xzr, x8, [x11, #0x40]
1004bb204:	str	x21, [x11, #0x50]
1004bb208:	mov	x0, x20
1004bb20c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bb210:	mov	x0, x19
1004bb214:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bb218:	mov	x0, x22
1004bb21c:	ldp	x29, x30, [sp, #0x80]
1004bb220:	ldp	x20, x19, [sp, #0x70]
1004bb224:	ldp	x22, x21, [sp, #0x60]
1004bb228:	ldp	x24, x23, [sp, #0x50]
1004bb22c:	ldp	x26, x25, [sp, #0x40]
1004bb230:	ldp	x28, x27, [sp, #0x30]
1004bb234:	add	sp, sp, #0x90
1004bb238:	ret
1004bb23c:	cmp	x8, #0x1
1004bb240:	cset	w0, hi
1004bb244:	adrp	x4, 7700 ; 0x1022cf000
1004bb248:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb24c:	mov	x1, x20
1004bb250:	mov	w2, #0x1
1004bb254:	mov	x3, x22
1004bb258:	bl	0x1004bfb6c
1004bb25c:	mov	x22, x0
1004bb260:	b	0x1004b9f7c
1004bb264:	cmp	x26, #0x1
1004bb268:	cset	w0, hi
1004bb26c:	adrp	x4, 7700 ; 0x1022cf000
1004bb270:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb274:	mov	x1, x25
1004bb278:	mov	w2, #0x1
1004bb27c:	mov	x3, x22
1004bb280:	bl	0x1004bfb6c
1004bb284:	mov	x22, x0
1004bb288:	b	0x1004ba05c
1004bb28c:	cmp	x28, #0x1
1004bb290:	cset	w0, hi
1004bb294:	adrp	x4, 7700 ; 0x1022cf000
1004bb298:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb29c:	mov	x1, x25
1004bb2a0:	mov	w2, #0x1
1004bb2a4:	mov	x3, x22
1004bb2a8:	bl	0x1004bfb6c
1004bb2ac:	mov	x22, x0
1004bb2b0:	b	0x1004ba13c
1004bb2b4:	cmp	x28, #0x1
1004bb2b8:	cset	w0, hi
1004bb2bc:	adrp	x4, 7700 ; 0x1022cf000
1004bb2c0:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb2c4:	mov	x1, x25
1004bb2c8:	mov	w2, #0x1
1004bb2cc:	mov	x3, x22
1004bb2d0:	bl	0x1004bfb6c
1004bb2d4:	mov	x22, x0
1004bb2d8:	b	0x1004ba234
1004bb2dc:	cmp	x8, #0x1
1004bb2e0:	cset	w0, hi
1004bb2e4:	adrp	x4, 7700 ; 0x1022cf000
1004bb2e8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb2ec:	mov	x1, x20
1004bb2f0:	mov	w2, #0x1
1004bb2f4:	mov	x3, x22
1004bb2f8:	bl	0x1004bfb6c
1004bb2fc:	mov	x22, x0
1004bb300:	ldr	x8, [x0, #0x18]
1004bb304:	lsr	x9, x8, #1
1004bb308:	b	0x1004ba28c
1004bb30c:	cmp	x8, #0x1
1004bb310:	cset	w0, hi
1004bb314:	adrp	x4, 7700 ; 0x1022cf000
1004bb318:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb31c:	mov	x1, x24
1004bb320:	mov	w2, #0x1
1004bb324:	mov	x3, x22
1004bb328:	bl	0x1004bfb6c
1004bb32c:	mov	x22, x0
1004bb330:	b	0x1004ba2c8
1004bb334:	cmp	x26, #0x1
1004bb338:	cset	w0, hi
1004bb33c:	adrp	x4, 7700 ; 0x1022cf000
1004bb340:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb344:	mov	x1, x25
1004bb348:	mov	w2, #0x1
1004bb34c:	mov	x3, x22
1004bb350:	bl	0x1004bfb6c
1004bb354:	mov	x22, x0
1004bb358:	b	0x1004ba3b4
1004bb35c:	cmp	x27, #0x1
1004bb360:	cset	w0, hi
1004bb364:	adrp	x4, 7700 ; 0x1022cf000
1004bb368:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb36c:	mov	x1, x25
1004bb370:	mov	w2, #0x1
1004bb374:	mov	x3, x22
1004bb378:	bl	0x1004bfb6c
1004bb37c:	mov	x22, x0
1004bb380:	b	0x1004ba494
1004bb384:	cmp	x28, #0x1
1004bb388:	cset	w0, hi
1004bb38c:	adrp	x4, 7700 ; 0x1022cf000
1004bb390:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb394:	mov	x1, x25
1004bb398:	mov	w2, #0x1
1004bb39c:	mov	x3, x22
1004bb3a0:	bl	0x1004bfb6c
1004bb3a4:	mov	x22, x0
1004bb3a8:	b	0x1004ba588
1004bb3ac:	cmp	x27, #0x1
1004bb3b0:	cset	w0, hi
1004bb3b4:	adrp	x4, 7700 ; 0x1022cf000
1004bb3b8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb3bc:	mov	x1, x25
1004bb3c0:	mov	w2, #0x1
1004bb3c4:	mov	x3, x22
1004bb3c8:	bl	0x1004bfb6c
1004bb3cc:	mov	x22, x0
1004bb3d0:	b	0x1004ba678
1004bb3d4:	cmp	x27, #0x1
1004bb3d8:	cset	w0, hi
1004bb3dc:	adrp	x4, 7700 ; 0x1022cf000
1004bb3e0:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb3e4:	mov	x1, x25
1004bb3e8:	mov	w2, #0x1
1004bb3ec:	mov	x3, x22
1004bb3f0:	bl	0x1004bfb6c
1004bb3f4:	mov	x22, x0
1004bb3f8:	b	0x1004ba76c
1004bb3fc:	cmp	x8, #0x1
1004bb400:	cset	w0, hi
1004bb404:	adrp	x4, 7700 ; 0x1022cf000
1004bb408:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb40c:	mov	x1, x20
1004bb410:	mov	w2, #0x1
1004bb414:	mov	x3, x22
1004bb418:	bl	0x1004bfb6c
1004bb41c:	mov	x22, x0
1004bb420:	ldr	x8, [x0, #0x18]
1004bb424:	lsr	x9, x8, #1
1004bb428:	b	0x1004ba7c8
1004bb42c:	cmp	x8, #0x1
1004bb430:	cset	w0, hi
1004bb434:	adrp	x4, 7700 ; 0x1022cf000
1004bb438:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb43c:	mov	x1, x24
1004bb440:	mov	w2, #0x1
1004bb444:	mov	x3, x22
1004bb448:	bl	0x1004bfb6c
1004bb44c:	mov	x22, x0
1004bb450:	b	0x1004ba804
1004bb454:	cmp	x8, #0x1
1004bb458:	cset	w0, hi
1004bb45c:	adrp	x4, 7700 ; 0x1022cf000
1004bb460:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb464:	mov	x1, x23
1004bb468:	mov	w2, #0x1
1004bb46c:	mov	x3, x22
1004bb470:	bl	0x1004bfb6c
1004bb474:	mov	x22, x0
1004bb478:	ldr	x8, [x0, #0x18]
1004bb47c:	lsr	x9, x8, #1
1004bb480:	b	0x1004bae24
1004bb484:	cmp	x8, #0x1
1004bb488:	cset	w0, hi
1004bb48c:	adrp	x4, 7700 ; 0x1022cf000
1004bb490:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb494:	mov	x1, x25
1004bb498:	mov	w2, #0x1
1004bb49c:	mov	x3, x22
1004bb4a0:	bl	0x1004bfb6c
1004bb4a4:	mov	x22, x0
1004bb4a8:	b	0x1004bae60
1004bb4ac:	cmp	x8, #0x1
1004bb4b0:	cset	w0, hi
1004bb4b4:	adrp	x4, 7700 ; 0x1022cf000
1004bb4b8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb4bc:	mov	x1, x20
1004bb4c0:	mov	w2, #0x1
1004bb4c4:	mov	x3, x22
1004bb4c8:	bl	0x1004bfb6c
1004bb4cc:	mov	x22, x0
1004bb4d0:	ldr	x8, [x0, #0x18]
1004bb4d4:	lsr	x9, x8, #1
1004bb4d8:	b	0x1004bb0ac
1004bb4dc:	cmp	x8, #0x1
1004bb4e0:	cset	w0, hi
1004bb4e4:	adrp	x4, 7700 ; 0x1022cf000
1004bb4e8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb4ec:	mov	x1, x23
1004bb4f0:	mov	w2, #0x1
1004bb4f4:	mov	x3, x22
1004bb4f8:	bl	0x1004bfb6c
1004bb4fc:	mov	x22, x0
1004bb500:	b	0x1004bb0e8
1004bb504:	cmp	x26, #0x1
1004bb508:	cset	w0, hi
1004bb50c:	adrp	x4, 7700 ; 0x1022cf000
1004bb510:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb514:	mov	x1, x24
1004bb518:	mov	w2, #0x1
1004bb51c:	mov	x3, x22
1004bb520:	bl	0x1004bfb6c
1004bb524:	mov	x22, x0
1004bb528:	b	0x1004bb1b4
1004bb52c:	cmp	x23, #0x1
1004bb530:	cset	w0, hi
1004bb534:	adrp	x4, 7700 ; 0x1022cf000
1004bb538:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb53c:	mov	x1, x27
1004bb540:	mov	w2, #0x1
1004bb544:	mov	x3, x22
1004bb548:	bl	0x1004bfb6c
1004bb54c:	mov	x22, x0
1004bb550:	b	0x1004ba940
1004bb554:	cmp	x28, #0x1
1004bb558:	cset	w0, hi
1004bb55c:	adrp	x4, 7700 ; 0x1022cf000
1004bb560:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb564:	mov	x1, x27
1004bb568:	mov	w2, #0x1
1004bb56c:	mov	x3, x22
1004bb570:	bl	0x1004bfb6c
1004bb574:	mov	x22, x0
1004bb578:	b	0x1004baa6c
1004bb57c:	cmp	x28, #0x1
1004bb580:	cset	w0, hi
1004bb584:	adrp	x4, 7700 ; 0x1022cf000
1004bb588:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb58c:	mov	x1, x27
1004bb590:	mov	w2, #0x1
1004bb594:	mov	x3, x22
1004bb598:	bl	0x1004bfb6c
1004bb59c:	mov	x22, x0
1004bb5a0:	b	0x1004baba4
1004bb5a4:	cmp	x28, #0x1
1004bb5a8:	cset	w0, hi
1004bb5ac:	adrp	x4, 7700 ; 0x1022cf000
1004bb5b0:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb5b4:	mov	x1, x25
1004bb5b8:	mov	w2, #0x1
1004bb5bc:	mov	x3, x22
1004bb5c0:	bl	0x1004bfb6c
1004bb5c4:	mov	x22, x0
1004bb5c8:	b	0x1004baf58
1004bb5cc:	cmp	x23, #0x1
1004bb5d0:	cset	w0, hi
1004bb5d4:	adrp	x4, 7700 ; 0x1022cf000
1004bb5d8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb5dc:	mov	x1, x27
1004bb5e0:	mov	w2, #0x1
1004bb5e4:	mov	x3, x22
1004bb5e8:	bl	0x1004bfb6c
1004bb5ec:	mov	x22, x0
1004bb5f0:	b	0x1004bac94
1004bb5f4:	cmp	x28, #0x1
1004bb5f8:	cset	w0, hi
1004bb5fc:	adrp	x4, 7700 ; 0x1022cf000
1004bb600:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb604:	mov	x1, x27
1004bb608:	mov	w2, #0x1
1004bb60c:	mov	x3, x22
1004bb610:	bl	0x1004bfb6c
1004bb614:	mov	x22, x0
1004bb618:	b	0x1004badd0
1004bb61c:	cmp	x27, #0x1
1004bb620:	cset	w0, hi
1004bb624:	adrp	x4, 7700 ; 0x1022cf000
1004bb628:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bb62c:	mov	x1, x25
1004bb630:	mov	w2, #0x1
1004bb634:	mov	x3, x22
1004bb638:	bl	0x1004bfb6c
1004bb63c:	mov	x22, x0
1004bb640:	b	0x1004bb050
1004bb644:	sub	sp, sp, #0x70
1004bb648:	stp	x24, x23, [sp, #0x30]
1004bb64c:	stp	x22, x21, [sp, #0x40]
1004bb650:	stp	x20, x19, [sp, #0x50]
1004bb654:	stp	x29, x30, [sp, #0x60]
1004bb658:	add	x29, sp, #0x60
1004bb65c:	mov	x22, x20
1004bb660:	mov	x19, x0
1004bb664:	adrp	x8, 7906 ; 0x10239d000
1004bb668:	ldr	x8, [x8, #0x250]
1004bb66c:	add	x0, x20, x8
1004bb670:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004bb674:	cbz	x0, 0x1004bb8cc
1004bb678:	ldr	x8, [x0]
1004bb67c:	adrp	x9, 7700 ; 0x1022cf000
1004bb680:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004bb684:	ldr	x9, [x9]
1004bb688:	and	x8, x9, x8
1004bb68c:	ldr	x8, [x8, #0x278]
1004bb690:	mov	x20, x0
1004bb694:	mov	x21, x0
1004bb698:	blr	x8
1004bb69c:	mov	x20, x0
1004bb6a0:	mov	x0, x21
1004bb6a4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bb6a8:	cbz	x20, 0x1004bb8cc
1004bb6ac:	adrp	x8, 7787 ; 0x102326000
1004bb6b0:	ldr	x0, [x8, #0xaa8] ; Objc class ref: _OBJC_CLASS_$_NSAlert
1004bb6b4:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004bb6b8:	bl	0x101ace2c0 ; selector init
1004bb6bc:	mov	x21, x0
1004bb6c0:	adrp	x8, 6429 ; 0x101dd8000
1004bb6c4:	add	x8, x8, #0xf70 ; literal pool for: "Keep macOS Awake"
1004bb6c8:	sub	x8, x8, #0x20
1004bb6cc:	mov	x24, #0x10
1004bb6d0:	movk	x24, #0xd000, lsl #48
1004bb6d4:	orr	x1, x8, #0x8000000000000000
1004bb6d8:	mov	x0, #0x10
1004bb6dc:	movk	x0, #0xd000, lsl #48
1004bb6e0:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004bb6e4:	mov	x23, x0
1004bb6e8:	mov	x0, x21
1004bb6ec:	mov	x2, x23
1004bb6f0:	bl	0x101ad3660 ; selector setMessageText:
1004bb6f4:	mov	x0, x23
1004bb6f8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bb6fc:	adrp	x8, 6429 ; 0x101dd8000
1004bb700:	add	x8, x8, #0xf90 ; literal pool for: "Prevent system sleep while tasks run in this tab."
1004bb704:	sub	x8, x8, #0x20
1004bb708:	mov	w9, #0x21
1004bb70c:	orr	x0, x24, x9
1004bb710:	orr	x1, x8, #0x8000000000000000
1004bb714:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004bb718:	mov	x23, x0
1004bb71c:	mov	x0, x21
1004bb720:	mov	x2, x23
1004bb724:	bl	0x101ad30c0 ; selector setInformativeText:
1004bb728:	mov	x0, x23
1004bb72c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bb730:	mov	x0, #0x6f46
1004bb734:	movk	x0, #0x2072, lsl #16
1004bb738:	movk	x0, #0x6854, lsl #32
1004bb73c:	movk	x0, #0x7369, lsl #48
1004bb740:	mov	x1, #0x5420
1004bb744:	movk	x1, #0x7361, lsl #16
1004bb748:	movk	x1, #0x6b, lsl #32
1004bb74c:	movk	x1, #0xed00, lsl #48
1004bb750:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004bb754:	mov	x23, x0
1004bb758:	mov	x0, x21
1004bb75c:	mov	x2, x23
1004bb760:	bl	0x101acb200 ; selector addButtonWithTitle:
1004bb764:	mov	x29, x29
1004bb768:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bb76c:	mov	x24, x0
1004bb770:	mov	x0, x23
1004bb774:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bb778:	mov	x0, x24
1004bb77c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bb780:	mov	x0, #0x6f46
1004bb784:	movk	x0, #0x2072, lsl #16
1004bb788:	movk	x0, #0x6c41, lsl #32
1004bb78c:	movk	x0, #0x206c, lsl #48
1004bb790:	mov	x1, #0x6154
1004bb794:	movk	x1, #0x6b73, lsl #16
1004bb798:	movk	x1, #0x73, lsl #32
1004bb79c:	movk	x1, #0xed00, lsl #48
1004bb7a0:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004bb7a4:	mov	x23, x0
1004bb7a8:	mov	x0, x21
1004bb7ac:	mov	x2, x23
1004bb7b0:	bl	0x101acb200 ; selector addButtonWithTitle:
1004bb7b4:	mov	x29, x29
1004bb7b8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bb7bc:	mov	x24, x0
1004bb7c0:	mov	x0, x23
1004bb7c4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bb7c8:	mov	x0, x24
1004bb7cc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bb7d0:	mov	x0, #0x6143
1004bb7d4:	movk	x0, #0x636e, lsl #16
1004bb7d8:	movk	x0, #0x6c65, lsl #32
1004bb7dc:	mov	x1, #-0x1a00000000000000
1004bb7e0:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004bb7e4:	mov	x23, x0
1004bb7e8:	mov	x0, x21
1004bb7ec:	mov	x2, x23
1004bb7f0:	bl	0x101acb200 ; selector addButtonWithTitle:
1004bb7f4:	mov	x29, x29
1004bb7f8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bb7fc:	mov	x24, x0
1004bb800:	mov	x0, x23
1004bb804:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bb808:	mov	x0, x24
1004bb80c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bb810:	adrp	x0, 7455 ; 0x1021da000
1004bb814:	add	x0, x0, #0x978
1004bb818:	mov	w1, #0x18
1004bb81c:	mov	w2, #0x7
1004bb820:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bb824:	mov	x23, x0
1004bb828:	add	x0, x0, #0x10
1004bb82c:	mov	x1, x22
1004bb830:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bb834:	adrp	x0, 7455 ; 0x1021da000
1004bb838:	add	x0, x0, #0xf18
1004bb83c:	mov	w1, #0x20
1004bb840:	mov	w2, #0x7
1004bb844:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bb848:	stp	x19, x23, [x0, #0x10]
1004bb84c:	adrp	x8, 6 ; 0x1004c1000
1004bb850:	add	x8, x8, #0x64c
1004bb854:	stp	x8, x0, [sp, #0x20]
1004bb858:	adrp	x8, 7696 ; 0x1022cb000
1004bb85c:	ldr	x8, [x8, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1004bb860:	str	x8, [sp]
1004bb864:	adrp	x8, 5670 ; 0x101ae1000
1004bb868:	ldr	d0, [x8]
1004bb86c:	str	d0, [sp, #0x8]
1004bb870:	adrp	x8, -1098 ; 0x100071000
1004bb874:	add	x8, x8, #0xb1c
1004bb878:	adrp	x9, 7455 ; 0x1021da000
1004bb87c:	add	x9, x9, #0xf30
1004bb880:	stp	x8, x9, [sp, #0x10]
1004bb884:	mov	x0, sp
1004bb888:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004bb88c:	mov	x22, x0
1004bb890:	ldr	x23, [sp, #0x28]
1004bb894:	mov	x0, x19
1004bb898:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bb89c:	mov	x0, x23
1004bb8a0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bb8a4:	mov	x0, x21
1004bb8a8:	mov	x2, x20
1004bb8ac:	mov	x3, x22
1004bb8b0:	bl	0x101acbb80 ; selector beginSheetModalForWindow:completionHandler:
1004bb8b4:	mov	x0, x22
1004bb8b8:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004bb8bc:	mov	x0, x20
1004bb8c0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bb8c4:	mov	x0, x21
1004bb8c8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bb8cc:	ldp	x29, x30, [sp, #0x60]
1004bb8d0:	ldp	x20, x19, [sp, #0x50]
1004bb8d4:	ldp	x22, x21, [sp, #0x40]
1004bb8d8:	ldp	x24, x23, [sp, #0x30]
1004bb8dc:	add	sp, sp, #0x70
1004bb8e0:	ret
1004bb8e4:	stp	x28, x27, [sp, #-0x60]!
1004bb8e8:	stp	x26, x25, [sp, #0x10]
1004bb8ec:	stp	x24, x23, [sp, #0x20]
1004bb8f0:	stp	x22, x21, [sp, #0x30]
1004bb8f4:	stp	x20, x19, [sp, #0x40]
1004bb8f8:	stp	x29, x30, [sp, #0x50]
1004bb8fc:	add	x29, sp, #0x50
1004bb900:	mov	x19, x8
1004bb904:	adrp	x0, 7814 ; 0x102341000
1004bb908:	add	x0, x0, #0x4a0
1004bb90c:	adrp	x1, 5670 ; 0x101ae1000
1004bb910:	add	x1, x1, #0xc60
1004bb914:	bl	0x100003c4c
1004bb918:	ldur	x8, [x0, #-0x8]
1004bb91c:	ldr	x9, [x8, #0x40]
1004bb920:	add	x8, x9, #0xf
1004bb924:	and	x8, x8, #0xfffffffffffffff0
1004bb928:	adrp	x16, 7696 ; 0x1022cb000
1004bb92c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004bb930:	blr	x16
1004bb934:	mov	x9, sp
1004bb938:	sub	x21, x9, x8
1004bb93c:	mov	sp, x21
1004bb940:	adrp	x8, 7906 ; 0x10239d000
1004bb944:	ldr	x8, [x8, #0x248]
1004bb948:	add	x0, x20, x8
1004bb94c:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004bb950:	cbz	x0, 0x1004bbadc
1004bb954:	mov	x20, x0
1004bb958:	ldr	x8, [x0]
1004bb95c:	ldr	x8, [x8, #0x260]
1004bb960:	blr	x8
1004bb964:	mov	x22, x0
1004bb968:	mov	x0, x20
1004bb96c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bb970:	cbz	x22, 0x1004bbadc
1004bb974:	ldr	x20, [x22, #0x18]
1004bb978:	ldr	x8, [x20]
1004bb97c:	ldr	x8, [x8, #0x118]
1004bb980:	blr	x8
1004bb984:	mov	x24, x0
1004bb988:	mov	x23, x1
1004bb98c:	ldr	x8, [x20]
1004bb990:	ldr	x8, [x8, #0x90]
1004bb994:	blr	x8
1004bb998:	mov	x20, x0
1004bb99c:	ldr	x8, [x0, #0x10]
1004bb9a0:	cbz	x8, 0x1004bbb1c
1004bb9a4:	mov	x0, x24
1004bb9a8:	mov	x1, x23
1004bb9ac:	bl	0x1000240a8
1004bb9b0:	tbz	w1, #0x0, 0x1004bbb1c
1004bb9b4:	mov	x24, x0
1004bb9b8:	ldr	x26, [x20, #0x38]
1004bb9bc:	mov	x0, #0x0
1004bb9c0:	bl	0x10068c794
1004bb9c4:	mov	x25, x0
1004bb9c8:	adrp	x2, 465 ; 0x10068c000
1004bb9cc:	add	x2, x2, #0x794
1004bb9d0:	ldur	x27, [x0, #-0x8]
1004bb9d4:	ldr	x8, [x27, #0x48]
1004bb9d8:	madd	x0, x8, x24, x26
1004bb9dc:	mov	x1, x21
1004bb9e0:	bl	0x1000e73b0
1004bb9e4:	mov	x0, x20
1004bb9e8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bb9ec:	mov	x0, x22
1004bb9f0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bb9f4:	mov	x0, x23
1004bb9f8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bb9fc:	ldr	x8, [x27, #0x38]
1004bba00:	mov	x0, x21
1004bba04:	mov	w1, #0x0
1004bba08:	mov	w2, #0x1
1004bba0c:	mov	x3, x25
1004bba10:	blr	x8
1004bba14:	mov	x0, x21
1004bba18:	mov	x1, x25
1004bba1c:	bl	0x101aca78c ; symbol stub for: _swift_getEnumCaseMultiPayload
1004bba20:	cmp	w0, #0x1
1004bba24:	b.ne	0x1004bbb58
1004bba28:	mov	x0, #0x0
1004bba2c:	bl	0x10068c76c
1004bba30:	ldrsw	x8, [x0, #0x14]
1004bba34:	ldr	x20, [x21, x8]
1004bba38:	mov	x0, #0x0
1004bba3c:	bl	0x1000e5480
1004bba40:	mov	x1, x0
1004bba44:	mov	x0, x20
1004bba48:	bl	0x101aca6fc ; symbol stub for: _swift_dynamicCastClass
1004bba4c:	cbz	x0, 0x1004bbb58
1004bba50:	mov	x22, x0
1004bba54:	mov	x0, #0x0
1004bba58:	bl	0x1004c1634
1004bba5c:	mov	x23, x0
1004bba60:	ldrsw	x24, [x0, #0x14]
1004bba64:	mov	x0, #0x0
1004bba68:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004bba6c:	mov	x2, x0
1004bba70:	ldur	x8, [x0, #-0x8]
1004bba74:	ldr	x8, [x8, #0x10]
1004bba78:	add	x0, x19, x24
1004bba7c:	mov	x1, x21
1004bba80:	blr	x8
1004bba84:	ldrsw	x8, [x23, #0x18]
1004bba88:	adrp	x2, 465 ; 0x10068c000
1004bba8c:	add	x2, x2, #0x76c
1004bba90:	add	x1, x19, x8
1004bba94:	mov	x0, x21
1004bba98:	bl	0x1000e73b0
1004bba9c:	str	x22, [x19]
1004bbaa0:	mov	x0, x20
1004bbaa4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bbaa8:	adrp	x1, 7814 ; 0x102341000
1004bbaac:	add	x1, x1, #0x4a0
1004bbab0:	adrp	x2, 5670 ; 0x101ae1000
1004bbab4:	add	x2, x2, #0xc60
1004bbab8:	mov	x0, x21
1004bbabc:	bl	0x10002d870
1004bbac0:	ldur	x8, [x23, #-0x8]
1004bbac4:	ldr	x8, [x8, #0x38]
1004bbac8:	mov	x0, x19
1004bbacc:	mov	w1, #0x0
1004bbad0:	mov	w2, #0x1
1004bbad4:	mov	x3, x23
1004bbad8:	b	0x1004bbb90
1004bbadc:	mov	x0, #0x0
1004bbae0:	bl	0x1004c1634
1004bbae4:	mov	x3, x0
1004bbae8:	ldur	x8, [x0, #-0x8]
1004bbaec:	ldr	x4, [x8, #0x38]
1004bbaf0:	mov	x0, x19
1004bbaf4:	mov	w1, #0x1
1004bbaf8:	mov	w2, #0x1
1004bbafc:	sub	sp, x29, #0x50
1004bbb00:	ldp	x29, x30, [sp, #0x50]
1004bbb04:	ldp	x20, x19, [sp, #0x40]
1004bbb08:	ldp	x22, x21, [sp, #0x30]
1004bbb0c:	ldp	x24, x23, [sp, #0x20]
1004bbb10:	ldp	x26, x25, [sp, #0x10]
1004bbb14:	ldp	x28, x27, [sp], #0x60
1004bbb18:	br	x4
1004bbb1c:	mov	x0, x22
1004bbb20:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bbb24:	mov	x0, x20
1004bbb28:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bbb2c:	mov	x0, x23
1004bbb30:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bbb34:	mov	x0, #0x0
1004bbb38:	bl	0x10068c794
1004bbb3c:	mov	x3, x0
1004bbb40:	ldur	x8, [x0, #-0x8]
1004bbb44:	ldr	x8, [x8, #0x38]
1004bbb48:	mov	x0, x21
1004bbb4c:	mov	w1, #0x1
1004bbb50:	mov	w2, #0x1
1004bbb54:	blr	x8
1004bbb58:	adrp	x1, 7814 ; 0x102341000
1004bbb5c:	add	x1, x1, #0x4a0
1004bbb60:	adrp	x2, 5670 ; 0x101ae1000
1004bbb64:	add	x2, x2, #0xc60
1004bbb68:	mov	x0, x21
1004bbb6c:	bl	0x10002d870
1004bbb70:	mov	x0, #0x0
1004bbb74:	bl	0x1004c1634
1004bbb78:	mov	x3, x0
1004bbb7c:	ldur	x8, [x0, #-0x8]
1004bbb80:	ldr	x8, [x8, #0x38]
1004bbb84:	mov	x0, x19
1004bbb88:	mov	w1, #0x1
1004bbb8c:	mov	w2, #0x1
1004bbb90:	blr	x8
1004bbb94:	sub	sp, x29, #0x50
1004bbb98:	ldp	x29, x30, [sp, #0x50]
1004bbb9c:	ldp	x20, x19, [sp, #0x40]
1004bbba0:	ldp	x22, x21, [sp, #0x30]
1004bbba4:	ldp	x24, x23, [sp, #0x20]
1004bbba8:	ldp	x26, x25, [sp, #0x10]
1004bbbac:	ldp	x28, x27, [sp], #0x60
1004bbbb0:	ret
1004bbbb4:	stp	d11, d10, [sp, #-0x80]!
1004bbbb8:	stp	d9, d8, [sp, #0x10]
1004bbbbc:	stp	x28, x27, [sp, #0x20]
1004bbbc0:	stp	x26, x25, [sp, #0x30]
1004bbbc4:	stp	x24, x23, [sp, #0x40]
1004bbbc8:	stp	x22, x21, [sp, #0x50]
1004bbbcc:	stp	x20, x19, [sp, #0x60]
1004bbbd0:	stp	x29, x30, [sp, #0x70]
1004bbbd4:	add	x29, sp, #0x70
1004bbbd8:	sub	sp, sp, #0x70
1004bbbdc:	mov	x19, x20
1004bbbe0:	stur	w2, [x29, #-0x9c]
1004bbbe4:	mov	x22, x1
1004bbbe8:	mov.16b	v8, v0
1004bbbec:	mov	x28, x0
1004bbbf0:	mov	x0, #0x0
1004bbbf4:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004bbbf8:	mov	x25, x0
1004bbbfc:	ldur	x21, [x0, #-0x8]
1004bbc00:	ldr	x27, [x21, #0x40]
1004bbc04:	mov	x9, x27
1004bbc08:	adrp	x16, 7696 ; 0x1022cb000
1004bbc0c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004bbc10:	blr	x16
1004bbc14:	mov	x8, sp
1004bbc18:	add	x9, x27, #0xf
1004bbc1c:	and	x12, x9, #0xfffffffffffffff0
1004bbc20:	sub	x8, x8, x12
1004bbc24:	stur	x8, [x29, #-0xd0]
1004bbc28:	mov	sp, x8
1004bbc2c:	mov	x9, x27
1004bbc30:	adrp	x16, 7696 ; 0x1022cb000
1004bbc34:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004bbc38:	blr	x16
1004bbc3c:	mov	x8, sp
1004bbc40:	sub	x8, x8, x12
1004bbc44:	stur	x8, [x29, #-0xb8]
1004bbc48:	mov	sp, x8
1004bbc4c:	mov	x9, x27
1004bbc50:	adrp	x16, 7696 ; 0x1022cb000
1004bbc54:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004bbc58:	blr	x16
1004bbc5c:	mov	x8, sp
1004bbc60:	sub	x23, x8, x12
1004bbc64:	mov	sp, x23
1004bbc68:	mov	x0, x28
1004bbc6c:	mov.16b	v0, v8
1004bbc70:	mov	w1, #0x4946
1004bbc74:	movk	w1, #0x454c, lsl #16
1004bbc78:	mov	x2, #-0x1c00000000000000
1004bbc7c:	bl	0x1004bfed0
1004bbc80:	mov	x0, x28
1004bbc84:	mov	x1, x22
1004bbc88:	bl	0x1004bc834
1004bbc8c:	mov.16b	v8, v0
1004bbc90:	adrp	x0, 7455 ; 0x1021da000
1004bbc94:	add	x0, x0, #0x978
1004bbc98:	mov	w1, #0x18
1004bbc9c:	mov	w2, #0x7
1004bbca0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bbca4:	mov	x26, x0
1004bbca8:	add	x0, x0, #0x10
1004bbcac:	mov	x1, x20
1004bbcb0:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bbcb4:	ldr	x8, [x21, #0x10]
1004bbcb8:	mov	x0, x23
1004bbcbc:	stp	x8, x22, [x29, #-0x98]
1004bbcc0:	mov	x1, x22
1004bbcc4:	mov	x2, x25
1004bbcc8:	blr	x8
1004bbccc:	ldrb	w9, [x21, #0x50]
1004bbcd0:	add	x8, x9, #0x18
1004bbcd4:	bic	x22, x8, x9
1004bbcd8:	adrp	x0, 7455 ; 0x1021da000
1004bbcdc:	add	x0, x0, #0xdb0
1004bbce0:	add	x1, x22, x27
1004bbce4:	stur	x9, [x29, #-0xb0]
1004bbce8:	orr	x2, x9, #0x7
1004bbcec:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bbcf0:	mov	x24, x0
1004bbcf4:	str	x26, [x0, #0x10]
1004bbcf8:	ldr	x8, [x21, #0x20]
1004bbcfc:	add	x0, x0, x22
1004bbd00:	mov	x1, x23
1004bbd04:	mov	x2, x25
1004bbd08:	stur	x8, [x29, #-0xc0]
1004bbd0c:	blr	x8
1004bbd10:	mov	x0, #0x0
1004bbd14:	bl	0x1004aede4
1004bbd18:	mov	x20, x0
1004bbd1c:	mov	x0, x26
1004bbd20:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bbd24:	mov	x8, #0x800000000000
1004bbd28:	movk	x8, #0x4071, lsl #48
1004bbd2c:	fmov	d2, x8
1004bbd30:	fmov	d9, #28.00000000
1004bbd34:	movi.2d	v0, #0000000000000000
1004bbd38:	fmov	d3, #28.00000000
1004bbd3c:	mov.16b	v1, v8
1004bbd40:	stur	x20, [x29, #-0xc8]
1004bbd44:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004bbd48:	mov	x23, x0
1004bbd4c:	ldr	x8, [x0]
1004bbd50:	adrp	x9, 7700 ; 0x1022cf000
1004bbd54:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004bbd58:	ldr	x9, [x9]
1004bbd5c:	and	x8, x9, x8
1004bbd60:	ldr	x8, [x8, #0x140]
1004bbd64:	str	x24, [sp, #-0x10]!
1004bbd68:	adrp	x7, 6 ; 0x1004c1000
1004bbd6c:	add	x7, x7, #0x10c
1004bbd70:	mov	x0, #0x6f43
1004bbd74:	movk	x0, #0x7970, lsl #16
1004bbd78:	movk	x0, #0x5020, lsl #32
1004bbd7c:	movk	x0, #0x7461, lsl #48
1004bbd80:	mov	x1, #0x68
1004bbd84:	movk	x1, #0xe900, lsl #48
1004bbd88:	mov	x2, #0x0
1004bbd8c:	mov	x3, #0x0
1004bbd90:	mov	w4, #0x0
1004bbd94:	mov	x5, #0x0
1004bbd98:	mov	w6, #0x1
1004bbd9c:	mov	x20, x23
1004bbda0:	blr	x8
1004bbda4:	add	sp, sp, #0x10
1004bbda8:	stur	x28, [x29, #-0xa8]
1004bbdac:	mov	x0, x28
1004bbdb0:	mov	x2, x23
1004bbdb4:	bl	0x101acb460 ; selector addSubview:
1004bbdb8:	adrp	x8, 7906 ; 0x10239d000
1004bbdbc:	ldr	x28, [x8, #0x270]
1004bbdc0:	add	x0, x19, x28
1004bbdc4:	sub	x1, x29, #0x88
1004bbdc8:	mov	w2, #0x21
1004bbdcc:	mov	x3, #0x0
1004bbdd0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bbdd4:	add	x20, x19, x28
1004bbdd8:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004bbddc:	ldr	x8, [x19, x28]
1004bbde0:	and	x8, x8, #0xffffffffffffff8
1004bbde4:	ldp	x21, x8, [x8, #0x10]
1004bbde8:	cmp	x21, x8, lsr #1
1004bbdec:	b.hs	0x1004bc134
1004bbdf0:	mov	x0, x23
1004bbdf4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bbdf8:	mov	x23, x0
1004bbdfc:	add	x20, x19, x28
1004bbe00:	mov	x0, x21
1004bbe04:	mov	x1, x23
1004bbe08:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004bbe0c:	sub	x0, x29, #0x88
1004bbe10:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004bbe14:	mov	x0, x26
1004bbe18:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bbe1c:	mov	x0, x23
1004bbe20:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bbe24:	mov	x0, x24
1004bbe28:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bbe2c:	fadd	d8, d8, d9
1004bbe30:	adrp	x8, 6429 ; 0x101dd8000
1004bbe34:	add	x8, x8, #0xf30 ; literal pool for: "Copy Relative Path"
1004bbe38:	sub	x21, x8, #0x20
1004bbe3c:	adrp	x0, 7455 ; 0x1021da000
1004bbe40:	add	x0, x0, #0x978
1004bbe44:	mov	w1, #0x18
1004bbe48:	mov	w2, #0x7
1004bbe4c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bbe50:	mov	x26, x0
1004bbe54:	add	x0, x0, #0x10
1004bbe58:	mov	x1, x19
1004bbe5c:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bbe60:	ldur	x20, [x29, #-0xb8]
1004bbe64:	mov	x0, x20
1004bbe68:	ldp	x8, x1, [x29, #-0x98]
1004bbe6c:	mov	x2, x25
1004bbe70:	blr	x8
1004bbe74:	adrp	x0, 7455 ; 0x1021da000
1004bbe78:	add	x0, x0, #0xdd8
1004bbe7c:	stur	x27, [x29, #-0xd8]
1004bbe80:	add	x1, x22, x27
1004bbe84:	mov	x23, x25
1004bbe88:	ldur	x25, [x29, #-0xb0]
1004bbe8c:	orr	x2, x25, #0x7
1004bbe90:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bbe94:	mov	x24, x0
1004bbe98:	str	x26, [x0, #0x10]
1004bbe9c:	add	x0, x0, x22
1004bbea0:	mov	x1, x20
1004bbea4:	stur	x23, [x29, #-0xb8]
1004bbea8:	mov	x2, x23
1004bbeac:	ldur	x27, [x29, #-0xc0]
1004bbeb0:	blr	x27
1004bbeb4:	mov	x0, x26
1004bbeb8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bbebc:	mov	x8, #0x800000000000
1004bbec0:	movk	x8, #0x4071, lsl #48
1004bbec4:	fmov	d2, x8
1004bbec8:	movi.2d	v0, #0000000000000000
1004bbecc:	fmov	d3, #28.00000000
1004bbed0:	mov.16b	v1, v8
1004bbed4:	ldur	x20, [x29, #-0xc8]
1004bbed8:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004bbedc:	mov	x23, x0
1004bbee0:	ldr	x8, [x0]
1004bbee4:	adrp	x9, 7700 ; 0x1022cf000
1004bbee8:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004bbeec:	ldr	x9, [x9]
1004bbef0:	and	x8, x9, x8
1004bbef4:	ldr	x8, [x8, #0x140]
1004bbef8:	str	x24, [sp, #-0x10]!
1004bbefc:	adrp	x7, 6 ; 0x1004c1000
1004bbf00:	add	x7, x7, #0x248
1004bbf04:	orr	x1, x21, #0x8000000000000000
1004bbf08:	mov	x0, #0x12
1004bbf0c:	movk	x0, #0xd000, lsl #48
1004bbf10:	mov	x2, #0x0
1004bbf14:	mov	x3, #0x0
1004bbf18:	mov	w4, #0x0
1004bbf1c:	mov	x5, #0x0
1004bbf20:	mov	w6, #0x1
1004bbf24:	mov	x20, x23
1004bbf28:	blr	x8
1004bbf2c:	add	sp, sp, #0x10
1004bbf30:	ldur	x22, [x29, #-0xa8]
1004bbf34:	mov	x0, x22
1004bbf38:	mov	x2, x23
1004bbf3c:	bl	0x101acb460 ; selector addSubview:
1004bbf40:	add	x0, x19, x28
1004bbf44:	sub	x1, x29, #0x88
1004bbf48:	mov	w2, #0x21
1004bbf4c:	mov	x3, #0x0
1004bbf50:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bbf54:	add	x20, x19, x28
1004bbf58:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004bbf5c:	ldr	x8, [x19, x28]
1004bbf60:	and	x8, x8, #0xffffffffffffff8
1004bbf64:	ldp	x21, x8, [x8, #0x10]
1004bbf68:	cmp	x21, x8, lsr #1
1004bbf6c:	b.hs	0x1004bc150
1004bbf70:	mov	x0, x23
1004bbf74:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bbf78:	mov	x23, x0
1004bbf7c:	add	x20, x19, x28
1004bbf80:	mov	x0, x21
1004bbf84:	mov	x1, x23
1004bbf88:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004bbf8c:	sub	x0, x29, #0x88
1004bbf90:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004bbf94:	mov	x0, x26
1004bbf98:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bbf9c:	mov	x0, x23
1004bbfa0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bbfa4:	mov	x0, x24
1004bbfa8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bbfac:	fmov	d0, #28.00000000
1004bbfb0:	fadd	d8, d8, d0
1004bbfb4:	ldur	w8, [x29, #-0x9c]
1004bbfb8:	tbz	w8, #0x0, 0x1004bc108
1004bbfbc:	mvn	x20, x25
1004bbfc0:	ldur	x24, [x29, #-0xd0]
1004bbfc4:	mov	x0, x24
1004bbfc8:	ldp	x8, x1, [x29, #-0x98]
1004bbfcc:	ldur	x21, [x29, #-0xb8]
1004bbfd0:	mov	x2, x21
1004bbfd4:	blr	x8
1004bbfd8:	add	x8, x25, #0x10
1004bbfdc:	and	x20, x8, x20
1004bbfe0:	adrp	x0, 7455 ; 0x1021da000
1004bbfe4:	add	x0, x0, #0xe00
1004bbfe8:	ldur	x8, [x29, #-0xd8]
1004bbfec:	add	x1, x20, x8
1004bbff0:	orr	x2, x25, #0x7
1004bbff4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bbff8:	mov	x23, x0
1004bbffc:	add	x0, x0, x20
1004bc000:	mov	x1, x24
1004bc004:	mov	x2, x21
1004bc008:	blr	x27
1004bc00c:	mov	x0, #0x0
1004bc010:	bl	0x1004ad03c
1004bc014:	mov	x8, #0x800000000000
1004bc018:	movk	x8, #0x4071, lsl #48
1004bc01c:	fmov	d9, x8
1004bc020:	fmov	d10, #28.00000000
1004bc024:	movi.2d	v0, #0000000000000000
1004bc028:	fmov	d3, #28.00000000
1004bc02c:	mov.16b	v1, v8
1004bc030:	mov.16b	v2, v9
1004bc034:	mov	x20, x0
1004bc038:	bl	0x100096d60
1004bc03c:	mov	x21, x22
1004bc040:	mov	x22, x0
1004bc044:	ldr	x8, [x0]
1004bc048:	adrp	x9, 7699 ; 0x1022cf000
1004bc04c:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004bc050:	ldr	x9, [x9]
1004bc054:	and	x8, x9, x8
1004bc058:	ldr	x8, [x8, #0x198]
1004bc05c:	adrp	x3, 5 ; 0x1004c1000
1004bc060:	add	x3, x3, #0x3c4
1004bc064:	mov	x0, #0x704f
1004bc068:	movk	x0, #0x6e65, lsl #16
1004bc06c:	movk	x0, #0x6920, lsl #32
1004bc070:	movk	x0, #0x6e, lsl #48
1004bc074:	mov	x1, #-0x1900000000000000
1004bc078:	mov.16b	v0, v9
1004bc07c:	mov	x2, x19
1004bc080:	mov	x4, x23
1004bc084:	mov	x5, #0x0
1004bc088:	mov	x6, #0x0
1004bc08c:	mov	x20, x22
1004bc090:	blr	x8
1004bc094:	mov	x0, x21
1004bc098:	mov	x2, x22
1004bc09c:	bl	0x101acb460 ; selector addSubview:
1004bc0a0:	add	x0, x19, x28
1004bc0a4:	sub	x1, x29, #0x88
1004bc0a8:	mov	w2, #0x21
1004bc0ac:	mov	x3, #0x0
1004bc0b0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bc0b4:	add	x20, x19, x28
1004bc0b8:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004bc0bc:	ldr	x8, [x19, x28]
1004bc0c0:	and	x8, x8, #0xffffffffffffff8
1004bc0c4:	ldp	x21, x8, [x8, #0x10]
1004bc0c8:	cmp	x21, x8, lsr #1
1004bc0cc:	b.hs	0x1004bc16c
1004bc0d0:	mov	x0, x22
1004bc0d4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bc0d8:	mov	x22, x0
1004bc0dc:	add	x20, x19, x28
1004bc0e0:	mov	x0, x21
1004bc0e4:	mov	x1, x22
1004bc0e8:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004bc0ec:	sub	x0, x29, #0x88
1004bc0f0:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004bc0f4:	mov	x0, x22
1004bc0f8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bc0fc:	mov	x0, x23
1004bc100:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bc104:	fadd	d8, d8, d10
1004bc108:	mov.16b	v0, v8
1004bc10c:	sub	sp, x29, #0x70
1004bc110:	ldp	x29, x30, [sp, #0x70]
1004bc114:	ldp	x20, x19, [sp, #0x60]
1004bc118:	ldp	x22, x21, [sp, #0x50]
1004bc11c:	ldp	x24, x23, [sp, #0x40]
1004bc120:	ldp	x26, x25, [sp, #0x30]
1004bc124:	ldp	x28, x27, [sp, #0x20]
1004bc128:	ldp	d9, d8, [sp, #0x10]
1004bc12c:	ldp	d11, d10, [sp], #0x80
1004bc130:	ret
1004bc134:	cmp	x8, #0x1
1004bc138:	cset	w0, hi
1004bc13c:	add	x1, x21, #0x1
1004bc140:	add	x20, x19, x28
1004bc144:	mov	w2, #0x1
1004bc148:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004bc14c:	b	0x1004bbdf0
1004bc150:	cmp	x8, #0x1
1004bc154:	cset	w0, hi
1004bc158:	add	x1, x21, #0x1
1004bc15c:	add	x20, x19, x28
1004bc160:	mov	w2, #0x1
1004bc164:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004bc168:	b	0x1004bbf70
1004bc16c:	cmp	x8, #0x1
1004bc170:	cset	w0, hi
1004bc174:	add	x1, x21, #0x1
1004bc178:	add	x20, x19, x28
1004bc17c:	mov	w2, #0x1
1004bc180:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004bc184:	b	0x1004bc0d0
1004bc188:	stp	x28, x27, [sp, #-0x60]!
1004bc18c:	stp	x26, x25, [sp, #0x10]
1004bc190:	stp	x24, x23, [sp, #0x20]
1004bc194:	stp	x22, x21, [sp, #0x30]
1004bc198:	stp	x20, x19, [sp, #0x40]
1004bc19c:	stp	x29, x30, [sp, #0x50]
1004bc1a0:	add	x29, sp, #0x50
1004bc1a4:	sub	sp, sp, #0xb0
1004bc1a8:	mov	x20, x0
1004bc1ac:	mov	x0, #0x0
1004bc1b0:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004bc1b4:	ldur	x8, [x0, #-0x8]
1004bc1b8:	stp	x8, x0, [x29, #-0xd0]
1004bc1bc:	ldr	x28, [x8, #0x40]
1004bc1c0:	mov	x9, x28
1004bc1c4:	adrp	x16, 7695 ; 0x1022cb000
1004bc1c8:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004bc1cc:	blr	x16
1004bc1d0:	mov	x8, sp
1004bc1d4:	add	x9, x28, #0xf
1004bc1d8:	and	x12, x9, #0xfffffffffffffff0
1004bc1dc:	sub	x8, x8, x12
1004bc1e0:	stur	x8, [x29, #-0xf0]
1004bc1e4:	mov	sp, x8
1004bc1e8:	mov	x9, x28
1004bc1ec:	adrp	x16, 7695 ; 0x1022cb000
1004bc1f0:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004bc1f4:	blr	x16
1004bc1f8:	mov	x8, sp
1004bc1fc:	sub	x8, x8, x12
1004bc200:	stur	x8, [x29, #-0xe0]
1004bc204:	mov	sp, x8
1004bc208:	mov	x9, x28
1004bc20c:	adrp	x16, 7695 ; 0x1022cb000
1004bc210:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004bc214:	blr	x16
1004bc218:	mov	x8, sp
1004bc21c:	sub	x22, x8, x12
1004bc220:	mov	sp, x22
1004bc224:	stur	x20, [x29, #-0xd8]
1004bc228:	bl	0x101ac4df8 ; symbol stub for: _$s10Foundation3URLV4pathSSvg
1004bc22c:	mov	x23, x1
1004bc230:	bl	0x10057b950
1004bc234:	mov	x21, x0
1004bc238:	mov	x20, x1
1004bc23c:	mov	x0, x23
1004bc240:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bc244:	cbz	x20, 0x1004bc2e4
1004bc248:	bl	0x1000ace0c
1004bc24c:	mov	x0, x21
1004bc250:	mov	x1, x20
1004bc254:	bl	0x10057b224
1004bc258:	mov	x25, x0
1004bc25c:	mov	x0, x21
1004bc260:	mov	x1, x20
1004bc264:	bl	0x10057c9dc
1004bc268:	mov	x23, x0
1004bc26c:	mov	x21, x1
1004bc270:	mov	x0, x20
1004bc274:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bc278:	mov	x19, #0x6544
1004bc27c:	movk	x19, #0x6166, lsl #16
1004bc280:	movk	x19, #0x6c75, lsl #32
1004bc284:	movk	x19, #0x2074, lsl #48
1004bc288:	cbz	x21, 0x1004bc2f0
1004bc28c:	mov	x8, #-0x2000000000000000
1004bc290:	stp	xzr, x8, [x29, #-0xa0]
1004bc294:	sub	x20, x29, #0xa0
1004bc298:	mov	w0, #0x10
1004bc29c:	bl	0x101ac757c ; symbol stub for: _$ss11_StringGutsV4growyySiF
1004bc2a0:	ldur	x0, [x29, #-0x98]
1004bc2a4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bc2a8:	mov	x8, #0x7041
1004bc2ac:	movk	x8, #0x2070, lsl #16
1004bc2b0:	movk	x8, #0x28, lsl #32
1004bc2b4:	movk	x8, #0xed00, lsl #48
1004bc2b8:	stp	x19, x8, [x29, #-0xa0]
1004bc2bc:	mov	x0, x23
1004bc2c0:	mov	x1, x21
1004bc2c4:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004bc2c8:	mov	w0, #0x29
1004bc2cc:	mov	x1, #-0x1f00000000000000
1004bc2d0:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004bc2d4:	mov	x0, x21
1004bc2d8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bc2dc:	ldp	x19, x23, [x29, #-0xa0]
1004bc2e0:	b	0x1004bc2fc
1004bc2e4:	adrp	x20, 7699 ; 0x1022cf000
1004bc2e8:	ldr	x20, [x20, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004bc2ec:	b	0x1004bc41c
1004bc2f0:	mov	x23, #0x7041
1004bc2f4:	movk	x23, #0x70, lsl #16
1004bc2f8:	movk	x23, #0xeb00, lsl #48
1004bc2fc:	ldp	x1, x26, [x29, #-0xd8]
1004bc300:	ldr	x8, [x26, #0x10]
1004bc304:	mov	x0, x22
1004bc308:	ldur	x24, [x29, #-0xc8]
1004bc30c:	mov	x2, x24
1004bc310:	blr	x8
1004bc314:	ldrb	w8, [x26, #0x50]
1004bc318:	add	x9, x8, #0x10
1004bc31c:	bic	x21, x9, x8
1004bc320:	adrp	x0, 7454 ; 0x1021da000
1004bc324:	add	x0, x0, #0xec8
1004bc328:	add	x1, x21, x28
1004bc32c:	orr	x2, x8, #0x7
1004bc330:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bc334:	mov	x20, x0
1004bc338:	ldr	x8, [x26, #0x20]
1004bc33c:	add	x0, x0, x21
1004bc340:	mov	x1, x22
1004bc344:	mov	x2, x24
1004bc348:	blr	x8
1004bc34c:	adrp	x0, 7454 ; 0x1021da000
1004bc350:	add	x0, x0, #0xef0
1004bc354:	mov	w1, #0x20
1004bc358:	mov	w2, #0x7
1004bc35c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bc360:	mov	x22, x0
1004bc364:	adrp	x8, 5 ; 0x1004c1000
1004bc368:	add	x8, x8, #0x5e4
1004bc36c:	stp	x8, x20, [x0, #0x10]
1004bc370:	mov	x0, x25
1004bc374:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bc378:	mov	x21, x0
1004bc37c:	adrp	x3, 7699 ; 0x1022cf000
1004bc380:	ldr	x3, [x3, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004bc384:	adrp	x4, 7699 ; 0x1022cf000
1004bc388:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bc38c:	mov	w0, #0x0
1004bc390:	mov	w1, #0x1
1004bc394:	mov	w2, #0x1
1004bc398:	bl	0x1004bfb6c
1004bc39c:	mov	x20, x0
1004bc3a0:	ldp	x24, x8, [x0, #0x10]
1004bc3a4:	lsr	x9, x8, #1
1004bc3a8:	add	x27, x24, #0x1
1004bc3ac:	cmp	x9, x24
1004bc3b0:	b.ls	0x1004bc790
1004bc3b4:	str	x27, [x20, #0x10]
1004bc3b8:	mov	w10, #0x38
1004bc3bc:	madd	x10, x24, x10, x20
1004bc3c0:	stp	x19, x23, [x10, #0x20]
1004bc3c4:	adrp	x11, -1208 ; 0x100004000
1004bc3c8:	add	x11, x11, #0xcc
1004bc3cc:	stp	xzr, xzr, [x10, #0x30]
1004bc3d0:	stp	x25, x11, [x10, #0x40]
1004bc3d4:	str	x22, [x10, #0x50]
1004bc3d8:	add	x23, x24, #0x2
1004bc3dc:	cmp	x9, x23
1004bc3e0:	b.lt	0x1004bc7c0
1004bc3e4:	str	x23, [x20, #0x10]
1004bc3e8:	mov	w8, #0x38
1004bc3ec:	madd	x8, x27, x8, x20
1004bc3f0:	mov	x9, #-0x1d00000000000000
1004bc3f4:	mov	w10, #0x2d2d
1004bc3f8:	movk	w10, #0x2d, lsl #16
1004bc3fc:	stp	x10, x9, [x8, #0x20]
1004bc400:	stp	xzr, xzr, [x8, #0x30]
1004bc404:	adrp	x9, -1209 ; 0x100003000
1004bc408:	add	x9, x9, #0xf40
1004bc40c:	stp	xzr, x9, [x8, #0x40]
1004bc410:	str	xzr, [x8, #0x50]
1004bc414:	mov	x0, x21
1004bc418:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bc41c:	bl	0x10057912c
1004bc420:	ldr	x22, [x0, #0x10]
1004bc424:	stp	x0, x28, [x29, #-0x100]
1004bc428:	cbz	x22, 0x1004bc5c4
1004bc42c:	add	x27, x0, #0x20
1004bc430:	add	x8, x28, #0x7
1004bc434:	stur	x8, [x29, #-0xe8]
1004bc438:	ldur	x28, [x29, #-0xe0]
1004bc43c:	ldp	q0, q1, [x27]
1004bc440:	stp	q0, q1, [x29, #-0xa0]
1004bc444:	ldrb	w8, [x27, #0x20]
1004bc448:	sturb	w8, [x29, #-0x80]
1004bc44c:	bl	0x1000ace0c
1004bc450:	sub	x0, x29, #0xa0
1004bc454:	bl	0x10057b218
1004bc458:	ldp	x8, x21, [x29, #-0xa0]
1004bc45c:	stp	x8, x0, [x29, #-0xc0]
1004bc460:	mov	x24, x20
1004bc464:	ldp	x1, x20, [x29, #-0xd8]
1004bc468:	ldr	x8, [x20, #0x10]
1004bc46c:	mov	x0, x28
1004bc470:	ldur	x19, [x29, #-0xc8]
1004bc474:	mov	x2, x19
1004bc478:	blr	x8
1004bc47c:	sub	x8, x29, #0xa0
1004bc480:	ldur	q0, [x8, #0x10]
1004bc484:	stur	q0, [x29, #-0x70]
1004bc488:	ldrb	w8, [x20, #0x50]
1004bc48c:	add	x9, x8, #0x10
1004bc490:	bic	x23, x9, x8
1004bc494:	ldur	x9, [x29, #-0xe8]
1004bc498:	add	x9, x9, x23
1004bc49c:	and	x26, x9, #0xfffffffffffffff8
1004bc4a0:	add	x1, x26, #0x21
1004bc4a4:	orr	x2, x8, #0x7
1004bc4a8:	adrp	x0, 7454 ; 0x1021da000
1004bc4ac:	add	x0, x0, #0xe28
1004bc4b0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bc4b4:	mov	x25, x0
1004bc4b8:	ldr	x8, [x20, #0x20]
1004bc4bc:	mov	x20, x24
1004bc4c0:	add	x0, x0, x23
1004bc4c4:	mov	x1, x28
1004bc4c8:	mov	x2, x19
1004bc4cc:	blr	x8
1004bc4d0:	add	x8, x25, x26
1004bc4d4:	ldp	q0, q1, [x29, #-0xa0]
1004bc4d8:	stp	q0, q1, [x8]
1004bc4dc:	ldurb	w9, [x29, #-0x80]
1004bc4e0:	strb	w9, [x8, #0x20]
1004bc4e4:	adrp	x0, 7454 ; 0x1021da000
1004bc4e8:	add	x0, x0, #0xe50
1004bc4ec:	mov	w1, #0x20
1004bc4f0:	mov	w2, #0x7
1004bc4f4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bc4f8:	mov	x23, x0
1004bc4fc:	adrp	x8, 5 ; 0x1004c1000
1004bc500:	add	x8, x8, #0x468
1004bc504:	stp	x8, x25, [x0, #0x10]
1004bc508:	mov	x0, x21
1004bc50c:	mov	w1, #0x2
1004bc510:	bl	0x101aca630 ; symbol stub for: _swift_bridgeObjectRetain_n
1004bc514:	sub	x0, x29, #0x70
1004bc518:	sub	x1, x29, #0xb0
1004bc51c:	bl	0x1000589e8
1004bc520:	mov	x0, x24
1004bc524:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004bc528:	tbz	w0, #0x0, 0x1004bc574
1004bc52c:	ldp	x26, x8, [x20, #0x10]
1004bc530:	add	x25, x26, #0x1
1004bc534:	cmp	x26, x8, lsr #1
1004bc538:	b.hs	0x1004bc59c
1004bc53c:	str	x25, [x20, #0x10]
1004bc540:	mov	w8, #0x38
1004bc544:	madd	x8, x26, x8, x20
1004bc548:	ldp	x10, x11, [x29, #-0xc0]
1004bc54c:	stp	x10, x21, [x8, #0x20]
1004bc550:	stp	xzr, xzr, [x8, #0x30]
1004bc554:	adrp	x9, -1208 ; 0x100004000
1004bc558:	add	x9, x9, #0xcc
1004bc55c:	stp	x11, x9, [x8, #0x40]
1004bc560:	str	x23, [x8, #0x50]
1004bc564:	add	x27, x27, #0x28
1004bc568:	subs	x22, x22, #0x1
1004bc56c:	b.ne	0x1004bc43c
1004bc570:	b	0x1004bc5c4
1004bc574:	ldr	x8, [x20, #0x10]
1004bc578:	add	x1, x8, #0x1
1004bc57c:	mov	w0, #0x0
1004bc580:	mov	w2, #0x1
1004bc584:	mov	x3, x20
1004bc588:	adrp	x4, 7699 ; 0x1022cf000
1004bc58c:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bc590:	bl	0x1004bfb6c
1004bc594:	mov	x20, x0
1004bc598:	b	0x1004bc52c
1004bc59c:	cmp	x8, #0x1
1004bc5a0:	cset	w0, hi
1004bc5a4:	mov	x1, x25
1004bc5a8:	mov	w2, #0x1
1004bc5ac:	mov	x3, x20
1004bc5b0:	adrp	x4, 7699 ; 0x1022cf000
1004bc5b4:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bc5b8:	bl	0x1004bfb6c
1004bc5bc:	mov	x20, x0
1004bc5c0:	b	0x1004bc53c
1004bc5c4:	ldur	x0, [x29, #-0x100]
1004bc5c8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bc5cc:	ldr	x19, [x20, #0x10]
1004bc5d0:	cbz	x19, 0x1004bc628
1004bc5d4:	mov	x0, x20
1004bc5d8:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004bc5dc:	tbz	w0, #0x0, 0x1004bc7e8
1004bc5e0:	ldp	x19, x8, [x20, #0x10]
1004bc5e4:	add	x21, x19, #0x1
1004bc5e8:	cmp	x19, x8, lsr #1
1004bc5ec:	ldur	x22, [x29, #-0xf8]
1004bc5f0:	b.hs	0x1004bc80c
1004bc5f4:	str	x21, [x20, #0x10]
1004bc5f8:	mov	w8, #0x38
1004bc5fc:	madd	x8, x19, x8, x20
1004bc600:	mov	x9, #-0x1d00000000000000
1004bc604:	mov	w10, #0x2d2d
1004bc608:	movk	w10, #0x2d, lsl #16
1004bc60c:	stp	x10, x9, [x8, #0x20]
1004bc610:	stp	xzr, xzr, [x8, #0x30]
1004bc614:	adrp	x9, -1209 ; 0x100003000
1004bc618:	add	x9, x9, #0xf40
1004bc61c:	stp	xzr, x9, [x8, #0x40]
1004bc620:	str	xzr, [x8, #0x50]
1004bc624:	b	0x1004bc62c
1004bc628:	ldur	x22, [x29, #-0xf8]
1004bc62c:	mov	x25, x20
1004bc630:	adrp	x8, 6428 ; 0x101dd8000
1004bc634:	add	x8, x8, #0xf50 ; literal pool for: "com.apple.finder"
1004bc638:	sub	x19, x8, #0x20
1004bc63c:	bl	0x1000ace0c
1004bc640:	orr	x1, x19, #0x8000000000000000
1004bc644:	mov	x0, #0x10
1004bc648:	movk	x0, #0xd000, lsl #48
1004bc64c:	bl	0x10057b224
1004bc650:	mov	x21, x0
1004bc654:	ldp	x1, x20, [x29, #-0xd8]
1004bc658:	ldr	x8, [x20, #0x10]
1004bc65c:	ldur	x24, [x29, #-0xf0]
1004bc660:	mov	x0, x24
1004bc664:	ldur	x23, [x29, #-0xc8]
1004bc668:	mov	x2, x23
1004bc66c:	blr	x8
1004bc670:	ldrb	w8, [x20, #0x50]
1004bc674:	add	x9, x8, #0x10
1004bc678:	bic	x19, x9, x8
1004bc67c:	adrp	x0, 7454 ; 0x1021da000
1004bc680:	add	x0, x0, #0xe78
1004bc684:	add	x1, x19, x22
1004bc688:	orr	x2, x8, #0x7
1004bc68c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bc690:	mov	x22, x0
1004bc694:	ldr	x8, [x20, #0x20]
1004bc698:	add	x0, x0, x19
1004bc69c:	mov	x1, x24
1004bc6a0:	mov	x2, x23
1004bc6a4:	blr	x8
1004bc6a8:	adrp	x0, 7454 ; 0x1021da000
1004bc6ac:	add	x0, x0, #0xea0
1004bc6b0:	mov	w1, #0x20
1004bc6b4:	mov	w2, #0x7
1004bc6b8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bc6bc:	mov	x19, x0
1004bc6c0:	adrp	x8, 5 ; 0x1004c1000
1004bc6c4:	add	x8, x8, #0x4fc
1004bc6c8:	stp	x8, x22, [x0, #0x10]
1004bc6cc:	mov	x0, x25
1004bc6d0:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004bc6d4:	tbz	w0, #0x0, 0x1004bc740
1004bc6d8:	ldp	x23, x8, [x25, #0x10]
1004bc6dc:	add	x22, x23, #0x1
1004bc6e0:	cmp	x23, x8, lsr #1
1004bc6e4:	b.hs	0x1004bc768
1004bc6e8:	str	x22, [x25, #0x10]
1004bc6ec:	mov	w8, #0x38
1004bc6f0:	madd	x8, x23, x8, x25
1004bc6f4:	mov	x9, #0x6946
1004bc6f8:	movk	x9, #0x646e, lsl #16
1004bc6fc:	movk	x9, #0x7265, lsl #32
1004bc700:	mov	x10, #-0x1a00000000000000
1004bc704:	stp	x9, x10, [x8, #0x20]
1004bc708:	stp	xzr, xzr, [x8, #0x30]
1004bc70c:	adrp	x9, -1208 ; 0x100004000
1004bc710:	add	x9, x9, #0xcc
1004bc714:	stp	x21, x9, [x8, #0x40]
1004bc718:	str	x19, [x8, #0x50]
1004bc71c:	mov	x0, x25
1004bc720:	sub	sp, x29, #0x50
1004bc724:	ldp	x29, x30, [sp, #0x50]
1004bc728:	ldp	x20, x19, [sp, #0x40]
1004bc72c:	ldp	x22, x21, [sp, #0x30]
1004bc730:	ldp	x24, x23, [sp, #0x20]
1004bc734:	ldp	x26, x25, [sp, #0x10]
1004bc738:	ldp	x28, x27, [sp], #0x60
1004bc73c:	ret
1004bc740:	ldr	x8, [x25, #0x10]
1004bc744:	adrp	x4, 7699 ; 0x1022cf000
1004bc748:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bc74c:	add	x1, x8, #0x1
1004bc750:	mov	w0, #0x0
1004bc754:	mov	w2, #0x1
1004bc758:	mov	x3, x25
1004bc75c:	bl	0x1004bfb6c
1004bc760:	mov	x25, x0
1004bc764:	b	0x1004bc6d8
1004bc768:	cmp	x8, #0x1
1004bc76c:	cset	w0, hi
1004bc770:	adrp	x4, 7699 ; 0x1022cf000
1004bc774:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bc778:	mov	x1, x22
1004bc77c:	mov	w2, #0x1
1004bc780:	mov	x3, x25
1004bc784:	bl	0x1004bfb6c
1004bc788:	mov	x25, x0
1004bc78c:	b	0x1004bc6e8
1004bc790:	cmp	x8, #0x1
1004bc794:	cset	w0, hi
1004bc798:	adrp	x4, 7699 ; 0x1022cf000
1004bc79c:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bc7a0:	mov	x1, x27
1004bc7a4:	mov	w2, #0x1
1004bc7a8:	mov	x3, x20
1004bc7ac:	bl	0x1004bfb6c
1004bc7b0:	mov	x20, x0
1004bc7b4:	ldr	x8, [x0, #0x18]
1004bc7b8:	lsr	x9, x8, #1
1004bc7bc:	b	0x1004bc3b4
1004bc7c0:	cmp	x8, #0x1
1004bc7c4:	cset	w0, hi
1004bc7c8:	adrp	x4, 7699 ; 0x1022cf000
1004bc7cc:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bc7d0:	mov	x1, x23
1004bc7d4:	mov	w2, #0x1
1004bc7d8:	mov	x3, x20
1004bc7dc:	bl	0x1004bfb6c
1004bc7e0:	mov	x20, x0
1004bc7e4:	b	0x1004bc3e4
1004bc7e8:	adrp	x4, 7699 ; 0x1022cf000
1004bc7ec:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bc7f0:	add	x1, x19, #0x1
1004bc7f4:	mov	w0, #0x0
1004bc7f8:	mov	w2, #0x1
1004bc7fc:	mov	x3, x20
1004bc800:	bl	0x1004bfb6c
1004bc804:	mov	x20, x0
1004bc808:	b	0x1004bc5e0
1004bc80c:	cmp	x8, #0x1
1004bc810:	cset	w0, hi
1004bc814:	adrp	x4, 7699 ; 0x1022cf000
1004bc818:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bc81c:	mov	x1, x21
1004bc820:	mov	w2, #0x1
1004bc824:	mov	x3, x20
1004bc828:	bl	0x1004bfb6c
1004bc82c:	mov	x20, x0
1004bc830:	b	0x1004bc5f4
1004bc834:	stp	d11, d10, [sp, #-0x80]!
1004bc838:	stp	d9, d8, [sp, #0x10]
1004bc83c:	stp	x28, x27, [sp, #0x20]
1004bc840:	stp	x26, x25, [sp, #0x30]
1004bc844:	stp	x24, x23, [sp, #0x40]
1004bc848:	stp	x22, x21, [sp, #0x50]
1004bc84c:	stp	x20, x19, [sp, #0x60]
1004bc850:	stp	x29, x30, [sp, #0x70]
1004bc854:	add	x29, sp, #0x70
1004bc858:	mov	x23, x1
1004bc85c:	mov.16b	v8, v0
1004bc860:	mov	x19, x0
1004bc864:	adrp	x8, 7786 ; 0x102326000
1004bc868:	ldr	x0, [x8, #0xa40] ; Objc class ref: _OBJC_CLASS_$_NSView
1004bc86c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004bc870:	mov	x8, #0x406f000000000000
1004bc874:	fmov	d2, x8
1004bc878:	fmov	d10, #28.00000000
1004bc87c:	fmov	d0, #16.00000000
1004bc880:	fmov	d3, #28.00000000
1004bc884:	mov.16b	v1, v8
1004bc888:	bl	0x101ace5a0 ; selector initWithFrame:
1004bc88c:	mov	x21, x0
1004bc890:	adrp	x8, 7694 ; 0x1022ca000
1004bc894:	ldr	x8, [x8, #0x618] ; literal pool symbol address: _NSFontWeightRegular
1004bc898:	ldr	d9, [x8]
1004bc89c:	adrp	x8, 7786 ; 0x102326000
1004bc8a0:	ldr	x0, [x8, #0xb20] ; Objc class ref: _OBJC_CLASS_$_NSImageSymbolConfiguration
1004bc8a4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bc8a8:	fmov	d0, #12.00000000
1004bc8ac:	mov.16b	v1, v9
1004bc8b0:	bl	0x101acc5c0 ; selector configurationWithPointSize:weight:
1004bc8b4:	mov	x29, x29
1004bc8b8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bc8bc:	mov	x22, x0
1004bc8c0:	mov	x0, #0x6f64
1004bc8c4:	movk	x0, #0x2e63, lsl #16
1004bc8c8:	movk	x0, #0x6574, lsl #32
1004bc8cc:	movk	x0, #0x7478, lsl #48
1004bc8d0:	mov	x1, #-0x1800000000000000
1004bc8d4:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004bc8d8:	mov	x24, x0
1004bc8dc:	adrp	x8, 7786 ; 0x102326000
1004bc8e0:	ldr	x0, [x8, #0xb28] ; Objc class ref: _OBJC_CLASS_$_NSImage
1004bc8e4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bc8e8:	mov	x2, x24
1004bc8ec:	mov	x3, #0x0
1004bc8f0:	bl	0x101ace220 ; selector imageWithSystemSymbolName:accessibilityDescription:
1004bc8f4:	mov	x29, x29
1004bc8f8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bc8fc:	mov	x25, x0
1004bc900:	mov	x0, x24
1004bc904:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bc908:	adrp	x27, 7786 ; 0x102326000
1004bc90c:	cbz	x25, 0x1004bc9b4
1004bc910:	mov	x0, x25
1004bc914:	mov	x2, x22
1004bc918:	bl	0x101ace200 ; selector imageWithSymbolConfiguration:
1004bc91c:	mov	x29, x29
1004bc920:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bc924:	mov	x24, x0
1004bc928:	mov	x0, x25
1004bc92c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bc930:	cbz	x24, 0x1004bc9b4
1004bc934:	adrp	x8, 7786 ; 0x102326000
1004bc938:	ldr	x0, [x8, #0xb50] ; Objc class ref: _OBJC_CLASS_$_NSImageView
1004bc93c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004bc940:	movi.2d	v0, #0000000000000000
1004bc944:	fmov	d1, #7.00000000
1004bc948:	fmov	d2, #14.00000000
1004bc94c:	fmov	d3, #14.00000000
1004bc950:	bl	0x101ace5a0 ; selector initWithFrame:
1004bc954:	mov	x25, x0
1004bc958:	mov	x2, x24
1004bc95c:	bl	0x101ad2f60 ; selector setImage:
1004bc960:	ldr	x0, [x27, #0x9c8]
1004bc964:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bc968:	bl	0x101ad12e0 ; selector secondaryLabelColor
1004bc96c:	mov	x29, x29
1004bc970:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bc974:	mov	x26, x0
1004bc978:	mov	x0, x25
1004bc97c:	mov	x2, x26
1004bc980:	bl	0x101ad2300 ; selector setContentTintColor:
1004bc984:	mov	x0, x26
1004bc988:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bc98c:	mov	x0, x25
1004bc990:	mov	x2, #0x0
1004bc994:	bl	0x101ad3000 ; selector setImageScaling:
1004bc998:	mov	x0, x21
1004bc99c:	mov	x2, x25
1004bc9a0:	bl	0x101acb460 ; selector addSubview:
1004bc9a4:	mov	x0, x24
1004bc9a8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bc9ac:	mov	x0, x25
1004bc9b0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bc9b4:	mov	x0, x23
1004bc9b8:	bl	0x1004bcb44
1004bc9bc:	mov	x20, x1
1004bc9c0:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004bc9c4:	mov	x23, x0
1004bc9c8:	mov	x0, x20
1004bc9cc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bc9d0:	adrp	x8, 7786 ; 0x102326000
1004bc9d4:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004bc9d8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bc9dc:	mov	x2, x23
1004bc9e0:	bl	0x101acf240 ; selector labelWithString:
1004bc9e4:	mov	x29, x29
1004bc9e8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bc9ec:	mov	x20, x0
1004bc9f0:	mov	x0, x23
1004bc9f4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bc9f8:	mov	x0, x20
1004bc9fc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bca00:	mov	x20, x0
1004bca04:	bl	0x10002dd04
1004bca08:	mov.16b	v1, v0
1004bca0c:	fmov	d0, #12.00000000
1004bca10:	bl	0x100004700
1004bca14:	mov	x23, x0
1004bca18:	mov	x0, x20
1004bca1c:	mov	x2, x23
1004bca20:	bl	0x101ad2aa0 ; selector setFont:
1004bca24:	mov	x0, x23
1004bca28:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bca2c:	ldr	x0, [x27, #0x9c8]
1004bca30:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bca34:	bl	0x101ad12e0 ; selector secondaryLabelColor
1004bca38:	mov	x29, x29
1004bca3c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bca40:	mov	x23, x0
1004bca44:	mov	x0, x20
1004bca48:	mov	x2, x23
1004bca4c:	bl	0x101ad4660 ; selector setTextColor:
1004bca50:	mov	x0, x23
1004bca54:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bca58:	mov	x0, x20
1004bca5c:	mov	w2, #0x5
1004bca60:	bl	0x101ad3340 ; selector setLineBreakMode:
1004bca64:	mov	x0, x20
1004bca68:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bca6c:	mov	x0, x20
1004bca70:	mov	w2, #0x0
1004bca74:	bl	0x101ad28e0 ; selector setEditable:
1004bca78:	mov	x0, x20
1004bca7c:	mov	w2, #0x0
1004bca80:	bl	0x101ad1fa0 ; selector setBordered:
1004bca84:	mov	x0, x20
1004bca88:	mov	w2, #0x0
1004bca8c:	bl	0x101ad2860 ; selector setDrawsBackground:
1004bca90:	mov	x0, x20
1004bca94:	bl	0x101ad4fe0 ; selector sizeToFit
1004bca98:	mov	x0, x20
1004bca9c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bcaa0:	mov	x20, x0
1004bcaa4:	bl	0x101acdcc0 ; selector frame
1004bcaa8:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004bcaac:	fsub	d0, d10, d0
1004bcab0:	fmov	d1, #0.50000000
1004bcab4:	fmul	d9, d0, d1
1004bcab8:	mov	x0, x20
1004bcabc:	bl	0x101acdcc0 ; selector frame
1004bcac0:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004bcac4:	mov.16b	v3, v0
1004bcac8:	mov	x8, #0xc00000000000
1004bcacc:	movk	x8, #0x406c, lsl #48
1004bcad0:	fmov	d2, x8
1004bcad4:	fmov	d0, #18.00000000
1004bcad8:	mov	x0, x20
1004bcadc:	mov.16b	v1, v9
1004bcae0:	bl	0x101ad2b80 ; selector setFrame:
1004bcae4:	mov	x0, x20
1004bcae8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bcaec:	mov	x0, x21
1004bcaf0:	mov	x2, x20
1004bcaf4:	bl	0x101acb460 ; selector addSubview:
1004bcaf8:	mov	x0, x19
1004bcafc:	mov	x2, x21
1004bcb00:	bl	0x101acb460 ; selector addSubview:
1004bcb04:	mov	x0, x20
1004bcb08:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bcb0c:	mov	x0, x21
1004bcb10:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bcb14:	mov	x0, x22
1004bcb18:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bcb1c:	fadd	d0, d8, d10
1004bcb20:	ldp	x29, x30, [sp, #0x70]
1004bcb24:	ldp	x20, x19, [sp, #0x60]
1004bcb28:	ldp	x22, x21, [sp, #0x50]
1004bcb2c:	ldp	x24, x23, [sp, #0x40]
1004bcb30:	ldp	x26, x25, [sp, #0x30]
1004bcb34:	ldp	x28, x27, [sp, #0x20]
1004bcb38:	ldp	d9, d8, [sp, #0x10]
1004bcb3c:	ldp	d11, d10, [sp], #0x80
1004bcb40:	ret
1004bcb44:	stp	x26, x25, [sp, #-0x50]!
1004bcb48:	stp	x24, x23, [sp, #0x10]
1004bcb4c:	stp	x22, x21, [sp, #0x20]
1004bcb50:	stp	x20, x19, [sp, #0x30]
1004bcb54:	stp	x29, x30, [sp, #0x40]
1004bcb58:	add	x29, sp, #0x40
1004bcb5c:	sub	sp, sp, #0x10
1004bcb60:	mov	x22, x20
1004bcb64:	mov	x20, x0
1004bcb68:	mov	x0, #0x0
1004bcb6c:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004bcb70:	mov	x23, x0
1004bcb74:	ldur	x26, [x0, #-0x8]
1004bcb78:	ldr	x8, [x26, #0x40]
1004bcb7c:	mov	x9, x8
1004bcb80:	adrp	x16, 7695 ; 0x1022cb000
1004bcb84:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004bcb88:	blr	x16
1004bcb8c:	mov	x9, sp
1004bcb90:	add	x8, x8, #0xf
1004bcb94:	and	x8, x8, #0xfffffffffffffff0
1004bcb98:	sub	x24, x9, x8
1004bcb9c:	mov	sp, x24
1004bcba0:	bl	0x101ac4df8 ; symbol stub for: _$s10Foundation3URLV4pathSSvg
1004bcba4:	mov	x21, x0
1004bcba8:	mov	x19, x1
1004bcbac:	mov	x8, x24
1004bcbb0:	bl	0x101ac4dc8 ; symbol stub for: _$s10Foundation3URLV25deletingLastPathComponentACyF
1004bcbb4:	mov	x20, x24
1004bcbb8:	bl	0x101ac4df8 ; symbol stub for: _$s10Foundation3URLV4pathSSvg
1004bcbbc:	mov	x20, x0
1004bcbc0:	mov	x25, x1
1004bcbc4:	ldr	x8, [x26, #0x8]
1004bcbc8:	mov	x0, x24
1004bcbcc:	mov	x1, x23
1004bcbd0:	blr	x8
1004bcbd4:	mov	x0, x20
1004bcbd8:	mov	x1, x25
1004bcbdc:	bl	0x100582f94
1004bcbe0:	mov	x24, x0
1004bcbe4:	mov	x23, x1
1004bcbe8:	mov	x0, x25
1004bcbec:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bcbf0:	cbz	x23, 0x1004bcca4
1004bcbf4:	stp	x24, x23, [x29, #-0x50]
1004bcbf8:	mov	x0, x23
1004bcbfc:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bcc00:	sub	x20, x29, #0x50
1004bcc04:	mov	w0, #0x2f
1004bcc08:	mov	x1, #-0x1f00000000000000
1004bcc0c:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004bcc10:	ldp	x0, x20, [x29, #-0x50]
1004bcc14:	mov	x1, x20
1004bcc18:	mov	x2, x21
1004bcc1c:	mov	x3, x19
1004bcc20:	bl	0x101ac658c ; symbol stub for: _$sSS9hasPrefixySbSSF
1004bcc24:	mov	x25, x0
1004bcc28:	mov	x0, x20
1004bcc2c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bcc30:	tbz	w25, #0x0, 0x1004bcc9c
1004bcc34:	mov	x0, x24
1004bcc38:	mov	x1, x23
1004bcc3c:	bl	0x101ac6430 ; symbol stub for: _$sSS5countSivg
1004bcc40:	mov	x20, x0
1004bcc44:	mov	x0, x23
1004bcc48:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bcc4c:	adds	x0, x20, #0x1
1004bcc50:	b.vs	0x1004bcdec
1004bcc54:	mov	x1, x21
1004bcc58:	mov	x2, x19
1004bcc5c:	bl	0x1000252e8
1004bcc60:	mov	x20, x0
1004bcc64:	mov	x21, x1
1004bcc68:	mov	x22, x2
1004bcc6c:	mov	x23, x3
1004bcc70:	mov	x0, x19
1004bcc74:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bcc78:	mov	x0, x20
1004bcc7c:	mov	x1, x21
1004bcc80:	mov	x2, x22
1004bcc84:	mov	x3, x23
1004bcc88:	bl	0x101ac6340 ; symbol stub for: _$sSS14_fromSubstringySSSshFZ
1004bcc8c:	mov	x20, x0
1004bcc90:	mov	x21, x1
1004bcc94:	mov	x19, x23
1004bcc98:	b	0x1004bcdc0
1004bcc9c:	mov	x0, x23
1004bcca0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bcca4:	adrp	x8, 7905 ; 0x10239d000
1004bcca8:	ldr	x8, [x8, #0x248]
1004bccac:	add	x0, x22, x8
1004bccb0:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004bccb4:	cbz	x0, 0x1004bcdac
1004bccb8:	ldr	x8, [x0]
1004bccbc:	ldr	x8, [x8, #0x260]
1004bccc0:	mov	x20, x0
1004bccc4:	mov	x22, x0
1004bccc8:	blr	x8
1004bcccc:	mov	x20, x0
1004bccd0:	mov	x0, x22
1004bccd4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bccd8:	cbz	x20, 0x1004bcdac
1004bccdc:	ldr	x22, [x20, #0x18]
1004bcce0:	mov	x0, x22
1004bcce4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bcce8:	mov	x0, x20
1004bccec:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bccf0:	ldr	x8, [x22]
1004bccf4:	ldr	x8, [x8, #0x148]
1004bccf8:	mov	x20, x22
1004bccfc:	blr	x8
1004bcd00:	mov	x20, x0
1004bcd04:	mov	x0, x22
1004bcd08:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bcd0c:	cbz	x20, 0x1004bcdac
1004bcd10:	ldr	x8, [x20]
1004bcd14:	ldr	x8, [x8, #0x408]
1004bcd18:	blr	x8
1004bcd1c:	mov	x23, x0
1004bcd20:	mov	x22, x1
1004bcd24:	mov	x0, x20
1004bcd28:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bcd2c:	and	x8, x23, #0xffffffffffff
1004bcd30:	ubfx	x9, x22, #56, #4
1004bcd34:	tst	x22, #0x2000000000000000
1004bcd38:	csel	x8, x8, x9, eq
1004bcd3c:	cbz	x8, 0x1004bcda4
1004bcd40:	stp	x23, x22, [x29, #-0x50]
1004bcd44:	mov	x0, x22
1004bcd48:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bcd4c:	sub	x20, x29, #0x50
1004bcd50:	mov	w0, #0x2f
1004bcd54:	mov	x1, #-0x1f00000000000000
1004bcd58:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004bcd5c:	ldp	x0, x20, [x29, #-0x50]
1004bcd60:	mov	x1, x20
1004bcd64:	mov	x2, x21
1004bcd68:	mov	x3, x19
1004bcd6c:	bl	0x101ac658c ; symbol stub for: _$sSS9hasPrefixySbSSF
1004bcd70:	mov	x24, x0
1004bcd74:	mov	x0, x20
1004bcd78:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bcd7c:	tbz	w24, #0x0, 0x1004bcda4
1004bcd80:	mov	x0, x23
1004bcd84:	mov	x1, x22
1004bcd88:	bl	0x101ac6430 ; symbol stub for: _$sSS5countSivg
1004bcd8c:	mov	x20, x0
1004bcd90:	mov	x0, x22
1004bcd94:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bcd98:	adds	x0, x20, #0x1
1004bcd9c:	b.vc	0x1004bcc54
1004bcda0:	brk	#0x1
1004bcda4:	mov	x0, x22
1004bcda8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bcdac:	mov	x0, x21
1004bcdb0:	mov	x1, x19
1004bcdb4:	bl	0x10006aee0
1004bcdb8:	mov	x20, x0
1004bcdbc:	mov	x21, x1
1004bcdc0:	mov	x0, x19
1004bcdc4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bcdc8:	mov	x0, x20
1004bcdcc:	mov	x1, x21
1004bcdd0:	sub	sp, x29, #0x40
1004bcdd4:	ldp	x29, x30, [sp, #0x40]
1004bcdd8:	ldp	x20, x19, [sp, #0x30]
1004bcddc:	ldp	x22, x21, [sp, #0x20]
1004bcde0:	ldp	x24, x23, [sp, #0x10]
1004bcde4:	ldp	x26, x25, [sp], #0x50
1004bcde8:	ret
1004bcdec:	brk	#0x1
1004bcdf0:	sub	sp, sp, #0xb0
1004bcdf4:	stp	d9, d8, [sp, #0x40]
1004bcdf8:	stp	x28, x27, [sp, #0x50]
1004bcdfc:	stp	x26, x25, [sp, #0x60]
1004bce00:	stp	x24, x23, [sp, #0x70]
1004bce04:	stp	x22, x21, [sp, #0x80]
1004bce08:	stp	x20, x19, [sp, #0x90]
1004bce0c:	stp	x29, x30, [sp, #0xa0]
1004bce10:	add	x29, sp, #0xa0
1004bce14:	mov	x19, x20
1004bce18:	mov	x22, x1
1004bce1c:	mov.16b	v8, v0
1004bce20:	mov	x28, x0
1004bce24:	adrp	x8, 7965 ; 0x1023d9000
1004bce28:	add	x8, x8, #0x848
1004bce2c:	ldr	x8, [x8]
1004bce30:	ldrb	w8, [x1, x8]
1004bce34:	adrp	x26, 7699 ; 0x1022cf000
1004bce38:	ldr	x26, [x26, #0x718] ; literal pool symbol address: _swift_isaMask
1004bce3c:	adrp	x21, 7905 ; 0x10239d000
1004bce40:	tbnz	w8, #0x0, 0x1004bd2e0
1004bce44:	adrp	x0, 7454 ; 0x1021da000
1004bce48:	add	x0, x0, #0x978
1004bce4c:	mov	w1, #0x18
1004bce50:	mov	w2, #0x7
1004bce54:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bce58:	mov	x24, x0
1004bce5c:	add	x0, x0, #0x10
1004bce60:	mov	x1, x19
1004bce64:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bce68:	adrp	x0, 7454 ; 0x1021da000
1004bce6c:	add	x0, x0, #0xb30
1004bce70:	mov	w1, #0x18
1004bce74:	mov	w2, #0x7
1004bce78:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bce7c:	mov	x25, x0
1004bce80:	add	x0, x0, #0x10
1004bce84:	mov	x1, x22
1004bce88:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bce8c:	adrp	x0, 7454 ; 0x1021da000
1004bce90:	add	x0, x0, #0xc98
1004bce94:	mov	w1, #0x20
1004bce98:	mov	w2, #0x7
1004bce9c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bcea0:	mov	x23, x26
1004bcea4:	mov	x26, x0
1004bcea8:	stp	x25, x24, [x0, #0x10]
1004bceac:	mov	x0, #0x0
1004bceb0:	bl	0x1004aede4
1004bceb4:	mov	x20, x0
1004bceb8:	mov	x0, x25
1004bcebc:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bcec0:	mov	x0, x24
1004bcec4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bcec8:	mov	x8, #0x800000000000
1004bcecc:	movk	x8, #0x4071, lsl #48
1004bced0:	fmov	d2, x8
1004bced4:	fmov	d9, #28.00000000
1004bced8:	movi.2d	v0, #0000000000000000
1004bcedc:	fmov	d3, #28.00000000
1004bcee0:	mov.16b	v1, v8
1004bcee4:	str	x20, [sp, #0x18]
1004bcee8:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004bceec:	mov	x27, x0
1004bcef0:	ldr	x8, [x0]
1004bcef4:	ldr	x9, [x23]
1004bcef8:	and	x8, x9, x8
1004bcefc:	ldr	x8, [x8, #0x140]
1004bcf00:	str	x26, [sp]
1004bcf04:	adrp	x7, 4 ; 0x1004c0000
1004bcf08:	add	x7, x7, #0xe9c
1004bcf0c:	mov	w0, #0x6153
1004bcf10:	movk	w0, #0x6576, lsl #16
1004bcf14:	mov	x1, #-0x1c00000000000000
1004bcf18:	mov	w2, #0x8ce2
1004bcf1c:	movk	w2, #0x5398, lsl #16
1004bcf20:	mov	x3, #-0x5c00000000000000
1004bcf24:	mov	w4, #0x0
1004bcf28:	mov	x5, #0x0
1004bcf2c:	mov	w6, #0x1
1004bcf30:	mov	x20, x27
1004bcf34:	blr	x8
1004bcf38:	mov	x0, x28
1004bcf3c:	mov	x2, x27
1004bcf40:	bl	0x101acb460 ; selector addSubview:
1004bcf44:	ldr	x21, [x21, #0x270]
1004bcf48:	add	x0, x19, x21
1004bcf4c:	add	x1, sp, #0x28
1004bcf50:	mov	w2, #0x21
1004bcf54:	mov	x3, #0x0
1004bcf58:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bcf5c:	add	x20, x19, x21
1004bcf60:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004bcf64:	ldr	x8, [x19, x21]
1004bcf68:	and	x8, x8, #0xffffffffffffff8
1004bcf6c:	str	x28, [sp, #0x10]
1004bcf70:	ldp	x28, x8, [x8, #0x10]
1004bcf74:	cmp	x28, x8, lsr #1
1004bcf78:	b.hs	0x1004bd4a0
1004bcf7c:	mov	x0, x27
1004bcf80:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bcf84:	mov	x27, x0
1004bcf88:	add	x20, x19, x21
1004bcf8c:	mov	x0, x28
1004bcf90:	mov	x1, x27
1004bcf94:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004bcf98:	add	x0, sp, #0x28
1004bcf9c:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004bcfa0:	mov	x0, x24
1004bcfa4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bcfa8:	mov	x0, x25
1004bcfac:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bcfb0:	mov	x0, x27
1004bcfb4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bcfb8:	mov	x0, x26
1004bcfbc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bcfc0:	fadd	d8, d8, d9
1004bcfc4:	adrp	x0, 7454 ; 0x1021da000
1004bcfc8:	add	x0, x0, #0x978
1004bcfcc:	mov	w1, #0x18
1004bcfd0:	mov	w2, #0x7
1004bcfd4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bcfd8:	mov	x20, x0
1004bcfdc:	add	x0, x0, #0x10
1004bcfe0:	mov	x1, x19
1004bcfe4:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bcfe8:	adrp	x0, 7454 ; 0x1021da000
1004bcfec:	add	x0, x0, #0xb30
1004bcff0:	mov	w1, #0x18
1004bcff4:	mov	w2, #0x7
1004bcff8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bcffc:	mov	x25, x0
1004bd000:	add	x0, x0, #0x10
1004bd004:	mov	x1, x22
1004bd008:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bd00c:	adrp	x0, 7453 ; 0x1021da000
1004bd010:	add	x0, x0, #0xcc0
1004bd014:	mov	w1, #0x20
1004bd018:	mov	w2, #0x7
1004bd01c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bd020:	mov	x26, x0
1004bd024:	stp	x20, x25, [x0, #0x10]
1004bd028:	str	x20, [sp, #0x8]
1004bd02c:	mov	x0, x20
1004bd030:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bd034:	mov	x0, x25
1004bd038:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bd03c:	mov	x8, #0x800000000000
1004bd040:	movk	x8, #0x4071, lsl #48
1004bd044:	fmov	d2, x8
1004bd048:	movi.2d	v0, #0000000000000000
1004bd04c:	fmov	d3, #28.00000000
1004bd050:	mov.16b	v1, v8
1004bd054:	ldr	x23, [sp, #0x18]
1004bd058:	mov	x20, x23
1004bd05c:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004bd060:	mov	x27, x0
1004bd064:	ldr	x8, [x0]
1004bd068:	adrp	x9, 7698 ; 0x1022cf000
1004bd06c:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004bd070:	ldr	x9, [x9]
1004bd074:	and	x8, x9, x8
1004bd078:	ldr	x8, [x8, #0x140]
1004bd07c:	adrp	x7, 3 ; 0x1004c0000
1004bd080:	add	x7, x7, #0xf40
1004bd084:	str	x26, [sp]
1004bd088:	mov	x0, #0x6153
1004bd08c:	movk	x0, #0x6576, lsl #16
1004bd090:	movk	x0, #0x4120, lsl #32
1004bd094:	movk	x0, #0xe273, lsl #48
1004bd098:	mov	x2, #0x8ce2
1004bd09c:	movk	x2, #0xe298, lsl #16
1004bd0a0:	movk	x2, #0xa787, lsl #32
1004bd0a4:	movk	x2, #0x53, lsl #48
1004bd0a8:	mov	x1, #0xa680
1004bd0ac:	movk	x1, #0xaa00, lsl #48
1004bd0b0:	mov	x3, #-0x5900000000000000
1004bd0b4:	mov	w4, #0x0
1004bd0b8:	mov	x5, #0x0
1004bd0bc:	mov	w6, #0x1
1004bd0c0:	mov	x20, x27
1004bd0c4:	blr	x8
1004bd0c8:	str	x22, [sp, #0x20]
1004bd0cc:	ldr	x22, [sp, #0x10]
1004bd0d0:	mov	x0, x22
1004bd0d4:	mov	x2, x27
1004bd0d8:	bl	0x101acb460 ; selector addSubview:
1004bd0dc:	add	x0, x19, x21
1004bd0e0:	add	x1, sp, #0x28
1004bd0e4:	mov	w2, #0x21
1004bd0e8:	mov	x3, #0x0
1004bd0ec:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bd0f0:	add	x20, x19, x21
1004bd0f4:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004bd0f8:	ldr	x8, [x19, x21]
1004bd0fc:	and	x8, x8, #0xffffffffffffff8
1004bd100:	ldp	x28, x8, [x8, #0x10]
1004bd104:	cmp	x28, x8, lsr #1
1004bd108:	b.hs	0x1004bd4bc
1004bd10c:	mov	x0, x27
1004bd110:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bd114:	mov	x27, x0
1004bd118:	add	x20, x19, x21
1004bd11c:	mov	x0, x28
1004bd120:	mov	x1, x27
1004bd124:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004bd128:	add	x0, sp, #0x28
1004bd12c:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004bd130:	ldr	x0, [sp, #0x8]
1004bd134:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bd138:	mov	x0, x25
1004bd13c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bd140:	mov	x0, x27
1004bd144:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bd148:	mov	x0, x26
1004bd14c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bd150:	fadd	d8, d8, d9
1004bd154:	adrp	x0, 7453 ; 0x1021da000
1004bd158:	add	x0, x0, #0x978
1004bd15c:	mov	w1, #0x18
1004bd160:	mov	w2, #0x7
1004bd164:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bd168:	mov	x24, x0
1004bd16c:	add	x0, x0, #0x10
1004bd170:	mov	x1, x19
1004bd174:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bd178:	adrp	x0, 7453 ; 0x1021da000
1004bd17c:	add	x0, x0, #0xb30
1004bd180:	mov	w1, #0x18
1004bd184:	mov	w2, #0x7
1004bd188:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bd18c:	mov	x25, x0
1004bd190:	add	x0, x0, #0x10
1004bd194:	ldr	x1, [sp, #0x20]
1004bd198:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bd19c:	adrp	x0, 7453 ; 0x1021da000
1004bd1a0:	add	x0, x0, #0xce8
1004bd1a4:	mov	w1, #0x20
1004bd1a8:	mov	w2, #0x7
1004bd1ac:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bd1b0:	mov	x26, x0
1004bd1b4:	stp	x24, x25, [x0, #0x10]
1004bd1b8:	mov	x0, x24
1004bd1bc:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bd1c0:	mov	x0, x25
1004bd1c4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bd1c8:	mov	x8, #0x800000000000
1004bd1cc:	movk	x8, #0x4071, lsl #48
1004bd1d0:	fmov	d2, x8
1004bd1d4:	movi.2d	v0, #0000000000000000
1004bd1d8:	fmov	d3, #28.00000000
1004bd1dc:	mov.16b	v1, v8
1004bd1e0:	mov	x20, x23
1004bd1e4:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004bd1e8:	mov	x23, x0
1004bd1ec:	ldr	x8, [x0]
1004bd1f0:	adrp	x9, 7698 ; 0x1022cf000
1004bd1f4:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004bd1f8:	ldr	x9, [x9]
1004bd1fc:	and	x8, x9, x8
1004bd200:	ldr	x8, [x8, #0x140]
1004bd204:	adrp	x7, 3 ; 0x1004c0000
1004bd208:	add	x7, x7, #0xf68
1004bd20c:	str	x26, [sp]
1004bd210:	mov	x0, #0x6944
1004bd214:	movk	x0, #0x6373, lsl #16
1004bd218:	movk	x0, #0x7261, lsl #32
1004bd21c:	movk	x0, #0x2064, lsl #48
1004bd220:	mov	x1, #0x6843
1004bd224:	movk	x1, #0x6e61, lsl #16
1004bd228:	movk	x1, #0x6567, lsl #32
1004bd22c:	movk	x1, #0xef73, lsl #48
1004bd230:	mov	x2, #0x0
1004bd234:	mov	x3, #0x0
1004bd238:	mov	w4, #0x0
1004bd23c:	mov	x5, #0x0
1004bd240:	mov	w6, #0x1
1004bd244:	mov	x20, x23
1004bd248:	blr	x8
1004bd24c:	mov	x0, x22
1004bd250:	mov	x2, x23
1004bd254:	bl	0x101acb460 ; selector addSubview:
1004bd258:	add	x0, x19, x21
1004bd25c:	add	x1, sp, #0x28
1004bd260:	mov	w2, #0x21
1004bd264:	mov	x3, #0x0
1004bd268:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bd26c:	add	x20, x19, x21
1004bd270:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004bd274:	ldr	x8, [x19, x21]
1004bd278:	and	x8, x8, #0xffffffffffffff8
1004bd27c:	ldp	x27, x8, [x8, #0x10]
1004bd280:	cmp	x27, x8, lsr #1
1004bd284:	mov	x28, x22
1004bd288:	b.hs	0x1004bd4d8
1004bd28c:	mov	x0, x23
1004bd290:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bd294:	mov	x23, x0
1004bd298:	add	x20, x19, x21
1004bd29c:	mov	x0, x27
1004bd2a0:	mov	x1, x23
1004bd2a4:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004bd2a8:	add	x0, sp, #0x28
1004bd2ac:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004bd2b0:	mov	x0, x24
1004bd2b4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bd2b8:	mov	x0, x25
1004bd2bc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bd2c0:	mov	x0, x23
1004bd2c4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bd2c8:	mov	x0, x26
1004bd2cc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bd2d0:	fadd	d8, d8, d9
1004bd2d4:	adrp	x26, 7698 ; 0x1022cf000
1004bd2d8:	ldr	x26, [x26, #0x718] ; literal pool symbol address: _swift_isaMask
1004bd2dc:	ldr	x22, [sp, #0x20]
1004bd2e0:	adrp	x8, 6406 ; 0x101dc3000
1004bd2e4:	add	x8, x8, #0x440 ; literal pool for: "Reload from Disk"
1004bd2e8:	sub	x21, x8, #0x20
1004bd2ec:	adrp	x0, 7453 ; 0x1021da000
1004bd2f0:	add	x0, x0, #0x978
1004bd2f4:	mov	w1, #0x18
1004bd2f8:	mov	w2, #0x7
1004bd2fc:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bd300:	mov	x23, x0
1004bd304:	add	x0, x0, #0x10
1004bd308:	mov	x1, x19
1004bd30c:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bd310:	adrp	x0, 7453 ; 0x1021da000
1004bd314:	add	x0, x0, #0xb30
1004bd318:	mov	w1, #0x18
1004bd31c:	mov	w2, #0x7
1004bd320:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bd324:	mov	x24, x0
1004bd328:	add	x0, x0, #0x10
1004bd32c:	mov	x1, x22
1004bd330:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bd334:	adrp	x0, 7453 ; 0x1021da000
1004bd338:	add	x0, x0, #0xd10
1004bd33c:	mov	w1, #0x20
1004bd340:	mov	w2, #0x7
1004bd344:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bd348:	mov	x22, x0
1004bd34c:	stp	x23, x24, [x0, #0x10]
1004bd350:	mov	x0, #0x0
1004bd354:	bl	0x1004aede4
1004bd358:	mov	x20, x0
1004bd35c:	mov	x0, x23
1004bd360:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bd364:	mov	x0, x24
1004bd368:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bd36c:	mov	x8, #0x800000000000
1004bd370:	movk	x8, #0x4071, lsl #48
1004bd374:	fmov	d2, x8
1004bd378:	fmov	d9, #28.00000000
1004bd37c:	movi.2d	v0, #0000000000000000
1004bd380:	fmov	d3, #28.00000000
1004bd384:	mov.16b	v1, v8
1004bd388:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004bd38c:	mov	x25, x0
1004bd390:	ldr	x8, [x0]
1004bd394:	ldr	x9, [x26]
1004bd398:	and	x8, x9, x8
1004bd39c:	ldr	x8, [x8, #0x140]
1004bd3a0:	str	x22, [sp]
1004bd3a4:	adrp	x7, 3 ; 0x1004c0000
1004bd3a8:	add	x7, x7, #0xf90
1004bd3ac:	orr	x1, x21, #0x8000000000000000
1004bd3b0:	mov	x0, #0x10
1004bd3b4:	movk	x0, #0xd000, lsl #48
1004bd3b8:	mov	x2, #0x0
1004bd3bc:	mov	x3, #0x0
1004bd3c0:	mov	w4, #0x0
1004bd3c4:	mov	x5, #0x0
1004bd3c8:	mov	w6, #0x1
1004bd3cc:	mov	x20, x25
1004bd3d0:	blr	x8
1004bd3d4:	mov	x0, x28
1004bd3d8:	mov	x2, x25
1004bd3dc:	bl	0x101acb460 ; selector addSubview:
1004bd3e0:	adrp	x8, 7904 ; 0x10239d000
1004bd3e4:	ldr	x26, [x8, #0x270]
1004bd3e8:	add	x0, x19, x26
1004bd3ec:	add	x1, sp, #0x28
1004bd3f0:	mov	w2, #0x21
1004bd3f4:	mov	x3, #0x0
1004bd3f8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bd3fc:	add	x20, x19, x26
1004bd400:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004bd404:	ldr	x8, [x19, x26]
1004bd408:	and	x8, x8, #0xffffffffffffff8
1004bd40c:	ldp	x21, x8, [x8, #0x10]
1004bd410:	cmp	x21, x8, lsr #1
1004bd414:	b.hs	0x1004bd484
1004bd418:	mov	x0, x25
1004bd41c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bd420:	mov	x25, x0
1004bd424:	add	x20, x19, x26
1004bd428:	mov	x0, x21
1004bd42c:	mov	x1, x25
1004bd430:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004bd434:	add	x0, sp, #0x28
1004bd438:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004bd43c:	mov	x0, x23
1004bd440:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bd444:	mov	x0, x24
1004bd448:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bd44c:	mov	x0, x25
1004bd450:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bd454:	mov	x0, x22
1004bd458:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bd45c:	fadd	d0, d8, d9
1004bd460:	ldp	x29, x30, [sp, #0xa0]
1004bd464:	ldp	x20, x19, [sp, #0x90]
1004bd468:	ldp	x22, x21, [sp, #0x80]
1004bd46c:	ldp	x24, x23, [sp, #0x70]
1004bd470:	ldp	x26, x25, [sp, #0x60]
1004bd474:	ldp	x28, x27, [sp, #0x50]
1004bd478:	ldp	d9, d8, [sp, #0x40]
1004bd47c:	add	sp, sp, #0xb0
1004bd480:	ret
1004bd484:	cmp	x8, #0x1
1004bd488:	cset	w0, hi
1004bd48c:	add	x1, x21, #0x1
1004bd490:	add	x20, x19, x26
1004bd494:	mov	w2, #0x1
1004bd498:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004bd49c:	b	0x1004bd418
1004bd4a0:	cmp	x8, #0x1
1004bd4a4:	cset	w0, hi
1004bd4a8:	add	x1, x28, #0x1
1004bd4ac:	add	x20, x19, x21
1004bd4b0:	mov	w2, #0x1
1004bd4b4:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004bd4b8:	b	0x1004bcf7c
1004bd4bc:	cmp	x8, #0x1
1004bd4c0:	cset	w0, hi
1004bd4c4:	add	x1, x28, #0x1
1004bd4c8:	add	x20, x19, x21
1004bd4cc:	mov	w2, #0x1
1004bd4d0:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004bd4d4:	b	0x1004bd10c
1004bd4d8:	cmp	x8, #0x1
1004bd4dc:	cset	w0, hi
1004bd4e0:	add	x1, x27, #0x1
1004bd4e4:	add	x20, x19, x21
1004bd4e8:	mov	w2, #0x1
1004bd4ec:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004bd4f0:	b	0x1004bd28c
1004bd4f4:	stp	x28, x27, [sp, #-0x60]!
1004bd4f8:	stp	x26, x25, [sp, #0x10]
1004bd4fc:	stp	x24, x23, [sp, #0x20]
1004bd500:	stp	x22, x21, [sp, #0x30]
1004bd504:	stp	x20, x19, [sp, #0x40]
1004bd508:	stp	x29, x30, [sp, #0x50]
1004bd50c:	add	x29, sp, #0x50
1004bd510:	sub	sp, sp, #0x60
1004bd514:	mov	x25, x3
1004bd518:	mov	x26, x2
1004bd51c:	mov	x24, x1
1004bd520:	mov	x20, x0
1004bd524:	mov	x0, #0x0
1004bd528:	bl	0x101ac5d88 ; symbol stub for: _$s8Dispatch0A13WorkItemFlagsVMa
1004bd52c:	mov	x19, x0
1004bd530:	ldur	x8, [x0, #-0x8]
1004bd534:	stur	x8, [x29, #-0xa0]
1004bd538:	ldr	x8, [x8, #0x40]
1004bd53c:	mov	x9, x8
1004bd540:	adrp	x16, 7694 ; 0x1022cb000
1004bd544:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004bd548:	blr	x16
1004bd54c:	mov	x9, sp
1004bd550:	add	x8, x8, #0xf
1004bd554:	and	x8, x8, #0xfffffffffffffff0
1004bd558:	sub	x21, x9, x8
1004bd55c:	mov	sp, x21
1004bd560:	mov	x0, #0x0
1004bd564:	bl	0x101ac5dc4 ; symbol stub for: _$s8Dispatch0A3QoSVMa
1004bd568:	stur	x0, [x29, #-0xa8]
1004bd56c:	ldur	x22, [x0, #-0x8]
1004bd570:	ldr	x8, [x22, #0x40]
1004bd574:	mov	x9, x8
1004bd578:	adrp	x16, 7694 ; 0x1022cb000
1004bd57c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004bd580:	blr	x16
1004bd584:	mov	x9, sp
1004bd588:	add	x8, x8, #0xf
1004bd58c:	and	x8, x8, #0xfffffffffffffff0
1004bd590:	sub	x23, x9, x8
1004bd594:	mov	sp, x23
1004bd598:	add	x0, x20, #0x10
1004bd59c:	sub	x1, x29, #0x68
1004bd5a0:	mov	x2, #0x0
1004bd5a4:	mov	x3, #0x0
1004bd5a8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bd5ac:	add	x0, x20, #0x10
1004bd5b0:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004bd5b4:	cbz	x0, 0x1004bd5e0
1004bd5b8:	mov	x20, x0
1004bd5bc:	ldr	x8, [x0]
1004bd5c0:	adrp	x9, 7698 ; 0x1022cf000
1004bd5c4:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004bd5c8:	ldr	x9, [x9]
1004bd5cc:	and	x8, x9, x8
1004bd5d0:	ldr	x8, [x8, #0x248]
1004bd5d4:	blr	x8
1004bd5d8:	mov	x0, x20
1004bd5dc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bd5e0:	adrp	x1, 7811 ; 0x102340000
1004bd5e4:	add	x1, x1, #0xc40
1004bd5e8:	adrp	x2, 7785 ; 0x102326000
1004bd5ec:	add	x2, x2, #0x9d8 ; Objc class ref: _OBJC_CLASS_$_OS_dispatch_queue
1004bd5f0:	mov	x0, #0x0
1004bd5f4:	bl	0x10002d97c
1004bd5f8:	mov	x20, x0
1004bd5fc:	bl	0x101ac6e44 ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE4mainABvgZ
1004bd600:	mov	x27, x0
1004bd604:	stp	x26, x24, [x29, #-0x78]
1004bd608:	adrp	x8, 7694 ; 0x1022cb000
1004bd60c:	ldr	x8, [x8, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1004bd610:	stur	x8, [x29, #-0x98]
1004bd614:	adrp	x8, 5668 ; 0x101ae1000
1004bd618:	ldr	d0, [x8]
1004bd61c:	stur	d0, [x29, #-0x90]
1004bd620:	adrp	x8, -1209 ; 0x100004000
1004bd624:	add	x8, x8, #0xd0
1004bd628:	stp	x8, x25, [x29, #-0x88]
1004bd62c:	sub	x0, x29, #0x98
1004bd630:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004bd634:	mov	x25, x0
1004bd638:	ldur	x20, [x29, #-0x70]
1004bd63c:	mov	x0, x24
1004bd640:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bd644:	mov	x0, x20
1004bd648:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bd64c:	mov	x8, x23
1004bd650:	bl	0x101ac5da0 ; symbol stub for: _$s8Dispatch0A3QoSV11unspecifiedACvgZ
1004bd654:	adrp	x8, 7698 ; 0x1022cf000
1004bd658:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004bd65c:	stur	x8, [x29, #-0x98]
1004bd660:	adrp	x0, 7813 ; 0x102342000
1004bd664:	add	x0, x0, #0x2e0
1004bd668:	adrp	x1, 7698 ; 0x1022cf000
1004bd66c:	ldr	x1, [x1, #0x930] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVMa
1004bd670:	adrp	x2, 7698 ; 0x1022cf000
1004bd674:	ldr	x2, [x2, #0x940] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVs10SetAlgebraAAMc
1004bd678:	bl	0x10002c7c4
1004bd67c:	mov	x24, x0
1004bd680:	adrp	x20, 7811 ; 0x102340000
1004bd684:	add	x20, x20, #0xc50
1004bd688:	adrp	x26, 5668 ; 0x101ae1000
1004bd68c:	add	x26, x26, #0x280
1004bd690:	mov	x0, x20
1004bd694:	mov	x1, x26
1004bd698:	bl	0x100003c4c
1004bd69c:	mov	x28, x0
1004bd6a0:	adrp	x0, 7813 ; 0x102342000
1004bd6a4:	add	x0, x0, #0x2f0
1004bd6a8:	adrp	x3, 7697 ; 0x1022ce000
1004bd6ac:	ldr	x3, [x3, #0x238] ; literal pool symbol address: _$sSayxGSTsMc
1004bd6b0:	mov	x1, x20
1004bd6b4:	mov	x2, x26
1004bd6b8:	bl	0x10002b714
1004bd6bc:	mov	x2, x0
1004bd6c0:	sub	x0, x29, #0x98
1004bd6c4:	mov	x8, x21
1004bd6c8:	mov	x1, x28
1004bd6cc:	mov	x20, x19
1004bd6d0:	mov	x3, x19
1004bd6d4:	mov	x4, x24
1004bd6d8:	bl	0x101ac7450 ; symbol stub for: _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
1004bd6dc:	mov	x0, #0x0
1004bd6e0:	mov	x1, x23
1004bd6e4:	mov	x2, x21
1004bd6e8:	mov	x3, x25
1004bd6ec:	mov	x20, x27
1004bd6f0:	bl	0x101ac6e5c ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE5async5group3qos5flags7executeySo0a1_b1_F0CSg_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
1004bd6f4:	mov	x0, x25
1004bd6f8:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004bd6fc:	mov	x0, x27
1004bd700:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bd704:	ldur	x8, [x29, #-0xa0]
1004bd708:	ldr	x8, [x8, #0x8]
1004bd70c:	mov	x0, x21
1004bd710:	mov	x1, x19
1004bd714:	blr	x8
1004bd718:	ldr	x8, [x22, #0x8]
1004bd71c:	mov	x0, x23
1004bd720:	ldur	x1, [x29, #-0xa8]
1004bd724:	blr	x8
1004bd728:	sub	sp, x29, #0x50
1004bd72c:	ldp	x29, x30, [sp, #0x50]
1004bd730:	ldp	x20, x19, [sp, #0x40]
1004bd734:	ldp	x22, x21, [sp, #0x30]
1004bd738:	ldp	x24, x23, [sp, #0x20]
1004bd73c:	ldp	x26, x25, [sp, #0x10]
1004bd740:	ldp	x28, x27, [sp], #0x60
1004bd744:	ret
1004bd748:	sub	sp, sp, #0x90
1004bd74c:	stp	d11, d10, [sp, #0x20]
1004bd750:	stp	d9, d8, [sp, #0x30]
1004bd754:	stp	x26, x25, [sp, #0x40]
1004bd758:	stp	x24, x23, [sp, #0x50]
1004bd75c:	stp	x22, x21, [sp, #0x60]
1004bd760:	stp	x20, x19, [sp, #0x70]
1004bd764:	stp	x29, x30, [sp, #0x80]
1004bd768:	add	x29, sp, #0x80
1004bd76c:	mov	x19, x20
1004bd770:	mov	x20, x1
1004bd774:	mov.16b	v8, v0
1004bd778:	mov	x24, x0
1004bd77c:	adrp	x0, 7453 ; 0x1021da000
1004bd780:	add	x0, x0, #0x978
1004bd784:	mov	w1, #0x18
1004bd788:	mov	w2, #0x7
1004bd78c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bd790:	mov	x21, x0
1004bd794:	add	x0, x0, #0x10
1004bd798:	mov	x1, x19
1004bd79c:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bd7a0:	adrp	x0, 7453 ; 0x1021da000
1004bd7a4:	add	x0, x0, #0xae0
1004bd7a8:	mov	w1, #0x18
1004bd7ac:	mov	w2, #0x7
1004bd7b0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bd7b4:	mov	x22, x0
1004bd7b8:	add	x0, x0, #0x10
1004bd7bc:	mov	x1, x20
1004bd7c0:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bd7c4:	adrp	x0, 7453 ; 0x1021da000
1004bd7c8:	add	x0, x0, #0xb08
1004bd7cc:	mov	w1, #0x20
1004bd7d0:	mov	w2, #0x7
1004bd7d4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bd7d8:	mov	x23, x0
1004bd7dc:	stp	x22, x21, [x0, #0x10]
1004bd7e0:	mov	x0, #0x0
1004bd7e4:	bl	0x1004ad03c
1004bd7e8:	mov	x20, x0
1004bd7ec:	mov	x0, x22
1004bd7f0:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bd7f4:	mov	x0, x21
1004bd7f8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bd7fc:	mov	x8, #0x800000000000
1004bd800:	movk	x8, #0x4071, lsl #48
1004bd804:	fmov	d9, x8
1004bd808:	fmov	d10, #28.00000000
1004bd80c:	movi.2d	v0, #0000000000000000
1004bd810:	fmov	d3, #28.00000000
1004bd814:	mov.16b	v1, v8
1004bd818:	mov.16b	v2, v9
1004bd81c:	bl	0x100096d60
1004bd820:	mov	x25, x0
1004bd824:	ldr	x8, [x0]
1004bd828:	adrp	x9, 7698 ; 0x1022cf000
1004bd82c:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004bd830:	ldr	x9, [x9]
1004bd834:	and	x8, x9, x8
1004bd838:	ldr	x8, [x8, #0x198]
1004bd83c:	adrp	x3, 3 ; 0x1004c0000
1004bd840:	add	x3, x3, #0x394
1004bd844:	mov	x0, #0x6956
1004bd848:	movk	x0, #0x7765, lsl #16
1004bd84c:	movk	x0, #0x4d20, lsl #32
1004bd850:	movk	x0, #0x646f, lsl #48
1004bd854:	mov	x1, #0x65
1004bd858:	movk	x1, #0xe900, lsl #48
1004bd85c:	mov.16b	v0, v9
1004bd860:	mov	x2, x19
1004bd864:	mov	x4, x23
1004bd868:	mov	x5, #0x0
1004bd86c:	mov	x6, #0x0
1004bd870:	mov	x20, x25
1004bd874:	blr	x8
1004bd878:	mov	x0, x24
1004bd87c:	mov	x2, x25
1004bd880:	bl	0x101acb460 ; selector addSubview:
1004bd884:	adrp	x8, 7904 ; 0x10239d000
1004bd888:	ldr	x26, [x8, #0x270]
1004bd88c:	add	x0, x19, x26
1004bd890:	add	x1, sp, #0x8
1004bd894:	mov	w2, #0x21
1004bd898:	mov	x3, #0x0
1004bd89c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bd8a0:	add	x20, x19, x26
1004bd8a4:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004bd8a8:	ldr	x8, [x19, x26]
1004bd8ac:	and	x8, x8, #0xffffffffffffff8
1004bd8b0:	ldp	x24, x8, [x8, #0x10]
1004bd8b4:	cmp	x24, x8, lsr #1
1004bd8b8:	b.hs	0x1004bd928
1004bd8bc:	mov	x0, x25
1004bd8c0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bd8c4:	mov	x25, x0
1004bd8c8:	add	x20, x19, x26
1004bd8cc:	mov	x0, x24
1004bd8d0:	mov	x1, x25
1004bd8d4:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004bd8d8:	add	x0, sp, #0x8
1004bd8dc:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004bd8e0:	mov	x0, x21
1004bd8e4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bd8e8:	mov	x0, x22
1004bd8ec:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bd8f0:	mov	x0, x25
1004bd8f4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bd8f8:	mov	x0, x23
1004bd8fc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bd900:	fadd	d0, d8, d10
1004bd904:	ldp	x29, x30, [sp, #0x80]
1004bd908:	ldp	x20, x19, [sp, #0x70]
1004bd90c:	ldp	x22, x21, [sp, #0x60]
1004bd910:	ldp	x24, x23, [sp, #0x50]
1004bd914:	ldp	x26, x25, [sp, #0x40]
1004bd918:	ldp	d9, d8, [sp, #0x30]
1004bd91c:	ldp	d11, d10, [sp, #0x20]
1004bd920:	add	sp, sp, #0x90
1004bd924:	ret
1004bd928:	cmp	x8, #0x1
1004bd92c:	cset	w0, hi
1004bd930:	add	x1, x24, #0x1
1004bd934:	add	x20, x19, x26
1004bd938:	mov	w2, #0x1
1004bd93c:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004bd940:	b	0x1004bd8bc
1004bd944:	stp	x28, x27, [sp, #-0x60]!
1004bd948:	stp	x26, x25, [sp, #0x10]
1004bd94c:	stp	x24, x23, [sp, #0x20]
1004bd950:	stp	x22, x21, [sp, #0x30]
1004bd954:	stp	x20, x19, [sp, #0x40]
1004bd958:	stp	x29, x30, [sp, #0x50]
1004bd95c:	add	x29, sp, #0x50
1004bd960:	sub	sp, sp, #0x170
1004bd964:	sub	x8, x29, #0x78
1004bd968:	stur	x6, [x8, #-0x100]
1004bd96c:	mov	x22, x5
1004bd970:	sub	x8, x29, #0x58
1004bd974:	stur	x4, [x8, #-0x100]
1004bd978:	sub	x8, x29, #0x60
1004bd97c:	stur	x3, [x8, #-0x100]
1004bd980:	sub	x8, x29, #0x68
1004bd984:	stur	x2, [x8, #-0x100]
1004bd988:	mov	x19, x1
1004bd98c:	mov	x20, x0
1004bd990:	adrp	x0, 7814 ; 0x102343000
1004bd994:	add	x0, x0, #0x20
1004bd998:	adrp	x1, 5669 ; 0x101ae2000
1004bd99c:	add	x1, x1, #0x680
1004bd9a0:	bl	0x100003c4c
1004bd9a4:	ldur	x8, [x0, #-0x8]
1004bd9a8:	ldr	x9, [x8, #0x40]
1004bd9ac:	add	x8, x9, #0xf
1004bd9b0:	and	x8, x8, #0xfffffffffffffff0
1004bd9b4:	adrp	x16, 7694 ; 0x1022cb000
1004bd9b8:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004bd9bc:	blr	x16
1004bd9c0:	mov	x9, sp
1004bd9c4:	sub	x8, x9, x8
1004bd9c8:	sub	x9, x29, #0xa0
1004bd9cc:	stur	x8, [x9, #-0x100]
1004bd9d0:	mov	sp, x8
1004bd9d4:	mov	x0, #0x0
1004bd9d8:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004bd9dc:	sub	x8, x29, #0x90
1004bd9e0:	stur	x0, [x8, #-0x100]
1004bd9e4:	ldur	x13, [x0, #-0x8]
1004bd9e8:	ldr	x14, [x13, #0x40]
1004bd9ec:	mov	x9, x14
1004bd9f0:	adrp	x16, 7694 ; 0x1022cb000
1004bd9f4:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004bd9f8:	blr	x16
1004bd9fc:	mov	x8, sp
1004bda00:	add	x9, x14, #0xf
1004bda04:	and	x12, x9, #0xfffffffffffffff0
1004bda08:	sub	x8, x8, x12
1004bda0c:	sub	x9, x29, #0xb0
1004bda10:	stur	x8, [x9, #-0x100]
1004bda14:	mov	sp, x8
1004bda18:	sub	x8, x29, #0xb8
1004bda1c:	stur	x14, [x8, #-0x100]
1004bda20:	mov	x9, x14
1004bda24:	adrp	x16, 7694 ; 0x1022cb000
1004bda28:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004bda2c:	blr	x16
1004bda30:	mov	x8, sp
1004bda34:	sub	x10, x8, x12
1004bda38:	mov	sp, x10
1004bda3c:	ldr	x21, [x20, #0x8]
1004bda40:	sub	x8, x29, #0x98
1004bda44:	stur	x13, [x8, #-0x100]
1004bda48:	sub	x8, x29, #0xa8
1004bda4c:	stur	x10, [x8, #-0x100]
1004bda50:	sub	x8, x29, #0x88
1004bda54:	stur	x20, [x8, #-0x100]
1004bda58:	sub	x8, x29, #0x70
1004bda5c:	stur	x21, [x8, #-0x100]
1004bda60:	cbz	x21, 0x1004bdab0
1004bda64:	ldrb	w8, [x20, #0x10]
1004bda68:	ldr	x9, [x20]
1004bda6c:	stp	x9, x21, [x29, #-0xb0]
1004bda70:	ldur	q0, [x29, #-0xb0]
1004bda74:	stur	q0, [x29, #-0xa0]
1004bda78:	sub	x0, x29, #0xb0
1004bda7c:	sub	x1, x29, #0xc8
1004bda80:	tbz	w8, #0x0, 0x1004bdabc
1004bda84:	bl	0x1000589e8
1004bda88:	mov	x0, #0x2820
1004bda8c:	movk	x0, #0x6f77, lsl #16
1004bda90:	movk	x0, #0x6b72, lsl #32
1004bda94:	movk	x0, #0x7274, lsl #48
1004bda98:	mov	x1, #0x6565
1004bda9c:	movk	x1, #0x29, lsl #16
1004bdaa0:	movk	x1, #0xeb00, lsl #48
1004bdaa4:	sub	x20, x29, #0xa0
1004bdaa8:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004bdaac:	b	0x1004bdac0
1004bdab0:	adrp	x21, 7698 ; 0x1022cf000
1004bdab4:	ldr	x21, [x21, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004bdab8:	b	0x1004bdb80
1004bdabc:	bl	0x1000589e8
1004bdac0:	ldp	x26, x20, [x29, #-0xa0]
1004bdac4:	bl	0x1004a9938
1004bdac8:	ldp	x27, x25, [x0]
1004bdacc:	mov	x0, x25
1004bdad0:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bdad4:	mov	x0, x20
1004bdad8:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bdadc:	adrp	x3, 7698 ; 0x1022cf000
1004bdae0:	ldr	x3, [x3, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004bdae4:	adrp	x4, 7698 ; 0x1022cf000
1004bdae8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004bdaec:	mov	w0, #0x0
1004bdaf0:	mov	w1, #0x1
1004bdaf4:	mov	w2, #0x1
1004bdaf8:	bl	0x1004bfb6c
1004bdafc:	ldp	x24, x8, [x0, #0x10]
1004bdb00:	mov	x3, x0
1004bdb04:	lsr	x9, x8, #1
1004bdb08:	add	x23, x24, #0x1
1004bdb0c:	cmp	x9, x24
1004bdb10:	b.ls	0x1004be7ac
1004bdb14:	str	x23, [x3, #0x10]
1004bdb18:	mov	w10, #0x38
1004bdb1c:	madd	x10, x24, x10, x3
1004bdb20:	stp	x26, x20, [x10, #0x20]
1004bdb24:	adrp	x11, -1210 ; 0x100003000
1004bdb28:	add	x11, x11, #0xf40
1004bdb2c:	stp	x27, x25, [x10, #0x30]
1004bdb30:	stp	xzr, x11, [x10, #0x40]
1004bdb34:	str	xzr, [x10, #0x50]
1004bdb38:	add	x25, x24, #0x2
1004bdb3c:	cmp	x9, x25
1004bdb40:	b.lt	0x1004be7d8
1004bdb44:	mov	x21, x3
1004bdb48:	str	x25, [x21, #0x10]
1004bdb4c:	mov	w8, #0x38
1004bdb50:	madd	x8, x23, x8, x21
1004bdb54:	mov	x9, #-0x1d00000000000000
1004bdb58:	mov	w10, #0x2d2d
1004bdb5c:	movk	w10, #0x2d, lsl #16
1004bdb60:	stp	x10, x9, [x8, #0x20]
1004bdb64:	stp	xzr, xzr, [x8, #0x30]
1004bdb68:	adrp	x9, -1210 ; 0x100003000
1004bdb6c:	add	x9, x9, #0xf40
1004bdb70:	stp	xzr, x9, [x8, #0x40]
1004bdb74:	str	xzr, [x8, #0x50]
1004bdb78:	mov	x0, x20
1004bdb7c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bdb80:	adrp	x0, 7453 ; 0x1021da000
1004bdb84:	add	x0, x0, #0x978
1004bdb88:	mov	w1, #0x18
1004bdb8c:	mov	w2, #0x7
1004bdb90:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bdb94:	mov	x20, x0
1004bdb98:	add	x0, x19, #0x10
1004bdb9c:	sub	x1, x29, #0xc8
1004bdba0:	mov	x2, #0x0
1004bdba4:	mov	x3, #0x0
1004bdba8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bdbac:	add	x0, x19, #0x10
1004bdbb0:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004bdbb4:	mov	x23, x0
1004bdbb8:	add	x0, x20, #0x10
1004bdbbc:	mov	x1, x23
1004bdbc0:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bdbc4:	mov	x0, x23
1004bdbc8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bdbcc:	adrp	x0, 7454 ; 0x1021db000
1004bdbd0:	add	x0, x0, #0xad0
1004bdbd4:	mov	w1, #0x38
1004bdbd8:	mov	w2, #0x7
1004bdbdc:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bdbe0:	mov	x25, x0
1004bdbe4:	sub	x8, x29, #0x68
1004bdbe8:	ldur	x8, [x8, #-0x100]
1004bdbec:	stp	x20, x8, [x0, #0x10]
1004bdbf0:	sub	x8, x29, #0x60
1004bdbf4:	ldur	x24, [x8, #-0x100]
1004bdbf8:	sub	x8, x29, #0x58
1004bdbfc:	ldur	x8, [x8, #-0x100]
1004bdc00:	stp	x24, x8, [x0, #0x20]
1004bdc04:	str	x22, [x0, #0x30]
1004bdc08:	adrp	x0, 7454 ; 0x1021db000
1004bdc0c:	add	x0, x0, #0xaf8
1004bdc10:	mov	w1, #0x20
1004bdc14:	mov	w2, #0x7
1004bdc18:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bdc1c:	mov	x23, x0
1004bdc20:	adrp	x8, 8 ; 0x1004c5000
1004bdc24:	add	x8, x8, #0xb00
1004bdc28:	stp	x8, x25, [x0, #0x10]
1004bdc2c:	mov	x0, x20
1004bdc30:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bdc34:	mov	x0, x24
1004bdc38:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bdc3c:	mov	x0, x22
1004bdc40:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bdc44:	mov	x0, x21
1004bdc48:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004bdc4c:	tbz	w0, #0x0, 0x1004be63c
1004bdc50:	ldp	x24, x8, [x21, #0x10]
1004bdc54:	add	x25, x24, #0x1
1004bdc58:	cmp	x24, x8, lsr #1
1004bdc5c:	b.hs	0x1004be664
1004bdc60:	str	x25, [x21, #0x10]
1004bdc64:	mov	w8, #0x38
1004bdc68:	madd	x8, x24, x8, x21
1004bdc6c:	mov	x9, #0x7453
1004bdc70:	movk	x9, #0x6761, lsl #16
1004bdc74:	movk	x9, #0x2065, lsl #32
1004bdc78:	movk	x9, #0x6946, lsl #48
1004bdc7c:	mov	x10, #0x656c
1004bdc80:	movk	x10, #0xea00, lsl #48
1004bdc84:	stp	x9, x10, [x8, #0x20]
1004bdc88:	stp	xzr, xzr, [x8, #0x30]
1004bdc8c:	adrp	x9, -1209 ; 0x100004000
1004bdc90:	add	x9, x9, #0xcc
1004bdc94:	stp	xzr, x9, [x8, #0x40]
1004bdc98:	str	x23, [x8, #0x50]
1004bdc9c:	mov	x0, x20
1004bdca0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bdca4:	adrp	x0, 7453 ; 0x1021da000
1004bdca8:	add	x0, x0, #0x978
1004bdcac:	mov	w1, #0x18
1004bdcb0:	mov	w2, #0x7
1004bdcb4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bdcb8:	mov	x20, x0
1004bdcbc:	add	x0, x19, #0x10
1004bdcc0:	sub	x1, x29, #0xe0
1004bdcc4:	mov	x2, #0x0
1004bdcc8:	mov	x3, #0x0
1004bdccc:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bdcd0:	add	x0, x19, #0x10
1004bdcd4:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004bdcd8:	mov	x23, x0
1004bdcdc:	add	x0, x20, #0x10
1004bdce0:	mov	x1, x23
1004bdce4:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bdce8:	mov	x0, x23
1004bdcec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bdcf0:	adrp	x0, 7454 ; 0x1021db000
1004bdcf4:	add	x0, x0, #0xb20
1004bdcf8:	mov	w1, #0x38
1004bdcfc:	mov	w2, #0x7
1004bdd00:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bdd04:	mov	x25, x0
1004bdd08:	sub	x8, x29, #0x68
1004bdd0c:	ldur	x8, [x8, #-0x100]
1004bdd10:	stp	x20, x8, [x0, #0x10]
1004bdd14:	sub	x8, x29, #0x60
1004bdd18:	ldur	x27, [x8, #-0x100]
1004bdd1c:	sub	x8, x29, #0x58
1004bdd20:	ldur	x8, [x8, #-0x100]
1004bdd24:	stp	x27, x8, [x0, #0x20]
1004bdd28:	str	x22, [x0, #0x30]
1004bdd2c:	adrp	x0, 7454 ; 0x1021db000
1004bdd30:	add	x0, x0, #0xb48
1004bdd34:	mov	w1, #0x20
1004bdd38:	mov	w2, #0x7
1004bdd3c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bdd40:	mov	x23, x0
1004bdd44:	adrp	x8, 8 ; 0x1004c5000
1004bdd48:	add	x8, x8, #0xb0c
1004bdd4c:	stp	x8, x25, [x0, #0x10]
1004bdd50:	ldp	x24, x26, [x21, #0x10]
1004bdd54:	mov	x28, x21
1004bdd58:	add	x25, x24, #0x1
1004bdd5c:	mov	x0, x27
1004bdd60:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bdd64:	mov	x0, x22
1004bdd68:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bdd6c:	mov	x0, x20
1004bdd70:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bdd74:	cmp	x24, x26, lsr #1
1004bdd78:	b.hs	0x1004be68c
1004bdd7c:	mov	x21, x28
1004bdd80:	str	x25, [x21, #0x10]
1004bdd84:	mov	w8, #0x38
1004bdd88:	madd	x8, x24, x8, x21
1004bdd8c:	mov	x9, #0x6e55
1004bdd90:	movk	x9, #0x7473, lsl #16
1004bdd94:	movk	x9, #0x6761, lsl #32
1004bdd98:	movk	x9, #0x2065, lsl #48
1004bdd9c:	mov	x10, #0x6946
1004bdda0:	movk	x10, #0x656c, lsl #16
1004bdda4:	movk	x10, #0xec00, lsl #48
1004bdda8:	stp	x9, x10, [x8, #0x20]
1004bddac:	stp	xzr, xzr, [x8, #0x30]
1004bddb0:	adrp	x9, -1209 ; 0x100004000
1004bddb4:	add	x9, x9, #0xcc
1004bddb8:	stp	xzr, x9, [x8, #0x40]
1004bddbc:	str	x23, [x8, #0x50]
1004bddc0:	mov	x0, x20
1004bddc4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bddc8:	adrp	x0, 7453 ; 0x1021da000
1004bddcc:	add	x0, x0, #0x978
1004bddd0:	mov	w1, #0x18
1004bddd4:	mov	w2, #0x7
1004bddd8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bdddc:	mov	x20, x0
1004bdde0:	add	x0, x19, #0x10
1004bdde4:	sub	x1, x29, #0xf8
1004bdde8:	mov	x2, #0x0
1004bddec:	mov	x3, #0x0
1004bddf0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bddf4:	sub	x8, x29, #0x80
1004bddf8:	stur	x19, [x8, #-0x100]
1004bddfc:	add	x0, x19, #0x10
1004bde00:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004bde04:	mov	x23, x0
1004bde08:	add	x0, x20, #0x10
1004bde0c:	mov	x1, x23
1004bde10:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bde14:	mov	x0, x23
1004bde18:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bde1c:	adrp	x0, 7454 ; 0x1021db000
1004bde20:	add	x0, x0, #0xb70
1004bde24:	mov	w1, #0x40
1004bde28:	mov	w2, #0x7
1004bde2c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bde30:	mov	x25, x0
1004bde34:	sub	x8, x29, #0x68
1004bde38:	ldur	x8, [x8, #-0x100]
1004bde3c:	stp	x20, x8, [x0, #0x10]
1004bde40:	sub	x8, x29, #0x60
1004bde44:	ldur	x27, [x8, #-0x100]
1004bde48:	sub	x8, x29, #0x58
1004bde4c:	ldur	x8, [x8, #-0x100]
1004bde50:	stp	x27, x8, [x0, #0x20]
1004bde54:	sub	x8, x29, #0x78
1004bde58:	ldur	x19, [x8, #-0x100]
1004bde5c:	stp	x22, x19, [x0, #0x30]
1004bde60:	adrp	x0, 7454 ; 0x1021db000
1004bde64:	add	x0, x0, #0xb98
1004bde68:	mov	w1, #0x20
1004bde6c:	mov	w2, #0x7
1004bde70:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bde74:	mov	x23, x0
1004bde78:	adrp	x8, 8 ; 0x1004c5000
1004bde7c:	add	x8, x8, #0xc60
1004bde80:	stp	x8, x25, [x0, #0x10]
1004bde84:	ldp	x24, x26, [x21, #0x10]
1004bde88:	mov	x28, x21
1004bde8c:	add	x25, x24, #0x1
1004bde90:	mov	x0, x27
1004bde94:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bde98:	mov	x27, x22
1004bde9c:	mov	x0, x22
1004bdea0:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bdea4:	mov	x0, x20
1004bdea8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bdeac:	mov	x0, x19
1004bdeb0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bdeb4:	cmp	x24, x26, lsr #1
1004bdeb8:	b.hs	0x1004be6b4
1004bdebc:	mov	x21, x28
1004bdec0:	adrp	x8, 6428 ; 0x101dd9000
1004bdec4:	add	x8, x8, #0x440 ; literal pool for: "Discard File Changes\342\200\246"
1004bdec8:	sub	x8, x8, #0x20
1004bdecc:	orr	x8, x8, #0x8000000000000000
1004bded0:	str	x25, [x21, #0x10]
1004bded4:	mov	w9, #0x38
1004bded8:	madd	x9, x24, x9, x21
1004bdedc:	mov	x10, #0x17
1004bdee0:	movk	x10, #0x1000, lsl #48
1004bdee4:	stp	x10, x8, [x9, #0x20]
1004bdee8:	stp	xzr, xzr, [x9, #0x30]
1004bdeec:	adrp	x8, -1209 ; 0x100004000
1004bdef0:	add	x8, x8, #0xcc
1004bdef4:	stp	xzr, x8, [x9, #0x40]
1004bdef8:	str	x23, [x9, #0x50]
1004bdefc:	mov	x0, x20
1004bdf00:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bdf04:	ldp	x23, x8, [x21, #0x10]
1004bdf08:	add	x20, x23, #0x1
1004bdf0c:	cmp	x23, x8, lsr #1
1004bdf10:	mov	x22, x27
1004bdf14:	sub	x9, x29, #0x80
1004bdf18:	ldur	x19, [x9, #-0x100]
1004bdf1c:	b.hs	0x1004be6dc
1004bdf20:	str	x20, [x21, #0x10]
1004bdf24:	mov	w8, #0x38
1004bdf28:	madd	x8, x23, x8, x21
1004bdf2c:	mov	x9, #-0x1d00000000000000
1004bdf30:	mov	w10, #0x2d2d
1004bdf34:	movk	w10, #0x2d, lsl #16
1004bdf38:	stp	x10, x9, [x8, #0x20]
1004bdf3c:	stp	xzr, xzr, [x8, #0x30]
1004bdf40:	adrp	x9, -1210 ; 0x100003000
1004bdf44:	add	x9, x9, #0xf40
1004bdf48:	stp	xzr, x9, [x8, #0x40]
1004bdf4c:	str	xzr, [x8, #0x50]
1004bdf50:	adrp	x0, 7453 ; 0x1021da000
1004bdf54:	add	x0, x0, #0x978
1004bdf58:	mov	w1, #0x18
1004bdf5c:	mov	w2, #0x7
1004bdf60:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bdf64:	mov	x20, x0
1004bdf68:	add	x0, x19, #0x10
1004bdf6c:	sub	x1, x29, #0x110
1004bdf70:	mov	x2, #0x0
1004bdf74:	mov	x3, #0x0
1004bdf78:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bdf7c:	add	x0, x19, #0x10
1004bdf80:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004bdf84:	mov	x23, x0
1004bdf88:	add	x0, x20, #0x10
1004bdf8c:	mov	x1, x23
1004bdf90:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bdf94:	mov	x0, x23
1004bdf98:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bdf9c:	adrp	x0, 7454 ; 0x1021db000
1004bdfa0:	add	x0, x0, #0xbc0
1004bdfa4:	mov	w1, #0x38
1004bdfa8:	mov	w2, #0x7
1004bdfac:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bdfb0:	mov	x24, x0
1004bdfb4:	sub	x8, x29, #0x68
1004bdfb8:	ldur	x8, [x8, #-0x100]
1004bdfbc:	stp	x20, x8, [x0, #0x10]
1004bdfc0:	sub	x8, x29, #0x60
1004bdfc4:	ldur	x27, [x8, #-0x100]
1004bdfc8:	sub	x8, x29, #0x58
1004bdfcc:	ldur	x8, [x8, #-0x100]
1004bdfd0:	stp	x27, x8, [x0, #0x20]
1004bdfd4:	str	x22, [x0, #0x30]
1004bdfd8:	adrp	x0, 7454 ; 0x1021db000
1004bdfdc:	add	x0, x0, #0xbe8
1004bdfe0:	mov	w1, #0x20
1004bdfe4:	mov	w2, #0x7
1004bdfe8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bdfec:	mov	x23, x0
1004bdff0:	adrp	x8, 8 ; 0x1004c5000
1004bdff4:	add	x8, x8, #0xcec
1004bdff8:	stp	x8, x24, [x0, #0x10]
1004bdffc:	ldp	x26, x25, [x21, #0x10]
1004be000:	mov	x28, x21
1004be004:	add	x24, x26, #0x1
1004be008:	mov	x0, x27
1004be00c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004be010:	mov	x0, x22
1004be014:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004be018:	mov	x0, x20
1004be01c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004be020:	cmp	x26, x25, lsr #1
1004be024:	b.hs	0x1004be704
1004be028:	mov	x25, #0x15
1004be02c:	movk	x25, #0xd000, lsl #48
1004be030:	adrp	x8, 6427 ; 0x101dd9000
1004be034:	add	x8, x8, #0x460 ; literal pool for: "Show Diff in New Pane"
1004be038:	sub	x8, x8, #0x20
1004be03c:	orr	x8, x8, #0x8000000000000000
1004be040:	str	x24, [x28, #0x10]
1004be044:	mov	w9, #0x38
1004be048:	madd	x9, x26, x9, x28
1004be04c:	stp	x25, x8, [x9, #0x20]
1004be050:	stp	xzr, xzr, [x9, #0x30]
1004be054:	adrp	x8, -1210 ; 0x100004000
1004be058:	add	x8, x8, #0xcc
1004be05c:	stp	xzr, x8, [x9, #0x40]
1004be060:	str	x23, [x9, #0x50]
1004be064:	mov	x0, x20
1004be068:	bl	0x101aca960 ; symbol stub for: _swift_release
1004be06c:	adrp	x0, 7452 ; 0x1021da000
1004be070:	add	x0, x0, #0x978
1004be074:	mov	w1, #0x18
1004be078:	mov	w2, #0x7
1004be07c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004be080:	mov	x20, x0
1004be084:	add	x0, x19, #0x10
1004be088:	sub	x1, x29, #0x128
1004be08c:	mov	x2, #0x0
1004be090:	mov	x3, #0x0
1004be094:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004be098:	add	x0, x19, #0x10
1004be09c:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004be0a0:	mov	x23, x0
1004be0a4:	add	x0, x20, #0x10
1004be0a8:	mov	x1, x23
1004be0ac:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004be0b0:	mov	x0, x23
1004be0b4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004be0b8:	adrp	x0, 7453 ; 0x1021db000
1004be0bc:	add	x0, x0, #0xc10
1004be0c0:	mov	w1, #0x38
1004be0c4:	mov	w2, #0x7
1004be0c8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004be0cc:	mov	x24, x0
1004be0d0:	sub	x8, x29, #0x68
1004be0d4:	ldur	x8, [x8, #-0x100]
1004be0d8:	stp	x20, x8, [x0, #0x10]
1004be0dc:	sub	x8, x29, #0x60
1004be0e0:	ldur	x21, [x8, #-0x100]
1004be0e4:	sub	x8, x29, #0x58
1004be0e8:	ldur	x8, [x8, #-0x100]
1004be0ec:	stp	x21, x8, [x0, #0x20]
1004be0f0:	str	x22, [x0, #0x30]
1004be0f4:	adrp	x0, 7453 ; 0x1021db000
1004be0f8:	add	x0, x0, #0xc38
1004be0fc:	mov	w1, #0x20
1004be100:	mov	w2, #0x7
1004be104:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004be108:	mov	x23, x0
1004be10c:	adrp	x8, 7 ; 0x1004c5000
1004be110:	add	x8, x8, #0xe64
1004be114:	stp	x8, x24, [x0, #0x10]
1004be118:	ldp	x26, x27, [x28, #0x10]
1004be11c:	add	x24, x26, #0x1
1004be120:	mov	x0, x21
1004be124:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004be128:	mov	x0, x22
1004be12c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004be130:	mov	x0, x20
1004be134:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004be138:	cmp	x26, x27, lsr #1
1004be13c:	b.hs	0x1004be72c
1004be140:	adrp	x8, 6427 ; 0x101dd9000
1004be144:	add	x8, x8, #0x480 ; literal pool for: "Show File History in New Pane"
1004be148:	sub	x8, x8, #0x20
1004be14c:	orr	x8, x8, #0x8000000000000000
1004be150:	str	x24, [x28, #0x10]
1004be154:	mov	w9, #0x38
1004be158:	madd	x9, x26, x9, x28
1004be15c:	add	x10, x25, #0x8
1004be160:	stp	x10, x8, [x9, #0x20]
1004be164:	stp	xzr, xzr, [x9, #0x30]
1004be168:	adrp	x8, -1210 ; 0x100004000
1004be16c:	add	x8, x8, #0xcc
1004be170:	stp	xzr, x8, [x9, #0x40]
1004be174:	str	x23, [x9, #0x50]
1004be178:	mov	x0, x20
1004be17c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004be180:	adrp	x0, 7452 ; 0x1021da000
1004be184:	add	x0, x0, #0x978
1004be188:	mov	w1, #0x18
1004be18c:	mov	w2, #0x7
1004be190:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004be194:	mov	x20, x0
1004be198:	add	x0, x19, #0x10
1004be19c:	sub	x1, x29, #0x140
1004be1a0:	mov	x2, #0x0
1004be1a4:	mov	x3, #0x0
1004be1a8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004be1ac:	add	x0, x19, #0x10
1004be1b0:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004be1b4:	mov	x19, x0
1004be1b8:	add	x0, x20, #0x10
1004be1bc:	mov	x1, x19
1004be1c0:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004be1c4:	mov	x0, x19
1004be1c8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004be1cc:	adrp	x0, 7453 ; 0x1021db000
1004be1d0:	add	x0, x0, #0xc60
1004be1d4:	mov	w1, #0x38
1004be1d8:	mov	w2, #0x7
1004be1dc:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004be1e0:	mov	x23, x0
1004be1e4:	sub	x8, x29, #0x68
1004be1e8:	ldur	x8, [x8, #-0x100]
1004be1ec:	stp	x20, x8, [x0, #0x10]
1004be1f0:	sub	x8, x29, #0x60
1004be1f4:	ldur	x26, [x8, #-0x100]
1004be1f8:	sub	x8, x29, #0x58
1004be1fc:	ldur	x8, [x8, #-0x100]
1004be200:	stp	x26, x8, [x0, #0x20]
1004be204:	str	x22, [x0, #0x30]
1004be208:	adrp	x0, 7453 ; 0x1021db000
1004be20c:	add	x0, x0, #0xc88
1004be210:	mov	w1, #0x20
1004be214:	mov	w2, #0x7
1004be218:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004be21c:	mov	x19, x0
1004be220:	adrp	x8, 8 ; 0x1004c6000
1004be224:	add	x8, x8, #0x10
1004be228:	stp	x8, x23, [x0, #0x10]
1004be22c:	ldp	x23, x24, [x28, #0x10]
1004be230:	add	x21, x23, #0x1
1004be234:	mov	x0, x26
1004be238:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004be23c:	mov	x0, x22
1004be240:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004be244:	mov	x0, x20
1004be248:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004be24c:	cmp	x23, x24, lsr #1
1004be250:	b.hs	0x1004be754
1004be254:	mov	x26, x28
1004be258:	adrp	x8, 6427 ; 0x101dd9000
1004be25c:	add	x8, x8, #0x4a0 ; literal pool for: "Show Blame in New Pane"
1004be260:	sub	x8, x8, #0x20
1004be264:	orr	x8, x8, #0x8000000000000000
1004be268:	str	x21, [x26, #0x10]
1004be26c:	mov	w9, #0x38
1004be270:	madd	x9, x23, x9, x26
1004be274:	add	x10, x25, #0x1
1004be278:	stp	x10, x8, [x9, #0x20]
1004be27c:	stp	xzr, xzr, [x9, #0x30]
1004be280:	adrp	x8, -1210 ; 0x100004000
1004be284:	add	x8, x8, #0xcc
1004be288:	stp	xzr, x8, [x9, #0x40]
1004be28c:	str	x19, [x9, #0x50]
1004be290:	mov	x0, x20
1004be294:	bl	0x101aca960 ; symbol stub for: _swift_release
1004be298:	bl	0x100579928
1004be29c:	ldr	x19, [x0, #0x10]
1004be2a0:	cbz	x19, 0x1004be4fc
1004be2a4:	ldp	x21, x8, [x26, #0x10]
1004be2a8:	add	x20, x21, #0x1
1004be2ac:	cmp	x21, x8, lsr #1
1004be2b0:	b.hs	0x1004be77c
1004be2b4:	str	x20, [x26, #0x10]
1004be2b8:	mov	w8, #0x38
1004be2bc:	madd	x8, x21, x8, x26
1004be2c0:	mov	x9, #-0x1d00000000000000
1004be2c4:	mov	w10, #0x2d2d
1004be2c8:	movk	w10, #0x2d, lsl #16
1004be2cc:	stp	x10, x9, [x8, #0x20]
1004be2d0:	stp	xzr, xzr, [x8, #0x30]
1004be2d4:	adrp	x9, -1211 ; 0x100003000
1004be2d8:	add	x9, x9, #0xf40
1004be2dc:	stp	xzr, x9, [x8, #0x40]
1004be2e0:	str	xzr, [x8, #0x50]
1004be2e4:	sub	x8, x29, #0x78
1004be2e8:	stur	x0, [x8, #-0x100]
1004be2ec:	cbz	x19, 0x1004be478
1004be2f0:	add	x27, x0, #0x30
1004be2f4:	sub	x8, x29, #0x60
1004be2f8:	ldur	x28, [x8, #-0x100]
1004be2fc:	ldp	q0, q1, [x27, #-0x10]
1004be300:	stp	q0, q1, [x29, #-0xa0]
1004be304:	ldrb	w8, [x27, #0x10]
1004be308:	sturb	w8, [x29, #-0x80]
1004be30c:	ldp	x25, x24, [x29, #-0xa0]
1004be310:	stur	q1, [x29, #-0x70]
1004be314:	mov	x0, x24
1004be318:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004be31c:	sub	x0, x29, #0x70
1004be320:	sub	x1, x29, #0x150
1004be324:	bl	0x1000589e8
1004be328:	bl	0x1000ace0c
1004be32c:	sub	x0, x29, #0xa0
1004be330:	bl	0x10057b218
1004be334:	sub	x8, x29, #0x58
1004be338:	stur	x0, [x8, #-0x100]
1004be33c:	mov	x8, #0x704f
1004be340:	movk	x8, #0x6e65, lsl #16
1004be344:	movk	x8, #0x5220, lsl #32
1004be348:	movk	x8, #0x7065, lsl #48
1004be34c:	sub	x9, x29, #0x50
1004be350:	stur	x8, [x9, #-0x100]
1004be354:	mov	x8, #0x206f
1004be358:	movk	x8, #0x6e69, lsl #16
1004be35c:	movk	x8, #0x20, lsl #32
1004be360:	movk	x8, #0xed00, lsl #48
1004be364:	sub	x9, x29, #0x48
1004be368:	stur	x8, [x9, #-0x100]
1004be36c:	mov	x0, x24
1004be370:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004be374:	sub	x20, x29, #0x150
1004be378:	mov	x0, x25
1004be37c:	mov	x1, x24
1004be380:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004be384:	mov	x0, x24
1004be388:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004be38c:	sub	x8, x29, #0x50
1004be390:	ldur	x21, [x8, #-0x100]
1004be394:	sub	x8, x29, #0x48
1004be398:	ldur	x22, [x8, #-0x100]
1004be39c:	adrp	x0, 7453 ; 0x1021db000
1004be3a0:	add	x0, x0, #0xcb0
1004be3a4:	mov	w1, #0x41
1004be3a8:	mov	w2, #0x7
1004be3ac:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004be3b0:	mov	x24, x0
1004be3b4:	sub	x8, x29, #0x68
1004be3b8:	ldur	x8, [x8, #-0x100]
1004be3bc:	stp	x8, x28, [x0, #0x10]
1004be3c0:	ldp	q0, q1, [x29, #-0xa0]
1004be3c4:	stp	q0, q1, [x0, #0x20]
1004be3c8:	ldurb	w8, [x29, #-0x80]
1004be3cc:	strb	w8, [x0, #0x40]
1004be3d0:	adrp	x0, 7453 ; 0x1021db000
1004be3d4:	add	x0, x0, #0xcd8
1004be3d8:	mov	w1, #0x20
1004be3dc:	mov	w2, #0x7
1004be3e0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004be3e4:	mov	x20, x0
1004be3e8:	adrp	x8, 10 ; 0x1004c8000
1004be3ec:	add	x8, x8, #0x8c4
1004be3f0:	stp	x8, x24, [x0, #0x10]
1004be3f4:	mov	x23, x26
1004be3f8:	ldp	x24, x26, [x26, #0x10]
1004be3fc:	add	x25, x24, #0x1
1004be400:	mov	x0, x28
1004be404:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004be408:	cmp	x24, x26, lsr #1
1004be40c:	b.hs	0x1004be450
1004be410:	mov	x26, x23
1004be414:	str	x25, [x26, #0x10]
1004be418:	mov	w8, #0x38
1004be41c:	madd	x8, x24, x8, x26
1004be420:	stp	x21, x22, [x8, #0x20]
1004be424:	stp	xzr, xzr, [x8, #0x30]
1004be428:	sub	x9, x29, #0x58
1004be42c:	ldur	x10, [x9, #-0x100]
1004be430:	adrp	x9, -1210 ; 0x100004000
1004be434:	add	x9, x9, #0xcc
1004be438:	stp	x10, x9, [x8, #0x40]
1004be43c:	str	x20, [x8, #0x50]
1004be440:	add	x27, x27, #0x28
1004be444:	subs	x19, x19, #0x1
1004be448:	b.ne	0x1004be2fc
1004be44c:	b	0x1004be478
1004be450:	cmp	x26, #0x1
1004be454:	cset	w0, hi
1004be458:	mov	x1, x25
1004be45c:	mov	w2, #0x1
1004be460:	mov	x3, x23
1004be464:	adrp	x4, 7697 ; 0x1022cf000
1004be468:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004be46c:	bl	0x1004bfb6c
1004be470:	mov	x26, x0
1004be474:	b	0x1004be414
1004be478:	sub	x8, x29, #0x78
1004be47c:	ldur	x0, [x8, #-0x100]
1004be480:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004be484:	sub	x8, x29, #0x70
1004be488:	ldur	x8, [x8, #-0x100]
1004be48c:	cbz	x8, 0x1004be618
1004be490:	sub	x8, x29, #0x88
1004be494:	ldur	x8, [x8, #-0x100]
1004be498:	ldr	x1, [x8, #0x30]
1004be49c:	cbz	x1, 0x1004be618
1004be4a0:	ldr	x0, [x8, #0x28]
1004be4a4:	sub	x8, x29, #0xa0
1004be4a8:	ldur	x19, [x8, #-0x100]
1004be4ac:	mov	x8, x19
1004be4b0:	bl	0x101ac4e10 ; symbol stub for: _$s10Foundation3URLV6stringACSgSSh_tcfC
1004be4b4:	sub	x8, x29, #0x98
1004be4b8:	ldur	x23, [x8, #-0x100]
1004be4bc:	ldr	x8, [x23, #0x30]
1004be4c0:	mov	x0, x19
1004be4c4:	mov	w1, #0x1
1004be4c8:	sub	x9, x29, #0x90
1004be4cc:	ldur	x22, [x9, #-0x100]
1004be4d0:	mov	x2, x22
1004be4d4:	blr	x8
1004be4d8:	cmp	w0, #0x1
1004be4dc:	b.ne	0x1004be520
1004be4e0:	adrp	x1, 7813 ; 0x102343000
1004be4e4:	add	x1, x1, #0x20
1004be4e8:	adrp	x2, 5668 ; 0x101ae2000
1004be4ec:	add	x2, x2, #0x680
1004be4f0:	mov	x0, x19
1004be4f4:	bl	0x10002d870
1004be4f8:	b	0x1004be618
1004be4fc:	sub	x8, x29, #0x70
1004be500:	ldur	x8, [x8, #-0x100]
1004be504:	cbz	x8, 0x1004be518
1004be508:	sub	x8, x29, #0x88
1004be50c:	ldur	x8, [x8, #-0x100]
1004be510:	ldr	x8, [x8, #0x30]
1004be514:	cbnz	x8, 0x1004be2a4
1004be518:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004be51c:	b	0x1004be618
1004be520:	ldr	x20, [x23, #0x20]
1004be524:	sub	x8, x29, #0xa8
1004be528:	ldur	x24, [x8, #-0x100]
1004be52c:	mov	x0, x24
1004be530:	mov	x1, x19
1004be534:	mov	x2, x22
1004be538:	blr	x20
1004be53c:	ldr	x8, [x23, #0x10]
1004be540:	sub	x9, x29, #0xb0
1004be544:	ldur	x25, [x9, #-0x100]
1004be548:	mov	x0, x25
1004be54c:	mov	x1, x24
1004be550:	mov	x2, x22
1004be554:	blr	x8
1004be558:	ldrb	w8, [x23, #0x50]
1004be55c:	add	x9, x8, #0x10
1004be560:	bic	x21, x9, x8
1004be564:	adrp	x0, 7453 ; 0x1021db000
1004be568:	add	x0, x0, #0xd00
1004be56c:	sub	x9, x29, #0xb8
1004be570:	ldur	x9, [x9, #-0x100]
1004be574:	add	x1, x21, x9
1004be578:	orr	x2, x8, #0x7
1004be57c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004be580:	mov	x19, x0
1004be584:	add	x0, x0, x21
1004be588:	mov	x1, x25
1004be58c:	mov	x2, x22
1004be590:	blr	x20
1004be594:	adrp	x0, 7453 ; 0x1021db000
1004be598:	add	x0, x0, #0xd28
1004be59c:	mov	w1, #0x20
1004be5a0:	mov	w2, #0x7
1004be5a4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004be5a8:	adrp	x8, 10 ; 0x1004c8000
1004be5ac:	add	x8, x8, #0x8cc
1004be5b0:	stp	x8, x19, [x0, #0x10]
1004be5b4:	ldp	x20, x8, [x26, #0x10]
1004be5b8:	add	x19, x20, #0x1
1004be5bc:	cmp	x20, x8, lsr #1
1004be5c0:	b.hs	0x1004be7fc
1004be5c4:	str	x19, [x26, #0x10]
1004be5c8:	mov	w8, #0x38
1004be5cc:	madd	x8, x20, x8, x26
1004be5d0:	mov	x9, #0x704f
1004be5d4:	movk	x9, #0x6e65, lsl #16
1004be5d8:	movk	x9, #0x5220, lsl #32
1004be5dc:	movk	x9, #0x6d65, lsl #48
1004be5e0:	mov	x10, #0x746f
1004be5e4:	movk	x10, #0x2065, lsl #16
1004be5e8:	movk	x10, #0x5255, lsl #32
1004be5ec:	movk	x10, #0xef4c, lsl #48
1004be5f0:	stp	x9, x10, [x8, #0x20]
1004be5f4:	stp	xzr, xzr, [x8, #0x30]
1004be5f8:	adrp	x9, -1210 ; 0x100004000
1004be5fc:	add	x9, x9, #0xcc
1004be600:	stp	xzr, x9, [x8, #0x40]
1004be604:	str	x0, [x8, #0x50]
1004be608:	ldr	x8, [x23, #0x8]
1004be60c:	mov	x0, x24
1004be610:	mov	x1, x22
1004be614:	blr	x8
1004be618:	mov	x0, x26
1004be61c:	sub	sp, x29, #0x50
1004be620:	ldp	x29, x30, [sp, #0x50]
1004be624:	ldp	x20, x19, [sp, #0x40]
1004be628:	ldp	x22, x21, [sp, #0x30]
1004be62c:	ldp	x24, x23, [sp, #0x20]
1004be630:	ldp	x26, x25, [sp, #0x10]
1004be634:	ldp	x28, x27, [sp], #0x60
1004be638:	ret
1004be63c:	ldr	x8, [x21, #0x10]
1004be640:	adrp	x4, 7697 ; 0x1022cf000
1004be644:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004be648:	add	x1, x8, #0x1
1004be64c:	mov	w0, #0x0
1004be650:	mov	w2, #0x1
1004be654:	mov	x3, x21
1004be658:	bl	0x1004bfb6c
1004be65c:	mov	x21, x0
1004be660:	b	0x1004bdc50
1004be664:	cmp	x8, #0x1
1004be668:	cset	w0, hi
1004be66c:	adrp	x4, 7697 ; 0x1022cf000
1004be670:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004be674:	mov	x1, x25
1004be678:	mov	w2, #0x1
1004be67c:	mov	x3, x21
1004be680:	bl	0x1004bfb6c
1004be684:	mov	x21, x0
1004be688:	b	0x1004bdc60
1004be68c:	cmp	x26, #0x1
1004be690:	cset	w0, hi
1004be694:	adrp	x4, 7697 ; 0x1022cf000
1004be698:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004be69c:	mov	x1, x25
1004be6a0:	mov	w2, #0x1
1004be6a4:	mov	x3, x28
1004be6a8:	bl	0x1004bfb6c
1004be6ac:	mov	x21, x0
1004be6b0:	b	0x1004bdd80
1004be6b4:	cmp	x26, #0x1
1004be6b8:	cset	w0, hi
1004be6bc:	adrp	x4, 7697 ; 0x1022cf000
1004be6c0:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004be6c4:	mov	x1, x25
1004be6c8:	mov	w2, #0x1
1004be6cc:	mov	x3, x28
1004be6d0:	bl	0x1004bfb6c
1004be6d4:	mov	x21, x0
1004be6d8:	b	0x1004bdec0
1004be6dc:	cmp	x8, #0x1
1004be6e0:	cset	w0, hi
1004be6e4:	adrp	x4, 7697 ; 0x1022cf000
1004be6e8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004be6ec:	mov	x1, x20
1004be6f0:	mov	w2, #0x1
1004be6f4:	mov	x3, x21
1004be6f8:	bl	0x1004bfb6c
1004be6fc:	mov	x21, x0
1004be700:	b	0x1004bdf20
1004be704:	cmp	x25, #0x1
1004be708:	cset	w0, hi
1004be70c:	adrp	x4, 7697 ; 0x1022cf000
1004be710:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004be714:	mov	x1, x24
1004be718:	mov	w2, #0x1
1004be71c:	mov	x3, x28
1004be720:	bl	0x1004bfb6c
1004be724:	mov	x28, x0
1004be728:	b	0x1004be028
1004be72c:	cmp	x27, #0x1
1004be730:	cset	w0, hi
1004be734:	adrp	x4, 7697 ; 0x1022cf000
1004be738:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004be73c:	mov	x1, x24
1004be740:	mov	w2, #0x1
1004be744:	mov	x3, x28
1004be748:	bl	0x1004bfb6c
1004be74c:	mov	x28, x0
1004be750:	b	0x1004be140
1004be754:	cmp	x24, #0x1
1004be758:	cset	w0, hi
1004be75c:	adrp	x4, 7697 ; 0x1022cf000
1004be760:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004be764:	mov	x1, x21
1004be768:	mov	w2, #0x1
1004be76c:	mov	x3, x28
1004be770:	bl	0x1004bfb6c
1004be774:	mov	x26, x0
1004be778:	b	0x1004be258
1004be77c:	cmp	x8, #0x1
1004be780:	mov	x22, x0
1004be784:	cset	w0, hi
1004be788:	adrp	x4, 7697 ; 0x1022cf000
1004be78c:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004be790:	mov	x1, x20
1004be794:	mov	w2, #0x1
1004be798:	mov	x3, x26
1004be79c:	bl	0x1004bfb6c
1004be7a0:	mov	x26, x0
1004be7a4:	mov	x0, x22
1004be7a8:	b	0x1004be2b4
1004be7ac:	cmp	x8, #0x1
1004be7b0:	cset	w0, hi
1004be7b4:	adrp	x4, 7697 ; 0x1022cf000
1004be7b8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004be7bc:	mov	x1, x23
1004be7c0:	mov	w2, #0x1
1004be7c4:	bl	0x1004bfb6c
1004be7c8:	mov	x3, x0
1004be7cc:	ldr	x8, [x0, #0x18]
1004be7d0:	lsr	x9, x8, #1
1004be7d4:	b	0x1004bdb14
1004be7d8:	cmp	x8, #0x1
1004be7dc:	cset	w0, hi
1004be7e0:	adrp	x4, 7697 ; 0x1022cf000
1004be7e4:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004be7e8:	mov	x1, x25
1004be7ec:	mov	w2, #0x1
1004be7f0:	bl	0x1004bfb6c
1004be7f4:	mov	x21, x0
1004be7f8:	b	0x1004bdb48
1004be7fc:	cmp	x8, #0x1
1004be800:	cset	w8, hi
1004be804:	adrp	x4, 7697 ; 0x1022cf000
1004be808:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004be80c:	mov	x21, x0
1004be810:	mov	x0, x8
1004be814:	mov	x1, x19
1004be818:	mov	w2, #0x1
1004be81c:	mov	x3, x26
1004be820:	bl	0x1004bfb6c
1004be824:	mov	x26, x0
1004be828:	mov	x0, x21
1004be82c:	b	0x1004be5c4
1004be830:	stp	x28, x27, [sp, #-0x60]!
1004be834:	stp	x26, x25, [sp, #0x10]
1004be838:	stp	x24, x23, [sp, #0x20]
1004be83c:	stp	x22, x21, [sp, #0x30]
1004be840:	stp	x20, x19, [sp, #0x40]
1004be844:	stp	x29, x30, [sp, #0x50]
1004be848:	add	x29, sp, #0x50
1004be84c:	sub	sp, sp, #0x80
1004be850:	mov	x24, x20
1004be854:	stp	x2, x3, [x29, #-0xc0]
1004be858:	mov	x28, x1
1004be85c:	mov	x22, x0
1004be860:	mov	x0, #0x0
1004be864:	bl	0x101ac5d88 ; symbol stub for: _$s8Dispatch0A13WorkItemFlagsVMa
1004be868:	ldur	x8, [x0, #-0x8]
1004be86c:	stp	x8, x0, [x29, #-0x98]
1004be870:	ldr	x8, [x8, #0x40]
1004be874:	mov	x9, x8
1004be878:	adrp	x16, 7693 ; 0x1022cb000
1004be87c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004be880:	blr	x16
1004be884:	mov	x9, sp
1004be888:	add	x8, x8, #0xf
1004be88c:	and	x8, x8, #0xfffffffffffffff0
1004be890:	sub	x8, x9, x8
1004be894:	stur	x8, [x29, #-0xa0]
1004be898:	mov	sp, x8
1004be89c:	mov	x0, #0x0
1004be8a0:	bl	0x101ac5dc4 ; symbol stub for: _$s8Dispatch0A3QoSVMa
1004be8a4:	ldur	x8, [x0, #-0x8]
1004be8a8:	stp	x8, x0, [x29, #-0xb0]
1004be8ac:	ldr	x8, [x8, #0x40]
1004be8b0:	mov	x9, x8
1004be8b4:	adrp	x16, 7693 ; 0x1022cb000
1004be8b8:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004be8bc:	blr	x16
1004be8c0:	mov	x9, sp
1004be8c4:	add	x8, x8, #0xf
1004be8c8:	and	x8, x8, #0xfffffffffffffff0
1004be8cc:	sub	x23, x9, x8
1004be8d0:	mov	sp, x23
1004be8d4:	mov	x0, #0x0
1004be8d8:	bl	0x101ac5de8 ; symbol stub for: _$s8Dispatch0A4TimeVMa
1004be8dc:	stur	x0, [x29, #-0x88]
1004be8e0:	ldur	x19, [x0, #-0x8]
1004be8e4:	ldr	x8, [x19, #0x40]
1004be8e8:	mov	x9, x8
1004be8ec:	adrp	x16, 7693 ; 0x1022cb000
1004be8f0:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004be8f4:	blr	x16
1004be8f8:	mov	x9, sp
1004be8fc:	add	x10, x8, #0xf
1004be900:	and	x12, x10, #0xfffffffffffffff0
1004be904:	sub	x26, x9, x12
1004be908:	mov	sp, x26
1004be90c:	mov	x9, x8
1004be910:	adrp	x16, 7693 ; 0x1022cb000
1004be914:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004be918:	blr	x16
1004be91c:	mov	x8, sp
1004be920:	sub	x25, x8, x12
1004be924:	mov	sp, x25
1004be928:	adrp	x8, 7903 ; 0x10239d000
1004be92c:	ldr	x8, [x8, #0x250]
1004be930:	add	x0, x20, x8
1004be934:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004be938:	adrp	x21, 7697 ; 0x1022cf000
1004be93c:	ldr	x21, [x21, #0x718] ; literal pool symbol address: _swift_isaMask
1004be940:	cbz	x0, 0x1004be96c
1004be944:	mov	x20, x0
1004be948:	ldr	x8, [x0]
1004be94c:	ldr	x9, [x21]
1004be950:	and	x8, x9, x8
1004be954:	ldr	x8, [x8, #0x440]
1004be958:	blr	x8
1004be95c:	mov	x27, x0
1004be960:	mov	x0, x20
1004be964:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004be968:	b	0x1004be970
1004be96c:	mov	x27, #0x0
1004be970:	ldr	x8, [x24]
1004be974:	ldr	x9, [x21]
1004be978:	and	x8, x9, x8
1004be97c:	ldr	x8, [x8, #0x248]
1004be980:	mov	x20, x24
1004be984:	blr	x8
1004be988:	cbz	x27, 0x1004beba8
1004be98c:	bl	_$s9TextStory09BufferingA7StorageC16bufferingEnabledSbvpfi
1004be990:	ldr	x8, [x27]
1004be994:	ldr	x9, [x21]
1004be998:	and	x8, x9, x8
1004be99c:	ldr	x8, [x8, #0x3e8]
1004be9a0:	and	w6, w0, #0x1
1004be9a4:	mov	w0, #0x0
1004be9a8:	mov	w1, #0x0
1004be9ac:	mov	x2, x22
1004be9b0:	mov	x3, x28
1004be9b4:	mov	x4, #0x0
1004be9b8:	mov	x5, #0x0
1004be9bc:	mov	x20, x27
1004be9c0:	blr	x8
1004be9c4:	cbz	x0, 0x1004bebc8
1004be9c8:	mov	x28, x0
1004be9cc:	adrp	x1, 7810 ; 0x102340000
1004be9d0:	add	x1, x1, #0xc40
1004be9d4:	adrp	x2, 7784 ; 0x102326000
1004be9d8:	add	x2, x2, #0x9d8 ; Objc class ref: _OBJC_CLASS_$_OS_dispatch_queue
1004be9dc:	mov	x0, #0x0
1004be9e0:	bl	0x10002d97c
1004be9e4:	mov	x20, x0
1004be9e8:	bl	0x101ac6e44 ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE4mainABvgZ
1004be9ec:	stur	x0, [x29, #-0xd0]
1004be9f0:	mov	x8, x26
1004be9f4:	bl	0x101ac5ddc ; symbol stub for: _$s8Dispatch0A4TimeV3nowACyFZ
1004be9f8:	mov	x8, #0x3333333333333333
1004be9fc:	movk	x8, #0x3fc3, lsl #48
1004bea00:	fmov	d0, x8
1004bea04:	mov	x8, x25
1004bea08:	mov	x0, x26
1004bea0c:	bl	0x101ac5e48 ; symbol stub for: _$s8Dispatch1poiyAA0A4TimeVAD_SdtF
1004bea10:	ldr	x8, [x19, #0x8]
1004bea14:	stur	x8, [x29, #-0xc8]
1004bea18:	mov	x0, x26
1004bea1c:	ldur	x1, [x29, #-0x88]
1004bea20:	blr	x8
1004bea24:	adrp	x0, 7452 ; 0x1021da000
1004bea28:	add	x0, x0, #0xa90
1004bea2c:	mov	w1, #0x28
1004bea30:	mov	w2, #0x7
1004bea34:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bea38:	ldp	x8, x19, [x29, #-0xc0]
1004bea3c:	stp	x28, x8, [x0, #0x10]
1004bea40:	str	x19, [x0, #0x20]
1004bea44:	adrp	x8, 2 ; 0x1004c0000
1004bea48:	add	x8, x8, #0x318
1004bea4c:	stp	x8, x0, [x29, #-0x60]
1004bea50:	adrp	x8, 7693 ; 0x1022cb000
1004bea54:	ldr	x8, [x8, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1004bea58:	stur	x8, [x29, #-0x80]
1004bea5c:	adrp	x8, 5667 ; 0x101ae1000
1004bea60:	ldr	d0, [x8]
1004bea64:	stur	d0, [x29, #-0x78]
1004bea68:	adrp	x8, -1210 ; 0x100004000
1004bea6c:	add	x8, x8, #0xd0
1004bea70:	adrp	x9, 7452 ; 0x1021da000
1004bea74:	add	x9, x9, #0xaa8
1004bea78:	stp	x8, x9, [x29, #-0x70]
1004bea7c:	sub	x0, x29, #0x80
1004bea80:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004bea84:	mov	x22, x0
1004bea88:	ldur	x20, [x29, #-0x58]
1004bea8c:	mov	x0, x28
1004bea90:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bea94:	mov	x0, x19
1004bea98:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bea9c:	mov	x0, x20
1004beaa0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004beaa4:	mov	x8, x23
1004beaa8:	bl	0x101ac5da0 ; symbol stub for: _$s8Dispatch0A3QoSV11unspecifiedACvgZ
1004beaac:	adrp	x8, 7697 ; 0x1022cf000
1004beab0:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004beab4:	stur	x8, [x29, #-0x80]
1004beab8:	adrp	x0, 7812 ; 0x102342000
1004beabc:	add	x0, x0, #0x2e0
1004beac0:	adrp	x1, 7697 ; 0x1022cf000
1004beac4:	ldr	x1, [x1, #0x930] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVMa
1004beac8:	adrp	x2, 7697 ; 0x1022cf000
1004beacc:	ldr	x2, [x2, #0x940] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVs10SetAlgebraAAMc
1004bead0:	bl	0x10002c7c4
1004bead4:	mov	x24, x0
1004bead8:	adrp	x20, 7810 ; 0x102340000
1004beadc:	add	x20, x20, #0xc50
1004beae0:	adrp	x26, 5667 ; 0x101ae1000
1004beae4:	add	x26, x26, #0x280
1004beae8:	mov	x0, x20
1004beaec:	mov	x1, x26
1004beaf0:	bl	0x100003c4c
1004beaf4:	mov	x19, x0
1004beaf8:	adrp	x0, 7812 ; 0x102342000
1004beafc:	add	x0, x0, #0x2f0
1004beb00:	adrp	x3, 7696 ; 0x1022ce000
1004beb04:	ldr	x3, [x3, #0x238] ; literal pool symbol address: _$sSayxGSTsMc
1004beb08:	mov	x1, x20
1004beb0c:	mov	x2, x26
1004beb10:	bl	0x10002b714
1004beb14:	mov	x2, x0
1004beb18:	sub	x0, x29, #0x80
1004beb1c:	ldur	x21, [x29, #-0xa0]
1004beb20:	mov	x8, x21
1004beb24:	mov	x1, x19
1004beb28:	ldur	x19, [x29, #-0x90]
1004beb2c:	mov	x20, x19
1004beb30:	mov	x3, x19
1004beb34:	mov	x4, x24
1004beb38:	bl	0x101ac7450 ; symbol stub for: _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
1004beb3c:	mov	x0, x25
1004beb40:	mov	x1, x23
1004beb44:	mov	x2, x21
1004beb48:	mov	x3, x22
1004beb4c:	ldur	x20, [x29, #-0xd0]
1004beb50:	bl	0x101ac6dd8 ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE10asyncAfter8deadline3qos5flags7executeyAC0D4TimeV_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
1004beb54:	mov	x0, x27
1004beb58:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004beb5c:	mov	x0, x22
1004beb60:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004beb64:	mov	x0, x28
1004beb68:	bl	0x101aca960 ; symbol stub for: _swift_release
1004beb6c:	mov	x0, x20
1004beb70:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004beb74:	ldur	x8, [x29, #-0x98]
1004beb78:	ldr	x8, [x8, #0x8]
1004beb7c:	mov	x0, x21
1004beb80:	mov	x1, x19
1004beb84:	blr	x8
1004beb88:	ldp	x8, x1, [x29, #-0xb0]
1004beb8c:	ldr	x8, [x8, #0x8]
1004beb90:	mov	x0, x23
1004beb94:	blr	x8
1004beb98:	mov	x0, x25
1004beb9c:	ldur	x1, [x29, #-0x88]
1004beba0:	ldur	x8, [x29, #-0xc8]
1004beba4:	blr	x8
1004beba8:	sub	sp, x29, #0x50
1004bebac:	ldp	x29, x30, [sp, #0x50]
1004bebb0:	ldp	x20, x19, [sp, #0x40]
1004bebb4:	ldp	x22, x21, [sp, #0x30]
1004bebb8:	ldp	x24, x23, [sp, #0x20]
1004bebbc:	ldp	x26, x25, [sp, #0x10]
1004bebc0:	ldp	x28, x27, [sp], #0x60
1004bebc4:	ret
1004bebc8:	mov	x0, x27
1004bebcc:	sub	sp, x29, #0x50
1004bebd0:	ldp	x29, x30, [sp, #0x50]
1004bebd4:	ldp	x20, x19, [sp, #0x40]
1004bebd8:	ldp	x22, x21, [sp, #0x30]
1004bebdc:	ldp	x24, x23, [sp, #0x20]
1004bebe0:	ldp	x26, x25, [sp, #0x10]
1004bebe4:	ldp	x28, x27, [sp], #0x60
1004bebe8:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004bebec:	sub	sp, sp, #0xa0
1004bebf0:	stp	x28, x27, [sp, #0x40]
1004bebf4:	stp	x26, x25, [sp, #0x50]
1004bebf8:	stp	x24, x23, [sp, #0x60]
1004bebfc:	stp	x22, x21, [sp, #0x70]
1004bec00:	stp	x20, x19, [sp, #0x80]
1004bec04:	stp	x29, x30, [sp, #0x90]
1004bec08:	add	x29, sp, #0x90
1004bec0c:	mov	x26, x20
1004bec10:	mov	x21, x4
1004bec14:	mov	x22, x3
1004bec18:	mov	x23, x2
1004bec1c:	mov	x24, x1
1004bec20:	mov	x25, x0
1004bec24:	adrp	x8, 7784 ; 0x102326000
1004bec28:	ldr	x0, [x8, #0xaa8] ; Objc class ref: _OBJC_CLASS_$_NSAlert
1004bec2c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004bec30:	bl	0x101ace2c0 ; selector init
1004bec34:	mov	x19, x0
1004bec38:	mov	x2, #0x0
1004bec3c:	bl	0x101ad1800 ; selector setAlertStyle:
1004bec40:	adrp	x8, 6426 ; 0x101dd8000
1004bec44:	add	x8, x8, #0xed0 ; literal pool for: "Discard file changes?"
1004bec48:	sub	x8, x8, #0x20
1004bec4c:	mov	x27, #0x15
1004bec50:	movk	x27, #0xd000, lsl #48
1004bec54:	orr	x1, x8, #0x8000000000000000
1004bec58:	mov	x0, #0x15
1004bec5c:	movk	x0, #0xd000, lsl #48
1004bec60:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004bec64:	mov	x20, x0
1004bec68:	mov	x0, x19
1004bec6c:	mov	x2, x20
1004bec70:	bl	0x101ad3660 ; selector setMessageText:
1004bec74:	mov	x0, x20
1004bec78:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bec7c:	mov	x8, #-0x2000000000000000
1004bec80:	stp	xzr, x8, [sp, #0x10]
1004bec84:	add	x20, sp, #0x10
1004bec88:	mov	w0, #0x38
1004bec8c:	bl	0x101ac757c ; symbol stub for: _$ss11_StringGutsV4growyySiF
1004bec90:	ldp	x8, x9, [sp, #0x10]
1004bec94:	stp	x8, x9, [sp, #0x10]
1004bec98:	add	x20, sp, #0x10
1004bec9c:	mov	x0, x23
1004beca0:	mov	x1, x22
1004beca4:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004beca8:	adrp	x8, 6426 ; 0x101dd8000
1004becac:	add	x8, x8, #0xef0 ; literal pool for: " will be reverted to HEAD. Unsaved edits will be lost."
1004becb0:	sub	x8, x8, #0x20
1004becb4:	add	x0, x27, #0x21
1004becb8:	orr	x1, x8, #0x8000000000000000
1004becbc:	add	x20, sp, #0x10
1004becc0:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004becc4:	ldp	x0, x20, [sp, #0x10]
1004becc8:	mov	x1, x20
1004beccc:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004becd0:	mov	x27, x0
1004becd4:	mov	x0, x20
1004becd8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004becdc:	mov	x0, x19
1004bece0:	mov	x2, x27
1004bece4:	bl	0x101ad30c0 ; selector setInformativeText:
1004bece8:	mov	x0, x27
1004becec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004becf0:	mov	x0, #0x6944
1004becf4:	movk	x0, #0x6373, lsl #16
1004becf8:	movk	x0, #0x7261, lsl #32
1004becfc:	movk	x0, #0x64, lsl #48
1004bed00:	mov	x1, #-0x1900000000000000
1004bed04:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004bed08:	mov	x20, x0
1004bed0c:	mov	x0, x19
1004bed10:	mov	x2, x20
1004bed14:	bl	0x101acb200 ; selector addButtonWithTitle:
1004bed18:	mov	x29, x29
1004bed1c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bed20:	mov	x27, x0
1004bed24:	mov	x0, x20
1004bed28:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bed2c:	mov	x0, x27
1004bed30:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bed34:	mov	x0, #0x6143
1004bed38:	movk	x0, #0x636e, lsl #16
1004bed3c:	movk	x0, #0x6c65, lsl #32
1004bed40:	mov	x1, #-0x1a00000000000000
1004bed44:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004bed48:	mov	x20, x0
1004bed4c:	mov	x0, x19
1004bed50:	mov	x2, x20
1004bed54:	bl	0x101acb200 ; selector addButtonWithTitle:
1004bed58:	mov	x29, x29
1004bed5c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bed60:	mov	x27, x0
1004bed64:	mov	x0, x20
1004bed68:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bed6c:	mov	x0, x27
1004bed70:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bed74:	adrp	x0, 7452 ; 0x1021da000
1004bed78:	add	x0, x0, #0x978
1004bed7c:	mov	w1, #0x18
1004bed80:	mov	w2, #0x7
1004bed84:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bed88:	mov	x28, x0
1004bed8c:	add	x0, x0, #0x10
1004bed90:	mov	x1, x26
1004bed94:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004bed98:	adrp	x0, 7452 ; 0x1021da000
1004bed9c:	add	x0, x0, #0x9f0
1004beda0:	mov	w1, #0x40
1004beda4:	mov	w2, #0x7
1004beda8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bedac:	mov	x27, x0
1004bedb0:	stp	x28, x25, [x0, #0x10]
1004bedb4:	stp	x24, x23, [x0, #0x20]
1004bedb8:	stp	x22, x21, [x0, #0x30]
1004bedbc:	adrp	x8, 7903 ; 0x10239d000
1004bedc0:	ldr	x8, [x8, #0x250]
1004bedc4:	add	x0, x26, x8
1004bedc8:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004bedcc:	cbz	x0, 0x1004beee4
1004bedd0:	ldr	x8, [x0]
1004bedd4:	adrp	x9, 7697 ; 0x1022cf000
1004bedd8:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004beddc:	ldr	x9, [x9]
1004bede0:	and	x8, x9, x8
1004bede4:	str	x23, [sp, #0x8]
1004bede8:	mov	x23, x25
1004bedec:	ldr	x25, [x8, #0x278]
1004bedf0:	mov	x26, x0
1004bedf4:	mov	x0, x21
1004bedf8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bedfc:	mov	x0, x22
1004bee00:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bee04:	mov	x0, x24
1004bee08:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bee0c:	mov	x0, x28
1004bee10:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bee14:	mov	x20, x26
1004bee18:	blr	x25
1004bee1c:	mov	x25, x23
1004bee20:	ldr	x23, [sp, #0x8]
1004bee24:	mov	x20, x0
1004bee28:	mov	x0, x26
1004bee2c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bee30:	cbz	x20, 0x1004bef04
1004bee34:	mov	x0, x28
1004bee38:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bee3c:	adrp	x8, 2 ; 0x1004c0000
1004bee40:	add	x8, x8, #0x2b0
1004bee44:	stp	x8, x27, [sp, #0x30]
1004bee48:	adrp	x8, 7693 ; 0x1022cb000
1004bee4c:	ldr	x8, [x8, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1004bee50:	str	x8, [sp, #0x10]
1004bee54:	adrp	x8, 5667 ; 0x101ae1000
1004bee58:	ldr	d0, [x8]
1004bee5c:	str	d0, [sp, #0x18]
1004bee60:	adrp	x8, -1101 ; 0x100071000
1004bee64:	add	x8, x8, #0xb1c
1004bee68:	adrp	x9, 7452 ; 0x1021da000
1004bee6c:	add	x9, x9, #0xa08
1004bee70:	stp	x8, x9, [sp, #0x20]
1004bee74:	add	x0, sp, #0x10
1004bee78:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004bee7c:	mov	x21, x0
1004bee80:	ldr	x22, [sp, #0x38]
1004bee84:	mov	x0, x27
1004bee88:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bee8c:	mov	x0, x22
1004bee90:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bee94:	mov	x0, x19
1004bee98:	mov	x2, x20
1004bee9c:	mov	x3, x21
1004beea0:	bl	0x101acbb80 ; selector beginSheetModalForWindow:completionHandler:
1004beea4:	mov	x0, x19
1004beea8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004beeac:	mov	x0, x27
1004beeb0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004beeb4:	mov	x0, x21
1004beeb8:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004beebc:	mov	x0, x20
1004beec0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004beec4:	ldp	x29, x30, [sp, #0x90]
1004beec8:	ldp	x20, x19, [sp, #0x80]
1004beecc:	ldp	x22, x21, [sp, #0x70]
1004beed0:	ldp	x24, x23, [sp, #0x60]
1004beed4:	ldp	x26, x25, [sp, #0x50]
1004beed8:	ldp	x28, x27, [sp, #0x40]
1004beedc:	add	sp, sp, #0xa0
1004beee0:	ret
1004beee4:	mov	x0, x21
1004beee8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004beeec:	mov	x0, x22
1004beef0:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004beef4:	mov	x0, x24
1004beef8:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004beefc:	mov	x0, x28
1004bef00:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004bef04:	mov	x0, x19
1004bef08:	bl	0x101ad1040 ; selector runModal
1004bef0c:	mov	x1, x28
1004bef10:	mov	x2, x25
1004bef14:	mov	x3, x24
1004bef18:	mov	x4, x23
1004bef1c:	mov	x5, x22
1004bef20:	mov	x6, x21
1004bef24:	bl	0x1004bef5c
1004bef28:	mov	x0, x28
1004bef2c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bef30:	mov	x0, x19
1004bef34:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bef38:	mov	x0, x27
1004bef3c:	ldp	x29, x30, [sp, #0x90]
1004bef40:	ldp	x20, x19, [sp, #0x80]
1004bef44:	ldp	x22, x21, [sp, #0x70]
1004bef48:	ldp	x24, x23, [sp, #0x60]
1004bef4c:	ldp	x26, x25, [sp, #0x50]
1004bef50:	ldp	x28, x27, [sp, #0x40]
1004bef54:	add	sp, sp, #0xa0
1004bef58:	b	0x101aca960 ; symbol stub for: _swift_release
1004bef5c:	stp	x28, x27, [sp, #-0x60]!
1004bef60:	stp	x26, x25, [sp, #0x10]
1004bef64:	stp	x24, x23, [sp, #0x20]
1004bef68:	stp	x22, x21, [sp, #0x30]
1004bef6c:	stp	x20, x19, [sp, #0x40]
1004bef70:	stp	x29, x30, [sp, #0x50]
1004bef74:	add	x29, sp, #0x50
1004bef78:	sub	sp, sp, #0x50
1004bef7c:	mov	x25, x6
1004bef80:	mov	x26, x5
1004bef84:	mov	x28, x4
1004bef88:	mov	x27, x3
1004bef8c:	mov	x24, x2
1004bef90:	mov	x19, x1
1004bef94:	mov	x20, x0
1004bef98:	mov	x0, #0x0
1004bef9c:	bl	0x101ac5d88 ; symbol stub for: _$s8Dispatch0A13WorkItemFlagsVMa
1004befa0:	mov	x21, x0
1004befa4:	ldur	x8, [x0, #-0x8]
1004befa8:	stur	x8, [x29, #-0x88]
1004befac:	ldr	x8, [x8, #0x40]
1004befb0:	mov	x9, x8
1004befb4:	adrp	x16, 7693 ; 0x1022cb000
1004befb8:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004befbc:	blr	x16
1004befc0:	mov	x9, sp
1004befc4:	add	x8, x8, #0xf
1004befc8:	and	x8, x8, #0xfffffffffffffff0
1004befcc:	sub	x22, x9, x8
1004befd0:	mov	sp, x22
1004befd4:	mov	x0, #0x0
1004befd8:	bl	0x101ac5dc4 ; symbol stub for: _$s8Dispatch0A3QoSVMa
1004befdc:	ldur	x12, [x0, #-0x8]
1004befe0:	ldr	x8, [x12, #0x40]
1004befe4:	mov	x9, x8
1004befe8:	adrp	x16, 7693 ; 0x1022cb000
1004befec:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004beff0:	blr	x16
1004beff4:	mov	x9, sp
1004beff8:	add	x8, x8, #0xf
1004beffc:	and	x8, x8, #0xfffffffffffffff0
1004bf000:	sub	x23, x9, x8
1004bf004:	mov	sp, x23
1004bf008:	cmp	x20, #0x3e8
1004bf00c:	b.ne	0x1004bf2ec
1004bf010:	stp	x12, x0, [x29, #-0x98]
1004bf014:	adrp	x0, 7810 ; 0x102341000
1004bf018:	add	x0, x0, #0x6d0
1004bf01c:	adrp	x1, 5666 ; 0x101ae1000
1004bf020:	add	x1, x1, #0x7e0
1004bf024:	bl	0x100003c4c
1004bf028:	mov	w1, #0x90
1004bf02c:	mov	w2, #0x7
1004bf030:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bf034:	mov	x20, x0
1004bf038:	adrp	x8, 5674 ; 0x101ae9000
1004bf03c:	ldr	q0, [x8, #0xdc0]
1004bf040:	str	q0, [x0, #0x10]
1004bf044:	mov	w8, #0x6967
1004bf048:	movk	w8, #0x74, lsl #16
1004bf04c:	mov	x9, #-0x1d00000000000000
1004bf050:	stp	x8, x9, [x0, #0x20]
1004bf054:	mov	w8, #0x432d
1004bf058:	mov	x9, #-0x1e00000000000000
1004bf05c:	stp	x8, x9, [x0, #0x30]
1004bf060:	stp	x24, x27, [x0, #0x40]
1004bf064:	mov	x8, #0x6863
1004bf068:	movk	x8, #0x6365, lsl #16
1004bf06c:	movk	x8, #0x6f6b, lsl #32
1004bf070:	movk	x8, #0x7475, lsl #48
1004bf074:	mov	x10, #-0x1800000000000000
1004bf078:	stp	x8, x10, [x0, #0x50]
1004bf07c:	mov	w8, #0x4548
1004bf080:	movk	w8, #0x4441, lsl #16
1004bf084:	mov	x10, #-0x1c00000000000000
1004bf088:	stp	x8, x10, [x0, #0x60]
1004bf08c:	mov	w8, #0x2d2d
1004bf090:	stp	x8, x9, [x0, #0x70]
1004bf094:	stp	x28, x26, [x0, #0x80]
1004bf098:	adrp	x8, 7783 ; 0x102326000
1004bf09c:	ldr	x0, [x8, #0xa50] ; Objc class ref: _OBJC_CLASS_$_NSProcessInfo
1004bf0a0:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bf0a4:	mov	x24, x0
1004bf0a8:	mov	x0, x27
1004bf0ac:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bf0b0:	mov	x0, x26
1004bf0b4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004bf0b8:	mov	x0, x24
1004bf0bc:	bl	0x101ad04e0 ; selector processInfo
1004bf0c0:	mov	x29, x29
1004bf0c4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bf0c8:	mov	x24, x0
1004bf0cc:	bl	0x101acd780 ; selector environment
1004bf0d0:	mov	x29, x29
1004bf0d4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bf0d8:	mov	x26, x0
1004bf0dc:	mov	x0, x24
1004bf0e0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf0e4:	adrp	x1, 7695 ; 0x1022ce000
1004bf0e8:	ldr	x1, [x1, #0x38] ; literal pool symbol address: _$sSSN
1004bf0ec:	adrp	x3, 7695 ; 0x1022ce000
1004bf0f0:	ldr	x3, [x3, #0x48] ; literal pool symbol address: _$sSSSHsWP
1004bf0f4:	mov	x0, x26
1004bf0f8:	mov	x2, x1
1004bf0fc:	bl	0x101ac5ef0 ; symbol stub for: _$sSD10FoundationE36_unconditionallyBridgeFromObjectiveCySDyxq_GSo12NSDictionaryCSgFZ
1004bf100:	mov	x24, x0
1004bf104:	mov	x0, x26
1004bf108:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf10c:	sub	x8, x29, #0x80
1004bf110:	mov	x0, x20
1004bf114:	mov	x1, x24
1004bf118:	mov	x2, #0x4024000000000000
1004bf11c:	mov	w3, #0x0
1004bf120:	mov	x4, #0x0
1004bf124:	mov	x5, #-0x1000000000000000
1004bf128:	bl	0x100069800
1004bf12c:	ldur	x26, [x29, #-0x78]
1004bf130:	ldur	x0, [x29, #-0x68]
1004bf134:	ldur	w27, [x29, #-0x60]
1004bf138:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bf13c:	mov	x0, x26
1004bf140:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bf144:	mov	x0, x20
1004bf148:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bf14c:	mov	x0, x24
1004bf150:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bf154:	cbz	w27, 0x1004bf17c
1004bf158:	adrp	x1, 7811 ; 0x102342000
1004bf15c:	add	x1, x1, #0x9a0
1004bf160:	adrp	x2, 7783 ; 0x102326000
1004bf164:	add	x2, x2, #0xb48 ; Objc class ref: _OBJC_CLASS_$_NSSound
1004bf168:	mov	x0, #0x0
1004bf16c:	bl	0x10002d97c
1004bf170:	mov	x20, x0
1004bf174:	bl	0x101ac6fac ; symbol stub for: _$sSo7NSSoundC6AppKitE4beepyyFZ
1004bf178:	b	0x1004bf2ec
1004bf17c:	adrp	x1, 7809 ; 0x102340000
1004bf180:	add	x1, x1, #0xc40
1004bf184:	adrp	x2, 7783 ; 0x102326000
1004bf188:	add	x2, x2, #0x9d8 ; Objc class ref: _OBJC_CLASS_$_OS_dispatch_queue
1004bf18c:	mov	x0, #0x0
1004bf190:	bl	0x10002d97c
1004bf194:	mov	x20, x0
1004bf198:	bl	0x101ac6e44 ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE4mainABvgZ
1004bf19c:	mov	x26, x0
1004bf1a0:	adrp	x0, 7451 ; 0x1021da000
1004bf1a4:	add	x0, x0, #0xa40
1004bf1a8:	mov	w1, #0x18
1004bf1ac:	mov	w2, #0x7
1004bf1b0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bf1b4:	str	x25, [x0, #0x10]
1004bf1b8:	adrp	x8, 1 ; 0x1004c0000
1004bf1bc:	add	x8, x8, #0x2e4
1004bf1c0:	stp	x8, x0, [x29, #-0x60]
1004bf1c4:	adrp	x8, 7692 ; 0x1022cb000
1004bf1c8:	ldr	x8, [x8, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1004bf1cc:	stur	x8, [x29, #-0x80]
1004bf1d0:	adrp	x8, 5666 ; 0x101ae1000
1004bf1d4:	ldr	d0, [x8]
1004bf1d8:	stur	d0, [x29, #-0x78]
1004bf1dc:	adrp	x8, -1211 ; 0x100004000
1004bf1e0:	add	x8, x8, #0xd0
1004bf1e4:	adrp	x9, 7451 ; 0x1021da000
1004bf1e8:	add	x9, x9, #0xa58
1004bf1ec:	stp	x8, x9, [x29, #-0x70]
1004bf1f0:	sub	x0, x29, #0x80
1004bf1f4:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004bf1f8:	mov	x24, x0
1004bf1fc:	ldur	x20, [x29, #-0x58]
1004bf200:	mov	x0, x25
1004bf204:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bf208:	mov	x0, x20
1004bf20c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bf210:	mov	x8, x23
1004bf214:	bl	0x101ac5da0 ; symbol stub for: _$s8Dispatch0A3QoSV11unspecifiedACvgZ
1004bf218:	adrp	x8, 7696 ; 0x1022cf000
1004bf21c:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004bf220:	stur	x8, [x29, #-0x80]
1004bf224:	adrp	x0, 7811 ; 0x102342000
1004bf228:	add	x0, x0, #0x2e0
1004bf22c:	adrp	x1, 7696 ; 0x1022cf000
1004bf230:	ldr	x1, [x1, #0x930] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVMa
1004bf234:	adrp	x2, 7696 ; 0x1022cf000
1004bf238:	ldr	x2, [x2, #0x940] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVs10SetAlgebraAAMc
1004bf23c:	bl	0x10002c7c4
1004bf240:	mov	x25, x0
1004bf244:	adrp	x20, 7809 ; 0x102340000
1004bf248:	add	x20, x20, #0xc50
1004bf24c:	adrp	x27, 5666 ; 0x101ae1000
1004bf250:	add	x27, x27, #0x280
1004bf254:	mov	x0, x20
1004bf258:	mov	x1, x27
1004bf25c:	bl	0x100003c4c
1004bf260:	mov	x28, x0
1004bf264:	adrp	x0, 7811 ; 0x102342000
1004bf268:	add	x0, x0, #0x2f0
1004bf26c:	adrp	x3, 7695 ; 0x1022ce000
1004bf270:	ldr	x3, [x3, #0x238] ; literal pool symbol address: _$sSayxGSTsMc
1004bf274:	mov	x1, x20
1004bf278:	mov	x2, x27
1004bf27c:	bl	0x10002b714
1004bf280:	mov	x2, x0
1004bf284:	sub	x0, x29, #0x80
1004bf288:	mov	x8, x22
1004bf28c:	mov	x1, x28
1004bf290:	mov	x20, x21
1004bf294:	mov	x3, x21
1004bf298:	mov	x4, x25
1004bf29c:	bl	0x101ac7450 ; symbol stub for: _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
1004bf2a0:	mov	x0, #0x0
1004bf2a4:	mov	x1, x23
1004bf2a8:	mov	x2, x22
1004bf2ac:	mov	x3, x24
1004bf2b0:	mov	x20, x26
1004bf2b4:	bl	0x101ac6e5c ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE5async5group3qos5flags7executeySo0a1_b1_F0CSg_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
1004bf2b8:	mov	x0, x24
1004bf2bc:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004bf2c0:	mov	x0, x26
1004bf2c4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf2c8:	ldur	x8, [x29, #-0x88]
1004bf2cc:	ldr	x8, [x8, #0x8]
1004bf2d0:	mov	x0, x22
1004bf2d4:	mov	x1, x21
1004bf2d8:	blr	x8
1004bf2dc:	ldp	x8, x1, [x29, #-0x98]
1004bf2e0:	ldr	x8, [x8, #0x8]
1004bf2e4:	mov	x0, x23
1004bf2e8:	blr	x8
1004bf2ec:	add	x0, x19, #0x10
1004bf2f0:	sub	x1, x29, #0x80
1004bf2f4:	mov	x2, #0x0
1004bf2f8:	mov	x3, #0x0
1004bf2fc:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004bf300:	add	x0, x19, #0x10
1004bf304:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004bf308:	cbz	x0, 0x1004bf334
1004bf30c:	mov	x20, x0
1004bf310:	ldr	x8, [x0]
1004bf314:	adrp	x9, 7696 ; 0x1022cf000
1004bf318:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004bf31c:	ldr	x9, [x9]
1004bf320:	and	x8, x9, x8
1004bf324:	ldr	x8, [x8, #0x248]
1004bf328:	blr	x8
1004bf32c:	mov	x0, x20
1004bf330:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf334:	sub	sp, x29, #0x50
1004bf338:	ldp	x29, x30, [sp, #0x50]
1004bf33c:	ldp	x20, x19, [sp, #0x40]
1004bf340:	ldp	x22, x21, [sp, #0x30]
1004bf344:	ldp	x24, x23, [sp, #0x20]
1004bf348:	ldp	x26, x25, [sp, #0x10]
1004bf34c:	ldp	x28, x27, [sp], #0x60
1004bf350:	ret
1004bf354:	adrp	x1, -15 ; 0x1004b0000
1004bf358:	add	x1, x1, #0x2a4
1004bf35c:	mov	x0, #0x0
1004bf360:	b	0x1004bf364
1004bf364:	sub	sp, sp, #0x20
1004bf368:	stp	x29, x30, [sp, #0x10]
1004bf36c:	add	x29, sp, #0x10
1004bf370:	blr	x1
1004bf374:	stp	x20, x0, [sp]
1004bf378:	adrp	x8, 7778 ; 0x102321000
1004bf37c:	ldr	x1, [x8, #0x2d8] ; Objc selector ref: dealloc
1004bf380:	mov	x0, sp
1004bf384:	bl	0x101ac9d0c ; Objc message: -[[x0 super] dealloc]
1004bf388:	ldp	x29, x30, [sp, #0x10]
1004bf38c:	add	sp, sp, #0x20
1004bf390:	ret
1004bf394:	stp	x20, x19, [sp, #-0x20]!
1004bf398:	stp	x29, x30, [sp, #0x10]
1004bf39c:	add	x29, sp, #0x10
1004bf3a0:	mov	x19, x0
1004bf3a4:	adrp	x8, 7830 ; 0x102355000
1004bf3a8:	ldr	x8, [x8, #0xd0]
1004bf3ac:	ldr	x0, [x0, x8]
1004bf3b0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf3b4:	adrp	x8, 7830 ; 0x102355000
1004bf3b8:	ldr	x8, [x8, #0xe0]
1004bf3bc:	add	x0, x19, x8
1004bf3c0:	bl	0x101acaabc ; symbol stub for: _swift_unknownObjectWeakDestroy
1004bf3c4:	adrp	x8, 7830 ; 0x102355000
1004bf3c8:	ldr	x8, [x8, #0xe8]
1004bf3cc:	ldr	x0, [x19, x8]
1004bf3d0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf3d4:	adrp	x8, 7902 ; 0x10239d000
1004bf3d8:	ldr	x8, [x8, #0x288]
1004bf3dc:	adrp	x1, 7810 ; 0x102341000
1004bf3e0:	add	x1, x1, #0x790
1004bf3e4:	adrp	x2, 5666 ; 0x101ae1000
1004bf3e8:	add	x2, x2, #0xd90
1004bf3ec:	add	x0, x19, x8
1004bf3f0:	bl	0x10002d870
1004bf3f4:	adrp	x8, 7902 ; 0x10239d000
1004bf3f8:	ldr	x8, [x8, #0x258]
1004bf3fc:	adrp	x1, 7809 ; 0x102340000
1004bf400:	add	x1, x1, #0xc30
1004bf404:	adrp	x2, 5666 ; 0x101ae1000
1004bf408:	add	x2, x2, #0x100
1004bf40c:	add	x0, x19, x8
1004bf410:	bl	0x10002d870
1004bf414:	adrp	x8, 7902 ; 0x10239d000
1004bf418:	ldr	x8, [x8, #0x260]
1004bf41c:	ldr	x0, [x19, x8]
1004bf420:	bl	0x101acaa68 ; symbol stub for: _swift_unknownObjectRelease
1004bf424:	adrp	x8, 7902 ; 0x10239d000
1004bf428:	ldr	x8, [x8, #0x268]
1004bf42c:	ldr	x0, [x19, x8]
1004bf430:	bl	0x101acaa68 ; symbol stub for: _swift_unknownObjectRelease
1004bf434:	adrp	x8, 7902 ; 0x10239d000
1004bf438:	ldr	x8, [x8, #0x248]
1004bf43c:	add	x0, x19, x8
1004bf440:	bl	0x101acab4c ; symbol stub for: _swift_weakDestroy
1004bf444:	adrp	x8, 7902 ; 0x10239d000
1004bf448:	ldr	x8, [x8, #0x250]
1004bf44c:	add	x0, x19, x8
1004bf450:	bl	0x101acaabc ; symbol stub for: _swift_unknownObjectWeakDestroy
1004bf454:	adrp	x8, 7902 ; 0x10239d000
1004bf458:	ldr	x8, [x8, #0x280]
1004bf45c:	add	x0, x19, x8
1004bf460:	bl	0x101acab4c ; symbol stub for: _swift_weakDestroy
1004bf464:	adrp	x8, 7902 ; 0x10239d000
1004bf468:	ldr	x8, [x8, #0x270]
1004bf46c:	ldr	x0, [x19, x8]
1004bf470:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bf474:	adrp	x8, 7902 ; 0x10239d000
1004bf478:	ldr	x8, [x8, #0x290]
1004bf47c:	ldr	x0, [x19, x8]
1004bf480:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf484:	adrp	x8, 7902 ; 0x10239d000
1004bf488:	ldr	x8, [x8, #0x298]
1004bf48c:	ldr	x0, [x19, x8]
1004bf490:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf494:	adrp	x8, 7902 ; 0x10239d000
1004bf498:	ldr	x8, [x8, #0x2a0]
1004bf49c:	ldr	x0, [x19, x8]
1004bf4a0:	ldp	x29, x30, [sp, #0x10]
1004bf4a4:	ldp	x20, x19, [sp], #0x20
1004bf4a8:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004bf4ac:	stp	x22, x21, [sp, #-0x30]!
1004bf4b0:	stp	x20, x19, [sp, #0x10]
1004bf4b4:	stp	x29, x30, [sp, #0x20]
1004bf4b8:	add	x29, sp, #0x20
1004bf4bc:	mov	x21, x2
1004bf4c0:	mov	x19, x0
1004bf4c4:	adrp	x8, 7778 ; 0x102321000
1004bf4c8:	ldr	x1, [x8, #0x590] ; Objc selector ref: insertNewline:
1004bf4cc:	mov	x0, x2
1004bf4d0:	bl	0x101ac51d0 ; symbol stub for: _$s10ObjectiveC8SelectorV2eeoiySbAC_ACtFZ
1004bf4d4:	tbz	w0, #0x0, 0x1004bf504
1004bf4d8:	adrp	x8, 7783 ; 0x102326000
1004bf4dc:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004bf4e0:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bf4e4:	mov	x1, x0
1004bf4e8:	mov	x0, x19
1004bf4ec:	mov	x2, #0x0
1004bf4f0:	mov	w3, #0x0
1004bf4f4:	mov	w4, #0x0
1004bf4f8:	bl	0x101aca720 ; symbol stub for: _swift_dynamicCastObjCClassUnconditional
1004bf4fc:	bl	0x1004b5d84
1004bf500:	b	0x1004bf534
1004bf504:	adrp	x8, 7778 ; 0x102321000
1004bf508:	ldr	x1, [x8, #0x828] ; Objc selector ref: cancelOperation:
1004bf50c:	mov	x0, x21
1004bf510:	bl	0x101ac51d0 ; symbol stub for: _$s10ObjectiveC8SelectorV2eeoiySbAC_ACtFZ
1004bf514:	tbz	w0, #0x0, 0x1004bf53c
1004bf518:	ldr	x8, [x20]
1004bf51c:	adrp	x9, 7696 ; 0x1022cf000
1004bf520:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004bf524:	ldr	x9, [x9]
1004bf528:	and	x8, x9, x8
1004bf52c:	ldr	x8, [x8, #0x248]
1004bf530:	blr	x8
1004bf534:	mov	w0, #0x1
1004bf538:	b	0x1004bf540
1004bf53c:	mov	w0, #0x0
1004bf540:	ldp	x29, x30, [sp, #0x20]
1004bf544:	ldp	x20, x19, [sp, #0x10]
1004bf548:	ldp	x22, x21, [sp], #0x30
1004bf54c:	ret
1004bf550:	stp	x29, x30, [sp, #-0x10]!
1004bf554:	mov	x29, sp
1004bf558:	adrp	x0, 7794 ; 0x102331000
1004bf55c:	add	x0, x0, #0x670
1004bf560:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bf564:	mov	x1, #0x0
1004bf568:	ldp	x29, x30, [sp], #0x10
1004bf56c:	ret
1004bf570:	mov	x0, #0x0
1004bf574:	b	0x1004b02a4
1004bf578:	sub	sp, sp, #0xf0
1004bf57c:	stp	x22, x21, [sp, #0xc0]
1004bf580:	stp	x20, x19, [sp, #0xd0]
1004bf584:	stp	x29, x30, [sp, #0xe0]
1004bf588:	add	x29, sp, #0xe0
1004bf58c:	mov	x19, x0
1004bf590:	adrp	x20, 5686 ; 0x101af5000
1004bf594:	add	x20, x20, #0xdb8
1004bf598:	adrp	x21, 5686 ; 0x101af5000
1004bf59c:	add	x21, x21, #0xdd0
1004bf5a0:	stp	x20, x21, [sp, #0x8]
1004bf5a4:	str	x20, [sp, #0x18]
1004bf5a8:	mov	w0, #0x13f
1004bf5ac:	bl	0x1001b4b34
1004bf5b0:	cmp	x1, #0x3f
1004bf5b4:	b.hi	0x1004bf634
1004bf5b8:	ldur	x8, [x0, #-0x8]
1004bf5bc:	add	x8, x8, #0x40
1004bf5c0:	adrp	x9, 5686 ; 0x101af5000
1004bf5c4:	add	x9, x9, #0xde8
1004bf5c8:	stp	x8, x9, [sp, #0x20]
1004bf5cc:	stp	x20, x20, [sp, #0x30]
1004bf5d0:	stp	x21, x21, [sp, #0x40]
1004bf5d4:	adrp	x8, 7694 ; 0x1022cd000
1004bf5d8:	ldr	x8, [x8, #0xb98] ; literal pool symbol address: _$sBi64_WV
1004bf5dc:	add	x8, x8, #0x40
1004bf5e0:	stp	x21, x8, [sp, #0x50]
1004bf5e4:	stp	x8, x8, [sp, #0x60]
1004bf5e8:	adrp	x9, 7694 ; 0x1022cd000
1004bf5ec:	ldr	x9, [x9, #0xb80] ; literal pool symbol address: _$sBbWV
1004bf5f0:	stp	x8, x8, [sp, #0x70]
1004bf5f4:	add	x9, x9, #0x40
1004bf5f8:	stp	x9, x8, [sp, #0x80]
1004bf5fc:	adrp	x9, 5686 ; 0x101af5000
1004bf600:	add	x9, x9, #0xe00
1004bf604:	stp	x9, x20, [sp, #0x90]
1004bf608:	stp	x20, x20, [sp, #0xa0]
1004bf60c:	stp	x8, x8, [sp, #0xb0]
1004bf610:	add	x3, sp, #0x8
1004bf614:	add	x4, x19, #0x50
1004bf618:	mov	x0, x19
1004bf61c:	mov	w1, #0x100
1004bf620:	mov	w2, #0x17
1004bf624:	bl	0x101acab1c ; symbol stub for: _swift_updateClassMetadata2
1004bf628:	cbnz	x0, 0x1004bf638
1004bf62c:	mov	x1, #0x0
1004bf630:	b	0x1004bf638
1004bf634:	mov	w1, #0x3f
1004bf638:	ldp	x29, x30, [sp, #0xe0]
1004bf63c:	ldp	x20, x19, [sp, #0xd0]
1004bf640:	ldp	x22, x21, [sp, #0xc0]
1004bf644:	add	sp, sp, #0xf0
1004bf648:	ret
1004bf64c:	stp	x24, x23, [sp, #-0x40]!
1004bf650:	stp	x22, x21, [sp, #0x10]
1004bf654:	stp	x20, x19, [sp, #0x20]
1004bf658:	stp	x29, x30, [sp, #0x30]
1004bf65c:	add	x29, sp, #0x30
1004bf660:	mov	x22, x4
1004bf664:	mov	x20, x3
1004bf668:	mov	x23, x0
1004bf66c:	adrp	x8, 7778 ; 0x102321000
1004bf670:	ldr	x24, [x8, #0x590] ; Objc selector ref: insertNewline:
1004bf674:	mov	x0, x2
1004bf678:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bf67c:	mov	x19, x0
1004bf680:	mov	x0, x20
1004bf684:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bf688:	mov	x21, x0
1004bf68c:	mov	x0, x23
1004bf690:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bf694:	mov	x20, x0
1004bf698:	mov	x0, x22
1004bf69c:	mov	x1, x24
1004bf6a0:	bl	0x101ac51d0 ; symbol stub for: _$s10ObjectiveC8SelectorV2eeoiySbAC_ACtFZ
1004bf6a4:	tbz	w0, #0x0, 0x1004bf6d8
1004bf6a8:	adrp	x8, 7783 ; 0x102326000
1004bf6ac:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004bf6b0:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bf6b4:	mov	x1, x0
1004bf6b8:	mov	x0, x19
1004bf6bc:	mov	x2, #0x0
1004bf6c0:	mov	w3, #0x0
1004bf6c4:	mov	w4, #0x0
1004bf6c8:	bl	0x101aca720 ; symbol stub for: _swift_dynamicCastObjCClassUnconditional
1004bf6cc:	bl	0x1004b5d84
1004bf6d0:	mov	w22, #0x1
1004bf6d4:	b	0x1004bf714
1004bf6d8:	adrp	x8, 7778 ; 0x102321000
1004bf6dc:	ldr	x1, [x8, #0x828] ; Objc selector ref: cancelOperation:
1004bf6e0:	mov	x0, x22
1004bf6e4:	bl	0x101ac51d0 ; symbol stub for: _$s10ObjectiveC8SelectorV2eeoiySbAC_ACtFZ
1004bf6e8:	tbz	w0, #0x0, 0x1004bf710
1004bf6ec:	ldr	x8, [x20]
1004bf6f0:	adrp	x9, 7696 ; 0x1022cf000
1004bf6f4:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004bf6f8:	ldr	x9, [x9]
1004bf6fc:	and	x8, x9, x8
1004bf700:	ldr	x8, [x8, #0x248]
1004bf704:	blr	x8
1004bf708:	mov	w22, #0x1
1004bf70c:	b	0x1004bf714
1004bf710:	mov	w22, #0x0
1004bf714:	mov	x0, x20
1004bf718:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf71c:	mov	x0, x19
1004bf720:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf724:	mov	x0, x21
1004bf728:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf72c:	mov	x0, x22
1004bf730:	ldp	x29, x30, [sp, #0x30]
1004bf734:	ldp	x20, x19, [sp, #0x20]
1004bf738:	ldp	x22, x21, [sp, #0x10]
1004bf73c:	ldp	x24, x23, [sp], #0x40
1004bf740:	ret
1004bf744:	sub	sp, sp, #0x60
1004bf748:	stp	d11, d10, [sp, #0x10]
1004bf74c:	stp	d9, d8, [sp, #0x20]
1004bf750:	stp	x22, x21, [sp, #0x30]
1004bf754:	stp	x20, x19, [sp, #0x40]
1004bf758:	stp	x29, x30, [sp, #0x50]
1004bf75c:	add	x29, sp, #0x50
1004bf760:	bl	0x1004bfa04
1004bf764:	stp	x20, x0, [sp]
1004bf768:	adrp	x8, 7781 ; 0x102324000
1004bf76c:	ldr	x1, [x8, #0xea8] ; Objc selector ref: updateTrackingAreas
1004bf770:	mov	x0, sp
1004bf774:	bl	0x101ac9d0c ; Objc message: -[[x0 super] updateTrackingAreas]
1004bf778:	adrp	x8, 7830 ; 0x102355000
1004bf77c:	ldr	x21, [x8, #0x150]
1004bf780:	ldr	x2, [x20, x21]
1004bf784:	cbz	x2, 0x1004bf790
1004bf788:	mov	x0, x20
1004bf78c:	bl	0x101ad0c40 ; selector removeTrackingArea:
1004bf790:	mov	x0, x20
1004bf794:	bl	0x101acbde0 ; selector bounds
1004bf798:	mov.16b	v8, v0
1004bf79c:	mov.16b	v9, v1
1004bf7a0:	mov.16b	v10, v2
1004bf7a4:	mov.16b	v11, v3
1004bf7a8:	adrp	x8, 7783 ; 0x102326000
1004bf7ac:	ldr	x0, [x8, #0xa48] ; Objc class ref: _OBJC_CLASS_$_NSTrackingArea
1004bf7b0:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004bf7b4:	mov.16b	v0, v8
1004bf7b8:	mov.16b	v1, v9
1004bf7bc:	mov.16b	v2, v10
1004bf7c0:	mov.16b	v3, v11
1004bf7c4:	mov	x3, x20
1004bf7c8:	mov	w2, #0x81
1004bf7cc:	mov	x4, #0x0
1004bf7d0:	bl	0x101ace7c0 ; selector initWithRect:options:owner:userInfo:
1004bf7d4:	mov	x19, x0
1004bf7d8:	mov	x0, x20
1004bf7dc:	mov	x2, x19
1004bf7e0:	bl	0x101acb540 ; selector addTrackingArea:
1004bf7e4:	ldr	x0, [x20, x21]
1004bf7e8:	str	x19, [x20, x21]
1004bf7ec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf7f0:	ldp	x29, x30, [sp, #0x50]
1004bf7f4:	ldp	x20, x19, [sp, #0x40]
1004bf7f8:	ldp	x22, x21, [sp, #0x30]
1004bf7fc:	ldp	d9, d8, [sp, #0x20]
1004bf800:	ldp	d11, d10, [sp, #0x10]
1004bf804:	add	sp, sp, #0x60
1004bf808:	ret
1004bf80c:	stp	x20, x19, [sp, #-0x20]!
1004bf810:	stp	x29, x30, [sp, #0x10]
1004bf814:	add	x29, sp, #0x10
1004bf818:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bf81c:	mov	x20, x0
1004bf820:	bl	0x1004bf744
1004bf824:	mov	x0, x20
1004bf828:	ldp	x29, x30, [sp, #0x10]
1004bf82c:	ldp	x20, x19, [sp], #0x20
1004bf830:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004bf834:	stp	x22, x21, [sp, #-0x30]!
1004bf838:	stp	x20, x19, [sp, #0x10]
1004bf83c:	stp	x29, x30, [sp, #0x20]
1004bf840:	add	x29, sp, #0x20
1004bf844:	mov	x19, x0
1004bf848:	mov	x0, x2
1004bf84c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bf850:	mov	x21, x0
1004bf854:	mov	x0, x19
1004bf858:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bf85c:	mov	x20, x0
1004bf860:	bl	0x1004c0140
1004bf864:	mov	x0, x21
1004bf868:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf86c:	mov	x0, x20
1004bf870:	ldp	x29, x30, [sp, #0x20]
1004bf874:	ldp	x20, x19, [sp, #0x10]
1004bf878:	ldp	x22, x21, [sp], #0x30
1004bf87c:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004bf880:	stp	x22, x21, [sp, #-0x30]!
1004bf884:	stp	x20, x19, [sp, #0x10]
1004bf888:	stp	x29, x30, [sp, #0x20]
1004bf88c:	add	x29, sp, #0x20
1004bf890:	mov	x19, x0
1004bf894:	mov	x0, x2
1004bf898:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bf89c:	mov	x21, x0
1004bf8a0:	mov	x0, x19
1004bf8a4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bf8a8:	mov	x20, x0
1004bf8ac:	bl	0x1004c0238
1004bf8b0:	mov	x0, x21
1004bf8b4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf8b8:	mov	x0, x20
1004bf8bc:	ldp	x29, x30, [sp, #0x20]
1004bf8c0:	ldp	x20, x19, [sp, #0x10]
1004bf8c4:	ldp	x22, x21, [sp], #0x30
1004bf8c8:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004bf8cc:	sub	sp, sp, #0x50
1004bf8d0:	stp	d11, d10, [sp, #0x10]
1004bf8d4:	stp	d9, d8, [sp, #0x20]
1004bf8d8:	stp	x20, x19, [sp, #0x30]
1004bf8dc:	stp	x29, x30, [sp, #0x40]
1004bf8e0:	add	x29, sp, #0x40
1004bf8e4:	mov.16b	v8, v3
1004bf8e8:	mov.16b	v9, v2
1004bf8ec:	mov.16b	v10, v1
1004bf8f0:	mov.16b	v11, v0
1004bf8f4:	mov	x19, x0
1004bf8f8:	adrp	x8, 7830 ; 0x102355000
1004bf8fc:	ldr	x8, [x8, #0x150]
1004bf900:	str	xzr, [x0, x8]
1004bf904:	adrp	x8, 7830 ; 0x102355000
1004bf908:	ldr	x8, [x8, #0x158]
1004bf90c:	strb	wzr, [x0, x8]
1004bf910:	bl	0x1004bfa04
1004bf914:	stp	x19, x0, [sp]
1004bf918:	adrp	x8, 7780 ; 0x102323000
1004bf91c:	ldr	x1, [x8, #0x50] ; Objc selector ref: initWithFrame:
1004bf920:	mov	x0, sp
1004bf924:	mov.16b	v0, v11
1004bf928:	mov.16b	v1, v10
1004bf92c:	mov.16b	v2, v9
1004bf930:	mov.16b	v3, v8
1004bf934:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithFrame:]
1004bf938:	ldp	x29, x30, [sp, #0x40]
1004bf93c:	ldp	x20, x19, [sp, #0x30]
1004bf940:	ldp	d9, d8, [sp, #0x20]
1004bf944:	ldp	d11, d10, [sp, #0x10]
1004bf948:	add	sp, sp, #0x50
1004bf94c:	ret
1004bf950:	sub	sp, sp, #0x40
1004bf954:	stp	x22, x21, [sp, #0x10]
1004bf958:	stp	x20, x19, [sp, #0x20]
1004bf95c:	stp	x29, x30, [sp, #0x30]
1004bf960:	add	x29, sp, #0x30
1004bf964:	mov	x19, x2
1004bf968:	mov	x20, x0
1004bf96c:	adrp	x8, 7830 ; 0x102355000
1004bf970:	ldr	x8, [x8, #0x150]
1004bf974:	str	xzr, [x0, x8]
1004bf978:	adrp	x8, 7830 ; 0x102355000
1004bf97c:	ldr	x8, [x8, #0x158]
1004bf980:	strb	wzr, [x0, x8]
1004bf984:	bl	0x1004bfa04
1004bf988:	stp	x20, x0, [sp]
1004bf98c:	adrp	x8, 7779 ; 0x102322000
1004bf990:	ldr	x20, [x8, #0xfd8] ; Objc selector ref: initWithCoder:
1004bf994:	mov	x0, x19
1004bf998:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bf99c:	mov	x21, x0
1004bf9a0:	mov	x0, sp
1004bf9a4:	mov	x1, x20
1004bf9a8:	mov	x2, x21
1004bf9ac:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithCoder:]
1004bf9b0:	mov	x29, x29
1004bf9b4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bf9b8:	mov	x19, x0
1004bf9bc:	mov	x0, x21
1004bf9c0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf9c4:	cbz	x19, 0x1004bf9d0
1004bf9c8:	mov	x0, x19
1004bf9cc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf9d0:	mov	x0, x19
1004bf9d4:	ldp	x29, x30, [sp, #0x30]
1004bf9d8:	ldp	x20, x19, [sp, #0x20]
1004bf9dc:	ldp	x22, x21, [sp, #0x10]
1004bf9e0:	add	sp, sp, #0x40
1004bf9e4:	ret
1004bf9e8:	adrp	x1, 0 ; 0x1004bf000
1004bf9ec:	add	x1, x1, #0xa04
1004bf9f0:	b	0x1004bf364
1004bf9f4:	adrp	x8, 7830 ; 0x102355000
1004bf9f8:	ldr	x8, [x8, #0x150]
1004bf9fc:	ldr	x0, [x0, x8]
1004bfa00:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004bfa04:	stp	x29, x30, [sp, #-0x10]!
1004bfa08:	mov	x29, sp
1004bfa0c:	adrp	x0, 7794 ; 0x102331000
1004bfa10:	add	x0, x0, #0xbc8
1004bfa14:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bfa18:	mov	x1, #0x0
1004bfa1c:	ldp	x29, x30, [sp], #0x10
1004bfa20:	ret
1004bfa24:	stp	x22, x21, [sp, #-0x30]!
1004bfa28:	stp	x20, x19, [sp, #0x10]
1004bfa2c:	stp	x29, x30, [sp, #0x20]
1004bfa30:	add	x29, sp, #0x20
1004bfa34:	mov	x19, x3
1004bfa38:	mov	x20, x0
1004bfa3c:	tbz	w2, #0x0, 0x1004bfa6c
1004bfa40:	ldr	x9, [x19, #0x18]
1004bfa44:	lsr	x8, x9, #1
1004bfa48:	cmp	x8, x1
1004bfa4c:	b.ge	0x1004bfa70
1004bfa50:	mov	x10, #0x4000000000000000
1004bfa54:	cmn	x8, x10
1004bfa58:	b.mi	0x1004bfb28
1004bfa5c:	and	x8, x9, #0xfffffffffffffffe
1004bfa60:	cmp	x8, x1
1004bfa64:	csel	x8, x8, x1, gt
1004bfa68:	b	0x1004bfa70
1004bfa6c:	mov	x8, x1
1004bfa70:	ldr	x21, [x19, #0x10]
1004bfa74:	cmp	x8, x21
1004bfa78:	csel	x22, x8, x21, gt
1004bfa7c:	cbz	x22, 0x1004bfac8
1004bfa80:	adrp	x0, 7830 ; 0x102355000
1004bfa84:	add	x0, x0, #0x530
1004bfa88:	adrp	x1, 5686 ; 0x101af5000
1004bfa8c:	add	x1, x1, #0xe58
1004bfa90:	bl	0x100003c4c
1004bfa94:	lsl	x8, x22, #5
1004bfa98:	add	x1, x8, #0x20
1004bfa9c:	mov	w2, #0x7
1004bfaa0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bfaa4:	mov	x22, x0
1004bfaa8:	bl	0x101ac9c04 ; symbol stub for: _malloc_size
1004bfaac:	subs	x8, x0, #0x20
1004bfab0:	sub	x9, x0, #0x1
1004bfab4:	csel	x8, x9, x8, lt
1004bfab8:	asr	x8, x8, #5
1004bfabc:	lsl	x8, x8, #1
1004bfac0:	stp	x21, x8, [x22, #0x10]
1004bfac4:	b	0x1004bfad0
1004bfac8:	adrp	x22, 7696 ; 0x1022cf000
1004bfacc:	ldr	x22, [x22, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004bfad0:	add	x0, x22, #0x20
1004bfad4:	add	x1, x19, #0x20
1004bfad8:	tbz	w20, #0x0, 0x1004bfafc
1004bfadc:	add	x8, x1, x21, lsl #5
1004bfae0:	cmp	x22, x19
1004bfae4:	ccmp	x0, x8, #0x2, eq
1004bfae8:	b.lo	0x1004bfaf4
1004bfaec:	lsl	x2, x21, #5
1004bfaf0:	bl	0x101ac9c40 ; symbol stub for: _memmove
1004bfaf4:	str	xzr, [x19, #0x10]
1004bfaf8:	b	0x1004bfb0c
1004bfafc:	adrp	x3, 7451 ; 0x1021da000
1004bfb00:	add	x3, x3, #0x5e0
1004bfb04:	mov	x2, x21
1004bfb08:	bl	0x101aca5b8 ; symbol stub for: _swift_arrayInitWithCopy
1004bfb0c:	mov	x0, x19
1004bfb10:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004bfb14:	mov	x0, x22
1004bfb18:	ldp	x29, x30, [sp, #0x20]
1004bfb1c:	ldp	x20, x19, [sp, #0x10]
1004bfb20:	ldp	x22, x21, [sp], #0x30
1004bfb24:	ret
1004bfb28:	brk	#0x1
1004bfb2c:	stp	x29, x30, [sp, #-0x10]!
1004bfb30:	mov	x29, sp
1004bfb34:	ldr	x3, [x20]
1004bfb38:	adrp	x4, 7696 ; 0x1022cf000
1004bfb3c:	ldr	x4, [x4, #0x738] ; literal pool symbol address: _swift_release
1004bfb40:	bl	0x1004bfb6c
1004bfb44:	str	x0, [x20]
1004bfb48:	ldp	x29, x30, [sp], #0x10
1004bfb4c:	ret
1004bfb50:	stp	x29, x30, [sp, #-0x10]!
1004bfb54:	mov	x29, sp
1004bfb58:	ldr	x3, [x20]
1004bfb5c:	bl	0x1004bfcc4
1004bfb60:	str	x0, [x20]
1004bfb64:	ldp	x29, x30, [sp], #0x10
1004bfb68:	ret
1004bfb6c:	stp	x26, x25, [sp, #-0x50]!
1004bfb70:	stp	x24, x23, [sp, #0x10]
1004bfb74:	stp	x22, x21, [sp, #0x20]
1004bfb78:	stp	x20, x19, [sp, #0x30]
1004bfb7c:	stp	x29, x30, [sp, #0x40]
1004bfb80:	add	x29, sp, #0x40
1004bfb84:	mov	x19, x4
1004bfb88:	mov	x20, x3
1004bfb8c:	mov	x21, x0
1004bfb90:	tbz	w2, #0x0, 0x1004bfbc0
1004bfb94:	ldr	x9, [x20, #0x18]
1004bfb98:	lsr	x8, x9, #1
1004bfb9c:	cmp	x8, x1
1004bfba0:	b.ge	0x1004bfbc4
1004bfba4:	mov	x10, #0x4000000000000000
1004bfba8:	cmn	x8, x10
1004bfbac:	b.mi	0x1004bfcc0
1004bfbb0:	and	x8, x9, #0xfffffffffffffffe
1004bfbb4:	cmp	x8, x1
1004bfbb8:	csel	x8, x8, x1, gt
1004bfbbc:	b	0x1004bfbc4
1004bfbc0:	mov	x8, x1
1004bfbc4:	ldr	x22, [x20, #0x10]
1004bfbc8:	cmp	x8, x22
1004bfbcc:	csel	x23, x8, x22, gt
1004bfbd0:	cbz	x23, 0x1004bfc30
1004bfbd4:	adrp	x0, 7830 ; 0x102355000
1004bfbd8:	add	x0, x0, #0x198
1004bfbdc:	adrp	x1, 5686 ; 0x101af5000
1004bfbe0:	add	x1, x1, #0xe48
1004bfbe4:	bl	0x100003c4c
1004bfbe8:	mov	w8, #0x38
1004bfbec:	mov	x9, #0x20
1004bfbf0:	madd	x1, x23, x8, x9
1004bfbf4:	mov	w2, #0x7
1004bfbf8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bfbfc:	mov	x23, x0
1004bfc00:	bl	0x101ac9c04 ; symbol stub for: _malloc_size
1004bfc04:	sub	x8, x0, #0x20
1004bfc08:	mov	x9, #0x4925
1004bfc0c:	movk	x9, #0x2492, lsl #16
1004bfc10:	movk	x9, #0x9249, lsl #32
1004bfc14:	movk	x9, #0x4924, lsl #48
1004bfc18:	smulh	x8, x8, x9
1004bfc1c:	asr	x9, x8, #4
1004bfc20:	add	x8, x9, x8, lsr #63
1004bfc24:	lsl	x8, x8, #1
1004bfc28:	stp	x22, x8, [x23, #0x10]
1004bfc2c:	b	0x1004bfc38
1004bfc30:	adrp	x23, 7696 ; 0x1022cf000
1004bfc34:	ldr	x23, [x23, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004bfc38:	add	x24, x23, #0x20
1004bfc3c:	add	x25, x20, #0x20
1004bfc40:	tbz	w21, #0x0, 0x1004bfc74
1004bfc44:	mov	w8, #0x38
1004bfc48:	madd	x8, x22, x8, x25
1004bfc4c:	cmp	x23, x20
1004bfc50:	ccmp	x24, x8, #0x2, eq
1004bfc54:	b.lo	0x1004bfc6c
1004bfc58:	lsl	x8, x22, #6
1004bfc5c:	sub	x2, x8, x22, lsl #3
1004bfc60:	mov	x0, x24
1004bfc64:	mov	x1, x25
1004bfc68:	bl	0x101ac9c40 ; symbol stub for: _memmove
1004bfc6c:	str	xzr, [x20, #0x10]
1004bfc70:	b	0x1004bfc9c
1004bfc74:	adrp	x0, 7830 ; 0x102355000
1004bfc78:	add	x0, x0, #0x1a0
1004bfc7c:	adrp	x1, 5686 ; 0x101af5000
1004bfc80:	add	x1, x1, #0xe50
1004bfc84:	bl	0x100003c4c
1004bfc88:	mov	x3, x0
1004bfc8c:	mov	x0, x24
1004bfc90:	mov	x1, x25
1004bfc94:	mov	x2, x22
1004bfc98:	bl	0x101aca5b8 ; symbol stub for: _swift_arrayInitWithCopy
1004bfc9c:	mov	x0, x20
1004bfca0:	blr	x19
1004bfca4:	mov	x0, x23
1004bfca8:	ldp	x29, x30, [sp, #0x40]
1004bfcac:	ldp	x20, x19, [sp, #0x30]
1004bfcb0:	ldp	x22, x21, [sp, #0x20]
1004bfcb4:	ldp	x24, x23, [sp, #0x10]
1004bfcb8:	ldp	x26, x25, [sp], #0x50
1004bfcbc:	ret
1004bfcc0:	brk	#0x1
1004bfcc4:	stp	x22, x21, [sp, #-0x30]!
1004bfcc8:	stp	x20, x19, [sp, #0x10]
1004bfccc:	stp	x29, x30, [sp, #0x20]
1004bfcd0:	add	x29, sp, #0x20
1004bfcd4:	mov	x19, x3
1004bfcd8:	mov	x20, x0
1004bfcdc:	tbz	w2, #0x0, 0x1004bfd0c
1004bfce0:	ldr	x9, [x19, #0x18]
1004bfce4:	lsr	x8, x9, #1
1004bfce8:	cmp	x8, x1
1004bfcec:	b.ge	0x1004bfd10
1004bfcf0:	mov	x10, #0x4000000000000000
1004bfcf4:	cmn	x8, x10
1004bfcf8:	b.mi	0x1004bfdd8
1004bfcfc:	and	x8, x9, #0xfffffffffffffffe
1004bfd00:	cmp	x8, x1
1004bfd04:	csel	x8, x8, x1, gt
1004bfd08:	b	0x1004bfd10
1004bfd0c:	mov	x8, x1
1004bfd10:	ldr	x22, [x19, #0x10]
1004bfd14:	cmp	x8, x22
1004bfd18:	csel	x21, x8, x22, gt
1004bfd1c:	cbz	x21, 0x1004bfd74
1004bfd20:	adrp	x0, 7830 ; 0x102355000
1004bfd24:	add	x0, x0, #0x548
1004bfd28:	adrp	x1, 5686 ; 0x101af5000
1004bfd2c:	add	x1, x1, #0xe70
1004bfd30:	bl	0x100003c4c
1004bfd34:	mov	w8, #0x28
1004bfd38:	mov	x9, #0x20
1004bfd3c:	madd	x1, x21, x8, x9
1004bfd40:	mov	w2, #0x7
1004bfd44:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004bfd48:	mov	x21, x0
1004bfd4c:	bl	0x101ac9c04 ; symbol stub for: _malloc_size
1004bfd50:	sub	x8, x0, #0x20
1004bfd54:	mov	x9, #0x6666666666666666
1004bfd58:	movk	x9, #0x6667
1004bfd5c:	smulh	x8, x8, x9
1004bfd60:	asr	x9, x8, #4
1004bfd64:	add	x8, x9, x8, lsr #63
1004bfd68:	lsl	x8, x8, #1
1004bfd6c:	stp	x22, x8, [x21, #0x10]
1004bfd70:	b	0x1004bfd7c
1004bfd74:	adrp	x21, 7696 ; 0x1022cf000
1004bfd78:	ldr	x21, [x21, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004bfd7c:	add	x0, x21, #0x20
1004bfd80:	add	x1, x19, #0x20
1004bfd84:	tbz	w20, #0x0, 0x1004bfdac
1004bfd88:	add	x8, x22, x22, lsl #2
1004bfd8c:	lsl	x2, x8, #3
1004bfd90:	add	x8, x1, x2
1004bfd94:	cmp	x21, x19
1004bfd98:	ccmp	x0, x8, #0x2, eq
1004bfd9c:	b.lo	0x1004bfda4
1004bfda0:	bl	0x101ac9c40 ; symbol stub for: _memmove
1004bfda4:	str	xzr, [x19, #0x10]
1004bfda8:	b	0x1004bfdbc
1004bfdac:	adrp	x3, 7458 ; 0x1021e1000
1004bfdb0:	add	x3, x3, #0xdd0
1004bfdb4:	mov	x2, x22
1004bfdb8:	bl	0x101aca5b8 ; symbol stub for: _swift_arrayInitWithCopy
1004bfdbc:	mov	x0, x19
1004bfdc0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004bfdc4:	mov	x0, x21
1004bfdc8:	ldp	x29, x30, [sp, #0x20]
1004bfdcc:	ldp	x20, x19, [sp, #0x10]
1004bfdd0:	ldp	x22, x21, [sp], #0x30
1004bfdd4:	ret
1004bfdd8:	brk	#0x1
1004bfddc:	stp	d9, d8, [sp, #-0x50]!
1004bfde0:	stp	x24, x23, [sp, #0x10]
1004bfde4:	stp	x22, x21, [sp, #0x20]
1004bfde8:	stp	x20, x19, [sp, #0x30]
1004bfdec:	stp	x29, x30, [sp, #0x40]
1004bfdf0:	add	x29, sp, #0x40
1004bfdf4:	mov.16b	v8, v0
1004bfdf8:	mov	x19, x0
1004bfdfc:	fmov	d0, #4.00000000
1004bfe00:	fadd	d9, d8, d0
1004bfe04:	adrp	x8, 7783 ; 0x102326000
1004bfe08:	ldr	x0, [x8, #0xa40] ; Objc class ref: _OBJC_CLASS_$_NSView
1004bfe0c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004bfe10:	mov	x8, #0x406f000000000000
1004bfe14:	fmov	d2, x8
1004bfe18:	fmov	d0, #16.00000000
1004bfe1c:	fmov	d3, #1.00000000
1004bfe20:	mov.16b	v1, v9
1004bfe24:	bl	0x101ace5a0 ; selector initWithFrame:
1004bfe28:	mov	x20, x0
1004bfe2c:	mov	w2, #0x1
1004bfe30:	bl	0x101ad4ca0 ; selector setWantsLayer:
1004bfe34:	mov	x0, x20
1004bfe38:	bl	0x101acf2c0 ; selector layer
1004bfe3c:	mov	x29, x29
1004bfe40:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bfe44:	cbz	x0, 0x1004bfe9c
1004bfe48:	mov	x21, x0
1004bfe4c:	adrp	x8, 7783 ; 0x102326000
1004bfe50:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004bfe54:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bfe58:	bl	0x101ad1600 ; selector separatorColor
1004bfe5c:	mov	x29, x29
1004bfe60:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bfe64:	mov	x22, x0
1004bfe68:	bl	0x101acad00 ; selector CGColor
1004bfe6c:	mov	x29, x29
1004bfe70:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bfe74:	mov	x23, x0
1004bfe78:	mov	x0, x22
1004bfe7c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bfe80:	mov	x0, x21
1004bfe84:	mov	x2, x23
1004bfe88:	bl	0x101ad1e00 ; selector setBackgroundColor:
1004bfe8c:	mov	x0, x21
1004bfe90:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bfe94:	mov	x0, x23
1004bfe98:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bfe9c:	mov	x0, x19
1004bfea0:	mov	x2, x20
1004bfea4:	bl	0x101acb460 ; selector addSubview:
1004bfea8:	mov	x0, x20
1004bfeac:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bfeb0:	fmov	d0, #9.00000000
1004bfeb4:	fadd	d0, d8, d0
1004bfeb8:	ldp	x29, x30, [sp, #0x40]
1004bfebc:	ldp	x20, x19, [sp, #0x30]
1004bfec0:	ldp	x22, x21, [sp, #0x20]
1004bfec4:	ldp	x24, x23, [sp, #0x10]
1004bfec8:	ldp	d9, d8, [sp], #0x50
1004bfecc:	ret
1004bfed0:	stp	d9, d8, [sp, #-0x40]!
1004bfed4:	stp	x22, x21, [sp, #0x10]
1004bfed8:	stp	x20, x19, [sp, #0x20]
1004bfedc:	stp	x29, x30, [sp, #0x30]
1004bfee0:	add	x29, sp, #0x30
1004bfee4:	mov.16b	v8, v0
1004bfee8:	mov	x19, x0
1004bfeec:	mov	x0, x1
1004bfef0:	mov	x1, x2
1004bfef4:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004bfef8:	mov	x20, x0
1004bfefc:	adrp	x8, 7783 ; 0x102326000
1004bff00:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004bff04:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bff08:	mov	x2, x20
1004bff0c:	bl	0x101acf240 ; selector labelWithString:
1004bff10:	mov	x29, x29
1004bff14:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bff18:	mov	x21, x0
1004bff1c:	mov	x0, x20
1004bff20:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bff24:	adrp	x8, 7691 ; 0x1022ca000
1004bff28:	ldr	x8, [x8, #0x610] ; literal pool symbol address: _NSFontWeightMedium
1004bff2c:	ldr	d9, [x8]
1004bff30:	mov	x0, x21
1004bff34:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bff38:	mov	x20, x0
1004bff3c:	fmov	d0, #11.00000000
1004bff40:	mov.16b	v1, v9
1004bff44:	bl	0x100004700
1004bff48:	mov	x21, x0
1004bff4c:	mov	x0, x20
1004bff50:	mov	x2, x21
1004bff54:	bl	0x101ad2aa0 ; selector setFont:
1004bff58:	mov	x0, x20
1004bff5c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bff60:	mov	x0, x21
1004bff64:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bff68:	adrp	x8, 7783 ; 0x102326000
1004bff6c:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004bff70:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bff74:	bl	0x101ad58a0 ; selector tertiaryLabelColor
1004bff78:	mov	x29, x29
1004bff7c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004bff80:	mov	x21, x0
1004bff84:	mov	x0, x20
1004bff88:	mov	x2, x21
1004bff8c:	bl	0x101ad4660 ; selector setTextColor:
1004bff90:	mov	x0, x21
1004bff94:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bff98:	fmov	d0, #8.00000000
1004bff9c:	fadd	d1, d8, d0
1004bffa0:	mov	x8, #0x406f000000000000
1004bffa4:	fmov	d2, x8
1004bffa8:	fmov	d0, #16.00000000
1004bffac:	fmov	d3, #14.00000000
1004bffb0:	mov	x0, x20
1004bffb4:	bl	0x101ad2b80 ; selector setFrame:
1004bffb8:	mov	x0, x20
1004bffbc:	mov	w2, #0x0
1004bffc0:	bl	0x101ad28e0 ; selector setEditable:
1004bffc4:	mov	x0, x20
1004bffc8:	mov	w2, #0x0
1004bffcc:	bl	0x101ad1fa0 ; selector setBordered:
1004bffd0:	mov	x0, x20
1004bffd4:	mov	w2, #0x0
1004bffd8:	bl	0x101ad2860 ; selector setDrawsBackground:
1004bffdc:	mov	x0, x19
1004bffe0:	mov	x2, x20
1004bffe4:	bl	0x101acb460 ; selector addSubview:
1004bffe8:	mov	x0, x20
1004bffec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bfff0:	fmov	d0, #24.00000000
1004bfff4:	fadd	d0, d8, d0
1004bfff8:	ldp	x29, x30, [sp, #0x30]
1004bfffc:	ldp	x20, x19, [sp, #0x20]
1004c0000:	ldp	x22, x21, [sp, #0x10]
1004c0004:	ldp	d9, d8, [sp], #0x40
1004c0008:	ret
1004c000c:	sub	sp, sp, #0x70
1004c0010:	stp	d9, d8, [sp, #0x20]
1004c0014:	stp	x24, x23, [sp, #0x30]
1004c0018:	stp	x22, x21, [sp, #0x40]
1004c001c:	stp	x20, x19, [sp, #0x50]
1004c0020:	stp	x29, x30, [sp, #0x60]
1004c0024:	add	x29, sp, #0x60
1004c0028:	mov	x20, x1
1004c002c:	mov	x19, x0
1004c0030:	add	x0, x1, #0x10
1004c0034:	add	x1, sp, #0x8
1004c0038:	mov	x2, #0x0
1004c003c:	mov	x3, #0x0
1004c0040:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c0044:	add	x0, x20, #0x10
1004c0048:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c004c:	cbz	x0, 0x1004c0120
1004c0050:	adrp	x8, 7829 ; 0x102355000
1004c0054:	ldr	x8, [x8, #0xd0]
1004c0058:	ldr	x20, [x0, x8]
1004c005c:	cbz	x20, 0x1004c011c
1004c0060:	mov	x23, x0
1004c0064:	adrp	x8, 7782 ; 0x102326000
1004c0068:	ldr	x0, [x8, #0xb00] ; Objc class ref: _OBJC_CLASS_$_NSEvent
1004c006c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c0070:	mov	x22, x0
1004c0074:	mov	x0, x20
1004c0078:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004c007c:	mov	x21, x0
1004c0080:	mov	x0, x22
1004c0084:	bl	0x101acf920 ; selector mouseLocation
1004c0088:	mov.16b	v8, v0
1004c008c:	mov.16b	v9, v1
1004c0090:	mov	x0, x21
1004c0094:	bl	0x101acdcc0 ; selector frame
1004c0098:	bl	0x1004ad2b4
1004c009c:	mov.16b	v4, v0
1004c00a0:	mov.16b	v5, v1
1004c00a4:	mov.16b	v6, v2
1004c00a8:	mov.16b	v7, v3
1004c00ac:	mov.16b	v0, v8
1004c00b0:	mov.16b	v1, v9
1004c00b4:	mov.16b	v2, v4
1004c00b8:	mov.16b	v3, v5
1004c00bc:	mov.16b	v4, v6
1004c00c0:	mov	w0, #0x0
1004c00c4:	mov.16b	v5, v7
1004c00c8:	bl	0x101ac9424 ; symbol stub for: _NSMouseInRect
1004c00cc:	mov	x22, x0
1004c00d0:	mov	x0, #0x0
1004c00d4:	bl	0x1004ad03c
1004c00d8:	mov.16b	v0, v8
1004c00dc:	mov.16b	v1, v9
1004c00e0:	mov	x20, x0
1004c00e4:	bl	0x1004a9ccc
1004c00e8:	tbnz	w22, #0x0, 0x1004c0110
1004c00ec:	tbnz	w0, #0x0, 0x1004c0110
1004c00f0:	mov	x20, x23
1004c00f4:	ldr	x8, [x23]
1004c00f8:	adrp	x9, 7695 ; 0x1022cf000
1004c00fc:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004c0100:	ldr	x9, [x9]
1004c0104:	and	x8, x9, x8
1004c0108:	ldr	x8, [x8, #0x248]
1004c010c:	blr	x8
1004c0110:	mov	x0, x21
1004c0114:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0118:	mov	x0, x23
1004c011c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0120:	mov	x0, x19
1004c0124:	ldp	x29, x30, [sp, #0x60]
1004c0128:	ldp	x20, x19, [sp, #0x50]
1004c012c:	ldp	x22, x21, [sp, #0x40]
1004c0130:	ldp	x24, x23, [sp, #0x30]
1004c0134:	ldp	d9, d8, [sp, #0x20]
1004c0138:	add	sp, sp, #0x70
1004c013c:	ret
1004c0140:	stp	x24, x23, [sp, #-0x40]!
1004c0144:	stp	x22, x21, [sp, #0x10]
1004c0148:	stp	x20, x19, [sp, #0x20]
1004c014c:	stp	x29, x30, [sp, #0x30]
1004c0150:	add	x29, sp, #0x30
1004c0154:	adrp	x8, 7829 ; 0x102355000
1004c0158:	ldr	x8, [x8, #0x158]
1004c015c:	mov	w9, #0x1
1004c0160:	strb	w9, [x20, x8]
1004c0164:	mov	x0, x20
1004c0168:	bl	0x101acf2c0 ; selector layer
1004c016c:	mov	x29, x29
1004c0170:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c0174:	adrp	x23, 7782 ; 0x102326000
1004c0178:	cbz	x0, 0x1004c01fc
1004c017c:	mov	x19, x0
1004c0180:	ldr	x0, [x23, #0x9c8]
1004c0184:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c0188:	bl	0x101acf220 ; selector labelColor
1004c018c:	mov	x29, x29
1004c0190:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c0194:	mov	x21, x0
1004c0198:	mov	x8, #0x147b
1004c019c:	movk	x8, #0x47ae, lsl #16
1004c01a0:	movk	x8, #0x7ae1, lsl #32
1004c01a4:	movk	x8, #0x3fb4, lsl #48
1004c01a8:	fmov	d0, x8
1004c01ac:	bl	0x101acc400 ; selector colorWithAlphaComponent:
1004c01b0:	mov	x29, x29
1004c01b4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c01b8:	mov	x22, x0
1004c01bc:	mov	x0, x21
1004c01c0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c01c4:	mov	x0, x22
1004c01c8:	bl	0x101acad00 ; selector CGColor
1004c01cc:	mov	x29, x29
1004c01d0:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c01d4:	mov	x21, x0
1004c01d8:	mov	x0, x22
1004c01dc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c01e0:	mov	x0, x19
1004c01e4:	mov	x2, x21
1004c01e8:	bl	0x101ad1e00 ; selector setBackgroundColor:
1004c01ec:	mov	x0, x19
1004c01f0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c01f4:	mov	x0, x21
1004c01f8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c01fc:	ldr	x0, [x23, #0x9c8]
1004c0200:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c0204:	bl	0x101acf220 ; selector labelColor
1004c0208:	mov	x29, x29
1004c020c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c0210:	mov	x19, x0
1004c0214:	mov	x0, x20
1004c0218:	mov	x2, x19
1004c021c:	bl	0x101ad2300 ; selector setContentTintColor:
1004c0220:	mov	x0, x19
1004c0224:	ldp	x29, x30, [sp, #0x30]
1004c0228:	ldp	x20, x19, [sp, #0x20]
1004c022c:	ldp	x22, x21, [sp, #0x10]
1004c0230:	ldp	x24, x23, [sp], #0x40
1004c0234:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004c0238:	stp	x20, x19, [sp, #-0x20]!
1004c023c:	stp	x29, x30, [sp, #0x10]
1004c0240:	add	x29, sp, #0x10
1004c0244:	adrp	x8, 7829 ; 0x102355000
1004c0248:	ldr	x8, [x8, #0x158]
1004c024c:	strb	wzr, [x20, x8]
1004c0250:	mov	x0, x20
1004c0254:	bl	0x101acf2c0 ; selector layer
1004c0258:	mov	x29, x29
1004c025c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c0260:	cbz	x0, 0x1004c0278
1004c0264:	mov	x19, x0
1004c0268:	mov	x2, #0x0
1004c026c:	bl	0x101ad1e00 ; selector setBackgroundColor:
1004c0270:	mov	x0, x19
1004c0274:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0278:	adrp	x8, 7782 ; 0x102326000
1004c027c:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004c0280:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c0284:	bl	0x101ad12e0 ; selector secondaryLabelColor
1004c0288:	mov	x29, x29
1004c028c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c0290:	mov	x19, x0
1004c0294:	mov	x0, x20
1004c0298:	mov	x2, x19
1004c029c:	bl	0x101ad2300 ; selector setContentTintColor:
1004c02a0:	mov	x0, x19
1004c02a4:	ldp	x29, x30, [sp, #0x10]
1004c02a8:	ldp	x20, x19, [sp], #0x20
1004c02ac:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004c02b0:	ldp	x1, x2, [x20, #0x10]
1004c02b4:	ldp	x3, x4, [x20, #0x20]
1004c02b8:	ldp	x5, x6, [x20, #0x30]
1004c02bc:	b	0x1004bef5c
1004c02c0:	stp	x29, x30, [sp, #-0x10]!
1004c02c4:	mov	x29, sp
1004c02c8:	ldr	x0, [x20, #0x10]
1004c02cc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c02d0:	mov	x0, x20
1004c02d4:	mov	w1, #0x18
1004c02d8:	mov	w2, #0x7
1004c02dc:	ldp	x29, x30, [sp], #0x10
1004c02e0:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004c02e4:	stp	x20, x19, [sp, #-0x20]!
1004c02e8:	stp	x29, x30, [sp, #0x10]
1004c02ec:	add	x29, sp, #0x10
1004c02f0:	ldr	x20, [x20, #0x10]
1004c02f4:	cbz	x20, 0x1004c0308
1004c02f8:	mov	w0, #0x0
1004c02fc:	mov	x1, #0x0
1004c0300:	mov	x2, #0x0
1004c0304:	bl	0x1000b6d5c
1004c0308:	ldp	x29, x30, [sp, #0x10]
1004c030c:	ldp	x20, x19, [sp], #0x20
1004c0310:	ret
1004c0314:	b	0x1001fd7a8
1004c0318:	sub	sp, sp, #0x40
1004c031c:	stp	x22, x21, [sp, #0x10]
1004c0320:	stp	x20, x19, [sp, #0x20]
1004c0324:	stp	x29, x30, [sp, #0x30]
1004c0328:	add	x29, sp, #0x30
1004c032c:	ldp	x19, x8, [x20, #0x10]
1004c0330:	ldr	x0, [x20, #0x20]
1004c0334:	stp	x8, x0, [sp]
1004c0338:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c033c:	mov	x20, sp
1004c0340:	mov	w0, #0xa
1004c0344:	mov	x1, #-0x1f00000000000000
1004c0348:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004c034c:	ldp	x20, x21, [sp]
1004c0350:	bl	_$s9TextStory09BufferingA7StorageC16bufferingEnabledSbvpfi
1004c0354:	mov	x22, x0
1004c0358:	bl	_$s8Markdown20HTMLFormatterOptionsV11parseAsidesACvgZ
1004c035c:	ldr	x8, [x19]
1004c0360:	ldr	x8, [x8, #0xa48]
1004c0364:	and	w3, w0, #0x1
1004c0368:	mov	x0, x20
1004c036c:	mov	x1, x21
1004c0370:	mov	x2, x22
1004c0374:	mov	x20, x19
1004c0378:	blr	x8
1004c037c:	mov	x0, x21
1004c0380:	ldp	x29, x30, [sp, #0x30]
1004c0384:	ldp	x20, x19, [sp, #0x20]
1004c0388:	ldp	x22, x21, [sp, #0x10]
1004c038c:	add	sp, sp, #0x40
1004c0390:	b	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c0394:	sub	sp, sp, #0xe0
1004c0398:	stp	x28, x27, [sp, #0x80]
1004c039c:	stp	x26, x25, [sp, #0x90]
1004c03a0:	stp	x24, x23, [sp, #0xa0]
1004c03a4:	stp	x22, x21, [sp, #0xb0]
1004c03a8:	stp	x20, x19, [sp, #0xc0]
1004c03ac:	stp	x29, x30, [sp, #0xd0]
1004c03b0:	add	x29, sp, #0xd0
1004c03b4:	ldp	x19, x28, [x20, #0x10]
1004c03b8:	add	x0, x19, #0x10
1004c03bc:	add	x1, sp, #0x68
1004c03c0:	mov	x2, #0x0
1004c03c4:	mov	x3, #0x0
1004c03c8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c03cc:	add	x0, x19, #0x10
1004c03d0:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c03d4:	cbz	x0, 0x1004c0630
1004c03d8:	mov	x21, x0
1004c03dc:	mov	w25, #0x9ce2
1004c03e0:	movk	w25, #0x93, lsl #16
1004c03e4:	mov	x20, x0
1004c03e8:	bl	0x1000e0880
1004c03ec:	stp	x28, x21, [sp, #0x20]
1004c03f0:	cbz	x0, 0x1004c063c
1004c03f4:	mov	x23, x0
1004c03f8:	adrp	x8, 7961 ; 0x1023d9000
1004c03fc:	add	x8, x8, #0x9d8
1004c0400:	ldr	x19, [x8]
1004c0404:	add	x0, x0, x19
1004c0408:	add	x1, sp, #0x38
1004c040c:	mov	x2, #0x0
1004c0410:	mov	x3, #0x0
1004c0414:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c0418:	ldrb	w28, [x23, x19]
1004c041c:	strb	w28, [sp, #0x50]
1004c0420:	strb	wzr, [sp, #0x37]
1004c0424:	bl	0x1000ba12c
1004c0428:	mov	x24, x0
1004c042c:	adrp	x2, 7419 ; 0x1021bb000
1004c0430:	add	x2, x2, #0xc90
1004c0434:	add	x0, sp, #0x50
1004c0438:	add	x1, sp, #0x37
1004c043c:	mov	x20, x2
1004c0440:	mov	x3, x24
1004c0444:	bl	0x101ac619c ; symbol stub for: _$sSQ2eeoiySbx_xtFZTj
1004c0448:	tst	w0, #0x1
1004c044c:	csel	x8, x25, xzr, ne
1004c0450:	str	x8, [sp, #0x18]
1004c0454:	mov	x8, #-0x5d00000000000000
1004c0458:	csel	x19, x8, xzr, ne
1004c045c:	adrp	x0, 7450 ; 0x1021da000
1004c0460:	add	x0, x0, #0xae0
1004c0464:	mov	w1, #0x18
1004c0468:	mov	w2, #0x7
1004c046c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c0470:	mov	x20, x0
1004c0474:	add	x0, x0, #0x10
1004c0478:	mov	x1, x21
1004c047c:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c0480:	adrp	x0, 7450 ; 0x1021da000
1004c0484:	add	x0, x0, #0xc48
1004c0488:	mov	w1, #0x20
1004c048c:	mov	w2, #0x7
1004c0490:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c0494:	mov	x26, x0
1004c0498:	adrp	x8, 0 ; 0x1004c0000
1004c049c:	add	x8, x8, #0xe34
1004c04a0:	stp	x8, x20, [x0, #0x10]
1004c04a4:	mov	x0, x21
1004c04a8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004c04ac:	mov	x25, x0
1004c04b0:	mov	x0, x20
1004c04b4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c04b8:	adrp	x3, 7695 ; 0x1022cf000
1004c04bc:	ldr	x3, [x3, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004c04c0:	adrp	x4, 7695 ; 0x1022cf000
1004c04c4:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c04c8:	mov	w0, #0x0
1004c04cc:	mov	w1, #0x1
1004c04d0:	mov	w2, #0x1
1004c04d4:	bl	0x1004bfb6c
1004c04d8:	mov	x22, x0
1004c04dc:	ldp	x21, x8, [x0, #0x10]
1004c04e0:	add	x27, x21, #0x1
1004c04e4:	cmp	x21, x8, lsr #1
1004c04e8:	b.hs	0x1004c0aa8
1004c04ec:	str	x27, [x22, #0x10]
1004c04f0:	mov	w8, #0x38
1004c04f4:	madd	x8, x21, x8, x22
1004c04f8:	mov	x9, #0x6f53
1004c04fc:	movk	x9, #0x7275, lsl #16
1004c0500:	movk	x9, #0x6563, lsl #32
1004c0504:	mov	x10, #-0x1a00000000000000
1004c0508:	stp	x9, x10, [x8, #0x20]
1004c050c:	ldr	x9, [sp, #0x18]
1004c0510:	stp	x9, x19, [x8, #0x30]
1004c0514:	adrp	x9, -1212 ; 0x100004000
1004c0518:	add	x9, x9, #0xcc
1004c051c:	stp	xzr, x9, [x8, #0x40]
1004c0520:	str	x26, [x8, #0x50]
1004c0524:	mov	x0, x20
1004c0528:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c052c:	strb	w28, [sp, #0x50]
1004c0530:	mov	w8, #0x1
1004c0534:	strb	w8, [sp, #0x37]
1004c0538:	adrp	x2, 7419 ; 0x1021bb000
1004c053c:	add	x2, x2, #0xc90
1004c0540:	add	x0, sp, #0x50
1004c0544:	add	x1, sp, #0x37
1004c0548:	mov	x20, x2
1004c054c:	mov	x3, x24
1004c0550:	bl	0x101ac619c ; symbol stub for: _$sSQ2eeoiySbx_xtFZTj
1004c0554:	tst	w0, #0x1
1004c0558:	mov	w8, #0x9ce2
1004c055c:	movk	w8, #0x93, lsl #16
1004c0560:	csel	x19, x8, xzr, ne
1004c0564:	mov	x8, #-0x5d00000000000000
1004c0568:	csel	x21, x8, xzr, ne
1004c056c:	adrp	x0, 7450 ; 0x1021da000
1004c0570:	add	x0, x0, #0xae0
1004c0574:	mov	w1, #0x18
1004c0578:	mov	w2, #0x7
1004c057c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c0580:	mov	x20, x0
1004c0584:	add	x0, x0, #0x10
1004c0588:	mov	x1, x25
1004c058c:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c0590:	mov	x0, x25
1004c0594:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0598:	adrp	x0, 7450 ; 0x1021da000
1004c059c:	add	x0, x0, #0xc70
1004c05a0:	mov	w1, #0x20
1004c05a4:	mov	w2, #0x7
1004c05a8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c05ac:	mov	x24, x0
1004c05b0:	adrp	x8, 0 ; 0x1004c0000
1004c05b4:	add	x8, x8, #0xe3c
1004c05b8:	stp	x8, x20, [x0, #0x10]
1004c05bc:	ldp	x26, x27, [x22, #0x10]
1004c05c0:	add	x25, x26, #0x1
1004c05c4:	mov	x0, x20
1004c05c8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c05cc:	cmp	x26, x27, lsr #1
1004c05d0:	b.hs	0x1004c0ad0
1004c05d4:	ldr	x28, [sp, #0x20]
1004c05d8:	str	x25, [x22, #0x10]
1004c05dc:	mov	w8, #0x38
1004c05e0:	madd	x8, x26, x8, x22
1004c05e4:	mov	x9, #0x7250
1004c05e8:	movk	x9, #0x7665, lsl #16
1004c05ec:	movk	x9, #0x6569, lsl #32
1004c05f0:	movk	x9, #0x77, lsl #48
1004c05f4:	mov	x10, #-0x1900000000000000
1004c05f8:	stp	x9, x10, [x8, #0x20]
1004c05fc:	stp	x19, x21, [x8, #0x30]
1004c0600:	adrp	x9, -1212 ; 0x100004000
1004c0604:	add	x9, x9, #0xcc
1004c0608:	stp	xzr, x9, [x8, #0x40]
1004c060c:	str	x24, [x8, #0x50]
1004c0610:	mov	x0, x23
1004c0614:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0618:	mov	x0, x20
1004c061c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c0620:	ldr	x21, [sp, #0x28]
1004c0624:	mov	w25, #0x9ce2
1004c0628:	movk	w25, #0x93, lsl #16
1004c062c:	b	0x1004c0644
1004c0630:	adrp	x22, 7695 ; 0x1022cf000
1004c0634:	ldr	x22, [x22, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004c0638:	b	0x1004c0a84
1004c063c:	adrp	x22, 7695 ; 0x1022cf000
1004c0640:	ldr	x22, [x22, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004c0644:	mov	x20, x21
1004c0648:	bl	0x1000dfd04
1004c064c:	cbz	x0, 0x1004c0a7c
1004c0650:	mov	x20, x0
1004c0654:	mov	w24, #0x2d2d
1004c0658:	movk	w24, #0x2d, lsl #16
1004c065c:	ldr	x19, [x22, #0x10]
1004c0660:	cbz	x19, 0x1004c06a8
1004c0664:	mov	x0, x22
1004c0668:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004c066c:	tbz	w0, #0x0, 0x1004c0b70
1004c0670:	ldp	x19, x8, [x22, #0x10]
1004c0674:	add	x23, x19, #0x1
1004c0678:	cmp	x19, x8, lsr #1
1004c067c:	b.hs	0x1004c0b94
1004c0680:	str	x23, [x22, #0x10]
1004c0684:	mov	w8, #0x38
1004c0688:	madd	x8, x19, x8, x22
1004c068c:	mov	x9, #-0x1d00000000000000
1004c0690:	stp	x24, x9, [x8, #0x20]
1004c0694:	stp	xzr, xzr, [x8, #0x30]
1004c0698:	adrp	x9, -1213 ; 0x100003000
1004c069c:	add	x9, x9, #0xf40
1004c06a0:	stp	xzr, x9, [x8, #0x40]
1004c06a4:	str	xzr, [x8, #0x50]
1004c06a8:	bl	0x1000a57b8
1004c06ac:	tst	w0, #0x1
1004c06b0:	mov	w26, #0x9ce2
1004c06b4:	movk	w26, #0x93, lsl #16
1004c06b8:	csel	x21, x25, xzr, ne
1004c06bc:	mov	x8, #-0x5d00000000000000
1004c06c0:	csel	x27, x8, xzr, ne
1004c06c4:	adrp	x0, 7450 ; 0x1021da000
1004c06c8:	add	x0, x0, #0xb30
1004c06cc:	mov	w1, #0x18
1004c06d0:	mov	w2, #0x7
1004c06d4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c06d8:	mov	x23, x0
1004c06dc:	add	x0, x0, #0x10
1004c06e0:	mov	x1, x20
1004c06e4:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c06e8:	adrp	x0, 7450 ; 0x1021da000
1004c06ec:	add	x0, x0, #0xb58
1004c06f0:	mov	w1, #0x20
1004c06f4:	mov	w2, #0x7
1004c06f8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c06fc:	mov	x25, x0
1004c0700:	stp	x23, x28, [x0, #0x10]
1004c0704:	adrp	x0, 7450 ; 0x1021da000
1004c0708:	add	x0, x0, #0xb80
1004c070c:	mov	w1, #0x20
1004c0710:	mov	w2, #0x7
1004c0714:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c0718:	mov	x24, x0
1004c071c:	adrp	x8, 0 ; 0x1004c0000
1004c0720:	add	x8, x8, #0xc0c
1004c0724:	stp	x8, x25, [x0, #0x10]
1004c0728:	mov	x0, x20
1004c072c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004c0730:	mov	x20, x0
1004c0734:	mov	x0, x23
1004c0738:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c073c:	mov	x0, x28
1004c0740:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c0744:	mov	x0, x22
1004c0748:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004c074c:	tbz	w0, #0x0, 0x1004c0af8
1004c0750:	ldp	x19, x8, [x22, #0x10]
1004c0754:	add	x25, x19, #0x1
1004c0758:	cmp	x19, x8, lsr #1
1004c075c:	b.hs	0x1004c0b20
1004c0760:	str	x25, [x22, #0x10]
1004c0764:	mov	w8, #0x38
1004c0768:	madd	x8, x19, x8, x22
1004c076c:	mov	x9, #0x6f57
1004c0770:	movk	x9, #0x6472, lsl #16
1004c0774:	movk	x9, #0x5720, lsl #32
1004c0778:	movk	x9, #0x6172, lsl #48
1004c077c:	mov	x10, #0x70
1004c0780:	movk	x10, #0xe900, lsl #48
1004c0784:	stp	x9, x10, [x8, #0x20]
1004c0788:	stp	x21, x27, [x8, #0x30]
1004c078c:	adrp	x9, -1213 ; 0x100003000
1004c0790:	add	x9, x9, #0x8c4
1004c0794:	stp	xzr, x9, [x8, #0x40]
1004c0798:	str	x24, [x8, #0x50]
1004c079c:	mov	x0, x23
1004c07a0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c07a4:	bl	0x10010385c
1004c07a8:	tst	w0, #0x1
1004c07ac:	csel	x19, x26, xzr, ne
1004c07b0:	mov	x8, #-0x5d00000000000000
1004c07b4:	csel	x21, x8, xzr, ne
1004c07b8:	adrp	x0, 7450 ; 0x1021da000
1004c07bc:	add	x0, x0, #0xb30
1004c07c0:	mov	w1, #0x18
1004c07c4:	mov	w2, #0x7
1004c07c8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c07cc:	mov	x23, x0
1004c07d0:	add	x0, x0, #0x10
1004c07d4:	mov	x1, x20
1004c07d8:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c07dc:	adrp	x0, 7450 ; 0x1021da000
1004c07e0:	add	x0, x0, #0xba8
1004c07e4:	mov	w1, #0x20
1004c07e8:	mov	w2, #0x7
1004c07ec:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c07f0:	mov	x25, x0
1004c07f4:	stp	x23, x28, [x0, #0x10]
1004c07f8:	adrp	x0, 7450 ; 0x1021da000
1004c07fc:	add	x0, x0, #0xbd0
1004c0800:	mov	w1, #0x20
1004c0804:	mov	w2, #0x7
1004c0808:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c080c:	mov	x24, x0
1004c0810:	adrp	x8, 0 ; 0x1004c0000
1004c0814:	add	x8, x8, #0xc20
1004c0818:	stp	x8, x25, [x0, #0x10]
1004c081c:	mov	x0, x28
1004c0820:	ldp	x27, x28, [x22, #0x10]
1004c0824:	add	x25, x27, #0x1
1004c0828:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c082c:	mov	x0, x23
1004c0830:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c0834:	cmp	x27, x28, lsr #1
1004c0838:	b.hs	0x1004c0b48
1004c083c:	str	x25, [x22, #0x10]
1004c0840:	mov	w8, #0x38
1004c0844:	madd	x8, x27, x8, x22
1004c0848:	mov	x9, #0x694c
1004c084c:	movk	x9, #0x656e, lsl #16
1004c0850:	movk	x9, #0x4e20, lsl #32
1004c0854:	movk	x9, #0x6d75, lsl #48
1004c0858:	mov	x10, #0x6562
1004c085c:	movk	x10, #0x7372, lsl #16
1004c0860:	movk	x10, #0xec00, lsl #48
1004c0864:	stp	x9, x10, [x8, #0x20]
1004c0868:	stp	x19, x21, [x8, #0x30]
1004c086c:	adrp	x9, -1212 ; 0x100004000
1004c0870:	add	x9, x9, #0xcc
1004c0874:	stp	xzr, x9, [x8, #0x40]
1004c0878:	str	x24, [x8, #0x50]
1004c087c:	mov	x0, x23
1004c0880:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c0884:	adrp	x8, 7961 ; 0x1023d9000
1004c0888:	add	x8, x8, #0x848
1004c088c:	ldr	x8, [x8]
1004c0890:	ldrb	w8, [x20, x8]
1004c0894:	tbz	w8, #0x0, 0x1004c08a8
1004c0898:	ldr	x0, [sp, #0x28]
1004c089c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c08a0:	mov	x21, x20
1004c08a4:	b	0x1004c0a74
1004c08a8:	ldp	x19, x8, [x22, #0x10]
1004c08ac:	add	x23, x19, #0x1
1004c08b0:	cmp	x19, x8, lsr #1
1004c08b4:	b.hs	0x1004c0bbc
1004c08b8:	mov	w21, #0x9ce2
1004c08bc:	movk	w21, #0x93, lsl #16
1004c08c0:	mov	w10, #0x2d2d
1004c08c4:	movk	w10, #0x2d, lsl #16
1004c08c8:	str	x23, [x22, #0x10]
1004c08cc:	mov	w8, #0x38
1004c08d0:	madd	x8, x19, x8, x22
1004c08d4:	mov	x9, #-0x1d00000000000000
1004c08d8:	stp	x10, x9, [x8, #0x20]
1004c08dc:	stp	xzr, xzr, [x8, #0x30]
1004c08e0:	adrp	x9, -1213 ; 0x100003000
1004c08e4:	add	x9, x9, #0xf40
1004c08e8:	stp	xzr, x9, [x8, #0x40]
1004c08ec:	str	xzr, [x8, #0x50]
1004c08f0:	adrp	x8, 7961 ; 0x1023d9000
1004c08f4:	add	x8, x8, #0x838
1004c08f8:	ldr	x19, [x8]
1004c08fc:	add	x0, x20, x19
1004c0900:	add	x1, sp, #0x50
1004c0904:	mov	x2, #0x0
1004c0908:	mov	x3, #0x0
1004c090c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c0910:	ldrb	w8, [x20, x19]
1004c0914:	cmp	w8, #0x0
1004c0918:	csel	x9, x21, xzr, ne
1004c091c:	mov	x8, #-0x5d00000000000000
1004c0920:	csel	x8, x8, xzr, ne
1004c0924:	stp	x8, x9, [sp, #0x10]
1004c0928:	mov	x8, #0x614d
1004c092c:	movk	x8, #0x656b, lsl #16
1004c0930:	movk	x8, #0x4520, lsl #32
1004c0934:	movk	x8, #0x6964, lsl #48
1004c0938:	mov	x9, #0x614d
1004c093c:	movk	x9, #0x656b, lsl #16
1004c0940:	movk	x9, #0x5220, lsl #32
1004c0944:	movk	x9, #0x6165, lsl #48
1004c0948:	csel	x8, x9, x8, ne
1004c094c:	str	x8, [sp, #0x8]
1004c0950:	mov	x8, #0x6174
1004c0954:	movk	x8, #0x6c62, lsl #16
1004c0958:	movk	x8, #0x65, lsl #32
1004c095c:	movk	x8, #0xed00, lsl #48
1004c0960:	mov	x9, #0x2d64
1004c0964:	movk	x9, #0x6e4f, lsl #16
1004c0968:	movk	x9, #0x796c, lsl #32
1004c096c:	movk	x9, #0xee00, lsl #48
1004c0970:	csel	x21, x9, x8, ne
1004c0974:	adrp	x0, 7450 ; 0x1021da000
1004c0978:	add	x0, x0, #0xb30
1004c097c:	mov	w1, #0x18
1004c0980:	mov	w2, #0x7
1004c0984:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c0988:	mov	x23, x0
1004c098c:	add	x0, x0, #0x10
1004c0990:	mov	x1, x20
1004c0994:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c0998:	mov	x0, x20
1004c099c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c09a0:	adrp	x0, 7450 ; 0x1021da000
1004c09a4:	add	x0, x0, #0xae0
1004c09a8:	mov	w1, #0x18
1004c09ac:	mov	w2, #0x7
1004c09b0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c09b4:	mov	x24, x0
1004c09b8:	add	x0, x0, #0x10
1004c09bc:	ldr	x1, [sp, #0x28]
1004c09c0:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c09c4:	adrp	x0, 7450 ; 0x1021da000
1004c09c8:	add	x0, x0, #0xbf8
1004c09cc:	mov	w1, #0x28
1004c09d0:	mov	w2, #0x7
1004c09d4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c09d8:	mov	x26, x0
1004c09dc:	stp	x23, x24, [x0, #0x10]
1004c09e0:	ldr	x28, [sp, #0x20]
1004c09e4:	str	x28, [x0, #0x20]
1004c09e8:	adrp	x0, 7450 ; 0x1021da000
1004c09ec:	add	x0, x0, #0xc20
1004c09f0:	mov	w1, #0x20
1004c09f4:	mov	w2, #0x7
1004c09f8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c09fc:	mov	x25, x0
1004c0a00:	adrp	x8, 0 ; 0x1004c0000
1004c0a04:	add	x8, x8, #0xd14
1004c0a08:	stp	x8, x26, [x0, #0x10]
1004c0a0c:	ldp	x19, x27, [x22, #0x10]
1004c0a10:	add	x26, x19, #0x1
1004c0a14:	mov	x0, x28
1004c0a18:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c0a1c:	mov	x0, x23
1004c0a20:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c0a24:	mov	x0, x24
1004c0a28:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c0a2c:	cmp	x19, x27, lsr #1
1004c0a30:	b.hs	0x1004c0be4
1004c0a34:	str	x26, [x22, #0x10]
1004c0a38:	mov	w8, #0x38
1004c0a3c:	madd	x8, x19, x8, x22
1004c0a40:	ldr	x9, [sp, #0x8]
1004c0a44:	stp	x9, x21, [x8, #0x20]
1004c0a48:	ldp	x9, x10, [sp, #0x10]
1004c0a4c:	stp	x10, x9, [x8, #0x30]
1004c0a50:	adrp	x9, -1212 ; 0x100004000
1004c0a54:	add	x9, x9, #0xcc
1004c0a58:	stp	xzr, x9, [x8, #0x40]
1004c0a5c:	str	x25, [x8, #0x50]
1004c0a60:	mov	x0, x24
1004c0a64:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c0a68:	mov	x0, x23
1004c0a6c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c0a70:	ldr	x21, [sp, #0x28]
1004c0a74:	mov	x0, x20
1004c0a78:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0a7c:	mov	x0, x21
1004c0a80:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0a84:	mov	x0, x22
1004c0a88:	ldp	x29, x30, [sp, #0xd0]
1004c0a8c:	ldp	x20, x19, [sp, #0xc0]
1004c0a90:	ldp	x22, x21, [sp, #0xb0]
1004c0a94:	ldp	x24, x23, [sp, #0xa0]
1004c0a98:	ldp	x26, x25, [sp, #0x90]
1004c0a9c:	ldp	x28, x27, [sp, #0x80]
1004c0aa0:	add	sp, sp, #0xe0
1004c0aa4:	ret
1004c0aa8:	cmp	x8, #0x1
1004c0aac:	cset	w0, hi
1004c0ab0:	adrp	x4, 7695 ; 0x1022cf000
1004c0ab4:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c0ab8:	mov	x1, x27
1004c0abc:	mov	w2, #0x1
1004c0ac0:	mov	x3, x22
1004c0ac4:	bl	0x1004bfb6c
1004c0ac8:	mov	x22, x0
1004c0acc:	b	0x1004c04ec
1004c0ad0:	cmp	x27, #0x1
1004c0ad4:	cset	w0, hi
1004c0ad8:	adrp	x4, 7695 ; 0x1022cf000
1004c0adc:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c0ae0:	mov	x1, x25
1004c0ae4:	mov	w2, #0x1
1004c0ae8:	mov	x3, x22
1004c0aec:	bl	0x1004bfb6c
1004c0af0:	mov	x22, x0
1004c0af4:	b	0x1004c05d4
1004c0af8:	ldr	x8, [x22, #0x10]
1004c0afc:	adrp	x4, 7695 ; 0x1022cf000
1004c0b00:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c0b04:	add	x1, x8, #0x1
1004c0b08:	mov	w0, #0x0
1004c0b0c:	mov	w2, #0x1
1004c0b10:	mov	x3, x22
1004c0b14:	bl	0x1004bfb6c
1004c0b18:	mov	x22, x0
1004c0b1c:	b	0x1004c0750
1004c0b20:	cmp	x8, #0x1
1004c0b24:	cset	w0, hi
1004c0b28:	adrp	x4, 7695 ; 0x1022cf000
1004c0b2c:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c0b30:	mov	x1, x25
1004c0b34:	mov	w2, #0x1
1004c0b38:	mov	x3, x22
1004c0b3c:	bl	0x1004bfb6c
1004c0b40:	mov	x22, x0
1004c0b44:	b	0x1004c0760
1004c0b48:	cmp	x28, #0x1
1004c0b4c:	cset	w0, hi
1004c0b50:	adrp	x4, 7695 ; 0x1022cf000
1004c0b54:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c0b58:	mov	x1, x25
1004c0b5c:	mov	w2, #0x1
1004c0b60:	mov	x3, x22
1004c0b64:	bl	0x1004bfb6c
1004c0b68:	mov	x22, x0
1004c0b6c:	b	0x1004c083c
1004c0b70:	adrp	x4, 7695 ; 0x1022cf000
1004c0b74:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c0b78:	add	x1, x19, #0x1
1004c0b7c:	mov	w0, #0x0
1004c0b80:	mov	w2, #0x1
1004c0b84:	mov	x3, x22
1004c0b88:	bl	0x1004bfb6c
1004c0b8c:	mov	x22, x0
1004c0b90:	b	0x1004c0670
1004c0b94:	cmp	x8, #0x1
1004c0b98:	cset	w0, hi
1004c0b9c:	adrp	x4, 7695 ; 0x1022cf000
1004c0ba0:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c0ba4:	mov	x1, x23
1004c0ba8:	mov	w2, #0x1
1004c0bac:	mov	x3, x22
1004c0bb0:	bl	0x1004bfb6c
1004c0bb4:	mov	x22, x0
1004c0bb8:	b	0x1004c0680
1004c0bbc:	cmp	x8, #0x1
1004c0bc0:	cset	w0, hi
1004c0bc4:	adrp	x4, 7695 ; 0x1022cf000
1004c0bc8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c0bcc:	mov	x1, x23
1004c0bd0:	mov	w2, #0x1
1004c0bd4:	mov	x3, x22
1004c0bd8:	bl	0x1004bfb6c
1004c0bdc:	mov	x22, x0
1004c0be0:	b	0x1004c08b8
1004c0be4:	cmp	x27, #0x1
1004c0be8:	cset	w0, hi
1004c0bec:	adrp	x4, 7695 ; 0x1022cf000
1004c0bf0:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c0bf4:	mov	x1, x26
1004c0bf8:	mov	w2, #0x1
1004c0bfc:	mov	x3, x22
1004c0c00:	bl	0x1004bfb6c
1004c0c04:	mov	x22, x0
1004c0c08:	b	0x1004c0a34
1004c0c0c:	adrp	x0, -1051 ; 0x1000a5000
1004c0c10:	add	x0, x0, #0x7b8
1004c0c14:	adrp	x1, -1051 ; 0x1000a5000
1004c0c18:	add	x1, x1, #0x800
1004c0c1c:	b	0x1004c0c34
1004c0c20:	adrp	x0, -957 ; 0x100103000
1004c0c24:	add	x0, x0, #0x85c
1004c0c28:	adrp	x1, -957 ; 0x100103000
1004c0c2c:	add	x1, x1, #0x8a0
1004c0c30:	b	0x1004c0c34
1004c0c34:	sub	sp, sp, #0x70
1004c0c38:	stp	x24, x23, [sp, #0x30]
1004c0c3c:	stp	x22, x21, [sp, #0x40]
1004c0c40:	stp	x20, x19, [sp, #0x50]
1004c0c44:	stp	x29, x30, [sp, #0x60]
1004c0c48:	add	x29, sp, #0x60
1004c0c4c:	mov	x19, x1
1004c0c50:	mov	x21, x0
1004c0c54:	ldp	x23, x22, [x20, #0x10]
1004c0c58:	add	x0, x23, #0x10
1004c0c5c:	add	x1, sp, #0x18
1004c0c60:	mov	x2, #0x0
1004c0c64:	mov	x3, #0x0
1004c0c68:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c0c6c:	add	x0, x23, #0x10
1004c0c70:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c0c74:	cbz	x0, 0x1004c0cfc
1004c0c78:	mov	x20, x0
1004c0c7c:	blr	x21
1004c0c80:	mov	w8, #0x1
1004c0c84:	bic	w0, w8, w0
1004c0c88:	blr	x19
1004c0c8c:	add	x0, x22, #0x10
1004c0c90:	mov	x1, sp
1004c0c94:	mov	x2, #0x0
1004c0c98:	mov	x3, #0x0
1004c0c9c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c0ca0:	add	x0, x22, #0x10
1004c0ca4:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c0ca8:	cbz	x0, 0x1004c0cf4
1004c0cac:	mov	x19, x0
1004c0cb0:	adrp	x8, 7782 ; 0x102326000
1004c0cb4:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c0cb8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c0cbc:	bl	0x101acce80 ; selector defaultCenter
1004c0cc0:	mov	x29, x29
1004c0cc4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c0cc8:	mov	x21, x0
1004c0ccc:	bl	0x10006e844
1004c0cd0:	ldr	x2, [x0]
1004c0cd4:	mov	x0, x21
1004c0cd8:	mov	x3, #0x0
1004c0cdc:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c0ce0:	mov	x0, x20
1004c0ce4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0ce8:	mov	x0, x19
1004c0cec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0cf0:	mov	x20, x21
1004c0cf4:	mov	x0, x20
1004c0cf8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0cfc:	ldp	x29, x30, [sp, #0x60]
1004c0d00:	ldp	x20, x19, [sp, #0x50]
1004c0d04:	ldp	x22, x21, [sp, #0x40]
1004c0d08:	ldp	x24, x23, [sp, #0x30]
1004c0d0c:	add	sp, sp, #0x70
1004c0d10:	ret
1004c0d14:	sub	sp, sp, #0x90
1004c0d18:	stp	x22, x21, [sp, #0x60]
1004c0d1c:	stp	x20, x19, [sp, #0x70]
1004c0d20:	stp	x29, x30, [sp, #0x80]
1004c0d24:	add	x29, sp, #0x80
1004c0d28:	ldp	x19, x22, [x20, #0x10]
1004c0d2c:	ldr	x21, [x20, #0x20]
1004c0d30:	add	x0, x19, #0x10
1004c0d34:	sub	x1, x29, #0x38
1004c0d38:	mov	x2, #0x0
1004c0d3c:	mov	x3, #0x0
1004c0d40:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c0d44:	add	x0, x19, #0x10
1004c0d48:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c0d4c:	cbz	x0, 0x1004c0e20
1004c0d50:	mov	x19, x0
1004c0d54:	add	x0, x22, #0x10
1004c0d58:	add	x1, sp, #0x30
1004c0d5c:	mov	x2, #0x0
1004c0d60:	mov	x3, #0x0
1004c0d64:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c0d68:	add	x0, x22, #0x10
1004c0d6c:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c0d70:	cbz	x0, 0x1004c0db0
1004c0d74:	mov	x20, x0
1004c0d78:	adrp	x8, 7961 ; 0x1023d9000
1004c0d7c:	add	x8, x8, #0x838
1004c0d80:	ldr	x22, [x8]
1004c0d84:	add	x0, x19, x22
1004c0d88:	add	x1, sp, #0x18
1004c0d8c:	mov	x2, #0x0
1004c0d90:	mov	x3, #0x0
1004c0d94:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c0d98:	ldrb	w8, [x19, x22]
1004c0d9c:	mov	w9, #0x1
1004c0da0:	bic	w0, w9, w8
1004c0da4:	bl	0x1000e0978
1004c0da8:	mov	x0, x20
1004c0dac:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0db0:	add	x0, x21, #0x10
1004c0db4:	mov	x1, sp
1004c0db8:	mov	x2, #0x0
1004c0dbc:	mov	x3, #0x0
1004c0dc0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c0dc4:	add	x0, x21, #0x10
1004c0dc8:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c0dcc:	cbz	x0, 0x1004c0e18
1004c0dd0:	mov	x20, x0
1004c0dd4:	adrp	x8, 7782 ; 0x102326000
1004c0dd8:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c0ddc:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c0de0:	bl	0x101acce80 ; selector defaultCenter
1004c0de4:	mov	x29, x29
1004c0de8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c0dec:	mov	x21, x0
1004c0df0:	bl	0x10006e844
1004c0df4:	ldr	x2, [x0]
1004c0df8:	mov	x0, x21
1004c0dfc:	mov	x3, #0x0
1004c0e00:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c0e04:	mov	x0, x19
1004c0e08:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0e0c:	mov	x0, x20
1004c0e10:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0e14:	mov	x19, x21
1004c0e18:	mov	x0, x19
1004c0e1c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0e20:	ldp	x29, x30, [sp, #0x80]
1004c0e24:	ldp	x20, x19, [sp, #0x70]
1004c0e28:	ldp	x22, x21, [sp, #0x60]
1004c0e2c:	add	sp, sp, #0x90
1004c0e30:	ret
1004c0e34:	mov	w0, #0x0
1004c0e38:	b	0x1004c0e44
1004c0e3c:	mov	w0, #0x1
1004c0e40:	b	0x1004c0e44
1004c0e44:	sub	sp, sp, #0x40
1004c0e48:	stp	x20, x19, [sp, #0x20]
1004c0e4c:	stp	x29, x30, [sp, #0x30]
1004c0e50:	add	x29, sp, #0x30
1004c0e54:	mov	x19, x0
1004c0e58:	add	x0, x20, #0x10
1004c0e5c:	add	x1, sp, #0x8
1004c0e60:	mov	x2, #0x0
1004c0e64:	mov	x3, #0x0
1004c0e68:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c0e6c:	add	x0, x20, #0x10
1004c0e70:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c0e74:	cbz	x0, 0x1004c0e8c
1004c0e78:	mov	x20, x0
1004c0e7c:	mov	x0, x19
1004c0e80:	bl	0x1000e092c
1004c0e84:	mov	x0, x20
1004c0e88:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0e8c:	ldp	x29, x30, [sp, #0x30]
1004c0e90:	ldp	x20, x19, [sp, #0x20]
1004c0e94:	add	sp, sp, #0x40
1004c0e98:	ret
1004c0e9c:	sub	sp, sp, #0x60
1004c0ea0:	stp	x22, x21, [sp, #0x30]
1004c0ea4:	stp	x20, x19, [sp, #0x40]
1004c0ea8:	stp	x29, x30, [sp, #0x50]
1004c0eac:	add	x29, sp, #0x50
1004c0eb0:	ldp	x21, x19, [x20, #0x10]
1004c0eb4:	add	x0, x21, #0x10
1004c0eb8:	add	x1, sp, #0x18
1004c0ebc:	mov	x2, #0x0
1004c0ec0:	mov	x3, #0x0
1004c0ec4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c0ec8:	add	x0, x21, #0x10
1004c0ecc:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c0ed0:	cbz	x0, 0x1004c0ee4
1004c0ed4:	mov	x20, x0
1004c0ed8:	bl	0x1000d0a94
1004c0edc:	mov	x0, x20
1004c0ee0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0ee4:	add	x0, x19, #0x10
1004c0ee8:	mov	x1, sp
1004c0eec:	mov	x2, #0x0
1004c0ef0:	mov	x3, #0x0
1004c0ef4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c0ef8:	add	x0, x19, #0x10
1004c0efc:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c0f00:	cbz	x0, 0x1004c0f2c
1004c0f04:	mov	x20, x0
1004c0f08:	ldr	x8, [x0]
1004c0f0c:	adrp	x9, 7695 ; 0x1022cf000
1004c0f10:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004c0f14:	ldr	x9, [x9]
1004c0f18:	and	x8, x9, x8
1004c0f1c:	ldr	x8, [x8, #0x248]
1004c0f20:	blr	x8
1004c0f24:	mov	x0, x20
1004c0f28:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c0f2c:	ldp	x29, x30, [sp, #0x50]
1004c0f30:	ldp	x20, x19, [sp, #0x40]
1004c0f34:	ldp	x22, x21, [sp, #0x30]
1004c0f38:	add	sp, sp, #0x60
1004c0f3c:	ret
1004c0f40:	stp	x29, x30, [sp, #-0x10]!
1004c0f44:	mov	x29, sp
1004c0f48:	ldp	x0, x1, [x20, #0x10]
1004c0f4c:	adrp	x2, 1 ; 0x1004c1000
1004c0f50:	add	x2, x2, #0xbc
1004c0f54:	adrp	x3, 7450 ; 0x1021da000
1004c0f58:	add	x3, x3, #0xd78
1004c0f5c:	bl	0x1004bd4f4
1004c0f60:	ldp	x29, x30, [sp], #0x10
1004c0f64:	ret
1004c0f68:	stp	x29, x30, [sp, #-0x10]!
1004c0f6c:	mov	x29, sp
1004c0f70:	ldp	x0, x1, [x20, #0x10]
1004c0f74:	adrp	x2, 1 ; 0x1004c1000
1004c0f78:	add	x2, x2, #0x14
1004c0f7c:	adrp	x3, 7450 ; 0x1021da000
1004c0f80:	add	x3, x3, #0xd50
1004c0f84:	bl	0x1004bd4f4
1004c0f88:	ldp	x29, x30, [sp], #0x10
1004c0f8c:	ret
1004c0f90:	stp	x29, x30, [sp, #-0x10]!
1004c0f94:	mov	x29, sp
1004c0f98:	ldp	x0, x1, [x20, #0x10]
1004c0f9c:	adrp	x2, 0 ; 0x1004c0000
1004c0fa0:	add	x2, x2, #0xfb8
1004c0fa4:	adrp	x3, 7450 ; 0x1021da000
1004c0fa8:	add	x3, x3, #0xd28
1004c0fac:	bl	0x1004bd4f4
1004c0fb0:	ldp	x29, x30, [sp], #0x10
1004c0fb4:	ret
1004c0fb8:	sub	sp, sp, #0x40
1004c0fbc:	stp	x20, x19, [sp, #0x20]
1004c0fc0:	stp	x29, x30, [sp, #0x30]
1004c0fc4:	add	x29, sp, #0x30
1004c0fc8:	add	x0, x20, #0x10
1004c0fcc:	add	x1, sp, #0x8
1004c0fd0:	mov	x2, #0x0
1004c0fd4:	mov	x3, #0x0
1004c0fd8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c0fdc:	add	x0, x20, #0x10
1004c0fe0:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c0fe4:	cbz	x0, 0x1004c1004
1004c0fe8:	mov	x20, x0
1004c0fec:	mov	w0, #0x1
1004c0ff0:	mov	x1, #0x0
1004c0ff4:	mov	x2, #0x0
1004c0ff8:	bl	0x1000b6d5c
1004c0ffc:	mov	x0, x20
1004c1000:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1004:	ldp	x29, x30, [sp, #0x30]
1004c1008:	ldp	x20, x19, [sp, #0x20]
1004c100c:	add	sp, sp, #0x40
1004c1010:	ret
1004c1014:	sub	sp, sp, #0x50
1004c1018:	stp	x20, x19, [sp, #0x30]
1004c101c:	stp	x29, x30, [sp, #0x40]
1004c1020:	add	x29, sp, #0x40
1004c1024:	add	x0, x20, #0x10
1004c1028:	add	x1, sp, #0x18
1004c102c:	mov	x2, #0x0
1004c1030:	mov	x3, #0x0
1004c1034:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1038:	add	x0, x20, #0x10
1004c103c:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c1040:	cbz	x0, 0x1004c108c
1004c1044:	mov	x20, x0
1004c1048:	adrp	x8, 7960 ; 0x1023d9000
1004c104c:	add	x8, x8, #0x898
1004c1050:	ldr	x19, [x8]
1004c1054:	add	x0, x0, x19
1004c1058:	mov	x1, sp
1004c105c:	mov	x2, #0x0
1004c1060:	mov	x3, #0x0
1004c1064:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1068:	ldrb	w8, [x20, x19]
1004c106c:	cmp	w8, #0x1
1004c1070:	b.ne	0x1004c1084
1004c1074:	bl	0x1000d06cc
1004c1078:	mov	x0, x20
1004c107c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1080:	b	0x1004c10ac
1004c1084:	mov	x0, x20
1004c1088:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c108c:	adrp	x1, 7809 ; 0x102342000
1004c1090:	add	x1, x1, #0x9a0
1004c1094:	adrp	x2, 7781 ; 0x102326000
1004c1098:	add	x2, x2, #0xb48 ; Objc class ref: _OBJC_CLASS_$_NSSound
1004c109c:	mov	x0, #0x0
1004c10a0:	bl	0x10002d97c
1004c10a4:	mov	x20, x0
1004c10a8:	bl	0x101ac6fac ; symbol stub for: _$sSo7NSSoundC6AppKitE4beepyyFZ
1004c10ac:	ldp	x29, x30, [sp, #0x40]
1004c10b0:	ldp	x20, x19, [sp, #0x30]
1004c10b4:	add	sp, sp, #0x50
1004c10b8:	ret
1004c10bc:	sub	sp, sp, #0x40
1004c10c0:	stp	x20, x19, [sp, #0x20]
1004c10c4:	stp	x29, x30, [sp, #0x30]
1004c10c8:	add	x29, sp, #0x30
1004c10cc:	add	x0, x20, #0x10
1004c10d0:	add	x1, sp, #0x8
1004c10d4:	mov	x2, #0x0
1004c10d8:	mov	x3, #0x0
1004c10dc:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c10e0:	add	x0, x20, #0x10
1004c10e4:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c10e8:	cbz	x0, 0x1004c10fc
1004c10ec:	mov	x20, x0
1004c10f0:	bl	0x1000b5b1c
1004c10f4:	mov	x0, x20
1004c10f8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c10fc:	ldp	x29, x30, [sp, #0x30]
1004c1100:	ldp	x20, x19, [sp, #0x20]
1004c1104:	add	sp, sp, #0x40
1004c1108:	ret
1004c110c:	sub	sp, sp, #0x70
1004c1110:	stp	x24, x23, [sp, #0x30]
1004c1114:	stp	x22, x21, [sp, #0x40]
1004c1118:	stp	x20, x19, [sp, #0x50]
1004c111c:	stp	x29, x30, [sp, #0x60]
1004c1120:	add	x29, sp, #0x60
1004c1124:	mov	x19, x20
1004c1128:	mov	x0, #0x0
1004c112c:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004c1130:	ldur	x8, [x0, #-0x8]
1004c1134:	ldrb	w8, [x8, #0x50]
1004c1138:	add	x9, x8, #0x18
1004c113c:	bic	x21, x9, x8
1004c1140:	ldr	x22, [x20, #0x10]
1004c1144:	add	x0, x22, #0x10
1004c1148:	add	x1, sp, #0x18
1004c114c:	mov	x2, #0x0
1004c1150:	mov	x3, #0x0
1004c1154:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1158:	add	x0, x22, #0x10
1004c115c:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c1160:	adrp	x23, 7694 ; 0x1022cf000
1004c1164:	ldr	x23, [x23, #0x718] ; literal pool symbol address: _swift_isaMask
1004c1168:	cbz	x0, 0x1004c118c
1004c116c:	mov	x20, x0
1004c1170:	ldr	x8, [x0]
1004c1174:	ldr	x9, [x23]
1004c1178:	and	x8, x9, x8
1004c117c:	ldr	x8, [x8, #0x248]
1004c1180:	blr	x8
1004c1184:	mov	x0, x20
1004c1188:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c118c:	add	x20, x19, x21
1004c1190:	bl	0x101ac4df8 ; symbol stub for: _$s10Foundation3URLV4pathSSvg
1004c1194:	mov	x21, x0
1004c1198:	mov	x19, x1
1004c119c:	add	x0, x22, #0x10
1004c11a0:	mov	x1, sp
1004c11a4:	mov	x2, #0x0
1004c11a8:	mov	x3, #0x0
1004c11ac:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c11b0:	add	x0, x22, #0x10
1004c11b4:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c11b8:	cbz	x0, 0x1004c1208
1004c11bc:	adrp	x8, 7900 ; 0x10239d000
1004c11c0:	ldr	x8, [x8, #0x250]
1004c11c4:	mov	x20, x0
1004c11c8:	add	x0, x0, x8
1004c11cc:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c11d0:	mov	x22, x0
1004c11d4:	mov	x0, x20
1004c11d8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c11dc:	cbz	x22, 0x1004c1208
1004c11e0:	ldr	x8, [x22]
1004c11e4:	ldr	x9, [x23]
1004c11e8:	and	x8, x9, x8
1004c11ec:	ldr	x8, [x8, #0x278]
1004c11f0:	mov	x20, x22
1004c11f4:	blr	x8
1004c11f8:	mov	x20, x0
1004c11fc:	mov	x0, x22
1004c1200:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1204:	b	0x1004c120c
1004c1208:	mov	x20, #0x0
1004c120c:	mov	x0, x21
1004c1210:	mov	x1, x19
1004c1214:	mov	x2, x20
1004c1218:	bl	0x1005ffef8
1004c121c:	mov	x0, x19
1004c1220:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c1224:	mov	x0, x20
1004c1228:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c122c:	ldp	x29, x30, [sp, #0x60]
1004c1230:	ldp	x20, x19, [sp, #0x50]
1004c1234:	ldp	x22, x21, [sp, #0x40]
1004c1238:	ldp	x24, x23, [sp, #0x30]
1004c123c:	add	sp, sp, #0x70
1004c1240:	ret
1004c1244:	b	0x10021f7e8
1004c1248:	sub	sp, sp, #0x90
1004c124c:	stp	x24, x23, [sp, #0x50]
1004c1250:	stp	x22, x21, [sp, #0x60]
1004c1254:	stp	x20, x19, [sp, #0x70]
1004c1258:	stp	x29, x30, [sp, #0x80]
1004c125c:	add	x29, sp, #0x80
1004c1260:	mov	x0, #0x0
1004c1264:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004c1268:	ldur	x8, [x0, #-0x8]
1004c126c:	ldrb	w8, [x8, #0x50]
1004c1270:	add	x9, x8, #0x18
1004c1274:	bic	x19, x9, x8
1004c1278:	ldr	x23, [x20, #0x10]
1004c127c:	add	x0, x23, #0x10
1004c1280:	add	x1, sp, #0x38
1004c1284:	mov	x2, #0x0
1004c1288:	mov	x3, #0x0
1004c128c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1290:	add	x0, x23, #0x10
1004c1294:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c1298:	cbz	x0, 0x1004c12c0
1004c129c:	mov	x22, x0
1004c12a0:	add	x0, x20, x19
1004c12a4:	mov	x20, x22
1004c12a8:	bl	0x1004bcb44
1004c12ac:	mov	x21, x0
1004c12b0:	mov	x19, x1
1004c12b4:	mov	x0, x22
1004c12b8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c12bc:	b	0x1004c12d0
1004c12c0:	add	x20, x20, x19
1004c12c4:	bl	0x101ac4d74 ; symbol stub for: _$s10Foundation3URLV17lastPathComponentSSvg
1004c12c8:	mov	x21, x0
1004c12cc:	mov	x19, x1
1004c12d0:	add	x0, x23, #0x10
1004c12d4:	add	x1, sp, #0x20
1004c12d8:	mov	x2, #0x0
1004c12dc:	mov	x3, #0x0
1004c12e0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c12e4:	add	x0, x23, #0x10
1004c12e8:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c12ec:	adrp	x24, 7694 ; 0x1022cf000
1004c12f0:	ldr	x24, [x24, #0x718] ; literal pool symbol address: _swift_isaMask
1004c12f4:	cbz	x0, 0x1004c1318
1004c12f8:	mov	x20, x0
1004c12fc:	ldr	x8, [x0]
1004c1300:	ldr	x9, [x24]
1004c1304:	and	x8, x9, x8
1004c1308:	ldr	x8, [x8, #0x248]
1004c130c:	blr	x8
1004c1310:	mov	x0, x20
1004c1314:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1318:	add	x0, x23, #0x10
1004c131c:	add	x1, sp, #0x8
1004c1320:	mov	x2, #0x0
1004c1324:	mov	x3, #0x0
1004c1328:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c132c:	add	x0, x23, #0x10
1004c1330:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c1334:	cbz	x0, 0x1004c1384
1004c1338:	adrp	x8, 7900 ; 0x10239d000
1004c133c:	ldr	x8, [x8, #0x250]
1004c1340:	mov	x20, x0
1004c1344:	add	x0, x0, x8
1004c1348:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c134c:	mov	x22, x0
1004c1350:	mov	x0, x20
1004c1354:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1358:	cbz	x22, 0x1004c1384
1004c135c:	ldr	x8, [x22]
1004c1360:	ldr	x9, [x24]
1004c1364:	and	x8, x9, x8
1004c1368:	ldr	x8, [x8, #0x278]
1004c136c:	mov	x20, x22
1004c1370:	blr	x8
1004c1374:	mov	x20, x0
1004c1378:	mov	x0, x22
1004c137c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1380:	b	0x1004c1388
1004c1384:	mov	x20, #0x0
1004c1388:	mov	x0, x21
1004c138c:	mov	x1, x19
1004c1390:	mov	x2, x20
1004c1394:	bl	0x1005ffef8
1004c1398:	mov	x0, x19
1004c139c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c13a0:	mov	x0, x20
1004c13a4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c13a8:	ldp	x29, x30, [sp, #0x80]
1004c13ac:	ldp	x20, x19, [sp, #0x70]
1004c13b0:	ldp	x22, x21, [sp, #0x60]
1004c13b4:	ldp	x24, x23, [sp, #0x50]
1004c13b8:	add	sp, sp, #0x90
1004c13bc:	ret
1004c13c0:	b	0x1004c64cc
1004c13c4:	stp	x29, x30, [sp, #-0x10]!
1004c13c8:	mov	x29, sp
1004c13cc:	mov	x0, #0x0
1004c13d0:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004c13d4:	ldur	x8, [x0, #-0x8]
1004c13d8:	ldrb	w8, [x8, #0x50]
1004c13dc:	add	x9, x8, #0x10
1004c13e0:	bic	x8, x9, x8
1004c13e4:	add	x0, x20, x8
1004c13e8:	ldp	x29, x30, [sp], #0x10
1004c13ec:	b	0x1004bc188
1004c13f0:	stp	x22, x21, [sp, #-0x30]!
1004c13f4:	stp	x20, x19, [sp, #0x10]
1004c13f8:	stp	x29, x30, [sp, #0x20]
1004c13fc:	add	x29, sp, #0x20
1004c1400:	mov	x0, #0x0
1004c1404:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004c1408:	mov	x1, x0
1004c140c:	ldur	x8, [x0, #-0x8]
1004c1410:	ldrb	w19, [x8, #0x50]
1004c1414:	add	x9, x19, #0x10
1004c1418:	bic	x9, x9, x19
1004c141c:	ldr	x10, [x8, #0x40]
1004c1420:	add	x10, x10, x9
1004c1424:	add	x10, x10, #0x7
1004c1428:	and	x21, x10, #0xfffffffffffffff8
1004c142c:	ldr	x8, [x8, #0x8]
1004c1430:	add	x0, x20, x9
1004c1434:	blr	x8
1004c1438:	add	x22, x20, x21
1004c143c:	ldr	x0, [x22, #0x8]
1004c1440:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c1444:	ldr	x0, [x22, #0x18]
1004c1448:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c144c:	add	x1, x21, #0x21
1004c1450:	orr	x2, x19, #0x7
1004c1454:	mov	x0, x20
1004c1458:	ldp	x29, x30, [sp, #0x20]
1004c145c:	ldp	x20, x19, [sp, #0x10]
1004c1460:	ldp	x22, x21, [sp], #0x30
1004c1464:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004c1468:	stp	x22, x21, [sp, #-0x30]!
1004c146c:	stp	x20, x19, [sp, #0x10]
1004c1470:	stp	x29, x30, [sp, #0x20]
1004c1474:	add	x29, sp, #0x20
1004c1478:	mov	x19, x20
1004c147c:	mov	x0, #0x0
1004c1480:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004c1484:	ldur	x8, [x0, #-0x8]
1004c1488:	ldrb	w9, [x8, #0x50]
1004c148c:	add	x10, x9, #0x10
1004c1490:	bic	x9, x10, x9
1004c1494:	ldr	x8, [x8, #0x40]
1004c1498:	add	x8, x8, x9
1004c149c:	add	x8, x8, #0x7
1004c14a0:	and	x21, x8, #0xfffffffffffffff8
1004c14a4:	add	x20, x20, x9
1004c14a8:	bl	0x101ac4df8 ; symbol stub for: _$s10Foundation3URLV4pathSSvg
1004c14ac:	mov	x20, x1
1004c14b0:	add	x5, x19, x21
1004c14b4:	mov	x2, #0x0
1004c14b8:	mov	x3, #0x0
1004c14bc:	mov	w4, #0x100
1004c14c0:	bl	0x10057b4a4
1004c14c4:	mov	x0, x20
1004c14c8:	ldp	x29, x30, [sp, #0x20]
1004c14cc:	ldp	x20, x19, [sp, #0x10]
1004c14d0:	ldp	x22, x21, [sp], #0x30
1004c14d4:	b	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c14d8:	stp	x29, x30, [sp, #-0x10]!
1004c14dc:	mov	x29, sp
1004c14e0:	ldr	x0, [x20, #0x18]
1004c14e4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c14e8:	mov	x0, x20
1004c14ec:	mov	w1, #0x20
1004c14f0:	mov	w2, #0x7
1004c14f4:	ldp	x29, x30, [sp], #0x10
1004c14f8:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004c14fc:	stp	x26, x25, [sp, #-0x50]!
1004c1500:	stp	x24, x23, [sp, #0x10]
1004c1504:	stp	x22, x21, [sp, #0x20]
1004c1508:	stp	x20, x19, [sp, #0x30]
1004c150c:	stp	x29, x30, [sp, #0x40]
1004c1510:	add	x29, sp, #0x40
1004c1514:	mov	x0, #0x0
1004c1518:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004c151c:	mov	x19, x0
1004c1520:	ldur	x23, [x0, #-0x8]
1004c1524:	ldrb	w22, [x23, #0x50]
1004c1528:	add	x8, x22, #0x10
1004c152c:	bic	x24, x8, x22
1004c1530:	adrp	x8, 7781 ; 0x102326000
1004c1534:	ldr	x0, [x8, #0xa10] ; Objc class ref: _OBJC_CLASS_$_NSWorkspace
1004c1538:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c153c:	bl	0x101ad4ec0 ; selector sharedWorkspace
1004c1540:	mov	x29, x29
1004c1544:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c1548:	mov	x21, x0
1004c154c:	adrp	x0, 7842 ; 0x102363000
1004c1550:	add	x0, x0, #0xa00
1004c1554:	adrp	x1, 5676 ; 0x101aed000
1004c1558:	add	x1, x1, #0x9e0
1004c155c:	bl	0x100003c4c
1004c1560:	ldr	x8, [x23, #0x48]
1004c1564:	add	x9, x22, #0x20
1004c1568:	bic	x25, x9, x22
1004c156c:	add	x1, x25, x8
1004c1570:	orr	x2, x22, #0x7
1004c1574:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c1578:	mov	x22, x0
1004c157c:	adrp	x8, 5664 ; 0x101ae1000
1004c1580:	ldr	q0, [x8, #0x130]
1004c1584:	str	q0, [x0, #0x10]
1004c1588:	ldr	x8, [x23, #0x10]
1004c158c:	add	x0, x0, x25
1004c1590:	add	x1, x20, x24
1004c1594:	mov	x2, x19
1004c1598:	blr	x8
1004c159c:	mov	x0, x22
1004c15a0:	mov	x1, x19
1004c15a4:	bl	0x101ac6754 ; symbol stub for: _$sSa10FoundationE19_bridgeToObjectiveCSo7NSArrayCyF
1004c15a8:	mov	x19, x0
1004c15ac:	mov	x0, x22
1004c15b0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c15b4:	mov	x0, x21
1004c15b8:	mov	x2, x19
1004c15bc:	bl	0x101acb100 ; selector activateFileViewerSelectingURLs:
1004c15c0:	mov	x0, x19
1004c15c4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c15c8:	mov	x0, x21
1004c15cc:	ldp	x29, x30, [sp, #0x40]
1004c15d0:	ldp	x20, x19, [sp, #0x30]
1004c15d4:	ldp	x22, x21, [sp, #0x20]
1004c15d8:	ldp	x24, x23, [sp, #0x10]
1004c15dc:	ldp	x26, x25, [sp], #0x50
1004c15e0:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004c15e4:	stp	x20, x19, [sp, #-0x20]!
1004c15e8:	stp	x29, x30, [sp, #0x10]
1004c15ec:	add	x29, sp, #0x10
1004c15f0:	mov	x0, #0x0
1004c15f4:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004c15f8:	ldur	x8, [x0, #-0x8]
1004c15fc:	ldrb	w8, [x8, #0x50]
1004c1600:	add	x9, x8, #0x10
1004c1604:	bic	x8, x9, x8
1004c1608:	add	x20, x20, x8
1004c160c:	bl	0x101ac4df8 ; symbol stub for: _$s10Foundation3URLV4pathSSvg
1004c1610:	mov	x19, x1
1004c1614:	mov	x2, #0x0
1004c1618:	mov	x3, #0x0
1004c161c:	mov	w4, #0x100
1004c1620:	bl	0x10057b6e0
1004c1624:	mov	x0, x19
1004c1628:	ldp	x29, x30, [sp, #0x10]
1004c162c:	ldp	x20, x19, [sp], #0x20
1004c1630:	b	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c1634:	adrp	x1, 7900 ; 0x10239d000
1004c1638:	add	x1, x1, #0x2f8
1004c163c:	adrp	x2, 6591 ; 0x101e80000
1004c1640:	add	x2, x2, #0x9a8
1004c1644:	b	0x1000a01d0
1004c1648:	b	0x1003dd514
1004c164c:	sub	sp, sp, #0x40
1004c1650:	stp	x20, x19, [sp, #0x20]
1004c1654:	stp	x29, x30, [sp, #0x30]
1004c1658:	add	x29, sp, #0x30
1004c165c:	mov	x8, x20
1004c1660:	ldr	x20, [x20, #0x10]
1004c1664:	ldr	x19, [x8, #0x18]
1004c1668:	cmp	x0, #0x3e8
1004c166c:	b.eq	0x1004c1680
1004c1670:	cmp	x0, #0x3e9
1004c1674:	b.ne	0x1004c1690
1004c1678:	mov	w0, #0x1
1004c167c:	b	0x1004c1684
1004c1680:	mov	w0, #0x0
1004c1684:	ldr	x8, [x20]
1004c1688:	ldr	x8, [x8, #0x5d8]
1004c168c:	blr	x8
1004c1690:	add	x0, x19, #0x10
1004c1694:	add	x1, sp, #0x8
1004c1698:	mov	x2, #0x0
1004c169c:	mov	x3, #0x0
1004c16a0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c16a4:	add	x0, x19, #0x10
1004c16a8:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c16ac:	cbz	x0, 0x1004c16f4
1004c16b0:	mov	x19, x0
1004c16b4:	adrp	x8, 7781 ; 0x102326000
1004c16b8:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c16bc:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c16c0:	bl	0x101acce80 ; selector defaultCenter
1004c16c4:	mov	x29, x29
1004c16c8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c16cc:	mov	x20, x0
1004c16d0:	bl	0x10006e844
1004c16d4:	ldr	x2, [x0]
1004c16d8:	mov	x0, x20
1004c16dc:	mov	x3, #0x0
1004c16e0:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c16e4:	mov	x0, x20
1004c16e8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c16ec:	mov	x0, x19
1004c16f0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c16f4:	ldp	x29, x30, [sp, #0x30]
1004c16f8:	ldp	x20, x19, [sp, #0x20]
1004c16fc:	add	sp, sp, #0x40
1004c1700:	ret
1004c1704:	sub	sp, sp, #0x50
1004c1708:	stp	x22, x21, [sp, #0x20]
1004c170c:	stp	x20, x19, [sp, #0x30]
1004c1710:	stp	x29, x30, [sp, #0x40]
1004c1714:	add	x29, sp, #0x40
1004c1718:	ldp	x19, x21, [x20, #0x10]
1004c171c:	ldr	x8, [x19]
1004c1720:	ldr	x8, [x8, #0xf0]
1004c1724:	mov	w0, #0x0
1004c1728:	mov	x20, x19
1004c172c:	blr	x8
1004c1730:	ldr	x8, [x19]
1004c1734:	ldr	x8, [x8, #0x108]
1004c1738:	mov	w0, #0x0
1004c173c:	blr	x8
1004c1740:	adrp	x0, 7808 ; 0x102341000
1004c1744:	add	x0, x0, #0x6d0
1004c1748:	adrp	x1, 5664 ; 0x101ae1000
1004c174c:	add	x1, x1, #0x7e0
1004c1750:	bl	0x100003c4c
1004c1754:	adrp	x1, 7828 ; 0x102355000
1004c1758:	add	x1, x1, #0x4f0
1004c175c:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c1760:	ldr	x8, [x19]
1004c1764:	ldr	x8, [x8, #0x2d0]
1004c1768:	blr	x8
1004c176c:	add	x0, x21, #0x10
1004c1770:	add	x1, sp, #0x8
1004c1774:	mov	x2, #0x0
1004c1778:	mov	x3, #0x0
1004c177c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1780:	add	x0, x21, #0x10
1004c1784:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c1788:	cbz	x0, 0x1004c17d0
1004c178c:	mov	x19, x0
1004c1790:	adrp	x8, 7781 ; 0x102326000
1004c1794:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c1798:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c179c:	bl	0x101acce80 ; selector defaultCenter
1004c17a0:	mov	x29, x29
1004c17a4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c17a8:	mov	x20, x0
1004c17ac:	bl	0x10006e844
1004c17b0:	ldr	x2, [x0]
1004c17b4:	mov	x0, x20
1004c17b8:	mov	x3, #0x0
1004c17bc:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c17c0:	mov	x0, x20
1004c17c4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c17c8:	mov	x0, x19
1004c17cc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c17d0:	ldp	x29, x30, [sp, #0x40]
1004c17d4:	ldp	x20, x19, [sp, #0x30]
1004c17d8:	ldp	x22, x21, [sp, #0x20]
1004c17dc:	add	sp, sp, #0x50
1004c17e0:	ret
1004c17e4:	sub	sp, sp, #0x50
1004c17e8:	stp	x22, x21, [sp, #0x20]
1004c17ec:	stp	x20, x19, [sp, #0x30]
1004c17f0:	stp	x29, x30, [sp, #0x40]
1004c17f4:	add	x29, sp, #0x40
1004c17f8:	ldp	x19, x21, [x20, #0x10]
1004c17fc:	ldr	x8, [x19]
1004c1800:	ldr	x8, [x8, #0xf8]
1004c1804:	mov	x0, sp
1004c1808:	mov	x20, x19
1004c180c:	blr	x8
1004c1810:	mov	x8, x0
1004c1814:	ldrb	w9, [x1]
1004c1818:	mov	w10, #0x1
1004c181c:	bic	w9, w10, w9
1004c1820:	strb	w9, [x1]
1004c1824:	mov	x0, sp
1004c1828:	mov	w1, #0x0
1004c182c:	blr	x8
1004c1830:	adrp	x0, 7808 ; 0x102341000
1004c1834:	add	x0, x0, #0x6d0
1004c1838:	adrp	x1, 5664 ; 0x101ae1000
1004c183c:	add	x1, x1, #0x7e0
1004c1840:	bl	0x100003c4c
1004c1844:	adrp	x1, 7828 ; 0x102355000
1004c1848:	add	x1, x1, #0x4b8
1004c184c:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c1850:	ldr	x8, [x19]
1004c1854:	ldr	x8, [x8, #0x2d0]
1004c1858:	blr	x8
1004c185c:	add	x0, x21, #0x10
1004c1860:	mov	x1, sp
1004c1864:	mov	x2, #0x0
1004c1868:	mov	x3, #0x0
1004c186c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1870:	add	x0, x21, #0x10
1004c1874:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c1878:	cbz	x0, 0x1004c18c0
1004c187c:	mov	x19, x0
1004c1880:	adrp	x8, 7781 ; 0x102326000
1004c1884:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c1888:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c188c:	bl	0x101acce80 ; selector defaultCenter
1004c1890:	mov	x29, x29
1004c1894:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c1898:	mov	x20, x0
1004c189c:	bl	0x10006e844
1004c18a0:	ldr	x2, [x0]
1004c18a4:	mov	x0, x20
1004c18a8:	mov	x3, #0x0
1004c18ac:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c18b0:	mov	x0, x20
1004c18b4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c18b8:	mov	x0, x19
1004c18bc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c18c0:	ldp	x29, x30, [sp, #0x40]
1004c18c4:	ldp	x20, x19, [sp, #0x30]
1004c18c8:	ldp	x22, x21, [sp, #0x20]
1004c18cc:	add	sp, sp, #0x50
1004c18d0:	ret
1004c18d4:	sub	sp, sp, #0x50
1004c18d8:	stp	x22, x21, [sp, #0x20]
1004c18dc:	stp	x20, x19, [sp, #0x30]
1004c18e0:	stp	x29, x30, [sp, #0x40]
1004c18e4:	add	x29, sp, #0x40
1004c18e8:	ldp	x19, x21, [x20, #0x10]
1004c18ec:	ldr	x8, [x19]
1004c18f0:	ldr	x8, [x8, #0x110]
1004c18f4:	mov	x0, sp
1004c18f8:	mov	x20, x19
1004c18fc:	blr	x8
1004c1900:	mov	x8, x0
1004c1904:	ldrb	w9, [x1]
1004c1908:	mov	w10, #0x1
1004c190c:	bic	w9, w10, w9
1004c1910:	strb	w9, [x1]
1004c1914:	mov	x0, sp
1004c1918:	mov	w1, #0x0
1004c191c:	blr	x8
1004c1920:	adrp	x0, 7808 ; 0x102341000
1004c1924:	add	x0, x0, #0x6d0
1004c1928:	adrp	x1, 5664 ; 0x101ae1000
1004c192c:	add	x1, x1, #0x7e0
1004c1930:	bl	0x100003c4c
1004c1934:	adrp	x1, 7828 ; 0x102355000
1004c1938:	add	x1, x1, #0x480
1004c193c:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c1940:	ldr	x8, [x19]
1004c1944:	ldr	x8, [x8, #0x2d0]
1004c1948:	blr	x8
1004c194c:	add	x0, x21, #0x10
1004c1950:	mov	x1, sp
1004c1954:	mov	x2, #0x0
1004c1958:	mov	x3, #0x0
1004c195c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1960:	add	x0, x21, #0x10
1004c1964:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c1968:	cbz	x0, 0x1004c19b0
1004c196c:	mov	x19, x0
1004c1970:	adrp	x8, 7781 ; 0x102326000
1004c1974:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c1978:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c197c:	bl	0x101acce80 ; selector defaultCenter
1004c1980:	mov	x29, x29
1004c1984:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c1988:	mov	x20, x0
1004c198c:	bl	0x10006e844
1004c1990:	ldr	x2, [x0]
1004c1994:	mov	x0, x20
1004c1998:	mov	x3, #0x0
1004c199c:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c19a0:	mov	x0, x20
1004c19a4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c19a8:	mov	x0, x19
1004c19ac:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c19b0:	ldp	x29, x30, [sp, #0x40]
1004c19b4:	ldp	x20, x19, [sp, #0x30]
1004c19b8:	ldp	x22, x21, [sp, #0x20]
1004c19bc:	add	sp, sp, #0x50
1004c19c0:	ret
1004c19c4:	sub	sp, sp, #0x50
1004c19c8:	stp	x22, x21, [sp, #0x20]
1004c19cc:	stp	x20, x19, [sp, #0x30]
1004c19d0:	stp	x29, x30, [sp, #0x40]
1004c19d4:	add	x29, sp, #0x40
1004c19d8:	ldp	x19, x21, [x20, #0x10]
1004c19dc:	ldr	x8, [x19]
1004c19e0:	ldr	x8, [x8, #0x120]
1004c19e4:	mov	w0, #0x0
1004c19e8:	mov	x20, x19
1004c19ec:	blr	x8
1004c19f0:	ldr	x8, [x19]
1004c19f4:	ldr	x8, [x8, #0x138]
1004c19f8:	mov	w0, #0x0
1004c19fc:	blr	x8
1004c1a00:	ldr	x8, [x19]
1004c1a04:	ldr	x8, [x8, #0x150]
1004c1a08:	mov	w0, #0x0
1004c1a0c:	blr	x8
1004c1a10:	ldr	x8, [x19]
1004c1a14:	ldr	x8, [x8, #0x168]
1004c1a18:	mov	w0, #0x0
1004c1a1c:	blr	x8
1004c1a20:	adrp	x0, 7808 ; 0x102341000
1004c1a24:	add	x0, x0, #0x6d0
1004c1a28:	adrp	x1, 5664 ; 0x101ae1000
1004c1a2c:	add	x1, x1, #0x7e0
1004c1a30:	bl	0x100003c4c
1004c1a34:	adrp	x1, 7828 ; 0x102355000
1004c1a38:	add	x1, x1, #0x418
1004c1a3c:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c1a40:	ldr	x8, [x19]
1004c1a44:	ldr	x8, [x8, #0x2d0]
1004c1a48:	blr	x8
1004c1a4c:	add	x0, x21, #0x10
1004c1a50:	add	x1, sp, #0x8
1004c1a54:	mov	x2, #0x0
1004c1a58:	mov	x3, #0x0
1004c1a5c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1a60:	add	x0, x21, #0x10
1004c1a64:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c1a68:	cbz	x0, 0x1004c1ab0
1004c1a6c:	mov	x19, x0
1004c1a70:	adrp	x8, 7781 ; 0x102326000
1004c1a74:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c1a78:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c1a7c:	bl	0x101acce80 ; selector defaultCenter
1004c1a80:	mov	x29, x29
1004c1a84:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c1a88:	mov	x20, x0
1004c1a8c:	bl	0x10006e844
1004c1a90:	ldr	x2, [x0]
1004c1a94:	mov	x0, x20
1004c1a98:	mov	x3, #0x0
1004c1a9c:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c1aa0:	mov	x0, x20
1004c1aa4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1aa8:	mov	x0, x19
1004c1aac:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1ab0:	ldp	x29, x30, [sp, #0x40]
1004c1ab4:	ldp	x20, x19, [sp, #0x30]
1004c1ab8:	ldp	x22, x21, [sp, #0x20]
1004c1abc:	add	sp, sp, #0x50
1004c1ac0:	ret
1004c1ac4:	sub	sp, sp, #0x50
1004c1ac8:	stp	x22, x21, [sp, #0x20]
1004c1acc:	stp	x20, x19, [sp, #0x30]
1004c1ad0:	stp	x29, x30, [sp, #0x40]
1004c1ad4:	add	x29, sp, #0x40
1004c1ad8:	ldp	x19, x21, [x20, #0x10]
1004c1adc:	ldr	x8, [x19]
1004c1ae0:	ldr	x8, [x8, #0x128]
1004c1ae4:	mov	x0, sp
1004c1ae8:	mov	x20, x19
1004c1aec:	blr	x8
1004c1af0:	mov	x8, x0
1004c1af4:	ldrb	w9, [x1]
1004c1af8:	mov	w10, #0x1
1004c1afc:	bic	w9, w10, w9
1004c1b00:	strb	w9, [x1]
1004c1b04:	mov	x0, sp
1004c1b08:	mov	w1, #0x0
1004c1b0c:	blr	x8
1004c1b10:	adrp	x0, 7808 ; 0x102341000
1004c1b14:	add	x0, x0, #0x6d0
1004c1b18:	adrp	x1, 5664 ; 0x101ae1000
1004c1b1c:	add	x1, x1, #0x7e0
1004c1b20:	bl	0x100003c4c
1004c1b24:	adrp	x1, 7828 ; 0x102355000
1004c1b28:	add	x1, x1, #0x3e0
1004c1b2c:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c1b30:	ldr	x8, [x19]
1004c1b34:	ldr	x8, [x8, #0x2d0]
1004c1b38:	blr	x8
1004c1b3c:	add	x0, x21, #0x10
1004c1b40:	mov	x1, sp
1004c1b44:	mov	x2, #0x0
1004c1b48:	mov	x3, #0x0
1004c1b4c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1b50:	add	x0, x21, #0x10
1004c1b54:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c1b58:	cbz	x0, 0x1004c1ba0
1004c1b5c:	mov	x19, x0
1004c1b60:	adrp	x8, 7781 ; 0x102326000
1004c1b64:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c1b68:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c1b6c:	bl	0x101acce80 ; selector defaultCenter
1004c1b70:	mov	x29, x29
1004c1b74:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c1b78:	mov	x20, x0
1004c1b7c:	bl	0x10006e844
1004c1b80:	ldr	x2, [x0]
1004c1b84:	mov	x0, x20
1004c1b88:	mov	x3, #0x0
1004c1b8c:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c1b90:	mov	x0, x20
1004c1b94:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1b98:	mov	x0, x19
1004c1b9c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1ba0:	ldp	x29, x30, [sp, #0x40]
1004c1ba4:	ldp	x20, x19, [sp, #0x30]
1004c1ba8:	ldp	x22, x21, [sp, #0x20]
1004c1bac:	add	sp, sp, #0x50
1004c1bb0:	ret
1004c1bb4:	sub	sp, sp, #0x50
1004c1bb8:	stp	x22, x21, [sp, #0x20]
1004c1bbc:	stp	x20, x19, [sp, #0x30]
1004c1bc0:	stp	x29, x30, [sp, #0x40]
1004c1bc4:	add	x29, sp, #0x40
1004c1bc8:	ldp	x19, x21, [x20, #0x10]
1004c1bcc:	ldr	x8, [x19]
1004c1bd0:	ldr	x8, [x8, #0x140]
1004c1bd4:	mov	x0, sp
1004c1bd8:	mov	x20, x19
1004c1bdc:	blr	x8
1004c1be0:	mov	x8, x0
1004c1be4:	ldrb	w9, [x1]
1004c1be8:	mov	w10, #0x1
1004c1bec:	bic	w9, w10, w9
1004c1bf0:	strb	w9, [x1]
1004c1bf4:	mov	x0, sp
1004c1bf8:	mov	w1, #0x0
1004c1bfc:	blr	x8
1004c1c00:	adrp	x0, 7808 ; 0x102341000
1004c1c04:	add	x0, x0, #0x6d0
1004c1c08:	adrp	x1, 5664 ; 0x101ae1000
1004c1c0c:	add	x1, x1, #0x7e0
1004c1c10:	bl	0x100003c4c
1004c1c14:	adrp	x1, 7828 ; 0x102355000
1004c1c18:	add	x1, x1, #0x3a8
1004c1c1c:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c1c20:	ldr	x8, [x19]
1004c1c24:	ldr	x8, [x8, #0x2d0]
1004c1c28:	blr	x8
1004c1c2c:	add	x0, x21, #0x10
1004c1c30:	mov	x1, sp
1004c1c34:	mov	x2, #0x0
1004c1c38:	mov	x3, #0x0
1004c1c3c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1c40:	add	x0, x21, #0x10
1004c1c44:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c1c48:	cbz	x0, 0x1004c1c90
1004c1c4c:	mov	x19, x0
1004c1c50:	adrp	x8, 7781 ; 0x102326000
1004c1c54:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c1c58:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c1c5c:	bl	0x101acce80 ; selector defaultCenter
1004c1c60:	mov	x29, x29
1004c1c64:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c1c68:	mov	x20, x0
1004c1c6c:	bl	0x10006e844
1004c1c70:	ldr	x2, [x0]
1004c1c74:	mov	x0, x20
1004c1c78:	mov	x3, #0x0
1004c1c7c:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c1c80:	mov	x0, x20
1004c1c84:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1c88:	mov	x0, x19
1004c1c8c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1c90:	ldp	x29, x30, [sp, #0x40]
1004c1c94:	ldp	x20, x19, [sp, #0x30]
1004c1c98:	ldp	x22, x21, [sp, #0x20]
1004c1c9c:	add	sp, sp, #0x50
1004c1ca0:	ret
1004c1ca4:	sub	sp, sp, #0x50
1004c1ca8:	stp	x22, x21, [sp, #0x20]
1004c1cac:	stp	x20, x19, [sp, #0x30]
1004c1cb0:	stp	x29, x30, [sp, #0x40]
1004c1cb4:	add	x29, sp, #0x40
1004c1cb8:	ldp	x19, x21, [x20, #0x10]
1004c1cbc:	ldr	x8, [x19]
1004c1cc0:	ldr	x8, [x8, #0x158]
1004c1cc4:	mov	x0, sp
1004c1cc8:	mov	x20, x19
1004c1ccc:	blr	x8
1004c1cd0:	mov	x8, x0
1004c1cd4:	ldrb	w9, [x1]
1004c1cd8:	mov	w10, #0x1
1004c1cdc:	bic	w9, w10, w9
1004c1ce0:	strb	w9, [x1]
1004c1ce4:	mov	x0, sp
1004c1ce8:	mov	w1, #0x0
1004c1cec:	blr	x8
1004c1cf0:	adrp	x0, 7808 ; 0x102341000
1004c1cf4:	add	x0, x0, #0x6d0
1004c1cf8:	adrp	x1, 5664 ; 0x101ae1000
1004c1cfc:	add	x1, x1, #0x7e0
1004c1d00:	bl	0x100003c4c
1004c1d04:	adrp	x1, 7828 ; 0x102355000
1004c1d08:	add	x1, x1, #0x370
1004c1d0c:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c1d10:	ldr	x8, [x19]
1004c1d14:	ldr	x8, [x8, #0x2d0]
1004c1d18:	blr	x8
1004c1d1c:	add	x0, x21, #0x10
1004c1d20:	mov	x1, sp
1004c1d24:	mov	x2, #0x0
1004c1d28:	mov	x3, #0x0
1004c1d2c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1d30:	add	x0, x21, #0x10
1004c1d34:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c1d38:	cbz	x0, 0x1004c1d80
1004c1d3c:	mov	x19, x0
1004c1d40:	adrp	x8, 7781 ; 0x102326000
1004c1d44:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c1d48:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c1d4c:	bl	0x101acce80 ; selector defaultCenter
1004c1d50:	mov	x29, x29
1004c1d54:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c1d58:	mov	x20, x0
1004c1d5c:	bl	0x10006e844
1004c1d60:	ldr	x2, [x0]
1004c1d64:	mov	x0, x20
1004c1d68:	mov	x3, #0x0
1004c1d6c:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c1d70:	mov	x0, x20
1004c1d74:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1d78:	mov	x0, x19
1004c1d7c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1d80:	ldp	x29, x30, [sp, #0x40]
1004c1d84:	ldp	x20, x19, [sp, #0x30]
1004c1d88:	ldp	x22, x21, [sp, #0x20]
1004c1d8c:	add	sp, sp, #0x50
1004c1d90:	ret
1004c1d94:	sub	sp, sp, #0x50
1004c1d98:	stp	x22, x21, [sp, #0x20]
1004c1d9c:	stp	x20, x19, [sp, #0x30]
1004c1da0:	stp	x29, x30, [sp, #0x40]
1004c1da4:	add	x29, sp, #0x40
1004c1da8:	ldp	x19, x21, [x20, #0x10]
1004c1dac:	ldr	x8, [x19]
1004c1db0:	ldr	x8, [x8, #0x170]
1004c1db4:	mov	x0, sp
1004c1db8:	mov	x20, x19
1004c1dbc:	blr	x8
1004c1dc0:	mov	x8, x0
1004c1dc4:	ldrb	w9, [x1]
1004c1dc8:	mov	w10, #0x1
1004c1dcc:	bic	w9, w10, w9
1004c1dd0:	strb	w9, [x1]
1004c1dd4:	mov	x0, sp
1004c1dd8:	mov	w1, #0x0
1004c1ddc:	blr	x8
1004c1de0:	adrp	x0, 7808 ; 0x102341000
1004c1de4:	add	x0, x0, #0x6d0
1004c1de8:	adrp	x1, 5664 ; 0x101ae1000
1004c1dec:	add	x1, x1, #0x7e0
1004c1df0:	bl	0x100003c4c
1004c1df4:	adrp	x1, 7828 ; 0x102355000
1004c1df8:	add	x1, x1, #0x338
1004c1dfc:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c1e00:	ldr	x8, [x19]
1004c1e04:	ldr	x8, [x8, #0x2d0]
1004c1e08:	blr	x8
1004c1e0c:	add	x0, x21, #0x10
1004c1e10:	mov	x1, sp
1004c1e14:	mov	x2, #0x0
1004c1e18:	mov	x3, #0x0
1004c1e1c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1e20:	add	x0, x21, #0x10
1004c1e24:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c1e28:	cbz	x0, 0x1004c1e70
1004c1e2c:	mov	x19, x0
1004c1e30:	adrp	x8, 7781 ; 0x102326000
1004c1e34:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c1e38:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c1e3c:	bl	0x101acce80 ; selector defaultCenter
1004c1e40:	mov	x29, x29
1004c1e44:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c1e48:	mov	x20, x0
1004c1e4c:	bl	0x10006e844
1004c1e50:	ldr	x2, [x0]
1004c1e54:	mov	x0, x20
1004c1e58:	mov	x3, #0x0
1004c1e5c:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c1e60:	mov	x0, x20
1004c1e64:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1e68:	mov	x0, x19
1004c1e6c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1e70:	ldp	x29, x30, [sp, #0x40]
1004c1e74:	ldp	x20, x19, [sp, #0x30]
1004c1e78:	ldp	x22, x21, [sp, #0x20]
1004c1e7c:	add	sp, sp, #0x50
1004c1e80:	ret
1004c1e84:	stp	x29, x30, [sp, #-0x10]!
1004c1e88:	mov	x29, sp
1004c1e8c:	add	x0, x20, #0x10
1004c1e90:	bl	0x101acab4c ; symbol stub for: _swift_weakDestroy
1004c1e94:	mov	x0, x20
1004c1e98:	mov	w1, #0x18
1004c1e9c:	mov	w2, #0x7
1004c1ea0:	ldp	x29, x30, [sp], #0x10
1004c1ea4:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004c1ea8:	b	0x10026b71c
1004c1eac:	sub	sp, sp, #0x70
1004c1eb0:	stp	x22, x21, [sp, #0x40]
1004c1eb4:	stp	x20, x19, [sp, #0x50]
1004c1eb8:	stp	x29, x30, [sp, #0x60]
1004c1ebc:	add	x29, sp, #0x60
1004c1ec0:	ldp	x19, x22, [x20, #0x10]
1004c1ec4:	ldr	x21, [x20, #0x20]
1004c1ec8:	ldr	x8, [x19]
1004c1ecc:	ldr	x8, [x8, #0x188]
1004c1ed0:	add	x0, sp, #0x20
1004c1ed4:	mov	x20, x19
1004c1ed8:	blr	x8
1004c1edc:	mov	x8, x0
1004c1ee0:	ldrb	w9, [x1]
1004c1ee4:	mov	w10, #0x1
1004c1ee8:	bic	w9, w10, w9
1004c1eec:	strb	w9, [x1]
1004c1ef0:	add	x0, sp, #0x20
1004c1ef4:	mov	w1, #0x0
1004c1ef8:	blr	x8
1004c1efc:	adrp	x0, 7808 ; 0x102341000
1004c1f00:	add	x0, x0, #0x6d0
1004c1f04:	adrp	x1, 5664 ; 0x101ae1000
1004c1f08:	add	x1, x1, #0x7e0
1004c1f0c:	bl	0x100003c4c
1004c1f10:	adrp	x1, 7828 ; 0x102355000
1004c1f14:	add	x1, x1, #0x300
1004c1f18:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c1f1c:	ldr	x8, [x19]
1004c1f20:	ldr	x8, [x8, #0x2d0]
1004c1f24:	blr	x8
1004c1f28:	add	x0, x22, #0x10
1004c1f2c:	add	x1, sp, #0x20
1004c1f30:	mov	x2, #0x0
1004c1f34:	mov	x3, #0x0
1004c1f38:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1f3c:	add	x0, x22, #0x10
1004c1f40:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004c1f44:	cbz	x0, 0x1004c1f60
1004c1f48:	mov	x20, x0
1004c1f4c:	ldr	x8, [x0]
1004c1f50:	ldr	x8, [x8, #0x6c8]
1004c1f54:	blr	x8
1004c1f58:	mov	x0, x20
1004c1f5c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c1f60:	add	x0, x21, #0x10
1004c1f64:	add	x1, sp, #0x8
1004c1f68:	mov	x2, #0x0
1004c1f6c:	mov	x3, #0x0
1004c1f70:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c1f74:	add	x0, x21, #0x10
1004c1f78:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c1f7c:	cbz	x0, 0x1004c1fc4
1004c1f80:	mov	x19, x0
1004c1f84:	adrp	x8, 7781 ; 0x102326000
1004c1f88:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c1f8c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c1f90:	bl	0x101acce80 ; selector defaultCenter
1004c1f94:	mov	x29, x29
1004c1f98:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c1f9c:	mov	x20, x0
1004c1fa0:	bl	0x10006e844
1004c1fa4:	ldr	x2, [x0]
1004c1fa8:	mov	x0, x20
1004c1fac:	mov	x3, #0x0
1004c1fb0:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c1fb4:	mov	x0, x20
1004c1fb8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1fbc:	mov	x0, x19
1004c1fc0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c1fc4:	ldp	x29, x30, [sp, #0x60]
1004c1fc8:	ldp	x20, x19, [sp, #0x50]
1004c1fcc:	ldp	x22, x21, [sp, #0x40]
1004c1fd0:	add	sp, sp, #0x70
1004c1fd4:	ret
1004c1fd8:	sub	sp, sp, #0x70
1004c1fdc:	stp	x22, x21, [sp, #0x40]
1004c1fe0:	stp	x20, x19, [sp, #0x50]
1004c1fe4:	stp	x29, x30, [sp, #0x60]
1004c1fe8:	add	x29, sp, #0x60
1004c1fec:	ldp	x19, x22, [x20, #0x10]
1004c1ff0:	ldr	x21, [x20, #0x20]
1004c1ff4:	ldr	x8, [x19]
1004c1ff8:	ldr	x8, [x8, #0x1a0]
1004c1ffc:	add	x0, sp, #0x20
1004c2000:	mov	x20, x19
1004c2004:	blr	x8
1004c2008:	mov	x8, x0
1004c200c:	ldrb	w9, [x1]
1004c2010:	mov	w10, #0x1
1004c2014:	bic	w9, w10, w9
1004c2018:	strb	w9, [x1]
1004c201c:	add	x0, sp, #0x20
1004c2020:	mov	w1, #0x0
1004c2024:	blr	x8
1004c2028:	adrp	x0, 7807 ; 0x102341000
1004c202c:	add	x0, x0, #0x6d0
1004c2030:	adrp	x1, 5663 ; 0x101ae1000
1004c2034:	add	x1, x1, #0x7e0
1004c2038:	bl	0x100003c4c
1004c203c:	adrp	x1, 7827 ; 0x102355000
1004c2040:	add	x1, x1, #0x2c8
1004c2044:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c2048:	ldr	x8, [x19]
1004c204c:	ldr	x8, [x8, #0x2d0]
1004c2050:	blr	x8
1004c2054:	add	x0, x22, #0x10
1004c2058:	add	x1, sp, #0x20
1004c205c:	mov	x2, #0x0
1004c2060:	mov	x3, #0x0
1004c2064:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c2068:	add	x0, x22, #0x10
1004c206c:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004c2070:	cbz	x0, 0x1004c208c
1004c2074:	mov	x20, x0
1004c2078:	ldr	x8, [x0]
1004c207c:	ldr	x8, [x8, #0x6c8]
1004c2080:	blr	x8
1004c2084:	mov	x0, x20
1004c2088:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c208c:	add	x0, x21, #0x10
1004c2090:	add	x1, sp, #0x8
1004c2094:	mov	x2, #0x0
1004c2098:	mov	x3, #0x0
1004c209c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c20a0:	add	x0, x21, #0x10
1004c20a4:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c20a8:	cbz	x0, 0x1004c20f0
1004c20ac:	mov	x19, x0
1004c20b0:	adrp	x8, 7780 ; 0x102326000
1004c20b4:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c20b8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c20bc:	bl	0x101acce80 ; selector defaultCenter
1004c20c0:	mov	x29, x29
1004c20c4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c20c8:	mov	x20, x0
1004c20cc:	bl	0x10006e844
1004c20d0:	ldr	x2, [x0]
1004c20d4:	mov	x0, x20
1004c20d8:	mov	x3, #0x0
1004c20dc:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c20e0:	mov	x0, x20
1004c20e4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c20e8:	mov	x0, x19
1004c20ec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c20f0:	ldp	x29, x30, [sp, #0x60]
1004c20f4:	ldp	x20, x19, [sp, #0x50]
1004c20f8:	ldp	x22, x21, [sp, #0x40]
1004c20fc:	add	sp, sp, #0x70
1004c2100:	ret
1004c2104:	adrp	x0, 7449 ; 0x1021db000
1004c2108:	add	x0, x0, #0x508
1004c210c:	adrp	x1, 0 ; 0x1004c2000
1004c2110:	add	x1, x1, #0x798
1004c2114:	b	0x1004c6aac
1004c2118:	sub	sp, sp, #0x50
1004c211c:	stp	x22, x21, [sp, #0x20]
1004c2120:	stp	x20, x19, [sp, #0x30]
1004c2124:	stp	x29, x30, [sp, #0x40]
1004c2128:	add	x29, sp, #0x40
1004c212c:	ldp	x19, x21, [x20, #0x10]
1004c2130:	ldr	x8, [x19]
1004c2134:	ldr	x8, [x8, #0x260]
1004c2138:	mov	x0, sp
1004c213c:	mov	x20, x19
1004c2140:	blr	x8
1004c2144:	mov	x8, x0
1004c2148:	ldrb	w9, [x1]
1004c214c:	mov	w10, #0x1
1004c2150:	bic	w9, w10, w9
1004c2154:	strb	w9, [x1]
1004c2158:	mov	x0, sp
1004c215c:	mov	w1, #0x0
1004c2160:	blr	x8
1004c2164:	adrp	x0, 7807 ; 0x102341000
1004c2168:	add	x0, x0, #0x6d0
1004c216c:	adrp	x1, 5663 ; 0x101ae1000
1004c2170:	add	x1, x1, #0x7e0
1004c2174:	bl	0x100003c4c
1004c2178:	adrp	x1, 7827 ; 0x102355000
1004c217c:	add	x1, x1, #0x258
1004c2180:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c2184:	ldr	x8, [x19]
1004c2188:	ldr	x8, [x8, #0x2d0]
1004c218c:	blr	x8
1004c2190:	add	x0, x21, #0x10
1004c2194:	mov	x1, sp
1004c2198:	mov	x2, #0x0
1004c219c:	mov	x3, #0x0
1004c21a0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c21a4:	add	x0, x21, #0x10
1004c21a8:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c21ac:	cbz	x0, 0x1004c21f4
1004c21b0:	mov	x19, x0
1004c21b4:	adrp	x8, 7780 ; 0x102326000
1004c21b8:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c21bc:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c21c0:	bl	0x101acce80 ; selector defaultCenter
1004c21c4:	mov	x29, x29
1004c21c8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c21cc:	mov	x20, x0
1004c21d0:	bl	0x10006e844
1004c21d4:	ldr	x2, [x0]
1004c21d8:	mov	x0, x20
1004c21dc:	mov	x3, #0x0
1004c21e0:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c21e4:	mov	x0, x20
1004c21e8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c21ec:	mov	x0, x19
1004c21f0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c21f4:	ldp	x29, x30, [sp, #0x40]
1004c21f8:	ldp	x20, x19, [sp, #0x30]
1004c21fc:	ldp	x22, x21, [sp, #0x20]
1004c2200:	add	sp, sp, #0x50
1004c2204:	ret
1004c2208:	sub	sp, sp, #0x60
1004c220c:	stp	x22, x21, [sp, #0x30]
1004c2210:	stp	x20, x19, [sp, #0x40]
1004c2214:	stp	x29, x30, [sp, #0x50]
1004c2218:	add	x29, sp, #0x50
1004c221c:	ldp	x19, x22, [x20, #0x10]
1004c2220:	ldr	x8, [x19]
1004c2224:	ldr	x8, [x8, #0x500]
1004c2228:	mov	x20, x19
1004c222c:	blr	x8
1004c2230:	tbz	w0, #0x0, 0x1004c2294
1004c2234:	add	x0, x22, #0x10
1004c2238:	add	x1, sp, #0x18
1004c223c:	mov	x2, #0x0
1004c2240:	mov	x3, #0x0
1004c2244:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c2248:	add	x0, x22, #0x10
1004c224c:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c2250:	cbz	x0, 0x1004c22c4
1004c2254:	adrp	x8, 7899 ; 0x10239d000
1004c2258:	ldr	x8, [x8, #0x248]
1004c225c:	mov	x21, x0
1004c2260:	add	x0, x0, x8
1004c2264:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004c2268:	mov	x20, x0
1004c226c:	mov	x0, x21
1004c2270:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2274:	cbz	x20, 0x1004c22c4
1004c2278:	ldr	x8, [x20]
1004c227c:	ldr	x8, [x8, #0xf0]
1004c2280:	blr	x8
1004c2284:	mov	x21, x0
1004c2288:	mov	x0, x20
1004c228c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c2290:	b	0x1004c22cc
1004c2294:	add	x0, x22, #0x10
1004c2298:	add	x1, sp, #0x18
1004c229c:	mov	x2, #0x0
1004c22a0:	mov	x3, #0x0
1004c22a4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c22a8:	add	x0, x22, #0x10
1004c22ac:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c22b0:	cbz	x0, 0x1004c234c
1004c22b4:	mov	x20, x0
1004c22b8:	mov	x0, x19
1004c22bc:	bl	0x1004bb644
1004c22c0:	b	0x1004c2344
1004c22c4:	adrp	x21, 7693 ; 0x1022cf000
1004c22c8:	ldr	x21, [x21, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004c22cc:	ldr	x8, [x19]
1004c22d0:	ldr	x8, [x8, #0x5e0]
1004c22d4:	mov	x0, x21
1004c22d8:	mov	x20, x19
1004c22dc:	blr	x8
1004c22e0:	mov	x0, x21
1004c22e4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c22e8:	add	x0, x22, #0x10
1004c22ec:	mov	x1, sp
1004c22f0:	mov	x2, #0x0
1004c22f4:	mov	x3, #0x0
1004c22f8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c22fc:	add	x0, x22, #0x10
1004c2300:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c2304:	cbz	x0, 0x1004c234c
1004c2308:	mov	x19, x0
1004c230c:	adrp	x8, 7780 ; 0x102326000
1004c2310:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c2314:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c2318:	bl	0x101acce80 ; selector defaultCenter
1004c231c:	mov	x29, x29
1004c2320:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c2324:	mov	x20, x0
1004c2328:	bl	0x10006e844
1004c232c:	ldr	x2, [x0]
1004c2330:	mov	x0, x20
1004c2334:	mov	x3, #0x0
1004c2338:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c233c:	mov	x0, x19
1004c2340:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2344:	mov	x0, x20
1004c2348:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c234c:	ldp	x29, x30, [sp, #0x50]
1004c2350:	ldp	x20, x19, [sp, #0x40]
1004c2354:	ldp	x22, x21, [sp, #0x30]
1004c2358:	add	sp, sp, #0x60
1004c235c:	ret
1004c2360:	adrp	x0, 7449 ; 0x1021db000
1004c2364:	add	x0, x0, #0x4e0
1004c2368:	adrp	x1, 0 ; 0x1004c2000
1004c236c:	add	x1, x1, #0x66c
1004c2370:	b	0x1004c239c
1004c2374:	adrp	x0, 7449 ; 0x1021db000
1004c2378:	add	x0, x0, #0x4b8
1004c237c:	adrp	x1, 0 ; 0x1004c2000
1004c2380:	add	x1, x1, #0x540
1004c2384:	b	0x1004c239c
1004c2388:	adrp	x0, 7449 ; 0x1021db000
1004c238c:	add	x0, x0, #0x490
1004c2390:	adrp	x1, 0 ; 0x1004c2000
1004c2394:	add	x1, x1, #0x414
1004c2398:	b	0x1004c239c
1004c239c:	stp	x24, x23, [sp, #-0x40]!
1004c23a0:	stp	x22, x21, [sp, #0x10]
1004c23a4:	stp	x20, x19, [sp, #0x20]
1004c23a8:	stp	x29, x30, [sp, #0x30]
1004c23ac:	add	x29, sp, #0x30
1004c23b0:	mov	x19, x1
1004c23b4:	ldr	x21, [x20, #0x20]
1004c23b8:	mov	w1, #0x28
1004c23bc:	mov	w2, #0x7
1004c23c0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c23c4:	mov	x22, x0
1004c23c8:	ldr	x23, [x20, #0x18]
1004c23cc:	ldr	q0, [x20, #0x10]
1004c23d0:	str	q0, [x0, #0x10]
1004c23d4:	str	x21, [x0, #0x20]
1004c23d8:	fmov	x0, d0
1004c23dc:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c23e0:	mov	x0, x23
1004c23e4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c23e8:	mov	x0, x21
1004c23ec:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c23f0:	mov	x0, x19
1004c23f4:	mov	x1, x22
1004c23f8:	bl	0x1004f7934
1004c23fc:	mov	x0, x22
1004c2400:	ldp	x29, x30, [sp, #0x30]
1004c2404:	ldp	x20, x19, [sp, #0x20]
1004c2408:	ldp	x22, x21, [sp, #0x10]
1004c240c:	ldp	x24, x23, [sp], #0x40
1004c2410:	b	0x101aca960 ; symbol stub for: _swift_release
1004c2414:	sub	sp, sp, #0x70
1004c2418:	stp	x22, x21, [sp, #0x40]
1004c241c:	stp	x20, x19, [sp, #0x50]
1004c2420:	stp	x29, x30, [sp, #0x60]
1004c2424:	add	x29, sp, #0x60
1004c2428:	ldp	x19, x22, [x20, #0x10]
1004c242c:	ldr	x21, [x20, #0x20]
1004c2430:	ldr	x8, [x19]
1004c2434:	ldr	x8, [x8, #0x1e8]
1004c2438:	add	x0, sp, #0x20
1004c243c:	mov	x20, x19
1004c2440:	blr	x8
1004c2444:	mov	x8, x0
1004c2448:	ldrb	w9, [x1]
1004c244c:	mov	w10, #0x1
1004c2450:	bic	w9, w10, w9
1004c2454:	strb	w9, [x1]
1004c2458:	add	x0, sp, #0x20
1004c245c:	mov	w1, #0x0
1004c2460:	blr	x8
1004c2464:	adrp	x0, 7807 ; 0x102341000
1004c2468:	add	x0, x0, #0x6d0
1004c246c:	adrp	x1, 5663 ; 0x101ae1000
1004c2470:	add	x1, x1, #0x7e0
1004c2474:	bl	0x100003c4c
1004c2478:	adrp	x1, 7827 ; 0x102355000
1004c247c:	add	x1, x1, #0x1b0
1004c2480:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c2484:	ldr	x8, [x19]
1004c2488:	ldr	x8, [x8, #0x2d0]
1004c248c:	blr	x8
1004c2490:	add	x0, x22, #0x10
1004c2494:	add	x1, sp, #0x20
1004c2498:	mov	x2, #0x0
1004c249c:	mov	x3, #0x0
1004c24a0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c24a4:	add	x0, x22, #0x10
1004c24a8:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004c24ac:	cbz	x0, 0x1004c24c8
1004c24b0:	mov	x20, x0
1004c24b4:	ldr	x8, [x0]
1004c24b8:	ldr	x8, [x8, #0x6c8]
1004c24bc:	blr	x8
1004c24c0:	mov	x0, x20
1004c24c4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c24c8:	add	x0, x21, #0x10
1004c24cc:	add	x1, sp, #0x8
1004c24d0:	mov	x2, #0x0
1004c24d4:	mov	x3, #0x0
1004c24d8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c24dc:	add	x0, x21, #0x10
1004c24e0:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c24e4:	cbz	x0, 0x1004c252c
1004c24e8:	mov	x19, x0
1004c24ec:	adrp	x8, 7780 ; 0x102326000
1004c24f0:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c24f4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c24f8:	bl	0x101acce80 ; selector defaultCenter
1004c24fc:	mov	x29, x29
1004c2500:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c2504:	mov	x20, x0
1004c2508:	bl	0x10006e844
1004c250c:	ldr	x2, [x0]
1004c2510:	mov	x0, x20
1004c2514:	mov	x3, #0x0
1004c2518:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c251c:	mov	x0, x20
1004c2520:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2524:	mov	x0, x19
1004c2528:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c252c:	ldp	x29, x30, [sp, #0x60]
1004c2530:	ldp	x20, x19, [sp, #0x50]
1004c2534:	ldp	x22, x21, [sp, #0x40]
1004c2538:	add	sp, sp, #0x70
1004c253c:	ret
1004c2540:	sub	sp, sp, #0x70
1004c2544:	stp	x22, x21, [sp, #0x40]
1004c2548:	stp	x20, x19, [sp, #0x50]
1004c254c:	stp	x29, x30, [sp, #0x60]
1004c2550:	add	x29, sp, #0x60
1004c2554:	ldp	x19, x22, [x20, #0x10]
1004c2558:	ldr	x21, [x20, #0x20]
1004c255c:	ldr	x8, [x19]
1004c2560:	ldr	x8, [x8, #0x1d0]
1004c2564:	add	x0, sp, #0x20
1004c2568:	mov	x20, x19
1004c256c:	blr	x8
1004c2570:	mov	x8, x0
1004c2574:	ldrb	w9, [x1]
1004c2578:	mov	w10, #0x1
1004c257c:	bic	w9, w10, w9
1004c2580:	strb	w9, [x1]
1004c2584:	add	x0, sp, #0x20
1004c2588:	mov	w1, #0x0
1004c258c:	blr	x8
1004c2590:	adrp	x0, 7807 ; 0x102341000
1004c2594:	add	x0, x0, #0x6d0
1004c2598:	adrp	x1, 5663 ; 0x101ae1000
1004c259c:	add	x1, x1, #0x7e0
1004c25a0:	bl	0x100003c4c
1004c25a4:	adrp	x1, 7827 ; 0x102355000
1004c25a8:	add	x1, x1, #0x1e8
1004c25ac:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c25b0:	ldr	x8, [x19]
1004c25b4:	ldr	x8, [x8, #0x2d0]
1004c25b8:	blr	x8
1004c25bc:	add	x0, x22, #0x10
1004c25c0:	add	x1, sp, #0x20
1004c25c4:	mov	x2, #0x0
1004c25c8:	mov	x3, #0x0
1004c25cc:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c25d0:	add	x0, x22, #0x10
1004c25d4:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004c25d8:	cbz	x0, 0x1004c25f4
1004c25dc:	mov	x20, x0
1004c25e0:	ldr	x8, [x0]
1004c25e4:	ldr	x8, [x8, #0x6c8]
1004c25e8:	blr	x8
1004c25ec:	mov	x0, x20
1004c25f0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c25f4:	add	x0, x21, #0x10
1004c25f8:	add	x1, sp, #0x8
1004c25fc:	mov	x2, #0x0
1004c2600:	mov	x3, #0x0
1004c2604:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c2608:	add	x0, x21, #0x10
1004c260c:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c2610:	cbz	x0, 0x1004c2658
1004c2614:	mov	x19, x0
1004c2618:	adrp	x8, 7780 ; 0x102326000
1004c261c:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c2620:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c2624:	bl	0x101acce80 ; selector defaultCenter
1004c2628:	mov	x29, x29
1004c262c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c2630:	mov	x20, x0
1004c2634:	bl	0x10006e844
1004c2638:	ldr	x2, [x0]
1004c263c:	mov	x0, x20
1004c2640:	mov	x3, #0x0
1004c2644:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c2648:	mov	x0, x20
1004c264c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2650:	mov	x0, x19
1004c2654:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2658:	ldp	x29, x30, [sp, #0x60]
1004c265c:	ldp	x20, x19, [sp, #0x50]
1004c2660:	ldp	x22, x21, [sp, #0x40]
1004c2664:	add	sp, sp, #0x70
1004c2668:	ret
1004c266c:	sub	sp, sp, #0x70
1004c2670:	stp	x22, x21, [sp, #0x40]
1004c2674:	stp	x20, x19, [sp, #0x50]
1004c2678:	stp	x29, x30, [sp, #0x60]
1004c267c:	add	x29, sp, #0x60
1004c2680:	ldp	x19, x22, [x20, #0x10]
1004c2684:	ldr	x21, [x20, #0x20]
1004c2688:	ldr	x8, [x19]
1004c268c:	ldr	x8, [x8, #0x1b8]
1004c2690:	add	x0, sp, #0x20
1004c2694:	mov	x20, x19
1004c2698:	blr	x8
1004c269c:	mov	x8, x0
1004c26a0:	ldrb	w9, [x1]
1004c26a4:	mov	w10, #0x1
1004c26a8:	bic	w9, w10, w9
1004c26ac:	strb	w9, [x1]
1004c26b0:	add	x0, sp, #0x20
1004c26b4:	mov	w1, #0x0
1004c26b8:	blr	x8
1004c26bc:	adrp	x0, 7807 ; 0x102341000
1004c26c0:	add	x0, x0, #0x6d0
1004c26c4:	adrp	x1, 5663 ; 0x101ae1000
1004c26c8:	add	x1, x1, #0x7e0
1004c26cc:	bl	0x100003c4c
1004c26d0:	adrp	x1, 7827 ; 0x102355000
1004c26d4:	add	x1, x1, #0x220
1004c26d8:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c26dc:	ldr	x8, [x19]
1004c26e0:	ldr	x8, [x8, #0x2d0]
1004c26e4:	blr	x8
1004c26e8:	add	x0, x22, #0x10
1004c26ec:	add	x1, sp, #0x20
1004c26f0:	mov	x2, #0x0
1004c26f4:	mov	x3, #0x0
1004c26f8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c26fc:	add	x0, x22, #0x10
1004c2700:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004c2704:	cbz	x0, 0x1004c2720
1004c2708:	mov	x20, x0
1004c270c:	ldr	x8, [x0]
1004c2710:	ldr	x8, [x8, #0x6c8]
1004c2714:	blr	x8
1004c2718:	mov	x0, x20
1004c271c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c2720:	add	x0, x21, #0x10
1004c2724:	add	x1, sp, #0x8
1004c2728:	mov	x2, #0x0
1004c272c:	mov	x3, #0x0
1004c2730:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c2734:	add	x0, x21, #0x10
1004c2738:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c273c:	cbz	x0, 0x1004c2784
1004c2740:	mov	x19, x0
1004c2744:	adrp	x8, 7780 ; 0x102326000
1004c2748:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c274c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c2750:	bl	0x101acce80 ; selector defaultCenter
1004c2754:	mov	x29, x29
1004c2758:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c275c:	mov	x20, x0
1004c2760:	bl	0x10006e844
1004c2764:	ldr	x2, [x0]
1004c2768:	mov	x0, x20
1004c276c:	mov	x3, #0x0
1004c2770:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c2774:	mov	x0, x20
1004c2778:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c277c:	mov	x0, x19
1004c2780:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2784:	ldp	x29, x30, [sp, #0x60]
1004c2788:	ldp	x20, x19, [sp, #0x50]
1004c278c:	ldp	x22, x21, [sp, #0x40]
1004c2790:	add	sp, sp, #0x70
1004c2794:	ret
1004c2798:	sub	sp, sp, #0x50
1004c279c:	stp	x22, x21, [sp, #0x20]
1004c27a0:	stp	x20, x19, [sp, #0x30]
1004c27a4:	stp	x29, x30, [sp, #0x40]
1004c27a8:	add	x29, sp, #0x40
1004c27ac:	ldp	x19, x21, [x20, #0x10]
1004c27b0:	ldr	x8, [x19]
1004c27b4:	ldr	x8, [x8, #0x230]
1004c27b8:	mov	x0, sp
1004c27bc:	mov	x20, x19
1004c27c0:	blr	x8
1004c27c4:	mov	x8, x0
1004c27c8:	ldrb	w9, [x1]
1004c27cc:	mov	w10, #0x1
1004c27d0:	bic	w9, w10, w9
1004c27d4:	strb	w9, [x1]
1004c27d8:	mov	x0, sp
1004c27dc:	mov	w1, #0x0
1004c27e0:	blr	x8
1004c27e4:	adrp	x0, 7807 ; 0x102341000
1004c27e8:	add	x0, x0, #0x6d0
1004c27ec:	adrp	x1, 5663 ; 0x101ae1000
1004c27f0:	add	x1, x1, #0x7e0
1004c27f4:	bl	0x100003c4c
1004c27f8:	adrp	x1, 7827 ; 0x102355000
1004c27fc:	add	x1, x1, #0x290
1004c2800:	bl	0x101aca8c4 ; symbol stub for: _swift_initStaticObject
1004c2804:	ldr	x8, [x19]
1004c2808:	ldr	x8, [x8, #0x2d0]
1004c280c:	blr	x8
1004c2810:	add	x0, x21, #0x10
1004c2814:	mov	x1, sp
1004c2818:	mov	x2, #0x0
1004c281c:	mov	x3, #0x0
1004c2820:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c2824:	add	x0, x21, #0x10
1004c2828:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c282c:	cbz	x0, 0x1004c2874
1004c2830:	mov	x19, x0
1004c2834:	adrp	x8, 7780 ; 0x102326000
1004c2838:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c283c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c2840:	bl	0x101acce80 ; selector defaultCenter
1004c2844:	mov	x29, x29
1004c2848:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c284c:	mov	x20, x0
1004c2850:	bl	0x10006e844
1004c2854:	ldr	x2, [x0]
1004c2858:	mov	x0, x20
1004c285c:	mov	x3, #0x0
1004c2860:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c2864:	mov	x0, x20
1004c2868:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c286c:	mov	x0, x19
1004c2870:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2874:	ldp	x29, x30, [sp, #0x40]
1004c2878:	ldp	x20, x19, [sp, #0x30]
1004c287c:	ldp	x22, x21, [sp, #0x20]
1004c2880:	add	sp, sp, #0x50
1004c2884:	ret
1004c2888:	sub	sp, sp, #0x50
1004c288c:	stp	x22, x21, [sp, #0x20]
1004c2890:	stp	x20, x19, [sp, #0x30]
1004c2894:	stp	x29, x30, [sp, #0x40]
1004c2898:	add	x29, sp, #0x40
1004c289c:	ldp	x21, x19, [x20, #0x10]
1004c28a0:	add	x0, x21, #0x10
1004c28a4:	add	x1, sp, #0x8
1004c28a8:	mov	x2, #0x0
1004c28ac:	mov	x3, #0x0
1004c28b0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c28b4:	add	x0, x21, #0x10
1004c28b8:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c28bc:	cbz	x0, 0x1004c28dc
1004c28c0:	mov	x20, x0
1004c28c4:	mov	x0, x19
1004c28c8:	bl	0x1004b9f0c
1004c28cc:	mov	x19, x0
1004c28d0:	mov	x0, x20
1004c28d4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c28d8:	b	0x1004c28e4
1004c28dc:	adrp	x19, 7693 ; 0x1022cf000
1004c28e0:	ldr	x19, [x19, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004c28e4:	mov	x0, x19
1004c28e8:	ldp	x29, x30, [sp, #0x40]
1004c28ec:	ldp	x20, x19, [sp, #0x30]
1004c28f0:	ldp	x22, x21, [sp, #0x20]
1004c28f4:	add	sp, sp, #0x50
1004c28f8:	ret
1004c28fc:	mov	w0, #0x1b
1004c2900:	b	0x1004c5a24
1004c2904:	mov	w0, #0x1c
1004c2908:	b	0x1004c5a24
1004c290c:	mov	w0, #0x1d
1004c2910:	b	0x1004c5a24
1004c2914:	mov	w0, #0x1e
1004c2918:	b	0x1004c5a24
1004c291c:	sub	sp, sp, #0x90
1004c2920:	stp	x24, x23, [sp, #0x50]
1004c2924:	stp	x22, x21, [sp, #0x60]
1004c2928:	stp	x20, x19, [sp, #0x70]
1004c292c:	stp	x29, x30, [sp, #0x80]
1004c2930:	add	x29, sp, #0x80
1004c2934:	ldp	x23, x19, [x20, #0x10]
1004c2938:	ldr	x21, [x20, #0x20]
1004c293c:	add	x0, x23, #0x10
1004c2940:	add	x1, sp, #0x38
1004c2944:	mov	x2, #0x0
1004c2948:	mov	x3, #0x0
1004c294c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c2950:	add	x0, x23, #0x10
1004c2954:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c2958:	cbz	x0, 0x1004c29e8
1004c295c:	adrp	x8, 7899 ; 0x10239d000
1004c2960:	ldr	x8, [x8, #0x248]
1004c2964:	mov	x22, x0
1004c2968:	add	x0, x0, x8
1004c296c:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004c2970:	mov	x20, x0
1004c2974:	mov	x0, x22
1004c2978:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c297c:	cbz	x20, 0x1004c29e8
1004c2980:	ldr	x8, [x20]
1004c2984:	ldr	x8, [x8, #0x260]
1004c2988:	blr	x8
1004c298c:	mov	x22, x0
1004c2990:	mov	x0, x20
1004c2994:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c2998:	cbz	x22, 0x1004c29e8
1004c299c:	ldr	x20, [x22, #0x18]
1004c29a0:	mov	x0, x20
1004c29a4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c29a8:	mov	x0, x22
1004c29ac:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c29b0:	ldr	x8, [x20]
1004c29b4:	ldr	x8, [x8, #0x78]
1004c29b8:	blr	x8
1004c29bc:	mov	x22, x0
1004c29c0:	mov	x0, x20
1004c29c4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c29c8:	ldr	x8, [x22]
1004c29cc:	ldr	x8, [x8, #0x120]
1004c29d0:	mov	x0, x19
1004c29d4:	mov	x1, x21
1004c29d8:	mov	x20, x22
1004c29dc:	blr	x8
1004c29e0:	mov	x0, x22
1004c29e4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c29e8:	add	x0, x23, #0x10
1004c29ec:	add	x1, sp, #0x20
1004c29f0:	mov	x2, #0x0
1004c29f4:	mov	x3, #0x0
1004c29f8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c29fc:	add	x0, x23, #0x10
1004c2a00:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c2a04:	adrp	x24, 7693 ; 0x1022cf000
1004c2a08:	ldr	x24, [x24, #0x718] ; literal pool symbol address: _swift_isaMask
1004c2a0c:	cbz	x0, 0x1004c2a80
1004c2a10:	adrp	x8, 7899 ; 0x10239d000
1004c2a14:	ldr	x8, [x8, #0x250]
1004c2a18:	mov	x20, x0
1004c2a1c:	add	x0, x0, x8
1004c2a20:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c2a24:	mov	x22, x0
1004c2a28:	mov	x0, x20
1004c2a2c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2a30:	cbz	x22, 0x1004c2a80
1004c2a34:	ldr	x8, [x22]
1004c2a38:	ldr	x9, [x24]
1004c2a3c:	and	x8, x9, x8
1004c2a40:	ldr	x8, [x8, #0x440]
1004c2a44:	mov	x20, x22
1004c2a48:	blr	x8
1004c2a4c:	mov	x20, x0
1004c2a50:	mov	x0, x22
1004c2a54:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2a58:	cbz	x20, 0x1004c2a80
1004c2a5c:	ldr	x8, [x20]
1004c2a60:	ldr	x9, [x24]
1004c2a64:	and	x8, x9, x8
1004c2a68:	ldr	x8, [x8, #0x428]
1004c2a6c:	mov	x0, x19
1004c2a70:	mov	x1, x21
1004c2a74:	blr	x8
1004c2a78:	mov	x0, x20
1004c2a7c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2a80:	add	x0, x23, #0x10
1004c2a84:	add	x1, sp, #0x8
1004c2a88:	mov	x2, #0x0
1004c2a8c:	mov	x3, #0x0
1004c2a90:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c2a94:	add	x0, x23, #0x10
1004c2a98:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c2a9c:	cbz	x0, 0x1004c2ac0
1004c2aa0:	mov	x20, x0
1004c2aa4:	ldr	x8, [x0]
1004c2aa8:	ldr	x9, [x24]
1004c2aac:	and	x8, x9, x8
1004c2ab0:	ldr	x8, [x8, #0x248]
1004c2ab4:	blr	x8
1004c2ab8:	mov	x0, x20
1004c2abc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2ac0:	ldp	x29, x30, [sp, #0x80]
1004c2ac4:	ldp	x20, x19, [sp, #0x70]
1004c2ac8:	ldp	x22, x21, [sp, #0x60]
1004c2acc:	ldp	x24, x23, [sp, #0x50]
1004c2ad0:	add	sp, sp, #0x90
1004c2ad4:	ret
1004c2ad8:	sub	sp, sp, #0xc0
1004c2adc:	stp	x28, x27, [sp, #0x60]
1004c2ae0:	stp	x26, x25, [sp, #0x70]
1004c2ae4:	stp	x24, x23, [sp, #0x80]
1004c2ae8:	stp	x22, x21, [sp, #0x90]
1004c2aec:	stp	x20, x19, [sp, #0xa0]
1004c2af0:	stp	x29, x30, [sp, #0xb0]
1004c2af4:	add	x29, sp, #0xb0
1004c2af8:	ldp	x19, x23, [x20, #0x10]
1004c2afc:	add	x0, x19, #0x10
1004c2b00:	add	x1, sp, #0x48
1004c2b04:	mov	x2, #0x0
1004c2b08:	mov	x3, #0x0
1004c2b0c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c2b10:	add	x0, x19, #0x10
1004c2b14:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004c2b18:	adrp	x24, 7693 ; 0x1022cf000
1004c2b1c:	ldr	x24, [x24, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004c2b20:	cbz	x0, 0x1004c2d78
1004c2b24:	mov	x25, x0
1004c2b28:	bl	0x1004a8108
1004c2b2c:	mov	x19, x0
1004c2b30:	ldr	x22, [x0, #0x10]
1004c2b34:	cbz	x22, 0x1004c2c14
1004c2b38:	stp	x23, x25, [sp, #0x10]
1004c2b3c:	str	x24, [sp, #0x30]
1004c2b40:	add	x20, sp, #0x30
1004c2b44:	mov	w0, #0x0
1004c2b48:	mov	x1, x22
1004c2b4c:	mov	w2, #0x0
1004c2b50:	bl	0x1004bfb2c
1004c2b54:	ldr	x20, [sp, #0x30]
1004c2b58:	bl	0x1004a9938
1004c2b5c:	str	x0, [sp, #0x20]
1004c2b60:	ldr	x24, [x20, #0x10]
1004c2b64:	mov	w8, #0x38
1004c2b68:	mov	x9, #0x50
1004c2b6c:	madd	x28, x24, x8, x9
1004c2b70:	str	x19, [sp, #0x8]
1004c2b74:	add	x27, x19, #0x28
1004c2b78:	ldp	x9, x25, [x27, #-0x8]
1004c2b7c:	ldr	x8, [sp, #0x20]
1004c2b80:	ldp	x23, x26, [x8]
1004c2b84:	stp	x9, x20, [sp, #0x28]
1004c2b88:	add	x21, x24, #0x1
1004c2b8c:	ldr	x19, [x20, #0x18]
1004c2b90:	mov	x0, x25
1004c2b94:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c2b98:	mov	x0, x26
1004c2b9c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c2ba0:	cmp	x24, x19, lsr #1
1004c2ba4:	b.hs	0x1004c2be4
1004c2ba8:	add	x27, x27, #0x10
1004c2bac:	str	x21, [x20, #0x10]
1004c2bb0:	add	x8, x20, x28
1004c2bb4:	ldr	x9, [sp, #0x28]
1004c2bb8:	stp	x9, x25, [x8, #-0x30]
1004c2bbc:	stp	x23, x26, [x8, #-0x20]
1004c2bc0:	adrp	x9, -1215 ; 0x100003000
1004c2bc4:	add	x9, x9, #0xf40
1004c2bc8:	stp	xzr, x9, [x8, #-0x10]
1004c2bcc:	add	x28, x28, #0x38
1004c2bd0:	mov	x24, x21
1004c2bd4:	str	xzr, [x8]
1004c2bd8:	subs	x22, x22, #0x1
1004c2bdc:	b.ne	0x1004c2b78
1004c2be0:	b	0x1004c2c04
1004c2be4:	cmp	x19, #0x1
1004c2be8:	cset	w0, hi
1004c2bec:	add	x20, sp, #0x30
1004c2bf0:	mov	x1, x21
1004c2bf4:	mov	w2, #0x1
1004c2bf8:	bl	0x1004bfb2c
1004c2bfc:	ldr	x20, [sp, #0x30]
1004c2c00:	b	0x1004c2ba8
1004c2c04:	ldr	x0, [sp, #0x8]
1004c2c08:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c2c0c:	ldp	x23, x25, [sp, #0x10]
1004c2c10:	b	0x1004c2c24
1004c2c14:	mov	x0, x19
1004c2c18:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c2c1c:	adrp	x20, 7693 ; 0x1022cf000
1004c2c20:	ldr	x20, [x20, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004c2c24:	ldp	x24, x21, [x25, #0x18]
1004c2c28:	mov	x0, x21
1004c2c2c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c2c30:	mov	x0, x20
1004c2c34:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004c2c38:	tbz	w0, #0x0, 0x1004c2d9c
1004c2c3c:	ldp	x19, x8, [x20, #0x10]
1004c2c40:	add	x22, x19, #0x1
1004c2c44:	cmp	x19, x8, lsr #1
1004c2c48:	b.hs	0x1004c2dc4
1004c2c4c:	str	x22, [x20, #0x10]
1004c2c50:	mov	w8, #0x38
1004c2c54:	madd	x8, x19, x8, x20
1004c2c58:	mov	w9, #0x2d2d
1004c2c5c:	movk	w9, #0x2d, lsl #16
1004c2c60:	mov	x10, #-0x1d00000000000000
1004c2c64:	stp	x9, x10, [x8, #0x20]
1004c2c68:	stp	xzr, xzr, [x8, #0x30]
1004c2c6c:	adrp	x9, -1215 ; 0x100003000
1004c2c70:	add	x9, x9, #0xf40
1004c2c74:	stp	xzr, x9, [x8, #0x40]
1004c2c78:	str	xzr, [x8, #0x50]
1004c2c7c:	adrp	x0, 7448 ; 0x1021da000
1004c2c80:	add	x0, x0, #0x978
1004c2c84:	mov	w1, #0x18
1004c2c88:	mov	w2, #0x7
1004c2c8c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c2c90:	mov	x22, x0
1004c2c94:	add	x0, x23, #0x10
1004c2c98:	add	x1, sp, #0x30
1004c2c9c:	mov	x2, #0x0
1004c2ca0:	mov	x3, #0x0
1004c2ca4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c2ca8:	add	x0, x23, #0x10
1004c2cac:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c2cb0:	mov	x23, x0
1004c2cb4:	add	x0, x22, #0x10
1004c2cb8:	mov	x1, x23
1004c2cbc:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c2cc0:	mov	x0, x23
1004c2cc4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2cc8:	adrp	x0, 7449 ; 0x1021db000
1004c2ccc:	add	x0, x0, #0x670
1004c2cd0:	mov	w1, #0x28
1004c2cd4:	mov	w2, #0x7
1004c2cd8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c2cdc:	mov	x23, x0
1004c2ce0:	stp	x22, x24, [x0, #0x10]
1004c2ce4:	str	x21, [x0, #0x20]
1004c2ce8:	adrp	x0, 7449 ; 0x1021db000
1004c2cec:	add	x0, x0, #0x698
1004c2cf0:	mov	w1, #0x20
1004c2cf4:	mov	w2, #0x7
1004c2cf8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c2cfc:	mov	x21, x0
1004c2d00:	adrp	x8, 0 ; 0x1004c2000
1004c2d04:	add	x8, x8, #0xe14
1004c2d08:	stp	x8, x23, [x0, #0x10]
1004c2d0c:	mov	x24, x20
1004c2d10:	ldp	x19, x20, [x20, #0x10]
1004c2d14:	add	x23, x19, #0x1
1004c2d18:	mov	x0, x22
1004c2d1c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c2d20:	cmp	x19, x20, lsr #1
1004c2d24:	b.hs	0x1004c2dec
1004c2d28:	str	x23, [x24, #0x10]
1004c2d2c:	mov	w8, #0x38
1004c2d30:	madd	x8, x19, x8, x24
1004c2d34:	mov	x9, #0x6f43
1004c2d38:	movk	x9, #0x7970, lsl #16
1004c2d3c:	movk	x9, #0x5020, lsl #32
1004c2d40:	movk	x9, #0x6e61, lsl #48
1004c2d44:	mov	x10, #0x2065
1004c2d48:	movk	x10, #0x4449, lsl #16
1004c2d4c:	movk	x10, #0xec00, lsl #48
1004c2d50:	stp	x9, x10, [x8, #0x20]
1004c2d54:	stp	xzr, xzr, [x8, #0x30]
1004c2d58:	adrp	x9, -1214 ; 0x100004000
1004c2d5c:	add	x9, x9, #0xcc
1004c2d60:	stp	xzr, x9, [x8, #0x40]
1004c2d64:	str	x21, [x8, #0x50]
1004c2d68:	mov	x0, x25
1004c2d6c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c2d70:	mov	x0, x22
1004c2d74:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c2d78:	mov	x0, x24
1004c2d7c:	ldp	x29, x30, [sp, #0xb0]
1004c2d80:	ldp	x20, x19, [sp, #0xa0]
1004c2d84:	ldp	x22, x21, [sp, #0x90]
1004c2d88:	ldp	x24, x23, [sp, #0x80]
1004c2d8c:	ldp	x26, x25, [sp, #0x70]
1004c2d90:	ldp	x28, x27, [sp, #0x60]
1004c2d94:	add	sp, sp, #0xc0
1004c2d98:	ret
1004c2d9c:	ldr	x8, [x20, #0x10]
1004c2da0:	adrp	x4, 7693 ; 0x1022cf000
1004c2da4:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c2da8:	add	x1, x8, #0x1
1004c2dac:	mov	w0, #0x0
1004c2db0:	mov	w2, #0x1
1004c2db4:	mov	x3, x20
1004c2db8:	bl	0x1004bfb6c
1004c2dbc:	mov	x20, x0
1004c2dc0:	b	0x1004c2c3c
1004c2dc4:	cmp	x8, #0x1
1004c2dc8:	cset	w0, hi
1004c2dcc:	adrp	x4, 7693 ; 0x1022cf000
1004c2dd0:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c2dd4:	mov	x1, x22
1004c2dd8:	mov	w2, #0x1
1004c2ddc:	mov	x3, x20
1004c2de0:	bl	0x1004bfb6c
1004c2de4:	mov	x20, x0
1004c2de8:	b	0x1004c2c4c
1004c2dec:	cmp	x20, #0x1
1004c2df0:	cset	w0, hi
1004c2df4:	adrp	x4, 7693 ; 0x1022cf000
1004c2df8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c2dfc:	mov	x1, x23
1004c2e00:	mov	w2, #0x1
1004c2e04:	mov	x3, x24
1004c2e08:	bl	0x1004bfb6c
1004c2e0c:	mov	x24, x0
1004c2e10:	b	0x1004c2d28
1004c2e14:	sub	sp, sp, #0x70
1004c2e18:	stp	x24, x23, [sp, #0x30]
1004c2e1c:	stp	x22, x21, [sp, #0x40]
1004c2e20:	stp	x20, x19, [sp, #0x50]
1004c2e24:	stp	x29, x30, [sp, #0x60]
1004c2e28:	add	x29, sp, #0x60
1004c2e2c:	ldp	x23, x19, [x20, #0x10]
1004c2e30:	ldr	x21, [x20, #0x20]
1004c2e34:	add	x0, x23, #0x10
1004c2e38:	add	x1, sp, #0x18
1004c2e3c:	mov	x2, #0x0
1004c2e40:	mov	x3, #0x0
1004c2e44:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c2e48:	add	x0, x23, #0x10
1004c2e4c:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c2e50:	adrp	x24, 7693 ; 0x1022cf000
1004c2e54:	ldr	x24, [x24, #0x718] ; literal pool symbol address: _swift_isaMask
1004c2e58:	cbz	x0, 0x1004c2ea4
1004c2e5c:	adrp	x8, 7899 ; 0x10239d000
1004c2e60:	ldr	x8, [x8, #0x250]
1004c2e64:	mov	x22, x0
1004c2e68:	add	x0, x0, x8
1004c2e6c:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c2e70:	mov	x20, x0
1004c2e74:	mov	x0, x22
1004c2e78:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2e7c:	cbz	x20, 0x1004c2ea4
1004c2e80:	ldr	x8, [x20]
1004c2e84:	ldr	x9, [x24]
1004c2e88:	and	x8, x9, x8
1004c2e8c:	ldr	x8, [x8, #0x278]
1004c2e90:	blr	x8
1004c2e94:	mov	x22, x0
1004c2e98:	mov	x0, x20
1004c2e9c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2ea0:	cbnz	x22, 0x1004c2ec4
1004c2ea4:	adrp	x8, 7688 ; 0x1022ca000
1004c2ea8:	ldr	x8, [x8, #0x558] ; literal pool symbol address: _NSApp
1004c2eac:	ldr	x0, [x8]
1004c2eb0:	cbz	x0, 0x1004c2f34
1004c2eb4:	bl	0x101acf6c0 ; selector mainWindow
1004c2eb8:	mov	x29, x29
1004c2ebc:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c2ec0:	mov	x22, x0
1004c2ec4:	add	x0, x23, #0x10
1004c2ec8:	mov	x1, sp
1004c2ecc:	mov	x2, #0x0
1004c2ed0:	mov	x3, #0x0
1004c2ed4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c2ed8:	add	x0, x23, #0x10
1004c2edc:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c2ee0:	cbz	x0, 0x1004c2f04
1004c2ee4:	mov	x20, x0
1004c2ee8:	ldr	x8, [x0]
1004c2eec:	ldr	x9, [x24]
1004c2ef0:	and	x8, x9, x8
1004c2ef4:	ldr	x8, [x8, #0x248]
1004c2ef8:	blr	x8
1004c2efc:	mov	x0, x20
1004c2f00:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2f04:	mov	x0, x19
1004c2f08:	mov	x1, x21
1004c2f0c:	mov	x2, x22
1004c2f10:	bl	0x1005ffef8
1004c2f14:	mov	x0, x22
1004c2f18:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c2f1c:	ldp	x29, x30, [sp, #0x60]
1004c2f20:	ldp	x20, x19, [sp, #0x50]
1004c2f24:	ldp	x22, x21, [sp, #0x40]
1004c2f28:	ldp	x24, x23, [sp, #0x30]
1004c2f2c:	add	sp, sp, #0x70
1004c2f30:	ret
1004c2f34:	brk	#0x1
1004c2f38:	stp	x28, x27, [sp, #-0x60]!
1004c2f3c:	stp	x26, x25, [sp, #0x10]
1004c2f40:	stp	x24, x23, [sp, #0x20]
1004c2f44:	stp	x22, x21, [sp, #0x30]
1004c2f48:	stp	x20, x19, [sp, #0x40]
1004c2f4c:	stp	x29, x30, [sp, #0x50]
1004c2f50:	add	x29, sp, #0x50
1004c2f54:	sub	sp, sp, #0x200
1004c2f58:	ldp	x8, x28, [x20, #0x10]
1004c2f5c:	str	x8, [sp, #0x20]
1004c2f60:	ldr	x27, [x20, #0x20]
1004c2f64:	bl	0x1003405e8
1004c2f68:	mov	x24, x0
1004c2f6c:	tbz	w0, #0x0, 0x1004c2f94
1004c2f70:	bl	0x1003def04
1004c2f74:	mov	x23, x0
1004c2f78:	ldr	x8, [x0, #0x10]
1004c2f7c:	cbz	x8, 0x1004c31d4
1004c2f80:	adrp	x25, 7693 ; 0x1022cf000
1004c2f84:	ldr	x25, [x25, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004c2f88:	ldr	x26, [x23, #0x10]
1004c2f8c:	cbnz	x26, 0x1004c2fa8
1004c2f90:	b	0x1004c325c
1004c2f94:	adrp	x25, 7693 ; 0x1022cf000
1004c2f98:	ldr	x25, [x25, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004c2f9c:	mov	x23, x25
1004c2fa0:	ldr	x26, [x23, #0x10]
1004c2fa4:	cbz	x26, 0x1004c325c
1004c2fa8:	str	w24, [sp, #0x4]
1004c2fac:	stp	x28, x27, [sp, #0x10]
1004c2fb0:	add	x27, sp, #0x140
1004c2fb4:	ldr	x8, [sp, #0x20]
1004c2fb8:	add	x0, x8, #0x10
1004c2fbc:	add	x1, sp, #0x128
1004c2fc0:	mov	x2, #0x0
1004c2fc4:	mov	x3, #0x0
1004c2fc8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c2fcc:	mov	w19, #0x20
1004c2fd0:	str	x23, [sp, #0x8]
1004c2fd4:	add	x8, x23, x19
1004c2fd8:	ldp	q0, q1, [x8]
1004c2fdc:	ldr	q2, [x8, #0x20]
1004c2fe0:	stp	q1, q2, [x27, #0x10]
1004c2fe4:	str	q0, [x27]
1004c2fe8:	ldp	q0, q1, [x8, #0x30]
1004c2fec:	ldp	q2, q3, [x8, #0x50]
1004c2ff0:	stp	q2, q3, [x27, #0x50]
1004c2ff4:	stp	q0, q1, [x27, #0x30]
1004c2ff8:	ldp	q0, q1, [x8, #0x70]
1004c2ffc:	ldr	q2, [x8, #0x90]
1004c3000:	ldr	x8, [x8, #0xa0]
1004c3004:	str	x8, [sp, #0x1e0]
1004c3008:	stp	q1, q2, [x27, #0x80]
1004c300c:	str	q0, [x27, #0x70]
1004c3010:	add	x0, sp, #0x140
1004c3014:	add	x1, sp, #0x80
1004c3018:	bl	0x10007ac30
1004c301c:	add	x0, sp, #0x140
1004c3020:	bl	0x1003df280
1004c3024:	stp	x1, x0, [sp, #0x28]
1004c3028:	add	x20, sp, #0x140
1004c302c:	bl	0x1003a89dc
1004c3030:	tst	w0, #0x1
1004c3034:	mov	w8, #0x6976
1004c3038:	movk	w8, #0x7765, lsl #16
1004c303c:	csel	x24, xzr, x8, ne
1004c3040:	mov	x8, #-0x1c00000000000000
1004c3044:	csel	x22, xzr, x8, ne
1004c3048:	adrp	x0, 7447 ; 0x1021da000
1004c304c:	add	x0, x0, #0x978
1004c3050:	mov	w1, #0x18
1004c3054:	mov	w2, #0x7
1004c3058:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c305c:	mov	x20, x0
1004c3060:	ldr	x8, [sp, #0x20]
1004c3064:	add	x0, x8, #0x10
1004c3068:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c306c:	mov	x21, x0
1004c3070:	add	x0, x20, #0x10
1004c3074:	mov	x1, x21
1004c3078:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c307c:	mov	x0, x21
1004c3080:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c3084:	adrp	x0, 7448 ; 0x1021db000
1004c3088:	add	x0, x0, #0x6e8
1004c308c:	mov	w1, #0xd0
1004c3090:	mov	w2, #0x7
1004c3094:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c3098:	mov	x28, x25
1004c309c:	mov	x25, x0
1004c30a0:	ldp	x8, x23, [sp, #0x10]
1004c30a4:	stp	x8, x23, [x0, #0x10]
1004c30a8:	ldp	q0, q1, [x27, #0x80]
1004c30ac:	stp	q0, q1, [x0, #0xa0]
1004c30b0:	ldr	x8, [sp, #0x1e0]
1004c30b4:	ldp	q0, q1, [x27, #0x40]
1004c30b8:	stp	q0, q1, [x0, #0x60]
1004c30bc:	ldp	q1, q0, [x27, #0x60]
1004c30c0:	stp	q1, q0, [x0, #0x80]
1004c30c4:	ldp	q0, q1, [x27]
1004c30c8:	stp	q0, q1, [x0, #0x20]
1004c30cc:	ldp	q1, q0, [x27, #0x20]
1004c30d0:	stp	q1, q0, [x0, #0x40]
1004c30d4:	stp	x8, x20, [x0, #0xc0]
1004c30d8:	adrp	x0, 7448 ; 0x1021db000
1004c30dc:	add	x0, x0, #0x710
1004c30e0:	mov	w1, #0x20
1004c30e4:	mov	w2, #0x7
1004c30e8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c30ec:	mov	x21, x0
1004c30f0:	adrp	x8, 0 ; 0x1004c3000
1004c30f4:	add	x8, x8, #0x858
1004c30f8:	stp	x8, x25, [x0, #0x10]
1004c30fc:	mov	x0, x23
1004c3100:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c3104:	mov	x0, x20
1004c3108:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c310c:	mov	x0, x28
1004c3110:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004c3114:	tbz	w0, #0x0, 0x1004c3174
1004c3118:	ldp	x23, x8, [x28, #0x10]
1004c311c:	mov	x3, x28
1004c3120:	add	x25, x23, #0x1
1004c3124:	cmp	x23, x8, lsr #1
1004c3128:	b.hs	0x1004c319c
1004c312c:	str	x25, [x3, #0x10]
1004c3130:	mov	x25, x3
1004c3134:	mov	w8, #0x38
1004c3138:	madd	x8, x23, x8, x3
1004c313c:	ldp	x9, x10, [sp, #0x28]
1004c3140:	stp	x10, x9, [x8, #0x20]
1004c3144:	stp	x24, x22, [x8, #0x30]
1004c3148:	adrp	x9, -1215 ; 0x100004000
1004c314c:	add	x9, x9, #0xcc
1004c3150:	stp	xzr, x9, [x8, #0x40]
1004c3154:	str	x21, [x8, #0x50]
1004c3158:	mov	x0, x20
1004c315c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c3160:	add	x19, x19, #0xa8
1004c3164:	subs	x26, x26, #0x1
1004c3168:	ldr	x23, [sp, #0x8]
1004c316c:	b.ne	0x1004c2fd4
1004c3170:	b	0x1004c31c0
1004c3174:	ldr	x8, [x28, #0x10]
1004c3178:	add	x1, x8, #0x1
1004c317c:	mov	w0, #0x0
1004c3180:	mov	w2, #0x1
1004c3184:	mov	x3, x28
1004c3188:	adrp	x4, 7692 ; 0x1022cf000
1004c318c:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c3190:	bl	0x1004bfb6c
1004c3194:	mov	x28, x0
1004c3198:	b	0x1004c3118
1004c319c:	cmp	x8, #0x1
1004c31a0:	cset	w0, hi
1004c31a4:	mov	x1, x25
1004c31a8:	mov	w2, #0x1
1004c31ac:	adrp	x4, 7692 ; 0x1022cf000
1004c31b0:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c31b4:	bl	0x1004bfb6c
1004c31b8:	mov	x3, x0
1004c31bc:	b	0x1004c312c
1004c31c0:	mov	x0, x23
1004c31c4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c31c8:	ldp	x28, x27, [sp, #0x10]
1004c31cc:	ldr	w24, [sp, #0x4]
1004c31d0:	b	0x1004c3264
1004c31d4:	bl	0x1004a9938
1004c31d8:	ldp	x19, x20, [x0]
1004c31dc:	mov	x0, x20
1004c31e0:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c31e4:	adrp	x3, 7692 ; 0x1022cf000
1004c31e8:	ldr	x3, [x3, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004c31ec:	adrp	x4, 7692 ; 0x1022cf000
1004c31f0:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c31f4:	mov	w0, #0x0
1004c31f8:	mov	w1, #0x1
1004c31fc:	mov	w2, #0x1
1004c3200:	bl	0x1004bfb6c
1004c3204:	mov	x25, x0
1004c3208:	ldp	x22, x8, [x0, #0x10]
1004c320c:	add	x21, x22, #0x1
1004c3210:	cmp	x22, x8, lsr #1
1004c3214:	b.hs	0x1004c37bc
1004c3218:	adrp	x8, 6422 ; 0x101dd9000
1004c321c:	add	x8, x8, #0x380 ; literal pool for: "No paired devices yet"
1004c3220:	sub	x8, x8, #0x20
1004c3224:	orr	x8, x8, #0x8000000000000000
1004c3228:	str	x21, [x25, #0x10]
1004c322c:	mov	w9, #0x38
1004c3230:	madd	x9, x22, x9, x25
1004c3234:	mov	x10, #0x15
1004c3238:	movk	x10, #0xd000, lsl #48
1004c323c:	stp	x10, x8, [x9, #0x20]
1004c3240:	stp	x19, x20, [x9, #0x30]
1004c3244:	adrp	x8, -1216 ; 0x100003000
1004c3248:	add	x8, x8, #0xf40
1004c324c:	stp	xzr, x8, [x9, #0x40]
1004c3250:	str	xzr, [x9, #0x50]
1004c3254:	ldr	x26, [x23, #0x10]
1004c3258:	cbnz	x26, 0x1004c2fa8
1004c325c:	mov	x0, x23
1004c3260:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c3264:	adrp	x0, 7447 ; 0x1021da000
1004c3268:	add	x0, x0, #0x978
1004c326c:	mov	w1, #0x18
1004c3270:	mov	w2, #0x7
1004c3274:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c3278:	mov	x20, x0
1004c327c:	ldr	x19, [sp, #0x20]
1004c3280:	add	x0, x19, #0x10
1004c3284:	add	x1, sp, #0x80
1004c3288:	mov	x2, #0x0
1004c328c:	mov	x3, #0x0
1004c3290:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c3294:	add	x0, x19, #0x10
1004c3298:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c329c:	mov	x21, x0
1004c32a0:	add	x0, x20, #0x10
1004c32a4:	mov	x1, x21
1004c32a8:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c32ac:	mov	x0, x21
1004c32b0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c32b4:	adrp	x0, 7448 ; 0x1021db000
1004c32b8:	add	x0, x0, #0x738
1004c32bc:	mov	w1, #0x20
1004c32c0:	mov	w2, #0x7
1004c32c4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c32c8:	mov	x23, x0
1004c32cc:	adrp	x8, 0 ; 0x1004c3000
1004c32d0:	add	x8, x8, #0x8d0
1004c32d4:	stp	x8, x20, [x0, #0x10]
1004c32d8:	mov	x0, x20
1004c32dc:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c32e0:	mov	x0, x25
1004c32e4:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004c32e8:	tbz	w0, #0x0, 0x1004c36cc
1004c32ec:	ldp	x19, x8, [x25, #0x10]
1004c32f0:	add	x21, x19, #0x1
1004c32f4:	cmp	x19, x8, lsr #1
1004c32f8:	b.hs	0x1004c36f4
1004c32fc:	adrp	x8, 6422 ; 0x101dd9000
1004c3300:	add	x8, x8, #0x330 ; literal pool for: "Pair a Device\342\200\246"
1004c3304:	sub	x8, x8, #0x20
1004c3308:	orr	x8, x8, #0x8000000000000000
1004c330c:	str	x21, [x25, #0x10]
1004c3310:	mov	w9, #0x38
1004c3314:	madd	x9, x19, x9, x25
1004c3318:	mov	x10, #0x10
1004c331c:	movk	x10, #0x1000, lsl #48
1004c3320:	stp	x10, x8, [x9, #0x20]
1004c3324:	stp	xzr, xzr, [x9, #0x30]
1004c3328:	adrp	x8, -1215 ; 0x100004000
1004c332c:	add	x8, x8, #0xcc
1004c3330:	stp	xzr, x8, [x9, #0x40]
1004c3334:	str	x23, [x9, #0x50]
1004c3338:	mov	x0, x20
1004c333c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c3340:	ldp	x19, x8, [x25, #0x10]
1004c3344:	add	x20, x19, #0x1
1004c3348:	cmp	x19, x8, lsr #1
1004c334c:	b.hs	0x1004c371c
1004c3350:	str	x20, [x25, #0x10]
1004c3354:	mov	w8, #0x38
1004c3358:	madd	x8, x19, x8, x25
1004c335c:	mov	w9, #0x2d2d
1004c3360:	movk	w9, #0x2d, lsl #16
1004c3364:	mov	x10, #-0x1d00000000000000
1004c3368:	stp	x9, x10, [x8, #0x20]
1004c336c:	stp	xzr, xzr, [x8, #0x30]
1004c3370:	adrp	x9, -1216 ; 0x100003000
1004c3374:	add	x9, x9, #0xf40
1004c3378:	stp	xzr, x9, [x8, #0x40]
1004c337c:	str	xzr, [x8, #0x50]
1004c3380:	adrp	x0, 7447 ; 0x1021da000
1004c3384:	add	x0, x0, #0x978
1004c3388:	mov	w1, #0x18
1004c338c:	mov	w2, #0x7
1004c3390:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c3394:	mov	x20, x0
1004c3398:	ldr	x19, [sp, #0x20]
1004c339c:	add	x0, x19, #0x10
1004c33a0:	add	x1, sp, #0x68
1004c33a4:	mov	x2, #0x0
1004c33a8:	mov	x3, #0x0
1004c33ac:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c33b0:	add	x0, x19, #0x10
1004c33b4:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c33b8:	mov	x21, x0
1004c33bc:	add	x0, x20, #0x10
1004c33c0:	mov	x1, x21
1004c33c4:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c33c8:	mov	x0, x21
1004c33cc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c33d0:	adrp	x0, 7448 ; 0x1021db000
1004c33d4:	add	x0, x0, #0x760
1004c33d8:	mov	w1, #0x28
1004c33dc:	mov	w2, #0x7
1004c33e0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c33e4:	mov	x23, x0
1004c33e8:	stp	x20, x28, [x0, #0x10]
1004c33ec:	str	x27, [x0, #0x20]
1004c33f0:	adrp	x0, 7448 ; 0x1021db000
1004c33f4:	add	x0, x0, #0x788
1004c33f8:	mov	w1, #0x20
1004c33fc:	mov	w2, #0x7
1004c3400:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c3404:	mov	x21, x0
1004c3408:	adrp	x8, 0 ; 0x1004c3000
1004c340c:	add	x8, x8, #0x8dc
1004c3410:	stp	x8, x23, [x0, #0x10]
1004c3414:	ldp	x19, x22, [x25, #0x10]
1004c3418:	add	x23, x19, #0x1
1004c341c:	mov	x0, x20
1004c3420:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c3424:	mov	x0, x27
1004c3428:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c342c:	cmp	x19, x22, lsr #1
1004c3430:	b.hs	0x1004c3744
1004c3434:	str	x23, [x25, #0x10]
1004c3438:	mov	w8, #0x38
1004c343c:	madd	x8, x19, x8, x25
1004c3440:	mov	x9, #0x6f43
1004c3444:	movk	x9, #0x7970, lsl #16
1004c3448:	movk	x9, #0x4c20, lsl #32
1004c344c:	movk	x9, #0x6e69, lsl #48
1004c3450:	mov	x10, #0x6b
1004c3454:	movk	x10, #0xe900, lsl #48
1004c3458:	stp	x9, x10, [x8, #0x20]
1004c345c:	stp	xzr, xzr, [x8, #0x30]
1004c3460:	adrp	x9, -1215 ; 0x100004000
1004c3464:	add	x9, x9, #0xcc
1004c3468:	stp	xzr, x9, [x8, #0x40]
1004c346c:	str	x21, [x8, #0x50]
1004c3470:	mov	x0, x20
1004c3474:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c3478:	adrp	x0, 7447 ; 0x1021da000
1004c347c:	add	x0, x0, #0x978
1004c3480:	mov	w1, #0x18
1004c3484:	mov	w2, #0x7
1004c3488:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c348c:	mov	x20, x0
1004c3490:	ldr	x19, [sp, #0x20]
1004c3494:	add	x0, x19, #0x10
1004c3498:	add	x1, sp, #0x50
1004c349c:	mov	x2, #0x0
1004c34a0:	mov	x3, #0x0
1004c34a4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c34a8:	add	x0, x19, #0x10
1004c34ac:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c34b0:	mov	x21, x0
1004c34b4:	add	x0, x20, #0x10
1004c34b8:	mov	x1, x21
1004c34bc:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c34c0:	mov	x0, x21
1004c34c4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c34c8:	adrp	x0, 7448 ; 0x1021db000
1004c34cc:	add	x0, x0, #0x7b0
1004c34d0:	mov	w1, #0x28
1004c34d4:	mov	w2, #0x7
1004c34d8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c34dc:	mov	x23, x0
1004c34e0:	stp	x20, x28, [x0, #0x10]
1004c34e4:	str	x27, [x0, #0x20]
1004c34e8:	adrp	x0, 7448 ; 0x1021db000
1004c34ec:	add	x0, x0, #0x7d8
1004c34f0:	mov	w1, #0x20
1004c34f4:	mov	w2, #0x7
1004c34f8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c34fc:	mov	x21, x0
1004c3500:	adrp	x8, 0 ; 0x1004c3000
1004c3504:	add	x8, x8, #0x8e4
1004c3508:	stp	x8, x23, [x0, #0x10]
1004c350c:	ldp	x19, x22, [x25, #0x10]
1004c3510:	add	x23, x19, #0x1
1004c3514:	mov	x0, x27
1004c3518:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c351c:	mov	x0, x20
1004c3520:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c3524:	cmp	x19, x22, lsr #1
1004c3528:	b.hs	0x1004c376c
1004c352c:	str	x23, [x25, #0x10]
1004c3530:	mov	w8, #0x38
1004c3534:	madd	x8, x19, x8, x25
1004c3538:	mov	x9, #0x6f43
1004c353c:	movk	x9, #0x7970, lsl #16
1004c3540:	movk	x9, #0x5720, lsl #32
1004c3544:	movk	x9, #0x6265, lsl #48
1004c3548:	mov	x10, #0x4c20
1004c354c:	movk	x10, #0x6e69, lsl #16
1004c3550:	movk	x10, #0x6b, lsl #32
1004c3554:	movk	x10, #0xed00, lsl #48
1004c3558:	stp	x9, x10, [x8, #0x20]
1004c355c:	stp	xzr, xzr, [x8, #0x30]
1004c3560:	adrp	x9, -1215 ; 0x100004000
1004c3564:	add	x9, x9, #0xcc
1004c3568:	stp	xzr, x9, [x8, #0x40]
1004c356c:	str	x21, [x8, #0x50]
1004c3570:	mov	x0, x20
1004c3574:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c3578:	tbz	w24, #0x0, 0x1004c36a8
1004c357c:	mov	x0, x28
1004c3580:	mov	x1, x27
1004c3584:	bl	0x100398100
1004c3588:	ldr	x19, [x0, #0x10]
1004c358c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c3590:	cbz	x19, 0x1004c36a8
1004c3594:	adrp	x8, 6422 ; 0x101dd9000
1004c3598:	add	x8, x8, #0x350 ; literal pool for: "remote_access.share.revoke_links"
1004c359c:	sub	x8, x8, #0x20
1004c35a0:	mov	x9, #0x15
1004c35a4:	movk	x9, #0xd000, lsl #48
1004c35a8:	add	x0, x9, #0xb
1004c35ac:	orr	x1, x8, #0x8000000000000000
1004c35b0:	bl	0x100063df0
1004c35b4:	mov	x20, x0
1004c35b8:	mov	x23, x1
1004c35bc:	adrp	x0, 7447 ; 0x1021da000
1004c35c0:	add	x0, x0, #0x978
1004c35c4:	mov	w1, #0x18
1004c35c8:	mov	w2, #0x7
1004c35cc:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c35d0:	mov	x24, x0
1004c35d4:	ldr	x19, [sp, #0x20]
1004c35d8:	add	x0, x19, #0x10
1004c35dc:	add	x1, sp, #0x38
1004c35e0:	mov	x2, #0x0
1004c35e4:	mov	x3, #0x0
1004c35e8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c35ec:	add	x0, x19, #0x10
1004c35f0:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c35f4:	mov	x21, x0
1004c35f8:	add	x0, x24, #0x10
1004c35fc:	mov	x1, x21
1004c3600:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c3604:	mov	x0, x21
1004c3608:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c360c:	adrp	x0, 7448 ; 0x1021db000
1004c3610:	add	x0, x0, #0x800
1004c3614:	mov	w1, #0x28
1004c3618:	mov	w2, #0x7
1004c361c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c3620:	mov	x22, x25
1004c3624:	mov	x25, x0
1004c3628:	stp	x28, x27, [x0, #0x10]
1004c362c:	str	x24, [x0, #0x20]
1004c3630:	adrp	x0, 7448 ; 0x1021db000
1004c3634:	add	x0, x0, #0x828
1004c3638:	mov	w1, #0x20
1004c363c:	mov	w2, #0x7
1004c3640:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c3644:	mov	x21, x0
1004c3648:	adrp	x8, 0 ; 0x1004c3000
1004c364c:	add	x8, x8, #0x988
1004c3650:	stp	x8, x25, [x0, #0x10]
1004c3654:	mov	x26, x22
1004c3658:	ldp	x19, x22, [x22, #0x10]
1004c365c:	add	x25, x19, #0x1
1004c3660:	mov	x0, x27
1004c3664:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c3668:	mov	x0, x24
1004c366c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c3670:	cmp	x19, x22, lsr #1
1004c3674:	b.hs	0x1004c3794
1004c3678:	str	x25, [x26, #0x10]
1004c367c:	mov	x25, x26
1004c3680:	mov	w8, #0x38
1004c3684:	madd	x8, x19, x8, x26
1004c3688:	stp	x20, x23, [x8, #0x20]
1004c368c:	stp	xzr, xzr, [x8, #0x30]
1004c3690:	adrp	x9, -1215 ; 0x100004000
1004c3694:	add	x9, x9, #0xcc
1004c3698:	stp	xzr, x9, [x8, #0x40]
1004c369c:	str	x21, [x8, #0x50]
1004c36a0:	mov	x0, x24
1004c36a4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c36a8:	mov	x0, x25
1004c36ac:	add	sp, sp, #0x200
1004c36b0:	ldp	x29, x30, [sp, #0x50]
1004c36b4:	ldp	x20, x19, [sp, #0x40]
1004c36b8:	ldp	x22, x21, [sp, #0x30]
1004c36bc:	ldp	x24, x23, [sp, #0x20]
1004c36c0:	ldp	x26, x25, [sp, #0x10]
1004c36c4:	ldp	x28, x27, [sp], #0x60
1004c36c8:	ret
1004c36cc:	ldr	x8, [x25, #0x10]
1004c36d0:	adrp	x4, 7692 ; 0x1022cf000
1004c36d4:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c36d8:	add	x1, x8, #0x1
1004c36dc:	mov	w0, #0x0
1004c36e0:	mov	w2, #0x1
1004c36e4:	mov	x3, x25
1004c36e8:	bl	0x1004bfb6c
1004c36ec:	mov	x25, x0
1004c36f0:	b	0x1004c32ec
1004c36f4:	cmp	x8, #0x1
1004c36f8:	cset	w0, hi
1004c36fc:	adrp	x4, 7692 ; 0x1022cf000
1004c3700:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c3704:	mov	x1, x21
1004c3708:	mov	w2, #0x1
1004c370c:	mov	x3, x25
1004c3710:	bl	0x1004bfb6c
1004c3714:	mov	x25, x0
1004c3718:	b	0x1004c32fc
1004c371c:	cmp	x8, #0x1
1004c3720:	cset	w0, hi
1004c3724:	adrp	x4, 7692 ; 0x1022cf000
1004c3728:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c372c:	mov	x1, x20
1004c3730:	mov	w2, #0x1
1004c3734:	mov	x3, x25
1004c3738:	bl	0x1004bfb6c
1004c373c:	mov	x25, x0
1004c3740:	b	0x1004c3350
1004c3744:	cmp	x22, #0x1
1004c3748:	cset	w0, hi
1004c374c:	adrp	x4, 7692 ; 0x1022cf000
1004c3750:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c3754:	mov	x1, x23
1004c3758:	mov	w2, #0x1
1004c375c:	mov	x3, x25
1004c3760:	bl	0x1004bfb6c
1004c3764:	mov	x25, x0
1004c3768:	b	0x1004c3434
1004c376c:	cmp	x22, #0x1
1004c3770:	cset	w0, hi
1004c3774:	adrp	x4, 7692 ; 0x1022cf000
1004c3778:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c377c:	mov	x1, x23
1004c3780:	mov	w2, #0x1
1004c3784:	mov	x3, x25
1004c3788:	bl	0x1004bfb6c
1004c378c:	mov	x25, x0
1004c3790:	b	0x1004c352c
1004c3794:	cmp	x22, #0x1
1004c3798:	cset	w0, hi
1004c379c:	adrp	x4, 7692 ; 0x1022cf000
1004c37a0:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c37a4:	mov	x1, x25
1004c37a8:	mov	w2, #0x1
1004c37ac:	mov	x3, x26
1004c37b0:	bl	0x1004bfb6c
1004c37b4:	mov	x26, x0
1004c37b8:	b	0x1004c3678
1004c37bc:	cmp	x8, #0x1
1004c37c0:	cset	w0, hi
1004c37c4:	adrp	x4, 7692 ; 0x1022cf000
1004c37c8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c37cc:	mov	x1, x21
1004c37d0:	mov	w2, #0x1
1004c37d4:	mov	x3, x25
1004c37d8:	bl	0x1004bfb6c
1004c37dc:	mov	x25, x0
1004c37e0:	b	0x1004c3218
1004c37e4:	stp	x29, x30, [sp, #-0x10]!
1004c37e8:	mov	x29, sp
1004c37ec:	ldr	x0, [x20, #0x18]
1004c37f0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c37f4:	ldr	x0, [x20, #0x28]
1004c37f8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c37fc:	ldr	x0, [x20, #0x38]
1004c3800:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c3804:	ldr	x0, [x20, #0x48]
1004c3808:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c380c:	ldr	x0, [x20, #0x58]
1004c3810:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c3814:	ldr	x0, [x20, #0x68]
1004c3818:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c381c:	ldr	x0, [x20, #0x78]
1004c3820:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c3824:	ldr	x0, [x20, #0x88]
1004c3828:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c382c:	ldr	x0, [x20, #0x98]
1004c3830:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c3834:	ldr	x0, [x20, #0xc0]
1004c3838:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c383c:	ldr	x0, [x20, #0xc8]
1004c3840:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c3844:	mov	x0, x20
1004c3848:	mov	w1, #0xd0
1004c384c:	mov	w2, #0x7
1004c3850:	ldp	x29, x30, [sp], #0x10
1004c3854:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004c3858:	sub	sp, sp, #0x40
1004c385c:	stp	x20, x19, [sp, #0x20]
1004c3860:	stp	x29, x30, [sp, #0x30]
1004c3864:	add	x29, sp, #0x30
1004c3868:	ldp	x0, x1, [x20, #0x10]
1004c386c:	ldr	x19, [x20, #0xc8]
1004c3870:	add	x2, x20, #0x20
1004c3874:	bl	0x1003df428
1004c3878:	add	x0, x19, #0x10
1004c387c:	add	x1, sp, #0x8
1004c3880:	mov	x2, #0x0
1004c3884:	mov	x3, #0x0
1004c3888:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c388c:	add	x0, x19, #0x10
1004c3890:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c3894:	cbz	x0, 0x1004c38c0
1004c3898:	mov	x20, x0
1004c389c:	ldr	x8, [x0]
1004c38a0:	adrp	x9, 7692 ; 0x1022cf000
1004c38a4:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004c38a8:	ldr	x9, [x9]
1004c38ac:	and	x8, x9, x8
1004c38b0:	ldr	x8, [x8, #0x248]
1004c38b4:	blr	x8
1004c38b8:	mov	x0, x20
1004c38bc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c38c0:	ldp	x29, x30, [sp, #0x30]
1004c38c4:	ldp	x20, x19, [sp, #0x20]
1004c38c8:	add	sp, sp, #0x40
1004c38cc:	ret
1004c38d0:	adrp	x0, -387 ; 0x100340000
1004c38d4:	add	x0, x0, #0x530
1004c38d8:	b	0x1004c3a08
1004c38dc:	mov	w0, #0x0
1004c38e0:	b	0x1004c38ec
1004c38e4:	mov	w0, #0x1
1004c38e8:	b	0x1004c38ec
1004c38ec:	sub	sp, sp, #0x60
1004c38f0:	stp	x24, x23, [sp, #0x20]
1004c38f4:	stp	x22, x21, [sp, #0x30]
1004c38f8:	stp	x20, x19, [sp, #0x40]
1004c38fc:	stp	x29, x30, [sp, #0x50]
1004c3900:	add	x29, sp, #0x50
1004c3904:	mov	x19, x0
1004c3908:	ldp	x23, x21, [x20, #0x10]
1004c390c:	ldr	x22, [x20, #0x20]
1004c3910:	add	x0, x23, #0x10
1004c3914:	add	x1, sp, #0x8
1004c3918:	mov	x2, #0x0
1004c391c:	mov	x3, #0x0
1004c3920:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c3924:	add	x0, x23, #0x10
1004c3928:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c392c:	cbz	x0, 0x1004c3958
1004c3930:	mov	x20, x0
1004c3934:	ldr	x8, [x0]
1004c3938:	adrp	x9, 7692 ; 0x1022cf000
1004c393c:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004c3940:	ldr	x9, [x9]
1004c3944:	and	x8, x9, x8
1004c3948:	ldr	x8, [x8, #0x248]
1004c394c:	blr	x8
1004c3950:	mov	x0, x20
1004c3954:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c3958:	and	w2, w19, #0x1
1004c395c:	mov	x0, x21
1004c3960:	mov	x1, x22
1004c3964:	bl	0x100340598
1004c3968:	ldp	x29, x30, [sp, #0x50]
1004c396c:	ldp	x20, x19, [sp, #0x40]
1004c3970:	ldp	x22, x21, [sp, #0x30]
1004c3974:	ldp	x24, x23, [sp, #0x20]
1004c3978:	add	sp, sp, #0x60
1004c397c:	ret
1004c3980:	mov	w0, #0x28
1004c3984:	b	0x1004c63a8
1004c3988:	sub	sp, sp, #0x40
1004c398c:	stp	x20, x19, [sp, #0x20]
1004c3990:	stp	x29, x30, [sp, #0x30]
1004c3994:	add	x29, sp, #0x30
1004c3998:	ldp	x0, x1, [x20, #0x10]
1004c399c:	ldr	x19, [x20, #0x20]
1004c39a0:	bl	0x100398b0c
1004c39a4:	add	x0, x19, #0x10
1004c39a8:	add	x1, sp, #0x8
1004c39ac:	mov	x2, #0x0
1004c39b0:	mov	x3, #0x0
1004c39b4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c39b8:	add	x0, x19, #0x10
1004c39bc:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c39c0:	cbz	x0, 0x1004c39ec
1004c39c4:	mov	x20, x0
1004c39c8:	ldr	x8, [x0]
1004c39cc:	adrp	x9, 7692 ; 0x1022cf000
1004c39d0:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004c39d4:	ldr	x9, [x9]
1004c39d8:	and	x8, x9, x8
1004c39dc:	ldr	x8, [x8, #0x248]
1004c39e0:	blr	x8
1004c39e4:	mov	x0, x20
1004c39e8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c39ec:	ldp	x29, x30, [sp, #0x30]
1004c39f0:	ldp	x20, x19, [sp, #0x20]
1004c39f4:	add	sp, sp, #0x40
1004c39f8:	ret
1004c39fc:	adrp	x0, 316 ; 0x1005ff000
1004c3a00:	add	x0, x0, #0xd1c
1004c3a04:	b	0x1004c3a08
1004c3a08:	sub	sp, sp, #0x40
1004c3a0c:	stp	x20, x19, [sp, #0x20]
1004c3a10:	stp	x29, x30, [sp, #0x30]
1004c3a14:	add	x29, sp, #0x30
1004c3a18:	mov	x19, x0
1004c3a1c:	add	x0, x20, #0x10
1004c3a20:	add	x1, sp, #0x8
1004c3a24:	mov	x2, #0x0
1004c3a28:	mov	x3, #0x0
1004c3a2c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c3a30:	add	x0, x20, #0x10
1004c3a34:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c3a38:	cbz	x0, 0x1004c3a64
1004c3a3c:	mov	x20, x0
1004c3a40:	ldr	x8, [x0]
1004c3a44:	adrp	x9, 7692 ; 0x1022cf000
1004c3a48:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004c3a4c:	ldr	x9, [x9]
1004c3a50:	and	x8, x9, x8
1004c3a54:	ldr	x8, [x8, #0x248]
1004c3a58:	blr	x8
1004c3a5c:	mov	x0, x20
1004c3a60:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c3a64:	blr	x19
1004c3a68:	ldp	x29, x30, [sp, #0x30]
1004c3a6c:	ldp	x20, x19, [sp, #0x20]
1004c3a70:	add	sp, sp, #0x40
1004c3a74:	ret
1004c3a78:	sub	sp, sp, #0x40
1004c3a7c:	stp	x20, x19, [sp, #0x20]
1004c3a80:	stp	x29, x30, [sp, #0x30]
1004c3a84:	add	x29, sp, #0x30
1004c3a88:	ldp	x0, x1, [x20, #0x10]
1004c3a8c:	ldr	x19, [x20, #0x20]
1004c3a90:	bl	0x10057b228
1004c3a94:	add	x0, x19, #0x10
1004c3a98:	add	x1, sp, #0x8
1004c3a9c:	mov	x2, #0x0
1004c3aa0:	mov	x3, #0x0
1004c3aa4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c3aa8:	add	x0, x19, #0x10
1004c3aac:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c3ab0:	cbz	x0, 0x1004c3adc
1004c3ab4:	mov	x20, x0
1004c3ab8:	ldr	x8, [x0]
1004c3abc:	adrp	x9, 7692 ; 0x1022cf000
1004c3ac0:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004c3ac4:	ldr	x9, [x9]
1004c3ac8:	and	x8, x9, x8
1004c3acc:	ldr	x8, [x8, #0x248]
1004c3ad0:	blr	x8
1004c3ad4:	mov	x0, x20
1004c3ad8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c3adc:	ldp	x29, x30, [sp, #0x30]
1004c3ae0:	ldp	x20, x19, [sp, #0x20]
1004c3ae4:	add	sp, sp, #0x40
1004c3ae8:	ret
1004c3aec:	stp	x29, x30, [sp, #-0x10]!
1004c3af0:	mov	x29, sp
1004c3af4:	ldr	x0, [x20, #0x18]
1004c3af8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c3afc:	mov	x0, x20
1004c3b00:	mov	w1, #0x20
1004c3b04:	mov	w2, #0x7
1004c3b08:	ldp	x29, x30, [sp], #0x10
1004c3b0c:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004c3b10:	sub	sp, sp, #0xc0
1004c3b14:	stp	x28, x27, [sp, #0x60]
1004c3b18:	stp	x26, x25, [sp, #0x70]
1004c3b1c:	stp	x24, x23, [sp, #0x80]
1004c3b20:	stp	x22, x21, [sp, #0x90]
1004c3b24:	stp	x20, x19, [sp, #0xa0]
1004c3b28:	stp	x29, x30, [sp, #0xb0]
1004c3b2c:	add	x29, sp, #0xb0
1004c3b30:	ldp	x9, x8, [x20, #0x10]
1004c3b34:	stp	x8, x9, [sp]
1004c3b38:	bl	0x10057912c
1004c3b3c:	ldr	x24, [x0, #0x10]
1004c3b40:	cbz	x24, 0x1004c3ca8
1004c3b44:	adrp	x19, 7692 ; 0x1022cf000
1004c3b48:	ldr	x19, [x19, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004c3b4c:	mov	w23, #0x20
1004c3b50:	mov	x20, x0
1004c3b54:	add	x8, x0, x23
1004c3b58:	ldp	q0, q1, [x8]
1004c3b5c:	stp	q0, q1, [sp, #0x20]
1004c3b60:	ldrb	w8, [x8, #0x20]
1004c3b64:	strb	w8, [sp, #0x40]
1004c3b68:	bl	0x1000ace0c
1004c3b6c:	add	x0, sp, #0x20
1004c3b70:	bl	0x10057b218
1004c3b74:	mov	x25, x0
1004c3b78:	ldp	x22, x26, [sp, #0x20]
1004c3b7c:	add	x8, sp, #0x20
1004c3b80:	ldur	q0, [x8, #0x10]
1004c3b84:	str	q0, [sp, #0x50]
1004c3b88:	adrp	x0, 7448 ; 0x1021db000
1004c3b8c:	add	x0, x0, #0x8a0
1004c3b90:	mov	w1, #0x41
1004c3b94:	mov	w2, #0x7
1004c3b98:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c3b9c:	mov	x28, x0
1004c3ba0:	ldp	x21, x8, [sp]
1004c3ba4:	stp	x8, x21, [x0, #0x10]
1004c3ba8:	ldp	q0, q1, [sp, #0x20]
1004c3bac:	stp	q0, q1, [x0, #0x20]
1004c3bb0:	ldrb	w8, [sp, #0x40]
1004c3bb4:	strb	w8, [x0, #0x40]
1004c3bb8:	adrp	x0, 7448 ; 0x1021db000
1004c3bbc:	add	x0, x0, #0x8c8
1004c3bc0:	mov	w1, #0x20
1004c3bc4:	mov	w2, #0x7
1004c3bc8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c3bcc:	mov	x27, x0
1004c3bd0:	adrp	x8, 0 ; 0x1004c3000
1004c3bd4:	add	x8, x8, #0xef8
1004c3bd8:	stp	x8, x28, [x0, #0x10]
1004c3bdc:	mov	x0, x26
1004c3be0:	mov	w1, #0x2
1004c3be4:	bl	0x101aca630 ; symbol stub for: _swift_bridgeObjectRetain_n
1004c3be8:	mov	x0, x21
1004c3bec:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c3bf0:	add	x0, sp, #0x50
1004c3bf4:	add	x1, sp, #0x10
1004c3bf8:	bl	0x1000589e8
1004c3bfc:	mov	x0, x19
1004c3c00:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004c3c04:	tbz	w0, #0x0, 0x1004c3c50
1004c3c08:	ldp	x21, x8, [x19, #0x10]
1004c3c0c:	add	x28, x21, #0x1
1004c3c10:	cmp	x21, x8, lsr #1
1004c3c14:	b.hs	0x1004c3c78
1004c3c18:	str	x28, [x19, #0x10]
1004c3c1c:	mov	w8, #0x38
1004c3c20:	madd	x8, x21, x8, x19
1004c3c24:	stp	x22, x26, [x8, #0x20]
1004c3c28:	stp	xzr, xzr, [x8, #0x30]
1004c3c2c:	adrp	x9, -1215 ; 0x100004000
1004c3c30:	add	x9, x9, #0xcc
1004c3c34:	stp	x25, x9, [x8, #0x40]
1004c3c38:	str	x27, [x8, #0x50]
1004c3c3c:	add	x23, x23, #0x28
1004c3c40:	subs	x24, x24, #0x1
1004c3c44:	mov	x0, x20
1004c3c48:	b.ne	0x1004c3b50
1004c3c4c:	b	0x1004c3ca0
1004c3c50:	ldr	x8, [x19, #0x10]
1004c3c54:	add	x1, x8, #0x1
1004c3c58:	mov	w0, #0x0
1004c3c5c:	mov	w2, #0x1
1004c3c60:	mov	x3, x19
1004c3c64:	adrp	x4, 7692 ; 0x1022cf000
1004c3c68:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c3c6c:	bl	0x1004bfb6c
1004c3c70:	mov	x19, x0
1004c3c74:	b	0x1004c3c08
1004c3c78:	cmp	x8, #0x1
1004c3c7c:	cset	w0, hi
1004c3c80:	mov	x1, x28
1004c3c84:	mov	w2, #0x1
1004c3c88:	mov	x3, x19
1004c3c8c:	adrp	x4, 7692 ; 0x1022cf000
1004c3c90:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c3c94:	bl	0x1004bfb6c
1004c3c98:	mov	x19, x0
1004c3c9c:	b	0x1004c3c18
1004c3ca0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c3ca4:	b	0x1004c3cb4
1004c3ca8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c3cac:	adrp	x19, 7692 ; 0x1022cf000
1004c3cb0:	ldr	x19, [x19, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004c3cb4:	mov	x26, #0x10
1004c3cb8:	movk	x26, #0xd000, lsl #48
1004c3cbc:	adrp	x8, 6421 ; 0x101dd8000
1004c3cc0:	add	x8, x8, #0xf50 ; literal pool for: "com.apple.finder"
1004c3cc4:	sub	x21, x8, #0x20
1004c3cc8:	bl	0x1000ace0c
1004c3ccc:	orr	x1, x21, #0x8000000000000000
1004c3cd0:	mov	x0, #0x10
1004c3cd4:	movk	x0, #0xd000, lsl #48
1004c3cd8:	bl	0x10057b224
1004c3cdc:	mov	x25, x0
1004c3ce0:	adrp	x0, 7448 ; 0x1021db000
1004c3ce4:	add	x0, x0, #0x8f0
1004c3ce8:	mov	w1, #0x20
1004c3cec:	mov	w2, #0x7
1004c3cf0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c3cf4:	mov	x21, x0
1004c3cf8:	ldp	x20, x8, [sp]
1004c3cfc:	stp	x8, x20, [x0, #0x10]
1004c3d00:	adrp	x0, 7448 ; 0x1021db000
1004c3d04:	add	x0, x0, #0x918
1004c3d08:	mov	w1, #0x20
1004c3d0c:	mov	w2, #0x7
1004c3d10:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c3d14:	mov	x23, x0
1004c3d18:	adrp	x8, 0 ; 0x1004c3000
1004c3d1c:	add	x8, x8, #0xf04
1004c3d20:	stp	x8, x21, [x0, #0x10]
1004c3d24:	mov	x0, x25
1004c3d28:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004c3d2c:	mov	x21, x0
1004c3d30:	mov	x0, x20
1004c3d34:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c3d38:	mov	x0, x19
1004c3d3c:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004c3d40:	tbz	w0, #0x0, 0x1004c3e7c
1004c3d44:	ldp	x22, x8, [x19, #0x10]
1004c3d48:	add	x24, x22, #0x1
1004c3d4c:	cmp	x22, x8, lsr #1
1004c3d50:	b.hs	0x1004c3ea4
1004c3d54:	str	x24, [x19, #0x10]
1004c3d58:	mov	w8, #0x38
1004c3d5c:	madd	x8, x22, x8, x19
1004c3d60:	mov	x9, #0x6946
1004c3d64:	movk	x9, #0x646e, lsl #16
1004c3d68:	movk	x9, #0x7265, lsl #32
1004c3d6c:	mov	x10, #-0x1a00000000000000
1004c3d70:	stp	x9, x10, [x8, #0x20]
1004c3d74:	stp	xzr, xzr, [x8, #0x30]
1004c3d78:	adrp	x9, -1215 ; 0x100004000
1004c3d7c:	add	x9, x9, #0xcc
1004c3d80:	stp	x25, x9, [x8, #0x40]
1004c3d84:	str	x23, [x8, #0x50]
1004c3d88:	adrp	x8, 6422 ; 0x101dd9000
1004c3d8c:	add	x8, x8, #0x3c0 ; literal pool for: "com.apple.Terminal"
1004c3d90:	sub	x22, x8, #0x20
1004c3d94:	bl	0x1000ace0c
1004c3d98:	add	x0, x26, #0x2
1004c3d9c:	orr	x1, x22, #0x8000000000000000
1004c3da0:	bl	0x10057b224
1004c3da4:	mov	x25, x0
1004c3da8:	adrp	x0, 7448 ; 0x1021db000
1004c3dac:	add	x0, x0, #0x940
1004c3db0:	mov	w1, #0x20
1004c3db4:	mov	w2, #0x7
1004c3db8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c3dbc:	mov	x24, x0
1004c3dc0:	ldp	x20, x8, [sp]
1004c3dc4:	stp	x8, x20, [x0, #0x10]
1004c3dc8:	adrp	x0, 7448 ; 0x1021db000
1004c3dcc:	add	x0, x0, #0x968
1004c3dd0:	mov	w1, #0x20
1004c3dd4:	mov	w2, #0x7
1004c3dd8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c3ddc:	mov	x23, x0
1004c3de0:	adrp	x8, 0 ; 0x1004c3000
1004c3de4:	add	x8, x8, #0xf0c
1004c3de8:	stp	x8, x24, [x0, #0x10]
1004c3dec:	ldp	x22, x26, [x19, #0x10]
1004c3df0:	add	x24, x22, #0x1
1004c3df4:	mov	x0, x20
1004c3df8:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c3dfc:	mov	x0, x25
1004c3e00:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004c3e04:	mov	x20, x0
1004c3e08:	cmp	x22, x26, lsr #1
1004c3e0c:	b.hs	0x1004c3ecc
1004c3e10:	str	x24, [x19, #0x10]
1004c3e14:	mov	w8, #0x38
1004c3e18:	madd	x8, x22, x8, x19
1004c3e1c:	mov	x9, #0x6554
1004c3e20:	movk	x9, #0x6d72, lsl #16
1004c3e24:	movk	x9, #0x6e69, lsl #32
1004c3e28:	movk	x9, #0x6c61, lsl #48
1004c3e2c:	mov	x10, #-0x1800000000000000
1004c3e30:	stp	x9, x10, [x8, #0x20]
1004c3e34:	stp	xzr, xzr, [x8, #0x30]
1004c3e38:	adrp	x9, -1215 ; 0x100004000
1004c3e3c:	add	x9, x9, #0xcc
1004c3e40:	stp	x25, x9, [x8, #0x40]
1004c3e44:	str	x23, [x8, #0x50]
1004c3e48:	mov	x0, x21
1004c3e4c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c3e50:	mov	x0, x20
1004c3e54:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c3e58:	mov	x0, x19
1004c3e5c:	ldp	x29, x30, [sp, #0xb0]
1004c3e60:	ldp	x20, x19, [sp, #0xa0]
1004c3e64:	ldp	x22, x21, [sp, #0x90]
1004c3e68:	ldp	x24, x23, [sp, #0x80]
1004c3e6c:	ldp	x26, x25, [sp, #0x70]
1004c3e70:	ldp	x28, x27, [sp, #0x60]
1004c3e74:	add	sp, sp, #0xc0
1004c3e78:	ret
1004c3e7c:	ldr	x8, [x19, #0x10]
1004c3e80:	adrp	x4, 7692 ; 0x1022cf000
1004c3e84:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c3e88:	add	x1, x8, #0x1
1004c3e8c:	mov	w0, #0x0
1004c3e90:	mov	w2, #0x1
1004c3e94:	mov	x3, x19
1004c3e98:	bl	0x1004bfb6c
1004c3e9c:	mov	x19, x0
1004c3ea0:	b	0x1004c3d44
1004c3ea4:	cmp	x8, #0x1
1004c3ea8:	cset	w0, hi
1004c3eac:	adrp	x4, 7692 ; 0x1022cf000
1004c3eb0:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c3eb4:	mov	x1, x24
1004c3eb8:	mov	w2, #0x1
1004c3ebc:	mov	x3, x19
1004c3ec0:	bl	0x1004bfb6c
1004c3ec4:	mov	x19, x0
1004c3ec8:	b	0x1004c3d54
1004c3ecc:	cmp	x26, #0x1
1004c3ed0:	cset	w0, hi
1004c3ed4:	adrp	x4, 7692 ; 0x1022cf000
1004c3ed8:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c3edc:	mov	x1, x24
1004c3ee0:	mov	w2, #0x1
1004c3ee4:	mov	x3, x19
1004c3ee8:	bl	0x1004bfb6c
1004c3eec:	mov	x19, x0
1004c3ef0:	b	0x1004c3e10
1004c3ef4:	b	0x1004c6488
1004c3ef8:	ldp	x0, x1, [x20, #0x10]
1004c3efc:	add	x2, x20, #0x20
1004c3f00:	b	0x10057b208
1004c3f04:	ldp	x0, x1, [x20, #0x10]
1004c3f08:	b	0x10057b228
1004c3f0c:	ldp	x0, x1, [x20, #0x10]
1004c3f10:	b	0x10057b298
1004c3f14:	stp	x29, x30, [sp, #-0x10]!
1004c3f18:	mov	x29, sp
1004c3f1c:	ldr	x0, [x20, #0x10]
1004c3f20:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c3f24:	mov	x0, x20
1004c3f28:	mov	w1, #0x20
1004c3f2c:	mov	w2, #0x7
1004c3f30:	ldp	x29, x30, [sp], #0x10
1004c3f34:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004c3f38:	stp	d9, d8, [sp, #-0x30]!
1004c3f3c:	stp	x20, x19, [sp, #0x10]
1004c3f40:	stp	x29, x30, [sp, #0x20]
1004c3f44:	add	x29, sp, #0x20
1004c3f48:	ldr	x19, [x20, #0x10]
1004c3f4c:	ldr	d8, [x20, #0x18]
1004c3f50:	mov	x8, #-0x6666666666666667
1004c3f54:	movk	x8, #0x999a
1004c3f58:	movk	x8, #0x3fc9, lsl #48
1004c3f5c:	fmov	d0, x8
1004c3f60:	bl	0x101ad28a0 ; selector setDuration:
1004c3f64:	adrp	x8, 7898 ; 0x10239d000
1004c3f68:	ldr	x8, [x8, #0x290]
1004c3f6c:	ldr	x0, [x19, x8]
1004c3f70:	cbz	x0, 0x1004c3fa8
1004c3f74:	bl	0x101acb740 ; selector animator
1004c3f78:	mov	x29, x29
1004c3f7c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c3f80:	mov	x19, x0
1004c3f84:	bl	0x101acdcc0 ; selector frame
1004c3f88:	mov	x0, x19
1004c3f8c:	mov.16b	v0, v8
1004c3f90:	bl	0x101ad2b80 ; selector setFrame:
1004c3f94:	mov	x0, x19
1004c3f98:	ldp	x29, x30, [sp, #0x20]
1004c3f9c:	ldp	x20, x19, [sp, #0x10]
1004c3fa0:	ldp	d9, d8, [sp], #0x30
1004c3fa4:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004c3fa8:	ldp	x29, x30, [sp, #0x20]
1004c3fac:	ldp	x20, x19, [sp, #0x10]
1004c3fb0:	ldp	d9, d8, [sp], #0x30
1004c3fb4:	ret
1004c3fb8:	mov	x0, x20
1004c3fbc:	mov	w1, #0x20
1004c3fc0:	mov	w2, #0x7
1004c3fc4:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004c3fc8:	mov	w0, #0x89
1004c3fcc:	b	0x1004c5a24
1004c3fd0:	mov	w0, #0x42
1004c3fd4:	b	0x1004c5a24
1004c3fd8:	mov	w0, #0x47
1004c3fdc:	b	0x1004c5a24
1004c3fe0:	mov	w0, #0x87
1004c3fe4:	b	0x1004c5a24
1004c3fe8:	sub	sp, sp, #0x60
1004c3fec:	stp	x22, x21, [sp, #0x30]
1004c3ff0:	stp	x20, x19, [sp, #0x40]
1004c3ff4:	stp	x29, x30, [sp, #0x50]
1004c3ff8:	add	x29, sp, #0x50
1004c3ffc:	mov	x19, x20
1004c4000:	add	x0, x20, #0x10
1004c4004:	add	x1, sp, #0x18
1004c4008:	mov	x2, #0x0
1004c400c:	mov	x3, #0x0
1004c4010:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c4014:	add	x0, x20, #0x10
1004c4018:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c401c:	adrp	x22, 7691 ; 0x1022cf000
1004c4020:	ldr	x22, [x22, #0x718] ; literal pool symbol address: _swift_isaMask
1004c4024:	cbz	x0, 0x1004c4090
1004c4028:	adrp	x8, 7897 ; 0x10239d000
1004c402c:	ldr	x8, [x8, #0x250]
1004c4030:	mov	x21, x0
1004c4034:	add	x0, x0, x8
1004c4038:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c403c:	mov	x20, x0
1004c4040:	mov	x0, x21
1004c4044:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c4048:	cbz	x20, 0x1004c4090
1004c404c:	ldr	x8, [x20]
1004c4050:	ldr	x9, [x22]
1004c4054:	and	x8, x9, x8
1004c4058:	ldr	x8, [x8, #0x440]
1004c405c:	blr	x8
1004c4060:	mov	x21, x0
1004c4064:	mov	x0, x20
1004c4068:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c406c:	cbz	x21, 0x1004c4090
1004c4070:	ldr	x8, [x21]
1004c4074:	ldr	x9, [x22]
1004c4078:	and	x8, x9, x8
1004c407c:	ldr	x8, [x8, #0x410]
1004c4080:	mov	x20, x21
1004c4084:	blr	x8
1004c4088:	mov	x0, x21
1004c408c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c4090:	add	x0, x19, #0x10
1004c4094:	mov	x1, sp
1004c4098:	mov	x2, #0x0
1004c409c:	mov	x3, #0x0
1004c40a0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c40a4:	add	x0, x19, #0x10
1004c40a8:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c40ac:	cbz	x0, 0x1004c40d0
1004c40b0:	mov	x20, x0
1004c40b4:	ldr	x8, [x0]
1004c40b8:	ldr	x9, [x22]
1004c40bc:	and	x8, x9, x8
1004c40c0:	ldr	x8, [x8, #0x248]
1004c40c4:	blr	x8
1004c40c8:	mov	x0, x20
1004c40cc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c40d0:	ldp	x29, x30, [sp, #0x50]
1004c40d4:	ldp	x20, x19, [sp, #0x40]
1004c40d8:	ldp	x22, x21, [sp, #0x30]
1004c40dc:	add	sp, sp, #0x60
1004c40e0:	ret
1004c40e4:	sub	sp, sp, #0x60
1004c40e8:	stp	x22, x21, [sp, #0x30]
1004c40ec:	stp	x20, x19, [sp, #0x40]
1004c40f0:	stp	x29, x30, [sp, #0x50]
1004c40f4:	add	x29, sp, #0x50
1004c40f8:	ldp	x19, x21, [x20, #0x10]
1004c40fc:	add	x0, x19, #0x10
1004c4100:	add	x1, sp, #0x18
1004c4104:	mov	x2, #0x0
1004c4108:	mov	x3, #0x0
1004c410c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c4110:	add	x0, x19, #0x10
1004c4114:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004c4118:	cbz	x0, 0x1004c4134
1004c411c:	mov	x20, x0
1004c4120:	ldr	x8, [x0]
1004c4124:	ldr	x8, [x8, #0x330]
1004c4128:	blr	x8
1004c412c:	mov	x0, x20
1004c4130:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c4134:	adrp	x8, 7778 ; 0x102326000
1004c4138:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004c413c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004c4140:	bl	0x101acce80 ; selector defaultCenter
1004c4144:	mov	x29, x29
1004c4148:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004c414c:	mov	x19, x0
1004c4150:	bl	0x10006e844
1004c4154:	ldr	x2, [x0]
1004c4158:	mov	x0, x19
1004c415c:	mov	x3, #0x0
1004c4160:	bl	0x101ad0340 ; selector postNotificationName:object:
1004c4164:	mov	x0, x19
1004c4168:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c416c:	add	x0, x21, #0x10
1004c4170:	mov	x1, sp
1004c4174:	mov	x2, #0x0
1004c4178:	mov	x3, #0x0
1004c417c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c4180:	add	x0, x21, #0x10
1004c4184:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c4188:	cbz	x0, 0x1004c41b4
1004c418c:	mov	x20, x0
1004c4190:	ldr	x8, [x0]
1004c4194:	adrp	x9, 7691 ; 0x1022cf000
1004c4198:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004c419c:	ldr	x9, [x9]
1004c41a0:	and	x8, x9, x8
1004c41a4:	ldr	x8, [x8, #0x248]
1004c41a8:	blr	x8
1004c41ac:	mov	x0, x20
1004c41b0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c41b4:	ldp	x29, x30, [sp, #0x50]
1004c41b8:	ldp	x20, x19, [sp, #0x40]
1004c41bc:	ldp	x22, x21, [sp, #0x30]
1004c41c0:	add	sp, sp, #0x60
1004c41c4:	ret
1004c41c8:	stp	x29, x30, [sp, #-0x10]!
1004c41cc:	mov	x29, sp
1004c41d0:	ldr	x0, [x20, #0x10]
1004c41d4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c41d8:	ldr	x0, [x20, #0x18]
1004c41dc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c41e0:	ldr	x0, [x20, #0x30]
1004c41e4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c41e8:	ldr	x0, [x20, #0x40]
1004c41ec:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c41f0:	ldr	x0, [x20, #0x50]
1004c41f4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c41f8:	add	x0, x20, #0x60
1004c41fc:	bl	0x10002d8d4
1004c4200:	ldr	x0, [x20, #0x98]
1004c4204:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c4208:	ldr	x0, [x20, #0xa8]
1004c420c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c4210:	ldr	x0, [x20, #0xb8]
1004c4214:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c4218:	mov	x0, x20
1004c421c:	mov	w1, #0xc1
1004c4220:	mov	w2, #0x7
1004c4224:	ldp	x29, x30, [sp], #0x10
1004c4228:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004c422c:	sub	sp, sp, #0x1e0
1004c4230:	stp	x28, x27, [sp, #0x180]
1004c4234:	stp	x26, x25, [sp, #0x190]
1004c4238:	stp	x24, x23, [sp, #0x1a0]
1004c423c:	stp	x22, x21, [sp, #0x1b0]
1004c4240:	stp	x20, x19, [sp, #0x1c0]
1004c4244:	stp	x29, x30, [sp, #0x1d0]
1004c4248:	add	x29, sp, #0x1d0
1004c424c:	ldp	x19, x22, [x20, #0x10]
1004c4250:	ldrb	w28, [x20, #0x59]
1004c4254:	adrp	x0, 7446 ; 0x1021da000
1004c4258:	add	x0, x0, #0x978
1004c425c:	mov	w1, #0x18
1004c4260:	mov	w2, #0x7
1004c4264:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4268:	mov	x23, x0
1004c426c:	add	x0, x19, #0x10
1004c4270:	sub	x1, x29, #0x70
1004c4274:	mov	x2, #0x0
1004c4278:	mov	x3, #0x0
1004c427c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c4280:	str	x19, [sp, #0x30]
1004c4284:	add	x0, x19, #0x10
1004c4288:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c428c:	mov	x19, x0
1004c4290:	add	x0, x23, #0x10
1004c4294:	mov	x1, x19
1004c4298:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c429c:	mov	x0, x19
1004c42a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c42a4:	adrp	x0, 7448 ; 0x1021dc000
1004c42a8:	add	x0, x0, #0x98
1004c42ac:	mov	w1, #0x59
1004c42b0:	mov	w2, #0x7
1004c42b4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c42b8:	mov	x19, x0
1004c42bc:	stp	x23, x22, [x0, #0x10]
1004c42c0:	ldp	q0, q1, [x20, #0x20]
1004c42c4:	stp	q0, q1, [x0, #0x20]
1004c42c8:	ldr	q0, [x20, #0x40]
1004c42cc:	str	q0, [x0, #0x40]
1004c42d0:	ldur	q0, [x20, #0x49]
1004c42d4:	stur	q0, [x0, #0x49]
1004c42d8:	adrp	x0, 7448 ; 0x1021dc000
1004c42dc:	add	x0, x0, #0xc0
1004c42e0:	mov	w1, #0x20
1004c42e4:	mov	w2, #0x7
1004c42e8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c42ec:	mov	x24, x0
1004c42f0:	adrp	x8, 2 ; 0x1004c6000
1004c42f4:	add	x8, x8, #0x638
1004c42f8:	stp	x8, x19, [x0, #0x10]
1004c42fc:	mov	x0, x22
1004c4300:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4304:	mov	x0, x23
1004c4308:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c430c:	add	x0, x20, #0x20
1004c4310:	sub	x1, x29, #0xb0
1004c4314:	bl	0x1004c6644
1004c4318:	adrp	x3, 7691 ; 0x1022cf000
1004c431c:	ldr	x3, [x3, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004c4320:	adrp	x4, 7691 ; 0x1022cf000
1004c4324:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c4328:	mov	w0, #0x0
1004c432c:	mov	w1, #0x1
1004c4330:	mov	w2, #0x1
1004c4334:	bl	0x1004bfb6c
1004c4338:	mov	x26, x0
1004c433c:	ldp	x19, x8, [x0, #0x10]
1004c4340:	add	x21, x19, #0x1
1004c4344:	cmp	x19, x8, lsr #1
1004c4348:	b.hs	0x1004c53dc
1004c434c:	str	x21, [x26, #0x10]
1004c4350:	mov	w8, #0x38
1004c4354:	madd	x8, x19, x8, x26
1004c4358:	mov	x9, #0x6f43
1004c435c:	movk	x9, #0x7970, lsl #16
1004c4360:	movk	x9, #0x5320, lsl #32
1004c4364:	movk	x9, #0x7365, lsl #48
1004c4368:	mov	x10, #0x6973
1004c436c:	movk	x10, #0x6e6f, lsl #16
1004c4370:	movk	x10, #0x4920, lsl #32
1004c4374:	movk	x10, #0xef44, lsl #48
1004c4378:	stp	x9, x10, [x8, #0x20]
1004c437c:	stp	xzr, xzr, [x8, #0x30]
1004c4380:	adrp	x9, -1216 ; 0x100004000
1004c4384:	add	x9, x9, #0xcc
1004c4388:	stp	xzr, x9, [x8, #0x40]
1004c438c:	str	x24, [x8, #0x50]
1004c4390:	mov	x0, x23
1004c4394:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c4398:	mov	x0, x28
1004c439c:	bl	0x1004f6714
1004c43a0:	tbz	w0, #0x0, 0x1004c44c0
1004c43a4:	adrp	x0, 7446 ; 0x1021da000
1004c43a8:	add	x0, x0, #0x978
1004c43ac:	mov	w1, #0x18
1004c43b0:	mov	w2, #0x7
1004c43b4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c43b8:	mov	x25, x0
1004c43bc:	ldr	x19, [sp, #0x30]
1004c43c0:	add	x0, x19, #0x10
1004c43c4:	add	x1, sp, #0x40
1004c43c8:	mov	x2, #0x0
1004c43cc:	mov	x3, #0x0
1004c43d0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c43d4:	add	x0, x19, #0x10
1004c43d8:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c43dc:	mov	x21, x0
1004c43e0:	add	x0, x25, #0x10
1004c43e4:	mov	x1, x21
1004c43e8:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c43ec:	mov	x0, x21
1004c43f0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c43f4:	adrp	x0, 7448 ; 0x1021dc000
1004c43f8:	add	x0, x0, #0x480
1004c43fc:	mov	w1, #0x59
1004c4400:	mov	w2, #0x7
1004c4404:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4408:	mov	x21, x0
1004c440c:	stp	x25, x22, [x0, #0x10]
1004c4410:	ldp	q0, q1, [x20, #0x20]
1004c4414:	stp	q0, q1, [x0, #0x20]
1004c4418:	ldur	q0, [x20, #0x40]
1004c441c:	str	q0, [x0, #0x40]
1004c4420:	ldur	q0, [x20, #0x49]
1004c4424:	stur	q0, [x0, #0x49]
1004c4428:	adrp	x0, 7448 ; 0x1021dc000
1004c442c:	add	x0, x0, #0x4a8
1004c4430:	mov	w1, #0x20
1004c4434:	mov	w2, #0x7
1004c4438:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c443c:	mov	x24, x0
1004c4440:	adrp	x8, 2 ; 0x1004c6000
1004c4444:	add	x8, x8, #0xd28
1004c4448:	stp	x8, x21, [x0, #0x10]
1004c444c:	mov	x0, x22
1004c4450:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4454:	add	x0, x20, #0x20
1004c4458:	sub	x1, x29, #0xb0
1004c445c:	bl	0x1004c6644
1004c4460:	ldp	x19, x21, [x26, #0x10]
1004c4464:	add	x23, x19, #0x1
1004c4468:	mov	x0, x25
1004c446c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4470:	cmp	x19, x21, lsr #1
1004c4474:	b.hs	0x1004c547c
1004c4478:	adrp	x8, 6421 ; 0x101dd9000
1004c447c:	add	x8, x8, #0x640 ; literal pool for: "View Session History"
1004c4480:	sub	x8, x8, #0x20
1004c4484:	orr	x8, x8, #0x8000000000000000
1004c4488:	str	x23, [x26, #0x10]
1004c448c:	mov	w9, #0x38
1004c4490:	madd	x9, x19, x9, x26
1004c4494:	mov	x10, #0x10
1004c4498:	movk	x10, #0xd000, lsl #48
1004c449c:	add	x10, x10, #0x4
1004c44a0:	stp	x10, x8, [x9, #0x20]
1004c44a4:	stp	xzr, xzr, [x9, #0x30]
1004c44a8:	adrp	x8, -1216 ; 0x100004000
1004c44ac:	add	x8, x8, #0xcc
1004c44b0:	stp	xzr, x8, [x9, #0x40]
1004c44b4:	str	x24, [x9, #0x50]
1004c44b8:	mov	x0, x25
1004c44bc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c44c0:	mov	x0, x28
1004c44c4:	bl	0x1005d7ab0
1004c44c8:	tbz	w0, #0x0, 0x1004c45e8
1004c44cc:	mov	x0, x28
1004c44d0:	bl	0x1005cb140
1004c44d4:	ands	w23, w0, #0x1
1004c44d8:	mov	x8, #0x6853
1004c44dc:	movk	x8, #0x776f, lsl #16
1004c44e0:	movk	x8, #0x5020, lsl #32
1004c44e4:	movk	x8, #0x616c, lsl #48
1004c44e8:	mov	x9, #0x6948
1004c44ec:	movk	x9, #0x6564, lsl #16
1004c44f0:	movk	x9, #0x5020, lsl #32
1004c44f4:	movk	x9, #0x616c, lsl #48
1004c44f8:	csel	x19, x9, x8, ne
1004c44fc:	adrp	x0, 7446 ; 0x1021da000
1004c4500:	add	x0, x0, #0x978
1004c4504:	mov	w1, #0x18
1004c4508:	mov	w2, #0x7
1004c450c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4510:	mov	x27, x0
1004c4514:	ldr	x21, [sp, #0x30]
1004c4518:	add	x0, x21, #0x10
1004c451c:	add	x1, sp, #0x58
1004c4520:	mov	x2, #0x0
1004c4524:	mov	x3, #0x0
1004c4528:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c452c:	add	x0, x21, #0x10
1004c4530:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c4534:	mov	x21, x0
1004c4538:	add	x0, x27, #0x10
1004c453c:	mov	x1, x21
1004c4540:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c4544:	mov	x0, x21
1004c4548:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c454c:	adrp	x0, 7448 ; 0x1021dc000
1004c4550:	add	x0, x0, #0x430
1004c4554:	mov	w1, #0x1a
1004c4558:	mov	w2, #0x7
1004c455c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4560:	mov	x21, x0
1004c4564:	str	x27, [x0, #0x10]
1004c4568:	strb	w23, [x0, #0x18]
1004c456c:	strb	w28, [x0, #0x19]
1004c4570:	adrp	x0, 7448 ; 0x1021dc000
1004c4574:	add	x0, x0, #0x458
1004c4578:	mov	w1, #0x20
1004c457c:	mov	w2, #0x7
1004c4580:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4584:	mov	x23, x0
1004c4588:	adrp	x8, 2 ; 0x1004c6000
1004c458c:	add	x8, x8, #0xc5c
1004c4590:	stp	x8, x21, [x0, #0x10]
1004c4594:	ldp	x24, x25, [x26, #0x10]
1004c4598:	add	x21, x24, #0x1
1004c459c:	mov	x0, x27
1004c45a0:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c45a4:	cmp	x24, x25, lsr #1
1004c45a8:	b.hs	0x1004c54a4
1004c45ac:	str	x21, [x26, #0x10]
1004c45b0:	mov	w8, #0x38
1004c45b4:	madd	x8, x24, x8, x26
1004c45b8:	mov	x9, #0x206e
1004c45bc:	movk	x9, #0x7551, lsl #16
1004c45c0:	movk	x9, #0x746f, lsl #32
1004c45c4:	movk	x9, #0xef61, lsl #48
1004c45c8:	stp	x19, x9, [x8, #0x20]
1004c45cc:	stp	xzr, xzr, [x8, #0x30]
1004c45d0:	adrp	x9, -1216 ; 0x100004000
1004c45d4:	add	x9, x9, #0xcc
1004c45d8:	stp	xzr, x9, [x8, #0x40]
1004c45dc:	str	x23, [x8, #0x50]
1004c45e0:	mov	x0, x27
1004c45e4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c45e8:	ldp	x19, x8, [x26, #0x10]
1004c45ec:	add	x21, x19, #0x1
1004c45f0:	cmp	x19, x8, lsr #1
1004c45f4:	stp	x20, x22, [sp, #0x20]
1004c45f8:	b.hs	0x1004c5404
1004c45fc:	mov	w10, #0x2d2d
1004c4600:	movk	w10, #0x2d, lsl #16
1004c4604:	str	x21, [x26, #0x10]
1004c4608:	mov	w8, #0x38
1004c460c:	madd	x8, x19, x8, x26
1004c4610:	mov	x9, #-0x1d00000000000000
1004c4614:	stp	x10, x9, [x8, #0x20]
1004c4618:	stp	xzr, xzr, [x8, #0x30]
1004c461c:	adrp	x9, -1217 ; 0x100003000
1004c4620:	add	x9, x9, #0xf40
1004c4624:	stp	xzr, x9, [x8, #0x40]
1004c4628:	str	xzr, [x8, #0x50]
1004c462c:	str	w28, [sp, #0x1c]
1004c4630:	mov	x0, x28
1004c4634:	bl	0x1004f33d0
1004c4638:	stp	x1, x0, [sp, #0x8]
1004c463c:	ldr	x8, [sp, #0x30]
1004c4640:	add	x0, x8, #0x10
1004c4644:	sub	x1, x29, #0xc8
1004c4648:	mov	x2, #0x0
1004c464c:	mov	x3, #0x0
1004c4650:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c4654:	mov	w8, #0x0
1004c4658:	mov	x9, #0x0
1004c465c:	mov	x25, x26
1004c4660:	str	w8, [sp, #0x38]
1004c4664:	adrp	x8, 7825 ; 0x102355000
1004c4668:	add	x8, x8, #0x550
1004c466c:	add	x8, x8, x9
1004c4670:	ldp	x21, x23, [x8, #0x28]
1004c4674:	ldrb	w26, [x8, #0x38]
1004c4678:	ldrb	w19, [x8, #0x39]
1004c467c:	ldp	x0, x8, [sp, #0x8]
1004c4680:	stp	x8, x0, [x29, #-0xb0]
1004c4684:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c4688:	sub	x20, x29, #0xb0
1004c468c:	mov	w0, #0x6920
1004c4690:	movk	w0, #0x206e, lsl #16
1004c4694:	mov	x1, #-0x1c00000000000000
1004c4698:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004c469c:	mov	x0, x21
1004c46a0:	mov	x1, x23
1004c46a4:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004c46a8:	ldp	x27, x28, [x29, #-0xb0]
1004c46ac:	adrp	x0, 7446 ; 0x1021da000
1004c46b0:	add	x0, x0, #0x978
1004c46b4:	mov	w1, #0x18
1004c46b8:	mov	w2, #0x7
1004c46bc:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c46c0:	mov	x20, x0
1004c46c4:	ldr	x8, [sp, #0x30]
1004c46c8:	add	x0, x8, #0x10
1004c46cc:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c46d0:	mov	x21, x0
1004c46d4:	add	x0, x20, #0x10
1004c46d8:	mov	x1, x21
1004c46dc:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c46e0:	mov	x0, x21
1004c46e4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c46e8:	ldr	x24, [sp, #0x20]
1004c46ec:	add	x0, x24, #0x60
1004c46f0:	add	x1, sp, #0xe0
1004c46f4:	bl	0x10011aaac
1004c46f8:	adrp	x0, 7448 ; 0x1021dc000
1004c46fc:	add	x0, x0, #0xe8
1004c4700:	mov	w1, #0x8b
1004c4704:	mov	w2, #0x7
1004c4708:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c470c:	mov	x21, x0
1004c4710:	ldr	x22, [sp, #0x28]
1004c4714:	stp	x20, x22, [x0, #0x10]
1004c4718:	ldp	q0, q1, [x24, #0x20]
1004c471c:	stp	q0, q1, [x0, #0x20]
1004c4720:	ldur	q0, [x24, #0x40]
1004c4724:	str	q0, [x0, #0x40]
1004c4728:	ldur	q0, [x24, #0x49]
1004c472c:	stur	q0, [x0, #0x49]
1004c4730:	add	x0, sp, #0xe0
1004c4734:	add	x1, x21, #0x60
1004c4738:	bl	0x10006d158
1004c473c:	strb	w26, [x21, #0x88]
1004c4740:	strb	w19, [x21, #0x89]
1004c4744:	ldr	w8, [sp, #0x1c]
1004c4748:	strb	w8, [x21, #0x8a]
1004c474c:	adrp	x0, 7448 ; 0x1021dc000
1004c4750:	add	x0, x0, #0x110
1004c4754:	mov	w1, #0x20
1004c4758:	mov	w2, #0x7
1004c475c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4760:	mov	x23, x0
1004c4764:	adrp	x8, 2 ; 0x1004c6000
1004c4768:	add	x8, x8, #0x688
1004c476c:	stp	x8, x21, [x0, #0x10]
1004c4770:	mov	x0, x22
1004c4774:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4778:	add	x0, x24, #0x20
1004c477c:	sub	x1, x29, #0xb0
1004c4780:	bl	0x1004c6644
1004c4784:	ldp	x19, x26, [x25, #0x10]
1004c4788:	mov	x22, x25
1004c478c:	add	x21, x19, #0x1
1004c4790:	mov	x0, x20
1004c4794:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4798:	cmp	x19, x26, lsr #1
1004c479c:	b.hs	0x1004c47e4
1004c47a0:	mov	x25, x22
1004c47a4:	str	x21, [x22, #0x10]
1004c47a8:	mov	w8, #0x38
1004c47ac:	madd	x8, x19, x8, x22
1004c47b0:	stp	x27, x28, [x8, #0x20]
1004c47b4:	stp	xzr, xzr, [x8, #0x30]
1004c47b8:	adrp	x9, -1216 ; 0x100004000
1004c47bc:	add	x9, x9, #0xcc
1004c47c0:	stp	xzr, x9, [x8, #0x40]
1004c47c4:	str	x23, [x8, #0x50]
1004c47c8:	mov	x0, x20
1004c47cc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c47d0:	mov	w8, #0x1
1004c47d4:	mov	w9, #0x18
1004c47d8:	ldr	w10, [sp, #0x38]
1004c47dc:	tbz	w10, #0x0, 0x1004c4660
1004c47e0:	b	0x1004c480c
1004c47e4:	cmp	x26, #0x1
1004c47e8:	cset	w0, hi
1004c47ec:	mov	x1, x21
1004c47f0:	mov	w2, #0x1
1004c47f4:	mov	x3, x22
1004c47f8:	adrp	x4, 7691 ; 0x1022cf000
1004c47fc:	ldr	x4, [x4, #0x528] ; literal pool symbol address: _swift_bridgeObjectRelease
1004c4800:	bl	0x1004bfb6c
1004c4804:	mov	x22, x0
1004c4808:	b	0x1004c47a0
1004c480c:	mov	x26, #0x6920
1004c4810:	movk	x26, #0x206e, lsl #16
1004c4814:	movk	x26, #0x654e, lsl #32
1004c4818:	movk	x26, #0x2077, lsl #48
1004c481c:	adrp	x0, 7825 ; 0x102355000
1004c4820:	add	x0, x0, #0x5a8
1004c4824:	adrp	x1, 5681 ; 0x101af5000
1004c4828:	add	x1, x1, #0xe78
1004c482c:	bl	0x100003c4c
1004c4830:	mov	x2, x0
1004c4834:	adrp	x0, 7825 ; 0x102355000
1004c4838:	add	x0, x0, #0x578
1004c483c:	mov	w1, #0x2
1004c4840:	bl	0x101aca5ac ; symbol stub for: _swift_arrayDestroy
1004c4844:	ldp	x0, x8, [sp, #0x8]
1004c4848:	stp	x8, x0, [x29, #-0xb0]
1004c484c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004c4850:	mov	x1, #0x6154
1004c4854:	movk	x1, #0x62, lsl #16
1004c4858:	movk	x1, #0xeb00, lsl #48
1004c485c:	sub	x20, x29, #0xb0
1004c4860:	mov	x0, x26
1004c4864:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004c4868:	ldp	x19, x23, [x29, #-0xb0]
1004c486c:	adrp	x0, 7446 ; 0x1021da000
1004c4870:	add	x0, x0, #0x978
1004c4874:	mov	w1, #0x18
1004c4878:	mov	w2, #0x7
1004c487c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4880:	mov	x20, x0
1004c4884:	ldr	x21, [sp, #0x30]
1004c4888:	add	x0, x21, #0x10
1004c488c:	add	x1, sp, #0xc8
1004c4890:	mov	x2, #0x0
1004c4894:	mov	x3, #0x0
1004c4898:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c489c:	add	x0, x21, #0x10
1004c48a0:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c48a4:	mov	x21, x0
1004c48a8:	add	x0, x20, #0x10
1004c48ac:	mov	x1, x21
1004c48b0:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c48b4:	mov	x0, x21
1004c48b8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c48bc:	ldr	x28, [sp, #0x20]
1004c48c0:	add	x0, x28, #0x60
1004c48c4:	add	x1, sp, #0xe0
1004c48c8:	bl	0x10011aaac
1004c48cc:	adrp	x0, 7448 ; 0x1021dc000
1004c48d0:	add	x0, x0, #0x138
1004c48d4:	mov	w1, #0x89
1004c48d8:	mov	w2, #0x7
1004c48dc:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c48e0:	mov	x21, x0
1004c48e4:	ldr	x24, [sp, #0x28]
1004c48e8:	stp	x20, x24, [x0, #0x10]
1004c48ec:	ldp	q0, q1, [x28, #0x20]
1004c48f0:	stp	q0, q1, [x0, #0x20]
1004c48f4:	ldur	q0, [x28, #0x40]
1004c48f8:	str	q0, [x0, #0x40]
1004c48fc:	ldur	q0, [x28, #0x49]
1004c4900:	stur	q0, [x0, #0x49]
1004c4904:	add	x0, sp, #0xe0
1004c4908:	add	x1, x21, #0x60
1004c490c:	bl	0x10006d158
1004c4910:	ldr	w8, [sp, #0x1c]
1004c4914:	strb	w8, [x21, #0x88]
1004c4918:	adrp	x0, 7448 ; 0x1021dc000
1004c491c:	add	x0, x0, #0x160
1004c4920:	mov	w1, #0x20
1004c4924:	mov	w2, #0x7
1004c4928:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c492c:	mov	x27, x0
1004c4930:	adrp	x8, 2 ; 0x1004c6000
1004c4934:	add	x8, x8, #0x8a4
1004c4938:	stp	x8, x21, [x0, #0x10]
1004c493c:	mov	x0, x24
1004c4940:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4944:	add	x0, x28, #0x20
1004c4948:	sub	x1, x29, #0xb0
1004c494c:	bl	0x1004c6644
1004c4950:	ldp	x24, x28, [x25, #0x10]
1004c4954:	add	x21, x24, #0x1
1004c4958:	mov	x0, x20
1004c495c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4960:	cmp	x24, x28, lsr #1
1004c4964:	b.hs	0x1004c542c
1004c4968:	mov	x28, x22
1004c496c:	str	x21, [x28, #0x10]
1004c4970:	mov	w8, #0x38
1004c4974:	madd	x8, x24, x8, x28
1004c4978:	stp	x19, x23, [x8, #0x20]
1004c497c:	stp	xzr, xzr, [x8, #0x30]
1004c4980:	adrp	x9, -1216 ; 0x100004000
1004c4984:	add	x9, x9, #0xcc
1004c4988:	stp	xzr, x9, [x8, #0x40]
1004c498c:	str	x27, [x8, #0x50]
1004c4990:	mov	x0, x20
1004c4994:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c4998:	mov	x8, #-0x2000000000000000
1004c499c:	stp	xzr, x8, [x29, #-0xb0]
1004c49a0:	sub	x20, x29, #0xb0
1004c49a4:	mov	w0, #0x10
1004c49a8:	bl	0x101ac757c ; symbol stub for: _$ss11_StringGutsV4growyySiF
1004c49ac:	ldur	x0, [x29, #-0xa8]
1004c49b0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004c49b4:	ldp	x8, x9, [sp, #0x8]
1004c49b8:	stp	x9, x8, [x29, #-0xb0]
1004c49bc:	mov	x1, #0x6957
1004c49c0:	movk	x1, #0x646e, lsl #16
1004c49c4:	movk	x1, #0x776f, lsl #32
1004c49c8:	movk	x1, #0xee00, lsl #48
1004c49cc:	mov	x0, x26
1004c49d0:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004c49d4:	ldp	x19, x24, [x29, #-0xb0]
1004c49d8:	adrp	x0, 7446 ; 0x1021da000
1004c49dc:	add	x0, x0, #0x978
1004c49e0:	mov	w1, #0x18
1004c49e4:	mov	w2, #0x7
1004c49e8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c49ec:	mov	x20, x0
1004c49f0:	ldr	x21, [sp, #0x30]
1004c49f4:	add	x0, x21, #0x10
1004c49f8:	add	x1, sp, #0xb0
1004c49fc:	mov	x2, #0x0
1004c4a00:	mov	x3, #0x0
1004c4a04:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c4a08:	add	x0, x21, #0x10
1004c4a0c:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c4a10:	mov	x21, x0
1004c4a14:	add	x0, x20, #0x10
1004c4a18:	mov	x1, x21
1004c4a1c:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c4a20:	mov	x0, x21
1004c4a24:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c4a28:	ldr	x27, [sp, #0x20]
1004c4a2c:	add	x0, x27, #0x60
1004c4a30:	add	x1, sp, #0xe0
1004c4a34:	bl	0x10011aaac
1004c4a38:	adrp	x0, 7448 ; 0x1021dc000
1004c4a3c:	add	x0, x0, #0x188
1004c4a40:	mov	w1, #0x89
1004c4a44:	mov	w2, #0x7
1004c4a48:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4a4c:	mov	x21, x0
1004c4a50:	ldr	x22, [sp, #0x28]
1004c4a54:	stp	x20, x22, [x0, #0x10]
1004c4a58:	ldp	q0, q1, [x27, #0x20]
1004c4a5c:	stp	q0, q1, [x0, #0x20]
1004c4a60:	ldur	q0, [x27, #0x40]
1004c4a64:	str	q0, [x0, #0x40]
1004c4a68:	ldur	q0, [x27, #0x49]
1004c4a6c:	stur	q0, [x0, #0x49]
1004c4a70:	add	x0, sp, #0xe0
1004c4a74:	add	x1, x21, #0x60
1004c4a78:	bl	0x10006d158
1004c4a7c:	ldr	w8, [sp, #0x1c]
1004c4a80:	strb	w8, [x21, #0x88]
1004c4a84:	adrp	x0, 7448 ; 0x1021dc000
1004c4a88:	add	x0, x0, #0x1b0
1004c4a8c:	mov	w1, #0x20
1004c4a90:	mov	w2, #0x7
1004c4a94:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4a98:	mov	x23, x0
1004c4a9c:	adrp	x8, 2 ; 0x1004c6000
1004c4aa0:	add	x8, x8, #0x8b0
1004c4aa4:	stp	x8, x21, [x0, #0x10]
1004c4aa8:	mov	x0, x22
1004c4aac:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4ab0:	add	x0, x27, #0x20
1004c4ab4:	sub	x1, x29, #0xb0
1004c4ab8:	bl	0x1004c6644
1004c4abc:	ldp	x25, x26, [x28, #0x10]
1004c4ac0:	add	x21, x25, #0x1
1004c4ac4:	mov	x0, x20
1004c4ac8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4acc:	cmp	x25, x26, lsr #1
1004c4ad0:	b.hs	0x1004c5454
1004c4ad4:	str	x21, [x28, #0x10]
1004c4ad8:	mov	w8, #0x38
1004c4adc:	madd	x8, x25, x8, x28
1004c4ae0:	stp	x19, x24, [x8, #0x20]
1004c4ae4:	stp	xzr, xzr, [x8, #0x30]
1004c4ae8:	adrp	x9, -1216 ; 0x100004000
1004c4aec:	add	x9, x9, #0xcc
1004c4af0:	stp	xzr, x9, [x8, #0x40]
1004c4af4:	str	x23, [x8, #0x50]
1004c4af8:	mov	x0, x20
1004c4afc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c4b00:	ldp	x20, x21, [x27, #0x90]
1004c4b04:	and	x8, x20, #0xffffffffffff
1004c4b08:	ubfx	x9, x21, #56, #4
1004c4b0c:	tst	x21, #0x2000000000000000
1004c4b10:	csel	x8, x8, x9, eq
1004c4b14:	cbz	x8, 0x1004c4e60
1004c4b18:	ldp	x23, x24, [x27, #0x78]
1004c4b1c:	add	x0, x27, #0x60
1004c4b20:	mov	x1, x23
1004c4b24:	bl	0x10002d8b0
1004c4b28:	mov	x4, x0
1004c4b2c:	ldp	x2, x3, [x27, #0xa0]
1004c4b30:	ldr	x9, [x24, #0x58]
1004c4b34:	add	x8, sp, #0xe0
1004c4b38:	mov	x0, x20
1004c4b3c:	mov	x1, x21
1004c4b40:	mov	x20, x4
1004c4b44:	mov	x4, x23
1004c4b48:	mov	x5, x24
1004c4b4c:	blr	x9
1004c4b50:	ldrb	w8, [sp, #0x100]
1004c4b54:	cmp	w8, #0xff
1004c4b58:	b.eq	0x1004c4e60
1004c4b5c:	ldp	q0, q1, [sp, #0xe0]
1004c4b60:	stp	q0, q1, [x29, #-0xb0]
1004c4b64:	sturb	w8, [x29, #-0x90]
1004c4b68:	sub	x20, x29, #0xb0
1004c4b6c:	bl	0x1004f4360
1004c4b70:	mov	x21, x0
1004c4b74:	adrp	x0, 7446 ; 0x1021da000
1004c4b78:	add	x0, x0, #0x978
1004c4b7c:	mov	w1, #0x18
1004c4b80:	mov	w2, #0x7
1004c4b84:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4b88:	mov	x20, x0
1004c4b8c:	tbz	w21, #0x0, 0x1004c4c54
1004c4b90:	ldr	x19, [sp, #0x30]
1004c4b94:	add	x0, x19, #0x10
1004c4b98:	add	x1, sp, #0x70
1004c4b9c:	mov	x2, #0x0
1004c4ba0:	mov	x3, #0x0
1004c4ba4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c4ba8:	add	x0, x19, #0x10
1004c4bac:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c4bb0:	mov	x21, x0
1004c4bb4:	add	x0, x20, #0x10
1004c4bb8:	mov	x1, x21
1004c4bbc:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c4bc0:	mov	x0, x21
1004c4bc4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c4bc8:	adrp	x0, 7448 ; 0x1021dc000
1004c4bcc:	add	x0, x0, #0x3e0
1004c4bd0:	mov	w1, #0x39
1004c4bd4:	mov	w2, #0x7
1004c4bd8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4bdc:	mov	x21, x0
1004c4be0:	str	x20, [x0, #0x10]
1004c4be4:	ldp	q0, q1, [x29, #-0xb0]
1004c4be8:	stur	q0, [x0, #0x18]
1004c4bec:	stur	q1, [x0, #0x28]
1004c4bf0:	ldurb	w8, [x29, #-0x90]
1004c4bf4:	strb	w8, [x0, #0x38]
1004c4bf8:	adrp	x0, 7448 ; 0x1021dc000
1004c4bfc:	add	x0, x0, #0x408
1004c4c00:	mov	w1, #0x20
1004c4c04:	mov	w2, #0x7
1004c4c08:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4c0c:	mov	x22, x0
1004c4c10:	adrp	x8, 2 ; 0x1004c6000
1004c4c14:	add	x8, x8, #0xba8
1004c4c18:	stp	x8, x21, [x0, #0x10]
1004c4c1c:	ldp	x19, x24, [x28, #0x10]
1004c4c20:	add	x23, x19, #0x1
1004c4c24:	mov	x0, x20
1004c4c28:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4c2c:	adrp	x8, 6421 ; 0x101dd9000
1004c4c30:	add	x8, x8, #0x620 ; literal pool for: "Open Remote Plan"
1004c4c34:	sub	x21, x8, #0x20
1004c4c38:	cmp	x19, x24, lsr #1
1004c4c3c:	b.hs	0x1004c55e4
1004c4c40:	adrp	x8, -1216 ; 0x100004000
1004c4c44:	add	x8, x8, #0xcc
1004c4c48:	mov	x24, #0x10
1004c4c4c:	movk	x24, #0xd000, lsl #48
1004c4c50:	b	0x1004c4e34
1004c4c54:	ldr	x19, [sp, #0x30]
1004c4c58:	add	x0, x19, #0x10
1004c4c5c:	add	x1, sp, #0x98
1004c4c60:	mov	x2, #0x0
1004c4c64:	mov	x3, #0x0
1004c4c68:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c4c6c:	add	x0, x19, #0x10
1004c4c70:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c4c74:	mov	x21, x0
1004c4c78:	add	x0, x20, #0x10
1004c4c7c:	mov	x1, x21
1004c4c80:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c4c84:	mov	x0, x21
1004c4c88:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c4c8c:	adrp	x0, 7448 ; 0x1021dc000
1004c4c90:	add	x0, x0, #0x340
1004c4c94:	mov	w1, #0x39
1004c4c98:	mov	w2, #0x7
1004c4c9c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4ca0:	mov	x21, x0
1004c4ca4:	str	x20, [x0, #0x10]
1004c4ca8:	ldp	q0, q1, [x29, #-0xb0]
1004c4cac:	stur	q0, [x0, #0x18]
1004c4cb0:	stur	q1, [x0, #0x28]
1004c4cb4:	ldurb	w8, [x29, #-0x90]
1004c4cb8:	strb	w8, [x0, #0x38]
1004c4cbc:	adrp	x0, 7448 ; 0x1021dc000
1004c4cc0:	add	x0, x0, #0x368
1004c4cc4:	mov	w1, #0x20
1004c4cc8:	mov	w2, #0x7
1004c4ccc:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4cd0:	mov	x22, x0
1004c4cd4:	adrp	x8, 4 ; 0x1004c8000
1004c4cd8:	add	x8, x8, #0x8e8
1004c4cdc:	stp	x8, x21, [x0, #0x10]
1004c4ce0:	mov	x0, x20
1004c4ce4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4ce8:	adrp	x2, 7804 ; 0x102340000
1004c4cec:	add	x2, x2, #0xc60
1004c4cf0:	adrp	x3, 5681 ; 0x101af5000
1004c4cf4:	add	x3, x3, #0xe80
1004c4cf8:	add	x0, sp, #0xe0
1004c4cfc:	add	x1, sp, #0x70
1004c4d00:	bl	0x10002d8f4
1004c4d04:	ldp	x19, x8, [x28, #0x10]
1004c4d08:	add	x21, x19, #0x1
1004c4d0c:	cmp	x19, x8, lsr #1
1004c4d10:	b.hs	0x1004c560c
1004c4d14:	str	x21, [x28, #0x10]
1004c4d18:	mov	w8, #0x38
1004c4d1c:	madd	x8, x19, x8, x28
1004c4d20:	mov	x9, #0x704f
1004c4d24:	movk	x9, #0x6e65, lsl #16
1004c4d28:	movk	x9, #0x5020, lsl #32
1004c4d2c:	movk	x9, #0x616c, lsl #48
1004c4d30:	mov	x10, #0x6e
1004c4d34:	movk	x10, #0xe900, lsl #48
1004c4d38:	stp	x9, x10, [x8, #0x20]
1004c4d3c:	stp	xzr, xzr, [x8, #0x30]
1004c4d40:	adrp	x9, -1216 ; 0x100004000
1004c4d44:	add	x9, x9, #0xcc
1004c4d48:	stp	xzr, x9, [x8, #0x40]
1004c4d4c:	str	x22, [x8, #0x50]
1004c4d50:	mov	x0, x20
1004c4d54:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c4d58:	adrp	x0, 7446 ; 0x1021da000
1004c4d5c:	add	x0, x0, #0x978
1004c4d60:	mov	w1, #0x18
1004c4d64:	mov	w2, #0x7
1004c4d68:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4d6c:	mov	x20, x0
1004c4d70:	ldr	x19, [sp, #0x30]
1004c4d74:	add	x0, x19, #0x10
1004c4d78:	add	x1, sp, #0x70
1004c4d7c:	mov	x2, #0x0
1004c4d80:	mov	x3, #0x0
1004c4d84:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004c4d88:	add	x0, x19, #0x10
1004c4d8c:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004c4d90:	mov	x21, x0
1004c4d94:	add	x0, x20, #0x10
1004c4d98:	mov	x1, x21
1004c4d9c:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004c4da0:	mov	x0, x21
1004c4da4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004c4da8:	adrp	x0, 7448 ; 0x1021dc000
1004c4dac:	add	x0, x0, #0x390
1004c4db0:	mov	w1, #0x39
1004c4db4:	mov	w2, #0x7
1004c4db8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4dbc:	mov	x21, x0
1004c4dc0:	str	x20, [x0, #0x10]
1004c4dc4:	ldp	q0, q1, [x29, #-0xb0]
1004c4dc8:	stur	q0, [x0, #0x18]
1004c4dcc:	stur	q1, [x0, #0x28]
1004c4dd0:	ldurb	w8, [x29, #-0x90]
1004c4dd4:	strb	w8, [x0, #0x38]
1004c4dd8:	adrp	x0, 7448 ; 0x1021dc000
1004c4ddc:	add	x0, x0, #0x3b8
1004c4de0:	mov	w1, #0x20
1004c4de4:	mov	w2, #0x7
1004c4de8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4dec:	mov	x22, x0
1004c4df0:	adrp	x8, 2 ; 0x1004c6000
1004c4df4:	add	x8, x8, #0xb68
1004c4df8:	stp	x8, x21, [x0, #0x10]
1004c4dfc:	ldp	x19, x25, [x28, #0x10]
1004c4e00:	add	x23, x19, #0x1
1004c4e04:	mov	x0, x20
1004c4e08:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4e0c:	adrp	x8, 6421 ; 0x101dd9000
1004c4e10:	add	x8, x8, #0x600 ; literal pool for: "Reveal Plan in Finder"
1004c4e14:	sub	x21, x8, #0x20
1004c4e18:	mov	x8, #0x10
1004c4e1c:	movk	x8, #0xd000, lsl #48
1004c4e20:	add	x24, x8, #0x5
1004c4e24:	cmp	x19, x25, lsr #1
1004c4e28:	b.hs	0x1004c5634
1004c4e2c:	adrp	x8, -1216 ; 0x100004000
1004c4e30:	add	x8, x8, #0xcc
1004c4e34:	orr	x9, x21, #0x8000000000000000
1004c4e38:	str	x23, [x28, #0x10]
1004c4e3c:	mov	w10, #0x38
1004c4e40:	madd	x10, x19, x10, x28
1004c4e44:	stp	x24, x9, [x10, #0x20]
1004c4e48:	stp	xzr, xzr, [x10, #0x30]
1004c4e4c:	stp	xzr, x8, [x10, #0x40]
1004c4e50:	str	x22, [x10, #0x50]
1004c4e54:	mov	x0, x20
1004c4e58:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c4e5c:	ldr	x22, [sp, #0x28]
1004c4e60:	cbz	x22, 0x1004c53b8
1004c4e64:	ldr	x8, [x22]
1004c4e68:	ldr	x8, [x8, #0x260]
1004c4e6c:	mov	x20, x22
1004c4e70:	blr	x8
1004c4e74:	cbz	x0, 0x1004c53b8
1004c4e78:	mov	x21, x0
1004c4e7c:	ldr	x8, [x0]
1004c4e80:	ldr	x8, [x8, #0x370]
1004c4e84:	mov	x20, x0
1004c4e88:	blr	x8
1004c4e8c:	mov	x20, x0
1004c4e90:	ldp	x19, x8, [x28, #0x10]
1004c4e94:	add	x22, x19, #0x1
1004c4e98:	cmp	x19, x8, lsr #1
1004c4e9c:	b.hs	0x1004c54cc
1004c4ea0:	mov	w23, #0x9ce2
1004c4ea4:	movk	w23, #0x93, lsl #16
1004c4ea8:	str	x22, [x28, #0x10]
1004c4eac:	mov	w8, #0x38
1004c4eb0:	madd	x8, x19, x8, x28
1004c4eb4:	mov	x9, #-0x1d00000000000000
1004c4eb8:	mov	w10, #0x2d2d
1004c4ebc:	movk	w10, #0x2d, lsl #16
1004c4ec0:	stp	x10, x9, [x8, #0x20]
1004c4ec4:	adrp	x9, -1217 ; 0x100003000
1004c4ec8:	add	x9, x9, #0xf40
1004c4ecc:	stp	xzr, xzr, [x8, #0x30]
1004c4ed0:	stp	xzr, x9, [x8, #0x40]
1004c4ed4:	str	xzr, [x8, #0x50]
1004c4ed8:	ldr	x8, [x20]
1004c4edc:	ldr	x8, [x8, #0x1a8]
1004c4ee0:	blr	x8
1004c4ee4:	tst	w0, #0x1
1004c4ee8:	csel	x26, x23, xzr, ne
1004c4eec:	mov	x8, #-0x5d00000000000000
1004c4ef0:	csel	x27, x8, xzr, ne
1004c4ef4:	adrp	x0, 7447 ; 0x1021db000
1004c4ef8:	add	x0, x0, #0x1e8
1004c4efc:	mov	w1, #0x18
1004c4f00:	mov	w2, #0x7
1004c4f04:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4f08:	mov	x22, x0
1004c4f0c:	add	x0, x0, #0x10
1004c4f10:	mov	x1, x21
1004c4f14:	bl	0x101acab58 ; symbol stub for: _swift_weakInit
1004c4f18:	adrp	x0, 7448 ; 0x1021dc000
1004c4f1c:	add	x0, x0, #0x1d8
1004c4f20:	mov	w1, #0x20
1004c4f24:	mov	w2, #0x7
1004c4f28:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4f2c:	mov	x24, x0
1004c4f30:	stp	x20, x22, [x0, #0x10]
1004c4f34:	adrp	x0, 7448 ; 0x1021dc000
1004c4f38:	add	x0, x0, #0x200
1004c4f3c:	mov	w1, #0x20
1004c4f40:	mov	w2, #0x7
1004c4f44:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004c4f48:	mov	x23, x0
1004c4f4c:	adrp	x8, 2 ; 0x1004c6000
1004c4f50:	add	x8, x8, #0xa70
1004c4f54:	stp	x8, x24, [x0, #0x10]
1004c4f58:	mov	x8, x28
1004c4f5c:	ldr	x28, [x28, #0x10]
1004c4f60:	mov	x19, x8
1004c4f64:	ldr	x25, [x8, #0x18]
1004c4f68:	add	x24, x28, #0x1
1004c4f6c:	mov	x0, x21
1004c4f70:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4f74:	mov	x0, x20
1004c4f78:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4f7c:	mov	x0, x22
1004c4f80:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004c4f84:	cmp	x28, x25, lsr #1
1004c4f88:	b.hs	0x1004c54f4
1004c4f8c:	adrp	x8, 6421 ; 0x101dd9000
1004c4f90:	add	x8, x8, #0x560 ; literal pool for: "Badge While Processing"
1004c4f94:	sub	x8, x8, #0x20
1004c4f98:	orr	x8, x8, #0x8000000000000000
1004c4f9c:	str	x24, [x19, #0x10]
1004c4fa0:	mov	w9, #0x38
1004c4fa4:	madd	x9, x28, x9, x19
1004c4fa8:	mov	x28, x19
1004c4fac:	mov	x10, #0x10
1004c4fb0:	movk	x10, #0xd000, lsl #48
1004c4fb4:	add	x10, x10, #0x6
1004c4fb8:	stp	x10, x8, [x9, #0x20]
1004c4fbc:	stp	x26, x27, [x9, #0x30]
1004c4fc0:	adrp	x8, -1216 ; 0x100004000
1004c4fc4:	add	x8, x8, #0xcc
1004c4fc8:	stp	xzr, x8, [x9, #0x40]
1004c4fcc:	str	x23, [x9, #0x50]
1004c4fd0:	mov	x0, x22
1004c4fd4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004c4fd8:	ldr	x8, [x20]
1004c4fdc:	ldr	x8, [x8, #0x1c0]
1004c4fe0:	blr	x8
1004c4fe4:	tst	w0, #0x1
1004c4fe8:	mov	w8, #0x9ce2
1004c4fec:	movk	w8, #0x93, lsl #16
1004c4ff0:	csel	x26, x8, xzr, ne
1004c4ff4:	mov	x8, #-0x5d00000000000000
1004c4ff8:	csel	x27, x8, xzr, ne
1004c4ffc:	adrp	x0, 7447 ; 0x1021db000
