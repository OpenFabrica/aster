
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001008da4f0 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E>:
1008e5b18: d10283ff    	sub	sp, sp, #0xa0
1008e5b1c: a9046ffc    	stp	x28, x27, [sp, #0x40]
1008e5b20: a90567fa    	stp	x26, x25, [sp, #0x50]
1008e5b24: a9065ff8    	stp	x24, x23, [sp, #0x60]
1008e5b28: a90757f6    	stp	x22, x21, [sp, #0x70]
1008e5b2c: a9084ff4    	stp	x20, x19, [sp, #0x80]
1008e5b30: a9097bfd    	stp	x29, x30, [sp, #0x90]
1008e5b34: 910243fd    	add	x29, sp, #0x90
1008e5b38: aa0203f5    	mov	x21, x2
1008e5b3c: aa0103f4    	mov	x20, x1
1008e5b40: aa0003f6    	mov	x22, x0
1008e5b44: 9406e2eb    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1008e5b48: 52801000    	mov	w0, #0x80               ; =128
1008e5b4c: 52800021    	mov	w1, #0x1                ; =1
1008e5b50: 9406e2e2    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1008e5b54: b4002080    	cbz	x0, 0x1008e5f64 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xba74>
1008e5b58: 52801008    	mov	w8, #0x80               ; =128
1008e5b5c: a90103e8    	stp	x8, x0, [sp, #0x10]
1008e5b60: 910043e8    	add	x8, sp, #0x10
1008e5b64: f90017e8    	str	x8, [sp, #0x28]
1008e5b68: 52800b68    	mov	w8, #0x5b               ; =91
1008e5b6c: 39000008    	strb	w8, [x0]
1008e5b70: 52800028    	mov	w8, #0x1                ; =1
1008e5b74: f90013e8    	str	x8, [sp, #0x20]
1008e5b78: b4001c75    	cbz	x21, 0x1008e5f04 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xba14>
1008e5b7c: f90007f6    	str	x22, [sp, #0x8]
1008e5b80: d2800016    	mov	x22, #0x0               ; =0
1008e5b84: 52800d08    	mov	w8, #0x68               ; =104
1008e5b88: 9b087eb5    	mul	x21, x21, x8
1008e5b8c: 52800028    	mov	w8, #0x1                ; =1
1008e5b90: 52800757    	mov	w23, #0x3a              ; =58
1008e5b94: 52800598    	mov	w24, #0x2c              ; =44
1008e5b98: 52800059    	mov	w25, #0x2               ; =2
1008e5b9c: b000913a    	adrp	x26, 0x101b0a000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x3014>
1008e5ba0: 9118c35a    	add	x26, x26, #0x630
1008e5ba4: 1400000a    	b	0x1008e5bcc <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb6dc>
1008e5ba8: f9400668    	ldr	x8, [x19, #0x8]
1008e5bac: 52800fa9    	mov	w9, #0x7d               ; =125
1008e5bb0: 38216909    	strb	w9, [x8, x1]
1008e5bb4: 91000428    	add	x8, x1, #0x1
1008e5bb8: f9000a68    	str	x8, [x19, #0x10]
1008e5bbc: 52800008    	mov	w8, #0x0                ; =0
1008e5bc0: 9101a2d6    	add	x22, x22, #0x68
1008e5bc4: eb1602bf    	cmp	x21, x22
1008e5bc8: 54001860    	b.eq	0x1008e5ed4 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb9e4>
1008e5bcc: f94017e0    	ldr	x0, [sp, #0x28]
1008e5bd0: 37000148    	tbnz	w8, #0x0, 0x1008e5bf8 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb708>
1008e5bd4: f9400801    	ldr	x1, [x0, #0x10]
1008e5bd8: f9400008    	ldr	x8, [x0]
1008e5bdc: eb01011f    	cmp	x8, x1
1008e5be0: 540015a0    	b.eq	0x1008e5e94 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb9a4>
1008e5be4: f9400408    	ldr	x8, [x0, #0x8]
1008e5be8: 38216918    	strb	w24, [x8, x1]
1008e5bec: 91000428    	add	x8, x1, #0x1
1008e5bf0: f9000808    	str	x8, [x0, #0x10]
1008e5bf4: f94017e0    	ldr	x0, [sp, #0x28]
1008e5bf8: f9400801    	ldr	x1, [x0, #0x10]
1008e5bfc: f9400008    	ldr	x8, [x0]
1008e5c00: eb01011f    	cmp	x8, x1
1008e5c04: 54001000    	b.eq	0x1008e5e04 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb914>
1008e5c08: f9400408    	ldr	x8, [x0, #0x8]
1008e5c0c: 52800f69    	mov	w9, #0x7b               ; =123
1008e5c10: 38216909    	strb	w9, [x8, x1]
1008e5c14: 91000428    	add	x8, x1, #0x1
1008e5c18: f9000808    	str	x8, [x0, #0x10]
1008e5c1c: 9100a3e8    	add	x8, sp, #0x28
1008e5c20: f9001be8    	str	x8, [sp, #0x30]
1008e5c24: 8b160288    	add	x8, x20, x22
1008e5c28: a940f11b    	ldp	x27, x28, [x8, #0x8]
1008e5c2c: b00091c1    	adrp	x1, 0x101b1e000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x17014>
1008e5c30: 910ef021    	add	x1, x1, #0x3bc
1008e5c34: 52800082    	mov	w2, #0x4                ; =4
1008e5c38: 97ffc7d9    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e5c3c: f94017f3    	ldr	x19, [sp, #0x28]
1008e5c40: f9400a61    	ldr	x1, [x19, #0x10]
1008e5c44: f9400268    	ldr	x8, [x19]
1008e5c48: eb01011f    	cmp	x8, x1
1008e5c4c: 54000ec0    	b.eq	0x1008e5e24 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb934>
1008e5c50: f9400668    	ldr	x8, [x19, #0x8]
1008e5c54: 38216917    	strb	w23, [x8, x1]
1008e5c58: 91000428    	add	x8, x1, #0x1
1008e5c5c: f9000a68    	str	x8, [x19, #0x10]
1008e5c60: f94017e0    	ldr	x0, [sp, #0x28]
1008e5c64: aa1b03e1    	mov	x1, x27
1008e5c68: aa1c03e2    	mov	x2, x28
1008e5c6c: 97ffc7cc    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e5c70: 8b160288    	add	x8, x20, x22
1008e5c74: a942711b    	ldp	x27, x28, [x8, #0x20]
1008e5c78: f94017f3    	ldr	x19, [sp, #0x28]
1008e5c7c: f9400a61    	ldr	x1, [x19, #0x10]
1008e5c80: f9400268    	ldr	x8, [x19]
1008e5c84: eb01011f    	cmp	x8, x1
1008e5c88: 54000dc0    	b.eq	0x1008e5e40 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb950>
1008e5c8c: f9400668    	ldr	x8, [x19, #0x8]
1008e5c90: 38216918    	strb	w24, [x8, x1]
1008e5c94: 91000428    	add	x8, x1, #0x1
1008e5c98: f9000a68    	str	x8, [x19, #0x10]
1008e5c9c: f94017e0    	ldr	x0, [sp, #0x28]
1008e5ca0: 3900e3f9    	strb	w25, [sp, #0x38]
1008e5ca4: b0009121    	adrp	x1, 0x101b0a000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x3014>
1008e5ca8: 91189021    	add	x1, x1, #0x624
1008e5cac: 52800182    	mov	w2, #0xc                ; =12
1008e5cb0: 97ffc7bb    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e5cb4: f94017f3    	ldr	x19, [sp, #0x28]
1008e5cb8: f9400a61    	ldr	x1, [x19, #0x10]
1008e5cbc: f9400268    	ldr	x8, [x19]
1008e5cc0: eb01011f    	cmp	x8, x1
1008e5cc4: 54000cc0    	b.eq	0x1008e5e5c <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb96c>
1008e5cc8: f9400668    	ldr	x8, [x19, #0x8]
1008e5ccc: 38216917    	strb	w23, [x8, x1]
1008e5cd0: 91000428    	add	x8, x1, #0x1
1008e5cd4: f9000a68    	str	x8, [x19, #0x10]
1008e5cd8: f94017e0    	ldr	x0, [sp, #0x28]
1008e5cdc: aa1b03e1    	mov	x1, x27
1008e5ce0: aa1c03e2    	mov	x2, x28
1008e5ce4: 97ffc7ae    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e5ce8: 8b160293    	add	x19, x20, x22
1008e5cec: 9100c3e0    	add	x0, sp, #0x30
1008e5cf0: 9100c263    	add	x3, x19, #0x30
1008e5cf4: 90009121    	adrp	x1, 0x101b09000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x2014>
1008e5cf8: 9137f421    	add	x1, x1, #0xdfd
1008e5cfc: 52800162    	mov	w2, #0xb                ; =11
1008e5d00: 9404dfb9    	bl	0x100a1dbe4 <__ZN8otty_ffi8run_link5route17he03dd72af65ce776E+0x36b34>
1008e5d04: 3941867b    	ldrb	w27, [x19, #0x61]
1008e5d08: f9401bfc    	ldr	x28, [sp, #0x30]
1008e5d0c: 3940e3e8    	ldrb	w8, [sp, #0x38]
1008e5d10: f9400380    	ldr	x0, [x28]
1008e5d14: 7100051f    	cmp	w8, #0x1
1008e5d18: 54000140    	b.eq	0x1008e5d40 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb850>
1008e5d1c: f9400801    	ldr	x1, [x0, #0x10]
1008e5d20: f9400008    	ldr	x8, [x0]
1008e5d24: eb01011f    	cmp	x8, x1
1008e5d28: 54000c60    	b.eq	0x1008e5eb4 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb9c4>
1008e5d2c: f9400408    	ldr	x8, [x0, #0x8]
1008e5d30: 38216918    	strb	w24, [x8, x1]
1008e5d34: 91000428    	add	x8, x1, #0x1
1008e5d38: f9000808    	str	x8, [x0, #0x10]
1008e5d3c: f9400380    	ldr	x0, [x28]
1008e5d40: 3900e3f9    	strb	w25, [sp, #0x38]
1008e5d44: b00091c1    	adrp	x1, 0x101b1e000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x17014>
1008e5d48: 910fe021    	add	x1, x1, #0x3f8
1008e5d4c: 52800082    	mov	w2, #0x4                ; =4
1008e5d50: 97ffc793    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e5d54: f9400393    	ldr	x19, [x28]
1008e5d58: f9400a61    	ldr	x1, [x19, #0x10]
1008e5d5c: f9400268    	ldr	x8, [x19]
1008e5d60: eb01011f    	cmp	x8, x1
1008e5d64: 540008a0    	b.eq	0x1008e5e78 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb988>
1008e5d68: f9400668    	ldr	x8, [x19, #0x8]
1008e5d6c: 38216917    	strb	w23, [x8, x1]
1008e5d70: 91000428    	add	x8, x1, #0x1
1008e5d74: f9000a68    	str	x8, [x19, #0x10]
1008e5d78: f9400380    	ldr	x0, [x28]
1008e5d7c: 9000c8e8    	adrp	x8, 0x102201000 <_$s4Otty16ModifierKeyEventON+0x8d50>
1008e5d80: 91134108    	add	x8, x8, #0x4d0
1008e5d84: f87b7901    	ldr	x1, [x8, x27, lsl #3]
1008e5d88: 900091c8    	adrp	x8, 0x101b1d000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x16014>
1008e5d8c: 91318108    	add	x8, x8, #0xc60
1008e5d90: f87b7902    	ldr	x2, [x8, x27, lsl #3]
1008e5d94: 97ffc782    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e5d98: 8b160293    	add	x19, x20, x22
1008e5d9c: 9100c3e0    	add	x0, sp, #0x30
1008e5da0: 91012263    	add	x3, x19, #0x48
1008e5da4: b00091c1    	adrp	x1, 0x101b1e000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x17014>
1008e5da8: 910fd021    	add	x1, x1, #0x3f4
1008e5dac: 52800082    	mov	w2, #0x4                ; =4
1008e5db0: 9404df8d    	bl	0x100a1dbe4 <__ZN8otty_ffi8run_link5route17he03dd72af65ce776E+0x36b34>
1008e5db4: 39418263    	ldrb	w3, [x19, #0x60]
1008e5db8: 9100c3e0    	add	x0, sp, #0x30
1008e5dbc: aa1a03e1    	mov	x1, x26
1008e5dc0: 52800182    	mov	w2, #0xc                ; =12
1008e5dc4: 9404e1a6    	bl	0x100a1e45c <__ZN8otty_ffi8run_link5route17he03dd72af65ce776E+0x373ac>
1008e5dc8: 3940e3e8    	ldrb	w8, [sp, #0x38]
1008e5dcc: 34ffef88    	cbz	w8, 0x1008e5bbc <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb6cc>
1008e5dd0: f9401be8    	ldr	x8, [sp, #0x30]
1008e5dd4: f9400113    	ldr	x19, [x8]
1008e5dd8: f9400a61    	ldr	x1, [x19, #0x10]
1008e5ddc: f9400268    	ldr	x8, [x19]
1008e5de0: eb01011f    	cmp	x8, x1
1008e5de4: 54ffee21    	b.ne	0x1008e5ba8 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb6b8>
1008e5de8: aa1303e0    	mov	x0, x19
1008e5dec: 52800022    	mov	w2, #0x1                ; =1
1008e5df0: 52800023    	mov	w3, #0x1                ; =1
1008e5df4: 52800024    	mov	w4, #0x1                ; =1
1008e5df8: 94450a96    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e5dfc: f9400a61    	ldr	x1, [x19, #0x10]
1008e5e00: 17ffff6a    	b	0x1008e5ba8 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb6b8>
1008e5e04: aa0003f3    	mov	x19, x0
1008e5e08: 52800022    	mov	w2, #0x1                ; =1
1008e5e0c: 52800023    	mov	w3, #0x1                ; =1
1008e5e10: 52800024    	mov	w4, #0x1                ; =1
1008e5e14: 94450a8f    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e5e18: aa1303e0    	mov	x0, x19
1008e5e1c: f9400a61    	ldr	x1, [x19, #0x10]
1008e5e20: 17ffff7a    	b	0x1008e5c08 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb718>
1008e5e24: aa1303e0    	mov	x0, x19
1008e5e28: 52800022    	mov	w2, #0x1                ; =1
1008e5e2c: 52800023    	mov	w3, #0x1                ; =1
1008e5e30: 52800024    	mov	w4, #0x1                ; =1
1008e5e34: 94450a87    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e5e38: f9400a61    	ldr	x1, [x19, #0x10]
1008e5e3c: 17ffff85    	b	0x1008e5c50 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb760>
1008e5e40: aa1303e0    	mov	x0, x19
1008e5e44: 52800022    	mov	w2, #0x1                ; =1
1008e5e48: 52800023    	mov	w3, #0x1                ; =1
1008e5e4c: 52800024    	mov	w4, #0x1                ; =1
1008e5e50: 94450a80    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e5e54: f9400a61    	ldr	x1, [x19, #0x10]
1008e5e58: 17ffff8d    	b	0x1008e5c8c <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb79c>
1008e5e5c: aa1303e0    	mov	x0, x19
1008e5e60: 52800022    	mov	w2, #0x1                ; =1
1008e5e64: 52800023    	mov	w3, #0x1                ; =1
1008e5e68: 52800024    	mov	w4, #0x1                ; =1
1008e5e6c: 94450a79    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e5e70: f9400a61    	ldr	x1, [x19, #0x10]
1008e5e74: 17ffff95    	b	0x1008e5cc8 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb7d8>
1008e5e78: aa1303e0    	mov	x0, x19
1008e5e7c: 52800022    	mov	w2, #0x1                ; =1
1008e5e80: 52800023    	mov	w3, #0x1                ; =1
1008e5e84: 52800024    	mov	w4, #0x1                ; =1
1008e5e88: 94450a72    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e5e8c: f9400a61    	ldr	x1, [x19, #0x10]
1008e5e90: 17ffffb6    	b	0x1008e5d68 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb878>
1008e5e94: aa0003f3    	mov	x19, x0
1008e5e98: 52800022    	mov	w2, #0x1                ; =1
1008e5e9c: 52800023    	mov	w3, #0x1                ; =1
1008e5ea0: 52800024    	mov	w4, #0x1                ; =1
1008e5ea4: 94450a6b    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e5ea8: aa1303e0    	mov	x0, x19
1008e5eac: f9400a61    	ldr	x1, [x19, #0x10]
1008e5eb0: 17ffff4d    	b	0x1008e5be4 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb6f4>
1008e5eb4: aa0003f3    	mov	x19, x0
1008e5eb8: 52800022    	mov	w2, #0x1                ; =1
1008e5ebc: 52800023    	mov	w3, #0x1                ; =1
1008e5ec0: 52800024    	mov	w4, #0x1                ; =1
1008e5ec4: 94450a63    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e5ec8: aa1303e0    	mov	x0, x19
1008e5ecc: f9400a61    	ldr	x1, [x19, #0x10]
1008e5ed0: 17ffff97    	b	0x1008e5d2c <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb83c>
1008e5ed4: f94017f3    	ldr	x19, [sp, #0x28]
1008e5ed8: f9400a61    	ldr	x1, [x19, #0x10]
1008e5edc: f9400268    	ldr	x8, [x19]
1008e5ee0: eb01011f    	cmp	x8, x1
1008e5ee4: 54000300    	b.eq	0x1008e5f44 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xba54>
1008e5ee8: f94007f6    	ldr	x22, [sp, #0x8]
1008e5eec: f9400668    	ldr	x8, [x19, #0x8]
1008e5ef0: 52800ba9    	mov	w9, #0x5d               ; =93
1008e5ef4: 38216909    	strb	w9, [x8, x1]
1008e5ef8: 91000428    	add	x8, x1, #0x1
1008e5efc: f9000a68    	str	x8, [x19, #0x10]
1008e5f00: 14000005    	b	0x1008e5f14 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xba24>
1008e5f04: 52800ba8    	mov	w8, #0x5d               ; =93
1008e5f08: 39000408    	strb	w8, [x0, #0x1]
1008e5f0c: 52800048    	mov	w8, #0x2                ; =2
1008e5f10: f90013e8    	str	x8, [sp, #0x20]
1008e5f14: 3dc007e0    	ldr	q0, [sp, #0x10]
1008e5f18: 3d8002c0    	str	q0, [x22]
1008e5f1c: f94013e8    	ldr	x8, [sp, #0x20]
1008e5f20: f9000ac8    	str	x8, [x22, #0x10]
1008e5f24: a9497bfd    	ldp	x29, x30, [sp, #0x90]
1008e5f28: a9484ff4    	ldp	x20, x19, [sp, #0x80]
1008e5f2c: a94757f6    	ldp	x22, x21, [sp, #0x70]
1008e5f30: a9465ff8    	ldp	x24, x23, [sp, #0x60]
1008e5f34: a94567fa    	ldp	x26, x25, [sp, #0x50]
1008e5f38: a9446ffc    	ldp	x28, x27, [sp, #0x40]
1008e5f3c: 910283ff    	add	sp, sp, #0xa0
1008e5f40: d65f03c0    	ret
1008e5f44: aa1303e0    	mov	x0, x19
1008e5f48: 52800022    	mov	w2, #0x1                ; =1
1008e5f4c: 52800023    	mov	w3, #0x1                ; =1
1008e5f50: 52800024    	mov	w4, #0x1                ; =1
1008e5f54: 94450a3f    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e5f58: f94007f6    	ldr	x22, [sp, #0x8]
1008e5f5c: f9400a61    	ldr	x1, [x19, #0x10]
1008e5f60: 17ffffe3    	b	0x1008e5eec <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb9fc>
1008e5f64: 52800020    	mov	w0, #0x1                ; =1
1008e5f68: 52801001    	mov	w1, #0x80               ; =128
1008e5f6c: 94477502    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1008e5f70: 14000001    	b	0x1008e5f74 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xba84>
1008e5f74: f9400be1    	ldr	x1, [sp, #0x10]
1008e5f78: b40000e1    	cbz	x1, 0x1008e5f94 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbaa4>
1008e5f7c: f9400fe8    	ldr	x8, [sp, #0x18]
1008e5f80: aa0003f3    	mov	x19, x0
1008e5f84: aa0803e0    	mov	x0, x8
1008e5f88: 52800022    	mov	w2, #0x1                ; =1
1008e5f8c: 9406e1d4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1008e5f90: aa1303e0    	mov	x0, x19
1008e5f94: 94478d90    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1008e5f98: d10143ff    	sub	sp, sp, #0x50
1008e5f9c: a90257f6    	stp	x22, x21, [sp, #0x20]
1008e5fa0: a9034ff4    	stp	x20, x19, [sp, #0x30]
1008e5fa4: a9047bfd    	stp	x29, x30, [sp, #0x40]
1008e5fa8: 910103fd    	add	x29, sp, #0x40
1008e5fac: aa0103f4    	mov	x20, x1
1008e5fb0: aa0003f3    	mov	x19, x0
1008e5fb4: 9406e1cf    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1008e5fb8: 52801000    	mov	w0, #0x80               ; =128
1008e5fbc: 52800021    	mov	w1, #0x1                ; =1
1008e5fc0: 9406e1c6    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1008e5fc4: b4002100    	cbz	x0, 0x1008e63e4 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbef4>
1008e5fc8: 52801008    	mov	w8, #0x80               ; =128
1008e5fcc: a90083e8    	stp	x8, x0, [sp, #0x8]
1008e5fd0: 52800b68    	mov	w8, #0x5b               ; =91
1008e5fd4: 39000008    	strb	w8, [x0]
1008e5fd8: 52800028    	mov	w8, #0x1                ; =1
1008e5fdc: f9000fe8    	str	x8, [sp, #0x18]
1008e5fe0: a9400a81    	ldp	x1, x2, [x20]
1008e5fe4: 910023e0    	add	x0, sp, #0x8
1008e5fe8: 97ffc6ed    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e5fec: a9415a95    	ldp	x21, x22, [x20, #0x10]
1008e5ff0: f9400fe1    	ldr	x1, [sp, #0x18]
1008e5ff4: f94007e8    	ldr	x8, [sp, #0x8]
1008e5ff8: eb01011f    	cmp	x8, x1
1008e5ffc: 540014c0    	b.eq	0x1008e6294 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbda4>
1008e6000: f9400be8    	ldr	x8, [sp, #0x10]
1008e6004: 52800589    	mov	w9, #0x2c               ; =44
1008e6008: 38216909    	strb	w9, [x8, x1]
1008e600c: 91000428    	add	x8, x1, #0x1
1008e6010: f9000fe8    	str	x8, [sp, #0x18]
1008e6014: 910023e0    	add	x0, sp, #0x8
1008e6018: aa1503e1    	mov	x1, x21
1008e601c: aa1603e2    	mov	x2, x22
1008e6020: 97ffc6df    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e6024: a9425a95    	ldp	x21, x22, [x20, #0x20]
1008e6028: f9400fe1    	ldr	x1, [sp, #0x18]
1008e602c: f94007e8    	ldr	x8, [sp, #0x8]
1008e6030: eb01011f    	cmp	x8, x1
1008e6034: 540013e0    	b.eq	0x1008e62b0 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbdc0>
1008e6038: f9400be8    	ldr	x8, [sp, #0x10]
1008e603c: 52800589    	mov	w9, #0x2c               ; =44
1008e6040: 38216909    	strb	w9, [x8, x1]
1008e6044: 91000428    	add	x8, x1, #0x1
1008e6048: f9000fe8    	str	x8, [sp, #0x18]
1008e604c: 910023e0    	add	x0, sp, #0x8
1008e6050: aa1503e1    	mov	x1, x21
1008e6054: aa1603e2    	mov	x2, x22
1008e6058: 97ffc6d1    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e605c: a9435a95    	ldp	x21, x22, [x20, #0x30]
1008e6060: f9400fe1    	ldr	x1, [sp, #0x18]
1008e6064: f94007e8    	ldr	x8, [sp, #0x8]
1008e6068: eb01011f    	cmp	x8, x1
1008e606c: 54001300    	b.eq	0x1008e62cc <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbddc>
1008e6070: f9400be8    	ldr	x8, [sp, #0x10]
1008e6074: 52800589    	mov	w9, #0x2c               ; =44
1008e6078: 38216909    	strb	w9, [x8, x1]
1008e607c: 91000428    	add	x8, x1, #0x1
1008e6080: f9000fe8    	str	x8, [sp, #0x18]
1008e6084: 910023e0    	add	x0, sp, #0x8
1008e6088: aa1503e1    	mov	x1, x21
1008e608c: aa1603e2    	mov	x2, x22
1008e6090: 97ffc6c3    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e6094: a9445a95    	ldp	x21, x22, [x20, #0x40]
1008e6098: f9400fe1    	ldr	x1, [sp, #0x18]
1008e609c: f94007e8    	ldr	x8, [sp, #0x8]
1008e60a0: eb01011f    	cmp	x8, x1
1008e60a4: 54001220    	b.eq	0x1008e62e8 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbdf8>
1008e60a8: f9400be8    	ldr	x8, [sp, #0x10]
1008e60ac: 52800589    	mov	w9, #0x2c               ; =44
1008e60b0: 38216909    	strb	w9, [x8, x1]
1008e60b4: 91000428    	add	x8, x1, #0x1
1008e60b8: f9000fe8    	str	x8, [sp, #0x18]
1008e60bc: 910023e0    	add	x0, sp, #0x8
1008e60c0: aa1503e1    	mov	x1, x21
1008e60c4: aa1603e2    	mov	x2, x22
1008e60c8: 97ffc6b5    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e60cc: a9455a95    	ldp	x21, x22, [x20, #0x50]
1008e60d0: f9400fe1    	ldr	x1, [sp, #0x18]
1008e60d4: f94007e8    	ldr	x8, [sp, #0x8]
1008e60d8: eb01011f    	cmp	x8, x1
1008e60dc: 54001140    	b.eq	0x1008e6304 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbe14>
1008e60e0: f9400be8    	ldr	x8, [sp, #0x10]
1008e60e4: 52800589    	mov	w9, #0x2c               ; =44
1008e60e8: 38216909    	strb	w9, [x8, x1]
1008e60ec: 91000428    	add	x8, x1, #0x1
1008e60f0: f9000fe8    	str	x8, [sp, #0x18]
1008e60f4: 910023e0    	add	x0, sp, #0x8
1008e60f8: aa1503e1    	mov	x1, x21
1008e60fc: aa1603e2    	mov	x2, x22
1008e6100: 97ffc6a7    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e6104: a9465a95    	ldp	x21, x22, [x20, #0x60]
1008e6108: f9400fe1    	ldr	x1, [sp, #0x18]
1008e610c: f94007e8    	ldr	x8, [sp, #0x8]
1008e6110: eb01011f    	cmp	x8, x1
1008e6114: 54001060    	b.eq	0x1008e6320 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbe30>
1008e6118: f9400be8    	ldr	x8, [sp, #0x10]
1008e611c: 52800589    	mov	w9, #0x2c               ; =44
1008e6120: 38216909    	strb	w9, [x8, x1]
1008e6124: 91000428    	add	x8, x1, #0x1
1008e6128: f9000fe8    	str	x8, [sp, #0x18]
1008e612c: 910023e0    	add	x0, sp, #0x8
1008e6130: aa1503e1    	mov	x1, x21
1008e6134: aa1603e2    	mov	x2, x22
1008e6138: 97ffc699    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e613c: a9475a95    	ldp	x21, x22, [x20, #0x70]
1008e6140: f9400fe1    	ldr	x1, [sp, #0x18]
1008e6144: f94007e8    	ldr	x8, [sp, #0x8]
1008e6148: eb01011f    	cmp	x8, x1
1008e614c: 54000f80    	b.eq	0x1008e633c <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbe4c>
1008e6150: f9400be8    	ldr	x8, [sp, #0x10]
1008e6154: 52800589    	mov	w9, #0x2c               ; =44
1008e6158: 38216909    	strb	w9, [x8, x1]
1008e615c: 91000428    	add	x8, x1, #0x1
1008e6160: f9000fe8    	str	x8, [sp, #0x18]
1008e6164: 910023e0    	add	x0, sp, #0x8
1008e6168: aa1503e1    	mov	x1, x21
1008e616c: aa1603e2    	mov	x2, x22
1008e6170: 97ffc68b    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e6174: a9485a95    	ldp	x21, x22, [x20, #0x80]
1008e6178: f9400fe1    	ldr	x1, [sp, #0x18]
1008e617c: f94007e8    	ldr	x8, [sp, #0x8]
1008e6180: eb01011f    	cmp	x8, x1
1008e6184: 54000ea0    	b.eq	0x1008e6358 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbe68>
1008e6188: f9400be8    	ldr	x8, [sp, #0x10]
1008e618c: 52800589    	mov	w9, #0x2c               ; =44
1008e6190: 38216909    	strb	w9, [x8, x1]
1008e6194: 91000428    	add	x8, x1, #0x1
1008e6198: f9000fe8    	str	x8, [sp, #0x18]
1008e619c: 910023e0    	add	x0, sp, #0x8
1008e61a0: aa1503e1    	mov	x1, x21
1008e61a4: aa1603e2    	mov	x2, x22
1008e61a8: 97ffc67d    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e61ac: a9495a95    	ldp	x21, x22, [x20, #0x90]
1008e61b0: f9400fe1    	ldr	x1, [sp, #0x18]
1008e61b4: f94007e8    	ldr	x8, [sp, #0x8]
1008e61b8: eb01011f    	cmp	x8, x1
1008e61bc: 54000dc0    	b.eq	0x1008e6374 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbe84>
1008e61c0: f9400be8    	ldr	x8, [sp, #0x10]
1008e61c4: 52800589    	mov	w9, #0x2c               ; =44
1008e61c8: 38216909    	strb	w9, [x8, x1]
1008e61cc: 91000428    	add	x8, x1, #0x1
1008e61d0: f9000fe8    	str	x8, [sp, #0x18]
1008e61d4: 910023e0    	add	x0, sp, #0x8
1008e61d8: aa1503e1    	mov	x1, x21
1008e61dc: aa1603e2    	mov	x2, x22
1008e61e0: 97ffc66f    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e61e4: a94a5a95    	ldp	x21, x22, [x20, #0xa0]
1008e61e8: f9400fe1    	ldr	x1, [sp, #0x18]
1008e61ec: f94007e8    	ldr	x8, [sp, #0x8]
1008e61f0: eb01011f    	cmp	x8, x1
1008e61f4: 54000ce0    	b.eq	0x1008e6390 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbea0>
1008e61f8: f9400be8    	ldr	x8, [sp, #0x10]
1008e61fc: 52800589    	mov	w9, #0x2c               ; =44
1008e6200: 38216909    	strb	w9, [x8, x1]
1008e6204: 91000428    	add	x8, x1, #0x1
1008e6208: f9000fe8    	str	x8, [sp, #0x18]
1008e620c: 910023e0    	add	x0, sp, #0x8
1008e6210: aa1503e1    	mov	x1, x21
1008e6214: aa1603e2    	mov	x2, x22
1008e6218: 97ffc661    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e621c: a94b5295    	ldp	x21, x20, [x20, #0xb0]
1008e6220: f9400fe1    	ldr	x1, [sp, #0x18]
1008e6224: f94007e8    	ldr	x8, [sp, #0x8]
1008e6228: eb01011f    	cmp	x8, x1
1008e622c: 54000c00    	b.eq	0x1008e63ac <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbebc>
1008e6230: f9400be8    	ldr	x8, [sp, #0x10]
1008e6234: 52800589    	mov	w9, #0x2c               ; =44
1008e6238: 38216909    	strb	w9, [x8, x1]
1008e623c: 91000428    	add	x8, x1, #0x1
1008e6240: f9000fe8    	str	x8, [sp, #0x18]
1008e6244: 910023e0    	add	x0, sp, #0x8
1008e6248: aa1503e1    	mov	x1, x21
1008e624c: aa1403e2    	mov	x2, x20
1008e6250: 97ffc653    	bl	0x1008d7b9c <_$s4Otty8HeldKeysV7isEmptySbvg+0x2bdc>
1008e6254: f9400fe1    	ldr	x1, [sp, #0x18]
1008e6258: f94007e8    	ldr	x8, [sp, #0x8]
1008e625c: eb01011f    	cmp	x8, x1
1008e6260: 54000b40    	b.eq	0x1008e63c8 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbed8>
1008e6264: f9400be8    	ldr	x8, [sp, #0x10]
1008e6268: 52800ba9    	mov	w9, #0x5d               ; =93
1008e626c: 38216909    	strb	w9, [x8, x1]
1008e6270: 91000428    	add	x8, x1, #0x1
1008e6274: f9000a68    	str	x8, [x19, #0x10]
1008e6278: 3cc083e0    	ldur	q0, [sp, #0x8]
1008e627c: 3d800260    	str	q0, [x19]
1008e6280: a9447bfd    	ldp	x29, x30, [sp, #0x40]
1008e6284: a9434ff4    	ldp	x20, x19, [sp, #0x30]
1008e6288: a94257f6    	ldp	x22, x21, [sp, #0x20]
1008e628c: 910143ff    	add	sp, sp, #0x50
1008e6290: d65f03c0    	ret
1008e6294: 910023e0    	add	x0, sp, #0x8
1008e6298: 52800022    	mov	w2, #0x1                ; =1
1008e629c: 52800023    	mov	w3, #0x1                ; =1
1008e62a0: 52800024    	mov	w4, #0x1                ; =1
1008e62a4: 9445096b    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e62a8: f9400fe1    	ldr	x1, [sp, #0x18]
1008e62ac: 17ffff55    	b	0x1008e6000 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbb10>
1008e62b0: 910023e0    	add	x0, sp, #0x8
1008e62b4: 52800022    	mov	w2, #0x1                ; =1
1008e62b8: 52800023    	mov	w3, #0x1                ; =1
1008e62bc: 52800024    	mov	w4, #0x1                ; =1
1008e62c0: 94450964    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e62c4: f9400fe1    	ldr	x1, [sp, #0x18]
1008e62c8: 17ffff5c    	b	0x1008e6038 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbb48>
1008e62cc: 910023e0    	add	x0, sp, #0x8
1008e62d0: 52800022    	mov	w2, #0x1                ; =1
1008e62d4: 52800023    	mov	w3, #0x1                ; =1
1008e62d8: 52800024    	mov	w4, #0x1                ; =1
1008e62dc: 9445095d    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e62e0: f9400fe1    	ldr	x1, [sp, #0x18]
1008e62e4: 17ffff63    	b	0x1008e6070 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbb80>
1008e62e8: 910023e0    	add	x0, sp, #0x8
1008e62ec: 52800022    	mov	w2, #0x1                ; =1
1008e62f0: 52800023    	mov	w3, #0x1                ; =1
1008e62f4: 52800024    	mov	w4, #0x1                ; =1
1008e62f8: 94450956    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e62fc: f9400fe1    	ldr	x1, [sp, #0x18]
1008e6300: 17ffff6a    	b	0x1008e60a8 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbbb8>
1008e6304: 910023e0    	add	x0, sp, #0x8
1008e6308: 52800022    	mov	w2, #0x1                ; =1
1008e630c: 52800023    	mov	w3, #0x1                ; =1
1008e6310: 52800024    	mov	w4, #0x1                ; =1
1008e6314: 9445094f    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e6318: f9400fe1    	ldr	x1, [sp, #0x18]
1008e631c: 17ffff71    	b	0x1008e60e0 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbbf0>
1008e6320: 910023e0    	add	x0, sp, #0x8
1008e6324: 52800022    	mov	w2, #0x1                ; =1
1008e6328: 52800023    	mov	w3, #0x1                ; =1
1008e632c: 52800024    	mov	w4, #0x1                ; =1
1008e6330: 94450948    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e6334: f9400fe1    	ldr	x1, [sp, #0x18]
1008e6338: 17ffff78    	b	0x1008e6118 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbc28>
1008e633c: 910023e0    	add	x0, sp, #0x8
1008e6340: 52800022    	mov	w2, #0x1                ; =1
1008e6344: 52800023    	mov	w3, #0x1                ; =1
1008e6348: 52800024    	mov	w4, #0x1                ; =1
1008e634c: 94450941    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e6350: f9400fe1    	ldr	x1, [sp, #0x18]
1008e6354: 17ffff7f    	b	0x1008e6150 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbc60>
1008e6358: 910023e0    	add	x0, sp, #0x8
1008e635c: 52800022    	mov	w2, #0x1                ; =1
1008e6360: 52800023    	mov	w3, #0x1                ; =1
1008e6364: 52800024    	mov	w4, #0x1                ; =1
1008e6368: 9445093a    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e636c: f9400fe1    	ldr	x1, [sp, #0x18]
1008e6370: 17ffff86    	b	0x1008e6188 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbc98>
1008e6374: 910023e0    	add	x0, sp, #0x8
1008e6378: 52800022    	mov	w2, #0x1                ; =1
1008e637c: 52800023    	mov	w3, #0x1                ; =1
1008e6380: 52800024    	mov	w4, #0x1                ; =1
1008e6384: 94450933    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e6388: f9400fe1    	ldr	x1, [sp, #0x18]
1008e638c: 17ffff8d    	b	0x1008e61c0 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbcd0>
1008e6390: 910023e0    	add	x0, sp, #0x8
1008e6394: 52800022    	mov	w2, #0x1                ; =1
1008e6398: 52800023    	mov	w3, #0x1                ; =1
1008e639c: 52800024    	mov	w4, #0x1                ; =1
1008e63a0: 9445092c    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e63a4: f9400fe1    	ldr	x1, [sp, #0x18]
1008e63a8: 17ffff94    	b	0x1008e61f8 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbd08>
1008e63ac: 910023e0    	add	x0, sp, #0x8
1008e63b0: 52800022    	mov	w2, #0x1                ; =1
1008e63b4: 52800023    	mov	w3, #0x1                ; =1
1008e63b8: 52800024    	mov	w4, #0x1                ; =1
1008e63bc: 94450925    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e63c0: f9400fe1    	ldr	x1, [sp, #0x18]
1008e63c4: 17ffff9b    	b	0x1008e6230 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbd40>
1008e63c8: 910023e0    	add	x0, sp, #0x8
1008e63cc: 52800022    	mov	w2, #0x1                ; =1
1008e63d0: 52800023    	mov	w3, #0x1                ; =1
1008e63d4: 52800024    	mov	w4, #0x1                ; =1
1008e63d8: 9445091e    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1008e63dc: f9400fe1    	ldr	x1, [sp, #0x18]
1008e63e0: 17ffffa1    	b	0x1008e6264 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbd74>
1008e63e4: 52800020    	mov	w0, #0x1                ; =1
1008e63e8: 52801001    	mov	w1, #0x80               ; =128
1008e63ec: 944773e2    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1008e63f0: aa0003f3    	mov	x19, x0
1008e63f4: f94007e1    	ldr	x1, [sp, #0x8]
1008e63f8: b4000081    	cbz	x1, 0x1008e6408 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xbf18>
1008e63fc: f9400be0    	ldr	x0, [sp, #0x10]
