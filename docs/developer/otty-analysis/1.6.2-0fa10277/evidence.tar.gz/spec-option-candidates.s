
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101432360 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E>:
101432638: d101c3ff    	sub	sp, sp, #0x70
10143263c: a9035ff8    	stp	x24, x23, [sp, #0x30]
101432640: a90457f6    	stp	x22, x21, [sp, #0x40]
101432644: a9054ff4    	stp	x20, x19, [sp, #0x50]
101432648: a9067bfd    	stp	x29, x30, [sp, #0x60]
10143264c: 910183fd    	add	x29, sp, #0x60
101432650: aa0503f4    	mov	x20, x5
101432654: aa0403f5    	mov	x21, x4
101432658: aa0303f6    	mov	x22, x3
10143265c: aa0003f3    	mov	x19, x0
101432660: 910003e8    	mov	x8, sp
101432664: aa0103e0    	mov	x0, x1
101432668: aa0203e1    	mov	x1, x2
10143266c: 940f6432    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
101432670: 52800108    	mov	w8, #0x8                ; =8
101432674: a901a3ff    	stp	xzr, x8, [sp, #0x18]
101432678: f90017ff    	str	xzr, [sp, #0x28]
10143267c: f84b0ec8    	ldr	x8, [x22, #0xb0]!
101432680: d2f00017    	mov	x23, #-0x8000000000000000 ; =-9223372036854775808
101432684: eb17011f    	cmp	x8, x23
101432688: 9a9603e2    	csel	x2, xzr, x22, eq
10143268c: 910003e0    	mov	x0, sp
101432690: 910063e1    	add	x1, sp, #0x18
101432694: 94000027    	bl	0x101432730 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x3d0>
101432698: d10022b5    	sub	x21, x21, #0x8
10143269c: d37df294    	lsl	x20, x20, #3
1014326a0: b4000154    	cbz	x20, 0x1014326c8 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x368>
1014326a4: f8746aa8    	ldr	x8, [x21, x20]
1014326a8: f84b0d09    	ldr	x9, [x8, #0xb0]!
1014326ac: eb17013f    	cmp	x9, x23
1014326b0: 9a8803e2    	csel	x2, xzr, x8, eq
1014326b4: d1002294    	sub	x20, x20, #0x8
1014326b8: 910003e0    	mov	x0, sp
1014326bc: 910063e1    	add	x1, sp, #0x18
1014326c0: 9400001c    	bl	0x101432730 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x3d0>
1014326c4: 17fffff7    	b	0x1014326a0 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x340>
1014326c8: 3cc183e0    	ldur	q0, [sp, #0x18]
1014326cc: 3d800260    	str	q0, [x19]
1014326d0: f94017e8    	ldr	x8, [sp, #0x28]
1014326d4: f9000a68    	str	x8, [x19, #0x10]
1014326d8: f94003e1    	ldr	x1, [sp]
1014326dc: b4000081    	cbz	x1, 0x1014326ec <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x38c>
1014326e0: f94007e0    	ldr	x0, [sp, #0x8]
1014326e4: 52800022    	mov	w2, #0x1                ; =1
1014326e8: 97d9affd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014326ec: a9467bfd    	ldp	x29, x30, [sp, #0x60]
1014326f0: a9454ff4    	ldp	x20, x19, [sp, #0x50]
1014326f4: a94457f6    	ldp	x22, x21, [sp, #0x40]
1014326f8: a9435ff8    	ldp	x24, x23, [sp, #0x30]
1014326fc: 9101c3ff    	add	sp, sp, #0x70
101432700: d65f03c0    	ret
101432704: 14000001    	b	0x101432708 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x3a8>
101432708: aa0003f3    	mov	x19, x0
10143270c: 910063e0    	add	x0, sp, #0x18
101432710: 94008dd5    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101432714: f94003e1    	ldr	x1, [sp]
101432718: b4000081    	cbz	x1, 0x101432728 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x3c8>
10143271c: f94007e0    	ldr	x0, [sp, #0x8]
101432720: 52800022    	mov	w2, #0x1                ; =1
101432724: 97d9afee    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101432728: aa1303e0    	mov	x0, x19
10143272c: 941a5baa    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101432730: d10483ff    	sub	sp, sp, #0x120
101432734: a90c6ffc    	stp	x28, x27, [sp, #0xc0]
101432738: a90d67fa    	stp	x26, x25, [sp, #0xd0]
10143273c: a90e5ff8    	stp	x24, x23, [sp, #0xe0]
101432740: a90f57f6    	stp	x22, x21, [sp, #0xf0]
101432744: a9104ff4    	stp	x20, x19, [sp, #0x100]
101432748: a9117bfd    	stp	x29, x30, [sp, #0x110]
10143274c: 910443fd    	add	x29, sp, #0x110
101432750: b4000cc2    	cbz	x2, 0x1014328e8 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x588>
101432754: f9400848    	ldr	x8, [x2, #0x10]
101432758: b4000c88    	cbz	x8, 0x1014328e8 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x588>
10143275c: aa0103f3    	mov	x19, x1
101432760: aa0003f4    	mov	x20, x0
101432764: f9400457    	ldr	x23, [x2, #0x8]
101432768: 52801309    	mov	w9, #0x98               ; =152
10143276c: 9b095d18    	madd	x24, x8, x9, x23
101432770: 910003f9    	mov	x25, sp
101432774: 14000004    	b	0x101432784 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x424>
101432778: 910262f7    	add	x23, x23, #0x98
10143277c: eb1802ff    	cmp	x23, x24
101432780: 54000b40    	b.eq	0x1014328e8 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x588>
101432784: f9403ee8    	ldr	x8, [x23, #0x78]
101432788: b4ffff88    	cbz	x8, 0x101432778 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x418>
10143278c: f9403afc    	ldr	x28, [x23, #0x70]
101432790: 52800309    	mov	w9, #0x18               ; =24
101432794: 9b09711a    	madd	x26, x8, x9, x28
101432798: 14000010    	b	0x1014327d8 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x478>
10143279c: f9400668    	ldr	x8, [x19, #0x8]
1014327a0: 52800d09    	mov	w9, #0x68               ; =104
1014327a4: 9b0922c8    	madd	x8, x22, x9, x8
1014327a8: ad4207e0    	ldp	q0, q1, [sp, #0x40]
1014327ac: ad020500    	stp	q0, q1, [x8, #0x40]
1014327b0: f94033e9    	ldr	x9, [sp, #0x60]
1014327b4: f9003109    	str	x9, [x8, #0x60]
1014327b8: ad4007e0    	ldp	q0, q1, [sp]
1014327bc: ad000500    	stp	q0, q1, [x8]
1014327c0: ad4103e1    	ldp	q1, q0, [sp, #0x20]
1014327c4: ad010101    	stp	q1, q0, [x8, #0x20]
1014327c8: 910006c8    	add	x8, x22, #0x1
1014327cc: f9000a68    	str	x8, [x19, #0x10]
1014327d0: eb1a039f    	cmp	x28, x26
1014327d4: 54fffd20    	b.eq	0x101432778 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x418>
1014327d8: 9100639c    	add	x28, x28, #0x18
1014327dc: 14000004    	b	0x1014327ec <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x48c>
1014327e0: eb1a039f    	cmp	x28, x26
1014327e4: 9100639c    	add	x28, x28, #0x18
1014327e8: 54fffc80    	b.eq	0x101432778 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x418>
1014327ec: f9400a88    	ldr	x8, [x20, #0x10]
1014327f0: b40002e8    	cbz	x8, 0x10143284c <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x4ec>
1014327f4: a97f0780    	ldp	x0, x1, [x28, #-0x10]
1014327f8: 910003e8    	mov	x8, sp
1014327fc: 940f63ce    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
101432800: a940a3f6    	ldp	x22, x8, [sp, #0x8]
101432804: f9400a82    	ldr	x2, [x20, #0x10]
101432808: eb02011f    	cmp	x8, x2
10143280c: 540000a3    	b.lo	0x101432820 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x4c0>
101432810: f9400680    	ldr	x0, [x20, #0x8]
101432814: aa1603e1    	mov	x1, x22
101432818: 941a5d01    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10143281c: 340000e0    	cbz	w0, 0x101432838 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x4d8>
101432820: f94003e1    	ldr	x1, [sp]
101432824: b4fffde1    	cbz	x1, 0x1014327e0 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x480>
101432828: aa1603e0    	mov	x0, x22
10143282c: 52800022    	mov	w2, #0x1                ; =1
101432830: 97d9afab    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101432834: 17ffffeb    	b	0x1014327e0 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x480>
101432838: f94003e1    	ldr	x1, [sp]
10143283c: b4000081    	cbz	x1, 0x10143284c <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x4ec>
101432840: aa1603e0    	mov	x0, x22
101432844: 52800022    	mov	w2, #0x1                ; =1
101432848: 97d9afa5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143284c: d1006380    	sub	x0, x28, #0x18
101432850: 9101a3e8    	add	x8, sp, #0x68
101432854: 940f725e    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101432858: f84802e8    	ldur	x8, [x23, #0x80]
10143285c: d2f00016    	mov	x22, #-0x8000000000000000 ; =-9223372036854775808
101432860: eb16011f    	cmp	x8, x22
101432864: 540000c0    	b.eq	0x10143287c <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x51c>
101432868: d101c3a8    	sub	x8, x29, #0x70
10143286c: 910202e0    	add	x0, x23, #0x80
101432870: 940f7257    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101432874: a97957b6    	ldp	x22, x21, [x29, #-0x70]
101432878: f85a03bb    	ldur	x27, [x29, #-0x60]
10143287c: 3cc683e0    	ldur	q0, [sp, #0x68]
101432880: 3d8023e0    	str	q0, [sp, #0x80]
101432884: f9403fe8    	ldr	x8, [sp, #0x78]
101432888: f9004be8    	str	x8, [sp, #0x90]
10143288c: d101c3a8    	sub	x8, x29, #0x70
101432890: 910203e0    	add	x0, sp, #0x80
101432894: 940f724e    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101432898: 3cc683e0    	ldur	q0, [sp, #0x68]
10143289c: 3c818320    	stur	q0, [x25, #0x18]
1014328a0: f9403fe8    	ldr	x8, [sp, #0x78]
1014328a4: f8028328    	stur	x8, [x25, #0x28]
1014328a8: 3cd903a0    	ldur	q0, [x29, #-0x70]
1014328ac: f85a03a8    	ldur	x8, [x29, #-0x60]
1014328b0: 3d8003e0    	str	q0, [sp]
1014328b4: f9000be8    	str	x8, [sp, #0x10]
1014328b8: a90357f6    	stp	x22, x21, [sp, #0x30]
1014328bc: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014328c0: a90423fb    	stp	x27, x8, [sp, #0x40]
1014328c4: 52802008    	mov	w8, #0x100              ; =256
1014328c8: 7900c3e8    	strh	w8, [sp, #0x60]
1014328cc: f9400a76    	ldr	x22, [x19, #0x10]
1014328d0: f9400268    	ldr	x8, [x19]
1014328d4: eb0802df    	cmp	x22, x8
1014328d8: 54fff621    	b.ne	0x10143279c <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x43c>
1014328dc: aa1303e0    	mov	x0, x19
1014328e0: 94197581    	bl	0x101a8fee4 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h79ba5ff6649e4cf8E>
1014328e4: 17ffffae    	b	0x10143279c <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x43c>
1014328e8: a9517bfd    	ldp	x29, x30, [sp, #0x110]
1014328ec: a9504ff4    	ldp	x20, x19, [sp, #0x100]
1014328f0: a94f57f6    	ldp	x22, x21, [sp, #0xf0]
1014328f4: a94e5ff8    	ldp	x24, x23, [sp, #0xe0]
1014328f8: a94d67fa    	ldp	x26, x25, [sp, #0xd0]
1014328fc: a94c6ffc    	ldp	x28, x27, [sp, #0xc0]
101432900: 910483ff    	add	sp, sp, #0x120
101432904: d65f03c0    	ret
101432908: aa0003f3    	mov	x19, x0
10143290c: f94037e1    	ldr	x1, [sp, #0x68]
101432910: b4000261    	cbz	x1, 0x10143295c <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x5fc>
101432914: f9403be0    	ldr	x0, [sp, #0x70]
101432918: 52800022    	mov	w2, #0x1                ; =1
10143291c: 97d9af70    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101432920: aa1303e0    	mov	x0, x19
101432924: 941a5b2c    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101432928: aa0003f3    	mov	x19, x0
10143292c: 910003e0    	mov	x0, sp
101432930: 97db2b6a    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101432934: aa1303e0    	mov	x0, x19
101432938: 941a5b27    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10143293c: aa0003f3    	mov	x19, x0
101432940: f94043e1    	ldr	x1, [sp, #0x80]
101432944: b4000081    	cbz	x1, 0x101432954 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x5f4>
101432948: f94047e0    	ldr	x0, [sp, #0x88]
10143294c: 52800022    	mov	w2, #0x1                ; =1
101432950: 97d9af63    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101432954: f240fadf    	tst	x22, #0x7fffffffffffffff
101432958: 54000061    	b.ne	0x101432964 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x604>
10143295c: aa1303e0    	mov	x0, x19
101432960: 941a5b1d    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101432964: aa1503e0    	mov	x0, x21
101432968: aa1603e1    	mov	x1, x22
10143296c: 52800022    	mov	w2, #0x1                ; =1
101432970: 97d9af5b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101432974: aa1303e0    	mov	x0, x19
101432978: 941a5b17    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10143297c: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
101432980: a90157f6    	stp	x22, x21, [sp, #0x10]
101432984: a9024ff4    	stp	x20, x19, [sp, #0x20]
101432988: a9037bfd    	stp	x29, x30, [sp, #0x30]
10143298c: 9100c3fd    	add	x29, sp, #0x30
101432990: aa0803f3    	mov	x19, x8
101432994: f9400808    	ldr	x8, [x0, #0x10]
101432998: b4000348    	cbz	x8, 0x101432a00 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x6a0>
10143299c: aa0203f4    	mov	x20, x2
1014329a0: aa0103f5    	mov	x21, x1
1014329a4: f9400409    	ldr	x9, [x0, #0x8]
1014329a8: 8b080508    	add	x8, x8, x8, lsl #1
1014329ac: d37ced17    	lsl	x23, x8, #4
1014329b0: 91006136    	add	x22, x9, #0x18
1014329b4: 14000004    	b	0x1014329c4 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x664>
1014329b8: 9100c2d6    	add	x22, x22, #0x30
1014329bc: f100c2f7    	subs	x23, x23, #0x30
1014329c0: 54000200    	b.eq	0x101432a00 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x6a0>
1014329c4: f85f82c8    	ldur	x8, [x22, #-0x8]
1014329c8: eb14011f    	cmp	x8, x20
1014329cc: 54ffff61    	b.ne	0x1014329b8 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x658>
1014329d0: f85f02c0    	ldur	x0, [x22, #-0x10]
1014329d4: aa1503e1    	mov	x1, x21
1014329d8: aa1403e2    	mov	x2, x20
1014329dc: 941a5c90    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
1014329e0: 35fffec0    	cbnz	w0, 0x1014329b8 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x658>
1014329e4: aa1303e8    	mov	x8, x19
1014329e8: aa1603e0    	mov	x0, x22
1014329ec: a9437bfd    	ldp	x29, x30, [sp, #0x30]
1014329f0: a9424ff4    	ldp	x20, x19, [sp, #0x20]
1014329f4: a94157f6    	ldp	x22, x21, [sp, #0x10]
1014329f8: a8c45ff8    	ldp	x24, x23, [sp], #0x40
1014329fc: 140f71f4    	b	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101432a00: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101432a04: f9000268    	str	x8, [x19]
101432a08: a9437bfd    	ldp	x29, x30, [sp, #0x30]
101432a0c: a9424ff4    	ldp	x20, x19, [sp, #0x20]
101432a10: a94157f6    	ldp	x22, x21, [sp, #0x10]
101432a14: a8c45ff8    	ldp	x24, x23, [sp], #0x40
101432a18: d65f03c0    	ret
101432a1c: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
101432a20: a90157f6    	stp	x22, x21, [sp, #0x10]
101432a24: a9024ff4    	stp	x20, x19, [sp, #0x20]
101432a28: a9037bfd    	stp	x29, x30, [sp, #0x30]
101432a2c: 9100c3fd    	add	x29, sp, #0x30
101432a30: aa0203f4    	mov	x20, x2
101432a34: aa0103f5    	mov	x21, x1
101432a38: aa0003f3    	mov	x19, x0
101432a3c: aa0803f6    	mov	x22, x8
101432a40: f8bfc000    	ldapr	x0, [x0]
101432a44: b4000320    	cbz	x0, 0x101432aa8 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x748>
101432a48: 940e30c2    	bl	0x1017bed50 <__ZN3std3sys3pal4unix4sync5mutex5Mutex4lock17h3548d2db0de37829E>
101432a4c: d0007d58    	adrp	x24, 0x1023dc000 <__ZN15crossbeam_utils6atomic11atomic_cell4lock5LOCKS17he2ac33ecd5b81040E+0x1680>
101432a50: 912da318    	add	x24, x24, #0xb68
101432a54: f9400308    	ldr	x8, [x24]
101432a58: f240f91f    	tst	x8, #0x7fffffffffffffff
101432a5c: 54000361    	b.ne	0x101432ac8 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x768>
101432a60: 52800017    	mov	w23, #0x0               ; =0
101432a64: 3940227f    	ldrb	wzr, [x19, #0x8]
101432a68: 91004260    	add	x0, x19, #0x10
101432a6c: aa1603e8    	mov	x8, x22
101432a70: aa1503e1    	mov	x1, x21
101432a74: aa1403e2    	mov	x2, x20
101432a78: 52800643    	mov	w3, #0x32               ; =50
101432a7c: 940188c7    	bl	0x101494d98 <__ZN10otty_state8frecency6Reader8matching17h99f3c63b9b2fb883E>
101432a80: 37000097    	tbnz	w23, #0x0, 0x101432a90 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x730>
101432a84: f9400308    	ldr	x8, [x24]
101432a88: f240f91f    	tst	x8, #0x7fffffffffffffff
101432a8c: 54000241    	b.ne	0x101432ad4 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x774>
101432a90: f9400260    	ldr	x0, [x19]
101432a94: a9437bfd    	ldp	x29, x30, [sp, #0x30]
101432a98: a9424ff4    	ldp	x20, x19, [sp, #0x20]
101432a9c: a94157f6    	ldp	x22, x21, [sp, #0x10]
101432aa0: a8c45ff8    	ldp	x24, x23, [sp], #0x40
101432aa4: 140e30b2    	b	0x1017bed6c <__ZN3std3sys3pal4unix4sync5mutex5Mutex6unlock17h5e6d0b50222d57d0E>
101432aa8: aa1303e0    	mov	x0, x19
101432aac: 941973f1    	bl	0x101a8fa70 <__ZN10serde_json2de21Deserializer$LT$R$GT$23parse_exponent_overflow17h8d2c34d8b104f113E+0x2e4>
101432ab0: 940e30a8    	bl	0x1017bed50 <__ZN3std3sys3pal4unix4sync5mutex5Mutex4lock17h3548d2db0de37829E>
101432ab4: d0007d58    	adrp	x24, 0x1023dc000 <__ZN15crossbeam_utils6atomic11atomic_cell4lock5LOCKS17he2ac33ecd5b81040E+0x1680>
101432ab8: 912da318    	add	x24, x24, #0xb68
101432abc: f9400308    	ldr	x8, [x24]
101432ac0: f240f91f    	tst	x8, #0x7fffffffffffffff
101432ac4: 54fffce0    	b.eq	0x101432a60 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x700>
101432ac8: 941a3457    	bl	0x101abfc24 <__ZN3std9panicking11panic_count17is_zero_slow_path17h055803fbeed74640E>
101432acc: 52000017    	eor	w23, w0, #0x1
101432ad0: 17ffffe5    	b	0x101432a64 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x704>
101432ad4: 941a3454    	bl	0x101abfc24 <__ZN3std9panicking11panic_count17is_zero_slow_path17h055803fbeed74640E>
101432ad8: 3707fdc0    	tbnz	w0, #0x0, 0x101432a90 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x730>
101432adc: 52800028    	mov	w8, #0x1                ; =1
101432ae0: 39002268    	strb	w8, [x19, #0x8]
101432ae4: 17ffffeb    	b	0x101432a90 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x730>
101432ae8: aa0003f4    	mov	x20, x0
101432aec: aa1303e0    	mov	x0, x19
101432af0: aa1703e1    	mov	x1, x23
101432af4: 97d3eb41    	bl	0x10092d7f8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1a7d0>
101432af8: aa1403e0    	mov	x0, x20
101432afc: 941a5ab6    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101432b00: 941a4489    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
