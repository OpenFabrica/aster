10066be90:     	sub	sp, sp, #0x50
10066be94:     	stp	x24, x23, [sp, #0x10]
10066be98:     	stp	x22, x21, [sp, #0x20]
10066be9c:     	stp	x20, x19, [sp, #0x30]
10066bea0:     	stp	x29, x30, [sp, #0x40]
10066bea4:     	add	x29, sp, #0x40
10066bea8:     	mov	x19, x20
10066beac:     	mov	x21, x0
10066beb0:     	ldr	x8, [x20]
10066beb4:     	ldr	x8, [x8, #0x508]
10066beb8:     	mov	w0, #0x1                ; =1
10066bebc:     	blr	x8
10066bec0:     	ldr	x8, [x20]
10066bec4:     	ldr	x8, [x8, #0x520]
10066bec8:     	mov	x0, x21
10066becc:     	blr	x8
10066bed0:     	mov	x8, #-0x2000000000000000 ; =-2305843009213693952
10066bed4:     	stp	xzr, x8, [sp]
10066bed8:     	mov	x20, sp
10066bedc:     	mov	w0, #0x27               ; =39
10066bee0:     	bl	0x101ac757c ; symbol _$ss11_StringGutsV4growyySiF
10066bee4:     	ldr	x0, [sp, #0x8]
10066bee8:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066beec:     	adrp	x8, 0x101de2000
10066bef0:     	add	x8, x8, #0xdd0 ; possible literal 'caffeinate enabled tab='
10066bef4:     	sub	x8, x8, #0x20
10066bef8:     	orr	x8, x8, #0x8000000000000000
10066befc:     	mov	x23, #0x17              ; =23
10066bf00:     	movk	x23, #0xd000, lsl #48
10066bf04:     	stp	x23, x8, [sp]
10066bf08:     	ldr	x8, [x19]
10066bf0c:     	ldr	x8, [x8, #0x698]
10066bf10:     	mov	x20, x19
10066bf14:     	blr	x8
10066bf18:     	mov	x22, x1
10066bf1c:     	mov	x20, sp
10066bf20:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066bf24:     	mov	x0, x22
10066bf28:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066bf2c:     	mov	x0, #0x7020             ; =28704
10066bf30:     	movk	x0, #0x7265, lsl #16
10066bf34:     	movk	x0, #0x6973, lsl #32
10066bf38:     	movk	x0, #0x7473, lsl #48
10066bf3c:     	mov	x1, #0x6e65             ; =28261
10066bf40:     	movk	x1, #0x3d74, lsl #16
10066bf44:     	movk	x1, #0xec00, lsl #48
10066bf48:     	mov	x20, sp
10066bf4c:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066bf50:     	adrp	x8, 0x101de2000
10066bf54:     	add	x8, x8, #0xe30 ; possible literal 'Otty will keep the system awake until you turn off keep-awake'
10066bf58:     	sub	x8, x8, #0x20
10066bf5c:     	adrp	x9, 0x101de2000
10066bf60:     	add	x9, x9, #0xdf0 ; possible literal 'Otty will keep the system awake until this task exits'
10066bf64:     	sub	x9, x9, #0x20
10066bf68:     	tst	w21, #0x1
10066bf6c:     	mov	w10, #0x7274            ; =29300
10066bf70:     	movk	w10, #0x6575, lsl #16
10066bf74:     	mov	x11, #0x6166            ; =24934
10066bf78:     	movk	x11, #0x736c, lsl #16
10066bf7c:     	movk	x11, #0x65, lsl #32
10066bf80:     	csel	x0, x10, x11, ne
10066bf84:     	mov	x10, #-0x1b00000000000000 ; =-1945555039024054272
10066bf88:     	mov	x11, #-0x1c00000000000000 ; =-2017612633061982208
10066bf8c:     	csel	x21, x11, x10, ne
10066bf90:     	add	x10, x23, #0x1e
10066bf94:     	add	x11, x23, #0x26
10066bf98:     	csel	x22, x11, x10, ne
10066bf9c:     	csel	x23, x8, x9, ne
10066bfa0:     	mov	x20, sp
10066bfa4:     	mov	x1, x21
10066bfa8:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066bfac:     	mov	x0, x21
10066bfb0:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066bfb4:     	ldp	x2, x20, [sp]
10066bfb8:     	mov	x0, #0x7250             ; =29264
10066bfbc:     	movk	x0, #0x7669, lsl #16
10066bfc0:     	movk	x0, #0x6c69, lsl #32
10066bfc4:     	movk	x0, #0x6765, lsl #48
10066bfc8:     	mov	x1, #0x65               ; =101
10066bfcc:     	movk	x1, #0xe900, lsl #48
10066bfd0:     	mov	x3, x20
10066bfd4:     	bl	0x100152e08
10066bfd8:     	mov	x0, x20
10066bfdc:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066bfe0:     	ldr	x8, [x19]
10066bfe4:     	ldr	x8, [x8, #0x5c0]
10066bfe8:     	mov	x20, x19
10066bfec:     	blr	x8
10066bff0:     	ldr	x8, [x19]
10066bff4:     	ldr	x8, [x8, #0x5d0]
10066bff8:     	orr	x1, x23, #0x8000000000000000
10066bffc:     	mov	x0, x22
10066c000:     	blr	x8
10066c004:     	orr	x0, x23, #0x8000000000000000
10066c008:     	ldp	x29, x30, [sp, #0x40]
10066c00c:     	ldp	x20, x19, [sp, #0x30]
10066c010:     	ldp	x22, x21, [sp, #0x20]
10066c014:     	ldp	x24, x23, [sp, #0x10]
10066c018:     	add	sp, sp, #0x50
10066c01c:     	b	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c020:     	sub	sp, sp, #0x80
10066c024:     	stp	x28, x27, [sp, #0x20]
10066c028:     	stp	x26, x25, [sp, #0x30]
10066c02c:     	stp	x24, x23, [sp, #0x40]
10066c030:     	stp	x22, x21, [sp, #0x50]
10066c034:     	stp	x20, x19, [sp, #0x60]
10066c038:     	stp	x29, x30, [sp, #0x70]
10066c03c:     	add	x29, sp, #0x70
10066c040:     	mov	x19, x20
10066c044:     	mov	x21, x0
10066c048:     	ldr	x8, [x20]
10066c04c:     	ldr	x8, [x8, #0x578]
10066c050:     	blr	x8
10066c054:     	mov	x22, x0
10066c058:     	ldr	x8, [x20]
10066c05c:     	ldr	x8, [x8, #0x508]
10066c060:     	mov	w0, #0x0                ; =0
10066c064:     	blr	x8
10066c068:     	ldr	x8, [x20]
10066c06c:     	ldr	x8, [x8, #0x520]
10066c070:     	mov	w0, #0x0                ; =0
10066c074:     	blr	x8
10066c078:     	ldr	x8, [x20]
10066c07c:     	ldr	x8, [x8, #0x5c8]
10066c080:     	blr	x8
10066c084:     	mov	x8, #-0x2000000000000000 ; =-2305843009213693952
10066c088:     	stp	xzr, x8, [sp, #0x10]
10066c08c:     	add	x20, sp, #0x10
10066c090:     	mov	w0, #0x1a               ; =26
10066c094:     	bl	0x101ac757c ; symbol _$ss11_StringGutsV4growyySiF
10066c098:     	ldr	x0, [sp, #0x18]
10066c09c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c0a0:     	adrp	x8, 0x101de2000
10066c0a4:     	add	x8, x8, #0xe70 ; possible literal 'caffeinate disabled tab='
10066c0a8:     	sub	x8, x8, #0x20
10066c0ac:     	orr	x8, x8, #0x8000000000000000
10066c0b0:     	mov	x9, #0x18               ; =24
10066c0b4:     	movk	x9, #0xd000, lsl #48
10066c0b8:     	stp	x9, x8, [sp, #0x10]
10066c0bc:     	ldr	x8, [x19]
10066c0c0:     	ldr	x8, [x8, #0x698]
10066c0c4:     	mov	x20, x19
10066c0c8:     	blr	x8
10066c0cc:     	mov	x23, x1
10066c0d0:     	add	x20, sp, #0x10
10066c0d4:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066c0d8:     	mov	x0, x23
10066c0dc:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c0e0:     	ldp	x2, x20, [sp, #0x10]
10066c0e4:     	mov	x0, #0x7250             ; =29264
10066c0e8:     	movk	x0, #0x7669, lsl #16
10066c0ec:     	movk	x0, #0x6c69, lsl #32
10066c0f0:     	movk	x0, #0x6765, lsl #48
10066c0f4:     	mov	x1, #0x65               ; =101
10066c0f8:     	movk	x1, #0xe900, lsl #48
10066c0fc:     	mov	x3, x20
10066c100:     	bl	0x100152e08
10066c104:     	mov	x0, x20
10066c108:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c10c:     	tbz	w22, #0x0, 0x10066c1d8
10066c110:     	lsr	x8, x21, #62
10066c114:     	cbnz	x8, 0x10066c250
10066c118:     	and	x8, x21, #0xffffffffffffff8
10066c11c:     	ldr	x23, [x8, #0x10]
10066c120:     	mov	x0, #0x33               ; =51
10066c124:     	movk	x0, #0x1000, lsl #48
10066c128:     	adrp	x8, 0x101de2000
10066c12c:     	add	x8, x8, #0xee0 ; possible literal 'Otty released keep-awake — system can sleep again'
10066c130:     	sub	x26, x8, #0x20
10066c134:     	cbz	x23, 0x10066c214
10066c138:     	mov	x24, #0x0               ; =0
10066c13c:     	and	x27, x21, #0xc000000000000001
10066c140:     	and	x28, x21, #0xffffffffffffff8
10066c144:     	adrp	x8, 0x101de2000
10066c148:     	add	x8, x8, #0xe90 ; possible literal 'Otty released keep-awake for this task — other tasks still active'
10066c14c:     	sub	x8, x8, #0x20
10066c150:     	str	x8, [sp, #0x8]
10066c154:     	b	0x10066c16c
10066c158:     	mov	x0, x20
10066c15c:     	bl	0x101aca960 ; symbol _swift_release
10066c160:     	add	x24, x24, #0x1
10066c164:     	cmp	x22, x23
10066c168:     	b.eq	0x10066c1f8
10066c16c:     	cbnz	x27, 0x10066c1bc
10066c170:     	ldr	x8, [x28, #0x10]
10066c174:     	cmp	x24, x8
10066c178:     	b.hs	0x10066c24c
10066c17c:     	add	x8, x21, x24, lsl #3
10066c180:     	ldr	x20, [x8, #0x20]
10066c184:     	mov	x0, x20
10066c188:     	bl	0x101aca978 ; symbol _swift_retain
10066c18c:     	adds	x22, x24, #0x1
10066c190:     	b.vs	0x10066c1d4
10066c194:     	cmp	x20, x19
10066c198:     	b.eq	0x10066c158
10066c19c:     	ldr	x8, [x20]
10066c1a0:     	ldr	x8, [x8, #0x578]
10066c1a4:     	blr	x8
10066c1a8:     	mov	x25, x0
10066c1ac:     	mov	x0, x20
10066c1b0:     	bl	0x101aca960 ; symbol _swift_release
10066c1b4:     	tbz	w25, #0x0, 0x10066c160
10066c1b8:     	b	0x10066c204
10066c1bc:     	mov	x0, x24
10066c1c0:     	mov	x1, x21
10066c1c4:     	bl	0x101ac75ac ; symbol _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
10066c1c8:     	mov	x20, x0
10066c1cc:     	adds	x22, x24, #0x1
10066c1d0:     	b.vc	0x10066c194
10066c1d4:     	brk	#0x1
10066c1d8:     	ldp	x29, x30, [sp, #0x70]
10066c1dc:     	ldp	x20, x19, [sp, #0x60]
10066c1e0:     	ldp	x22, x21, [sp, #0x50]
10066c1e4:     	ldp	x24, x23, [sp, #0x40]
10066c1e8:     	ldp	x26, x25, [sp, #0x30]
10066c1ec:     	ldp	x28, x27, [sp, #0x20]
10066c1f0:     	add	sp, sp, #0x80
10066c1f4:     	ret
10066c1f8:     	mov	x0, #0x33               ; =51
10066c1fc:     	movk	x0, #0x1000, lsl #48
10066c200:     	b	0x10066c214
10066c204:     	mov	x0, #0x33               ; =51
10066c208:     	movk	x0, #0x1000, lsl #48
10066c20c:     	add	x0, x0, #0x10
10066c210:     	ldr	x26, [sp, #0x8]
10066c214:     	ldr	x8, [x19]
10066c218:     	ldr	x8, [x8, #0x5d0]
10066c21c:     	orr	x1, x26, #0x8000000000000000
10066c220:     	mov	x20, x19
10066c224:     	blr	x8
10066c228:     	orr	x0, x26, #0x8000000000000000
10066c22c:     	ldp	x29, x30, [sp, #0x70]
10066c230:     	ldp	x20, x19, [sp, #0x60]
10066c234:     	ldp	x22, x21, [sp, #0x50]
10066c238:     	ldp	x24, x23, [sp, #0x40]
10066c23c:     	ldp	x26, x25, [sp, #0x30]
10066c240:     	ldp	x28, x27, [sp, #0x20]
10066c244:     	add	sp, sp, #0x80
10066c248:     	b	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c24c:     	brk	#0x1
10066c250:     	and	x8, x21, #0xffffffffffffff8
10066c254:     	cmn	x21, #0x1
10066c258:     	csel	x0, x8, x21, gt
10066c25c:     	bl	0x101ac7900 ; symbol _$ss18_CocoaArrayWrapperV8endIndexSivg
10066c260:     	mov	x23, x0
10066c264:     	b	0x10066c120
