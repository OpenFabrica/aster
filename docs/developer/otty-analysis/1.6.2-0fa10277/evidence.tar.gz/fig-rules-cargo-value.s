
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010140fc68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E>:
10140feac: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
10140feb0: a9014ff4    	stp	x20, x19, [sp, #0x10]
10140feb4: a9027bfd    	stp	x29, x30, [sp, #0x20]
10140feb8: 910083fd    	add	x29, sp, #0x20
10140febc: aa0203f3    	mov	x19, x2
10140fec0: aa0003f4    	mov	x20, x0
10140fec4: f100085f    	cmp	x2, #0x2
10140fec8: 54000403    	b.lo	0x10140ff48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2e0>
10140fecc: 39400028    	ldrb	w8, [x1]
10140fed0: 7100891f    	cmp	w8, #0x22
10140fed4: 540000c1    	b.ne	0x10140feec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x284>
10140fed8: 8b130028    	add	x8, x1, x19
10140fedc: 385ff108    	ldurb	w8, [x8, #-0x1]
10140fee0: 7100891f    	cmp	w8, #0x22
10140fee4: 54000100    	b.eq	0x10140ff04 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x29c>
10140fee8: 39400028    	ldrb	w8, [x1]
10140feec: 71009d1f    	cmp	w8, #0x27
10140fef0: 540002e1    	b.ne	0x10140ff4c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2e4>
10140fef4: 8b130028    	add	x8, x1, x19
10140fef8: 385ff108    	ldurb	w8, [x8, #-0x1]
10140fefc: 71009d1f    	cmp	w8, #0x27
10140ff00: 54000261    	b.ne	0x10140ff4c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2e4>
10140ff04: d1000663    	sub	x3, x19, #0x1
10140ff08: aa0103f6    	mov	x22, x1
10140ff0c: 38c01ec8    	ldrsb	w8, [x22, #0x1]!
10140ff10: 3101011f    	cmn	w8, #0x40
10140ff14: 540004eb    	b.lt	0x10140ffb0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x348>
10140ff18: 38e36828    	ldrsb	w8, [x1, x3]
10140ff1c: 3101011f    	cmn	w8, #0x40
10140ff20: 5400048b    	b.lt	0x10140ffb0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x348>
10140ff24: f1000a73    	subs	x19, x19, #0x2
10140ff28: 540002e0    	b.eq	0x10140ff84 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x31c>
10140ff2c: 97da39f1    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140ff30: aa1303e0    	mov	x0, x19
10140ff34: 52800021    	mov	w1, #0x1                ; =1
10140ff38: 97da39e8    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140ff3c: aa0003f5    	mov	x21, x0
10140ff40: b5000240    	cbnz	x0, 0x10140ff88 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x320>
10140ff44: 1400000a    	b	0x10140ff6c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x304>
10140ff48: b4000193    	cbz	x19, 0x10140ff78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x310>
10140ff4c: aa0103f5    	mov	x21, x1
10140ff50: 97da39e8    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140ff54: aa1303e0    	mov	x0, x19
10140ff58: 52800021    	mov	w1, #0x1                ; =1
10140ff5c: 97da39df    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140ff60: aa1503e1    	mov	x1, x21
10140ff64: aa0003f5    	mov	x21, x0
10140ff68: b50000a0    	cbnz	x0, 0x10140ff7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x314>
10140ff6c: 52800020    	mov	w0, #0x1                ; =1
10140ff70: aa1303e1    	mov	x1, x19
10140ff74: 941acd00    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140ff78: 52800035    	mov	w21, #0x1               ; =1
10140ff7c: aa1503e0    	mov	x0, x21
10140ff80: 14000004    	b	0x10140ff90 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x328>
10140ff84: 52800035    	mov	w21, #0x1               ; =1
10140ff88: aa1503e0    	mov	x0, x21
10140ff8c: aa1603e1    	mov	x1, x22
10140ff90: aa1303e2    	mov	x2, x19
10140ff94: 941ae725    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10140ff98: a9005693    	stp	x19, x21, [x20]
10140ff9c: f9000a93    	str	x19, [x20, #0x10]
10140ffa0: a9427bfd    	ldp	x29, x30, [sp, #0x20]
10140ffa4: a9414ff4    	ldp	x20, x19, [sp, #0x10]
10140ffa8: a8c357f6    	ldp	x22, x21, [sp], #0x30
10140ffac: d65f03c0    	ret
10140ffb0: b00072c4    	adrp	x4, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
10140ffb4: 9122e084    	add	x4, x4, #0x8b8
10140ffb8: aa0103e0    	mov	x0, x1
10140ffbc: aa1303e1    	mov	x1, x19
10140ffc0: 52800022    	mov	w2, #0x1                ; =1
10140ffc4: 941acd91    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
