
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010140b34c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E>:
10140e124: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10140e128: a90167fa    	stp	x26, x25, [sp, #0x10]
10140e12c: a9025ff8    	stp	x24, x23, [sp, #0x20]
10140e130: a90357f6    	stp	x22, x21, [sp, #0x30]
10140e134: a9044ff4    	stp	x20, x19, [sp, #0x40]
10140e138: a9057bfd    	stp	x29, x30, [sp, #0x50]
10140e13c: 910143fd    	add	x29, sp, #0x50
10140e140: d124c3ff    	sub	sp, sp, #0x930
10140e144: f90003ff    	str	xzr, [sp]
10140e148: f9401828    	ldr	x8, [x1, #0x30]
10140e14c: b4002ae8    	cbz	x8, 0x10140e6a8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x335c>
10140e150: aa0103f6    	mov	x22, x1
10140e154: a9405029    	ldp	x9, x20, [x1]
10140e158: a9414c28    	ldp	x8, x19, [x1, #0x10]
10140e15c: f90017e8    	str	x8, [sp, #0x28]
10140e160: a942202a    	ldp	x10, x8, [x1, #0x20]
10140e164: a90327ea    	stp	x10, x9, [sp, #0x30]
10140e168: a901a3e0    	stp	x0, x8, [sp, #0x18]
10140e16c: 910103e8    	add	x8, sp, #0x40
10140e170: 9100e020    	add	x0, x1, #0x38
10140e174: 940f6e87    	bl	0x1017e9b90 <__ZN75_$LT$std..fs..ReadDir$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h8142713fd293396eE>
10140e178: b94043e8    	ldr	w8, [sp, #0x40]
10140e17c: 7100051f    	cmp	w8, #0x1
10140e180: 54002921    	b.ne	0x10140e6a4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3358>
10140e184: f9401be8    	ldr	x8, [sp, #0x30]
10140e188: 8b080268    	add	x8, x19, x8
10140e18c: f9000be8    	str	x8, [sp, #0x10]
10140e190: f00072c8    	adrp	x8, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
10140e194: 9125e108    	add	x8, x8, #0x978
10140e198: f90007e8    	str	x8, [sp, #0x8]
10140e19c: 1400000b    	b	0x10140e1c8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2e7c>
10140e1a0: 92400728    	and	x8, x25, #0x3
10140e1a4: f100051f    	cmp	x8, #0x1
10140e1a8: 54000a20    	b.eq	0x10140e2ec <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2fa0>
10140e1ac: f9401ac8    	ldr	x8, [x22, #0x30]
10140e1b0: b40027a8    	cbz	x8, 0x10140e6a4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3358>
10140e1b4: 910103e8    	add	x8, sp, #0x40
10140e1b8: 9100e2c0    	add	x0, x22, #0x38
10140e1bc: 940f6e75    	bl	0x1017e9b90 <__ZN75_$LT$std..fs..ReadDir$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h8142713fd293396eE>
10140e1c0: b94043e8    	ldr	w8, [sp, #0x40]
10140e1c4: 36002708    	tbz	w8, #0x0, 0x10140e6a4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3358>
10140e1c8: a944e7f5    	ldp	x21, x25, [sp, #0x48]
10140e1cc: f9401ac8    	ldr	x8, [x22, #0x30]
10140e1d0: d1000508    	sub	x8, x8, #0x1
10140e1d4: f9001ac8    	str	x8, [x22, #0x30]
10140e1d8: b4fffe55    	cbz	x21, 0x10140e1a0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2e54>
10140e1dc: 9111a3e8    	add	x8, sp, #0x468
10140e1e0: 91004100    	add	x0, x8, #0x10
10140e1e4: 910103e8    	add	x8, sp, #0x40
10140e1e8: 91006101    	add	x1, x8, #0x18
10140e1ec: 52808202    	mov	w2, #0x410              ; =1040
10140e1f0: 941aee8e    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10140e1f4: f90237f5    	str	x21, [sp, #0x468]
10140e1f8: f9023bf9    	str	x25, [sp, #0x470]
10140e1fc: d10223a8    	sub	x8, x29, #0x88
10140e200: 9111a3e0    	add	x0, sp, #0x468
10140e204: 940e8cec    	bl	0x1017b15b4 <__ZN3std2fs8DirEntry9file_name17h6382942abec15980E>
10140e208: a97807b9    	ldp	x25, x1, [x29, #-0x80]
10140e20c: d103e3a8    	sub	x8, x29, #0xf8
10140e210: aa1903e0    	mov	x0, x25
10140e214: 94100162    	bl	0x10180e79c <__ZN5alloc6string6String15from_utf8_lossy17hcb81682812c4da7aE>
10140e218: a970ebbb    	ldp	x27, x26, [x29, #-0xf8]
10140e21c: f85183bc    	ldur	x28, [x29, #-0xe8]
10140e220: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140e224: eb08037f    	cmp	x27, x8
10140e228: 54000201    	b.ne	0x10140e268 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2f1c>
10140e22c: b400011c    	cbz	x28, 0x10140e24c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2f00>
10140e230: 97da4130    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140e234: aa1c03e0    	mov	x0, x28
10140e238: 52800021    	mov	w1, #0x1                ; =1
10140e23c: 97da4127    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140e240: aa0003f7    	mov	x23, x0
10140e244: b5000060    	cbnz	x0, 0x10140e250 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2f04>
10140e248: 1400012b    	b	0x10140e6f4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x33a8>
10140e24c: 52800037    	mov	w23, #0x1               ; =1
10140e250: aa1703e0    	mov	x0, x23
10140e254: aa1a03e1    	mov	x1, x26
10140e258: aa1c03e2    	mov	x2, x28
10140e25c: 941aee73    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10140e260: aa1703fa    	mov	x26, x23
10140e264: aa1c03fb    	mov	x27, x28
10140e268: f85783a1    	ldur	x1, [x29, #-0x88]
10140e26c: b4000081    	cbz	x1, 0x10140e27c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2f30>
10140e270: aa1903e0    	mov	x0, x25
10140e274: 52800022    	mov	w2, #0x1                ; =1
10140e278: 97da4119    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e27c: f9401fe8    	ldr	x8, [sp, #0x38]
10140e280: 39400108    	ldrb	w8, [x8]
10140e284: 7100051f    	cmp	w8, #0x1
10140e288: 540000a0    	b.eq	0x10140e29c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2f50>
10140e28c: b400009c    	cbz	x28, 0x10140e29c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2f50>
10140e290: 39400348    	ldrb	w8, [x26]
10140e294: 7100b91f    	cmp	w8, #0x2e
10140e298: 540009a0    	b.eq	0x10140e3cc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3080>
10140e29c: f9400a88    	ldr	x8, [x20, #0x10]
10140e2a0: b4000508    	cbz	x8, 0x10140e340 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2ff4>
10140e2a4: d10223a8    	sub	x8, x29, #0x88
10140e2a8: aa1a03e0    	mov	x0, x26
10140e2ac: aa1c03e1    	mov	x1, x28
10140e2b0: 940ff521    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
10140e2b4: a97823b9    	ldp	x25, x8, [x29, #-0x80]
10140e2b8: f9400a82    	ldr	x2, [x20, #0x10]
10140e2bc: eb02011f    	cmp	x8, x2
10140e2c0: 540000a3    	b.lo	0x10140e2d4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2f88>
10140e2c4: f9400680    	ldr	x0, [x20, #0x8]
10140e2c8: aa1903e1    	mov	x1, x25
10140e2cc: 941aee54    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10140e2d0: 340002e0    	cbz	w0, 0x10140e32c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2fe0>
10140e2d4: f85783a1    	ldur	x1, [x29, #-0x88]
10140e2d8: b40007a1    	cbz	x1, 0x10140e3cc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3080>
10140e2dc: aa1903e0    	mov	x0, x25
10140e2e0: 52800022    	mov	w2, #0x1                ; =1
10140e2e4: 97da40fe    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e2e8: 14000039    	b	0x10140e3cc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3080>
10140e2ec: f85fff3a    	ldr	x26, [x25, #-0x1]!
10140e2f0: f9400735    	ldr	x21, [x25, #0x8]
10140e2f4: f94002a8    	ldr	x8, [x21]
10140e2f8: b4000068    	cbz	x8, 0x10140e304 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2fb8>
10140e2fc: aa1a03e0    	mov	x0, x26
10140e300: d63f0100    	blr	x8
10140e304: f94006a1    	ldr	x1, [x21, #0x8]
10140e308: b4000081    	cbz	x1, 0x10140e318 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2fcc>
10140e30c: f9400aa2    	ldr	x2, [x21, #0x10]
10140e310: aa1a03e0    	mov	x0, x26
10140e314: 97da40f2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e318: aa1903e0    	mov	x0, x25
10140e31c: 52800301    	mov	w1, #0x18               ; =24
10140e320: 52800102    	mov	w2, #0x8                ; =8
10140e324: 97da40ee    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e328: 17ffffa1    	b	0x10140e1ac <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2e60>
10140e32c: f85783a1    	ldur	x1, [x29, #-0x88]
10140e330: b4000081    	cbz	x1, 0x10140e340 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2ff4>
10140e334: aa1903e0    	mov	x0, x25
10140e338: 52800022    	mov	w2, #0x1                ; =1
10140e33c: 97da40e8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e340: d10223a8    	sub	x8, x29, #0x88
10140e344: 9111a3e0    	add	x0, sp, #0x468
10140e348: 940e8c63    	bl	0x1017b14d4 <__ZN3std2fs8DirEntry4path17hb370d900e38be2caE>
10140e34c: a97807b7    	ldp	x23, x1, [x29, #-0x80]
10140e350: aa1703e0    	mov	x0, x23
10140e354: 940ed833    	bl	0x1017c4420 <__ZN3std4path4Path6is_dir17hdaadc6576e56c526E>
10140e358: aa0003f9    	mov	x25, x0
10140e35c: f85783a1    	ldur	x1, [x29, #-0x88]
10140e360: b4000081    	cbz	x1, 0x10140e370 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3024>
10140e364: aa1703e0    	mov	x0, x23
10140e368: 52800022    	mov	w2, #0x1                ; =1
10140e36c: 97da40dc    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e370: f94017e8    	ldr	x8, [sp, #0x28]
10140e374: 39400108    	ldrb	w8, [x8]
10140e378: 2a080328    	orr	w8, w25, w8
10140e37c: 36000288    	tbz	w8, #0x0, 0x10140e3cc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3080>
10140e380: f94013e8    	ldr	x8, [sp, #0x20]
10140e384: 39400108    	ldrb	w8, [x8]
10140e388: f9401be9    	ldr	x9, [sp, #0x30]
10140e38c: a93427b3    	stp	x19, x9, [x29, #-0xc0]
10140e390: a93573ba    	stp	x26, x28, [x29, #-0xb0]
10140e394: 36000348    	tbz	w8, #0x0, 0x10140e3fc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x30b0>
10140e398: d10303a8    	sub	x8, x29, #0xc0
10140e39c: f81783a8    	stur	x8, [x29, #-0x88]
10140e3a0: b0000208    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
10140e3a4: 91117108    	add	x8, x8, #0x45c
10140e3a8: d102c3a9    	sub	x9, x29, #0xb0
10140e3ac: a93827a8    	stp	x8, x9, [x29, #-0x80]
10140e3b0: f81903a8    	stur	x8, [x29, #-0x70]
10140e3b4: d103e3a8    	sub	x8, x29, #0xf8
10140e3b8: d10223a1    	sub	x1, x29, #0x88
10140e3bc: b0005060    	adrp	x0, 0x101e1b000 <_writev+0x101e1b000>
10140e3c0: 9102d000    	add	x0, x0, #0xb4
10140e3c4: 940ff46f    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
10140e3c8: 14000086    	b	0x10140e5e0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3294>
10140e3cc: b40000bb    	cbz	x27, 0x10140e3e0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3094>
10140e3d0: aa1a03e0    	mov	x0, x26
10140e3d4: aa1b03e1    	mov	x1, x27
10140e3d8: 52800022    	mov	w2, #0x1                ; =1
10140e3dc: 97da40c0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e3e0: f94237e8    	ldr	x8, [sp, #0x468]
10140e3e4: 92800009    	mov	x9, #-0x1               ; =-1
10140e3e8: f8690108    	ldaddl	x9, x8, [x8]
10140e3ec: f100051f    	cmp	x8, #0x1
10140e3f0: 54ffede1    	b.ne	0x10140e1ac <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2e60>
10140e3f4: d2f00017    	mov	x23, #-0x8000000000000000 ; =-9223372036854775808
10140e3f8: 1400009a    	b	0x10140e660 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3314>
10140e3fc: f9400be8    	ldr	x8, [sp, #0x10]
10140e400: 14000004    	b	0x10140e410 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x30c4>
10140e404: aa0a03e8    	mov	x8, x10
10140e408: 7100bd3f    	cmp	w9, #0x2f
10140e40c: 54000460    	b.eq	0x10140e498 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x314c>
10140e410: eb08027f    	cmp	x19, x8
10140e414: 54000540    	b.eq	0x10140e4bc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3170>
10140e418: aa0803ea    	mov	x10, x8
10140e41c: 38dffd49    	ldrsb	w9, [x10, #-0x1]!
10140e420: 36ffff29    	tbz	w9, #0x1f, 0x10140e404 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x30b8>
10140e424: aa0803eb    	mov	x11, x8
10140e428: 38dfed6a    	ldrsb	w10, [x11, #-0x2]!
10140e42c: 3101015f    	cmn	w10, #0x40
10140e430: 5400014a    	b.ge	0x10140e458 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x310c>
10140e434: aa0803ec    	mov	x12, x8
10140e438: 38dfdd8b    	ldrsb	w11, [x12, #-0x3]!
10140e43c: 3101017f    	cmn	w11, #0x40
10140e440: 540001aa    	b.ge	0x10140e474 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3128>
10140e444: 12001d6b    	and	w11, w11, #0xff
10140e448: 385fcd0c    	ldrb	w12, [x8, #-0x4]!
10140e44c: 1200156b    	and	w11, w11, #0x3f
10140e450: 331a098b    	bfi	w11, w12, #6, #3
10140e454: 1400000a    	b	0x10140e47c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3130>
10140e458: 1200114a    	and	w10, w10, #0x1f
10140e45c: aa0b03e8    	mov	x8, x11
10140e460: 12001529    	and	w9, w9, #0x3f
10140e464: 2a0a1929    	orr	w9, w9, w10, lsl #6
10140e468: 7100bd3f    	cmp	w9, #0x2f
10140e46c: 54fffd21    	b.ne	0x10140e410 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x30c4>
10140e470: 1400000a    	b	0x10140e498 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x314c>
10140e474: 12000d6b    	and	w11, w11, #0xf
10140e478: aa0c03e8    	mov	x8, x12
10140e47c: 12001d4a    	and	w10, w10, #0xff
10140e480: 1200154a    	and	w10, w10, #0x3f
10140e484: 2a0b194a    	orr	w10, w10, w11, lsl #6
10140e488: 12001529    	and	w9, w9, #0x3f
10140e48c: 2a0a1929    	orr	w9, w9, w10, lsl #6
10140e490: 7100bd3f    	cmp	w9, #0x2f
10140e494: 54fffbe1    	b.ne	0x10140e410 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x30c4>
10140e498: eb130103    	subs	x3, x8, x19
10140e49c: 54000480    	b.eq	0x10140e52c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x31e0>
10140e4a0: f9401be8    	ldr	x8, [sp, #0x30]
10140e4a4: eb08007f    	cmp	x3, x8
10140e4a8: 54000502    	b.hs	0x10140e548 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x31fc>
10140e4ac: 38e36a68    	ldrsb	w8, [x19, x3]
10140e4b0: 3101051f    	cmn	w8, #0x41
10140e4b4: 540004cc    	b.gt	0x10140e54c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3200>
10140e4b8: 14000097    	b	0x10140e714 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x33c8>
10140e4bc: b400011c    	cbz	x28, 0x10140e4dc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3190>
10140e4c0: 97da408c    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140e4c4: aa1c03e0    	mov	x0, x28
10140e4c8: 52800021    	mov	w1, #0x1                ; =1
10140e4cc: 97da4083    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140e4d0: aa0003f7    	mov	x23, x0
10140e4d4: b5000060    	cbnz	x0, 0x10140e4e0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3194>
10140e4d8: 1400008b    	b	0x10140e704 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x33b8>
10140e4dc: 52800037    	mov	w23, #0x1               ; =1
10140e4e0: aa1703e0    	mov	x0, x23
10140e4e4: aa1a03e1    	mov	x1, x26
10140e4e8: aa1c03e2    	mov	x2, x28
10140e4ec: 941aedcf    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10140e4f0: a930dfbc    	stp	x28, x23, [x29, #-0xf8]
10140e4f4: f81183bc    	stur	x28, [x29, #-0xe8]
10140e4f8: 35000779    	cbnz	w25, 0x10140e5e4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3298>
10140e4fc: 3cd083a0    	ldur	q0, [x29, #-0xf8]
10140e500: 3c9203a0    	stur	q0, [x29, #-0xe0]
10140e504: a971dfb9    	ldp	x25, x23, [x29, #-0xe8]
10140e508: f81303b9    	stur	x25, [x29, #-0xd0]
10140e50c: f85283b5    	ldur	x21, [x29, #-0xd8]
10140e510: 52800078    	mov	w24, #0x3               ; =3
10140e514: f94237e8    	ldr	x8, [sp, #0x468]
10140e518: 92800009    	mov	x9, #-0x1               ; =-1
10140e51c: f8690108    	ldaddl	x9, x8, [x8]
10140e520: f100051f    	cmp	x8, #0x1
10140e524: 54000a41    	b.ne	0x10140e66c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3320>
10140e528: 1400004e    	b	0x10140e660 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3314>
10140e52c: f9401be8    	ldr	x8, [sp, #0x30]
10140e530: f100051f    	cmp	x8, #0x1
10140e534: 54000389    	b.ls	0x10140e5a4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3258>
10140e538: 39c00668    	ldrsb	w8, [x19, #0x1]
10140e53c: 3101051f    	cmn	w8, #0x41
10140e540: 5400034c    	b.gt	0x10140e5a8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x325c>
10140e544: 14000078    	b	0x10140e724 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x33d8>
10140e548: 54000e61    	b.ne	0x10140e714 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x33c8>
10140e54c: a9360fb3    	stp	x19, x3, [x29, #-0xa0]
10140e550: aa1303e0    	mov	x0, x19
10140e554: f9401be1    	ldr	x1, [sp, #0x30]
10140e558: 9400eda0    	bl	0x101449bd8 <__ZN17otty_autocomplete7sources6is_dir17h36378ede18c97a36E+0x4>
10140e55c: b81743a0    	stur	w0, [x29, #-0x8c]
10140e560: d10283a8    	sub	x8, x29, #0xa0
10140e564: f81783a8    	stur	x8, [x29, #-0x88]
10140e568: b0000208    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
10140e56c: 91117108    	add	x8, x8, #0x45c
10140e570: d10233a9    	sub	x9, x29, #0x8c
10140e574: a93827a8    	stp	x8, x9, [x29, #-0x80]
10140e578: d0002009    	adrp	x9, 0x101810000 <__ZN92_$LT$alloc..borrow..Cow$LT$str$GT$$u20$as$u20$core..ops..arith..AddAssign$LT$$RF$str$GT$$GT$10add_assign17h2c4b02baf6f14f7dE+0x440>
10140e57c: 912ab12a    	add	x10, x9, #0xaac
10140e580: d102c3a9    	sub	x9, x29, #0xb0
10140e584: a93927aa    	stp	x10, x9, [x29, #-0x70]
10140e588: f81a03a8    	stur	x8, [x29, #-0x60]
10140e58c: d103e3a8    	sub	x8, x29, #0xf8
10140e590: d10223a1    	sub	x1, x29, #0x88
10140e594: b0004f80    	adrp	x0, 0x101dff000 <_writev+0x101dff000>
10140e598: 9117ec00    	add	x0, x0, #0x5fb
10140e59c: 940ff3f9    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
10140e5a0: 14000010    	b	0x10140e5e0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3294>
10140e5a4: 54000c01    	b.ne	0x10140e724 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x33d8>
10140e5a8: 52800028    	mov	w8, #0x1                ; =1
10140e5ac: a93623b3    	stp	x19, x8, [x29, #-0xa0]
10140e5b0: d10283a8    	sub	x8, x29, #0xa0
10140e5b4: f81783a8    	stur	x8, [x29, #-0x88]
10140e5b8: b0000208    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
10140e5bc: 91117108    	add	x8, x8, #0x45c
10140e5c0: d102c3a9    	sub	x9, x29, #0xb0
10140e5c4: a93827a8    	stp	x8, x9, [x29, #-0x80]
10140e5c8: f81903a8    	stur	x8, [x29, #-0x70]
10140e5cc: d103e3a8    	sub	x8, x29, #0xf8
10140e5d0: d10223a1    	sub	x1, x29, #0x88
10140e5d4: b0005060    	adrp	x0, 0x101e1b000 <_writev+0x101e1b000>
10140e5d8: 9102d000    	add	x0, x0, #0xb4
10140e5dc: 940ff3e9    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
10140e5e0: 34fff8f9    	cbz	w25, 0x10140e4fc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x31b0>
10140e5e4: aa1303e0    	mov	x0, x19
10140e5e8: f9401be1    	ldr	x1, [sp, #0x30]
10140e5ec: 9400ed7b    	bl	0x101449bd8 <__ZN17otty_autocomplete7sources6is_dir17h36378ede18c97a36E+0x4>
10140e5f0: b81603a0    	stur	w0, [x29, #-0xa0]
10140e5f4: d103e3a8    	sub	x8, x29, #0xf8
10140e5f8: f81783a8    	stur	x8, [x29, #-0x88]
10140e5fc: b00002e8    	adrp	x8, 0x10146b000 <__ZN4core5slice4sort8unstable8heapsort8heapsort17h14b311923aeea277E+0x3bbc>
10140e600: 913b4109    	add	x9, x8, #0xed0
10140e604: d10283a8    	sub	x8, x29, #0xa0
10140e608: a93823a9    	stp	x9, x8, [x29, #-0x80]
10140e60c: d0002008    	adrp	x8, 0x101810000 <__ZN92_$LT$alloc..borrow..Cow$LT$str$GT$$u20$as$u20$core..ops..arith..AddAssign$LT$$RF$str$GT$$GT$10add_assign17h2c4b02baf6f14f7dE+0x440>
10140e610: 912ab108    	add	x8, x8, #0xaac
10140e614: f81903a8    	stur	x8, [x29, #-0x70]
10140e618: d10383a8    	sub	x8, x29, #0xe0
10140e61c: d10223a1    	sub	x1, x29, #0x88
10140e620: b0005060    	adrp	x0, 0x101e1b000 <_writev+0x101e1b000>
10140e624: 9102d000    	add	x0, x0, #0xb4
10140e628: 940ff3d6    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
10140e62c: a97257b7    	ldp	x23, x21, [x29, #-0xe0]
10140e630: f85303b9    	ldur	x25, [x29, #-0xd0]
10140e634: f85083a1    	ldur	x1, [x29, #-0xf8]
10140e638: b4000281    	cbz	x1, 0x10140e688 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x333c>
10140e63c: f85103a0    	ldur	x0, [x29, #-0xf0]
10140e640: 52800022    	mov	w2, #0x1                ; =1
10140e644: 97da4026    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e648: 52800098    	mov	w24, #0x4               ; =4
10140e64c: f94237e8    	ldr	x8, [sp, #0x468]
10140e650: 92800009    	mov	x9, #-0x1               ; =-1
10140e654: f8690108    	ldaddl	x9, x8, [x8]
10140e658: f100051f    	cmp	x8, #0x1
10140e65c: 54000081    	b.ne	0x10140e66c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3320>
10140e660: d50339bf    	dmb	ishld
10140e664: 9111a3e0    	add	x0, sp, #0x468
10140e668: 940f3849    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
10140e66c: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10140e670: eb0802ff    	cmp	x23, x8
10140e674: 54ffda00    	b.eq	0x10140e1b4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2e68>
10140e678: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140e67c: eb0802ff    	cmp	x23, x8
10140e680: 54ffd960    	b.eq	0x10140e1ac <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2e60>
10140e684: 14000013    	b	0x10140e6d0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3384>
10140e688: 52800098    	mov	w24, #0x4               ; =4
10140e68c: f94237e8    	ldr	x8, [sp, #0x468]
10140e690: 92800009    	mov	x9, #-0x1               ; =-1
10140e694: f8690108    	ldaddl	x9, x8, [x8]
10140e698: f100051f    	cmp	x8, #0x1
10140e69c: 54fffe81    	b.ne	0x10140e66c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3320>
10140e6a0: 17fffff0    	b	0x10140e660 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3314>
10140e6a4: f9400fe0    	ldr	x0, [sp, #0x18]
10140e6a8: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140e6ac: f9000008    	str	x8, [x0]
10140e6b0: 9124c3ff    	add	sp, sp, #0x930
10140e6b4: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10140e6b8: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10140e6bc: a94357f6    	ldp	x22, x21, [sp, #0x30]
10140e6c0: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10140e6c4: a94167fa    	ldp	x26, x25, [sp, #0x10]
10140e6c8: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10140e6cc: d65f03c0    	ret
10140e6d0: f9400fe9    	ldr	x9, [sp, #0x18]
10140e6d4: a9005537    	stp	x23, x21, [x9]
10140e6d8: a9016d39    	stp	x25, x27, [x9, #0x10]
10140e6dc: a902713a    	stp	x26, x28, [x9, #0x20]
10140e6e0: f9001928    	str	x8, [x9, #0x30]
10140e6e4: f9002528    	str	x8, [x9, #0x48]
10140e6e8: 3901813f    	strb	wzr, [x9, #0x60]
10140e6ec: 39018538    	strb	w24, [x9, #0x61]
10140e6f0: 17fffff0    	b	0x10140e6b0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3364>
10140e6f4: 52800020    	mov	w0, #0x1                ; =1
10140e6f8: aa1c03e1    	mov	x1, x28
10140e6fc: 941ad31e    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140e700: 1400000f    	b	0x10140e73c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x33f0>
10140e704: 52800020    	mov	w0, #0x1                ; =1
10140e708: aa1c03e1    	mov	x1, x28
10140e70c: 941ad31a    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140e710: 1400000b    	b	0x10140e73c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x33f0>
10140e714: f00072c8    	adrp	x8, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
10140e718: 91264108    	add	x8, x8, #0x990
10140e71c: f90007e8    	str	x8, [sp, #0x8]
10140e720: 14000002    	b	0x10140e728 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x33dc>
10140e724: 52800023    	mov	w3, #0x1                ; =1
10140e728: aa1303e0    	mov	x0, x19
10140e72c: f9401be1    	ldr	x1, [sp, #0x30]
10140e730: d2800002    	mov	x2, #0x0                ; =0
10140e734: f94007e4    	ldr	x4, [sp, #0x8]
10140e738: 941ad3b4    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
10140e73c: d4200020    	brk	#0x1
10140e740: 14000021    	b	0x10140e7c4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3478>
10140e744: aa0003f3    	mov	x19, x0
10140e748: f94006a1    	ldr	x1, [x21, #0x8]
10140e74c: b4000081    	cbz	x1, 0x10140e75c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3410>
10140e750: f9400aa2    	ldr	x2, [x21, #0x10]
10140e754: aa1a03e0    	mov	x0, x26
10140e758: 97da3fe1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e75c: aa1903e0    	mov	x0, x25
10140e760: 52800301    	mov	w1, #0x18               ; =24
10140e764: 52800102    	mov	w2, #0x8                ; =8
10140e768: 97da3fdd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e76c: aa1303e0    	mov	x0, x19
10140e770: 941aeb99    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140e774: aa0003f3    	mov	x19, x0
10140e778: f85083a1    	ldur	x1, [x29, #-0xf8]
10140e77c: b4000261    	cbz	x1, 0x10140e7c8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x347c>
10140e780: f85103a0    	ldur	x0, [x29, #-0xf0]
10140e784: 14000006    	b	0x10140e79c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3450>
10140e788: 14000008    	b	0x10140e7a8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x345c>
10140e78c: aa0003f3    	mov	x19, x0
10140e790: f85783a1    	ldur	x1, [x29, #-0x88]
10140e794: b40001a1    	cbz	x1, 0x10140e7c8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x347c>
10140e798: aa1703e0    	mov	x0, x23
10140e79c: 52800022    	mov	w2, #0x1                ; =1
10140e7a0: 97da3fcf    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e7a4: 14000009    	b	0x10140e7c8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x347c>
10140e7a8: aa0003f3    	mov	x19, x0
10140e7ac: f85783a1    	ldur	x1, [x29, #-0x88]
10140e7b0: b4000161    	cbz	x1, 0x10140e7dc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3490>
10140e7b4: aa1903e0    	mov	x0, x25
10140e7b8: 14000007    	b	0x10140e7d4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3488>
10140e7bc: aa0003f3    	mov	x19, x0
10140e7c0: 14000007    	b	0x10140e7dc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3490>
10140e7c4: aa0003f3    	mov	x19, x0
10140e7c8: b40000bb    	cbz	x27, 0x10140e7dc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3490>
10140e7cc: aa1a03e0    	mov	x0, x26
10140e7d0: aa1b03e1    	mov	x1, x27
10140e7d4: 52800022    	mov	w2, #0x1                ; =1
10140e7d8: 97da3fc1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e7dc: f94237e8    	ldr	x8, [sp, #0x468]
10140e7e0: 92800009    	mov	x9, #-0x1               ; =-1
10140e7e4: f8690108    	ldaddl	x9, x8, [x8]
10140e7e8: f100051f    	cmp	x8, #0x1
10140e7ec: 54000081    	b.ne	0x10140e7fc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x34b0>
10140e7f0: d50339bf    	dmb	ishld
10140e7f4: 9111a3e0    	add	x0, sp, #0x468
10140e7f8: 940f37e5    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
10140e7fc: aa1303e0    	mov	x0, x19
10140e800: 941aeb75    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140e804: 941ad548    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
10140e808: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
10140e80c: a90157f6    	stp	x22, x21, [sp, #0x10]
10140e810: a9024ff4    	stp	x20, x19, [sp, #0x20]
10140e814: a9037bfd    	stp	x29, x30, [sp, #0x30]
10140e818: 9100c3fd    	add	x29, sp, #0x30
10140e81c: aa0103f3    	mov	x19, x1
10140e820: aa0003f4    	mov	x20, x0
10140e824: f9400435    	ldr	x21, [x1, #0x8]
10140e828: f9400c28    	ldr	x8, [x1, #0x18]
10140e82c: cb150116    	sub	x22, x8, x21
10140e830: d343fec8    	lsr	x8, x22, #3
10140e834: d289d8a9    	mov	x9, #0x4ec5             ; =20165
10140e838: f2b89d89    	movk	x9, #0xc4ec, lsl #16
10140e83c: f2dd89c9    	movk	x9, #0xec4e, lsl #32
10140e840: f2e9d889    	movk	x9, #0x4ec4, lsl #48
10140e844: 9b097d17    	mul	x23, x8, x9
10140e848: f9400818    	ldr	x24, [x0, #0x10]
10140e84c: f9400008    	ldr	x8, [x0]
10140e850: cb180108    	sub	x8, x8, x24
10140e854: eb0802ff    	cmp	x23, x8
10140e858: 54000328    	b.hi	0x10140e8bc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3570>
10140e85c: f9400688    	ldr	x8, [x20, #0x8]
10140e860: 52800d09    	mov	w9, #0x68               ; =104
10140e864: 9b092300    	madd	x0, x24, x9, x8
10140e868: aa1503e1    	mov	x1, x21
10140e86c: aa1603e2    	mov	x2, x22
10140e870: 941aecee    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10140e874: 8b170308    	add	x8, x24, x23
10140e878: f9000a88    	str	x8, [x20, #0x10]
10140e87c: f9400a68    	ldr	x8, [x19, #0x10]
10140e880: b4000148    	cbz	x8, 0x10140e8a8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x355c>
10140e884: f9400260    	ldr	x0, [x19]
10140e888: 52800d09    	mov	w9, #0x68               ; =104
10140e88c: 9b097d01    	mul	x1, x8, x9
10140e890: 52800102    	mov	w2, #0x8                ; =8
10140e894: a9437bfd    	ldp	x29, x30, [sp, #0x30]
10140e898: a9424ff4    	ldp	x20, x19, [sp, #0x20]
10140e89c: a94157f6    	ldp	x22, x21, [sp, #0x10]
10140e8a0: a8c45ff8    	ldp	x24, x23, [sp], #0x40
10140e8a4: 17da3f8e    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e8a8: a9437bfd    	ldp	x29, x30, [sp, #0x30]
10140e8ac: a9424ff4    	ldp	x20, x19, [sp, #0x20]
10140e8b0: a94157f6    	ldp	x22, x21, [sp, #0x10]
10140e8b4: a8c45ff8    	ldp	x24, x23, [sp], #0x40
10140e8b8: d65f03c0    	ret
10140e8bc: aa1403e0    	mov	x0, x20
10140e8c0: aa1803e1    	mov	x1, x24
10140e8c4: aa1703e2    	mov	x2, x23
10140e8c8: 52800103    	mov	w3, #0x8                ; =8
10140e8cc: 52800d04    	mov	w4, #0x68               ; =104
10140e8d0: 941867e0    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10140e8d4: f9400a98    	ldr	x24, [x20, #0x10]
10140e8d8: 17ffffe1    	b	0x10140e85c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3510>
10140e8dc: aa0003f4    	mov	x20, x0
10140e8e0: aa1303e0    	mov	x0, x19
10140e8e4: 9401111d    	bl	0x101452d58 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x58d0>
10140e8e8: aa1403e0    	mov	x0, x20
10140e8ec: 941aeb3a    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140e8f0: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
10140e8f4: a90157f6    	stp	x22, x21, [sp, #0x10]
10140e8f8: a9024ff4    	stp	x20, x19, [sp, #0x20]
10140e8fc: a9037bfd    	stp	x29, x30, [sp, #0x30]
10140e900: 9100c3fd    	add	x29, sp, #0x30
10140e904: aa0103f3    	mov	x19, x1
10140e908: aa0003f4    	mov	x20, x0
10140e90c: f9400435    	ldr	x21, [x1, #0x8]
10140e910: f9400c28    	ldr	x8, [x1, #0x18]
10140e914: cb150116    	sub	x22, x8, x21
10140e918: d343fec8    	lsr	x8, x22, #3
10140e91c: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
10140e920: f2955569    	movk	x9, #0xaaab
10140e924: 9b097d17    	mul	x23, x8, x9
10140e928: f9400818    	ldr	x24, [x0, #0x10]
10140e92c: f9400008    	ldr	x8, [x0]
10140e930: cb180108    	sub	x8, x8, x24
10140e934: eb0802ff    	cmp	x23, x8
10140e938: 54000328    	b.hi	0x10140e99c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x3650>
10140e93c: f9400688    	ldr	x8, [x20, #0x8]
10140e940: 52800309    	mov	w9, #0x18               ; =24
10140e944: 9b092300    	madd	x0, x24, x9, x8
10140e948: aa1503e1    	mov	x1, x21
10140e94c: aa1603e2    	mov	x2, x22
10140e950: 941aecb6    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10140e954: 8b170308    	add	x8, x24, x23
10140e958: f9000a88    	str	x8, [x20, #0x10]
10140e95c: f9400a68    	ldr	x8, [x19, #0x10]
10140e960: b4000148    	cbz	x8, 0x10140e988 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x363c>
10140e964: f9400260    	ldr	x0, [x19]
10140e968: 8b080508    	add	x8, x8, x8, lsl #1
10140e96c: d37df101    	lsl	x1, x8, #3
10140e970: 52800102    	mov	w2, #0x8                ; =8
10140e974: a9437bfd    	ldp	x29, x30, [sp, #0x30]
10140e978: a9424ff4    	ldp	x20, x19, [sp, #0x20]
10140e97c: a94157f6    	ldp	x22, x21, [sp, #0x10]
10140e980: a8c45ff8    	ldp	x24, x23, [sp], #0x40
10140e984: 17da3f56    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e988: a9437bfd    	ldp	x29, x30, [sp, #0x30]
10140e98c: a9424ff4    	ldp	x20, x19, [sp, #0x20]
10140e990: a94157f6    	ldp	x22, x21, [sp, #0x10]
10140e994: a8c45ff8    	ldp	x24, x23, [sp], #0x40
10140e998: d65f03c0    	ret
10140e99c: aa1403e0    	mov	x0, x20
10140e9a0: aa1803e1    	mov	x1, x24
10140e9a4: aa1703e2    	mov	x2, x23
10140e9a8: 52800103    	mov	w3, #0x8                ; =8
10140e9ac: 52800304    	mov	w4, #0x18               ; =24
10140e9b0: 941867a8    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10140e9b4: f9400a98    	ldr	x24, [x20, #0x10]
10140e9b8: 17ffffe1    	b	0x10140e93c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x35f0>
10140e9bc: aa0003f4    	mov	x20, x0
10140e9c0: aa1303e0    	mov	x0, x19
10140e9c4: 97d48991    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
10140e9c8: aa1403e0    	mov	x0, x20
10140e9cc: 941aeb02    	bl	0x101ac95d4 <_writev+0x101ac95d4>
