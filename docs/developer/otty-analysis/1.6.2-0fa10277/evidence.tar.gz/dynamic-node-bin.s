
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001013fdd28 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE>:
1013fe1ac: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
1013fe1b0: a90167fa    	stp	x26, x25, [sp, #0x10]
1013fe1b4: a9025ff8    	stp	x24, x23, [sp, #0x20]
1013fe1b8: a90357f6    	stp	x22, x21, [sp, #0x30]
1013fe1bc: a9044ff4    	stp	x20, x19, [sp, #0x40]
1013fe1c0: a9057bfd    	stp	x29, x30, [sp, #0x50]
1013fe1c4: 910143fd    	add	x29, sp, #0x50
1013fe1c8: d132c3ff    	sub	sp, sp, #0xcb0
1013fe1cc: f90003ff    	str	xzr, [sp]
1013fe1d0: f9443028    	ldr	x8, [x1, #0x860]
1013fe1d4: b4001328    	cbz	x8, 0x1013fe438 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x710>
1013fe1d8: aa0103f5    	mov	x21, x1
1013fe1dc: 39616028    	ldrb	w8, [x1, #0x858]
1013fe1e0: 7100091f    	cmp	w8, #0x2
1013fe1e4: 540012a0    	b.eq	0x1013fe438 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x710>
1013fe1e8: f94436a8    	ldr	x8, [x21, #0x868]
1013fe1ec: a90023e0    	stp	x0, x8, [sp]
1013fe1f0: 912142b6    	add	x22, x21, #0x850
1013fe1f4: 910043f7    	add	x23, sp, #0x10
1013fe1f8: 910043e8    	add	x8, sp, #0x10
1013fe1fc: aa1603e0    	mov	x0, x22
1013fe200: 940fae64    	bl	0x1017e9b90 <__ZN75_$LT$std..fs..ReadDir$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h8142713fd293396eE>
1013fe204: b94013e8    	ldr	w8, [sp, #0x10]
1013fe208: 7100051f    	cmp	w8, #0x1
1013fe20c: 54000fa1    	b.ne	0x1013fe400 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x6d8>
1013fe210: b24107f3    	mov	x19, #-0x7fffffffffffffff ; =-9223372036854775807
1013fe214: 14000008    	b	0x1013fe234 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x50c>
1013fe218: eb13031f    	cmp	x24, x19
1013fe21c: 54001221    	b.ne	0x1013fe460 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x738>
1013fe220: 910043e8    	add	x8, sp, #0x10
1013fe224: aa1603e0    	mov	x0, x22
1013fe228: 940fae5a    	bl	0x1017e9b90 <__ZN75_$LT$std..fs..ReadDir$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h8142713fd293396eE>
1013fe22c: b94013e8    	ldr	w8, [sp, #0x10]
1013fe230: 36000e88    	tbz	w8, #0x0, 0x1013fe400 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x6d8>
1013fe234: a941e3f9    	ldp	x25, x24, [sp, #0x18]
1013fe238: b40005b9    	cbz	x25, 0x1013fe2ec <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x5c4>
1013fe23c: f90223f8    	str	x24, [sp, #0x440]
1013fe240: 9110e3e8    	add	x8, sp, #0x438
1013fe244: 91004100    	add	x0, x8, #0x10
1013fe248: 910062e1    	add	x1, x23, #0x18
1013fe24c: 52808202    	mov	w2, #0x410              ; =1040
1013fe250: 941b2e76    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1013fe254: f9021fff    	str	xzr, [sp, #0x438]
1013fe258: f90433f8    	str	x24, [sp, #0x860]
1013fe25c: 912163e8    	add	x8, sp, #0x858
1013fe260: 91004100    	add	x0, x8, #0x10
1013fe264: 910062e1    	add	x1, x23, #0x18
1013fe268: 52808202    	mov	w2, #0x410              ; =1040
1013fe26c: 941b2e6f    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1013fe270: f94432a8    	ldr	x8, [x21, #0x860]
1013fe274: d1000508    	sub	x8, x8, #0x1
1013fe278: f90432a8    	str	x8, [x21, #0x860]
1013fe27c: f9042ff9    	str	x25, [sp, #0x858]
1013fe280: d10223a8    	sub	x8, x29, #0x88
1013fe284: 912163e0    	add	x0, sp, #0x858
1013fe288: 940ecccb    	bl	0x1017b15b4 <__ZN3std2fs8DirEntry9file_name17h6382942abec15980E>
1013fe28c: a977e3b9    	ldp	x25, x24, [x29, #-0x88]
1013fe290: f85883bb    	ldur	x27, [x29, #-0x78]
1013fe294: d101c3a8    	sub	x8, x29, #0x70
1013fe298: aa1803e0    	mov	x0, x24
1013fe29c: aa1b03e1    	mov	x1, x27
1013fe2a0: 94109a86    	bl	0x101824cb8 <__ZN4core3str8converts9from_utf817ha54c467cc832e2ffE>
1013fe2a4: b85903a8    	ldur	w8, [x29, #-0x70]
1013fe2a8: 36000108    	tbz	w8, #0x0, 0x1013fe2c8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x5a0>
1013fe2ac: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013fe2b0: eb08033f    	cmp	x25, x8
1013fe2b4: 54000421    	b.ne	0x1013fe338 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x610>
1013fe2b8: aa1803f9    	mov	x25, x24
1013fe2bc: f85983a8    	ldur	x8, [x29, #-0x68]
1013fe2c0: aa1b03f8    	mov	x24, x27
1013fe2c4: aa0803fb    	mov	x27, x8
1013fe2c8: f9442fe8    	ldr	x8, [sp, #0x858]
1013fe2cc: 92800009    	mov	x9, #-0x1               ; =-1
1013fe2d0: f8690108    	ldaddl	x9, x8, [x8]
1013fe2d4: f100051f    	cmp	x8, #0x1
1013fe2d8: 54000461    	b.ne	0x1013fe364 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x63c>
1013fe2dc: d50339bf    	dmb	ishld
1013fe2e0: 912163e0    	add	x0, sp, #0x858
1013fe2e4: 940f792a    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013fe2e8: 1400001f    	b	0x1013fe364 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x63c>
1013fe2ec: 92400708    	and	x8, x24, #0x3
1013fe2f0: f100051f    	cmp	x8, #0x1
1013fe2f4: 54fff961    	b.ne	0x1013fe220 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x4f8>
1013fe2f8: f85fff19    	ldr	x25, [x24, #-0x1]!
1013fe2fc: f940071a    	ldr	x26, [x24, #0x8]
1013fe300: f9400348    	ldr	x8, [x26]
1013fe304: b4000068    	cbz	x8, 0x1013fe310 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x5e8>
1013fe308: aa1903e0    	mov	x0, x25
1013fe30c: d63f0100    	blr	x8
1013fe310: f9400741    	ldr	x1, [x26, #0x8]
1013fe314: b4000081    	cbz	x1, 0x1013fe324 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x5fc>
1013fe318: f9400b42    	ldr	x2, [x26, #0x10]
1013fe31c: aa1903e0    	mov	x0, x25
1013fe320: 97da80ef    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe324: aa1803e0    	mov	x0, x24
1013fe328: 52800301    	mov	w1, #0x18               ; =24
1013fe32c: 52800102    	mov	w2, #0x8                ; =8
1013fe330: 97da80eb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe334: 17ffffbb    	b	0x1013fe220 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x4f8>
1013fe338: b40000b9    	cbz	x25, 0x1013fe34c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x624>
1013fe33c: aa1803e0    	mov	x0, x24
1013fe340: aa1903e1    	mov	x1, x25
1013fe344: 52800022    	mov	w2, #0x1                ; =1
1013fe348: 97da80e5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe34c: d2f00019    	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
1013fe350: f9442fe8    	ldr	x8, [sp, #0x858]
1013fe354: 92800009    	mov	x9, #-0x1               ; =-1
1013fe358: f8690108    	ldaddl	x9, x8, [x8]
1013fe35c: f100051f    	cmp	x8, #0x1
1013fe360: 54fffbe0    	b.eq	0x1013fe2dc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x5b4>
1013fe364: d2f0001a    	mov	x26, #-0x8000000000000000 ; =-9223372036854775808
1013fe368: eb1a033f    	cmp	x25, x26
1013fe36c: 54000220    	b.eq	0x1013fe3b0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x688>
1013fe370: b400009b    	cbz	x27, 0x1013fe380 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x658>
1013fe374: 39400308    	ldrb	w8, [x24]
1013fe378: 7100b91f    	cmp	w8, #0x2e
1013fe37c: 54000100    	b.eq	0x1013fe39c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x674>
1013fe380: f94007e0    	ldr	x0, [sp, #0x8]
1013fe384: aa1803e1    	mov	x1, x24
1013fe388: aa1b03e2    	mov	x2, x27
1013fe38c: 94004230    	bl	0x10140ec4c <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E>
1013fe390: 36000060    	tbz	w0, #0x0, 0x1013fe39c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x674>
1013fe394: aa1903fa    	mov	x26, x25
1013fe398: 14000006    	b	0x1013fe3b0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x688>
1013fe39c: b40000b9    	cbz	x25, 0x1013fe3b0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x688>
1013fe3a0: aa1803e0    	mov	x0, x24
1013fe3a4: aa1903e1    	mov	x1, x25
1013fe3a8: 52800022    	mov	w2, #0x1                ; =1
1013fe3ac: 97da80cc    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe3b0: f94432a8    	ldr	x8, [x21, #0x860]
1013fe3b4: f100011f    	cmp	x8, #0x0
1013fe3b8: 1a9f07e8    	cset	w8, ne
1013fe3bc: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1013fe3c0: eb09035f    	cmp	x26, x9
1013fe3c4: 1a9f17e9    	cset	w9, eq
1013fe3c8: 6a09011f    	tst	w8, w9
1013fe3cc: 9a9b139c    	csel	x28, x28, x27, ne
1013fe3d0: 9a981294    	csel	x20, x20, x24, ne
1013fe3d4: 9a9a1278    	csel	x24, x19, x26, ne
1013fe3d8: f9421fe8    	ldr	x8, [sp, #0x438]
1013fe3dc: b4fff1e8    	cbz	x8, 0x1013fe218 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x4f0>
1013fe3e0: 92800009    	mov	x9, #-0x1               ; =-1
1013fe3e4: f8690108    	ldaddl	x9, x8, [x8]
1013fe3e8: f100051f    	cmp	x8, #0x1
1013fe3ec: 54fff161    	b.ne	0x1013fe218 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x4f0>
1013fe3f0: d50339bf    	dmb	ishld
1013fe3f4: 9110e3e0    	add	x0, sp, #0x438
1013fe3f8: 940f78e5    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013fe3fc: 17ffff87    	b	0x1013fe218 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x4f0>
1013fe400: 396162a8    	ldrb	w8, [x21, #0x858]
1013fe404: 7100091f    	cmp	w8, #0x2
1013fe408: 54000120    	b.eq	0x1013fe42c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x704>
1013fe40c: f94002c8    	ldr	x8, [x22]
1013fe410: 92800009    	mov	x9, #-0x1               ; =-1
1013fe414: f8690108    	ldaddl	x9, x8, [x8]
1013fe418: f100051f    	cmp	x8, #0x1
1013fe41c: 54000081    	b.ne	0x1013fe42c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x704>
1013fe420: d50339bf    	dmb	ishld
1013fe424: aa1603e0    	mov	x0, x22
1013fe428: 940f78d9    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013fe42c: 52800048    	mov	w8, #0x2                ; =2
1013fe430: 392162a8    	strb	w8, [x21, #0x858]
1013fe434: f94003e0    	ldr	x0, [sp]
1013fe438: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013fe43c: f9000008    	str	x8, [x0]
1013fe440: 9132c3ff    	add	sp, sp, #0xcb0
1013fe444: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1013fe448: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1013fe44c: a94357f6    	ldp	x22, x21, [sp, #0x30]
1013fe450: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1013fe454: a94167fa    	ldp	x26, x25, [sp, #0x10]
1013fe458: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1013fe45c: d65f03c0    	ret
1013fe460: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013fe464: eb08031f    	cmp	x24, x8
1013fe468: f94003e0    	ldr	x0, [sp]
1013fe46c: 54fffe60    	b.eq	0x1013fe438 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x710>
1013fe470: aa0003f3    	mov	x19, x0
1013fe474: 97da809f    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1013fe478: 52800060    	mov	w0, #0x3                ; =3
1013fe47c: 52800021    	mov	w1, #0x1                ; =1
1013fe480: 97da8096    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1013fe484: b4000320    	cbz	x0, 0x1013fe4e8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x7c0>
1013fe488: aa0003f5    	mov	x21, x0
1013fe48c: 52800dc8    	mov	w8, #0x6e               ; =110
1013fe490: 39000808    	strb	w8, [x0, #0x2]
1013fe494: 528d2c48    	mov	w8, #0x6962             ; =26978
1013fe498: 79000008    	strh	w8, [x0]
1013fe49c: f9042ffa    	str	x26, [sp, #0x858]
1013fe4a0: f90433f4    	str	x20, [sp, #0x860]
1013fe4a4: f90437fc    	str	x28, [sp, #0x868]
1013fe4a8: 910043e8    	add	x8, sp, #0x10
1013fe4ac: 912163e0    	add	x0, sp, #0x858
1013fe4b0: 94104347    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1013fe4b4: 3dc007e0    	ldr	q0, [sp, #0x10]
1013fe4b8: f94013e8    	ldr	x8, [sp, #0x20]
1013fe4bc: 3d800260    	str	q0, [x19]
1013fe4c0: a9016a68    	stp	x8, x26, [x19, #0x10]
1013fe4c4: a9027274    	stp	x20, x28, [x19, #0x20]
1013fe4c8: 52800068    	mov	w8, #0x3                ; =3
1013fe4cc: a9035668    	stp	x8, x21, [x19, #0x30]
1013fe4d0: d0004208    	adrp	x8, 0x101c40000 <__ZN6rustls8versions5TLS1317h044579f6764766a2E+0x1b4a>
1013fe4d4: 3dc2a500    	ldr	q0, [x8, #0xa90]
1013fe4d8: 3d801260    	str	q0, [x19, #0x40]
1013fe4dc: 52804008    	mov	w8, #0x200              ; =512
1013fe4e0: 7900c268    	strh	w8, [x19, #0x60]
1013fe4e4: 17ffffd7    	b	0x1013fe440 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x718>
1013fe4e8: 52800020    	mov	w0, #0x1                ; =1
1013fe4ec: 52800061    	mov	w1, #0x3                ; =3
1013fe4f0: 941b13a1    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1013fe4f4: d4200020    	brk	#0x1
1013fe4f8: aa0003f3    	mov	x19, x0
1013fe4fc: b40000ba    	cbz	x26, 0x1013fe510 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x7e8>
1013fe500: aa1403e0    	mov	x0, x20
1013fe504: aa1a03e1    	mov	x1, x26
1013fe508: 52800022    	mov	w2, #0x1                ; =1
1013fe50c: 97da8074    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe510: aa1503e0    	mov	x0, x21
1013fe514: 52800061    	mov	w1, #0x3                ; =3
1013fe518: 52800022    	mov	w2, #0x1                ; =1
1013fe51c: 97da8070    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe520: aa1303e0    	mov	x0, x19
1013fe524: 941b2c2c    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013fe528: aa0003f3    	mov	x19, x0
1013fe52c: b400071a    	cbz	x26, 0x1013fe60c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8e4>
1013fe530: aa1403e0    	mov	x0, x20
1013fe534: aa1a03e1    	mov	x1, x26
1013fe538: 52800022    	mov	w2, #0x1                ; =1
1013fe53c: 97da8068    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe540: aa1303e0    	mov	x0, x19
1013fe544: 941b2c24    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013fe548: 52800048    	mov	w8, #0x2                ; =2
1013fe54c: 392162a8    	strb	w8, [x21, #0x858]
1013fe550: 941b2c21    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013fe554: aa0003f3    	mov	x19, x0
1013fe558: f9400741    	ldr	x1, [x26, #0x8]
1013fe55c: b4000081    	cbz	x1, 0x1013fe56c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x844>
1013fe560: f9400b42    	ldr	x2, [x26, #0x10]
1013fe564: aa1903e0    	mov	x0, x25
1013fe568: 97da805d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe56c: aa1803e0    	mov	x0, x24
1013fe570: 52800301    	mov	w1, #0x18               ; =24
1013fe574: 52800102    	mov	w2, #0x8                ; =8
1013fe578: 97da8059    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe57c: aa1303e0    	mov	x0, x19
1013fe580: 941b2c15    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013fe584: aa0003f3    	mov	x19, x0
1013fe588: b4000319    	cbz	x25, 0x1013fe5e8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8c0>
1013fe58c: aa1803e0    	mov	x0, x24
1013fe590: aa1903e1    	mov	x1, x25
1013fe594: 52800022    	mov	w2, #0x1                ; =1
1013fe598: 97da8051    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe59c: 14000013    	b	0x1013fe5e8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8c0>
1013fe5a0: aa0003f3    	mov	x19, x0
1013fe5a4: 14000011    	b	0x1013fe5e8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8c0>
1013fe5a8: aa0003f3    	mov	x19, x0
1013fe5ac: b40000f9    	cbz	x25, 0x1013fe5c8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8a0>
1013fe5b0: aa1803e0    	mov	x0, x24
1013fe5b4: aa1903e1    	mov	x1, x25
1013fe5b8: 52800022    	mov	w2, #0x1                ; =1
1013fe5bc: 97da8048    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe5c0: 14000002    	b	0x1013fe5c8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8a0>
1013fe5c4: aa0003f3    	mov	x19, x0
1013fe5c8: f9442fe8    	ldr	x8, [sp, #0x858]
1013fe5cc: 92800009    	mov	x9, #-0x1               ; =-1
1013fe5d0: f8690108    	ldaddl	x9, x8, [x8]
1013fe5d4: f100051f    	cmp	x8, #0x1
1013fe5d8: 54000081    	b.ne	0x1013fe5e8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8c0>
1013fe5dc: d50339bf    	dmb	ishld
1013fe5e0: 912163e0    	add	x0, sp, #0x858
1013fe5e4: 940f786a    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013fe5e8: f9421fe8    	ldr	x8, [sp, #0x438]
1013fe5ec: b4000108    	cbz	x8, 0x1013fe60c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8e4>
1013fe5f0: 92800009    	mov	x9, #-0x1               ; =-1
1013fe5f4: f8690108    	ldaddl	x9, x8, [x8]
1013fe5f8: f100051f    	cmp	x8, #0x1
1013fe5fc: 54000081    	b.ne	0x1013fe60c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8e4>
1013fe600: d50339bf    	dmb	ishld
1013fe604: 9110e3e0    	add	x0, sp, #0x438
1013fe608: 940f7861    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013fe60c: aa1303e0    	mov	x0, x19
1013fe610: 941b2bf1    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013fe614: 941b15c4    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1013fe618: 941b15c3    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
