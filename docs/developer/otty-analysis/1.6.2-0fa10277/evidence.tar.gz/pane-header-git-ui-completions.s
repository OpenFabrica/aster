10058b960:     	b	0x101aca6a8 ; symbol _swift_deallocObject
10058b964:     	sub	sp, sp, #0x90
10058b968:     	stp	x28, x27, [sp, #0x30]
10058b96c:     	stp	x26, x25, [sp, #0x40]
10058b970:     	stp	x24, x23, [sp, #0x50]
10058b974:     	stp	x22, x21, [sp, #0x60]
10058b978:     	stp	x20, x19, [sp, #0x70]
10058b97c:     	stp	x29, x30, [sp, #0x80]
10058b980:     	add	x29, sp, #0x80
10058b984:     	mov	w27, #0x7550            ; =30032
10058b988:     	movk	w27, #0x6873, lsl #16
10058b98c:     	ldp	x21, x22, [x20, #0x10]
10058b990:     	ldp	x26, x19, [x20, #0x20]
10058b994:     	mov	x8, #-0x2000000000000000 ; =-2305843009213693952
10058b998:     	stp	xzr, x8, [sp]
10058b99c:     	mov	x20, sp
10058b9a0:     	mov	w0, #0x23               ; =35
10058b9a4:     	bl	0x101ac757c ; symbol _$ss11_StringGutsV4growyySiF
10058b9a8:     	ldr	x0, [sp, #0x8]
10058b9ac:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058b9b0:     	mov	x8, #0x7550             ; =30032
10058b9b4:     	movk	x8, #0x6873, lsl #16
10058b9b8:     	movk	x8, #0x2220, lsl #32
10058b9bc:     	mov	x9, #-0x1a00000000000000 ; =-1873497444986126336
10058b9c0:     	stp	x8, x9, [sp]
10058b9c4:     	mov	x20, sp
10058b9c8:     	mov	x0, x21
10058b9cc:     	mov	x1, x22
10058b9d0:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10058b9d4:     	adrp	x8, 0x101ddd000
10058b9d8:     	add	x8, x8, #0x9a0 ; possible literal '" to the remote repository?'
10058b9dc:     	sub	x8, x8, #0x20
10058b9e0:     	orr	x1, x8, #0x8000000000000000
10058b9e4:     	mov	x20, sp
10058b9e8:     	mov	x0, #0x1b               ; =27
10058b9ec:     	movk	x0, #0xd000, lsl #48
10058b9f0:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10058b9f4:     	ldp	x24, x20, [sp]
10058b9f8:     	adrp	x0, 0x102341000
10058b9fc:     	add	x0, x0, #0x6d0
10058ba00:     	adrp	x1, 0x101ae1000
10058ba04:     	add	x1, x1, #0x7e0 ; possible literal '\n14'
10058ba08:     	bl	0x100003c4c
10058ba0c:     	mov	w1, #0x60               ; =96
10058ba10:     	mov	w2, #0x7                ; =7
10058ba14:     	bl	0x101aca588 ; symbol _swift_allocObject
10058ba18:     	adrp	x8, 0x101ae1000
10058ba1c:     	ldr	q0, [x8, #0x120]
10058ba20:     	str	q0, [x0, #0x10]
10058ba24:     	mov	w8, #0x6967             ; =26983
10058ba28:     	movk	w8, #0x74, lsl #16
10058ba2c:     	mov	x9, #-0x1d00000000000000 ; =-2089670227099910144
10058ba30:     	stp	x8, x9, [x0, #0x20]
10058ba34:     	mov	w8, #0x432d             ; =17197
10058ba38:     	mov	x9, #-0x1e00000000000000 ; =-2161727821137838080
10058ba3c:     	stp	x8, x9, [x0, #0x30]
10058ba40:     	stp	x26, x19, [x0, #0x40]
10058ba44:     	orr	x8, x27, #0x20
10058ba48:     	mov	x9, #-0x1c00000000000000 ; =-2017612633061982208
10058ba4c:     	stp	x8, x9, [x0, #0x50]
10058ba50:     	adrp	x8, 0x1022ca000
10058ba54:     	ldr	x8, [x8, #0x558]
10058ba58:     	ldr	x22, [x8]
10058ba5c:     	cbz	x22, 0x10058bc88
10058ba60:     	mov	x21, x0
10058ba64:     	mov	x0, x19
10058ba68:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10058ba6c:     	mov	x0, x22
10058ba70:     	bl	0x101acf200 ; selector keyWindow
10058ba74:     	mov	x29, x29
10058ba78:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
10058ba7c:     	cbz	x0, 0x10058bc5c
10058ba80:     	mov	x22, x0
10058ba84:     	adrp	x8, 0x102326000
10058ba88:     	ldr	x0, [x8, #0xaa8]
10058ba8c:     	bl	0x101ac9cb8 ; symbol _objc_allocWithZone
10058ba90:     	bl	0x101ace2c0 ; selector init
10058ba94:     	mov	x23, x0
10058ba98:     	mov	x0, #0x7550             ; =30032
10058ba9c:     	movk	x0, #0x6873, lsl #16
10058baa0:     	movk	x0, #0x7420, lsl #32
10058baa4:     	movk	x0, #0x206f, lsl #48
10058baa8:     	mov	x1, #0x6552             ; =25938
10058baac:     	movk	x1, #0x6f6d, lsl #16
10058bab0:     	movk	x1, #0x6574, lsl #32
10058bab4:     	movk	x1, #0xee00, lsl #48
10058bab8:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
10058babc:     	mov	x25, x0
10058bac0:     	mov	x0, x23
10058bac4:     	mov	x2, x25
10058bac8:     	bl	0x101ad3660 ; selector setMessageText:
10058bacc:     	mov	x0, x25
10058bad0:     	bl	0x101ac9d30 ; symbol _objc_release
10058bad4:     	mov	x0, x24
10058bad8:     	mov	x1, x20
10058badc:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
10058bae0:     	mov	x24, x0
10058bae4:     	mov	x0, x23
10058bae8:     	mov	x2, x24
10058baec:     	bl	0x101ad30c0 ; selector setInformativeText:
10058baf0:     	mov	x0, x24
10058baf4:     	bl	0x101ac9d30 ; symbol _objc_release
10058baf8:     	mov	x25, #-0x1c00000000000000 ; =-2017612633061982208
10058bafc:     	mov	w0, #0x7550             ; =30032
10058bb00:     	movk	w0, #0x6873, lsl #16
10058bb04:     	mov	x1, #-0x1c00000000000000 ; =-2017612633061982208
10058bb08:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
10058bb0c:     	mov	x24, x0
10058bb10:     	mov	x0, x23
10058bb14:     	mov	x2, x24
10058bb18:     	bl	0x101acb200 ; selector addButtonWithTitle:
10058bb1c:     	mov	x29, x29
10058bb20:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
10058bb24:     	bl	0x101ac9d30 ; symbol _objc_release
10058bb28:     	mov	x0, x24
10058bb2c:     	bl	0x101ac9d30 ; symbol _objc_release
10058bb30:     	mov	x0, #0x6143             ; =24899
10058bb34:     	movk	x0, #0x636e, lsl #16
10058bb38:     	movk	x0, #0x6c65, lsl #32
10058bb3c:     	mov	x1, #-0x1a00000000000000 ; =-1873497444986126336
10058bb40:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
10058bb44:     	mov	x24, x0
10058bb48:     	mov	x0, x23
10058bb4c:     	mov	x2, x24
10058bb50:     	bl	0x101acb200 ; selector addButtonWithTitle:
10058bb54:     	mov	x29, x29
10058bb58:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
10058bb5c:     	bl	0x101ac9d30 ; symbol _objc_release
10058bb60:     	mov	x0, x24
10058bb64:     	bl	0x101ac9d30 ; symbol _objc_release
10058bb68:     	adrp	x0, 0x1021e1000
10058bb6c:     	add	x0, x0, #0x920
10058bb70:     	mov	w1, #0x50               ; =80
10058bb74:     	mov	w2, #0x7                ; =7
10058bb78:     	bl	0x101aca588 ; symbol _swift_allocObject
10058bb7c:     	stp	x27, x25, [x0, #0x10]
10058bb80:     	mov	x8, #0x7550             ; =30032
10058bb84:     	movk	x8, #0x6873, lsl #16
10058bb88:     	movk	x8, #0x6e69, lsl #32
10058bb8c:     	movk	x8, #0x2e67, lsl #48
10058bb90:     	mov	x9, #0x2e2e             ; =11822
10058bb94:     	movk	x9, #0xea00, lsl #48
10058bb98:     	stp	x8, x9, [x0, #0x20]
10058bb9c:     	stp	x21, x26, [x0, #0x30]
10058bba0:     	stp	x19, xzr, [x0, #0x40]
10058bba4:     	adrp	x8, 0x10058b000
10058bba8:     	add	x8, x8, #0xe08
10058bbac:     	stp	x8, x0, [sp, #0x20]
10058bbb0:     	adrp	x8, 0x1022cb000
10058bbb4:     	ldr	x8, [x8, #0x300]
10058bbb8:     	str	x8, [sp]
10058bbbc:     	adrp	x8, 0x101ae1000
10058bbc0:     	ldr	d0, [x8]
10058bbc4:     	str	d0, [sp, #0x8]
10058bbc8:     	adrp	x8, 0x100071000
10058bbcc:     	add	x8, x8, #0xb1c
10058bbd0:     	adrp	x9, 0x1021e1000
10058bbd4:     	add	x9, x9, #0x938
10058bbd8:     	stp	x8, x9, [sp, #0x10]
10058bbdc:     	mov	x0, sp
10058bbe0:     	bl	0x101ac9514 ; symbol __Block_copy
10058bbe4:     	mov	x24, x0
10058bbe8:     	ldr	x25, [sp, #0x28]
10058bbec:     	mov	x0, x19
10058bbf0:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10058bbf4:     	mov	x0, x21
10058bbf8:     	bl	0x101aca978 ; symbol _swift_retain
10058bbfc:     	mov	x0, x25
10058bc00:     	bl	0x101aca960 ; symbol _swift_release
10058bc04:     	mov	x0, x23
10058bc08:     	mov	x2, x22
10058bc0c:     	mov	x3, x24
10058bc10:     	bl	0x101acbb80 ; selector beginSheetModalForWindow:completionHandler:
10058bc14:     	mov	x0, x20
10058bc18:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058bc1c:     	mov	x0, x21
10058bc20:     	bl	0x101aca960 ; symbol _swift_release
10058bc24:     	mov	x0, x24
10058bc28:     	bl	0x101ac9520 ; symbol __Block_release
10058bc2c:     	mov	x0, x23
10058bc30:     	bl	0x101ac9d30 ; symbol _objc_release
10058bc34:     	mov	x0, x22
10058bc38:     	bl	0x101ac9d30 ; symbol _objc_release
10058bc3c:     	ldp	x29, x30, [sp, #0x80]
10058bc40:     	ldp	x20, x19, [sp, #0x70]
10058bc44:     	ldp	x22, x21, [sp, #0x60]
10058bc48:     	ldp	x24, x23, [sp, #0x50]
10058bc4c:     	ldp	x26, x25, [sp, #0x40]
10058bc50:     	ldp	x28, x27, [sp, #0x30]
10058bc54:     	add	sp, sp, #0x90
10058bc58:     	ret
10058bc5c:     	mov	x0, x20
10058bc60:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058bc64:     	mov	x0, x21
10058bc68:     	ldp	x29, x30, [sp, #0x80]
10058bc6c:     	ldp	x20, x19, [sp, #0x70]
10058bc70:     	ldp	x22, x21, [sp, #0x60]
10058bc74:     	ldp	x24, x23, [sp, #0x50]
10058bc78:     	ldp	x26, x25, [sp, #0x40]
10058bc7c:     	ldp	x28, x27, [sp, #0x30]
10058bc80:     	add	sp, sp, #0x90
10058bc84:     	b	0x101aca960 ; symbol _swift_release
10058bc88:     	brk	#0x1
10058bc8c:     	b	0x10058bc90
10058bc90:     	stp	x29, x30, [sp, #-0x10]!
10058bc94:     	mov	x29, sp
10058bc98:     	ldr	x0, [x20, #0x18]
10058bc9c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058bca0:     	ldr	x0, [x20, #0x28]
10058bca4:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058bca8:     	ldr	x0, [x20, #0x30]
10058bcac:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058bcb0:     	ldr	x0, [x20, #0x40]
10058bcb4:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058bcb8:     	ldr	x0, [x20, #0x48]
10058bcbc:     	bl	0x101aca960 ; symbol _swift_release
10058bcc0:     	mov	x0, x20
10058bcc4:     	mov	w1, #0x50               ; =80
10058bcc8:     	mov	w2, #0x7                ; =7
10058bccc:     	ldp	x29, x30, [sp], #0x10
10058bcd0:     	b	0x101aca6a8 ; symbol _swift_deallocObject
10058bcd4:     	sub	sp, sp, #0x20
10058bcd8:     	stp	x29, x30, [sp, #0x10]
10058bcdc:     	add	x29, sp, #0x10
10058bce0:     	mov	x8, x1
10058bce4:     	ldp	x1, x2, [x20, #0x10]
10058bce8:     	ldp	x3, x4, [x20, #0x20]
10058bcec:     	ldp	x5, x6, [x20, #0x30]
10058bcf0:     	ldp	x7, x9, [x20, #0x40]
10058bcf4:     	str	x9, [sp]
10058bcf8:     	blr	x8
10058bcfc:     	ldp	x29, x30, [sp, #0x10]
10058bd00:     	add	sp, sp, #0x20
10058bd04:     	ret
10058bd08:     	stp	x29, x30, [sp, #-0x10]!
10058bd0c:     	mov	x29, sp
10058bd10:     	ldr	x0, [x20, #0x18]
10058bd14:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058bd18:     	ldr	x0, [x20, #0x20]
10058bd1c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058bd20:     	ldr	x0, [x20, #0x28]
10058bd24:     	bl	0x101aca960 ; symbol _swift_release
10058bd28:     	mov	x0, x20
10058bd2c:     	mov	w1, #0x30               ; =48
10058bd30:     	mov	w2, #0x7                ; =7
10058bd34:     	ldp	x29, x30, [sp], #0x10
10058bd38:     	b	0x101aca6a8 ; symbol _swift_deallocObject
10058bd3c:     	stp	x22, x21, [sp, #-0x30]!
10058bd40:     	stp	x20, x19, [sp, #0x10]
10058bd44:     	stp	x29, x30, [sp, #0x20]
10058bd48:     	add	x29, sp, #0x20
10058bd4c:     	ldp	x19, x21, [x20, #0x10]
10058bd50:     	ldp	x22, x20, [x20, #0x20]
10058bd54:     	mov	x0, #0x0                ; =0
10058bd58:     	bl	0x10058ff54
10058bd5c:     	mov	x4, x0
10058bd60:     	mov	x0, x19
10058bd64:     	mov	x1, x21
10058bd68:     	mov	x2, x22
10058bd6c:     	mov	x3, x20
10058bd70:     	mov	x20, x4
10058bd74:     	bl	0x10058cefc
10058bd78:     	ldp	x29, x30, [sp, #0x20]
10058bd7c:     	ldp	x20, x19, [sp, #0x10]
10058bd80:     	ldp	x22, x21, [sp], #0x30
10058bd84:     	ret
10058bd88:     	b	0x100588744
10058bd8c:     	b	0x100588744
10058bd90:     	b	0x10058829c
10058bd94:     	b	0x10058829c
10058bd98:     	b	0x10058829c
10058bd9c:     	b	0x10058829c
10058bda0:     	b	0x10058829c
10058bda4:     	b	0x10058829c
10058bda8:     	b	0x10058829c
10058bdac:     	b	0x10058829c
10058bdb0:     	b	0x10058829c
10058bdb4:     	b	0x10058829c
10058bdb8:     	b	0x10058829c
10058bdbc:     	b	0x10058829c
10058bdc0:     	b	0x10058829c
10058bdc4:     	b	0x10058829c
10058bdc8:     	b	0x1005882b0
10058bdcc:     	b	0x1005882b0
10058bdd0:     	b	0x1005882b0
10058bdd4:     	b	0x1005882b0
10058bdd8:     	b	0x1005882b0
10058bddc:     	b	0x1005882b0
10058bde0:     	b	0x1005882b0
10058bde4:     	b	0x1005882b0
10058bde8:     	b	0x1005882b0
10058bdec:     	b	0x1005882b0
10058bdf0:     	b	0x1005882b0
10058bdf4:     	b	0x1005882b0
10058bdf8:     	b	0x1005882b0
10058bdfc:     	b	0x1005882b0
10058be00:     	b	0x10058ab68
10058be04:     	b	0x10058ab60
10058be08:     	b	0x100589498
10058be0c:     	b	0x10058abbc
10058be10:     	b	0x10058abc0
10058be14:     	b	0x10058ab5c
10058be18:     	b	0x10058ab64
10058be1c:     	b	0x10058bc8c
10058be20:     	b	0x10058c478
10058be24:     	stp	x28, x27, [sp, #-0x60]!
10058be28:     	stp	x26, x25, [sp, #0x10]
10058be2c:     	stp	x24, x23, [sp, #0x20]
10058be30:     	stp	x22, x21, [sp, #0x30]
10058be34:     	stp	x20, x19, [sp, #0x40]
10058be38:     	stp	x29, x30, [sp, #0x50]
10058be3c:     	add	x29, sp, #0x50
10058be40:     	sub	sp, sp, #0x220
10058be44:     	mov	x28, x5
10058be48:     	str	x4, [sp, #0x28]
10058be4c:     	mov	x22, x3
10058be50:     	mov	x19, x2
10058be54:     	mov	x24, x1
10058be58:     	mov	x25, x0
10058be5c:     	mov	w0, #0x2f               ; =47
10058be60:     	mov	x1, #-0x1f00000000000000 ; =-2233785415175766016
10058be64:     	bl	0x101ac6598 ; symbol _$sSS9hasSuffixySbSSF
10058be68:     	tbz	w0, #0x0, 0x10058be78
10058be6c:     	mov	x0, x22
10058be70:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10058be74:     	b	0x10058be98
10058be78:     	stp	x19, x22, [x29, #-0xf0]
10058be7c:     	mov	x0, x22
