1004c65a0:     	mov	x3, x1
1004c65a4:     	mov	x2, x0
1004c65a8:     	ldp	x0, x1, [x20, #0x10]
1004c65ac:     	b	0x100582e2c
1004c65b0:     	stp	x22, x21, [sp, #-0x30]!
1004c65b4:     	stp	x20, x19, [sp, #0x10]
1004c65b8:     	stp	x29, x30, [sp, #0x20]
1004c65bc:     	add	x29, sp, #0x20
1004c65c0:     	ldp	x19, x20, [x20, #0x10]
1004c65c4:     	adrp	x8, 0x102326000
1004c65c8:     	ldr	x0, [x8, #0xa00]
1004c65cc:     	bl	0x101ac9d24 ; symbol _objc_opt_self
1004c65d0:     	bl	0x101acce80 ; selector defaultCenter
1004c65d4:     	mov	x29, x29
1004c65d8:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
1004c65dc:     	mov	x21, x0
1004c65e0:     	bl	0x10006ec34
1004c65e4:     	ldr	x0, [x0]
1004c65e8:     	bl	0x101ac9d3c ; symbol _objc_retain
1004c65ec:     	mov	x22, x0
1004c65f0:     	mov	x0, x19
1004c65f4:     	mov	x1, x20
1004c65f8:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004c65fc:     	mov	x19, x0
1004c6600:     	mov	x0, x21
1004c6604:     	mov	x2, x22
1004c6608:     	mov	x3, x19
1004c660c:     	bl	0x101ad0340 ; selector postNotificationName:object:
