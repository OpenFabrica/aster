101414134: f9001ff9    	str	x25, [sp, #0x38]
101414138: b9407b38    	ldr	w24, [x25, #0x78]
10141413c: 52800159    	mov	w25, #0xa               ; =10
101414140: f0004653    	adrp	x19, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101414144: 91214a73    	add	x19, x19, #0x852
101414148: b900bbf8    	str	w24, [sp, #0xb8]
10141414c: 14000003    	b	0x101414158 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44f0>
101414150: f1000739    	subs	x25, x25, #0x1
101414154: 540008c0    	b.eq	0x10141426c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4604>
101414158: 940ec8d5    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
10141415c: eb1a001f    	cmp	x0, x26
101414160: 54000081    	b.ne	0x101414170 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4508>
101414164: 6b18003f    	cmp	w1, w24
101414168: 54000063    	b.lo	0x101414174 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x450c>
10141416c: 14000040    	b	0x10141426c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4604>
101414170: 540007ea    	b.ge	0x10141426c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4604>
101414174: 910403e8    	add	x8, sp, #0x100
101414178: aa1603e0    	mov	x0, x22
10141417c: aa1703e1    	mov	x1, x23
101414180: aa1303e2    	mov	x2, x19
101414184: 52800143    	mov	w3, #0xa                ; =10
101414188: 940ec045    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
10141418c: a950d3f5    	ldp	x21, x20, [sp, #0x108]
101414190: 912783e8    	add	x8, sp, #0x9e0
101414194: aa1503e0    	mov	x0, x21
101414198: aa1403e1    	mov	x1, x20
10141419c: 940e9c58    	bl	0x1017bb2fc <__ZN3std3sys2fs8metadata17h317aa82d489c5e37E>
1014141a0: b949e3e8    	ldr	w8, [sp, #0x9e0]
1014141a4: 36000428    	tbz	w8, #0x0, 0x101414228 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x45c0>
1014141a8: f944f7f4    	ldr	x20, [sp, #0x9e8]
1014141ac: 92400688    	and	x8, x20, #0x3
1014141b0: f100051f    	cmp	x8, #0x1
1014141b4: 54000221    	b.ne	0x1014141f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4590>
1014141b8: f85ffe98    	ldr	x24, [x20, #-0x1]!
1014141bc: f940069b    	ldr	x27, [x20, #0x8]
1014141c0: f9400368    	ldr	x8, [x27]
1014141c4: b4000068    	cbz	x8, 0x1014141d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4568>
1014141c8: aa1803e0    	mov	x0, x24
1014141cc: d63f0100    	blr	x8
1014141d0: f9400761    	ldr	x1, [x27, #0x8]
1014141d4: b4000081    	cbz	x1, 0x1014141e4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x457c>
1014141d8: f9400b62    	ldr	x2, [x27, #0x10]
1014141dc: aa1803e0    	mov	x0, x24
1014141e0: 97da293f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014141e4: aa1403e0    	mov	x0, x20
1014141e8: 52800301    	mov	w1, #0x18               ; =24
1014141ec: 52800102    	mov	w2, #0x8                ; =8
1014141f0: 97da293b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014141f4: b940bbf8    	ldr	w24, [sp, #0xb8]
1014141f8: aa1603e0    	mov	x0, x22
1014141fc: aa1703e1    	mov	x1, x23
101414200: 940ec0fa    	bl	0x1017c45e8 <__ZN3std4path4Path6parent17h81615573672c555dE>
101414204: aa0003f6    	mov	x22, x0
101414208: b4000280    	cbz	x0, 0x101414258 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x45f0>
10141420c: aa0103f7    	mov	x23, x1
101414210: f94083e1    	ldr	x1, [sp, #0x100]
101414214: b4fff9e1    	cbz	x1, 0x101414150 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44e8>
101414218: aa1503e0    	mov	x0, x21
10141421c: 52800022    	mov	w2, #0x1                ; =1
101414220: 97da292f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414224: 17ffffcb    	b	0x101414150 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44e8>
101414228: f94083e9    	ldr	x9, [sp, #0x100]
10141422c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101414230: a90a27f5    	stp	x21, x9, [sp, #0xa0]
101414234: eb08013f    	cmp	x9, x8
101414238: 540001a0    	b.eq	0x10141426c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4604>
10141423c: 940ec89c    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101414240: eb1a001f    	cmp	x0, x26
101414244: 54002761    	b.ne	0x101414730 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4ac8>
101414248: b940bbe8    	ldr	w8, [sp, #0xb8]
10141424c: 6b08003f    	cmp	w1, w8
101414250: 54002743    	b.lo	0x101414738 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4ad0>
101414254: 14000155    	b	0x1014147a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4b40>
101414258: f94083e1    	ldr	x1, [sp, #0x100]
10141425c: b4000081    	cbz	x1, 0x10141426c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4604>
101414260: aa1503e0    	mov	x0, x21
101414264: 52800022    	mov	w2, #0x1                ; =1
101414268: 97da291d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141426c: 52800108    	mov	w8, #0x8                ; =8
101414270: a91023ff    	stp	xzr, x8, [sp, #0x100]
101414274: a9117fff    	stp	xzr, xzr, [sp, #0x110]
101414278: a9127fe8    	stp	x8, xzr, [sp, #0x120]
10141427c: a91323ff    	stp	xzr, x8, [sp, #0x130]
101414280: a9147fff    	stp	xzr, xzr, [sp, #0x140]
101414284: f900abe8    	str	x8, [sp, #0x150]
101414288: f0003788    	adrp	x8, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
10141428c: 3dc2f900    	ldr	q0, [x8, #0xbe0]
101414290: 910403e8    	add	x8, sp, #0x100
101414294: 3c858100    	stur	q0, [x8, #0x58]
101414298: b940b3e8    	ldr	w8, [sp, #0xb0]
10141429c: 7100051f    	cmp	w8, #0x1
1014142a0: 5400018d    	b.le	0x1014142d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4668>
1014142a4: 7100091f    	cmp	w8, #0x2
1014142a8: 54000360    	b.eq	0x101414314 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x46ac>
1014142ac: 71000d1f    	cmp	w8, #0x3
1014142b0: 54000741    	b.ne	0x101414398 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4730>
1014142b4: a9520be1    	ldp	x1, x2, [sp, #0x120]
1014142b8: d10303a0    	sub	x0, x29, #0xc0
1014142bc: 94015fdb    	bl	0x10146c228 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xaf8>
1014142c0: f0004648    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014142c4: 91218d08    	add	x8, x8, #0x863
1014142c8: 528000a9    	mov	w9, #0x5                ; =5
1014142cc: 140001f6    	b	0x101414aa4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e3c>
1014142d0: 35000728    	cbnz	w8, 0x1014143b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x474c>
1014142d4: a9508be1    	ldp	x1, x2, [sp, #0x108]
1014142d8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014142dc: 91094000    	add	x0, x0, #0x250
1014142e0: 94015fd2    	bl	0x10146c228 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xaf8>
1014142e4: f94933e8    	ldr	x8, [sp, #0x1260]
1014142e8: b5003d08    	cbnz	x8, 0x101414a88 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e20>
1014142ec: f940b3e8    	ldr	x8, [sp, #0x160]
1014142f0: d2f00016    	mov	x22, #-0x8000000000000000 ; =-9223372036854775808
1014142f4: eb16011f    	cmp	x8, x22
1014142f8: 540039a1    	b.ne	0x101414a2c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4dc4>
1014142fc: d2f00014    	mov	x20, #-0x8000000000000000 ; =-9223372036854775808
101414300: 140001d2    	b	0x101414a48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4de0>
101414304: f90003e9    	str	x9, [sp]
101414308: d280001a    	mov	x26, #0x0               ; =0
10141430c: b5ffeee1    	cbnz	x1, 0x1014140e8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4480>
101414310: 17ffff7a    	b	0x1014140f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4490>
101414314: 528eac37    	mov	w23, #0x7561            ; =30049
101414318: 72ae8d97    	movk	w23, #0x746c, lsl #16
10141431c: 528cac98    	mov	w24, #0x6564            ; =25956
101414320: 72ac2cd8    	movk	w24, #0x6166, lsl #16
101414324: a953a3e9    	ldp	x9, x8, [sp, #0x138]
101414328: 8b080508    	add	x8, x8, x8, lsl #1
10141432c: d37df108    	lsl	x8, x8, #3
101414330: 8b080139    	add	x25, x9, x8
101414334: 91006129    	add	x9, x9, #0x18
101414338: b4000288    	cbz	x8, 0x101414388 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4720>
10141433c: aa0903fa    	mov	x26, x9
101414340: f85f8129    	ldur	x9, [x9, #-0x8]
101414344: f1001d3f    	cmp	x9, #0x7
101414348: 54000121    	b.ne	0x10141436c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4704>
10141434c: f85f0349    	ldur	x9, [x26, #-0x10]
101414350: b940012a    	ldr	w10, [x9]
101414354: b8403129    	ldur	w9, [x9, #0x3]
101414358: 6b18015f    	cmp	w10, w24
10141435c: 7a570120    	ccmp	w9, w23, #0x0, eq
101414360: 91006349    	add	x9, x26, #0x18
101414364: d1006108    	sub	x8, x8, #0x18
101414368: 54fffe80    	b.eq	0x101414338 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x46d0>
10141436c: d1006340    	sub	x0, x26, #0x18
101414370: 912783e8    	add	x8, sp, #0x9e0
101414374: 940feb96    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101414378: f944f3f3    	ldr	x19, [sp, #0x9e0]
10141437c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101414380: eb08027f    	cmp	x19, x8
101414384: 54001b81    	b.ne	0x1014146f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4a8c>
101414388: 52800108    	mov	w8, #0x8                ; =8
10141438c: a93423bf    	stp	xzr, x8, [x29, #-0xc0]
101414390: f81503bf    	stur	xzr, [x29, #-0xb0]
101414394: 14000143    	b	0x1014148a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4c38>
101414398: a9550be1    	ldp	x1, x2, [sp, #0x150]
10141439c: d10303a0    	sub	x0, x29, #0xc0
1014143a0: 94015fa2    	bl	0x10146c228 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xaf8>
1014143a4: f0004648    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014143a8: 9121a108    	add	x8, x8, #0x868
1014143ac: 528000e9    	mov	w9, #0x7                ; =7
1014143b0: 140001bd    	b	0x101414aa4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e3c>
1014143b4: 52800108    	mov	w8, #0x8                ; =8
1014143b8: a93423bf    	stp	xzr, x8, [x29, #-0xc0]
1014143bc: f81503bf    	stur	xzr, [x29, #-0xb0]
1014143c0: f0004648    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014143c4: 91212d08    	add	x8, x8, #0x84b
1014143c8: 528000e9    	mov	w9, #0x7                ; =7
1014143cc: 140001b6    	b	0x101414aa4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e3c>
1014143d0: eb1a001f    	cmp	x0, x26
1014143d4: 540003aa    	b.ge	0x101414448 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x47e0>
1014143d8: 912783e8    	add	x8, sp, #0x9e0
1014143dc: aa1503e0    	mov	x0, x21
1014143e0: aa1803e1    	mov	x1, x24
1014143e4: 940e70c2    	bl	0x1017b06ec <__ZN3std2fs14read_to_string5inner17h33327e834bd59c04E>
1014143e8: aa1903f3    	mov	x19, x25
1014143ec: f944f3f9    	ldr	x25, [sp, #0x9e0]
1014143f0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014143f4: eb08033f    	cmp	x25, x8
1014143f8: 540013a1    	b.ne	0x10141466c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4a04>
1014143fc: f944f7f3    	ldr	x19, [sp, #0x9e8]
101414400: 92400668    	and	x8, x19, #0x3
101414404: f100051f    	cmp	x8, #0x1
101414408: 54000201    	b.ne	0x101414448 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x47e0>
10141440c: f85ffe74    	ldr	x20, [x19, #-0x1]!
101414410: f9400677    	ldr	x23, [x19, #0x8]
101414414: f94002e8    	ldr	x8, [x23]
101414418: b4000068    	cbz	x8, 0x101414424 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x47bc>
10141441c: aa1403e0    	mov	x0, x20
101414420: d63f0100    	blr	x8
101414424: f94006e1    	ldr	x1, [x23, #0x8]
101414428: b4000081    	cbz	x1, 0x101414438 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x47d0>
10141442c: f9400ae2    	ldr	x2, [x23, #0x10]
101414430: aa1403e0    	mov	x0, x20
101414434: 97da28aa    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414438: aa1303e0    	mov	x0, x19
10141443c: 52800301    	mov	w1, #0x18               ; =24
101414440: 52800102    	mov	w2, #0x8                ; =8
101414444: 97da28a6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414448: b4ff07f6    	cbz	x22, 0x101412544 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28dc>
10141444c: aa1503e0    	mov	x0, x21
101414450: aa1603e1    	mov	x1, x22
101414454: 52800022    	mov	w2, #0x1                ; =1
101414458: 97da28a1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141445c: 17fff83a    	b	0x101412544 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28dc>
101414460: f0004642    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101414464: 910b6042    	add	x2, x2, #0x2d8
101414468: 912783e8    	add	x8, sp, #0x9e0
10141446c: aa1603e0    	mov	x0, x22
101414470: aa1703e1    	mov	x1, x23
101414474: 52800103    	mov	w3, #0x8                ; =8
101414478: 940ebf89    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
10141447c: f944f7f3    	ldr	x19, [sp, #0x9e8]
101414480: f944fbe1    	ldr	x1, [sp, #0x9f0]
101414484: 910403e8    	add	x8, sp, #0x100
101414488: aa1303e0    	mov	x0, x19
10141448c: 940e9be6    	bl	0x1017bb424 <__ZN3std3sys2fs8read_dir17h3de3d951fc53246fE>
101414490: 394423f4    	ldrb	w20, [sp, #0x108]
101414494: f94083f5    	ldr	x21, [sp, #0x100]
101414498: f944f3e1    	ldr	x1, [sp, #0x9e0]
10141449c: b4000081    	cbz	x1, 0x1014144ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4844>
1014144a0: aa1303e0    	mov	x0, x19
1014144a4: 52800022    	mov	w2, #0x1                ; =1
1014144a8: 97da288d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014144ac: 71000a9f    	cmp	w20, #0x2
1014144b0: 54000f81    	b.ne	0x1014146a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4a38>
1014144b4: 924006a8    	and	x8, x21, #0x3
1014144b8: f100051f    	cmp	x8, #0x1
1014144bc: 54005060    	b.eq	0x101414ec8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5260>
1014144c0: d2800013    	mov	x19, #0x0               ; =0
1014144c4: d2800015    	mov	x21, #0x0               ; =0
1014144c8: 52800114    	mov	w20, #0x8               ; =8
1014144cc: a9005395    	stp	x21, x20, [x28]
1014144d0: f9000b93    	str	x19, [x28, #0x10]
1014144d4: 140008fc    	b	0x1014168c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c5c>
1014144d8: a94757e8    	ldp	x8, x21, [sp, #0x70]
1014144dc: aa0803f3    	mov	x19, x8
1014144e0: f94043fb    	ldr	x27, [sp, #0x80]
1014144e4: f9402bf6    	ldr	x22, [sp, #0x50]
1014144e8: 14000012    	b	0x101414530 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x48c8>
1014144ec: aa1803f3    	mov	x19, x24
1014144f0: aa1c03f7    	mov	x23, x28
1014144f4: 1400000d    	b	0x101414528 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x48c0>
1014144f8: f9093bf6    	str	x22, [sp, #0x1270]
1014144fc: f9092ff8    	str	x24, [sp, #0x1258]
101414500: b40000b7    	cbz	x23, 0x101414514 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x48ac>
101414504: aa1903e0    	mov	x0, x25
101414508: aa1703e1    	mov	x1, x23
10141450c: 52800022    	mov	w2, #0x1                ; =1
101414510: 97da2873    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414514: aa1c03f7    	mov	x23, x28
101414518: a947eff5    	ldp	x21, x27, [sp, #0x78]
10141451c: f9403be8    	ldr	x8, [sp, #0x70]
101414520: 14000007    	b	0x10141453c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x48d4>
101414524: d2800016    	mov	x22, #0x0               ; =0
101414528: a947eff5    	ldp	x21, x27, [sp, #0x78]
10141452c: f9403be8    	ldr	x8, [sp, #0x70]
101414530: f9093bf6    	str	x22, [sp, #0x1270]
101414534: f9092ff3    	str	x19, [sp, #0x1258]
101414538: aa1303f8    	mov	x24, x19
10141453c: eb180108    	subs	x8, x8, x24
101414540: 54000200    	b.eq	0x101414580 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4918>
101414544: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
101414548: f2955569    	movk	x9, #0xaaab
10141454c: 9bc97d08    	umulh	x8, x8, x9
101414550: d344fd13    	lsr	x19, x8, #4
101414554: 91002314    	add	x20, x24, #0x8
101414558: 14000004    	b	0x101414568 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4900>
10141455c: 91006294    	add	x20, x20, #0x18
101414560: f1000673    	subs	x19, x19, #0x1
101414564: 540000e0    	b.eq	0x101414580 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4918>
101414568: f85f8281    	ldur	x1, [x20, #-0x8]
10141456c: b4ffff81    	cbz	x1, 0x10141455c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x48f4>
101414570: f9400280    	ldr	x0, [x20]
101414574: 52800022    	mov	w2, #0x1                ; =1
101414578: 97da2859    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141457c: 17fffff8    	b	0x10141455c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x48f4>
101414580: b40000d5    	cbz	x21, 0x101414598 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4930>
101414584: 8b1506a8    	add	x8, x21, x21, lsl #1
101414588: d37df101    	lsl	x1, x8, #3
10141458c: f94033e0    	ldr	x0, [sp, #0x60]
101414590: 52800102    	mov	w2, #0x8                ; =8
101414594: 97da2852    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414598: f94063f3    	ldr	x19, [sp, #0xc0]
10141459c: f94087f4    	ldr	x20, [sp, #0x108]
1014145a0: b4000594    	cbz	x20, 0x101414650 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x49e8>
1014145a4: aa1703fa    	mov	x26, x23
1014145a8: f9408ff5    	ldr	x21, [sp, #0x118]
1014145ac: b40003d5    	cbz	x21, 0x101414624 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x49bc>
1014145b0: f94083f6    	ldr	x22, [sp, #0x100]
1014145b4: aa1603f7    	mov	x23, x22
1014145b8: fc4086e0    	ldr	d0, [x23], #0x8
1014145bc: 2e208800    	cmge.8b	v0, v0, #0
