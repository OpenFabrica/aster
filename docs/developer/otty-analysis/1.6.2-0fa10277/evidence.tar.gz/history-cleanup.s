
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010143f7c4 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE>:
10143f7c4: d10683ff    	sub	sp, sp, #0x1a0
10143f7c8: 6d122beb    	stp	d11, d10, [sp, #0x120]
10143f7cc: 6d1323e9    	stp	d9, d8, [sp, #0x130]
10143f7d0: a9146ffc    	stp	x28, x27, [sp, #0x140]
10143f7d4: a91567fa    	stp	x26, x25, [sp, #0x150]
10143f7d8: a9165ff8    	stp	x24, x23, [sp, #0x160]
10143f7dc: a91757f6    	stp	x22, x21, [sp, #0x170]
10143f7e0: a9184ff4    	stp	x20, x19, [sp, #0x180]
10143f7e4: a9197bfd    	stp	x29, x30, [sp, #0x190]
10143f7e8: 910643fd    	add	x29, sp, #0x190
10143f7ec: f9400c16    	ldr	x22, [x0, #0x18]
10143f7f0: f9403009    	ldr	x9, [x0, #0x60]
10143f7f4: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10143f7f8: eb0802df    	cmp	x22, x8
10143f7fc: fa411120    	ccmp	x9, x1, #0x0, ne
10143f800: 54002381    	b.ne	0x10143fc70 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x4ac>
10143f804: aa0203f5    	mov	x21, x2
10143f808: aa0003fa    	mov	x26, x0
10143f80c: a9425c18    	ldp	x24, x23, [x0, #0x20]
10143f810: a9432419    	ldp	x25, x9, [x0, #0x30]
10143f814: f90033e9    	str	x9, [sp, #0x60]
10143f818: a944701b    	ldp	x27, x28, [x0, #0x40]
10143f81c: a9454c09    	ldp	x9, x19, [x0, #0x50]
10143f820: f9002be9    	str	x9, [sp, #0x50]
10143f824: f9000c08    	str	x8, [x0, #0x18]
10143f828: 34002062    	cbz	w2, 0x10143fc34 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x470>
10143f82c: aa0303f4    	mov	x20, x3
10143f830: 9101a3e8    	add	x8, sp, #0x68
10143f834: aa1803e0    	mov	x0, x24
10143f838: aa1703e1    	mov	x1, x23
10143f83c: a90367fc    	stp	x28, x25, [sp, #0x30]
10143f840: 94002b5e    	bl	0x10144a5b8 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E>
10143f844: 7101febf    	cmp	w21, #0x7f
10143f848: 540006e1    	b.ne	0x10143f924 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x160>
10143f84c: aa1803e0    	mov	x0, x24
10143f850: aa1703e1    	mov	x1, x23
10143f854: 97d434d5    	bl	0x10094cba8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b80>
10143f858: f9402be8    	ldr	x8, [sp, #0x50]
10143f85c: a90b4fe8    	stp	x8, x19, [sp, #0xb0]
10143f860: a90c07e0    	stp	x0, x1, [sp, #0xc0]
10143f864: b0007148    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
10143f868: 9126c108    	add	x8, x8, #0x9b0
10143f86c: 9102c3e9    	add	x9, sp, #0xb0
10143f870: a936a3a9    	stp	x9, x8, [x29, #-0x98]
10143f874: 910303e9    	add	x9, sp, #0xc0
10143f878: a937a3a9    	stp	x9, x8, [x29, #-0x88]
10143f87c: f0004502    	adrp	x2, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10143f880: 9102cc42    	add	x2, x2, #0xb3
10143f884: 910203e0    	add	x0, sp, #0x80
10143f888: 9102c341    	add	x1, x26, #0xb0
10143f88c: d10263a4    	sub	x4, x29, #0x98
10143f890: 528007c3    	mov	w3, #0x3e               ; =62
10143f894: 52800045    	mov	w5, #0x2                ; =2
10143f898: f94033f7    	ldr	x23, [sp, #0x60]
10143f89c: 9400d0b5    	bl	0x101473b70 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x67e0>
10143f8a0: d2800273    	mov	x19, #0x13              ; =19
10143f8a4: f2f00013    	movk	x19, #0x8000, lsl #48
10143f8a8: f94043e8    	ldr	x8, [sp, #0x80]
10143f8ac: eb13011f    	cmp	x8, x19
10143f8b0: 54000140    	b.eq	0x10143f8d8 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x114>
10143f8b4: ad4407e0    	ldp	q0, q1, [sp, #0x80]
10143f8b8: ad3a07a0    	stp	q0, q1, [x29, #-0xc0]
10143f8bc: f94053e8    	ldr	x8, [sp, #0xa0]
10143f8c0: f81603a8    	stur	x8, [x29, #-0xa0]
10143f8c4: f85403a8    	ldur	x8, [x29, #-0xc0]
10143f8c8: eb13011f    	cmp	x8, x19
10143f8cc: 54000060    	b.eq	0x10143f8d8 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x114>
10143f8d0: d10303a0    	sub	x0, x29, #0xc0
10143f8d4: 94004f18    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
10143f8d8: a94773f9    	ldp	x25, x28, [sp, #0x70]
10143f8dc: b40019dc    	cbz	x28, 0x10143fc14 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x450>
10143f8e0: 8b1c0788    	add	x8, x28, x28, lsl #1
10143f8e4: d37df114    	lsl	x20, x8, #3
10143f8e8: 91004335    	add	x21, x25, #0x10
10143f8ec: 14000008    	b	0x10143f90c <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x148>
10143f8f0: aa1a03e0    	mov	x0, x26
10143f8f4: aa1703e1    	mov	x1, x23
10143f8f8: aa1b03e2    	mov	x2, x27
10143f8fc: 97fffac7    	bl	0x10143e418 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1b00>
10143f900: 910062b5    	add	x21, x21, #0x18
10143f904: f1006294    	subs	x20, x20, #0x18
10143f908: 54000ec0    	b.eq	0x10143fae0 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x31c>
10143f90c: a97f92a3    	ldp	x3, x4, [x21, #-0x8]
10143f910: b4ffff04    	cbz	x4, 0x10143f8f0 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x12c>
10143f914: 39400068    	ldrb	w8, [x3]
10143f918: 7100b51f    	cmp	w8, #0x2d
10143f91c: 54fffea1    	b.ne	0x10143f8f0 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x12c>
10143f920: 17fffff8    	b	0x10143f900 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x13c>
10143f924: f9400e88    	ldr	x8, [x20, #0x18]
10143f928: a94773f9    	ldp	x25, x28, [sp, #0x70]
10143f92c: f94033f7    	ldr	x23, [sp, #0x60]
10143f930: b40015a8    	cbz	x8, 0x10143fbe4 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x420>
10143f934: b40011bc    	cbz	x28, 0x10143fb68 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x3a4>
10143f938: a9005bf8    	stp	x24, x22, [sp]
10143f93c: 52800308    	mov	w8, #0x18               ; =24
10143f940: 9b086798    	madd	x24, x28, x8, x25
10143f944: 91006328    	add	x8, x25, #0x18
10143f948: a942268a    	ldp	x10, x9, [x20, #0x20]
10143f94c: a9022be9    	stp	x9, x10, [sp, #0x20]
10143f950: a9402a89    	ldp	x9, x10, [x20]
10143f954: a9042be9    	stp	x9, x10, [sp, #0x40]
10143f958: 5280030a    	mov	w10, #0x18              ; =24
10143f95c: 5285a5ab    	mov	w11, #0x2d2d            ; =11565
10143f960: 0f0107a8    	movi.2s	v8, #0x3d
10143f964: aa1903f6    	mov	x22, x25
10143f968: f9000bfb    	str	x27, [sp, #0x10]
10143f96c: 1400002e    	b	0x10143fa24 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x260>
10143f970: a9442be8    	ldp	x8, x10, [sp, #0x40]
10143f974: 8a0a0013    	and	x19, x0, x10
10143f978: fc73690a    	ldr	d10, [x8, x19]
10143f97c: 2e298d40    	cmeq.8b	v0, v10, v9
10143f980: 9e660008    	fmov	x8, d0
10143f984: f201c119    	ands	x25, x8, #0x8080808080808080
10143f988: 540002e0    	b.eq	0x10143f9e4 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x220>
10143f98c: f9000fe9    	str	x9, [sp, #0x18]
10143f990: dac00328    	rbit	x8, x25
10143f994: dac01108    	clz	x8, x8
10143f998: 8b480e68    	add	x8, x19, x8, lsr #3
10143f99c: f94027e9    	ldr	x9, [sp, #0x48]
10143f9a0: 8a090108    	and	x8, x8, x9
10143f9a4: 52800309    	mov	w9, #0x18               ; =24
10143f9a8: 9b09fd08    	mneg	x8, x8, x9
10143f9ac: f94023e9    	ldr	x9, [sp, #0x40]
10143f9b0: 8b080128    	add	x8, x9, x8
10143f9b4: f85f8109    	ldur	x9, [x8, #-0x8]
10143f9b8: eb0902ff    	cmp	x23, x9
10143f9bc: 540000c1    	b.ne	0x10143f9d4 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x210>
10143f9c0: f85f0101    	ldur	x1, [x8, #-0x10]
10143f9c4: aa1503e0    	mov	x0, x21
10143f9c8: aa1703e2    	mov	x2, x23
10143f9cc: 941a2894    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10143f9d0: 340001a0    	cbz	w0, 0x10143fa04 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x240>
10143f9d4: d1000728    	sub	x8, x25, #0x1
10143f9d8: ea190119    	ands	x25, x8, x25
10143f9dc: f9400fe9    	ldr	x9, [sp, #0x18]
10143f9e0: 54fffd81    	b.ne	0x10143f990 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x1cc>
10143f9e4: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
10143f9e8: 2e208d40    	cmeq.8b	v0, v10, v0
10143f9ec: 2e30a800    	umaxv.8b	b0, v0
10143f9f0: 1e260008    	fmov	w8, s0
10143f9f4: 370005e8    	tbnz	w8, #0x0, 0x10143fab0 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x2ec>
10143f9f8: 91002129    	add	x9, x9, #0x8
10143f9fc: 8b090260    	add	x0, x19, x9
10143fa00: 17ffffdc    	b	0x10143f970 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x1ac>
10143fa04: a945dff3    	ldp	x19, x23, [sp, #0x58]
10143fa08: aa1b03f9    	mov	x25, x27
10143fa0c: 5280030a    	mov	w10, #0x18              ; =24
10143fa10: 5285a5ab    	mov	w11, #0x2d2d            ; =11565
10143fa14: eb1802df    	cmp	x22, x24
10143fa18: 9a8a03e8    	csel	x8, xzr, x10, eq
10143fa1c: 8b0802c8    	add	x8, x22, x8
10143fa20: 540008c0    	b.eq	0x10143fb38 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x374>
10143fa24: aa1603e9    	mov	x9, x22
10143fa28: aa0803f6    	mov	x22, x8
10143fa2c: f9400934    	ldr	x20, [x9, #0x10]
10143fa30: f1000a9f    	cmp	x20, #0x2
10143fa34: 54ffff03    	b.lo	0x10143fa14 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x250>
10143fa38: f9400535    	ldr	x21, [x9, #0x8]
10143fa3c: 794002a8    	ldrh	w8, [x21]
10143fa40: 6b0b011f    	cmp	w8, w11
10143fa44: 1a9f07e8    	cset	w8, ne
10143fa48: f1000a9f    	cmp	x20, #0x2
10143fa4c: 7a401900    	ccmp	w8, #0x0, #0x0, ne
10143fa50: 54fffe21    	b.ne	0x10143fa14 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x250>
10143fa54: a90853f5    	stp	x21, x20, [sp, #0x80]
10143fa58: a90953ff    	stp	xzr, x20, [sp, #0x90]
10143fa5c: 52800028    	mov	w8, #0x1                ; =1
10143fa60: 3902a3e8    	strb	w8, [sp, #0xa8]
10143fa64: fd0053e8    	str	d8, [sp, #0xa0]
10143fa68: d10303a0    	sub	x0, x29, #0xc0
10143fa6c: 910203e1    	add	x1, sp, #0x80
10143fa70: 9400b51b    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
10143fa74: aa1903fb    	mov	x27, x25
10143fa78: b85403a8    	ldur	w8, [x29, #-0xc0]
10143fa7c: f85483a9    	ldur	x9, [x29, #-0xb8]
10143fa80: 7100011f    	cmp	w8, #0x0
10143fa84: 9a931133    	csel	x19, x9, x19, ne
10143fa88: f9002ff3    	str	x19, [sp, #0x58]
10143fa8c: 9a941137    	csel	x23, x9, x20, ne
10143fa90: a94203e1    	ldp	x1, x0, [sp, #0x20]
10143fa94: aa1503e2    	mov	x2, x21
10143fa98: aa1703e3    	mov	x3, x23
10143fa9c: 97d436e8    	bl	0x10094d63c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a614>
10143faa0: d2800009    	mov	x9, #0x0                ; =0
10143faa4: d379fc08    	lsr	x8, x0, #57
10143faa8: 0e010d09    	dup.8b	v9, w8
10143faac: 17ffffb1    	b	0x10143f970 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x1ac>
10143fab0: aa1b03f9    	mov	x25, x27
10143fab4: aa1a03e0    	mov	x0, x26
10143fab8: f94033f7    	ldr	x23, [sp, #0x60]
10143fabc: aa1703e1    	mov	x1, x23
10143fac0: f9400be2    	ldr	x2, [sp, #0x10]
10143fac4: aa1503e3    	mov	x3, x21
10143fac8: aa1403e4    	mov	x4, x20
10143facc: 97fffa53    	bl	0x10143e418 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1b00>
10143fad0: 5280030a    	mov	w10, #0x18              ; =24
10143fad4: 5285a5ab    	mov	w11, #0x2d2d            ; =11565
10143fad8: f9402ff3    	ldr	x19, [sp, #0x58]
10143fadc: 17ffffce    	b	0x10143fa14 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x250>
10143fae0: a9409323    	ldp	x3, x4, [x25, #0x8]
10143fae4: aa1a03e0    	mov	x0, x26
10143fae8: 52800021    	mov	w1, #0x1                ; =1
10143faec: d2800002    	mov	x2, #0x0                ; =0
10143faf0: 97fffa4a    	bl	0x10143e418 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1b00>
10143faf4: b0007148    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
10143faf8: 91290108    	add	x8, x8, #0xa40
10143fafc: a93423b9    	stp	x25, x8, [x29, #-0xc0]
10143fb00: f0004502    	adrp	x2, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10143fb04: 9107c842    	add	x2, x2, #0x1f2
10143fb08: 910203e0    	add	x0, sp, #0x80
10143fb0c: 9102c341    	add	x1, x26, #0xb0
10143fb10: d10303a4    	sub	x4, x29, #0xc0
10143fb14: 52800583    	mov	w3, #0x2c               ; =44
10143fb18: 52800025    	mov	w5, #0x1                ; =1
10143fb1c: 9400d015    	bl	0x101473b70 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x67e0>
10143fb20: f94043e8    	ldr	x8, [sp, #0x80]
10143fb24: eb13011f    	cmp	x8, x19
10143fb28: 54000600    	b.eq	0x10143fbe8 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x424>
10143fb2c: 910203e0    	add	x0, sp, #0x80
10143fb30: 94004e81    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
10143fb34: 1400002d    	b	0x10143fbe8 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x424>
10143fb38: 91002333    	add	x19, x25, #0x8
10143fb3c: a9405bf8    	ldp	x24, x22, [sp]
10143fb40: 14000004    	b	0x10143fb50 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x38c>
10143fb44: 91006273    	add	x19, x19, #0x18
10143fb48: f100079c    	subs	x28, x28, #0x1
10143fb4c: 540000e0    	b.eq	0x10143fb68 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x3a4>
10143fb50: f85f8261    	ldur	x1, [x19, #-0x8]
10143fb54: b4ffff81    	cbz	x1, 0x10143fb44 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x380>
10143fb58: f9400260    	ldr	x0, [x19]
10143fb5c: 52800022    	mov	w2, #0x1                ; =1
10143fb60: 97d97adf    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fb64: 17fffff8    	b	0x10143fb44 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x380>
10143fb68: f94037e8    	ldr	x8, [sp, #0x68]
10143fb6c: b40000c8    	cbz	x8, 0x10143fb84 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x3c0>
10143fb70: 8b080508    	add	x8, x8, x8, lsl #1
10143fb74: d37df101    	lsl	x1, x8, #3
10143fb78: aa1903e0    	mov	x0, x25
10143fb7c: 52800102    	mov	w2, #0x8                ; =8
10143fb80: 97d97ad7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fb84: a9434fe1    	ldp	x1, x19, [sp, #0x30]
10143fb88: b4000081    	cbz	x1, 0x10143fb98 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x3d4>
10143fb8c: f9402be0    	ldr	x0, [sp, #0x50]
10143fb90: 52800022    	mov	w2, #0x1                ; =1
10143fb94: 97d97ad2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fb98: b40000b3    	cbz	x19, 0x10143fbac <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x3e8>
10143fb9c: aa1703e0    	mov	x0, x23
10143fba0: aa1303e1    	mov	x1, x19
10143fba4: 52800022    	mov	w2, #0x1                ; =1
10143fba8: 97d97acd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fbac: b4000636    	cbz	x22, 0x10143fc70 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x4ac>
10143fbb0: aa1803e0    	mov	x0, x24
10143fbb4: aa1603e1    	mov	x1, x22
10143fbb8: 52800022    	mov	w2, #0x1                ; =1
10143fbbc: a9597bfd    	ldp	x29, x30, [sp, #0x190]
10143fbc0: a9584ff4    	ldp	x20, x19, [sp, #0x180]
10143fbc4: a95757f6    	ldp	x22, x21, [sp, #0x170]
10143fbc8: a9565ff8    	ldp	x24, x23, [sp, #0x160]
10143fbcc: a95567fa    	ldp	x26, x25, [sp, #0x150]
10143fbd0: a9546ffc    	ldp	x28, x27, [sp, #0x140]
10143fbd4: 6d5323e9    	ldp	d9, d8, [sp, #0x130]
10143fbd8: 6d522beb    	ldp	d11, d10, [sp, #0x120]
10143fbdc: 910683ff    	add	sp, sp, #0x1a0
10143fbe0: 17d97abf    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fbe4: b400019c    	cbz	x28, 0x10143fc14 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x450>
10143fbe8: 91002333    	add	x19, x25, #0x8
10143fbec: 14000004    	b	0x10143fbfc <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x438>
10143fbf0: 91006273    	add	x19, x19, #0x18
10143fbf4: f100079c    	subs	x28, x28, #0x1
10143fbf8: 540000e0    	b.eq	0x10143fc14 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x450>
10143fbfc: f85f8261    	ldur	x1, [x19, #-0x8]
10143fc00: b4ffff81    	cbz	x1, 0x10143fbf0 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x42c>
10143fc04: f9400260    	ldr	x0, [x19]
10143fc08: 52800022    	mov	w2, #0x1                ; =1
10143fc0c: 97d97ab4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fc10: 17fffff8    	b	0x10143fbf0 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x42c>
10143fc14: f94037e8    	ldr	x8, [sp, #0x68]
10143fc18: b40000c8    	cbz	x8, 0x10143fc30 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x46c>
10143fc1c: 8b080508    	add	x8, x8, x8, lsl #1
10143fc20: d37df101    	lsl	x1, x8, #3
10143fc24: aa1903e0    	mov	x0, x25
10143fc28: 52800102    	mov	w2, #0x8                ; =8
10143fc2c: 97d97aac    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fc30: a94367fc    	ldp	x28, x25, [sp, #0x30]
10143fc34: b40000bc    	cbz	x28, 0x10143fc48 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x484>
10143fc38: f9402be0    	ldr	x0, [sp, #0x50]
10143fc3c: aa1c03e1    	mov	x1, x28
10143fc40: 52800022    	mov	w2, #0x1                ; =1
10143fc44: 97d97aa6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fc48: b40000b9    	cbz	x25, 0x10143fc5c <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x498>
10143fc4c: f94033e0    	ldr	x0, [sp, #0x60]
10143fc50: aa1903e1    	mov	x1, x25
10143fc54: 52800022    	mov	w2, #0x1                ; =1
10143fc58: 97d97aa1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fc5c: b40000b6    	cbz	x22, 0x10143fc70 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x4ac>
10143fc60: aa1803e0    	mov	x0, x24
10143fc64: aa1603e1    	mov	x1, x22
10143fc68: 52800022    	mov	w2, #0x1                ; =1
10143fc6c: 97d97a9c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fc70: a9597bfd    	ldp	x29, x30, [sp, #0x190]
10143fc74: a9584ff4    	ldp	x20, x19, [sp, #0x180]
10143fc78: a95757f6    	ldp	x22, x21, [sp, #0x170]
10143fc7c: a9565ff8    	ldp	x24, x23, [sp, #0x160]
10143fc80: a95567fa    	ldp	x26, x25, [sp, #0x150]
10143fc84: a9546ffc    	ldp	x28, x27, [sp, #0x140]
10143fc88: 6d5323e9    	ldp	d9, d8, [sp, #0x130]
10143fc8c: 6d522beb    	ldp	d11, d10, [sp, #0x120]
10143fc90: 910683ff    	add	sp, sp, #0x1a0
10143fc94: d65f03c0    	ret
10143fc98: a9005bf8    	stp	x24, x22, [sp]
10143fc9c: aa0003f4    	mov	x20, x0
10143fca0: 14000007    	b	0x10143fcbc <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x4f8>
10143fca4: 14000002    	b	0x10143fcac <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x4e8>
10143fca8: 14000002    	b	0x10143fcb0 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x4ec>
10143fcac: a9005bf8    	stp	x24, x22, [sp]
10143fcb0: aa0003f4    	mov	x20, x0
10143fcb4: 9101a3e0    	add	x0, sp, #0x68
10143fcb8: 97d40b95    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10143fcbc: f9401be8    	ldr	x8, [sp, #0x30]
10143fcc0: b50000e8    	cbnz	x8, 0x10143fcdc <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x518>
10143fcc4: f9401fe8    	ldr	x8, [sp, #0x38]
10143fcc8: b5000168    	cbnz	x8, 0x10143fcf4 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x530>
10143fccc: f94007e8    	ldr	x8, [sp, #0x8]
10143fcd0: b50001e8    	cbnz	x8, 0x10143fd0c <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x548>
10143fcd4: aa1403e0    	mov	x0, x20
10143fcd8: 941a263f    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10143fcdc: f9402be0    	ldr	x0, [sp, #0x50]
10143fce0: f9401be1    	ldr	x1, [sp, #0x30]
10143fce4: 52800022    	mov	w2, #0x1                ; =1
10143fce8: 97d97a7d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fcec: f9401fe8    	ldr	x8, [sp, #0x38]
10143fcf0: b4fffee8    	cbz	x8, 0x10143fccc <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x508>
10143fcf4: f94033e0    	ldr	x0, [sp, #0x60]
10143fcf8: f9401fe1    	ldr	x1, [sp, #0x38]
10143fcfc: 52800022    	mov	w2, #0x1                ; =1
10143fd00: 97d97a77    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fd04: f94007e8    	ldr	x8, [sp, #0x8]
10143fd08: b4fffe68    	cbz	x8, 0x10143fcd4 <__ZN17otty_autocomplete7history14CommandHistory17cleanup_if_failed17h57006512c8363a7aE+0x510>
10143fd0c: a94007e0    	ldp	x0, x1, [sp]
10143fd10: 52800022    	mov	w2, #0x1                ; =1
10143fd14: 97d97a72    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fd18: aa1403e0    	mov	x0, x20
10143fd1c: 941a262e    	bl	0x101ac95d4 <_writev+0x101ac95d4>

000000010143fd20 <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE>:
10143fd20: d10243ff    	sub	sp, sp, #0x90
10143fd24: a9036ffc    	stp	x28, x27, [sp, #0x30]
10143fd28: a90467fa    	stp	x26, x25, [sp, #0x40]
10143fd2c: a9055ff8    	stp	x24, x23, [sp, #0x50]
10143fd30: a90657f6    	stp	x22, x21, [sp, #0x60]
10143fd34: a9074ff4    	stp	x20, x19, [sp, #0x70]
10143fd38: a9087bfd    	stp	x29, x30, [sp, #0x80]
10143fd3c: 910203fd    	add	x29, sp, #0x80
10143fd40: aa0003f4    	mov	x20, x0
10143fd44: aa0803f3    	mov	x19, x8
10143fd48: d2800276    	mov	x22, #0x13              ; =19
10143fd4c: f2f00016    	movk	x22, #0x8000, lsl #48
10143fd50: f0004502    	adrp	x2, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10143fd54: 91087842    	add	x2, x2, #0x21e
10143fd58: 910023e0    	add	x0, sp, #0x8
10143fd5c: 9102c281    	add	x1, x20, #0xb0
10143fd60: 52800363    	mov	w3, #0x1b               ; =27
10143fd64: 9400ce81    	bl	0x101473768 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x63d8>
10143fd68: f94007e8    	ldr	x8, [sp, #0x8]
10143fd6c: eb16011f    	cmp	x8, x22
10143fd70: 54000541    	b.ne	0x10143fe18 <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE+0xf8>
10143fd74: f0004502    	adrp	x2, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10143fd78: 9108e442    	add	x2, x2, #0x239
10143fd7c: 910023e0    	add	x0, sp, #0x8
10143fd80: 9102c281    	add	x1, x20, #0xb0
10143fd84: 52800343    	mov	w3, #0x1a               ; =26
10143fd88: 9400ce78    	bl	0x101473768 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x63d8>
10143fd8c: f94007e8    	ldr	x8, [sp, #0x8]
10143fd90: eb16011f    	cmp	x8, x22
10143fd94: 54000421    	b.ne	0x10143fe18 <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE+0xf8>
10143fd98: f9409a97    	ldr	x23, [x20, #0x130]
10143fd9c: b40006b7    	cbz	x23, 0x10143fe70 <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE+0x150>
10143fda0: f9408e95    	ldr	x21, [x20, #0x118]
10143fda4: aa1503f8    	mov	x24, x21
10143fda8: fc408700    	ldr	d0, [x24], #0x8
10143fdac: 2e208800    	cmge.8b	v0, v0, #0
10143fdb0: 9e660008    	fmov	x8, d0
10143fdb4: 9201c11b    	and	x27, x8, #0x8080808080808080
10143fdb8: 52800319    	mov	w25, #0x18              ; =24
10143fdbc: aa1503fa    	mov	x26, x21
10143fdc0: 14000005    	b	0x10143fdd4 <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE+0xb4>
10143fdc4: d1000768    	sub	x8, x27, #0x1
10143fdc8: 8a1b011b    	and	x27, x8, x27
10143fdcc: d10006f7    	sub	x23, x23, #0x1
10143fdd0: b4000337    	cbz	x23, 0x10143fe34 <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE+0x114>
10143fdd4: b50000fb    	cbnz	x27, 0x10143fdf0 <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE+0xd0>
10143fdd8: fc408700    	ldr	d0, [x24], #0x8
10143fddc: 2e208800    	cmge.8b	v0, v0, #0
10143fde0: 9e660008    	fmov	x8, d0
10143fde4: d103035a    	sub	x26, x26, #0xc0
10143fde8: 9201c11b    	and	x27, x8, #0x8080808080808080
10143fdec: b4ffff7b    	cbz	x27, 0x10143fdd8 <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE+0xb8>
10143fdf0: dac00368    	rbit	x8, x27
10143fdf4: dac01108    	clz	x8, x8
10143fdf8: cb480fe8    	neg	x8, x8, lsr #3
10143fdfc: 9b396908    	smaddl	x8, w8, w25, x26
10143fe00: f85e8101    	ldur	x1, [x8, #-0x18]
10143fe04: b4fffe01    	cbz	x1, 0x10143fdc4 <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE+0xa4>
10143fe08: f85f0100    	ldur	x0, [x8, #-0x10]
10143fe0c: 52800022    	mov	w2, #0x1                ; =1
10143fe10: 97d97a33    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143fe14: 17ffffec    	b	0x10143fdc4 <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE+0xa4>
10143fe18: f9400be9    	ldr	x9, [sp, #0x10]
10143fe1c: 3cc183e0    	ldur	q0, [sp, #0x18]
10143fe20: 3d800660    	str	q0, [x19, #0x10]
10143fe24: f94017ea    	ldr	x10, [sp, #0x28]
10143fe28: f900126a    	str	x10, [x19, #0x20]
10143fe2c: a9002668    	stp	x8, x9, [x19]
10143fe30: 14000011    	b	0x10143fe74 <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE+0x154>
10143fe34: f9409297    	ldr	x23, [x20, #0x120]
10143fe38: b4000197    	cbz	x23, 0x10143fe68 <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE+0x148>
10143fe3c: 910026e2    	add	x2, x23, #0x9
10143fe40: aa1503e0    	mov	x0, x21
10143fe44: 52801fe1    	mov	w1, #0xff               ; =255
10143fe48: 941a2781    	bl	0x101ac9c4c <_writev+0x101ac9c4c>
10143fe4c: 910006e8    	add	x8, x23, #0x1
10143fe50: d343fd08    	lsr	x8, x8, #3
10143fe54: d37df109    	lsl	x9, x8, #3
10143fe58: cb080128    	sub	x8, x9, x8
10143fe5c: f10022ff    	cmp	x23, #0x8
10143fe60: 9a8832e8    	csel	x8, x23, x8, lo
10143fe64: 14000002    	b	0x10143fe6c <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE+0x14c>
10143fe68: d2800008    	mov	x8, #0x0                ; =0
10143fe6c: a912fe88    	stp	x8, xzr, [x20, #0x128]
10143fe70: f9000276    	str	x22, [x19]
10143fe74: a9487bfd    	ldp	x29, x30, [sp, #0x80]
10143fe78: a9474ff4    	ldp	x20, x19, [sp, #0x70]
10143fe7c: a94657f6    	ldp	x22, x21, [sp, #0x60]
10143fe80: a9455ff8    	ldp	x24, x23, [sp, #0x50]
10143fe84: a94467fa    	ldp	x26, x25, [sp, #0x40]
10143fe88: a9436ffc    	ldp	x28, x27, [sp, #0x30]
10143fe8c: 910243ff    	add	sp, sp, #0x90
10143fe90: d65f03c0    	ret
