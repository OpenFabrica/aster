10066c268:     	sub	sp, sp, #0x40
10066c26c:     	stp	x20, x19, [sp, #0x20]
10066c270:     	stp	x29, x30, [sp, #0x30]
10066c274:     	add	x29, sp, #0x30
10066c278:     	adrp	x8, 0x1023da000
10066c27c:     	ldr	x19, [x8, #0x3c0]
10066c280:     	add	x0, x20, x19
10066c284:     	add	x1, sp, #0x8
10066c288:     	mov	x2, #0x0                ; =0
10066c28c:     	mov	x3, #0x0                ; =0
10066c290:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066c294:     	ldrb	w0, [x20, x19]
10066c298:     	ldp	x29, x30, [sp, #0x30]
10066c29c:     	ldp	x20, x19, [sp, #0x20]
10066c2a0:     	add	sp, sp, #0x40
10066c2a4:     	ret
10066c2a8:     	sub	sp, sp, #0x50
10066c2ac:     	stp	x22, x21, [sp, #0x20]
10066c2b0:     	stp	x20, x19, [sp, #0x30]
10066c2b4:     	stp	x29, x30, [sp, #0x40]
10066c2b8:     	add	x29, sp, #0x40
10066c2bc:     	mov	x19, x0
10066c2c0:     	adrp	x8, 0x1023da000
10066c2c4:     	ldr	x21, [x8, #0x3c0]
10066c2c8:     	add	x0, x20, x21
10066c2cc:     	add	x1, sp, #0x8
10066c2d0:     	mov	w2, #0x1                ; =1
10066c2d4:     	mov	x3, #0x0                ; =0
10066c2d8:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066c2dc:     	strb	w19, [x20, x21]
10066c2e0:     	ldp	x29, x30, [sp, #0x40]
10066c2e4:     	ldp	x20, x19, [sp, #0x30]
10066c2e8:     	ldp	x22, x21, [sp, #0x20]
10066c2ec:     	add	sp, sp, #0x50
10066c2f0:     	ret
10066c2f4:     	stp	x20, x19, [sp, #-0x20]!
10066c2f8:     	stp	x29, x30, [sp, #0x10]
10066c2fc:     	add	x29, sp, #0x10
10066c300:     	mov	x1, x0
10066c304:     	adrp	x8, 0x1023da000
10066c308:     	ldr	x19, [x8, #0x3c0]
10066c30c:     	add	x0, x20, x19
10066c310:     	mov	w2, #0x21               ; =33
10066c314:     	mov	x3, #0x0                ; =0
10066c318:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066c31c:     	adrp	x0, 0x10002d000
10066c320:     	add	x0, x0, #0xd0c
10066c324:     	add	x1, x20, x19
10066c328:     	ldp	x29, x30, [sp, #0x10]
10066c32c:     	ldp	x20, x19, [sp], #0x20
10066c330:     	ret
10066c334:     	adrp	x0, 0x1023da000
10066c338:     	add	x0, x0, #0x3c8
10066c33c:     	b	0x100252ff4
10066c340:     	adrp	x2, 0x1023da000
10066c344:     	add	x2, x2, #0x3c8
10066c348:     	b	0x100253050
10066c34c:     	stp	x20, x19, [sp, #-0x20]!
10066c350:     	stp	x29, x30, [sp, #0x10]
10066c354:     	add	x29, sp, #0x10
10066c358:     	mov	x1, x0
10066c35c:     	adrp	x8, 0x1023da000
10066c360:     	ldr	x19, [x8, #0x3c8]
10066c364:     	add	x0, x20, x19
10066c368:     	mov	w2, #0x21               ; =33
10066c36c:     	mov	x3, #0x0                ; =0
10066c370:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066c374:     	adrp	x0, 0x10002d000
10066c378:     	add	x0, x0, #0xd0c
10066c37c:     	add	x1, x20, x19
10066c380:     	ldp	x29, x30, [sp, #0x10]
10066c384:     	ldp	x20, x19, [sp], #0x20
10066c388:     	ret
10066c38c:     	adrp	x0, 0x1023da000
10066c390:     	add	x0, x0, #0x3d0
10066c394:     	b	0x100252ff4
10066c398:     	adrp	x2, 0x1023da000
10066c39c:     	add	x2, x2, #0x3d0
10066c3a0:     	b	0x100253050
10066c3a4:     	stp	x20, x19, [sp, #-0x20]!
10066c3a8:     	stp	x29, x30, [sp, #0x10]
10066c3ac:     	add	x29, sp, #0x10
10066c3b0:     	mov	x1, x0
10066c3b4:     	adrp	x8, 0x1023da000
10066c3b8:     	ldr	x19, [x8, #0x3d0]
10066c3bc:     	add	x0, x20, x19
10066c3c0:     	mov	w2, #0x21               ; =33
10066c3c4:     	mov	x3, #0x0                ; =0
10066c3c8:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066c3cc:     	adrp	x0, 0x10002d000
10066c3d0:     	add	x0, x0, #0xd0c
10066c3d4:     	add	x1, x20, x19
10066c3d8:     	ldp	x29, x30, [sp, #0x10]
10066c3dc:     	ldp	x20, x19, [sp], #0x20
10066c3e0:     	ret
10066c3e4:     	adrp	x0, 0x1023da000
10066c3e8:     	add	x0, x0, #0x3d8
10066c3ec:     	b	0x100252ff4
10066c3f0:     	adrp	x2, 0x1023da000
10066c3f4:     	add	x2, x2, #0x3d8
10066c3f8:     	b	0x100253050
10066c3fc:     	stp	x20, x19, [sp, #-0x20]!
10066c400:     	stp	x29, x30, [sp, #0x10]
10066c404:     	add	x29, sp, #0x10
10066c408:     	mov	x1, x0
10066c40c:     	adrp	x8, 0x1023da000
10066c410:     	ldr	x19, [x8, #0x3d8]
10066c414:     	add	x0, x20, x19
10066c418:     	mov	w2, #0x21               ; =33
10066c41c:     	mov	x3, #0x0                ; =0
10066c420:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066c424:     	adrp	x0, 0x10002d000
10066c428:     	add	x0, x0, #0xd0c
10066c42c:     	add	x1, x20, x19
10066c430:     	ldp	x29, x30, [sp, #0x10]
10066c434:     	ldp	x20, x19, [sp], #0x20
10066c438:     	ret
10066c43c:     	sub	sp, sp, #0x50
10066c440:     	stp	x24, x23, [sp, #0x10]
10066c444:     	stp	x22, x21, [sp, #0x20]
10066c448:     	stp	x20, x19, [sp, #0x30]
10066c44c:     	stp	x29, x30, [sp, #0x40]
10066c450:     	add	x29, sp, #0x40
10066c454:     	ldr	x8, [x20]
10066c458:     	ldr	x23, [x8, #0x618]
10066c45c:     	blr	x23
10066c460:     	mov	x22, x1
10066c464:     	bl	0x1000bbb04
10066c468:     	mov	x21, x0
10066c46c:     	mov	x19, x1
10066c470:     	mov	x0, x22
10066c474:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c478:     	cbz	x19, 0x10066c4cc
10066c47c:     	mov	x0, x21
10066c480:     	mov	x1, x19
10066c484:     	bl	0x101ac5fc8
10066c488:     	mov	x21, x0
10066c48c:     	mov	x0, x19
10066c490:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c494:     	blr	x23
10066c498:     	tbnz	w21, #0x0, 0x10066c4d4
10066c49c:     	stp	x0, x1, [sp]
10066c4a0:     	mov	x0, x1
10066c4a4:     	mov	x19, x1
10066c4a8:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066c4ac:     	mov	x20, sp
10066c4b0:     	mov	w0, #0x20               ; =32
10066c4b4:     	mov	x1, #-0x1f00000000000000 ; =-2233785415175766016
10066c4b8:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066c4bc:     	mov	x0, x19
10066c4c0:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c4c4:     	ldp	x0, x1, [sp]
10066c4c8:     	b	0x10066c4d4
10066c4cc:     	mov	x0, #0x0                ; =0
10066c4d0:     	mov	x1, #-0x2000000000000000 ; =-2305843009213693952
10066c4d4:     	ldp	x29, x30, [sp, #0x40]
10066c4d8:     	ldp	x20, x19, [sp, #0x30]
10066c4dc:     	ldp	x22, x21, [sp, #0x20]
10066c4e0:     	ldp	x24, x23, [sp, #0x10]
10066c4e4:     	add	sp, sp, #0x50
10066c4e8:     	ret
10066c4ec:     	stp	x26, x25, [sp, #-0x50]!
10066c4f0:     	stp	x24, x23, [sp, #0x10]
10066c4f4:     	stp	x22, x21, [sp, #0x20]
10066c4f8:     	stp	x20, x19, [sp, #0x30]
10066c4fc:     	stp	x29, x30, [sp, #0x40]
10066c500:     	add	x29, sp, #0x40
10066c504:     	mov	x0, #0x0                ; =0
10066c508:     	bl	0x10068c794
10066c50c:     	mov	x22, x0
10066c510:     	ldur	x26, [x0, #-0x8]
10066c514:     	ldr	x8, [x26, #0x40]
10066c518:     	mov	x9, x8
10066c51c:     	adrp	x16, 0x1022cb000
10066c520:     	ldr	x16, [x16, #0x398]
10066c524:     	blr	x16
10066c528:     	mov	x9, sp
10066c52c:     	add	x8, x8, #0xf
10066c530:     	and	x8, x8, #0xfffffffffffffff0
10066c534:     	sub	x19, x9, x8
10066c538:     	mov	sp, x19
10066c53c:     	adrp	x0, 0x102341000
10066c540:     	add	x0, x0, #0x4a0
10066c544:     	adrp	x1, 0x101ae1000
10066c548:     	add	x1, x1, #0xc60 ; possible literal ',)4'
10066c54c:     	bl	0x100003c4c
10066c550:     	ldur	x8, [x0, #-0x8]
10066c554:     	ldr	x9, [x8, #0x40]
10066c558:     	add	x8, x9, #0xf
10066c55c:     	and	x8, x8, #0xfffffffffffffff0
10066c560:     	adrp	x16, 0x1022cb000
10066c564:     	ldr	x16, [x16, #0x398]
10066c568:     	blr	x16
10066c56c:     	mov	x9, sp
10066c570:     	sub	x23, x9, x8
10066c574:     	mov	sp, x23
10066c578:     	ldr	x21, [x20, #0x18]
10066c57c:     	ldr	x8, [x21]
10066c580:     	ldr	x8, [x8, #0x118]
10066c584:     	mov	x20, x21
10066c588:     	blr	x8
10066c58c:     	mov	x25, x0
10066c590:     	mov	x24, x1
10066c594:     	ldr	x8, [x21]
10066c598:     	ldr	x8, [x8, #0x90]
10066c59c:     	blr	x8
10066c5a0:     	mov	x20, x0
10066c5a4:     	ldr	x8, [x0, #0x10]
10066c5a8:     	cbz	x8, 0x10066c5f0
10066c5ac:     	mov	x0, x25
10066c5b0:     	mov	x1, x24
10066c5b4:     	bl	0x1000240a8
10066c5b8:     	tbz	w1, #0x0, 0x10066c5f0
10066c5bc:     	ldr	x8, [x20, #0x38]
10066c5c0:     	ldr	x9, [x26, #0x48]
10066c5c4:     	madd	x0, x9, x0, x8
10066c5c8:     	adrp	x2, 0x10068c000
10066c5cc:     	add	x2, x2, #0x794 ; possible literal '��'
10066c5d0:     	mov	x1, x23
10066c5d4:     	bl	0x1000e73b0
10066c5d8:     	mov	x0, x20
10066c5dc:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c5e0:     	mov	x0, x24
10066c5e4:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c5e8:     	mov	w1, #0x0                ; =0
10066c5ec:     	b	0x10066c604
10066c5f0:     	mov	x0, x20
10066c5f4:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c5f8:     	mov	x0, x24
10066c5fc:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c600:     	mov	w1, #0x1                ; =1
10066c604:     	ldr	x8, [x26, #0x38]
10066c608:     	mov	x0, x23
10066c60c:     	mov	w2, #0x1                ; =1
10066c610:     	mov	x3, x22
10066c614:     	blr	x8
10066c618:     	ldr	x8, [x26, #0x30]
10066c61c:     	mov	x0, x23
10066c620:     	mov	w1, #0x1                ; =1
10066c624:     	mov	x2, x22
10066c628:     	blr	x8
10066c62c:     	cbz	w0, 0x10066c688
10066c630:     	adrp	x1, 0x102341000
10066c634:     	add	x1, x1, #0x4a0
10066c638:     	adrp	x2, 0x101ae1000
10066c63c:     	add	x2, x2, #0xc60 ; possible literal ',)4'
10066c640:     	mov	x0, x23
10066c644:     	bl	0x10002d870
10066c648:     	ldr	x8, [x21]
10066c64c:     	ldr	x8, [x8, #0x128]
10066c650:     	mov	x20, x21
10066c654:     	blr	x8
10066c658:     	cbz	x0, 0x10066c6e0
10066c65c:     	ldr	x8, [x0]
10066c660:     	ldr	x8, [x8, #0x3f0]
10066c664:     	mov	x20, x0
10066c668:     	mov	x19, x0
10066c66c:     	blr	x8
10066c670:     	mov	x20, x0
10066c674:     	mov	x21, x1
10066c678:     	mov	x0, x19
10066c67c:     	bl	0x101aca960 ; symbol _swift_release
10066c680:     	mov	x1, x21
10066c684:     	b	0x10066c6e8
10066c688:     	adrp	x22, 0x10068c000
10066c68c:     	add	x22, x22, #0x794 ; possible literal '��'
10066c690:     	mov	x0, x23
10066c694:     	mov	x1, x19
10066c698:     	mov	x2, x22
10066c69c:     	bl	0x1000e73b0
10066c6a0:     	adrp	x1, 0x102341000
10066c6a4:     	add	x1, x1, #0x4a0
10066c6a8:     	adrp	x2, 0x101ae1000
10066c6ac:     	add	x2, x2, #0xc60 ; possible literal ',)4'
10066c6b0:     	mov	x0, x23
10066c6b4:     	bl	0x10002d870
10066c6b8:     	mov	x20, x19
10066c6bc:     	bl	0x100663ea8
10066c6c0:     	mov	x20, x0
10066c6c4:     	mov	x23, x1
10066c6c8:     	mov	x0, x19
10066c6cc:     	mov	x1, x22
10066c6d0:     	bl	0x100059058
10066c6d4:     	cbz	x23, 0x10066c648
10066c6d8:     	mov	x1, x23
10066c6dc:     	b	0x10066c6e8
10066c6e0:     	mov	x20, #0x0               ; =0
10066c6e4:     	mov	x1, #-0x2000000000000000 ; =-2305843009213693952
10066c6e8:     	mov	x0, x20
10066c6ec:     	sub	sp, x29, #0x40
10066c6f0:     	ldp	x29, x30, [sp, #0x40]
10066c6f4:     	ldp	x20, x19, [sp, #0x30]
10066c6f8:     	ldp	x22, x21, [sp, #0x20]
10066c6fc:     	ldp	x24, x23, [sp, #0x10]
10066c700:     	ldp	x26, x25, [sp], #0x50
10066c704:     	ret
10066c708:     	stp	x28, x27, [sp, #-0x60]!
10066c70c:     	stp	x26, x25, [sp, #0x10]
10066c710:     	stp	x24, x23, [sp, #0x20]
10066c714:     	stp	x22, x21, [sp, #0x30]
10066c718:     	stp	x20, x19, [sp, #0x40]
10066c71c:     	stp	x29, x30, [sp, #0x50]
10066c720:     	add	x29, sp, #0x50
10066c724:     	mov	x19, x20
10066c728:     	mov	x0, #0x0                ; =0
10066c72c:     	bl	0x10068c794
10066c730:     	mov	x23, x0
10066c734:     	ldur	x27, [x0, #-0x8]
10066c738:     	ldr	x8, [x27, #0x40]
10066c73c:     	mov	x9, x8
10066c740:     	adrp	x16, 0x1022cb000
10066c744:     	ldr	x16, [x16, #0x398]
10066c748:     	blr	x16
10066c74c:     	mov	x9, sp
10066c750:     	add	x8, x8, #0xf
10066c754:     	and	x8, x8, #0xfffffffffffffff0
10066c758:     	sub	x21, x9, x8
10066c75c:     	mov	sp, x21
10066c760:     	adrp	x0, 0x102341000
10066c764:     	add	x0, x0, #0x4a0
10066c768:     	adrp	x1, 0x101ae1000
10066c76c:     	add	x1, x1, #0xc60 ; possible literal ',)4'
10066c770:     	bl	0x100003c4c
10066c774:     	ldur	x8, [x0, #-0x8]
10066c778:     	ldr	x9, [x8, #0x40]
10066c77c:     	add	x8, x9, #0xf
10066c780:     	and	x8, x8, #0xfffffffffffffff0
10066c784:     	adrp	x16, 0x1022cb000
10066c788:     	ldr	x16, [x16, #0x398]
10066c78c:     	blr	x16
10066c790:     	mov	x9, sp
10066c794:     	sub	x24, x9, x8
10066c798:     	mov	sp, x24
10066c79c:     	ldr	x22, [x20, #0x18]
10066c7a0:     	ldr	x8, [x22]
10066c7a4:     	ldr	x8, [x8, #0x118]
10066c7a8:     	mov	x20, x22
10066c7ac:     	blr	x8
10066c7b0:     	mov	x26, x0
10066c7b4:     	mov	x25, x1
10066c7b8:     	ldr	x8, [x22]
10066c7bc:     	ldr	x8, [x8, #0x90]
10066c7c0:     	blr	x8
10066c7c4:     	mov	x20, x0
10066c7c8:     	ldr	x8, [x0, #0x10]
10066c7cc:     	cbz	x8, 0x10066c814
10066c7d0:     	mov	x0, x26
10066c7d4:     	mov	x1, x25
10066c7d8:     	bl	0x1000240a8
10066c7dc:     	tbz	w1, #0x0, 0x10066c814
10066c7e0:     	ldr	x8, [x20, #0x38]
10066c7e4:     	ldr	x9, [x27, #0x48]
10066c7e8:     	madd	x0, x9, x0, x8
10066c7ec:     	adrp	x2, 0x10068c000
10066c7f0:     	add	x2, x2, #0x794 ; possible literal '��'
10066c7f4:     	mov	x1, x24
10066c7f8:     	bl	0x1000e73b0
10066c7fc:     	mov	x0, x20
10066c800:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c804:     	mov	x0, x25
10066c808:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c80c:     	mov	w1, #0x0                ; =0
10066c810:     	b	0x10066c828
10066c814:     	mov	x0, x20
10066c818:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c81c:     	mov	x0, x25
10066c820:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c824:     	mov	w1, #0x1                ; =1
10066c828:     	ldr	x8, [x27, #0x38]
10066c82c:     	mov	x0, x24
10066c830:     	mov	w2, #0x1                ; =1
10066c834:     	mov	x3, x23
10066c838:     	blr	x8
10066c83c:     	ldr	x8, [x27, #0x30]
10066c840:     	mov	x0, x24
10066c844:     	mov	w1, #0x1                ; =1
10066c848:     	mov	x2, x23
10066c84c:     	blr	x8
10066c850:     	cbz	w0, 0x10066c8ac
10066c854:     	adrp	x1, 0x102341000
10066c858:     	add	x1, x1, #0x4a0
10066c85c:     	adrp	x2, 0x101ae1000
10066c860:     	add	x2, x2, #0xc60 ; possible literal ',)4'
10066c864:     	mov	x0, x24
10066c868:     	bl	0x10002d870
10066c86c:     	ldr	x8, [x22]
10066c870:     	ldr	x8, [x8, #0x128]
10066c874:     	mov	x20, x22
10066c878:     	blr	x8
10066c87c:     	cbz	x0, 0x10066c908
10066c880:     	mov	x20, x0
10066c884:     	ldr	x8, [x0]
10066c888:     	ldr	x8, [x8, #0x3f8]
10066c88c:     	blr	x8
10066c890:     	mov	x21, x0
10066c894:     	mov	x22, x1
10066c898:     	mov	x0, x20
10066c89c:     	bl	0x101aca960 ; symbol _swift_release
10066c8a0:     	mov	x1, x22
10066c8a4:     	mov	x0, x21
10066c8a8:     	b	0x10066c90c
10066c8ac:     	adrp	x23, 0x10068c000
10066c8b0:     	add	x23, x23, #0x794 ; possible literal '��'
10066c8b4:     	mov	x0, x24
10066c8b8:     	mov	x1, x21
10066c8bc:     	mov	x2, x23
10066c8c0:     	bl	0x1000e73b0
10066c8c4:     	adrp	x1, 0x102341000
10066c8c8:     	add	x1, x1, #0x4a0
10066c8cc:     	adrp	x2, 0x101ae1000
10066c8d0:     	add	x2, x2, #0xc60 ; possible literal ',)4'
10066c8d4:     	mov	x0, x24
10066c8d8:     	bl	0x10002d870
10066c8dc:     	mov	x20, x21
10066c8e0:     	bl	0x100663ea8
10066c8e4:     	mov	x20, x0
10066c8e8:     	mov	x24, x1
10066c8ec:     	mov	x0, x21
10066c8f0:     	mov	x1, x23
10066c8f4:     	bl	0x100059058
10066c8f8:     	cbz	x24, 0x10066c86c
10066c8fc:     	mov	x1, x24
10066c900:     	mov	x0, x20
10066c904:     	b	0x10066c90c
10066c908:     	mov	x1, #-0x2000000000000000 ; =-2305843009213693952
10066c90c:     	and	x8, x0, #0xffffffffffff
10066c910:     	ubfx	x9, x1, #56, #4
10066c914:     	tst	x1, #0x2000000000000000
10066c918:     	csel	x8, x8, x9, eq
10066c91c:     	cbnz	x8, 0x10066c938
10066c920:     	mov	x0, x1
10066c924:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066c928:     	ldr	x8, [x19]
10066c92c:     	ldr	x8, [x8, #0x630]
10066c930:     	mov	x20, x19
10066c934:     	blr	x8
10066c938:     	sub	sp, x29, #0x50
10066c93c:     	ldp	x29, x30, [sp, #0x50]
10066c940:     	ldp	x20, x19, [sp, #0x40]
10066c944:     	ldp	x22, x21, [sp, #0x30]
10066c948:     	ldp	x24, x23, [sp, #0x20]
10066c94c:     	ldp	x26, x25, [sp, #0x10]
10066c950:     	ldp	x28, x27, [sp], #0x60
10066c954:     	ret
10066c958:     	stp	x29, x30, [sp, #-0x10]!
10066c95c:     	mov	x29, sp
10066c960:     	ldr	x8, [x20]
10066c964:     	ldr	x8, [x8, #0x5e8]
10066c968:     	blr	x8
10066c96c:     	and	w8, w0, #0xff
10066c970:     	ldr	x9, [x20]
10066c974:     	cmp	w8, #0x1
10066c978:     	mov	w8, #0x650              ; =1616
10066c97c:     	mov	w10, #0x600             ; =1536
10066c980:     	csel	x8, x10, x8, eq
10066c984:     	ldr	x0, [x9, x8]
10066c988:     	ldp	x29, x30, [sp], #0x10
10066c98c:     	br	x0
10066c990:     	sub	sp, sp, #0x70
10066c994:     	stp	x28, x27, [sp, #0x10]
10066c998:     	stp	x26, x25, [sp, #0x20]
10066c99c:     	stp	x24, x23, [sp, #0x30]
10066c9a0:     	stp	x22, x21, [sp, #0x40]
10066c9a4:     	stp	x20, x19, [sp, #0x50]
10066c9a8:     	stp	x29, x30, [sp, #0x60]
10066c9ac:     	add	x29, sp, #0x60
10066c9b0:     	mov	x22, x5
10066c9b4:     	mov	x23, x4
10066c9b8:     	mov	x24, x3
10066c9bc:     	mov	x19, x1
10066c9c0:     	mov	x21, x0
10066c9c4:     	mov	w8, #0x7561             ; =30049
10066c9c8:     	movk	w8, #0x6f74, lsl #16
10066c9cc:     	cmp	x3, #0x0
10066c9d0:     	csel	x25, x8, x2, eq
10066c9d4:     	mov	x8, #-0x1c00000000000000 ; =-2017612633061982208
10066c9d8:     	csel	x26, x8, x3, eq
10066c9dc:     	adrp	x0, 0x102341000
10066c9e0:     	add	x0, x0, #0xc28
10066c9e4:     	adrp	x1, 0x101ae3000
10066c9e8:     	add	x1, x1, #0x540
10066c9ec:     	bl	0x100003c4c
10066c9f0:     	adrp	x1, 0x10235e000
10066c9f4:     	add	x1, x1, #0xde8
10066c9f8:     	bl	0x101aca8c4 ; symbol _swift_initStaticObject
10066c9fc:     	mov	x27, x0
10066ca00:     	mov	x0, x24
10066ca04:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066ca08:     	mov	x0, x27
10066ca0c:     	mov	x1, x25
10066ca10:     	mov	x2, x26
10066ca14:     	bl	0x101ac79fc
10066ca18:     	mov	x24, x0
10066ca1c:     	mov	x0, x26
10066ca20:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066ca24:     	cmp	x24, #0x1
10066ca28:     	cset	w8, eq
10066ca2c:     	cmp	x24, #0x2
10066ca30:     	mov	w9, #0x2                ; =2
10066ca34:     	csel	w24, w9, w8, eq
10066ca38:     	ldr	x8, [x20]
10066ca3c:     	ldr	x8, [x8, #0x5f0]
10066ca40:     	mov	x0, x24
10066ca44:     	blr	x8
10066ca48:     	cbz	w24, 0x10066ca74
10066ca4c:     	cmp	w24, #0x1
10066ca50:     	b.ne	0x10066caa0
10066ca54:     	ldr	x8, [x20]
10066ca58:     	ldr	x22, [x8, #0x608]
10066ca5c:     	mov	x0, x19
10066ca60:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066ca64:     	mov	x0, x21
10066ca68:     	mov	x1, x19
10066ca6c:     	blr	x22
10066ca70:     	b	0x10066cacc
10066ca74:     	ldr	x8, [x20]
10066ca78:     	ldr	x8, [x8, #0x608]
10066ca7c:     	mov	x0, #0x0                ; =0
10066ca80:     	mov	x1, #-0x2000000000000000 ; =-2305843009213693952
10066ca84:     	blr	x8
10066ca88:     	ldr	x8, [x20]
10066ca8c:     	ldr	x8, [x8, #0x620]
10066ca90:     	mov	x0, #0x0                ; =0
10066ca94:     	mov	x1, #-0x2000000000000000 ; =-2305843009213693952
10066ca98:     	blr	x8
10066ca9c:     	b	0x10066cacc
10066caa0:     	cmp	x22, #0x0
10066caa4:     	csel	x23, xzr, x23, eq
10066caa8:     	mov	x8, #-0x2000000000000000 ; =-2305843009213693952
10066caac:     	csel	x24, x8, x22, eq
10066cab0:     	ldr	x8, [x20]
10066cab4:     	ldr	x25, [x8, #0x620]
10066cab8:     	mov	x0, x22
10066cabc:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066cac0:     	mov	x0, x23
10066cac4:     	mov	x1, x24
10066cac8:     	blr	x25
10066cacc:     	ldr	x8, [x20]
10066cad0:     	ldr	x0, [x8, #0x638]
10066cad4:     	str	x0, [sp, #0x8]
10066cad8:     	mov	x0, x19
10066cadc:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066cae0:     	mov	x0, x21
10066cae4:     	mov	x1, x19
10066cae8:     	ldr	x2, [sp, #0x8]
10066caec:     	ldp	x29, x30, [sp, #0x60]
10066caf0:     	ldp	x20, x19, [sp, #0x50]
10066caf4:     	ldp	x22, x21, [sp, #0x40]
10066caf8:     	ldp	x24, x23, [sp, #0x30]
10066cafc:     	ldp	x26, x25, [sp, #0x20]
10066cb00:     	ldp	x28, x27, [sp, #0x10]
10066cb04:     	add	sp, sp, #0x70
10066cb08:     	br	x2
10066cb0c:     	sub	sp, sp, #0x50
10066cb10:     	stp	x24, x23, [sp, #0x10]
10066cb14:     	stp	x22, x21, [sp, #0x20]
10066cb18:     	stp	x20, x19, [sp, #0x30]
10066cb1c:     	stp	x29, x30, [sp, #0x40]
10066cb20:     	add	x29, sp, #0x40
10066cb24:     	ldr	x8, [x20]
10066cb28:     	ldr	x8, [x8, #0x5e8]
10066cb2c:     	blr	x8
10066cb30:     	ldr	x8, [x20]
10066cb34:     	ands	w9, w0, #0xff
10066cb38:     	b.eq	0x10066cb4c
10066cb3c:     	cmp	w9, #0x1
10066cb40:     	b.ne	0x10066cb68
10066cb44:     	ldr	x0, [x8, #0x600]
10066cb48:     	b	0x10066cb50
10066cb4c:     	ldr	x0, [x8, #0x650]
10066cb50:     	ldp	x29, x30, [sp, #0x40]
10066cb54:     	ldp	x20, x19, [sp, #0x30]
10066cb58:     	ldp	x22, x21, [sp, #0x20]
10066cb5c:     	ldp	x24, x23, [sp, #0x10]
10066cb60:     	add	sp, sp, #0x50
10066cb64:     	br	x0
10066cb68:     	ldr	x8, [x8, #0x648]
10066cb6c:     	blr	x8
10066cb70:     	mov	x19, x0
10066cb74:     	mov	x21, x1
10066cb78:     	ldr	x8, [x20]
10066cb7c:     	ldr	x8, [x8, #0x650]
10066cb80:     	blr	x8
10066cb84:     	mov	x22, x0
10066cb88:     	mov	x23, x1
10066cb8c:     	stp	x19, x21, [sp]
10066cb90:     	mov	x0, x21
10066cb94:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066cb98:     	mov	x20, sp
10066cb9c:     	mov	x0, x22
10066cba0:     	mov	x1, x23
10066cba4:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066cba8:     	mov	x0, x21
10066cbac:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066cbb0:     	mov	x0, x23
10066cbb4:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066cbb8:     	ldp	x0, x1, [sp]
10066cbbc:     	ldp	x29, x30, [sp, #0x40]
10066cbc0:     	ldp	x20, x19, [sp, #0x30]
10066cbc4:     	ldp	x22, x21, [sp, #0x20]
10066cbc8:     	ldp	x24, x23, [sp, #0x10]
10066cbcc:     	add	sp, sp, #0x50
10066cbd0:     	ret
10066cbd4:     	stp	x22, x21, [sp, #-0x30]!
10066cbd8:     	stp	x20, x19, [sp, #0x10]
10066cbdc:     	stp	x29, x30, [sp, #0x20]
10066cbe0:     	add	x29, sp, #0x20
10066cbe4:     	ldr	x8, [x20]
10066cbe8:     	ldr	x8, [x8, #0x650]
10066cbec:     	blr	x8
10066cbf0:     	and	x8, x0, #0xffffffffffff
10066cbf4:     	ubfx	x9, x1, #56, #4
10066cbf8:     	tst	x1, #0x2000000000000000
10066cbfc:     	csel	x8, x8, x9, eq
10066cc00:     	cbnz	x8, 0x10066cc60
10066cc04:     	mov	x0, x1
10066cc08:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066cc0c:     	ldr	x8, [x20]
10066cc10:     	ldr	x8, [x8, #0x688]
10066cc14:     	blr	x8
10066cc18:     	and	x8, x0, #0xffffffffffff
10066cc1c:     	ubfx	x9, x1, #56, #4
10066cc20:     	tst	x1, #0x2000000000000000
10066cc24:     	csel	x8, x8, x9, eq
10066cc28:     	cbz	x8, 0x10066cc50
10066cc2c:     	mov	x19, x1
10066cc30:     	bl	0x10006aee0
10066cc34:     	mov	x20, x0
10066cc38:     	mov	x21, x1
10066cc3c:     	mov	x0, x19
10066cc40:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066cc44:     	mov	x0, x20
10066cc48:     	mov	x1, x21
10066cc4c:     	b	0x10066cc60
10066cc50:     	mov	x0, x1
10066cc54:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066cc58:     	mov	x0, #0x0                ; =0
10066cc5c:     	mov	x1, #-0x2000000000000000 ; =-2305843009213693952
10066cc60:     	ldp	x29, x30, [sp, #0x20]
10066cc64:     	ldp	x20, x19, [sp, #0x10]
10066cc68:     	ldp	x22, x21, [sp], #0x30
10066cc6c:     	ret
10066cc70:     	sub	sp, sp, #0x60
10066cc74:     	stp	x24, x23, [sp, #0x20]
10066cc78:     	stp	x22, x21, [sp, #0x30]
10066cc7c:     	stp	x20, x19, [sp, #0x40]
10066cc80:     	stp	x29, x30, [sp, #0x50]
10066cc84:     	add	x29, sp, #0x50
10066cc88:     	ldr	x8, [x20]
10066cc8c:     	ldr	x8, [x8, #0x5e8]
10066cc90:     	blr	x8
10066cc94:     	ldr	x8, [x20]
10066cc98:     	ands	w9, w0, #0xff
10066cc9c:     	b.eq	0x10066ccb0
10066cca0:     	cmp	w9, #0x1
10066cca4:     	b.ne	0x10066cce8
10066cca8:     	ldr	x0, [x8, #0x600]
10066ccac:     	b	0x10066cd8c
10066ccb0:     	ldr	x0, [x8, #0x658]
10066ccb4:     	str	x0, [sp, #0x8]
10066ccb8:     	blr	x0
10066ccbc:     	mov	x19, x0
10066ccc0:     	mov	x21, x1
10066ccc4:     	mov	x0, x1
10066ccc8:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066cccc:     	and	x8, x19, #0xffffffffffff
10066ccd0:     	ubfx	x9, x21, #56, #4
10066ccd4:     	tst	x21, #0x2000000000000000
10066ccd8:     	csel	x8, x8, x9, eq
10066ccdc:     	cbz	x8, 0x10066cd84
10066cce0:     	ldr	x0, [sp, #0x8]
10066cce4:     	b	0x10066cd8c
10066cce8:     	ldr	x8, [x8, #0x648]
10066ccec:     	blr	x8
10066ccf0:     	mov	x21, x0
10066ccf4:     	mov	x19, x1
10066ccf8:     	ldr	x8, [x20]
10066ccfc:     	ldr	x24, [x8, #0x658]
10066cd00:     	blr	x24
10066cd04:     	mov	x22, x0
10066cd08:     	mov	x23, x1
10066cd0c:     	mov	x0, x1
10066cd10:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066cd14:     	and	x8, x22, #0xffffffffffff
10066cd18:     	ubfx	x9, x23, #56, #4
10066cd1c:     	tst	x23, #0x2000000000000000
10066cd20:     	csel	x8, x8, x9, eq
10066cd24:     	cbnz	x8, 0x10066cd30
10066cd28:     	ldr	x8, [x20]
10066cd2c:     	ldr	x24, [x8, #0x678]
10066cd30:     	blr	x24
10066cd34:     	mov	x22, x0
10066cd38:     	mov	x23, x1
10066cd3c:     	stp	x21, x19, [sp, #0x10]
10066cd40:     	mov	x0, x19
10066cd44:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066cd48:     	add	x20, sp, #0x10
10066cd4c:     	mov	x0, x22
10066cd50:     	mov	x1, x23
10066cd54:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066cd58:     	mov	x0, x19
10066cd5c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066cd60:     	mov	x0, x23
10066cd64:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066cd68:     	ldp	x0, x1, [sp, #0x10]
10066cd6c:     	ldp	x29, x30, [sp, #0x50]
10066cd70:     	ldp	x20, x19, [sp, #0x40]
10066cd74:     	ldp	x22, x21, [sp, #0x30]
10066cd78:     	ldp	x24, x23, [sp, #0x20]
10066cd7c:     	add	sp, sp, #0x60
10066cd80:     	ret
10066cd84:     	ldr	x8, [x20]
10066cd88:     	ldr	x0, [x8, #0x678]
10066cd8c:     	ldp	x29, x30, [sp, #0x50]
10066cd90:     	ldp	x20, x19, [sp, #0x40]
10066cd94:     	ldp	x22, x21, [sp, #0x30]
10066cd98:     	ldp	x24, x23, [sp, #0x20]
10066cd9c:     	add	sp, sp, #0x60
10066cda0:     	br	x0
10066cda4:     	stp	x26, x25, [sp, #-0x50]!
10066cda8:     	stp	x24, x23, [sp, #0x10]
10066cdac:     	stp	x22, x21, [sp, #0x20]
10066cdb0:     	stp	x20, x19, [sp, #0x30]
10066cdb4:     	stp	x29, x30, [sp, #0x40]
10066cdb8:     	add	x29, sp, #0x40
10066cdbc:     	mov	x0, #0x0                ; =0
10066cdc0:     	bl	0x10068c794
10066cdc4:     	ldur	x25, [x0, #-0x8]
10066cdc8:     	ldr	x8, [x25, #0x40]
10066cdcc:     	mov	x9, x8
10066cdd0:     	adrp	x16, 0x1022cb000
10066cdd4:     	ldr	x16, [x16, #0x398]
10066cdd8:     	blr	x16
10066cddc:     	mov	x9, sp
10066cde0:     	add	x10, x8, #0xf
10066cde4:     	and	x12, x10, #0xfffffffffffffff0
10066cde8:     	sub	x22, x9, x12
10066cdec:     	mov	sp, x22
10066cdf0:     	mov	x9, x8
10066cdf4:     	adrp	x16, 0x1022cb000
10066cdf8:     	ldr	x16, [x16, #0x398]
10066cdfc:     	blr	x16
