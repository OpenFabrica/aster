# Otty 1.6.2 动态读取器：SSH 与 Cargo 补充证据

这些结论来自同一已校验 Otty arm64 二进制的有界 LLVM 指令分析，属于独立静态佐证，不是新 REA Evidence，也不是原版运行测试。二进制、范围、工具命令与输出 hash 见 `fig-rules-provenance.json`。Dispatcher 原始范围为 `0x10140ffc8–0x101417a84`；`fig-rules-dispatch-annotated.s` 仅给相邻 adrp/add 加原始字节注释，不用最近的符号名称替代匿名函数身份。

## Cargo

- 向上找首个 metadata 成功的 `Cargo.toml`，最多检查 10 个目录，循环检查时间预算。首个命中停止，即使随后读取失败，也不继续父目录。地址 `0x101414134–26c`、读取 `0x101414738`。
- 清单读取器是逐行解析，不是通用 TOML：按行 trim，跳空行和首字符 `#`；`[[...]]`、`[...]` 仅取内部 trim 后的节名；其他行按第一个 `=` 拆 trim 后的键、值。地址 `0x101414d20–101415968`。
- `[bin]`/`[[bin]]` 的 `name` 累积到 bin；bench 同理；`[package] name` 覆盖一个 package name；`[features]` 收集每个键的原文。节名与键均大小写敏感。features 输出排除精确字符串 `default`，带引号的键没有自动去引号。
- name 值去引号 helper `0x10140feac` 只在长度至少 2 且首尾均为相同的 ASCII 单/双引号时删去最外层一对。无转义处理，无行尾注释剥离。因此 `name = "demo" # note` 的结果仍是含引号和注释的字面值。
- `[workspace] members` 只处理同一行，要求值以 `[` 开头；取首个 `]` 前的部分，按逗号拆，再 trim、用上述 helper 去外层引号，忽略空值。不读取后续行、不展开 glob、不读成员的 Cargo.toml、不改成 basename。地址 `0x101415258–101415958`。成员向量从栈 `a28/a30/a38` 移至 `148/150/158`，package 输出直接 clone 该向量，`0x101414398–3b0`。
- `bin` 若显式清单为空才回退 package name。`bench`、feature、package 不作同样回退。输出描述分别是 `bin`、`feature`、`bench`、`package`。经 `0x1013fe020–1013fe158` 的 matches 与候选构造，kind=2、clear_leader=false，保持清单中的顺序；该收集路径不局部排序/去重，最终引擎的全局去重排序另计。
- example 是独立的 `cwd/examples` 目录枚举，地址 `0x101414460–49c`。不使用向上找到的 manifest 所在目录，不读取 `[[example]]`，不检查文件类型，目录和非 `.rs` 文件也可成为候选。
- example 的限制为前 200 个成功的 ReadDir 条目；计数在 UTF-8 校验、隐藏名和 prefix 过滤之前递减；单条 ReadDir 错误跳过且不消耗计数。地址 `0x1014146b0`、`0x1013ff1bc–1c4`。
- example 跳过非 UTF-8 文件名、以 `.` 开头的名称。对其余名称仅做 `strip_suffix(".rs").unwrap_or(name)`，空结果跳过，再用 GeneratorContext.matches；保留其他后缀。不检查 metadata。地址 `0x1013ff1d4–210`、`0x1013ff2b8–314`、`0x1013ff3e4–420`、`0x1013ff354–38c`。
- example 描述为 `example`、kind=2、clear_leader=false。收集后按候选文本 UTF-8 字节升序稳定排序：`0x101414a1c → 0x101416990`；2–20 项调用 `0x1014591cc`，21 项起调用 `0x101459a38` stable driftsort。两条比较均为 text 的 memcmp，再按长度：`0x10145924c–270`、`0x10145d408–42c`。先截目录条目，后过滤和排序。

可测试条件：父目录清单应命中，但子目录的 examples 只来自子目录；`members=["crates/*", "../other"]` 输出原文；`features` 的 `default` 被去掉而 `"default"` 保留；`examples/hello.rs` 与 `examples/hello/` 都可能产生 `hello`，非 `.rs` 文件名原样保留；200 个成功但前缀不匹配的条目会耗尽扫描名额。

## SSH、SCP、SFTP

- 共享 host generator，只在首个 host 位置工作。遍历已完成 token（从索引 1 开始，不含当前未完成 token）；遇到空 token 或首字节不是 `-` 的 token 就返回空候选。精确二字节选项 `-b -c -D -E -e -F -I -i -J -L -l -m -O -o -p -Q -R -S -W -w` 跳过自己与下一 token，其他以 `-` 开头 token 只跳过自己，不展开 cluster。地址 `0x101411188–101411a54`。
- 不专门排除当前 option-value 槽位，所以 `ssh -p `、`ssh -p 2` 仍可进入 host 候选；`scp local ` 已有首个普通参数，不产生 host 候选。
- 当前 token 在第一个 `@` 分开；保留包含 `@` 的前半部分，后半部分用于主机前缀匹配。不是最后一个 `@`。地址 `0x1014111d8–1208`。
- 候选来源顺序为 config、known host、recent；描述精确为 `ssh config`、`known host`、`recent`，kind=2、clear_leader=false；跨来源按最终文本去重。原版 config 使用用户 home 与 config_dir/ssh_config；recent 从应用 state.db 取。Aster 接入其自有数据源的行为应另行说明，不应读取 Otty 的用户数据库来掩盖差异。

### known_hosts

`known_hosts` 读取 UTF-8 失败返回空。`parse_known_hosts` 地址 `0x101478080`：

1. 行 trim，跳空行、首 `#` 或首 `|`。
2. 取第一个 Unicode whitespace 分隔词；若它以 `@` 开头，取第二个词。缺词跳过；得到的 host 字段首 `|` 仍跳过。
3. host 字段按逗号分段。若一段以 `[` 开头，去首 `[`，取第一个 `]` 前的内容；没有 `]` 时保留剩余内容。空段跳过。
4. 名称包含任意 `!`、`*`、`?` 就跳过。mask `0x8000040200000000` 与 Unicode scalar 检查见 `0x1014783c0–44c`。不验证 key type、key 内容或其他字段。
5. 按最终字符串精确去重，保留首次出现次序。依据 `0x1014781ec–1014784c8`。

可测试条件：`@cert-authority one,two ssh-ed25519 ...` 收集 one/two；`[host]:2222` 只收集 host；`[broken` 收集 broken；`|1|...` 不收集；包含星号、问号或感叹号的名称不收集。单有一个普通 host token 的行也可收集，不要求后面有合法 key。

### config Loader

`all_config_host_names` (`0x10147894c`) 调用 `Loader::new(home)`、`with_otty_config(custom)`、`load()`，遍历加载后的 Host 对象，跳过 `+0x11f` 的 pattern flag，按具体 alias 原文首次出现去重。不把 HostName 当作新候选名。

- Loader 原始 roots 为 `~/.config/otty/ssh_config`、`~/.ssh/config`；with_otty_config 删除 managed 标记 1 的原项并把指定路径插到 roots 首位。因此 config_dir/ssh_config 先于用户 config。依据 `0x10147a604–734`、`0x10147a43c–544`、`0x10147a974–9a4`。
- 每个文件 canonicalize 后用 visited 集合阻止重复，canonicalize 失败则使用原 path；读取失败跳过。Include 深度上限为 3，根 depth=0，入口 depth>=3 即返回，所以最多继续两层 Include。依据 `0x10147ac3c–acd0`；默认常量 `0x101b07d50` 的第二个 u64 为 3。
- Include 对每个路径运行 resolve_include，再 glob 展开，然后递归 depth+1。精确 `~` 使用 home，`~/` 前缀使用 home.join(rest)，绝对路径保留，其他路径相对 home/.ssh；不是相对包含它的文件的目录。依据 `0x101479f48–10147a038`、`0x10147ad98–ada8`、`0x10147b584–630`。
- 行解析按 trim，跳空或首 `#`；键至第一个 Unicode whitespace 或 `=`，键 ASCII 小写。剩余部分 trim_start，可去一个首 `=` 再 trim_start。Host/Include 的值用 `0x10147c784` 分词。
- 值分词仅双引号切换 quoted 并去除；引号外 Unicode whitespace 分词，引号内空白保留。单引号、反斜杠、`#` 均为普通字符；不剥行尾注释，不报未闭双引号；`""` 可形成空词。依据 `0x10147c7e8–10147caa8`。因此 `Host alpha # note` 产生 alpha、#、note 三个 Host 名称，`Host "alpha beta"` 产生一个含空格名称。
- Host 的任意名称 scalar 为 `!`、`*`、`?` 时设置 pattern flag；最终枚举跳过这些项。依据 `0x10147b100–b220`，同 known_hosts mask。Match directive 清空当前 Host 关联，后续 Host 仍可重新加入。

仍未确认：Include glob 展开的排序与所有模式语法、recent 的 SQL 查询条件和上限、Loader 其他属性的全部合并语义、所有时间预算退出与外部存储错误路径。这些不应依靠通用 OpenSSH 理论补齐。此文件未涉及 Make、Compose 或 jump 的新增结论。
