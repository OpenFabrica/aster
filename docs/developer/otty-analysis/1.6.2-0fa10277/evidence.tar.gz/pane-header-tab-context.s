10066773c:     	sub	sp, sp, #0x40
100667740:     	stp	x20, x19, [sp, #0x20]
100667744:     	stp	x29, x30, [sp, #0x30]
100667748:     	add	x29, sp, #0x30
10066774c:     	adrp	x8, 0x1023da000
100667750:     	ldr	x19, [x8, #0x360]
100667754:     	add	x0, x20, x19
100667758:     	add	x1, sp, #0x8
10066775c:     	mov	x2, #0x0                ; =0
100667760:     	mov	x3, #0x0                ; =0
100667764:     	bl	0x101aca600 ; symbol _swift_beginAccess
100667768:     	ldr	x0, [x20, x19]
10066776c:     	bl	0x101aca978 ; symbol _swift_retain
100667770:     	ldp	x29, x30, [sp, #0x30]
100667774:     	ldp	x20, x19, [sp, #0x20]
100667778:     	add	sp, sp, #0x40
10066777c:     	ret
100667780:     	adrp	x1, 0x1023da000
100667784:     	add	x1, x1, #0x360
100667788:     	adrp	x2, 0x1022cf000
10066778c:     	ldr	x2, [x2, #0x738]
100667790:     	b	0x100007ecc
100667794:     	stp	x20, x19, [sp, #-0x20]!
100667798:     	stp	x29, x30, [sp, #0x10]
10066779c:     	add	x29, sp, #0x10
1006677a0:     	mov	x1, x0
1006677a4:     	adrp	x8, 0x1023da000
1006677a8:     	ldr	x19, [x8, #0x360]
1006677ac:     	add	x0, x20, x19
1006677b0:     	mov	w2, #0x21               ; =33
1006677b4:     	mov	x3, #0x0                ; =0
1006677b8:     	bl	0x101aca600 ; symbol _swift_beginAccess
1006677bc:     	adrp	x0, 0x10002d000
1006677c0:     	add	x0, x0, #0xd0c
1006677c4:     	add	x1, x20, x19
1006677c8:     	ldp	x29, x30, [sp, #0x10]
1006677cc:     	ldp	x20, x19, [sp], #0x20
1006677d0:     	ret
1006677d4:     	adrp	x0, 0x1023da000
1006677d8:     	add	x0, x0, #0x368
1006677dc:     	b	0x100252ff4
1006677e0:     	adrp	x2, 0x1023da000
1006677e4:     	add	x2, x2, #0x368
1006677e8:     	b	0x100253050
1006677ec:     	stp	x20, x19, [sp, #-0x20]!
1006677f0:     	stp	x29, x30, [sp, #0x10]
1006677f4:     	add	x29, sp, #0x10
1006677f8:     	mov	x1, x0
1006677fc:     	adrp	x8, 0x1023da000
100667800:     	ldr	x19, [x8, #0x368]
100667804:     	add	x0, x20, x19
100667808:     	mov	w2, #0x21               ; =33
10066780c:     	mov	x3, #0x0                ; =0
100667810:     	bl	0x101aca600 ; symbol _swift_beginAccess
100667814:     	adrp	x0, 0x10002d000
100667818:     	add	x0, x0, #0xd0c
10066781c:     	add	x1, x20, x19
100667820:     	ldp	x29, x30, [sp, #0x10]
100667824:     	ldp	x20, x19, [sp], #0x20
100667828:     	ret
10066782c:     	sub	sp, sp, #0x40
100667830:     	stp	x20, x19, [sp, #0x20]
100667834:     	stp	x29, x30, [sp, #0x30]
100667838:     	add	x29, sp, #0x30
10066783c:     	adrp	x8, 0x1023da000
100667840:     	ldr	x19, [x8, #0x370]
100667844:     	add	x0, x20, x19
100667848:     	add	x1, sp, #0x8
10066784c:     	mov	x2, #0x0                ; =0
100667850:     	mov	x3, #0x0                ; =0
100667854:     	bl	0x101aca600 ; symbol _swift_beginAccess
100667858:     	ldrb	w0, [x20, x19]
10066785c:     	ldp	x29, x30, [sp, #0x30]
100667860:     	ldp	x20, x19, [sp, #0x20]
100667864:     	add	sp, sp, #0x40
100667868:     	ret
10066786c:     	sub	sp, sp, #0x50
100667870:     	stp	x22, x21, [sp, #0x20]
100667874:     	stp	x20, x19, [sp, #0x30]
100667878:     	stp	x29, x30, [sp, #0x40]
10066787c:     	add	x29, sp, #0x40
100667880:     	mov	x19, x0
100667884:     	adrp	x8, 0x1023da000
100667888:     	ldr	x21, [x8, #0x370]
10066788c:     	add	x0, x20, x21
100667890:     	add	x1, sp, #0x8
100667894:     	mov	w2, #0x1                ; =1
100667898:     	mov	x3, #0x0                ; =0
10066789c:     	bl	0x101aca600 ; symbol _swift_beginAccess
1006678a0:     	strb	w19, [x20, x21]
1006678a4:     	ldp	x29, x30, [sp, #0x40]
1006678a8:     	ldp	x20, x19, [sp, #0x30]
1006678ac:     	ldp	x22, x21, [sp, #0x20]
1006678b0:     	add	sp, sp, #0x50
1006678b4:     	ret
1006678b8:     	stp	x20, x19, [sp, #-0x20]!
1006678bc:     	stp	x29, x30, [sp, #0x10]
1006678c0:     	add	x29, sp, #0x10
1006678c4:     	mov	x1, x0
1006678c8:     	adrp	x8, 0x1023da000
1006678cc:     	ldr	x19, [x8, #0x370]
1006678d0:     	add	x0, x20, x19
1006678d4:     	mov	w2, #0x21               ; =33
1006678d8:     	mov	x3, #0x0                ; =0
1006678dc:     	bl	0x101aca600 ; symbol _swift_beginAccess
1006678e0:     	adrp	x0, 0x10002d000
1006678e4:     	add	x0, x0, #0xd0c
1006678e8:     	add	x1, x20, x19
1006678ec:     	ldp	x29, x30, [sp, #0x10]
1006678f0:     	ldp	x20, x19, [sp], #0x20
1006678f4:     	ret
1006678f8:     	stp	x20, x19, [sp, #-0x20]!
1006678fc:     	stp	x29, x30, [sp, #0x10]
100667900:     	add	x29, sp, #0x10
100667904:     	ldr	x20, [x20, #0x18]
100667908:     	ldr	x8, [x20]
10066790c:     	ldr	x8, [x8, #0x128]
100667910:     	blr	x8
100667914:     	cbz	x0, 0x10066793c
100667918:     	mov	x20, x0
10066791c:     	ldr	x8, [x0]
100667920:     	ldr	x8, [x8, #0x540]
100667924:     	blr	x8
100667928:     	mov	x19, x0
10066792c:     	mov	x0, x20
100667930:     	bl	0x101aca960 ; symbol _swift_release
100667934:     	mov	x0, x19
100667938:     	b	0x100667940
10066793c:     	mov	w0, #0xc                ; =12
100667940:     	ldp	x29, x30, [sp, #0x10]
100667944:     	ldp	x20, x19, [sp], #0x20
100667948:     	ret
10066794c:     	stp	x20, x19, [sp, #-0x20]!
100667950:     	stp	x29, x30, [sp, #0x10]
100667954:     	add	x29, sp, #0x10
100667958:     	mov	x19, x0
10066795c:     	ldr	x20, [x20, #0x18]
100667960:     	ldr	x8, [x20]
100667964:     	ldr	x8, [x8, #0x128]
100667968:     	blr	x8
10066796c:     	cbz	x0, 0x100667994
100667970:     	mov	x20, x0
100667974:     	ldr	x8, [x0]
100667978:     	ldr	x8, [x8, #0x548]
10066797c:     	mov	x0, x19
100667980:     	blr	x8
100667984:     	mov	x0, x20
100667988:     	ldp	x29, x30, [sp, #0x10]
10066798c:     	ldp	x20, x19, [sp], #0x20
100667990:     	b	0x101aca960 ; symbol _swift_release
100667994:     	ldp	x29, x30, [sp, #0x10]
100667998:     	ldp	x20, x19, [sp], #0x20
10066799c:     	ret
1006679a0:     	stp	x22, x21, [sp, #-0x30]!
1006679a4:     	stp	x20, x19, [sp, #0x10]
1006679a8:     	stp	x29, x30, [sp, #0x20]
1006679ac:     	add	x29, sp, #0x20
1006679b0:     	mov	x19, x0
1006679b4:     	ldr	x20, [x20, #0x18]
1006679b8:     	str	x20, [x0]
1006679bc:     	ldr	x8, [x20]
1006679c0:     	ldr	x8, [x8, #0x128]
1006679c4:     	str	x8, [x0, #0x8]
1006679c8:     	blr	x8
1006679cc:     	cbz	x0, 0x1006679f0
1006679d0:     	mov	x20, x0
1006679d4:     	ldr	x8, [x0]
1006679d8:     	ldr	x8, [x8, #0x540]
1006679dc:     	blr	x8
1006679e0:     	mov	x21, x0
1006679e4:     	mov	x0, x20
1006679e8:     	bl	0x101aca960 ; symbol _swift_release
1006679ec:     	b	0x1006679f4
1006679f0:     	mov	w21, #0xc               ; =12
1006679f4:     	sturb	w21, [x19, #0x10]
1006679f8:     	adrp	x0, 0x100667000
1006679fc:     	add	x0, x0, #0xa14
100667a00:     	add	x1, x19, #0x10
100667a04:     	ldp	x29, x30, [sp, #0x20]
100667a08:     	ldp	x20, x19, [sp, #0x10]
100667a0c:     	ldp	x22, x21, [sp], #0x30
100667a10:     	ret
100667a14:     	stp	x20, x19, [sp, #-0x20]!
100667a18:     	stp	x29, x30, [sp, #0x10]
100667a1c:     	add	x29, sp, #0x10
100667a20:     	ldp	x20, x8, [x0]
100667a24:     	ldrb	w19, [x0, #0x10]!
100667a28:     	blr	x8
100667a2c:     	cbz	x0, 0x100667a54
100667a30:     	mov	x20, x0
100667a34:     	ldr	x8, [x0]
100667a38:     	ldr	x8, [x8, #0x548]
100667a3c:     	mov	x0, x19
100667a40:     	blr	x8
100667a44:     	mov	x0, x20
100667a48:     	ldp	x29, x30, [sp, #0x10]
100667a4c:     	ldp	x20, x19, [sp], #0x20
100667a50:     	b	0x101aca960 ; symbol _swift_release
100667a54:     	ldp	x29, x30, [sp, #0x10]
100667a58:     	ldp	x20, x19, [sp], #0x20
100667a5c:     	ret
100667a60:     	sub	sp, sp, #0xd0
100667a64:     	stp	x22, x21, [sp, #0xa0]
100667a68:     	stp	x20, x19, [sp, #0xb0]
100667a6c:     	stp	x29, x30, [sp, #0xc0]
100667a70:     	add	x29, sp, #0xc0
100667a74:     	mov	x19, x8
100667a78:     	add	x21, sp, #0x60
100667a7c:     	adrp	x8, 0x1023da000
100667a80:     	ldr	x8, [x8, #0x378]
100667a84:     	add	x20, x20, x8
100667a88:     	add	x1, sp, #0x48
100667a8c:     	mov	x0, x20
100667a90:     	mov	x2, #0x0                ; =0
100667a94:     	mov	x3, #0x0                ; =0
100667a98:     	bl	0x101aca600 ; symbol _swift_beginAccess
100667a9c:     	ldp	q0, q1, [x20]
100667aa0:     	stp	q0, q1, [sp, #0x60]
100667aa4:     	ldp	q0, q1, [x20, #0x20]
100667aa8:     	str	q0, [sp, #0x80]
100667aac:     	str	q1, [x21, #0x30]
100667ab0:     	add	x0, sp, #0x60
100667ab4:     	add	x1, sp, #0x8
100667ab8:     	bl	0x10068bf58
100667abc:     	ldp	q0, q1, [sp, #0x60]
100667ac0:     	stp	q0, q1, [x19]
100667ac4:     	ldr	q0, [sp, #0x80]
100667ac8:     	ldr	q1, [x21, #0x30]
100667acc:     	stp	q0, q1, [x19, #0x20]
100667ad0:     	ldp	x29, x30, [sp, #0xc0]
100667ad4:     	ldp	x20, x19, [sp, #0xb0]
100667ad8:     	ldp	x22, x21, [sp, #0xa0]
100667adc:     	add	sp, sp, #0xd0
100667ae0:     	ret
100667ae4:     	sub	sp, sp, #0x60
100667ae8:     	stp	x24, x23, [sp, #0x20]
100667aec:     	stp	x22, x21, [sp, #0x30]
100667af0:     	stp	x20, x19, [sp, #0x40]
100667af4:     	stp	x29, x30, [sp, #0x50]
100667af8:     	add	x29, sp, #0x50
100667afc:     	mov	x19, x0
100667b00:     	adrp	x8, 0x1023da000
100667b04:     	ldr	x8, [x8, #0x378]
100667b08:     	add	x20, x20, x8
100667b0c:     	add	x1, sp, #0x8
100667b10:     	mov	x0, x20
100667b14:     	mov	w2, #0x1                ; =1
100667b18:     	mov	x3, #0x0                ; =0
100667b1c:     	bl	0x101aca600 ; symbol _swift_beginAccess
100667b20:     	ldr	x21, [x20, #0x8]
100667b24:     	ldr	x22, [x20, #0x18]
100667b28:     	ldr	x23, [x20, #0x28]
100667b2c:     	ldr	x0, [x20, #0x38]
100667b30:     	ldp	q0, q1, [x19]
100667b34:     	stp	q0, q1, [x20]
100667b38:     	ldp	q0, q1, [x19, #0x20]
100667b3c:     	stp	q0, q1, [x20, #0x20]
100667b40:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100667b44:     	mov	x0, x23
100667b48:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100667b4c:     	mov	x0, x22
100667b50:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100667b54:     	mov	x0, x21
100667b58:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100667b5c:     	ldp	x29, x30, [sp, #0x50]
100667b60:     	ldp	x20, x19, [sp, #0x40]
100667b64:     	ldp	x22, x21, [sp, #0x30]
100667b68:     	ldp	x24, x23, [sp, #0x20]
100667b6c:     	add	sp, sp, #0x60
100667b70:     	ret
100667b74:     	stp	x20, x19, [sp, #-0x20]!
100667b78:     	stp	x29, x30, [sp, #0x10]
100667b7c:     	add	x29, sp, #0x10
100667b80:     	mov	x1, x0
100667b84:     	adrp	x8, 0x1023da000
100667b88:     	ldr	x19, [x8, #0x378]
100667b8c:     	add	x0, x20, x19
100667b90:     	mov	w2, #0x21               ; =33
100667b94:     	mov	x3, #0x0                ; =0
100667b98:     	bl	0x101aca600 ; symbol _swift_beginAccess
100667b9c:     	adrp	x0, 0x10002d000
100667ba0:     	add	x0, x0, #0xd0c
100667ba4:     	add	x1, x20, x19
100667ba8:     	ldp	x29, x30, [sp, #0x10]
100667bac:     	ldp	x20, x19, [sp], #0x20
100667bb0:     	ret
100667bb4:     	sub	sp, sp, #0x180
100667bb8:     	stp	x28, x27, [sp, #0x150]
100667bbc:     	stp	x20, x19, [sp, #0x160]
100667bc0:     	stp	x29, x30, [sp, #0x170]
100667bc4:     	add	x29, sp, #0x170
100667bc8:     	mov	x19, x8
100667bcc:     	adrp	x8, 0x1023da000
100667bd0:     	ldr	x8, [x8, #0x380]
100667bd4:     	add	x20, x20, x8
100667bd8:     	add	x1, sp, #0x98
100667bdc:     	mov	x0, x20
100667be0:     	mov	x2, #0x0                ; =0
100667be4:     	mov	x3, #0x0                ; =0
100667be8:     	bl	0x101aca600 ; symbol _swift_beginAccess
100667bec:     	ldp	q0, q1, [x20, #0x60]
100667bf0:     	stp	q0, q1, [sp, #0x110]
100667bf4:     	ldr	q0, [x20, #0x80]
100667bf8:     	str	q0, [sp, #0x130]
100667bfc:     	ldr	x8, [x20, #0x90]
100667c00:     	str	x8, [sp, #0x140]
100667c04:     	ldp	q0, q1, [x20, #0x20]
100667c08:     	stp	q0, q1, [sp, #0xd0]
100667c0c:     	ldp	q0, q1, [x20, #0x40]
100667c10:     	stp	q0, q1, [sp, #0xf0]
100667c14:     	ldp	q0, q1, [x20]
100667c18:     	stp	q0, q1, [sp, #0xb0]
100667c1c:     	adrp	x2, 0x10235e000
100667c20:     	add	x2, x2, #0xdd8
100667c24:     	adrp	x3, 0x101afc000
100667c28:     	add	x3, x3, #0x918 ; possible literal '<q3'
100667c2c:     	add	x0, sp, #0xb0
100667c30:     	mov	x1, sp
100667c34:     	bl	0x10002d8f4
100667c38:     	ldp	q0, q1, [sp, #0x110]
100667c3c:     	stp	q0, q1, [x19, #0x60]
100667c40:     	ldr	q0, [sp, #0x130]
100667c44:     	str	q0, [x19, #0x80]
100667c48:     	ldr	x8, [sp, #0x140]
100667c4c:     	str	x8, [x19, #0x90]
100667c50:     	ldp	q0, q1, [sp, #0xd0]
100667c54:     	stp	q0, q1, [x19, #0x20]
100667c58:     	ldp	q0, q1, [sp, #0xf0]
100667c5c:     	stp	q0, q1, [x19, #0x40]
100667c60:     	ldp	q0, q1, [sp, #0xb0]
100667c64:     	stp	q0, q1, [x19]
100667c68:     	ldp	x29, x30, [sp, #0x170]
100667c6c:     	ldp	x20, x19, [sp, #0x160]
100667c70:     	ldp	x28, x27, [sp, #0x150]
100667c74:     	add	sp, sp, #0x180
100667c78:     	ret
100667c7c:     	sub	sp, sp, #0xf0
100667c80:     	stp	x22, x21, [sp, #0xc0]
100667c84:     	stp	x20, x19, [sp, #0xd0]
100667c88:     	stp	x29, x30, [sp, #0xe0]
100667c8c:     	add	x29, sp, #0xe0
100667c90:     	mov	x19, x0
100667c94:     	add	x21, sp, #0x20
100667c98:     	adrp	x8, 0x1023da000
100667c9c:     	ldr	x8, [x8, #0x380]
100667ca0:     	add	x20, x20, x8
100667ca4:     	add	x1, sp, #0x8
100667ca8:     	mov	x0, x20
100667cac:     	mov	w2, #0x1                ; =1
100667cb0:     	mov	x3, #0x0                ; =0
100667cb4:     	bl	0x101aca600 ; symbol _swift_beginAccess
100667cb8:     	ldp	q2, q1, [x20, #0x60]
100667cbc:     	ldr	q0, [x20, #0x80]
100667cc0:     	stp	q1, q0, [x21, #0x70]
100667cc4:     	ldr	x8, [x20, #0x90]
100667cc8:     	str	x8, [sp, #0xb0]
100667ccc:     	ldp	q0, q1, [x20, #0x20]
100667cd0:     	stp	q0, q1, [sp, #0x40]
100667cd4:     	ldp	q0, q1, [x20, #0x40]
100667cd8:     	str	q0, [sp, #0x60]
100667cdc:     	stp	q1, q2, [sp, #0x70]
100667ce0:     	ldp	q0, q1, [x20]
100667ce4:     	stp	q0, q1, [sp, #0x20]
100667ce8:     	ldp	q0, q1, [x19, #0x60]
100667cec:     	stp	q0, q1, [x20, #0x60]
100667cf0:     	ldr	q0, [x19, #0x80]
100667cf4:     	str	q0, [x20, #0x80]
100667cf8:     	ldr	x8, [x19, #0x90]
100667cfc:     	str	x8, [x20, #0x90]
100667d00:     	ldp	q0, q1, [x19, #0x20]
100667d04:     	stp	q0, q1, [x20, #0x20]
100667d08:     	ldp	q0, q1, [x19, #0x40]
100667d0c:     	stp	q0, q1, [x20, #0x40]
100667d10:     	ldp	q0, q1, [x19]
100667d14:     	stp	q0, q1, [x20]
100667d18:     	adrp	x1, 0x10235e000
100667d1c:     	add	x1, x1, #0xdd8
100667d20:     	adrp	x2, 0x101afc000
100667d24:     	add	x2, x2, #0x918 ; possible literal '<q3'
100667d28:     	add	x0, sp, #0x20
100667d2c:     	bl	0x10002d870
100667d30:     	ldp	x29, x30, [sp, #0xe0]
100667d34:     	ldp	x20, x19, [sp, #0xd0]
100667d38:     	ldp	x22, x21, [sp, #0xc0]
100667d3c:     	add	sp, sp, #0xf0
100667d40:     	ret
100667d44:     	stp	x20, x19, [sp, #-0x20]!
100667d48:     	stp	x29, x30, [sp, #0x10]
100667d4c:     	add	x29, sp, #0x10
100667d50:     	mov	x1, x0
100667d54:     	adrp	x8, 0x1023da000
100667d58:     	ldr	x19, [x8, #0x380]
100667d5c:     	add	x0, x20, x19
100667d60:     	mov	w2, #0x21               ; =33
100667d64:     	mov	x3, #0x0                ; =0
100667d68:     	bl	0x101aca600 ; symbol _swift_beginAccess
100667d6c:     	adrp	x0, 0x10002d000
100667d70:     	add	x0, x0, #0xd0c
100667d74:     	add	x1, x20, x19
100667d78:     	ldp	x29, x30, [sp, #0x10]
100667d7c:     	ldp	x20, x19, [sp], #0x20
100667d80:     	ret
100667d84:     	sub	sp, sp, #0x40
100667d88:     	stp	x20, x19, [sp, #0x20]
100667d8c:     	stp	x29, x30, [sp, #0x30]
100667d90:     	add	x29, sp, #0x30
100667d94:     	adrp	x8, 0x1023da000
100667d98:     	ldr	x19, [x8, #0x388]
100667d9c:     	add	x0, x20, x19
100667da0:     	add	x1, sp, #0x8
100667da4:     	mov	x2, #0x0                ; =0
100667da8:     	mov	x3, #0x0                ; =0
100667dac:     	bl	0x101aca600 ; symbol _swift_beginAccess
100667db0:     	ldr	x0, [x20, x19]
100667db4:     	ldp	x29, x30, [sp, #0x30]
100667db8:     	ldp	x20, x19, [sp, #0x20]
100667dbc:     	add	sp, sp, #0x40
100667dc0:     	ret
100667dc4:     	sub	sp, sp, #0x50
100667dc8:     	stp	x22, x21, [sp, #0x20]
100667dcc:     	stp	x20, x19, [sp, #0x30]
100667dd0:     	stp	x29, x30, [sp, #0x40]
100667dd4:     	add	x29, sp, #0x40
100667dd8:     	mov	x19, x0
100667ddc:     	adrp	x8, 0x1023da000
100667de0:     	ldr	x21, [x8, #0x388]
100667de4:     	add	x0, x20, x21
100667de8:     	add	x1, sp, #0x8
100667dec:     	mov	w2, #0x1                ; =1
100667df0:     	mov	x3, #0x0                ; =0
100667df4:     	bl	0x101aca600 ; symbol _swift_beginAccess
100667df8:     	str	x19, [x20, x21]
100667dfc:     	ldp	x29, x30, [sp, #0x40]
100667e00:     	ldp	x20, x19, [sp, #0x30]
100667e04:     	ldp	x22, x21, [sp, #0x20]
100667e08:     	add	sp, sp, #0x50
100667e0c:     	ret
100667e10:     	stp	x20, x19, [sp, #-0x20]!
100667e14:     	stp	x29, x30, [sp, #0x10]
100667e18:     	add	x29, sp, #0x10
100667e1c:     	mov	x1, x0
100667e20:     	adrp	x8, 0x1023da000
100667e24:     	ldr	x19, [x8, #0x388]
100667e28:     	add	x0, x20, x19
100667e2c:     	mov	w2, #0x21               ; =33
100667e30:     	mov	x3, #0x0                ; =0
100667e34:     	bl	0x101aca600 ; symbol _swift_beginAccess
100667e38:     	adrp	x0, 0x10002d000
100667e3c:     	add	x0, x0, #0xd0c
100667e40:     	add	x1, x20, x19
100667e44:     	ldp	x29, x30, [sp, #0x10]
100667e48:     	ldp	x20, x19, [sp], #0x20
100667e4c:     	ret
100667e50:     	sub	sp, sp, #0x120
100667e54:     	stp	d9, d8, [sp, #0xd0]
100667e58:     	stp	x24, x23, [sp, #0xe0]
100667e5c:     	stp	x22, x21, [sp, #0xf0]
100667e60:     	stp	x20, x19, [sp, #0x100]
100667e64:     	stp	x29, x30, [sp, #0x110]
100667e68:     	add	x29, sp, #0x110
100667e6c:     	mov	x19, x20
100667e70:     	mov.16b	v8, v0
100667e74:     	ldr	x20, [x20, #0x18]
100667e78:     	ldr	x8, [x20]
100667e7c:     	ldr	x8, [x8, #0x128]
100667e80:     	blr	x8
100667e84:     	cbnz	x0, 0x100667e98
100667e88:     	ldr	x8, [x20]
100667e8c:     	ldr	x8, [x8, #0x148]
100667e90:     	blr	x8
100667e94:     	cbz	x0, 0x100667ee4
100667e98:     	ldr	x8, [x0]
100667e9c:     	ldr	x8, [x8, #0x398]
100667ea0:     	mov.16b	v0, v8
100667ea4:     	mov	x20, x0
100667ea8:     	mov	x22, x0
100667eac:     	blr	x8
100667eb0:     	mov	x20, x0
100667eb4:     	mov	x21, x1
100667eb8:     	mov	x0, x22
100667ebc:     	bl	0x101aca960 ; symbol _swift_release
100667ec0:     	cbz	x20, 0x100667ee4
100667ec4:     	mov	x0, x20
100667ec8:     	mov	x1, x21
100667ecc:     	bl	0x10068c9f0
100667ed0:     	mov	x0, x20
100667ed4:     	bl	0x101ac9d30 ; symbol _objc_release
100667ed8:     	mov	x0, x21
100667edc:     	bl	0x101ac9d30 ; symbol _objc_release
100667ee0:     	b	0x100667ff8
100667ee4:     	ldr	x8, [x19]
100667ee8:     	ldr	x23, [x8, #0x3d0]
100667eec:     	mov	x8, sp
100667ef0:     	mov	x20, x19
100667ef4:     	blr	x23
100667ef8:     	ldr	q0, [sp, #0x10]
100667efc:     	stur	q0, [x29, #-0x50]
100667f00:     	ldp	x21, x20, [x29, #-0x50]
100667f04:     	mov	x0, x20
100667f08:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100667f0c:     	mov	x0, sp
100667f10:     	bl	0x1001340e4
100667f14:     	sub	x0, x29, #0x50
100667f18:     	bl	0x10002d1f0
100667f1c:     	and	x8, x21, #0xffffffffffff
100667f20:     	ubfx	x9, x20, #56, #4
100667f24:     	tst	x20, #0x2000000000000000
100667f28:     	csel	x8, x8, x9, eq
100667f2c:     	cbz	x8, 0x100667fe8
100667f30:     	add	x8, sp, #0x40
100667f34:     	mov	x20, x19
100667f38:     	blr	x23
100667f3c:     	ldp	x20, x22, [sp, #0x50]
100667f40:     	mov	x0, x22
100667f44:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100667f48:     	add	x0, sp, #0x40
100667f4c:     	bl	0x1001340e4
100667f50:     	bl	0x1000028c0
100667f54:     	mov	x2, x0
100667f58:     	mov	x0, x20
100667f5c:     	mov	x1, x22
100667f60:     	mov.16b	v0, v8
100667f64:     	bl	0x100453d1c
100667f68:     	mov	x21, x0
100667f6c:     	mov	x0, x22
100667f70:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100667f74:     	cbz	x21, 0x100667ff4
100667f78:     	adrp	x1, 0x102343000
100667f7c:     	add	x1, x1, #0xb20
100667f80:     	adrp	x2, 0x102326000
100667f84:     	add	x2, x2, #0x9c8
100667f88:     	mov	x0, #0x0                ; =0
100667f8c:     	bl	0x10002d97c
100667f90:     	mov	x22, x0
100667f94:     	add	x8, sp, #0x80
100667f98:     	mov	x20, x19
100667f9c:     	blr	x23
100667fa0:     	ldp	x19, x23, [sp, #0xa0]
100667fa4:     	mov	x0, x23
100667fa8:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100667fac:     	add	x0, sp, #0x80
100667fb0:     	bl	0x1001340e4
100667fb4:     	mov	x0, x19
100667fb8:     	mov	x1, x23
100667fbc:     	mov	x20, x22
100667fc0:     	bl	0x1000040dc
100667fc4:     	mov	x19, x0
100667fc8:     	mov	x0, x23
100667fcc:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100667fd0:     	mov	x0, x21
100667fd4:     	mov	x1, x19
100667fd8:     	bl	0x100003f40
100667fdc:     	mov	x20, x0
100667fe0:     	mov	x21, x1
100667fe4:     	b	0x100667ff8
100667fe8:     	mov	x20, #0x0               ; =0
100667fec:     	mov	x21, #0x0               ; =0
100667ff0:     	b	0x100667ff8
100667ff4:     	mov	x20, #0x0               ; =0
100667ff8:     	mov	x0, x20
100667ffc:     	mov	x1, x21
100668000:     	ldp	x29, x30, [sp, #0x110]
100668004:     	ldp	x20, x19, [sp, #0x100]
100668008:     	ldp	x22, x21, [sp, #0xf0]
10066800c:     	ldp	x24, x23, [sp, #0xe0]
100668010:     	ldp	d9, d8, [sp, #0xd0]
100668014:     	add	sp, sp, #0x120
100668018:     	ret
10066801c:     	stp	x22, x21, [sp, #-0x30]!
100668020:     	stp	x20, x19, [sp, #0x10]
100668024:     	stp	x29, x30, [sp, #0x20]
100668028:     	add	x29, sp, #0x20
10066802c:     	ldr	x20, [x20, #0x18]
100668030:     	ldr	x8, [x20]
100668034:     	ldr	x8, [x8, #0x128]
100668038:     	blr	x8
10066803c:     	cbz	x0, 0x100668068
100668040:     	ldr	x8, [x0]
100668044:     	ldr	x8, [x8, #0x558]
100668048:     	mov	x20, x0
10066804c:     	mov	x21, x0
100668050:     	blr	x8
100668054:     	mov	x19, x0
100668058:     	mov	x20, x1
10066805c:     	mov	x0, x21
100668060:     	bl	0x101aca960 ; symbol _swift_release
100668064:     	b	0x100668070
100668068:     	mov	x19, #0x0               ; =0
10066806c:     	mov	x20, #0x0               ; =0
100668070:     	mov	x0, x19
100668074:     	mov	x1, x20
100668078:     	ldp	x29, x30, [sp, #0x20]
10066807c:     	ldp	x20, x19, [sp, #0x10]
100668080:     	ldp	x22, x21, [sp], #0x30
100668084:     	ret
100668088:     	stp	x22, x21, [sp, #-0x30]!
10066808c:     	stp	x20, x19, [sp, #0x10]
100668090:     	stp	x29, x30, [sp, #0x20]
100668094:     	add	x29, sp, #0x20
100668098:     	mov	x19, x1
10066809c:     	mov	x21, x0
1006680a0:     	ldr	x20, [x20, #0x18]
1006680a4:     	ldr	x8, [x20]
1006680a8:     	ldr	x8, [x8, #0x128]
1006680ac:     	blr	x8
1006680b0:     	cbz	x0, 0x1006680e0
1006680b4:     	mov	x20, x0
1006680b8:     	ldr	x8, [x0]
1006680bc:     	ldr	x8, [x8, #0x560]
1006680c0:     	mov	x0, x21
1006680c4:     	mov	x1, x19
1006680c8:     	blr	x8
1006680cc:     	mov	x0, x20
1006680d0:     	ldp	x29, x30, [sp, #0x20]
1006680d4:     	ldp	x20, x19, [sp, #0x10]
1006680d8:     	ldp	x22, x21, [sp], #0x30
1006680dc:     	b	0x101aca960 ; symbol _swift_release
1006680e0:     	mov	x0, x19
1006680e4:     	ldp	x29, x30, [sp, #0x20]
1006680e8:     	ldp	x20, x19, [sp, #0x10]
1006680ec:     	ldp	x22, x21, [sp], #0x30
1006680f0:     	b	0x101aca60c ; symbol _swift_bridgeObjectRelease
1006680f4:     	stp	x22, x21, [sp, #-0x30]!
1006680f8:     	stp	x20, x19, [sp, #0x10]
1006680fc:     	stp	x29, x30, [sp, #0x20]
