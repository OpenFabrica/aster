
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010147cba8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E>:
10147cba8: d10583ff    	sub	sp, sp, #0x160
10147cbac: 6d0e2beb    	stp	d11, d10, [sp, #0xe0]
10147cbb0: 6d0f23e9    	stp	d9, d8, [sp, #0xf0]
10147cbb4: a9106ffc    	stp	x28, x27, [sp, #0x100]
10147cbb8: a91167fa    	stp	x26, x25, [sp, #0x110]
10147cbbc: a9125ff8    	stp	x24, x23, [sp, #0x120]
10147cbc0: a91357f6    	stp	x22, x21, [sp, #0x130]
10147cbc4: a9144ff4    	stp	x20, x19, [sp, #0x140]
10147cbc8: a9157bfd    	stp	x29, x30, [sp, #0x150]
10147cbcc: 910543fd    	add	x29, sp, #0x150
10147cbd0: a9017fe8    	stp	x8, xzr, [sp, #0x10]
10147cbd4: 9e6703e0    	fmov	d0, xzr
10147cbd8: 52800109    	mov	w9, #0x8                ; =8
10147cbdc: a90227ff    	stp	xzr, x9, [sp, #0x20]
10147cbe0: 52800108    	mov	w8, #0x8                ; =8
10147cbe4: f90007e8    	str	x8, [sp, #0x8]
10147cbe8: f9001bff    	str	xzr, [sp, #0x30]
10147cbec: 6e180400    	mov.d	v0[1], v0[0]
10147cbf0: 3c8383e0    	stur	q0, [sp, #0x38]
10147cbf4: 9100e3fa    	add	x26, sp, #0x38
10147cbf8: a90483e1    	stp	x1, x0, [sp, #0x48]
10147cbfc: a905ffe1    	stp	x1, xzr, [sp, #0x58]
10147cc00: f90037e1    	str	x1, [sp, #0x68]
10147cc04: 0f000540    	movi.2s	v0, #0xa
10147cc08: fd003be0    	str	d0, [sp, #0x70]
10147cc0c: 5280003b    	mov	w27, #0x1               ; =1
10147cc10: 3901e3fb    	strb	w27, [sp, #0x78]
10147cc14: 790103ff    	strh	wzr, [sp, #0x80]
10147cc18: d0004918    	adrp	x24, 0x101d9e000 <__ZN10serde_core2de5impls79_$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$std..time..SystemTime$GT$11deserialize14check_overflow13NANOS_PER_SEC17hdc7a2dcd898dff25E+0xffe0>
10147cc1c: 91239f18    	add	x24, x24, #0x8e7
10147cc20: 5280041c    	mov	w28, #0x20              ; =32
10147cc24: 0f05e7e8    	movi.8b	v8, #0xbf
10147cc28: 0f00e749    	movi.8b	v9, #0x1a
10147cc2c: 0f01e40a    	movi.8b	v10, #0x20
10147cc30: d287c013    	mov	x19, #0x3e00            ; =15872
10147cc34: f2c00033    	movk	x19, #0x1, lsl #32
10147cc38: 14000005    	b	0x10147cc4c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xa4>
10147cc3c: d287c013    	mov	x19, #0x3e00            ; =15872
10147cc40: f2c00033    	movk	x19, #0x1, lsl #32
10147cc44: 394207e8    	ldrb	w8, [sp, #0x81]
10147cc48: 37003168    	tbnz	w8, #0x0, 0x10147d274 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x6cc>
10147cc4c: f9402bf4    	ldr	x20, [sp, #0x50]
10147cc50: 910283e0    	add	x0, sp, #0xa0
10147cc54: 91006341    	add	x1, x26, #0x18
10147cc58: 9400432d    	bl	0x10148d90c <__ZN4core5slice4sort6stable9quicksort9quicksort17h1ad04638c7ce3510E+0x1974>
10147cc5c: b940a3e8    	ldr	w8, [sp, #0xa0]
10147cc60: 7100051f    	cmp	w8, #0x1
10147cc64: 54000101    	b.ne	0x10147cc84 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xdc>
10147cc68: f9405be8    	ldr	x8, [sp, #0xb0]
10147cc6c: f94023e9    	ldr	x9, [sp, #0x40]
10147cc70: cb090101    	sub	x1, x8, x9
10147cc74: 8b090280    	add	x0, x20, x9
10147cc78: f90023e8    	str	x8, [sp, #0x40]
10147cc7c: b50001c1    	cbnz	x1, 0x10147ccb4 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x10c>
10147cc80: 1400001c    	b	0x10147ccf0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x148>
10147cc84: 394207e8    	ldrb	w8, [sp, #0x81]
10147cc88: 37002f68    	tbnz	w8, #0x0, 0x10147d274 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x6cc>
10147cc8c: 390207fb    	strb	w27, [sp, #0x81]
10147cc90: 394203ea    	ldrb	w10, [sp, #0x80]
10147cc94: a94427e8    	ldp	x8, x9, [sp, #0x40]
10147cc98: 3700006a    	tbnz	w10, #0x0, 0x10147cca4 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xfc>
10147cc9c: eb08013f    	cmp	x9, x8
10147cca0: 54002ea0    	b.eq	0x10147d274 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x6cc>
10147cca4: f9402bea    	ldr	x10, [sp, #0x50]
10147cca8: cb080121    	sub	x1, x9, x8
10147ccac: 8b080140    	add	x0, x10, x8
10147ccb0: b4000201    	cbz	x1, 0x10147ccf0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x148>
10147ccb4: d1000428    	sub	x8, x1, #0x1
10147ccb8: 38686809    	ldrb	w9, [x0, x8]
10147ccbc: 7100293f    	cmp	w9, #0xa
10147ccc0: 54000181    	b.ne	0x10147ccf0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x148>
10147ccc4: d1000829    	sub	x9, x1, #0x2
10147ccc8: b40000c8    	cbz	x8, 0x10147cce0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x138>
10147cccc: 3869680a    	ldrb	w10, [x0, x9]
10147ccd0: 12001d4a    	and	w10, w10, #0xff
10147ccd4: 7100355f    	cmp	w10, #0xd
10147ccd8: 9a9f000a    	csel	x10, x0, xzr, eq
10147ccdc: 14000002    	b	0x10147cce4 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x13c>
10147cce0: d280000a    	mov	x10, #0x0               ; =0
10147cce4: f100015f    	cmp	x10, #0x0
10147cce8: 9a890101    	csel	x1, x8, x9, eq
10147ccec: 9a8a0000    	csel	x0, x0, x10, eq
10147ccf0: b4002c20    	cbz	x0, 0x10147d274 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x6cc>
10147ccf4: f9401ff5    	ldr	x21, [sp, #0x38]
10147ccf8: 910006a8    	add	x8, x21, #0x1
10147ccfc: f9001fe8    	str	x8, [sp, #0x38]
10147cd00: 97d33f19    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
10147cd04: b4fffa01    	cbz	x1, 0x10147cc44 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x9c>
10147cd08: 3940000a    	ldrb	w10, [x0]
10147cd0c: 71008d5f    	cmp	w10, #0x23
10147cd10: 54fff9a0    	b.eq	0x10147cc44 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x9c>
10147cd14: d2800014    	mov	x20, #0x0               ; =0
10147cd18: 110006b9    	add	w25, w21, #0x1
10147cd1c: 8b010008    	add	x8, x0, x1
10147cd20: aa0003e9    	mov	x9, x0
10147cd24: 373800aa    	tbnz	w10, #0x7, 0x10147cd38 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x190>
10147cd28: 9100052b    	add	x11, x9, #0x1
10147cd2c: 7100815f    	cmp	w10, #0x20
10147cd30: 540003c9    	b.ls	0x10147cda8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x200>
10147cd34: 14000021    	b	0x10147cdb8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x210>
10147cd38: 3940052b    	ldrb	w11, [x9, #0x1]
10147cd3c: 1200156d    	and	w13, w11, #0x3f
10147cd40: 7103815f    	cmp	w10, #0xe0
10147cd44: 540001e3    	b.lo	0x10147cd80 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x1d8>
10147cd48: 1200114c    	and	w12, w10, #0x1f
10147cd4c: 3940092b    	ldrb	w11, [x9, #0x2]
10147cd50: 1200156b    	and	w11, w11, #0x3f
10147cd54: 2a0d196d    	orr	w13, w11, w13, lsl #6
10147cd58: 7103c15f    	cmp	w10, #0xf0
10147cd5c: 540001e3    	b.lo	0x10147cd98 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x1f0>
10147cd60: 9100112b    	add	x11, x9, #0x4
10147cd64: 39400d2a    	ldrb	w10, [x9, #0x3]
10147cd68: 1200154a    	and	w10, w10, #0x3f
10147cd6c: 2a0d194a    	orr	w10, w10, w13, lsl #6
10147cd70: 330e098a    	bfi	w10, w12, #18, #3
10147cd74: 7100815f    	cmp	w10, #0x20
10147cd78: 54000189    	b.ls	0x10147cda8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x200>
10147cd7c: 1400000f    	b	0x10147cdb8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x210>
10147cd80: 9100092b    	add	x11, x9, #0x2
10147cd84: 331a114d    	bfi	w13, w10, #6, #5
10147cd88: aa0d03ea    	mov	x10, x13
10147cd8c: 7100815f    	cmp	w10, #0x20
10147cd90: 540000c9    	b.ls	0x10147cda8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x200>
10147cd94: 14000009    	b	0x10147cdb8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x210>
10147cd98: 91000d2b    	add	x11, x9, #0x3
10147cd9c: 2a0c31aa    	orr	w10, w13, w12, lsl #12
10147cda0: 7100815f    	cmp	w10, #0x20
10147cda4: 540000a8    	b.hi	0x10147cdb8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x210>
10147cda8: 2a0a03ec    	mov	w12, w10
10147cdac: 9acc236c    	lsl	x12, x27, x12
10147cdb0: ea13019f    	tst	x12, x19
10147cdb4: 540004e1    	b.ne	0x10147ce50 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x2a8>
10147cdb8: 7102015f    	cmp	w10, #0x80
10147cdbc: 54000163    	b.lo	0x10147cde8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x240>
10147cdc0: 53087d4c    	lsr	w12, w10, #8
10147cdc4: 71007d9f    	cmp	w12, #0x1f
10147cdc8: 5400024c    	b.gt	0x10147ce10 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x268>
10147cdcc: 3400030c    	cbz	w12, 0x10147ce2c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x284>
10147cdd0: 7100599f    	cmp	w12, #0x16
10147cdd4: 540000e1    	b.ne	0x10147cdf0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x248>
10147cdd8: 5282d00c    	mov	w12, #0x1680            ; =5760
10147cddc: 6b0c015f    	cmp	w10, w12
10147cde0: 54000081    	b.ne	0x10147cdf0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x248>
10147cde4: 1400001b    	b	0x10147ce50 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x2a8>
10147cde8: 7100f55f    	cmp	w10, #0x3d
10147cdec: 54000320    	b.eq	0x10147ce50 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x2a8>
10147cdf0: eb08017f    	cmp	x11, x8
10147cdf4: 540002c0    	b.eq	0x10147ce4c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x2a4>
10147cdf8: cb090289    	sub	x9, x20, x9
10147cdfc: 8b0b0134    	add	x20, x9, x11
10147ce00: 3940016a    	ldrb	w10, [x11]
10147ce04: aa0b03e9    	mov	x9, x11
10147ce08: 363ff90a    	tbz	w10, #0x7, 0x10147cd28 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x180>
10147ce0c: 17ffffcb    	b	0x10147cd38 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x190>
10147ce10: 7100819f    	cmp	w12, #0x20
10147ce14: 54000140    	b.eq	0x10147ce3c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x294>
10147ce18: 7100c19f    	cmp	w12, #0x30
10147ce1c: 54fffea1    	b.ne	0x10147cdf0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x248>
10147ce20: 71400d5f    	cmp	w10, #0x3, lsl #12      ; =0x3000
10147ce24: 54fffe61    	b.ne	0x10147cdf0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x248>
10147ce28: 1400000a    	b	0x10147ce50 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x2a8>
10147ce2c: 92401d4a    	and	x10, x10, #0xff
10147ce30: 386a6b0a    	ldrb	w10, [x24, x10]
10147ce34: 3607fdea    	tbz	w10, #0x0, 0x10147cdf0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x248>
10147ce38: 14000006    	b	0x10147ce50 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x2a8>
10147ce3c: 92401d4a    	and	x10, x10, #0xff
10147ce40: 386a6b0a    	ldrb	w10, [x24, x10]
10147ce44: 360ffd6a    	tbz	w10, #0x1, 0x10147cdf0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x248>
10147ce48: 14000002    	b	0x10147ce50 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x2a8>
10147ce4c: aa0103f4    	mov	x20, x1
10147ce50: b4ffefb4    	cbz	x20, 0x10147cc44 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x9c>
10147ce54: eb140028    	subs	x8, x1, x20
10147ce58: 540000a9    	b.ls	0x10147ce6c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x2c4>
10147ce5c: 38f46809    	ldrsb	w9, [x0, x20]
10147ce60: 3101053f    	cmn	w9, #0x41
10147ce64: 5400006c    	b.gt	0x10147ce70 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x2c8>
10147ce68: 14000112    	b	0x10147d2b0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x708>
10147ce6c: 54002221    	b.ne	0x10147d2b0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x708>
10147ce70: aa1803f3    	mov	x19, x24
10147ce74: aa0003f8    	mov	x24, x0
10147ce78: 8b140000    	add	x0, x0, x20
10147ce7c: aa0803e1    	mov	x1, x8
10147ce80: 97d33f8d    	bl	0x10094ccb4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c8c>
10147ce84: aa0003f7    	mov	x23, x0
10147ce88: aa0103f6    	mov	x22, x1
10147ce8c: b4000121    	cbz	x1, 0x10147ceb0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x308>
10147ce90: 394002e8    	ldrb	w8, [x23]
10147ce94: 7100f51f    	cmp	w8, #0x3d
10147ce98: 540000c1    	b.ne	0x10147ceb0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x308>
10147ce9c: d10006c1    	sub	x1, x22, #0x1
10147cea0: 910006e0    	add	x0, x23, #0x1
10147cea4: 97d33f84    	bl	0x10094ccb4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c8c>
10147cea8: aa0003f7    	mov	x23, x0
10147ceac: aa0103f6    	mov	x22, x1
10147ceb0: 97d88610    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147ceb4: aa1403e0    	mov	x0, x20
10147ceb8: 52800021    	mov	w1, #0x1                ; =1
10147cebc: 97d88607    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147cec0: b4002040    	cbz	x0, 0x10147d2c8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x720>
10147cec4: aa0003f5    	mov	x21, x0
10147cec8: aa1803e1    	mov	x1, x24
10147cecc: aa1403e2    	mov	x2, x20
10147ced0: 94193356    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147ced4: f100229f    	cmp	x20, #0x8
10147ced8: 54000082    	b.hs	0x10147cee8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x340>
10147cedc: d2800008    	mov	x8, #0x0                ; =0
10147cee0: aa1303f8    	mov	x24, x19
10147cee4: 14000034    	b	0x10147cfb4 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x40c>
10147cee8: f101029f    	cmp	x20, #0x40
10147ceec: aa1303f8    	mov	x24, x19
10147cef0: 54000062    	b.hs	0x10147cefc <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x354>
10147cef4: d2800008    	mov	x8, #0x0                ; =0
10147cef8: 14000021    	b	0x10147cf7c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x3d4>
10147cefc: 927ae688    	and	x8, x20, #0xffffffffffffffc0
10147cf00: 910082a9    	add	x9, x21, #0x20
10147cf04: aa0803ea    	mov	x10, x8
10147cf08: 4f05e7f0    	movi.16b	v16, #0xbf
10147cf0c: 4f00e751    	movi.16b	v17, #0x1a
10147cf10: 4f01e412    	movi.16b	v18, #0x20
10147cf14: ad7f0520    	ldp	q0, q1, [x9, #-0x20]
10147cf18: ad400d22    	ldp	q2, q3, [x9]
10147cf1c: 4e308404    	add.16b	v4, v0, v16
10147cf20: 4e308425    	add.16b	v5, v1, v16
10147cf24: 4e308446    	add.16b	v6, v2, v16
10147cf28: 4e308467    	add.16b	v7, v3, v16
10147cf2c: 6e243624    	cmhi.16b	v4, v17, v4
10147cf30: 6e253625    	cmhi.16b	v5, v17, v5
10147cf34: 6e263626    	cmhi.16b	v6, v17, v6
10147cf38: 6e273627    	cmhi.16b	v7, v17, v7
10147cf3c: 4e321c84    	and.16b	v4, v4, v18
10147cf40: 4e321ca5    	and.16b	v5, v5, v18
10147cf44: 4e321cc6    	and.16b	v6, v6, v18
10147cf48: 4e321ce7    	and.16b	v7, v7, v18
10147cf4c: 4ea01c80    	orr.16b	v0, v4, v0
10147cf50: 4ea11ca1    	orr.16b	v1, v5, v1
10147cf54: 4ea21cc2    	orr.16b	v2, v6, v2
10147cf58: ad3f0520    	stp	q0, q1, [x9, #-0x20]
10147cf5c: 4ea31ce0    	orr.16b	v0, v7, v3
10147cf60: ac820122    	stp	q2, q0, [x9], #0x40
10147cf64: f101014a    	subs	x10, x10, #0x40
10147cf68: 54fffd61    	b.ne	0x10147cf14 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x36c>
10147cf6c: eb08029f    	cmp	x20, x8
10147cf70: 54000360    	b.eq	0x10147cfdc <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x434>
10147cf74: f27d0a9f    	tst	x20, #0x38
10147cf78: 540001e0    	b.eq	0x10147cfb4 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x40c>
10147cf7c: aa0803ea    	mov	x10, x8
10147cf80: 927df288    	and	x8, x20, #0xfffffffffffffff8
10147cf84: cb080149    	sub	x9, x10, x8
10147cf88: 8b0a02aa    	add	x10, x21, x10
10147cf8c: fd400140    	ldr	d0, [x10]
10147cf90: 0e288401    	add.8b	v1, v0, v8
10147cf94: 2e213521    	cmhi.8b	v1, v9, v1
10147cf98: 0e2a1c21    	and.8b	v1, v1, v10
10147cf9c: 0ea01c20    	orr.8b	v0, v1, v0
10147cfa0: fc008540    	str	d0, [x10], #0x8
10147cfa4: b1002129    	adds	x9, x9, #0x8
10147cfa8: 54ffff21    	b.ne	0x10147cf8c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x3e4>
10147cfac: eb08029f    	cmp	x20, x8
10147cfb0: 54000160    	b.eq	0x10147cfdc <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x434>
10147cfb4: cb080289    	sub	x9, x20, x8
10147cfb8: 8b0802a8    	add	x8, x21, x8
10147cfbc: 3940010a    	ldrb	w10, [x8]
10147cfc0: 5101054b    	sub	w11, w10, #0x41
10147cfc4: 7100697f    	cmp	w11, #0x1a
10147cfc8: 1a9f338b    	csel	w11, w28, wzr, lo
10147cfcc: 2a0a016a    	orr	w10, w11, w10
10147cfd0: 3800150a    	strb	w10, [x8], #0x1
10147cfd4: f1000529    	subs	x9, x9, #0x1
10147cfd8: 54ffff21    	b.ne	0x10147cfbc <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x414>
10147cfdc: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10147cfe0: eb08029f    	cmp	x20, x8
10147cfe4: 54ffe2c0    	b.eq	0x10147cc3c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x94>
10147cfe8: f1001e9f    	cmp	x20, #0x7
10147cfec: 54000600    	b.eq	0x10147d0ac <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x504>
10147cff0: f100169f    	cmp	x20, #0x5
10147cff4: 540003c0    	b.eq	0x10147d06c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x4c4>
10147cff8: f100129f    	cmp	x20, #0x4
10147cffc: 540006a1    	b.ne	0x10147d0d0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x528>
10147d000: b94002a8    	ldr	w8, [x21]
10147d004: 528ded09    	mov	w9, #0x6f68             ; =28520
10147d008: 72ae8e69    	movk	w9, #0x7473, lsl #16
10147d00c: 6b09011f    	cmp	w8, w9
10147d010: 54000601    	b.ne	0x10147d0d0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x528>
10147d014: 910223e0    	add	x0, sp, #0x88
10147d018: aa1703e1    	mov	x1, x23
10147d01c: aa1603e2    	mov	x2, x22
10147d020: 97fffdd9    	bl	0x10147c784 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x78>
10147d024: f9404fe8    	ldr	x8, [sp, #0x98]
10147d028: d287c013    	mov	x19, #0x3e00            ; =15872
10147d02c: f2c00033    	movk	x19, #0x1, lsl #32
10147d030: b4000c88    	cbz	x8, 0x10147d1c0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x618>
10147d034: 3cc883e0    	ldur	q0, [sp, #0x88]
10147d038: 910283e9    	add	x9, sp, #0xa0
10147d03c: 3c808120    	stur	q0, [x9, #0x8]
10147d040: f9404fe8    	ldr	x8, [sp, #0x98]
10147d044: f8018128    	stur	x8, [x9, #0x18]
10147d048: b900c3f9    	str	w25, [sp, #0xc0]
10147d04c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10147d050: f90053e8    	str	x8, [sp, #0xa0]
10147d054: a941a3e9    	ldp	x9, x8, [sp, #0x18]
10147d058: eb08013f    	cmp	x9, x8
10147d05c: 54000e81    	b.ne	0x10147d22c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x684>
10147d060: 910083e0    	add	x0, sp, #0x20
10147d064: 94184f3e    	bl	0x101a90d5c <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h1f8bc85a2c28128eE>
10147d068: 1400006f    	b	0x10147d224 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x67c>
10147d06c: b94002a8    	ldr	w8, [x21]
10147d070: 394012a9    	ldrb	w9, [x21, #0x4]
10147d074: 528c2daa    	mov	w10, #0x616d            ; =24941
10147d078: 72ac6e8a    	movk	w10, #0x6374, lsl #16
10147d07c: 6b0a011f    	cmp	w8, w10
10147d080: 52800d08    	mov	w8, #0x68               ; =104
10147d084: 7a480120    	ccmp	w9, w8, #0x0, eq
10147d088: 54000241    	b.ne	0x10147d0d0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x528>
10147d08c: b4000ab6    	cbz	x22, 0x10147d1e0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x638>
10147d090: 97d88598    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147d094: aa1603e0    	mov	x0, x22
10147d098: 52800021    	mov	w1, #0x1                ; =1
10147d09c: 97d8858f    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147d0a0: aa0003f8    	mov	x24, x0
10147d0a4: b5000a00    	cbnz	x0, 0x10147d1e4 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x63c>
10147d0a8: 1400008c    	b	0x10147d2d8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x730>
10147d0ac: b94002a8    	ldr	w8, [x21]
10147d0b0: b84032a9    	ldur	w9, [x21, #0x3]
10147d0b4: 528dcd2a    	mov	w10, #0x6e69            ; =28265
10147d0b8: 72ad8c6a    	movk	w10, #0x6c63, lsl #16
10147d0bc: 6b0a011f    	cmp	w8, w10
10147d0c0: 528ead88    	mov	w8, #0x756c             ; =30060
10147d0c4: 72acac88    	movk	w8, #0x6564, lsl #16
10147d0c8: 7a480120    	ccmp	w9, w8, #0x0, eq
10147d0cc: 540004c0    	b.eq	0x10147d164 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x5bc>
10147d0d0: 910223e0    	add	x0, sp, #0x88
10147d0d4: aa1703e1    	mov	x1, x23
10147d0d8: aa1603e2    	mov	x2, x22
10147d0dc: 97fffdaa    	bl	0x10147c784 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x78>
10147d0e0: f9404fe8    	ldr	x8, [sp, #0x98]
10147d0e4: d287c013    	mov	x19, #0x3e00            ; =15872
10147d0e8: f2c00033    	movk	x19, #0x1, lsl #32
10147d0ec: b40006a8    	cbz	x8, 0x10147d1c0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x618>
10147d0f0: 3cc883e0    	ldur	q0, [sp, #0x88]
10147d0f4: 910283e9    	add	x9, sp, #0xa0
10147d0f8: 3c818120    	stur	q0, [x9, #0x18]
10147d0fc: f9404fe8    	ldr	x8, [sp, #0x98]
10147d100: f8028128    	stur	x8, [x9, #0x28]
10147d104: a90a57f4    	stp	x20, x21, [sp, #0xa0]
10147d108: f9005bf4    	str	x20, [sp, #0xb0]
10147d10c: b900d3f9    	str	w25, [sp, #0xd0]
10147d110: a941a3e9    	ldp	x9, x8, [sp, #0x18]
10147d114: eb08013f    	cmp	x9, x8
10147d118: 540000a1    	b.ne	0x10147d12c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x584>
10147d11c: 910083e0    	add	x0, sp, #0x20
10147d120: 94184f0f    	bl	0x101a90d5c <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h1f8bc85a2c28128eE>
10147d124: f94017e8    	ldr	x8, [sp, #0x28]
10147d128: f90007e8    	str	x8, [sp, #0x8]
10147d12c: f9400fea    	ldr	x10, [sp, #0x18]
10147d130: 52800708    	mov	w8, #0x38               ; =56
10147d134: f94007e9    	ldr	x9, [sp, #0x8]
10147d138: 9b082548    	madd	x8, x10, x8, x9
10147d13c: ad4507e0    	ldp	q0, q1, [sp, #0xa0]
10147d140: 3dc033e2    	ldr	q2, [sp, #0xc0]
10147d144: f9406be9    	ldr	x9, [sp, #0xd0]
10147d148: f9001909    	str	x9, [x8, #0x30]
10147d14c: ad008901    	stp	q1, q2, [x8, #0x10]
10147d150: 3d800100    	str	q0, [x8]
10147d154: 9100054a    	add	x10, x10, #0x1
10147d158: f9000fea    	str	x10, [sp, #0x18]
10147d15c: f9001bea    	str	x10, [sp, #0x30]
10147d160: 17fffeb9    	b	0x10147cc44 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x9c>
10147d164: 910223e0    	add	x0, sp, #0x88
10147d168: aa1703e1    	mov	x1, x23
10147d16c: aa1603e2    	mov	x2, x22
10147d170: 97fffd85    	bl	0x10147c784 <__ZN15otty_ssh_config4load9SshConfig3get17hb9c22860e1cf350fE+0x78>
10147d174: f9404fe8    	ldr	x8, [sp, #0x98]
10147d178: d287c013    	mov	x19, #0x3e00            ; =15872
10147d17c: f2c00033    	movk	x19, #0x1, lsl #32
10147d180: b4000208    	cbz	x8, 0x10147d1c0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x618>
10147d184: 3cc883e0    	ldur	q0, [sp, #0x88]
10147d188: 910283e9    	add	x9, sp, #0xa0
10147d18c: 3c808120    	stur	q0, [x9, #0x8]
10147d190: f9404fe8    	ldr	x8, [sp, #0x98]
10147d194: f8018128    	stur	x8, [x9, #0x18]
10147d198: b900c3f9    	str	w25, [sp, #0xc0]
10147d19c: d2800048    	mov	x8, #0x2                ; =2
10147d1a0: f2f00008    	movk	x8, #0x8000, lsl #48
10147d1a4: f90053e8    	str	x8, [sp, #0xa0]
10147d1a8: a941a3e9    	ldp	x9, x8, [sp, #0x18]
10147d1ac: eb08013f    	cmp	x9, x8
10147d1b0: 540003e1    	b.ne	0x10147d22c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x684>
10147d1b4: 910083e0    	add	x0, sp, #0x20
10147d1b8: 94184ee9    	bl	0x101a90d5c <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h1f8bc85a2c28128eE>
10147d1bc: 1400001a    	b	0x10147d224 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x67c>
10147d1c0: f94047e8    	ldr	x8, [sp, #0x88]
10147d1c4: b40004e8    	cbz	x8, 0x10147d260 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x6b8>
10147d1c8: f9404be0    	ldr	x0, [sp, #0x90]
10147d1cc: 8b080508    	add	x8, x8, x8, lsl #1
10147d1d0: d37df101    	lsl	x1, x8, #3
10147d1d4: 52800102    	mov	w2, #0x8                ; =8
10147d1d8: 97d88541    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147d1dc: 14000021    	b	0x10147d260 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x6b8>
10147d1e0: 52800038    	mov	w24, #0x1               ; =1
10147d1e4: aa1803e0    	mov	x0, x24
10147d1e8: aa1703e1    	mov	x1, x23
10147d1ec: aa1603e2    	mov	x2, x22
10147d1f0: 9419328e    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147d1f4: a90b5bf8    	stp	x24, x22, [sp, #0xb0]
10147d1f8: b900c3f9    	str	w25, [sp, #0xc0]
10147d1fc: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10147d200: a90a5be8    	stp	x8, x22, [sp, #0xa0]
10147d204: a941a3e9    	ldp	x9, x8, [sp, #0x18]
10147d208: eb08013f    	cmp	x9, x8
10147d20c: aa1303f8    	mov	x24, x19
10147d210: d287c013    	mov	x19, #0x3e00            ; =15872
10147d214: f2c00033    	movk	x19, #0x1, lsl #32
10147d218: 540000a1    	b.ne	0x10147d22c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x684>
10147d21c: 910083e0    	add	x0, sp, #0x20
10147d220: 94184ecf    	bl	0x101a90d5c <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h1f8bc85a2c28128eE>
10147d224: f94017e8    	ldr	x8, [sp, #0x28]
10147d228: f90007e8    	str	x8, [sp, #0x8]
10147d22c: f9400fea    	ldr	x10, [sp, #0x18]
10147d230: 52800708    	mov	w8, #0x38               ; =56
10147d234: f94007e9    	ldr	x9, [sp, #0x8]
10147d238: 9b082548    	madd	x8, x10, x8, x9
10147d23c: ad4507e0    	ldp	q0, q1, [sp, #0xa0]
10147d240: 3dc033e2    	ldr	q2, [sp, #0xc0]
10147d244: f9406be9    	ldr	x9, [sp, #0xd0]
10147d248: f9001909    	str	x9, [x8, #0x30]
10147d24c: ad008901    	stp	q1, q2, [x8, #0x10]
10147d250: 3d800100    	str	q0, [x8]
10147d254: 9100054a    	add	x10, x10, #0x1
10147d258: f9000fea    	str	x10, [sp, #0x18]
10147d25c: f9001bea    	str	x10, [sp, #0x30]
10147d260: aa1503e0    	mov	x0, x21
10147d264: aa1403e1    	mov	x1, x20
10147d268: 52800022    	mov	w2, #0x1                ; =1
10147d26c: 97d8851c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147d270: 17fffe75    	b	0x10147cc44 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x9c>
10147d274: 3dc00be0    	ldr	q0, [sp, #0x20]
10147d278: f9400be9    	ldr	x9, [sp, #0x10]
10147d27c: 3d800120    	str	q0, [x9]
10147d280: f9401be8    	ldr	x8, [sp, #0x30]
10147d284: f9000928    	str	x8, [x9, #0x10]
10147d288: a9557bfd    	ldp	x29, x30, [sp, #0x150]
10147d28c: a9544ff4    	ldp	x20, x19, [sp, #0x140]
10147d290: a95357f6    	ldp	x22, x21, [sp, #0x130]
10147d294: a9525ff8    	ldp	x24, x23, [sp, #0x120]
10147d298: a95167fa    	ldp	x26, x25, [sp, #0x110]
10147d29c: a9506ffc    	ldp	x28, x27, [sp, #0x100]
10147d2a0: 6d4f23e9    	ldp	d9, d8, [sp, #0xf0]
10147d2a4: 6d4e2beb    	ldp	d11, d10, [sp, #0xe0]
10147d2a8: 910583ff    	add	sp, sp, #0x160
10147d2ac: d65f03c0    	ret
10147d2b0: b0006f64    	adrp	x4, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
10147d2b4: 91264084    	add	x4, x4, #0x990
10147d2b8: d2800002    	mov	x2, #0x0                ; =0
10147d2bc: aa1403e3    	mov	x3, x20
10147d2c0: 941918d2    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
10147d2c4: 14000008    	b	0x10147d2e4 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x73c>
10147d2c8: 52800020    	mov	w0, #0x1                ; =1
10147d2cc: aa1403e1    	mov	x1, x20
10147d2d0: 94191829    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10147d2d4: 14000004    	b	0x10147d2e4 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x73c>
10147d2d8: 52800020    	mov	w0, #0x1                ; =1
10147d2dc: aa1603e1    	mov	x1, x22
10147d2e0: 94191825    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10147d2e4: d4200020    	brk	#0x1
10147d2e8: 14000002    	b	0x10147d2f0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x748>
10147d2ec: 14000001    	b	0x10147d2f0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x748>
10147d2f0: aa0003f3    	mov	x19, x0
10147d2f4: 910283e0    	add	x0, sp, #0xa0
10147d2f8: 97d302e0    	bl	0x10093de78 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2ae50>
10147d2fc: 1400000a    	b	0x10147d324 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x77c>
10147d300: 14000008    	b	0x10147d320 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x778>
10147d304: aa0003f3    	mov	x19, x0
10147d308: 910283e0    	add	x0, sp, #0xa0
10147d30c: 97d302db    	bl	0x10093de78 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2ae50>
10147d310: 910083e0    	add	x0, sp, #0x20
10147d314: 97d3203a    	bl	0x1009453fc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x323d4>
10147d318: aa1303e0    	mov	x0, x19
10147d31c: 941930ae    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147d320: aa0003f3    	mov	x19, x0
10147d324: aa1503e0    	mov	x0, x21
10147d328: aa1403e1    	mov	x1, x20
10147d32c: 52800022    	mov	w2, #0x1                ; =1
10147d330: 97d884eb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147d334: 910083e0    	add	x0, sp, #0x20
10147d338: 97d32031    	bl	0x1009453fc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x323d4>
10147d33c: aa1303e0    	mov	x0, x19
10147d340: 941930a5    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147d344: aa0003f3    	mov	x19, x0
10147d348: 910083e0    	add	x0, sp, #0x20
10147d34c: 97d3202c    	bl	0x1009453fc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x323d4>
10147d350: aa1303e0    	mov	x0, x19
10147d354: 941930a0    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147d358: aa0003f3    	mov	x19, x0
10147d35c: 910083e0    	add	x0, sp, #0x20
10147d360: 97d32027    	bl	0x1009453fc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x323d4>
10147d364: aa1303e0    	mov	x0, x19
10147d368: 9419309b    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147d36c: d10503ff    	sub	sp, sp, #0x140
10147d370: a90e6ffc    	stp	x28, x27, [sp, #0xe0]
10147d374: a90f67fa    	stp	x26, x25, [sp, #0xf0]
10147d378: a9105ff8    	stp	x24, x23, [sp, #0x100]
10147d37c: a91157f6    	stp	x22, x21, [sp, #0x110]
10147d380: a9124ff4    	stp	x20, x19, [sp, #0x120]
10147d384: a9137bfd    	stp	x29, x30, [sp, #0x130]
10147d388: 9104c3fd    	add	x29, sp, #0x130
10147d38c: aa0003f4    	mov	x20, x0
10147d390: a9018fe2    	stp	x2, x3, [sp, #0x18]
10147d394: 9100a3e0    	add	x0, sp, #0x28
10147d398: 940000be    	bl	0x10147d690 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xae8>
10147d39c: f9401ff3    	ldr	x19, [sp, #0x38]
10147d3a0: b4000b33    	cbz	x19, 0x10147d504 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x95c>
10147d3a4: f9000bf4    	str	x20, [sp, #0x10]
10147d3a8: 910063e8    	add	x8, sp, #0x18
10147d3ac: b0000069    	adrp	x9, 0x10148a000 <__ZN3std2io5error5Error3new17h519eec155b6ed967E+0x50>
10147d3b0: 91012129    	add	x9, x9, #0x48
10147d3b4: a905a7e8    	stp	x8, x9, [sp, #0x58]
10147d3b8: b0004c80    	adrp	x0, 0x101e0e000 <_writev+0x101e0e000>
10147d3bc: 91138000    	add	x0, x0, #0x4e0
10147d3c0: d101e3a8    	sub	x8, x29, #0x78
10147d3c4: 910163e1    	add	x1, sp, #0x58
10147d3c8: 940e386e    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
10147d3cc: d280001c    	mov	x28, #0x0               ; =0
10147d3d0: 3cd883a0    	ldur	q0, [x29, #-0x78]
10147d3d4: 3d8013e0    	str	q0, [sp, #0x40]
10147d3d8: f85983aa    	ldur	x10, [x29, #-0x68]
10147d3dc: 8b130a68    	add	x8, x19, x19, lsl #2
10147d3e0: d37df11b    	lsl	x27, x8, #3
10147d3e4: a942d3e9    	ldp	x9, x20, [sp, #0x28]
10147d3e8: 8b1b0288    	add	x8, x20, x27
10147d3ec: a90553ea    	stp	x10, x20, [sp, #0x50]
10147d3f0: f90007e9    	str	x9, [sp, #0x8]
10147d3f4: a906a3e9    	stp	x9, x8, [sp, #0x68]
10147d3f8: d2f00013    	mov	x19, #-0x8000000000000000 ; =-9223372036854775808
10147d3fc: b0004c97    	adrp	x23, 0x101e0e000 <_writev+0x101e0e000>
10147d400: 9114eef7    	add	x23, x23, #0x53b
10147d404: 14000004    	b	0x10147d414 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x86c>
10147d408: 9100a39c    	add	x28, x28, #0x28
10147d40c: eb1c037f    	cmp	x27, x28
10147d410: 54000c20    	b.eq	0x10147d594 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x9ec>
10147d414: 8b1c0288    	add	x8, x20, x28
10147d418: f9400915    	ldr	x21, [x8, #0x10]
10147d41c: eb1302bf    	cmp	x21, x19
10147d420: 54000920    	b.eq	0x10147d544 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x99c>
10147d424: a9418916    	ldp	x22, x2, [x8, #0x18]
10147d428: a9402508    	ldp	x8, x9, [x8]
10147d42c: a90927e8    	stp	x8, x9, [sp, #0x90]
10147d430: d10243a0    	sub	x0, x29, #0x90
10147d434: aa1603e1    	mov	x1, x22
10147d438: 94000e62    	bl	0x101480dc0 <__ZN15otty_ssh_config5write14include_status17hc606e35df5f40982E+0x8e0>
10147d43c: 910243e8    	add	x8, sp, #0x90
10147d440: f81883a8    	stur	x8, [x29, #-0x78]
10147d444: b0000068    	adrp	x8, 0x10148a000 <__ZN3std2io5error5Error3new17h519eec155b6ed967E+0x50>
10147d448: 91012109    	add	x9, x8, #0x48
10147d44c: d10243a8    	sub	x8, x29, #0x90
10147d450: a93923a9    	stp	x9, x8, [x29, #-0x70]
10147d454: 90000088    	adrp	x8, 0x10148d000 <__ZN4core5slice4sort6stable9quicksort9quicksort17h1ad04638c7ce3510E+0x1068>
10147d458: 910c9108    	add	x8, x8, #0x324
10147d45c: f81a03a8    	stur	x8, [x29, #-0x60]
10147d460: 9101e3e8    	add	x8, sp, #0x78
10147d464: d101e3a1    	sub	x1, x29, #0x78
10147d468: aa1703e0    	mov	x0, x23
10147d46c: 940e3845    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
10147d470: f85703a1    	ldur	x1, [x29, #-0x90]
10147d474: b4000081    	cbz	x1, 0x10147d484 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x8dc>
10147d478: f85783a0    	ldur	x0, [x29, #-0x88]
10147d47c: 52800022    	mov	w2, #0x1                ; =1
10147d480: 97d88497    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147d484: a94867f8    	ldp	x24, x25, [sp, #0x80]
10147d488: f9402bfa    	ldr	x26, [sp, #0x50]
10147d48c: f94023e8    	ldr	x8, [sp, #0x40]
10147d490: cb1a0108    	sub	x8, x8, x26
10147d494: eb08033f    	cmp	x25, x8
10147d498: 54000268    	b.hi	0x10147d4e4 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x93c>
10147d49c: f94027e8    	ldr	x8, [sp, #0x48]
10147d4a0: 8b1a0100    	add	x0, x8, x26
10147d4a4: aa1803e1    	mov	x1, x24
10147d4a8: aa1903e2    	mov	x2, x25
10147d4ac: 941931df    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147d4b0: 8b190348    	add	x8, x26, x25
10147d4b4: f9002be8    	str	x8, [sp, #0x50]
10147d4b8: f9403fe1    	ldr	x1, [sp, #0x78]
10147d4bc: b4000081    	cbz	x1, 0x10147d4cc <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x924>
10147d4c0: aa1803e0    	mov	x0, x24
10147d4c4: 52800022    	mov	w2, #0x1                ; =1
10147d4c8: 97d88485    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147d4cc: b4fff9f5    	cbz	x21, 0x10147d408 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x860>
10147d4d0: aa1603e0    	mov	x0, x22
10147d4d4: aa1503e1    	mov	x1, x21
10147d4d8: 52800022    	mov	w2, #0x1                ; =1
10147d4dc: 97d88480    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147d4e0: 17ffffca    	b	0x10147d408 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x860>
10147d4e4: 910103e0    	add	x0, sp, #0x40
10147d4e8: aa1a03e1    	mov	x1, x26
10147d4ec: aa1903e2    	mov	x2, x25
10147d4f0: 52800023    	mov	w3, #0x1                ; =1
10147d4f4: 52800024    	mov	w4, #0x1                ; =1
10147d4f8: 9416acd6    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10147d4fc: f9402bfa    	ldr	x26, [sp, #0x50]
10147d500: 17ffffe7    	b	0x10147d49c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x8f4>
10147d504: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10147d508: f9000288    	str	x8, [x20]
10147d50c: f94017e8    	ldr	x8, [sp, #0x28]
10147d510: b40005a8    	cbz	x8, 0x10147d5c4 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xa1c>
10147d514: f9401be0    	ldr	x0, [sp, #0x30]
10147d518: 8b080908    	add	x8, x8, x8, lsl #2
10147d51c: d37df101    	lsl	x1, x8, #3
10147d520: 52800102    	mov	w2, #0x8                ; =8
10147d524: a9537bfd    	ldp	x29, x30, [sp, #0x130]
10147d528: a9524ff4    	ldp	x20, x19, [sp, #0x120]
10147d52c: a95157f6    	ldp	x22, x21, [sp, #0x110]
10147d530: a9505ff8    	ldp	x24, x23, [sp, #0x100]
10147d534: a94f67fa    	ldp	x26, x25, [sp, #0xf0]
10147d538: a94e6ffc    	ldp	x28, x27, [sp, #0xe0]
10147d53c: 910503ff    	add	sp, sp, #0x140
10147d540: 17d88467    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147d544: d100a369    	sub	x9, x27, #0x28
10147d548: eb1c013f    	cmp	x9, x28
10147d54c: 54000240    	b.eq	0x10147d594 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x9ec>
10147d550: 91010113    	add	x19, x8, #0x40
10147d554: cb1c0368    	sub	x8, x27, x28
10147d558: d100a108    	sub	x8, x8, #0x28
10147d55c: b202e7e9    	mov	x9, #-0x3333333333333334 ; =-3689348814741910324
10147d560: f29999a9    	movk	x9, #0xcccd
10147d564: 9bc97d08    	umulh	x8, x8, x9
10147d568: d345fd15    	lsr	x21, x8, #5
10147d56c: 14000004    	b	0x10147d57c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x9d4>
10147d570: 9100a273    	add	x19, x19, #0x28
10147d574: f10006b5    	subs	x21, x21, #0x1
10147d578: 540000e0    	b.eq	0x10147d594 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x9ec>
10147d57c: f85f8261    	ldur	x1, [x19, #-0x8]
10147d580: b4ffff81    	cbz	x1, 0x10147d570 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x9c8>
10147d584: f9400260    	ldr	x0, [x19]
10147d588: 52800022    	mov	w2, #0x1                ; =1
10147d58c: 97d88454    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147d590: 17fffff8    	b	0x10147d570 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x9c8>
10147d594: f94007e8    	ldr	x8, [sp, #0x8]
10147d598: b40000c8    	cbz	x8, 0x10147d5b0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xa08>
10147d59c: 8b080908    	add	x8, x8, x8, lsl #2
10147d5a0: d37df101    	lsl	x1, x8, #3
10147d5a4: aa1403e0    	mov	x0, x20
10147d5a8: 52800102    	mov	w2, #0x8                ; =8
10147d5ac: 97d8844c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147d5b0: 3dc013e0    	ldr	q0, [sp, #0x40]
10147d5b4: f9400be9    	ldr	x9, [sp, #0x10]
10147d5b8: 3d800120    	str	q0, [x9]
10147d5bc: f9402be8    	ldr	x8, [sp, #0x50]
10147d5c0: f9000928    	str	x8, [x9, #0x10]
10147d5c4: a9537bfd    	ldp	x29, x30, [sp, #0x130]
10147d5c8: a9524ff4    	ldp	x20, x19, [sp, #0x120]
10147d5cc: a95157f6    	ldp	x22, x21, [sp, #0x110]
10147d5d0: a9505ff8    	ldp	x24, x23, [sp, #0x100]
10147d5d4: a94f67fa    	ldp	x26, x25, [sp, #0xf0]
10147d5d8: a94e6ffc    	ldp	x28, x27, [sp, #0xe0]
10147d5dc: 910503ff    	add	sp, sp, #0x140
10147d5e0: d65f03c0    	ret
10147d5e4: aa0003f3    	mov	x19, x0
10147d5e8: 8b1c0288    	add	x8, x20, x28
10147d5ec: 9100a108    	add	x8, x8, #0x28
10147d5f0: f90033e8    	str	x8, [sp, #0x60]
10147d5f4: f9403fe1    	ldr	x1, [sp, #0x78]
10147d5f8: b40002c1    	cbz	x1, 0x10147d650 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xaa8>
10147d5fc: aa1803e0    	mov	x0, x24
10147d600: 1400000d    	b	0x10147d634 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xa8c>
10147d604: aa0003f3    	mov	x19, x0
10147d608: 9100a3e0    	add	x0, sp, #0x28
10147d60c: 97dcfb8f    	bl	0x100bbc448 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hcf7d51b5b4311c36E+0x8b30>
10147d610: aa1303e0    	mov	x0, x19
10147d614: 94192ff0    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147d618: aa0003f3    	mov	x19, x0
10147d61c: 8b1c0288    	add	x8, x20, x28
10147d620: 9100a108    	add	x8, x8, #0x28
10147d624: f90033e8    	str	x8, [sp, #0x60]
10147d628: f85703a1    	ldur	x1, [x29, #-0x90]
10147d62c: b4000121    	cbz	x1, 0x10147d650 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xaa8>
10147d630: f85783a0    	ldur	x0, [x29, #-0x88]
10147d634: 52800022    	mov	w2, #0x1                ; =1
10147d638: 97d88429    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147d63c: 14000005    	b	0x10147d650 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xaa8>
10147d640: aa0003f3    	mov	x19, x0
10147d644: 8b1c0288    	add	x8, x20, x28
10147d648: 9100a108    	add	x8, x8, #0x28
10147d64c: f90033e8    	str	x8, [sp, #0x60]
10147d650: b40000b5    	cbz	x21, 0x10147d664 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xabc>
10147d654: aa1603e0    	mov	x0, x22
10147d658: aa1503e1    	mov	x1, x21
10147d65c: 52800022    	mov	w2, #0x1                ; =1
10147d660: 97d8841f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147d664: 910163e0    	add	x0, sp, #0x58
10147d668: 9400348d    	bl	0x10148a89c <__ZN3std2io5error5Error3new17h519eec155b6ed967E+0x8ec>
10147d66c: f94023e1    	ldr	x1, [sp, #0x40]
10147d670: b5000061    	cbnz	x1, 0x10147d67c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xad4>
10147d674: aa1303e0    	mov	x0, x19
10147d678: 94192fd7    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147d67c: f94027e0    	ldr	x0, [sp, #0x48]
10147d680: 52800022    	mov	w2, #0x1                ; =1
10147d684: 97d88416    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147d688: aa1303e0    	mov	x0, x19
10147d68c: 94192fd2    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147d690: d101c3ff    	sub	sp, sp, #0x70
10147d694: a9035ff8    	stp	x24, x23, [sp, #0x30]
10147d698: a90457f6    	stp	x22, x21, [sp, #0x40]
10147d69c: a9054ff4    	stp	x20, x19, [sp, #0x50]
10147d6a0: a9067bfd    	stp	x29, x30, [sp, #0x60]
10147d6a4: 910183fd    	add	x29, sp, #0x60
10147d6a8: aa0103f4    	mov	x20, x1
10147d6ac: aa0003f3    	mov	x19, x0
10147d6b0: f9400028    	ldr	x8, [x1]
10147d6b4: b24107e9    	mov	x9, #-0x7fffffffffffffff ; =-9223372036854775807
10147d6b8: 8b090109    	add	x9, x8, x9
10147d6bc: 8a88fd28    	and	x8, x9, x8, asr #63
10147d6c0: f100051f    	cmp	x8, #0x1
10147d6c4: 5400060d    	b.le	0x10147d784 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xbdc>
10147d6c8: f100091f    	cmp	x8, #0x2
10147d6cc: 540010a0    	b.eq	0x10147d8e0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xd38>
10147d6d0: f1000d1f    	cmp	x8, #0x3
10147d6d4: 540012e1    	b.ne	0x10147d930 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xd88>
10147d6d8: 97d88406    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147d6dc: 52800a00    	mov	w0, #0x50               ; =80
10147d6e0: 52800101    	mov	w1, #0x8                ; =8
10147d6e4: 97d883fd    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147d6e8: b4001ec0    	cbz	x0, 0x10147dac0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf18>
10147d6ec: aa0003f4    	mov	x20, x0
10147d6f0: 97d88400    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147d6f4: 52800040    	mov	w0, #0x2                ; =2
10147d6f8: 52800021    	mov	w1, #0x1                ; =1
10147d6fc: 97d883f7    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147d700: b4001e60    	cbz	x0, 0x10147dacc <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf24>
10147d704: aa0003f5    	mov	x21, x0
10147d708: 528dedc8    	mov	w8, #0x6f6e             ; =28526
10147d70c: 79000008    	strh	w8, [x0]
10147d710: 97d883f8    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147d714: 528003a0    	mov	w0, #0x1d               ; =29
10147d718: 52800021    	mov	w1, #0x1                ; =1
10147d71c: 97d883ef    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147d720: b4001e60    	cbz	x0, 0x10147daec <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf44>
10147d724: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147d728: 9110e908    	add	x8, x8, #0x43a
10147d72c: 3dc00100    	ldr	q0, [x8]
10147d730: 3d800000    	str	q0, [x0]
10147d734: 3cc0d100    	ldur	q0, [x8, #0xd]
10147d738: 3c80d000    	stur	q0, [x0, #0xd]
10147d73c: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147d740: 91109908    	add	x8, x8, #0x426
10147d744: f9000288    	str	x8, [x20]
10147d748: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147d74c: 3dc0b500    	ldr	q0, [x8, #0x2d0]
10147d750: 3c808280    	stur	q0, [x20, #0x8]
10147d754: 52800048    	mov	w8, #0x2                ; =2
10147d758: a901a295    	stp	x21, x8, [x20, #0x18]
10147d75c: d0004329    	adrp	x9, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147d760: 91115d29    	add	x9, x9, #0x457
10147d764: f9001689    	str	x9, [x20, #0x28]
10147d768: d0004329    	adrp	x9, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147d76c: 3dc0b920    	ldr	q0, [x9, #0x2e0]
10147d770: 3d800e80    	str	q0, [x20, #0x30]
10147d774: 528003a9    	mov	w9, #0x1d               ; =29
10147d778: a9042680    	stp	x0, x9, [x20, #0x40]
10147d77c: a9005268    	stp	x8, x20, [x19]
10147d780: 140000c6    	b	0x10147da98 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xef0>
10147d784: b5000de8    	cbnz	x8, 0x10147d940 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xd98>
10147d788: 97d883da    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147d78c: 52800a00    	mov	w0, #0x50               ; =80
10147d790: 52800101    	mov	w1, #0x8                ; =8
10147d794: 97d883d1    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147d798: b4001940    	cbz	x0, 0x10147dac0 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf18>
10147d79c: aa0003f5    	mov	x21, x0
10147d7a0: 910063e8    	add	x8, sp, #0x18
10147d7a4: aa1403e0    	mov	x0, x20
10147d7a8: 940e4689    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10147d7ac: a941dff6    	ldp	x22, x23, [sp, #0x18]
10147d7b0: f94017f8    	ldr	x24, [sp, #0x28]
10147d7b4: 97d883cf    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147d7b8: 52800060    	mov	w0, #0x3                ; =3
10147d7bc: 52800021    	mov	w1, #0x1                ; =1
10147d7c0: 97d883c6    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147d7c4: b40019c0    	cbz	x0, 0x10147dafc <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf54>
10147d7c8: 52800e68    	mov	w8, #0x73               ; =115
10147d7cc: 39000808    	strb	w8, [x0, #0x2]
10147d7d0: 528caf28    	mov	w8, #0x6579             ; =25977
10147d7d4: 79000008    	strh	w8, [x0]
10147d7d8: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147d7dc: 910f6508    	add	x8, x8, #0x3d9
10147d7e0: 52800189    	mov	w9, #0xc                ; =12
10147d7e4: a90026a8    	stp	x8, x9, [x21]
10147d7e8: a9015eb6    	stp	x22, x23, [x21, #0x10]
10147d7ec: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147d7f0: 910f9508    	add	x8, x8, #0x3e5
10147d7f4: a90222b8    	stp	x24, x8, [x21, #0x20]
10147d7f8: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147d7fc: 3dc0bd00    	ldr	q0, [x8, #0x2f0]
10147d800: 3d800ea0    	str	q0, [x21, #0x30]
10147d804: 52800068    	mov	w8, #0x3                ; =3
10147d808: a90422a0    	stp	x0, x8, [x21, #0x40]
10147d80c: 52800048    	mov	w8, #0x2                ; =2
10147d810: a901d7e8    	stp	x8, x21, [sp, #0x18]
10147d814: f90017e8    	str	x8, [sp, #0x28]
10147d818: 39406288    	ldrb	w8, [x20, #0x18]
10147d81c: 36001388    	tbz	w8, #0x0, 0x10147da8c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xee4>
10147d820: 3d8003e0    	str	q0, [sp]
10147d824: 97d883b3    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147d828: 52800060    	mov	w0, #0x3                ; =3
10147d82c: 52800021    	mov	w1, #0x1                ; =1
10147d830: 97d883aa    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147d834: b40016c0    	cbz	x0, 0x10147db0c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf64>
10147d838: aa0003f4    	mov	x20, x0
10147d83c: 52800e68    	mov	w8, #0x73               ; =115
10147d840: 39000808    	strb	w8, [x0, #0x2]
10147d844: 528caf28    	mov	w8, #0x6579             ; =25977
10147d848: 79000008    	strh	w8, [x0]
10147d84c: 910063e0    	add	x0, sp, #0x18
10147d850: 94184d91    	bl	0x101a90e94 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h87933242974444aeE>
10147d854: f94013f5    	ldr	x21, [sp, #0x20]
10147d858: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147d85c: 910fcd08    	add	x8, x8, #0x3f3
10147d860: f9002aa8    	str	x8, [x21, #0x50]
10147d864: 3dc003e0    	ldr	q0, [sp]
10147d868: 3c8582a0    	stur	q0, [x21, #0x58]
10147d86c: 52800068    	mov	w8, #0x3                ; =3
10147d870: a906a2b4    	stp	x20, x8, [x21, #0x68]
10147d874: f90017e8    	str	x8, [sp, #0x28]
10147d878: 97d8839e    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147d87c: 52800060    	mov	w0, #0x3                ; =3
10147d880: 52800021    	mov	w1, #0x1                ; =1
10147d884: 97d88395    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147d888: b4001420    	cbz	x0, 0x10147db0c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf64>
10147d88c: aa0003f4    	mov	x20, x0
10147d890: 52800e68    	mov	w8, #0x73               ; =115
10147d894: 39000808    	strb	w8, [x0, #0x2]
10147d898: 528caf28    	mov	w8, #0x6579             ; =25977
10147d89c: 79000008    	strh	w8, [x0]
10147d8a0: f9400fe8    	ldr	x8, [sp, #0x18]
10147d8a4: f1000d1f    	cmp	x8, #0x3
10147d8a8: 54000081    	b.ne	0x10147d8b8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xd10>
10147d8ac: 910063e0    	add	x0, sp, #0x18
10147d8b0: 94184d79    	bl	0x101a90e94 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h87933242974444aeE>
10147d8b4: f94013f5    	ldr	x21, [sp, #0x20]
10147d8b8: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147d8bc: 91100508    	add	x8, x8, #0x401
10147d8c0: f9003ea8    	str	x8, [x21, #0x78]
10147d8c4: d0003448    	adrp	x8, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
10147d8c8: 3dc31900    	ldr	q0, [x8, #0xc60]
10147d8cc: 3d8022a0    	str	q0, [x21, #0x80]
10147d8d0: 52800068    	mov	w8, #0x3                ; =3
10147d8d4: a90922b4    	stp	x20, x8, [x21, #0x90]
10147d8d8: 52800088    	mov	w8, #0x4                ; =4
10147d8dc: 1400006b    	b	0x10147da88 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xee0>
10147d8e0: 97d88384    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147d8e4: 52800500    	mov	w0, #0x28               ; =40
10147d8e8: 52800101    	mov	w1, #0x8                ; =8
10147d8ec: 97d8837b    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147d8f0: b4000e20    	cbz	x0, 0x10147dab4 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf0c>
10147d8f4: aa0003f5    	mov	x21, x0
10147d8f8: 910063e8    	add	x8, sp, #0x18
10147d8fc: 91002280    	add	x0, x20, #0x8
10147d900: 940e4633    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10147d904: 3cc183e0    	ldur	q0, [sp, #0x18]
10147d908: 3d8006a0    	str	q0, [x21, #0x10]
10147d90c: f94017e8    	ldr	x8, [sp, #0x28]
10147d910: f90012a8    	str	x8, [x21, #0x20]
10147d914: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147d918: 91106508    	add	x8, x8, #0x419
10147d91c: 528001a9    	mov	w9, #0xd                ; =13
10147d920: a90026a8    	stp	x8, x9, [x21]
10147d924: 52800028    	mov	w8, #0x1                ; =1
10147d928: a9005668    	stp	x8, x21, [x19]
10147d92c: 1400005b    	b	0x10147da98 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xef0>
10147d930: 52800108    	mov	w8, #0x8                ; =8
10147d934: a900227f    	stp	xzr, x8, [x19]
10147d938: f9000a7f    	str	xzr, [x19, #0x10]
10147d93c: 14000058    	b	0x10147da9c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xef4>
10147d940: 97d8836c    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147d944: 52800500    	mov	w0, #0x28               ; =40
10147d948: 52800101    	mov	w1, #0x8                ; =8
10147d94c: 97d88363    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147d950: b4000b20    	cbz	x0, 0x10147dab4 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf0c>
10147d954: aa0003f5    	mov	x21, x0
10147d958: 97d88366    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147d95c: 528001a0    	mov	w0, #0xd                ; =13
10147d960: 52800021    	mov	w1, #0x1                ; =1
10147d964: 97d8835d    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147d968: b4000ba0    	cbz	x0, 0x10147dadc <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf34>
10147d96c: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147d970: 91103108    	add	x8, x8, #0x40c
10147d974: f9400109    	ldr	x9, [x8]
10147d978: f9000009    	str	x9, [x0]
10147d97c: f8405108    	ldur	x8, [x8, #0x5]
10147d980: f8005008    	stur	x8, [x0, #0x5]
10147d984: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147d988: 91106508    	add	x8, x8, #0x419
10147d98c: f90002a8    	str	x8, [x21]
10147d990: 528001a8    	mov	w8, #0xd                ; =13
10147d994: 4e080d00    	dup.2d	v0, x8
10147d998: 3c8082a0    	stur	q0, [x21, #0x8]
10147d99c: a901a2a0    	stp	x0, x8, [x21, #0x18]
10147d9a0: 52800028    	mov	w8, #0x1                ; =1
10147d9a4: a901d7e8    	stp	x8, x21, [sp, #0x18]
10147d9a8: f90017e8    	str	x8, [sp, #0x28]
10147d9ac: f9400688    	ldr	x8, [x20, #0x8]
10147d9b0: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10147d9b4: eb09011f    	cmp	x8, x9
10147d9b8: 540006a0    	b.eq	0x10147da8c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xee4>
10147d9bc: a9410680    	ldp	x0, x1, [x20, #0x10]
10147d9c0: 97d33be9    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
10147d9c4: b4000640    	cbz	x0, 0x10147da8c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xee4>
10147d9c8: aa0103f4    	mov	x20, x1
10147d9cc: b4000601    	cbz	x1, 0x10147da8c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xee4>
10147d9d0: aa0003f6    	mov	x22, x0
10147d9d4: 97d88347    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147d9d8: aa1403e0    	mov	x0, x20
10147d9dc: 52800021    	mov	w1, #0x1                ; =1
10147d9e0: 97d8833e    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147d9e4: b40009c0    	cbz	x0, 0x10147db1c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf74>
10147d9e8: aa0003f5    	mov	x21, x0
10147d9ec: aa1603e1    	mov	x1, x22
10147d9f0: aa1403e2    	mov	x2, x20
10147d9f4: 9419308d    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147d9f8: 910063e0    	add	x0, sp, #0x18
10147d9fc: 94184d26    	bl	0x101a90e94 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h87933242974444aeE>
10147da00: f94013f6    	ldr	x22, [sp, #0x20]
10147da04: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147da08: 910f6508    	add	x8, x8, #0x3d9
10147da0c: 52800189    	mov	w9, #0xc                ; =12
10147da10: a902a6c8    	stp	x8, x9, [x22, #0x28]
10147da14: a903d6d4    	stp	x20, x21, [x22, #0x38]
10147da18: f90026d4    	str	x20, [x22, #0x48]
10147da1c: 52800048    	mov	w8, #0x2                ; =2
10147da20: f90017e8    	str	x8, [sp, #0x28]
10147da24: 97d88333    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147da28: 52800074    	mov	w20, #0x3               ; =3
10147da2c: 52800060    	mov	w0, #0x3                ; =3
10147da30: 52800021    	mov	w1, #0x1                ; =1
10147da34: 97d88329    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147da38: b4000720    	cbz	x0, 0x10147db1c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf74>
10147da3c: aa0003f5    	mov	x21, x0
10147da40: 52800e68    	mov	w8, #0x73               ; =115
10147da44: 39000808    	strb	w8, [x0, #0x2]
10147da48: 528caf28    	mov	w8, #0x6579             ; =25977
10147da4c: 79000008    	strh	w8, [x0]
10147da50: f9400fe8    	ldr	x8, [sp, #0x18]
10147da54: f100091f    	cmp	x8, #0x2
10147da58: 54000081    	b.ne	0x10147da68 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xec0>
10147da5c: 910063e0    	add	x0, sp, #0x18
10147da60: 94184d0d    	bl	0x101a90e94 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h87933242974444aeE>
10147da64: f94013f6    	ldr	x22, [sp, #0x20]
10147da68: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147da6c: 910f9508    	add	x8, x8, #0x3e5
10147da70: f9002ac8    	str	x8, [x22, #0x50]
10147da74: d0004328    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147da78: 3dc0bd00    	ldr	q0, [x8, #0x2f0]
10147da7c: 3c8582c0    	stur	q0, [x22, #0x58]
10147da80: 52800068    	mov	w8, #0x3                ; =3
10147da84: a906a2d5    	stp	x21, x8, [x22, #0x68]
10147da88: f90017e8    	str	x8, [sp, #0x28]
10147da8c: 3cc183e0    	ldur	q0, [sp, #0x18]
10147da90: 3d800260    	str	q0, [x19]
10147da94: f94017e8    	ldr	x8, [sp, #0x28]
10147da98: f9000a68    	str	x8, [x19, #0x10]
10147da9c: a9467bfd    	ldp	x29, x30, [sp, #0x60]
10147daa0: a9454ff4    	ldp	x20, x19, [sp, #0x50]
10147daa4: a94457f6    	ldp	x22, x21, [sp, #0x40]
10147daa8: a9435ff8    	ldp	x24, x23, [sp, #0x30]
10147daac: 9101c3ff    	add	sp, sp, #0x70
10147dab0: d65f03c0    	ret
10147dab4: 52800100    	mov	w0, #0x8                ; =8
10147dab8: 52800501    	mov	w1, #0x28               ; =40
10147dabc: 94191620    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
10147dac0: 52800100    	mov	w0, #0x8                ; =8
10147dac4: 52800a01    	mov	w1, #0x50               ; =80
10147dac8: 9419161d    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
10147dacc: 52800020    	mov	w0, #0x1                ; =1
10147dad0: 52800041    	mov	w1, #0x2                ; =2
10147dad4: 94191628    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10147dad8: 14000014    	b	0x10147db28 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf80>
10147dadc: 52800020    	mov	w0, #0x1                ; =1
10147dae0: 528001a1    	mov	w1, #0xd                ; =13
10147dae4: 94191624    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10147dae8: 14000010    	b	0x10147db28 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf80>
10147daec: 52800020    	mov	w0, #0x1                ; =1
10147daf0: 528003a1    	mov	w1, #0x1d               ; =29
10147daf4: 94191620    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10147daf8: 1400000c    	b	0x10147db28 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf80>
10147dafc: 52800020    	mov	w0, #0x1                ; =1
10147db00: 52800061    	mov	w1, #0x3                ; =3
10147db04: 9419161c    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10147db08: 14000008    	b	0x10147db28 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf80>
10147db0c: 52800020    	mov	w0, #0x1                ; =1
10147db10: 52800061    	mov	w1, #0x3                ; =3
10147db14: 94191618    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10147db18: 14000004    	b	0x10147db28 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xf80>
10147db1c: 52800020    	mov	w0, #0x1                ; =1
10147db20: aa1403e1    	mov	x1, x20
10147db24: 94191614    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10147db28: d4200020    	brk	#0x1
10147db2c: aa0003f3    	mov	x19, x0
10147db30: aa1503e0    	mov	x0, x21
10147db34: 1400000d    	b	0x10147db68 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xfc0>
10147db38: 1400000a    	b	0x10147db60 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0xfb8>
10147db3c: aa0003f3    	mov	x19, x0
10147db40: aa1503e0    	mov	x0, x21
10147db44: aa1403e1    	mov	x1, x20
10147db48: 52800022    	mov	w2, #0x1                ; =1
10147db4c: 97d882e4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147db50: 910063e0    	add	x0, sp, #0x18
10147db54: 97dcfa3d    	bl	0x100bbc448 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hcf7d51b5b4311c36E+0x8b30>
10147db58: aa1303e0    	mov	x0, x19
10147db5c: 94192e9e    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147db60: aa0003f3    	mov	x19, x0
10147db64: aa1403e0    	mov	x0, x20
10147db68: 52800061    	mov	w1, #0x3                ; =3
10147db6c: 52800022    	mov	w2, #0x1                ; =1
10147db70: 97d882db    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147db74: 910063e0    	add	x0, sp, #0x18
10147db78: 97dcfa34    	bl	0x100bbc448 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hcf7d51b5b4311c36E+0x8b30>
10147db7c: aa1303e0    	mov	x0, x19
10147db80: 94192e95    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147db84: aa0003f3    	mov	x19, x0
10147db88: 910063e0    	add	x0, sp, #0x18
10147db8c: 97dcfa2f    	bl	0x100bbc448 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hcf7d51b5b4311c36E+0x8b30>
10147db90: aa1303e0    	mov	x0, x19
10147db94: 94192e90    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147db98: aa0003f3    	mov	x19, x0
10147db9c: 910063e0    	add	x0, sp, #0x18
10147dba0: 97dcfa2a    	bl	0x100bbc448 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hcf7d51b5b4311c36E+0x8b30>
10147dba4: aa1303e0    	mov	x0, x19
10147dba8: 94192e8b    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147dbac: aa0003f3    	mov	x19, x0
10147dbb0: b40003f6    	cbz	x22, 0x10147dc2c <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x1084>
10147dbb4: aa1703e0    	mov	x0, x23
10147dbb8: aa1603e1    	mov	x1, x22
10147dbbc: 52800022    	mov	w2, #0x1                ; =1
10147dbc0: 97d882c7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147dbc4: aa1503e0    	mov	x0, x21
10147dbc8: 52800a01    	mov	w1, #0x50               ; =80
10147dbcc: 52800102    	mov	w2, #0x8                ; =8
10147dbd0: 97d882c3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147dbd4: aa1303e0    	mov	x0, x19
10147dbd8: 94192e7f    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147dbdc: aa0003f3    	mov	x19, x0
10147dbe0: aa1503e0    	mov	x0, x21
10147dbe4: 52800041    	mov	w1, #0x2                ; =2
10147dbe8: 52800022    	mov	w2, #0x1                ; =1
10147dbec: 97d882bc    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147dbf0: aa1403e0    	mov	x0, x20
10147dbf4: 52800a01    	mov	w1, #0x50               ; =80
10147dbf8: 52800102    	mov	w2, #0x8                ; =8
10147dbfc: 97d882b8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147dc00: aa1303e0    	mov	x0, x19
10147dc04: 94192e74    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147dc08: 1400000f    	b	0x10147dc44 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E+0x109c>
10147dc0c: aa0003f3    	mov	x19, x0
10147dc10: aa1403e0    	mov	x0, x20
10147dc14: 52800a01    	mov	w1, #0x50               ; =80
10147dc18: 52800102    	mov	w2, #0x8                ; =8
10147dc1c: 97d882b0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147dc20: aa1303e0    	mov	x0, x19
10147dc24: 94192e6c    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147dc28: aa0003f3    	mov	x19, x0
10147dc2c: aa1503e0    	mov	x0, x21
10147dc30: 52800a01    	mov	w1, #0x50               ; =80
10147dc34: 52800102    	mov	w2, #0x8                ; =8
10147dc38: 97d882a9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147dc3c: aa1303e0    	mov	x0, x19
10147dc40: 94192e65    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147dc44: aa0003f3    	mov	x19, x0
10147dc48: aa1503e0    	mov	x0, x21
10147dc4c: 52800501    	mov	w1, #0x28               ; =40
10147dc50: 52800102    	mov	w2, #0x8                ; =8
10147dc54: 97d882a2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147dc58: aa1303e0    	mov	x0, x19
10147dc5c: 94192e5e    	bl	0x101ac95d4 <_writev+0x101ac95d4>
