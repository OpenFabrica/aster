
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101432f78 <__ZN17otty_autocomplete6engine6Engine11known_flags17hf02d40176fa4b1ccE>:
101432f78: d10203ff    	sub	sp, sp, #0x80
101432f7c: a9045ff8    	stp	x24, x23, [sp, #0x40]
101432f80: a90557f6    	stp	x22, x21, [sp, #0x50]
101432f84: a9064ff4    	stp	x20, x19, [sp, #0x60]
101432f88: a9077bfd    	stp	x29, x30, [sp, #0x70]
101432f8c: 9101c3fd    	add	x29, sp, #0x70
101432f90: aa0003f4    	mov	x20, x0
101432f94: aa0803f3    	mov	x19, x8
101432f98: d0007a40    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101432f9c: 9131a000    	add	x0, x0, #0xc68
101432fa0: f9400008    	ldr	x8, [x0]
101432fa4: d63f0100    	blr	x8
101432fa8: 39404008    	ldrb	w8, [x0, #0x10]
101432fac: 7100051f    	cmp	w8, #0x1
101432fb0: 540004c1    	b.ne	0x101433048 <__ZN17otty_autocomplete6engine6Engine11known_flags17hf02d40176fa4b1ccE+0xd0>
101432fb4: a9402408    	ldp	x8, x9, [x0]
101432fb8: 9100050a    	add	x10, x8, #0x1
101432fbc: f900000a    	str	x10, [x0]
101432fc0: d00071aa    	adrp	x10, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101432fc4: 9116614a    	add	x10, x10, #0x598
101432fc8: ad400540    	ldp	q0, q1, [x10]
101432fcc: ad0007e0    	stp	q0, q1, [sp]
101432fd0: a90227e8    	stp	x8, x9, [sp, #0x20]
101432fd4: f84d8e88    	ldr	x8, [x20, #0xd8]!
101432fd8: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101432fdc: eb09011f    	cmp	x8, x9
101432fe0: 54000200    	b.eq	0x101433020 <__ZN17otty_autocomplete6engine6Engine11known_flags17hf02d40176fa4b1ccE+0xa8>
101432fe4: aa1403e0    	mov	x0, x20
101432fe8: 97ffb411    	bl	0x10142002c <__ZN17otty_autocomplete2db13CompletionsDb11lookup_spec17h895ef0a520e673c6E>
101432fec: aa0003f4    	mov	x20, x0
101432ff0: b4000180    	cbz	x0, 0x101433020 <__ZN17otty_autocomplete6engine6Engine11known_flags17hf02d40176fa4b1ccE+0xa8>
101432ff4: f9001ff4    	str	x20, [sp, #0x38]
101432ff8: 91004280    	add	x0, x20, #0x10
101432ffc: 910003e1    	mov	x1, sp
101433000: 97fffd4a    	bl	0x101432528 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x1c8>
101433004: 92800008    	mov	x8, #-0x1               ; =-1
101433008: f8680288    	ldaddl	x8, x8, [x20]
10143300c: f100051f    	cmp	x8, #0x1
101433010: 54000081    	b.ne	0x101433020 <__ZN17otty_autocomplete6engine6Engine11known_flags17hf02d40176fa4b1ccE+0xa8>
101433014: d50339bf    	dmb	ishld
101433018: 9100e3e0    	add	x0, sp, #0x38
10143301c: 9400e1c5    	bl	0x10146b730 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E>
101433020: ad4007e0    	ldp	q0, q1, [sp]
101433024: ad000660    	stp	q0, q1, [x19]
101433028: 3dc00be0    	ldr	q0, [sp, #0x20]
10143302c: 3d800a60    	str	q0, [x19, #0x20]
101433030: a9477bfd    	ldp	x29, x30, [sp, #0x70]
101433034: a9464ff4    	ldp	x20, x19, [sp, #0x60]
101433038: a94557f6    	ldp	x22, x21, [sp, #0x50]
10143303c: a9445ff8    	ldp	x24, x23, [sp, #0x40]
101433040: 910203ff    	add	sp, sp, #0x80
101433044: d65f03c0    	ret
101433048: aa0203f7    	mov	x23, x2
10143304c: aa0103f5    	mov	x21, x1
101433050: aa0003f6    	mov	x22, x0
101433054: 940e324d    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101433058: aa1703e2    	mov	x2, x23
10143305c: aa0003e8    	mov	x8, x0
101433060: aa1603e0    	mov	x0, x22
101433064: aa0103e9    	mov	x9, x1
101433068: aa1503e1    	mov	x1, x21
10143306c: f90006c9    	str	x9, [x22, #0x8]
101433070: 5280002a    	mov	w10, #0x1               ; =1
101433074: 390042ca    	strb	w10, [x22, #0x10]
101433078: 17ffffd0    	b	0x101432fb8 <__ZN17otty_autocomplete6engine6Engine11known_flags17hf02d40176fa4b1ccE+0x40>
10143307c: aa0003f3    	mov	x19, x0
101433080: 92800008    	mov	x8, #-0x1               ; =-1
101433084: f8680288    	ldaddl	x8, x8, [x20]
101433088: f100051f    	cmp	x8, #0x1
10143308c: 540000e1    	b.ne	0x1014330a8 <__ZN17otty_autocomplete6engine6Engine11known_flags17hf02d40176fa4b1ccE+0x130>
101433090: d50339bf    	dmb	ishld
101433094: 9100e3e0    	add	x0, sp, #0x38
101433098: 9400e1a6    	bl	0x10146b730 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E>
10143309c: 14000003    	b	0x1014330a8 <__ZN17otty_autocomplete6engine6Engine11known_flags17hf02d40176fa4b1ccE+0x130>
1014330a0: 941a4321    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014330a4: aa0003f3    	mov	x19, x0
1014330a8: 910003e0    	mov	x0, sp
1014330ac: 97d4566c    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
1014330b0: aa1303e0    	mov	x0, x19
1014330b4: 941a5948    	bl	0x101ac95d4 <_writev+0x101ac95d4>

00000001014330b8 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E>:
1014330b8: d10603ff    	sub	sp, sp, #0x180
1014330bc: a9126ffc    	stp	x28, x27, [sp, #0x120]
1014330c0: a91367fa    	stp	x26, x25, [sp, #0x130]
1014330c4: a9145ff8    	stp	x24, x23, [sp, #0x140]
1014330c8: a91557f6    	stp	x22, x21, [sp, #0x150]
1014330cc: a9164ff4    	stp	x20, x19, [sp, #0x160]
1014330d0: a9177bfd    	stp	x29, x30, [sp, #0x170]
1014330d4: 9105c3fd    	add	x29, sp, #0x170
1014330d8: aa0603f7    	mov	x23, x6
1014330dc: aa0503f3    	mov	x19, x5
1014330e0: a90513e3    	stp	x3, x4, [sp, #0x50]
1014330e4: a9040be1    	stp	x1, x2, [sp, #0x40]
1014330e8: aa0003fa    	mov	x26, x0
1014330ec: f9001fe8    	str	x8, [sp, #0x38]
1014330f0: d10283a8    	sub	x8, x29, #0xa0
1014330f4: 94001a81    	bl	0x101439af8 <__ZN17otty_autocomplete6engine6Engine19known_command_names17ha82863526f844155E>
1014330f8: a9765bb5    	ldp	x21, x22, [x29, #-0xa0]
1014330fc: f85783a8    	ldur	x8, [x29, #-0x88]
101433100: 8b1606c9    	add	x9, x22, x22, lsl #1
101433104: d37df129    	lsl	x9, x9, #3
101433108: 8b16012a    	add	x10, x9, x22
10143310c: 9100854a    	add	x10, x10, #0x21
101433110: cb0902a9    	sub	x9, x21, x9
101433114: d1006129    	sub	x9, x9, #0x18
101433118: 5280010b    	mov	w11, #0x8               ; =8
10143311c: f10002df    	cmp	x22, #0x0
101433120: 9a8a010a    	csel	x10, x8, x10, eq
101433124: 9a890109    	csel	x9, x8, x9, eq
101433128: f90017e9    	str	x9, [sp, #0x28]
10143312c: 9a8b03e9    	csel	x9, xzr, x11, eq
101433130: f9001be9    	str	x9, [sp, #0x30]
101433134: a9062bf3    	stp	x19, x10, [sp, #0x60]
101433138: b40006a8    	cbz	x8, 0x10143320c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x154>
10143313c: fd4002a0    	ldr	d0, [x21]
101433140: 910022b9    	add	x25, x21, #0x8
101433144: 2e208800    	cmge.8b	v0, v0, #0
101433148: 9e660009    	fmov	x9, d0
10143314c: aa1503fb    	mov	x27, x21
101433150: f201c129    	ands	x9, x9, #0x8080808080808080
101433154: 540000e1    	b.ne	0x101433170 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0xb8>
101433158: fc408720    	ldr	d0, [x25], #0x8
10143315c: 2e208800    	cmge.8b	v0, v0, #0
101433160: 9e660009    	fmov	x9, d0
101433164: d103037b    	sub	x27, x27, #0xc0
101433168: 9201c129    	and	x9, x9, #0x8080808080808080
10143316c: b4ffff69    	cbz	x9, 0x101433158 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0xa0>
101433170: d100052a    	sub	x10, x9, #0x1
101433174: dac0012b    	rbit	x11, x9
101433178: dac0116b    	clz	x11, x11
10143317c: 8a09015c    	and	x28, x10, x9
101433180: cb4b0fe9    	neg	x9, x11, lsr #3
101433184: 5280030a    	mov	w10, #0x18              ; =24
101433188: 9b2a6d29    	smaddl	x9, w9, w10, x27
10143318c: d1000513    	sub	x19, x8, #0x1
101433190: f85e8134    	ldur	x20, [x9, #-0x18]
101433194: d2f0000a    	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
101433198: eb0a029f    	cmp	x20, x10
10143319c: 54000721    	b.ne	0x101433280 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x1c8>
1014331a0: 52800108    	mov	w8, #0x8                ; =8
1014331a4: a90723ff    	stp	xzr, x8, [sp, #0x70]
1014331a8: f90043ff    	str	xzr, [sp, #0x80]
1014331ac: b4000373    	cbz	x19, 0x101433218 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x160>
1014331b0: 52800314    	mov	w20, #0x18              ; =24
1014331b4: 14000005    	b	0x1014331c8 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x110>
1014331b8: d1000788    	sub	x8, x28, #0x1
1014331bc: 8a1c011c    	and	x28, x8, x28
1014331c0: d1000673    	sub	x19, x19, #0x1
1014331c4: b40002b3    	cbz	x19, 0x101433218 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x160>
1014331c8: b50000fc    	cbnz	x28, 0x1014331e4 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x12c>
1014331cc: fc408720    	ldr	d0, [x25], #0x8
1014331d0: 2e208800    	cmge.8b	v0, v0, #0
1014331d4: 9e660008    	fmov	x8, d0
1014331d8: d103037b    	sub	x27, x27, #0xc0
1014331dc: 9201c11c    	and	x28, x8, #0x8080808080808080
1014331e0: b4ffff7c    	cbz	x28, 0x1014331cc <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x114>
1014331e4: dac00388    	rbit	x8, x28
1014331e8: dac01108    	clz	x8, x8
1014331ec: cb480fe8    	neg	x8, x8, lsr #3
1014331f0: 9b346d08    	smaddl	x8, w8, w20, x27
1014331f4: f85e8101    	ldur	x1, [x8, #-0x18]
1014331f8: b4fffe01    	cbz	x1, 0x1014331b8 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x100>
1014331fc: f85f0100    	ldur	x0, [x8, #-0x10]
101433200: 52800022    	mov	w2, #0x1                ; =1
101433204: 97d9ad36    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433208: 17ffffec    	b	0x1014331b8 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x100>
10143320c: 52800108    	mov	w8, #0x8                ; =8
101433210: a90723ff    	stp	xzr, x8, [sp, #0x70]
101433214: f90043ff    	str	xzr, [sp, #0x80]
101433218: f94037e1    	ldr	x1, [sp, #0x68]
10143321c: b4000096    	cbz	x22, 0x10143322c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x174>
101433220: b4000061    	cbz	x1, 0x10143322c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x174>
101433224: a9428be0    	ldp	x0, x2, [sp, #0x28]
101433228: 97d9ad2d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143322c: f84d8f48    	ldr	x8, [x26, #0xd8]!
101433230: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101433234: eb09011f    	cmp	x8, x9
101433238: 54001281    	b.ne	0x101433488 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x3d0>
10143323c: b0007a40    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101433240: 9131a000    	add	x0, x0, #0xc68
101433244: f9400008    	ldr	x8, [x0]
101433248: d63f0100    	blr	x8
10143324c: aa0003f3    	mov	x19, x0
101433250: 39404008    	ldrb	w8, [x0, #0x10]
101433254: 7100051f    	cmp	w8, #0x1
101433258: 54002141    	b.ne	0x101433680 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x5c8>
10143325c: a9400660    	ldp	x0, x1, [x19]
101433260: 91000408    	add	x8, x0, #0x1
101433264: f9000268    	str	x8, [x19]
101433268: b00071a8    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
10143326c: 91166108    	add	x8, x8, #0x598
101433270: ad400500    	ldp	q0, q1, [x8]
101433274: ad0487e0    	stp	q0, q1, [sp, #0x90]
101433278: a90b07e0    	stp	x0, x1, [sp, #0xb0]
10143327c: 14000099    	b	0x1014334e0 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x428>
101433280: f85f012a    	ldur	x10, [x9, #-0x10]
101433284: a901dbea    	stp	x10, x22, [sp, #0x18]
101433288: 5280008a    	mov	w10, #0x4               ; =4
10143328c: f100111f    	cmp	x8, #0x4
101433290: 9a8a8118    	csel	x24, x8, x10, hi
101433294: 8b18070a    	add	x10, x24, x24, lsl #1
101433298: d37df156    	lsl	x22, x10, #3
10143329c: b200f3ea    	mov	x10, #0x5555555555555555 ; =6148914691236517205
1014332a0: f28aaaca    	movk	x10, #0x5556
1014332a4: f2e0aaaa    	movk	x10, #0x555, lsl #48
1014332a8: d100054a    	sub	x10, x10, #0x1
1014332ac: eb0a011f    	cmp	x8, x10
1014332b0: 540000c9    	b.ls	0x1014332c8 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x210>
1014332b4: d2800017    	mov	x23, #0x0               ; =0
1014332b8: aa1703e0    	mov	x0, x23
1014332bc: aa1603e1    	mov	x1, x22
1014332c0: 941a402d    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014332c4: d4200020    	brk	#0x1
1014332c8: f9000bf7    	str	x23, [sp, #0x10]
1014332cc: f85f812a    	ldur	x10, [x9, #-0x8]
1014332d0: b4000156    	cbz	x22, 0x1014332f8 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x240>
1014332d4: f90007ea    	str	x10, [sp, #0x8]
1014332d8: 97d9ad06    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014332dc: 52800117    	mov	w23, #0x8               ; =8
1014332e0: aa1603e0    	mov	x0, x22
1014332e4: 52800101    	mov	w1, #0x8                ; =8
1014332e8: 97d9acfc    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014332ec: b4fffe60    	cbz	x0, 0x1014332b8 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x200>
1014332f0: f94007ea    	ldr	x10, [sp, #0x8]
1014332f4: 14000003    	b	0x101433300 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x248>
1014332f8: d2800018    	mov	x24, #0x0               ; =0
1014332fc: 52800100    	mov	w0, #0x8                ; =8
101433300: a941a3e9    	ldp	x9, x8, [sp, #0x18]
101433304: 8b0802a8    	add	x8, x21, x8
101433308: 91000508    	add	x8, x8, #0x1
10143330c: a9002414    	stp	x20, x9, [x0]
101433310: f900080a    	str	x10, [x0, #0x10]
101433314: a90903f8    	stp	x24, x0, [sp, #0x90]
101433318: 52800029    	mov	w9, #0x1                ; =1
10143331c: f90053e9    	str	x9, [sp, #0xa0]
101433320: f9401bea    	ldr	x10, [sp, #0x30]
101433324: f94037e9    	ldr	x9, [sp, #0x68]
101433328: a93627aa    	stp	x10, x9, [x29, #-0xa0]
10143332c: f94017e9    	ldr	x9, [sp, #0x28]
101433330: a9376fa9    	stp	x9, x27, [x29, #-0x90]
101433334: a93867bc    	stp	x28, x25, [x29, #-0x80]
101433338: a9394fa8    	stp	x8, x19, [x29, #-0x70]
10143333c: b4000893    	cbz	x19, 0x10143344c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x394>
101433340: 52800034    	mov	w20, #0x1               ; =1
101433344: 52800317    	mov	w23, #0x18              ; =24
101433348: d2f0000a    	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
10143334c: 14000009    	b	0x101433370 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x2b8>
101433350: f9404fe0    	ldr	x0, [sp, #0x98]
101433354: d2f0000a    	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
101433358: 9b170288    	madd	x8, x20, x23, x0
10143335c: a9005915    	stp	x21, x22, [x8]
101433360: f9000918    	str	x24, [x8, #0x10]
101433364: 91000694    	add	x20, x20, #0x1
101433368: f90053f4    	str	x20, [sp, #0xa0]
10143336c: b4000713    	cbz	x19, 0x10143344c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x394>
101433370: b50000fc    	cbnz	x28, 0x10143338c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x2d4>
101433374: fc408720    	ldr	d0, [x25], #0x8
101433378: 2e208800    	cmge.8b	v0, v0, #0
10143337c: 9e660008    	fmov	x8, d0
101433380: d103037b    	sub	x27, x27, #0xc0
101433384: 9201c11c    	and	x28, x8, #0x8080808080808080
101433388: b4ffff7c    	cbz	x28, 0x101433374 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x2bc>
10143338c: d1000788    	sub	x8, x28, #0x1
101433390: dac00389    	rbit	x9, x28
101433394: dac01129    	clz	x9, x9
101433398: 8a1c011c    	and	x28, x8, x28
10143339c: cb490fe8    	neg	x8, x9, lsr #3
1014333a0: 9b376d08    	smaddl	x8, w8, w23, x27
1014333a4: d1000673    	sub	x19, x19, #0x1
1014333a8: f85e8115    	ldur	x21, [x8, #-0x18]
1014333ac: eb0a02bf    	cmp	x21, x10
1014333b0: 540001a0    	b.eq	0x1014333e4 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x32c>
1014333b4: a97f6116    	ldp	x22, x24, [x8, #-0x10]
1014333b8: f9404be8    	ldr	x8, [sp, #0x90]
1014333bc: eb08029f    	cmp	x20, x8
1014333c0: 54fffcc1    	b.ne	0x101433358 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x2a0>
1014333c4: b1000668    	adds	x8, x19, #0x1
1014333c8: da9f3102    	csinv	x2, x8, xzr, lo
1014333cc: 910243e0    	add	x0, sp, #0x90
1014333d0: aa1403e1    	mov	x1, x20
1014333d4: 52800103    	mov	w3, #0x8                ; =8
1014333d8: 52800304    	mov	w4, #0x18               ; =24
1014333dc: 9417d51d    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1014333e0: 17ffffdc    	b	0x101433350 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x298>
1014333e4: f81883b9    	stur	x25, [x29, #-0x78]
1014333e8: f81783bb    	stur	x27, [x29, #-0x88]
1014333ec: b4000313    	cbz	x19, 0x10143344c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x394>
1014333f0: 52800314    	mov	w20, #0x18              ; =24
1014333f4: 14000005    	b	0x101433408 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x350>
1014333f8: d1000788    	sub	x8, x28, #0x1
1014333fc: 8a1c011c    	and	x28, x8, x28
101433400: d1000673    	sub	x19, x19, #0x1
101433404: b4000253    	cbz	x19, 0x10143344c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x394>
101433408: b50000fc    	cbnz	x28, 0x101433424 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x36c>
10143340c: fc408720    	ldr	d0, [x25], #0x8
101433410: 2e208800    	cmge.8b	v0, v0, #0
101433414: 9e660008    	fmov	x8, d0
101433418: d103037b    	sub	x27, x27, #0xc0
10143341c: 9201c11c    	and	x28, x8, #0x8080808080808080
101433420: b4ffff7c    	cbz	x28, 0x10143340c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x354>
101433424: dac00388    	rbit	x8, x28
101433428: dac01108    	clz	x8, x8
10143342c: cb480fe8    	neg	x8, x8, lsr #3
101433430: 9b346d08    	smaddl	x8, w8, w20, x27
101433434: f85e8101    	ldur	x1, [x8, #-0x18]
101433438: b4fffe01    	cbz	x1, 0x1014333f8 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x340>
10143343c: f85f0100    	ldur	x0, [x8, #-0x10]
101433440: 52800022    	mov	w2, #0x1                ; =1
101433444: 97d9aca6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433448: 17ffffec    	b	0x1014333f8 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x340>
10143344c: f94037e1    	ldr	x1, [sp, #0x68]
101433450: f94013e8    	ldr	x8, [sp, #0x20]
101433454: b4000088    	cbz	x8, 0x101433464 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x3ac>
101433458: b4000061    	cbz	x1, 0x101433464 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x3ac>
10143345c: a9428be0    	ldp	x0, x2, [sp, #0x28]
101433460: 97d9ac9f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433464: 3dc027e0    	ldr	q0, [sp, #0x90]
101433468: 3d801fe0    	str	q0, [sp, #0x70]
10143346c: f94053e8    	ldr	x8, [sp, #0xa0]
101433470: f90043e8    	str	x8, [sp, #0x80]
101433474: f9400bf7    	ldr	x23, [sp, #0x10]
101433478: f84d8f48    	ldr	x8, [x26, #0xd8]!
10143347c: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101433480: eb09011f    	cmp	x8, x9
101433484: 54ffedc0    	b.eq	0x10143323c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x184>
101433488: a947d7f3    	ldp	x19, x21, [sp, #0x78]
10143348c: b0007a40    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101433490: 9131a000    	add	x0, x0, #0xc68
101433494: f9400008    	ldr	x8, [x0]
101433498: d63f0100    	blr	x8
10143349c: aa0003f4    	mov	x20, x0
1014334a0: 39404008    	ldrb	w8, [x0, #0x10]
1014334a4: 7100051f    	cmp	w8, #0x1
1014334a8: 54000f61    	b.ne	0x101433694 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x5dc>
1014334ac: a9400680    	ldp	x0, x1, [x20]
1014334b0: 91000408    	add	x8, x0, #0x1
1014334b4: f9000288    	str	x8, [x20]
1014334b8: b00071a8    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
1014334bc: 91166108    	add	x8, x8, #0x598
1014334c0: ad400500    	ldp	q0, q1, [x8]
1014334c4: ad3b07a0    	stp	q0, q1, [x29, #-0xa0]
1014334c8: a93807a0    	stp	x0, x1, [x29, #-0x80]
1014334cc: b5000795    	cbnz	x21, 0x1014335bc <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x504>
1014334d0: ad7b07a0    	ldp	q0, q1, [x29, #-0xa0]
1014334d4: ad0487e0    	stp	q0, q1, [sp, #0x90]
1014334d8: 3cd803a0    	ldur	q0, [x29, #-0x80]
1014334dc: 3d802fe0    	str	q0, [sp, #0xb0]
1014334e0: 9101c3e8    	add	x8, sp, #0x70
1014334e4: f81503a8    	stur	x8, [x29, #-0xb0]
1014334e8: 910243e8    	add	x8, sp, #0x90
1014334ec: f81583a8    	stur	x8, [x29, #-0xa8]
1014334f0: d102c3a8    	sub	x8, x29, #0xb0
1014334f4: d00071a9    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
1014334f8: 910d6129    	add	x9, x9, #0x358
1014334fc: a93627a8    	stp	x8, x9, [x29, #-0xa0]
101433500: d102a3a8    	sub	x8, x29, #0xa8
101433504: d00071a9    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101433508: 910e2129    	add	x9, x9, #0x388
10143350c: a93727a8    	stp	x8, x9, [x29, #-0x90]
101433510: f81803bf    	stur	xzr, [x29, #-0x80]
101433514: d10283a0    	sub	x0, x29, #0xa0
101433518: a94387e8    	ldp	x8, x1, [sp, #0x38]
10143351c: a9448fe2    	ldp	x2, x3, [sp, #0x48]
101433520: a94597e4    	ldp	x4, x5, [sp, #0x58]
101433524: aa1703e6    	mov	x6, x23
101433528: 97ffdc67    	bl	0x10142a6c4 <__ZN17otty_autocomplete3fix16CommandFixEngine16suggest_fix_item17h83b35e147ad22653E>
10143352c: f9404ff3    	ldr	x19, [sp, #0x98]
101433530: b4000713    	cbz	x19, 0x101433610 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x558>
101433534: f94057f4    	ldr	x20, [sp, #0xa8]
101433538: b4000594    	cbz	x20, 0x1014335e8 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x530>
10143353c: f9404bf5    	ldr	x21, [sp, #0x90]
101433540: aa1503f6    	mov	x22, x21
101433544: fc4086c0    	ldr	d0, [x22], #0x8
101433548: 2e208800    	cmge.8b	v0, v0, #0
10143354c: 9e660008    	fmov	x8, d0
101433550: 9201c118    	and	x24, x8, #0x8080808080808080
101433554: 52800317    	mov	w23, #0x18              ; =24
101433558: 14000005    	b	0x10143356c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x4b4>
10143355c: d1000708    	sub	x8, x24, #0x1
101433560: 8a180118    	and	x24, x8, x24
101433564: d1000694    	sub	x20, x20, #0x1
101433568: b4000414    	cbz	x20, 0x1014335e8 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x530>
10143356c: b50000f8    	cbnz	x24, 0x101433588 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x4d0>
101433570: fc4086c0    	ldr	d0, [x22], #0x8
101433574: 2e208800    	cmge.8b	v0, v0, #0
101433578: 9e660008    	fmov	x8, d0
10143357c: d10302b5    	sub	x21, x21, #0xc0
101433580: 9201c118    	and	x24, x8, #0x8080808080808080
101433584: b4ffff78    	cbz	x24, 0x101433570 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x4b8>
101433588: dac00308    	rbit	x8, x24
10143358c: dac01108    	clz	x8, x8
101433590: cb480fe8    	neg	x8, x8, lsr #3
101433594: 9b375508    	smaddl	x8, w8, w23, x21
101433598: f85e8101    	ldur	x1, [x8, #-0x18]
10143359c: b4fffe01    	cbz	x1, 0x10143355c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x4a4>
1014335a0: f85f0100    	ldur	x0, [x8, #-0x10]
1014335a4: 52800022    	mov	w2, #0x1                ; =1
1014335a8: 97d9ac4d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014335ac: 17ffffec    	b	0x10143355c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x4a4>
1014335b0: 91006273    	add	x19, x19, #0x18
1014335b4: f10006b5    	subs	x21, x21, #0x1
1014335b8: 54fff8c0    	b.eq	0x1014334d0 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x418>
1014335bc: a9408a61    	ldp	x1, x2, [x19, #0x8]
1014335c0: aa1a03e0    	mov	x0, x26
1014335c4: 97ffcf53    	bl	0x101427310 <__ZN17otty_autocomplete2db13CompletionsDb8has_spec17h2625f531a0989828E>
1014335c8: 34ffff40    	cbz	w0, 0x1014335b0 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x4f8>
1014335cc: 910243e8    	add	x8, sp, #0x90
1014335d0: aa1303e0    	mov	x0, x19
1014335d4: 940f6efe    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1014335d8: d10283a0    	sub	x0, x29, #0xa0
1014335dc: 910243e1    	add	x1, sp, #0x90
1014335e0: 94010d5b    	bl	0x101476b4c <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xee0>
1014335e4: 17fffff3    	b	0x1014335b0 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x4f8>
1014335e8: 8b130668    	add	x8, x19, x19, lsl #1
1014335ec: d37df108    	lsl	x8, x8, #3
1014335f0: 8b130109    	add	x9, x8, x19
1014335f4: b1008521    	adds	x1, x9, #0x21
1014335f8: 540000c0    	b.eq	0x101433610 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x558>
1014335fc: f9404be9    	ldr	x9, [sp, #0x90]
101433600: cb080128    	sub	x8, x9, x8
101433604: d1006100    	sub	x0, x8, #0x18
101433608: 52800102    	mov	w2, #0x8                ; =8
10143360c: 97d9ac34    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433610: a947d3f3    	ldp	x19, x20, [sp, #0x78]
101433614: b4000194    	cbz	x20, 0x101433644 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x58c>
101433618: 91002275    	add	x21, x19, #0x8
10143361c: 14000004    	b	0x10143362c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x574>
101433620: 910062b5    	add	x21, x21, #0x18
101433624: f1000694    	subs	x20, x20, #0x1
101433628: 540000e0    	b.eq	0x101433644 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x58c>
10143362c: f85f82a1    	ldur	x1, [x21, #-0x8]
101433630: b4ffff81    	cbz	x1, 0x101433620 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x568>
101433634: f94002a0    	ldr	x0, [x21]
101433638: 52800022    	mov	w2, #0x1                ; =1
10143363c: 97d9ac28    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433640: 17fffff8    	b	0x101433620 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x568>
101433644: f9403be8    	ldr	x8, [sp, #0x70]
101433648: b40000c8    	cbz	x8, 0x101433660 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x5a8>
10143364c: 8b080508    	add	x8, x8, x8, lsl #1
101433650: d37df101    	lsl	x1, x8, #3
101433654: aa1303e0    	mov	x0, x19
101433658: 52800102    	mov	w2, #0x8                ; =8
10143365c: 97d9ac20    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433660: a9577bfd    	ldp	x29, x30, [sp, #0x170]
101433664: a9564ff4    	ldp	x20, x19, [sp, #0x160]
101433668: a95557f6    	ldp	x22, x21, [sp, #0x150]
10143366c: a9545ff8    	ldp	x24, x23, [sp, #0x140]
101433670: a95367fa    	ldp	x26, x25, [sp, #0x130]
101433674: a9526ffc    	ldp	x28, x27, [sp, #0x120]
101433678: 910603ff    	add	sp, sp, #0x180
10143367c: d65f03c0    	ret
101433680: 940e30c2    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101433684: f9000661    	str	x1, [x19, #0x8]
101433688: 52800028    	mov	w8, #0x1                ; =1
10143368c: 39004268    	strb	w8, [x19, #0x10]
101433690: 17fffef4    	b	0x101433260 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x1a8>
101433694: 940e30bd    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101433698: f9000681    	str	x1, [x20, #0x8]
10143369c: 52800028    	mov	w8, #0x1                ; =1
1014336a0: 39004288    	strb	w8, [x20, #0x10]
1014336a4: 17ffff83    	b	0x1014334b0 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x3f8>
1014336a8: aa0003f7    	mov	x23, x0
1014336ac: 14000014    	b	0x1014336fc <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x644>
1014336b0: aa0003f7    	mov	x23, x0
1014336b4: a937f3bb    	stp	x27, x28, [x29, #-0x88]
1014336b8: f81883b9    	stur	x25, [x29, #-0x78]
1014336bc: f81983b3    	stur	x19, [x29, #-0x68]
1014336c0: b40000b5    	cbz	x21, 0x1014336d4 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x61c>
1014336c4: aa1603e0    	mov	x0, x22
1014336c8: aa1503e1    	mov	x1, x21
1014336cc: 52800022    	mov	w2, #0x1                ; =1
1014336d0: 97d9ac03    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014336d4: d10283a0    	sub	x0, x29, #0xa0
1014336d8: 94008b49    	bl	0x1014563fc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8f74>
1014336dc: 910243e0    	add	x0, sp, #0x90
1014336e0: 14000008    	b	0x101433700 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x648>
1014336e4: aa0003f7    	mov	x23, x0
1014336e8: 910243e0    	add	x0, sp, #0x90
1014336ec: 14000003    	b	0x1014336f8 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x640>
1014336f0: aa0003f7    	mov	x23, x0
1014336f4: d10283a0    	sub	x0, x29, #0xa0
1014336f8: 97d454d9    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
1014336fc: 9101c3e0    	add	x0, sp, #0x70
101433700: 97d43d03    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101433704: aa1703e0    	mov	x0, x23
101433708: 941a57b3    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10143370c: aa0003f7    	mov	x23, x0
101433710: f94013f5    	ldr	x21, [sp, #0x20]
101433714: b40000b4    	cbz	x20, 0x101433728 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x670>
101433718: f9400fe0    	ldr	x0, [sp, #0x18]
10143371c: aa1403e1    	mov	x1, x20
101433720: 52800022    	mov	w2, #0x1                ; =1
101433724: 97d9abee    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433728: b5000113    	cbnz	x19, 0x101433748 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x690>
10143372c: b40000b5    	cbz	x21, 0x101433740 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x688>
101433730: f94037e1    	ldr	x1, [sp, #0x68]
101433734: b4000061    	cbz	x1, 0x101433740 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x688>
101433738: a9428be0    	ldp	x0, x2, [sp, #0x28]
10143373c: 97d9abe8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433740: aa1703e0    	mov	x0, x23
101433744: 941a57a4    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101433748: 52800314    	mov	w20, #0x18              ; =24
10143374c: 14000005    	b	0x101433760 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x6a8>
101433750: d1000788    	sub	x8, x28, #0x1
101433754: 8a1c011c    	and	x28, x8, x28
101433758: d1000673    	sub	x19, x19, #0x1
10143375c: b4fffe93    	cbz	x19, 0x10143372c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x674>
101433760: b50000fc    	cbnz	x28, 0x10143377c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x6c4>
101433764: fc408720    	ldr	d0, [x25], #0x8
101433768: 2e208800    	cmge.8b	v0, v0, #0
10143376c: 9e660008    	fmov	x8, d0
101433770: d103037b    	sub	x27, x27, #0xc0
101433774: 9201c11c    	and	x28, x8, #0x8080808080808080
101433778: b4ffff7c    	cbz	x28, 0x101433764 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x6ac>
10143377c: dac00388    	rbit	x8, x28
101433780: dac01108    	clz	x8, x8
101433784: cb480fe8    	neg	x8, x8, lsr #3
101433788: 9b346d08    	smaddl	x8, w8, w20, x27
10143378c: f85e8101    	ldur	x1, [x8, #-0x18]
101433790: b4fffe01    	cbz	x1, 0x101433750 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x698>
101433794: f85f0100    	ldur	x0, [x8, #-0x10]
101433798: 52800022    	mov	w2, #0x1                ; =1
10143379c: 97d9abd0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014337a0: 17ffffec    	b	0x101433750 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x698>
1014337a4: f9400009    	ldr	x9, [x0]
1014337a8: a9408921    	ldp	x1, x2, [x9, #0x8]
1014337ac: aa0803e0    	mov	x0, x8
1014337b0: 1400e29e    	b	0x10146c228 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xaf8>
1014337b4: 6dba23e9    	stp	d9, d8, [sp, #-0x60]!
1014337b8: a90167fa    	stp	x26, x25, [sp, #0x10]
1014337bc: a9025ff8    	stp	x24, x23, [sp, #0x20]
1014337c0: a90357f6    	stp	x22, x21, [sp, #0x30]
1014337c4: a9044ff4    	stp	x20, x19, [sp, #0x40]
1014337c8: a9057bfd    	stp	x29, x30, [sp, #0x50]
1014337cc: 910143fd    	add	x29, sp, #0x50
1014337d0: f9400017    	ldr	x23, [x0]
1014337d4: f9400ee8    	ldr	x8, [x23, #0x18]
1014337d8: b4000648    	cbz	x8, 0x1014338a0 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x7e8>
1014337dc: aa0203f3    	mov	x19, x2
1014337e0: aa0103f4    	mov	x20, x1
1014337e4: a94206e0    	ldp	x0, x1, [x23, #0x20]
1014337e8: aa1403e2    	mov	x2, x20
1014337ec: aa1303e3    	mov	x3, x19
1014337f0: 97d46793    	bl	0x10094d63c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a614>
1014337f4: d2800015    	mov	x21, #0x0               ; =0
1014337f8: d379fc08    	lsr	x8, x0, #57
1014337fc: a9405af7    	ldp	x23, x22, [x23]
101433800: 0e010d08    	dup.8b	v8, w8
101433804: 6f07e7e1    	movi.2d	v1, #0xffffffffffffffff
101433808: 52800318    	mov	w24, #0x18              ; =24
10143380c: 8a160019    	and	x25, x0, x22
101433810: fc796ae9    	ldr	d9, [x23, x25]
101433814: 2e288d20    	cmeq.8b	v0, v9, v8
101433818: 9e660008    	fmov	x8, d0
10143381c: f201c11a    	ands	x26, x8, #0x8080808080808080
101433820: 54000260    	b.eq	0x10143386c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x7b4>
101433824: dac00348    	rbit	x8, x26
101433828: dac01108    	clz	x8, x8
10143382c: 8b480f28    	add	x8, x25, x8, lsr #3
101433830: 8a160108    	and	x8, x8, x22
101433834: 9b18fd08    	mneg	x8, x8, x24
101433838: 8b0802e8    	add	x8, x23, x8
10143383c: f85f8109    	ldur	x9, [x8, #-0x8]
101433840: eb09027f    	cmp	x19, x9
101433844: 540000c1    	b.ne	0x10143385c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x7a4>
101433848: f85f0101    	ldur	x1, [x8, #-0x10]
10143384c: aa1403e0    	mov	x0, x20
101433850: aa1303e2    	mov	x2, x19
101433854: 941a58f2    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101433858: 34000280    	cbz	w0, 0x1014338a8 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x7f0>
10143385c: d1000748    	sub	x8, x26, #0x1
101433860: ea1a011a    	ands	x26, x8, x26
101433864: 6f07e7e1    	movi.2d	v1, #0xffffffffffffffff
101433868: 54fffde1    	b.ne	0x101433824 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x76c>
10143386c: 2e218d20    	cmeq.8b	v0, v9, v1
101433870: 2e30a800    	umaxv.8b	b0, v0
101433874: 1e260008    	fmov	w8, s0
101433878: 37000148    	tbnz	w8, #0x0, 0x1014338a0 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x7e8>
10143387c: 910022b5    	add	x21, x21, #0x8
101433880: 8b150320    	add	x0, x25, x21
101433884: 8a160019    	and	x25, x0, x22
101433888: fc796ae9    	ldr	d9, [x23, x25]
10143388c: 2e288d20    	cmeq.8b	v0, v9, v8
101433890: 9e660008    	fmov	x8, d0
101433894: f201c11a    	ands	x26, x8, #0x8080808080808080
101433898: 54fffc61    	b.ne	0x101433824 <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x76c>
10143389c: 17fffff4    	b	0x10143386c <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x7b4>
1014338a0: 52800000    	mov	w0, #0x0                ; =0
1014338a4: 14000002    	b	0x1014338ac <__ZN17otty_autocomplete6engine6Engine11suggest_fix17h5b362df68e50c594E+0x7f4>
1014338a8: 52800020    	mov	w0, #0x1                ; =1
1014338ac: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1014338b0: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1014338b4: a94357f6    	ldp	x22, x21, [sp, #0x30]
1014338b8: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1014338bc: a94167fa    	ldp	x26, x25, [sp, #0x10]
1014338c0: 6cc623e9    	ldp	d9, d8, [sp], #0x60
1014338c4: d65f03c0    	ret
