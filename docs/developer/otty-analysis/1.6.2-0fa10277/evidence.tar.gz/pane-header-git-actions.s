1004c616c:     	sub	sp, sp, #0x60
1004c6170:     	stp	x22, x21, [sp, #0x30]
1004c6174:     	stp	x20, x19, [sp, #0x40]
1004c6178:     	stp	x29, x30, [sp, #0x50]
1004c617c:     	add	x29, sp, #0x50
1004c6180:     	ldp	x22, x19, [x20, #0x10]
1004c6184:     	ldr	x21, [x20, #0x20]
1004c6188:     	add	x0, x22, #0x10
1004c618c:     	add	x1, sp, #0x18
1004c6190:     	mov	x2, #0x0                ; =0
1004c6194:     	mov	x3, #0x0                ; =0
1004c6198:     	bl	0x101aca600 ; symbol _swift_beginAccess
1004c619c:     	add	x0, x22, #0x10
1004c61a0:     	bl	0x101acaad4 ; symbol _swift_unknownObjectWeakLoadStrong
1004c61a4:     	cbz	x0, 0x1004c61d0
1004c61a8:     	mov	x20, x0
1004c61ac:     	ldr	x8, [x0]
1004c61b0:     	adrp	x9, 0x1022cf000
1004c61b4:     	ldr	x9, [x9, #0x718]
1004c61b8:     	ldr	x9, [x9]
1004c61bc:     	and	x8, x9, x8
1004c61c0:     	ldr	x8, [x8, #0x248]
1004c61c4:     	blr	x8
1004c61c8:     	mov	x0, x20
1004c61cc:     	bl	0x101ac9d30 ; symbol _objc_release
1004c61d0:     	add	x0, x22, #0x10
1004c61d4:     	mov	x1, sp
1004c61d8:     	mov	x2, #0x0                ; =0
1004c61dc:     	mov	x3, #0x0                ; =0
1004c61e0:     	bl	0x101aca600 ; symbol _swift_beginAccess
1004c61e4:     	add	x0, x22, #0x10
1004c61e8:     	bl	0x101acaad4 ; symbol _swift_unknownObjectWeakLoadStrong
1004c61ec:     	cbz	x0, 0x1004c6214
1004c61f0:     	adrp	x8, 0x10239d000
1004c61f4:     	ldr	x8, [x8, #0x248]
1004c61f8:     	mov	x22, x0
1004c61fc:     	add	x0, x0, x8
1004c6200:     	bl	0x101acab64 ; symbol _swift_weakLoadStrong
1004c6204:     	mov	x20, x0
1004c6208:     	mov	x0, x22
1004c620c:     	bl	0x101ac9d30 ; symbol _objc_release
1004c6210:     	b	0x1004c6218
1004c6214:     	mov	x20, #0x0               ; =0
1004c6218:     	mov	x0, x19
1004c621c:     	mov	x1, x21
1004c6220:     	mov	x2, x20
1004c6224:     	bl	0x100587dc8
1004c6228:     	mov	x0, x20
1004c622c:     	bl	0x101aca960 ; symbol _swift_release
1004c6230:     	ldp	x29, x30, [sp, #0x50]
1004c6234:     	ldp	x20, x19, [sp, #0x40]
1004c6238:     	ldp	x22, x21, [sp, #0x30]
1004c623c:     	add	sp, sp, #0x60
1004c6240:     	ret
1004c6244:     	sub	sp, sp, #0x80
1004c6248:     	stp	x24, x23, [sp, #0x40]
1004c624c:     	stp	x22, x21, [sp, #0x50]
1004c6250:     	stp	x20, x19, [sp, #0x60]
1004c6254:     	stp	x29, x30, [sp, #0x70]
1004c6258:     	add	x29, sp, #0x70
1004c625c:     	ldp	x21, x22, [x20, #0x10]
1004c6260:     	ldr	x19, [x20, #0x20]
1004c6264:     	add	x0, x21, #0x10
1004c6268:     	add	x1, sp, #0x28
1004c626c:     	mov	x2, #0x0                ; =0
1004c6270:     	mov	x3, #0x0                ; =0
1004c6274:     	bl	0x101aca600 ; symbol _swift_beginAccess
1004c6278:     	add	x0, x21, #0x10
1004c627c:     	bl	0x101acaad4 ; symbol _swift_unknownObjectWeakLoadStrong
1004c6280:     	cbz	x0, 0x1004c6368
1004c6284:     	mov	x20, x0
1004c6288:     	ldr	x8, [x0]
1004c628c:     	adrp	x9, 0x1022cf000
1004c6290:     	ldr	x9, [x9, #0x718]
1004c6294:     	ldr	x9, [x9]
1004c6298:     	and	x8, x9, x8
1004c629c:     	ldr	x8, [x8, #0x248]
1004c62a0:     	blr	x8
1004c62a4:     	adrp	x8, 0x101dd9000
1004c62a8:     	add	x8, x8, #0x530 ; possible literal 'Enter the name for the new branch:'
1004c62ac:     	sub	x23, x8, #0x20
1004c62b0:     	adrp	x0, 0x1021dc000
1004c62b4:     	add	x0, x0, #0x20
1004c62b8:     	mov	w1, #0x20               ; =32
1004c62bc:     	mov	w2, #0x7                ; =7
1004c62c0:     	bl	0x101aca588 ; symbol _swift_allocObject
1004c62c4:     	mov	x21, x0
1004c62c8:     	stp	x22, x19, [x0, #0x10]
1004c62cc:     	mov	x0, x19
1004c62d0:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
1004c62d4:     	bl	0x10010d314
1004c62d8:     	mov	x6, x0
1004c62dc:     	mov	x19, x1
1004c62e0:     	adrp	x8, 0x1004c6000
1004c62e4:     	add	x8, x8, #0x5a0
1004c62e8:     	stp	x8, x21, [sp, #0x10]
1004c62ec:     	mov	x8, #-0x1a00000000000000 ; =-1873497444986126336
1004c62f0:     	mov	x9, #0x7243             ; =29251
1004c62f4:     	movk	x9, #0x6165, lsl #16
1004c62f8:     	movk	x9, #0x6574, lsl #32
1004c62fc:     	stp	x9, x8, [sp]
1004c6300:     	mov	x0, #0x7243             ; =29251
1004c6304:     	movk	x0, #0x6165, lsl #16
1004c6308:     	movk	x0, #0x6574, lsl #32
1004c630c:     	movk	x0, #0x4220, lsl #48
1004c6310:     	mov	x1, #0x6172             ; =24946
1004c6314:     	movk	x1, #0x636e, lsl #16
1004c6318:     	movk	x1, #0x68, lsl #32
1004c631c:     	movk	x1, #0xed00, lsl #48
1004c6320:     	mov	x4, #0x7262             ; =29282
1004c6324:     	movk	x4, #0x6e61, lsl #16
1004c6328:     	movk	x4, #0x6863, lsl #32
1004c632c:     	movk	x4, #0x6e2d, lsl #48
1004c6330:     	mov	x5, #0x6d61             ; =28001
1004c6334:     	movk	x5, #0x65, lsl #16
1004c6338:     	movk	x5, #0xeb00, lsl #48
1004c633c:     	orr	x3, x23, #0x8000000000000000
1004c6340:     	mov	x2, #0x22               ; =34
1004c6344:     	movk	x2, #0xd000, lsl #48
1004c6348:     	mov	x7, x19
1004c634c:     	bl	0x100617b58
1004c6350:     	mov	x0, x19
1004c6354:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1004c6358:     	mov	x0, x21
1004c635c:     	bl	0x101aca960 ; symbol _swift_release
1004c6360:     	mov	x0, x20
1004c6364:     	bl	0x101ac9d30 ; symbol _objc_release
1004c6368:     	ldp	x29, x30, [sp, #0x70]
1004c636c:     	ldp	x20, x19, [sp, #0x60]
1004c6370:     	ldp	x22, x21, [sp, #0x50]
1004c6374:     	ldp	x24, x23, [sp, #0x40]
1004c6378:     	add	sp, sp, #0x80
1004c637c:     	ret
1004c6380:     	ldp	x0, x1, [x20, #0x10]
1004c6384:     	b	0x1005882b8
1004c6388:     	adrp	x0, 0x100588000
1004c638c:     	add	x0, x0, #0x770
1004c6390:     	b	0x1004c63ec
1004c6394:     	ldp	x0, x1, [x20, #0x10]
1004c6398:     	b	0x100588a4c
1004c639c:     	adrp	x0, 0x100588000
1004c63a0:     	add	x0, x0, #0xc90
1004c63a4:     	b	0x1004c63ec
1004c63a8:     	stp	x20, x19, [sp, #-0x20]!
1004c63ac:     	stp	x29, x30, [sp, #0x10]
1004c63b0:     	add	x29, sp, #0x10
1004c63b4:     	mov	x19, x0
1004c63b8:     	ldr	x0, [x20, #0x18]
1004c63bc:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1004c63c0:     	ldr	x0, [x20, #0x20]
1004c63c4:     	bl	0x101aca960 ; symbol _swift_release
1004c63c8:     	mov	x0, x20
1004c63cc:     	mov	x1, x19
1004c63d0:     	mov	w2, #0x7                ; =7
1004c63d4:     	ldp	x29, x30, [sp, #0x10]
1004c63d8:     	ldp	x20, x19, [sp], #0x20
1004c63dc:     	b	0x101aca6a8 ; symbol _swift_deallocObject
1004c63e0:     	adrp	x0, 0x100588000
1004c63e4:     	add	x0, x0, #0xf94
1004c63e8:     	b	0x1004c63ec
1004c63ec:     	sub	sp, sp, #0x60
1004c63f0:     	stp	x24, x23, [sp, #0x20]
1004c63f4:     	stp	x22, x21, [sp, #0x30]
1004c63f8:     	stp	x20, x19, [sp, #0x40]
1004c63fc:     	stp	x29, x30, [sp, #0x50]
1004c6400:     	add	x29, sp, #0x50
1004c6404:     	mov	x19, x0
1004c6408:     	ldp	x23, x21, [x20, #0x10]
1004c640c:     	ldr	x20, [x20, #0x20]
1004c6410:     	add	x0, x20, #0x10
1004c6414:     	add	x1, sp, #0x8
1004c6418:     	mov	x2, #0x0                ; =0
1004c641c:     	mov	x3, #0x0                ; =0
1004c6420:     	bl	0x101aca600 ; symbol _swift_beginAccess
1004c6424:     	add	x0, x20, #0x10
1004c6428:     	bl	0x101acaad4 ; symbol _swift_unknownObjectWeakLoadStrong
1004c642c:     	cbz	x0, 0x1004c6454
1004c6430:     	adrp	x8, 0x10239d000
1004c6434:     	ldr	x8, [x8, #0x248]
1004c6438:     	mov	x20, x0
1004c643c:     	add	x0, x0, x8
1004c6440:     	bl	0x101acab64 ; symbol _swift_weakLoadStrong
1004c6444:     	mov	x22, x0
1004c6448:     	mov	x0, x20
1004c644c:     	bl	0x101ac9d30 ; symbol _objc_release
1004c6450:     	b	0x1004c6458
1004c6454:     	mov	x22, #0x0               ; =0
1004c6458:     	mov	x0, x23
1004c645c:     	mov	x1, x21
1004c6460:     	mov	x2, x22
1004c6464:     	blr	x19
1004c6468:     	mov	x0, x22
1004c646c:     	bl	0x101aca960 ; symbol _swift_release
1004c6470:     	ldp	x29, x30, [sp, #0x50]
1004c6474:     	ldp	x20, x19, [sp, #0x40]
1004c6478:     	ldp	x22, x21, [sp, #0x30]
1004c647c:     	ldp	x24, x23, [sp, #0x20]
1004c6480:     	add	sp, sp, #0x60
1004c6484:     	ret
1004c6488:     	stp	x29, x30, [sp, #-0x10]!
1004c648c:     	mov	x29, sp
1004c6490:     	ldr	x0, [x20, #0x18]
1004c6494:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
