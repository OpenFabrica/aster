1004b04b0:	stp	x20, x19, [sp, #-0x20]!
1004b04b4:	stp	x29, x30, [sp, #0x10]
1004b04b8:	add	x29, sp, #0x10
1004b04bc:	mov	x20, x0
1004b04c0:	bl	0x1004b02f4
1004b04c4:	ldp	x29, x30, [sp, #0x10]
1004b04c8:	ldp	x20, x19, [sp], #0x20
1004b04cc:	ret
1004b04d0:	stp	x29, x30, [sp, #-0x10]!
1004b04d4:	mov	x29, sp
1004b04d8:	adrp	x8, 7845 ; 0x102355000
1004b04dc:	ldr	x8, [x8, #0xd0]
1004b04e0:	ldr	x0, [x20, x8]
1004b04e4:	cbz	x0, 0x1004b04ec
1004b04e8:	bl	0x101acf0c0 ; selector isVisible
1004b04ec:	ldp	x29, x30, [sp], #0x10
1004b04f0:	ret
1004b04f4:	stp	d11, d10, [sp, #-0x80]!
1004b04f8:	stp	d9, d8, [sp, #0x10]
1004b04fc:	stp	x28, x27, [sp, #0x20]
1004b0500:	stp	x26, x25, [sp, #0x30]
1004b0504:	stp	x24, x23, [sp, #0x40]
1004b0508:	stp	x22, x21, [sp, #0x50]
1004b050c:	stp	x20, x19, [sp, #0x60]
1004b0510:	stp	x29, x30, [sp, #0x70]
1004b0514:	add	x29, sp, #0x70
1004b0518:	sub	sp, sp, #0x1c0
1004b051c:	mov	x19, sp
1004b0520:	mov	x26, x20
1004b0524:	mov	x22, x2
1004b0528:	mov	x23, x1
1004b052c:	mov	x21, x0
1004b0530:	mov	x0, #0x0
1004b0534:	bl	0x101ac5d88 ; symbol stub for: _$s8Dispatch0A13WorkItemFlagsVMa
1004b0538:	mov	x28, x0
1004b053c:	ldur	x25, [x0, #-0x8]
1004b0540:	ldr	x8, [x25, #0x40]
1004b0544:	mov	x9, x8
1004b0548:	adrp	x16, 7707 ; 0x1022cb000
1004b054c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b0550:	blr	x16
1004b0554:	mov	x9, sp
1004b0558:	add	x8, x8, #0xf
1004b055c:	and	x8, x8, #0xfffffffffffffff0
1004b0560:	sub	x8, x9, x8
1004b0564:	str	x8, [x19, #0x58]
1004b0568:	mov	sp, x8
1004b056c:	mov	x0, #0x0
1004b0570:	bl	0x101ac5dc4 ; symbol stub for: _$s8Dispatch0A3QoSVMa
1004b0574:	ldur	x8, [x0, #-0x8]
1004b0578:	stp	x8, x0, [x19, #0x48]
1004b057c:	ldr	x8, [x8, #0x40]
1004b0580:	mov	x9, x8
1004b0584:	adrp	x16, 7707 ; 0x1022cb000
1004b0588:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b058c:	blr	x16
1004b0590:	mov	x9, sp
1004b0594:	add	x8, x8, #0xf
1004b0598:	and	x8, x8, #0xfffffffffffffff0
1004b059c:	sub	x8, x9, x8
1004b05a0:	str	x8, [x19, #0x40]
1004b05a4:	mov	sp, x8
1004b05a8:	mov	x0, #0x0
1004b05ac:	bl	0x101ac5d94 ; symbol stub for: _$s8Dispatch0A3QoSV0B6SClassOMa
1004b05b0:	ldur	x8, [x0, #-0x8]
1004b05b4:	stp	x8, x0, [x19, #0x30]
1004b05b8:	ldr	x8, [x8, #0x40]
1004b05bc:	mov	x9, x8
1004b05c0:	adrp	x16, 7707 ; 0x1022cb000
1004b05c4:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b05c8:	blr	x16
1004b05cc:	mov	x9, sp
1004b05d0:	add	x8, x8, #0xf
1004b05d4:	and	x8, x8, #0xfffffffffffffff0
1004b05d8:	sub	x8, x9, x8
1004b05dc:	str	x8, [x19, #0x28]
1004b05e0:	mov	sp, x8
1004b05e4:	ldr	x8, [x20]
1004b05e8:	adrp	x24, 7711 ; 0x1022cf000
1004b05ec:	ldr	x24, [x24, #0x718] ; literal pool symbol address: _swift_isaMask
1004b05f0:	ldr	x9, [x24]
1004b05f4:	and	x8, x9, x8
1004b05f8:	ldr	x8, [x8, #0x228]
1004b05fc:	blr	x8
1004b0600:	tbz	w0, #0x0, 0x1004b061c
1004b0604:	ldr	x8, [x26]
1004b0608:	ldr	x9, [x24]
1004b060c:	and	x8, x9, x8
1004b0610:	ldr	x8, [x8, #0x248]
1004b0614:	mov	x20, x26
1004b0618:	blr	x8
1004b061c:	mov	x0, x26
1004b0620:	bl	0x100070cd4
1004b0624:	adrp	x8, 7917 ; 0x10239d000
1004b0628:	ldr	x8, [x8, #0x248]
1004b062c:	add	x0, x26, x8
1004b0630:	mov	x1, x23
1004b0634:	bl	0x101acab28 ; symbol stub for: _swift_weakAssign
1004b0638:	adrp	x8, 7917 ; 0x10239d000
1004b063c:	ldr	x8, [x8, #0x250]
1004b0640:	add	x0, x26, x8
1004b0644:	mov	x1, x22
1004b0648:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004b064c:	mov	x0, x21
1004b0650:	bl	0x101ad6200 ; selector window
1004b0654:	mov	x29, x29
1004b0658:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b065c:	cbz	x0, 0x1004b0af4
1004b0660:	mov	x20, x0
1004b0664:	str	x25, [x19, #0x18]
1004b0668:	mov	x0, x21
1004b066c:	bl	0x101acbde0 ; selector bounds
1004b0670:	mov	x0, x21
1004b0674:	mov	x2, #0x0
1004b0678:	bl	0x101acc9c0 ; selector convertRect:toView:
1004b067c:	str	x20, [x19, #0x20]
1004b0680:	mov	x0, x20
1004b0684:	bl	0x101acca00 ; selector convertRectToScreen:
1004b0688:	mov.16b	v8, v0
1004b068c:	mov.16b	v9, v1
1004b0690:	mov.16b	v10, v2
1004b0694:	mov.16b	v11, v3
1004b0698:	ldr	x8, [x23]
1004b069c:	ldr	x25, [x8, #0x260]
1004b06a0:	mov	x20, x23
1004b06a4:	blr	x25
1004b06a8:	cbz	x0, 0x1004b06d0
1004b06ac:	mov	x20, x0
1004b06b0:	ldr	x8, [x0]
1004b06b4:	ldr	x8, [x8, #0x688]
1004b06b8:	blr	x8
1004b06bc:	mov	x22, x0
1004b06c0:	mov	x21, x1
1004b06c4:	mov	x0, x20
1004b06c8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b06cc:	b	0x1004b06d8
1004b06d0:	mov	x22, #0x0
1004b06d4:	mov	x21, #-0x2000000000000000
1004b06d8:	and	x8, x22, #0xffffffffffff
1004b06dc:	ubfx	x9, x21, #56, #4
1004b06e0:	tst	x21, #0x2000000000000000
1004b06e4:	csel	x8, x8, x9, eq
1004b06e8:	str	x22, [x19, #0x10]
1004b06ec:	cbz	x8, 0x1004b07f4
1004b06f0:	str	x28, [x19, #0x8]
1004b06f4:	mov	x0, x22
1004b06f8:	mov	x1, x21
1004b06fc:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b0700:	mov	x20, x0
1004b0704:	adrp	x28, 7798 ; 0x102326000
1004b0708:	mov	x0, x20
1004b070c:	bl	0x101acf3a0 ; selector length
1004b0710:	cmp	x0, #0x2
1004b0714:	b.lt	0x1004b07fc
1004b0718:	ldr	x0, [x28, #0xa80]
1004b071c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b0720:	bl	0x101accee0 ; selector defaultManager
1004b0724:	mov	x29, x29
1004b0728:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b072c:	mov	x24, x0
1004b0730:	mov	w0, #0x672e
1004b0734:	movk	w0, #0x7469, lsl #16
1004b0738:	mov	x1, #-0x1c00000000000000
1004b073c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b0740:	mov	x27, x0
1004b0744:	mov	x0, x20
1004b0748:	mov	x2, x27
1004b074c:	bl	0x101ad52e0 ; selector stringByAppendingPathComponent:
1004b0750:	mov	x29, x29
1004b0754:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b0758:	mov	x22, x0
1004b075c:	mov	x0, x27
1004b0760:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b0764:	cbnz	x22, 0x1004b0784
1004b0768:	mov	x0, #0x0
1004b076c:	bl	0x101ac625c ; symbol stub for: _$sSS10FoundationE36_unconditionallyBridgeFromObjectiveCySSSo8NSStringCSgFZ
1004b0770:	mov	x27, x1
1004b0774:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b0778:	mov	x22, x0
1004b077c:	mov	x0, x27
1004b0780:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b0784:	mov	x0, x24
1004b0788:	mov	x2, x22
1004b078c:	bl	0x101acd900 ; selector fileExistsAtPath:
1004b0790:	mov	x27, x0
1004b0794:	mov	x0, x22
1004b0798:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b079c:	mov	x0, x24
1004b07a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b07a4:	tbnz	w27, #0x0, 0x1004b0804
1004b07a8:	mov	x0, x20
1004b07ac:	bl	0x101ad5300 ; selector stringByDeletingLastPathComponent
1004b07b0:	mov	x29, x29
1004b07b4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b07b8:	cbz	x0, 0x1004b0b1c
1004b07bc:	mov	x24, x0
1004b07c0:	bl	0x101acf3a0 ; selector length
1004b07c4:	mov	x22, x0
1004b07c8:	mov	x0, x20
1004b07cc:	bl	0x101acf3a0 ; selector length
1004b07d0:	mov	x27, x0
1004b07d4:	mov	x0, x20
1004b07d8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b07dc:	mov	x20, x24
1004b07e0:	cmp	x22, x27
1004b07e4:	b.ne	0x1004b0708
1004b07e8:	mov	w22, #0x0
1004b07ec:	mov	x20, x24
1004b07f0:	b	0x1004b0808
1004b07f4:	mov	w22, #0x0
1004b07f8:	b	0x1004b0814
1004b07fc:	mov	w22, #0x0
1004b0800:	b	0x1004b0808
1004b0804:	mov	w22, #0x1
1004b0808:	mov	x0, x20
1004b080c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b0810:	ldr	x28, [x19, #0x8]
1004b0814:	sub	x24, x29, #0xe0
1004b0818:	mov	x20, x23
1004b081c:	blr	x25
1004b0820:	cbz	x0, 0x1004b0844
1004b0824:	mov	x20, x0
1004b0828:	ldr	x8, [x0]
1004b082c:	ldr	x9, [x8, #0x4e8]
1004b0830:	add	x8, x19, #0xf0
1004b0834:	blr	x9
1004b0838:	mov	x0, x20
1004b083c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b0840:	b	0x1004b0858
1004b0844:	strb	wzr, [x19, #0x140]
1004b0848:	movi.2d	v0, #0000000000000000
1004b084c:	stp	q0, q0, [x19, #0x120]
1004b0850:	stp	q0, q0, [x19, #0x100]
1004b0854:	str	q0, [x19, #0xf0]
1004b0858:	ldp	q0, q1, [x19, #0xf0]
1004b085c:	stur	q0, [x19, #0x9f]
1004b0860:	stur	q1, [x19, #0xaf]
1004b0864:	ldrb	w8, [x19, #0x140]
1004b0868:	strb	w8, [x19, #0xef]
1004b086c:	ldp	q0, q1, [x19, #0x120]
1004b0870:	stur	q1, [x19, #0xdf]
1004b0874:	ldr	q1, [x19, #0x110]
1004b0878:	stur	q0, [x19, #0xcf]
1004b087c:	stur	q1, [x19, #0xbf]
1004b0880:	sturb	w22, [x29, #-0xe0]
1004b0884:	ldur	q0, [x19, #0x98]
1004b0888:	ldur	q1, [x19, #0xa8]
1004b088c:	stur	q1, [x24, #0x11]
1004b0890:	stur	q0, [x24, #0x1]
1004b0894:	ldur	q0, [x19, #0xb8]
1004b0898:	ldur	q1, [x19, #0xc8]
1004b089c:	ldur	q2, [x19, #0xd8]
1004b08a0:	ldr	x8, [x19, #0xe8]
1004b08a4:	stur	x8, [x24, #0x51]
1004b08a8:	stur	q2, [x24, #0x41]
1004b08ac:	stur	q1, [x24, #0x31]
1004b08b0:	stur	q0, [x24, #0x21]
1004b08b4:	sub	x0, x29, #0xe0
1004b08b8:	mov.16b	v0, v8
1004b08bc:	mov.16b	v1, v9
1004b08c0:	mov.16b	v2, v10
1004b08c4:	mov	x20, x26
1004b08c8:	mov.16b	v3, v11
1004b08cc:	bl	0x1004b112c
1004b08d0:	adrp	x1, 7858 ; 0x102362000
1004b08d4:	add	x1, x1, #0xd50
1004b08d8:	adrp	x2, 5701 ; 0x101af5000
1004b08dc:	add	x2, x2, #0xd80
1004b08e0:	add	x0, x19, #0xf0
1004b08e4:	bl	0x10002d870
1004b08e8:	cbz	w22, 0x1004b0ae4
1004b08ec:	adrp	x1, 7824 ; 0x102340000
1004b08f0:	add	x1, x1, #0xc40
1004b08f4:	adrp	x2, 7798 ; 0x102326000
1004b08f8:	add	x2, x2, #0x9d8 ; Objc class ref: _OBJC_CLASS_$_OS_dispatch_queue
1004b08fc:	mov	x0, #0x0
1004b0900:	bl	0x10002d97c
1004b0904:	mov	x20, x0
1004b0908:	adrp	x8, 7711 ; 0x1022cf000
1004b090c:	ldr	x8, [x8, #0x950] ; literal pool symbol address: _$s8Dispatch0A3QoSV0B6SClassO13userInitiatedyA2EmFWC
1004b0910:	ldr	w1, [x8]
1004b0914:	ldp	x25, x24, [x19, #0x28]
1004b0918:	ldr	x8, [x24, #0x68]
1004b091c:	mov	x0, x25
1004b0920:	ldr	x22, [x19, #0x38]
1004b0924:	mov	x2, x22
1004b0928:	blr	x8
1004b092c:	mov	x0, x25
1004b0930:	bl	0x101ac6e80 ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE6global3qosAbC0D3QoSV0G6SClassO_tFZ
1004b0934:	mov	x23, x0
1004b0938:	ldr	x8, [x24, #0x8]
1004b093c:	mov	x0, x25
1004b0940:	mov	x1, x22
1004b0944:	blr	x8
1004b0948:	adrp	x0, 7466 ; 0x1021da000
1004b094c:	add	x0, x0, #0x978
1004b0950:	mov	w1, #0x18
1004b0954:	mov	w2, #0x7
1004b0958:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b095c:	mov	x27, x0
1004b0960:	add	x0, x0, #0x10
1004b0964:	mov	x1, x26
1004b0968:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b096c:	adrp	x0, 7466 ; 0x1021da000
1004b0970:	add	x0, x0, #0x9a0
1004b0974:	mov	w1, #0x48
1004b0978:	mov	w2, #0x7
1004b097c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b0980:	ldr	x8, [x19, #0x10]
1004b0984:	stp	x8, x21, [x0, #0x10]
1004b0988:	str	x27, [x0, #0x20]
1004b098c:	stp	d8, d9, [x0, #0x28]
1004b0990:	stp	d10, d11, [x0, #0x38]
1004b0994:	adrp	x8, 1 ; 0x1004b1000
1004b0998:	add	x8, x8, #0x804
1004b099c:	stp	x8, x0, [x19, #0x88]
1004b09a0:	adrp	x8, 7707 ; 0x1022cb000
1004b09a4:	ldr	x8, [x8, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1004b09a8:	str	x8, [x19, #0x68]
1004b09ac:	adrp	x8, 5681 ; 0x101ae1000
1004b09b0:	ldr	d0, [x8]
1004b09b4:	str	d0, [x19, #0x70]
1004b09b8:	adrp	x8, -1196 ; 0x100004000
1004b09bc:	add	x8, x8, #0xd0
1004b09c0:	adrp	x9, 7466 ; 0x1021da000
1004b09c4:	add	x9, x9, #0x9b8
1004b09c8:	stp	x8, x9, [x19, #0x78]
1004b09cc:	add	x0, x19, #0x68
1004b09d0:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004b09d4:	mov	x21, x0
1004b09d8:	mov	x0, x27
1004b09dc:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b09e0:	ldr	x25, [x19, #0x40]
1004b09e4:	mov	x8, x25
1004b09e8:	bl	0x101ac5da0 ; symbol stub for: _$s8Dispatch0A3QoSV11unspecifiedACvgZ
1004b09ec:	adrp	x8, 7711 ; 0x1022cf000
1004b09f0:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004b09f4:	str	x8, [x19, #0x60]
1004b09f8:	adrp	x0, 7826 ; 0x102342000
1004b09fc:	add	x0, x0, #0x2e0
1004b0a00:	adrp	x1, 7711 ; 0x1022cf000
1004b0a04:	ldr	x1, [x1, #0x930] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVMa
1004b0a08:	adrp	x2, 7711 ; 0x1022cf000
1004b0a0c:	ldr	x2, [x2, #0x940] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVs10SetAlgebraAAMc
1004b0a10:	bl	0x10002c7c4
1004b0a14:	mov	x22, x0
1004b0a18:	adrp	x20, 7824 ; 0x102340000
1004b0a1c:	add	x20, x20, #0xc50
1004b0a20:	adrp	x24, 5681 ; 0x101ae1000
1004b0a24:	add	x24, x24, #0x280
1004b0a28:	mov	x0, x20
1004b0a2c:	mov	x1, x24
1004b0a30:	bl	0x100003c4c
1004b0a34:	mov	x26, x0
1004b0a38:	adrp	x0, 7826 ; 0x102342000
1004b0a3c:	add	x0, x0, #0x2f0
1004b0a40:	adrp	x3, 7710 ; 0x1022ce000
1004b0a44:	ldr	x3, [x3, #0x238] ; literal pool symbol address: _$sSayxGSTsMc
1004b0a48:	mov	x1, x20
1004b0a4c:	mov	x2, x24
1004b0a50:	bl	0x10002b714
1004b0a54:	mov	x2, x0
1004b0a58:	add	x0, x19, #0x60
1004b0a5c:	ldr	x24, [x19, #0x58]
1004b0a60:	mov	x8, x24
1004b0a64:	mov	x1, x26
1004b0a68:	mov	x20, x28
1004b0a6c:	mov	x3, x28
1004b0a70:	mov	x4, x22
1004b0a74:	bl	0x101ac7450 ; symbol stub for: _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
1004b0a78:	mov	x0, #0x0
1004b0a7c:	mov	x1, x25
1004b0a80:	mov	x2, x24
1004b0a84:	mov	x3, x21
1004b0a88:	mov	x20, x23
1004b0a8c:	bl	0x101ac6e5c ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE5async5group3qos5flags7executeySo0a1_b1_F0CSg_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
1004b0a90:	mov	x0, x21
1004b0a94:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004b0a98:	mov	x0, x23
1004b0a9c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b0aa0:	ldr	x8, [x19, #0x18]
1004b0aa4:	ldr	x8, [x8, #0x8]
1004b0aa8:	mov	x0, x24
1004b0aac:	mov	x1, x28
1004b0ab0:	blr	x8
1004b0ab4:	ldp	x8, x1, [x19, #0x48]
1004b0ab8:	ldr	x8, [x8, #0x8]
1004b0abc:	mov	x0, x25
1004b0ac0:	blr	x8
1004b0ac4:	ldr	x20, [x19, #0x90]
1004b0ac8:	mov	x0, x27
1004b0acc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b0ad0:	ldr	x0, [x19, #0x20]
1004b0ad4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b0ad8:	mov	x0, x20
1004b0adc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b0ae0:	b	0x1004b0af4
1004b0ae4:	ldr	x0, [x19, #0x20]
1004b0ae8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b0aec:	mov	x0, x21
1004b0af0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b0af4:	sub	sp, x29, #0x70
1004b0af8:	ldp	x29, x30, [sp, #0x70]
1004b0afc:	ldp	x20, x19, [sp, #0x60]
1004b0b00:	ldp	x22, x21, [sp, #0x50]
1004b0b04:	ldp	x24, x23, [sp, #0x40]
1004b0b08:	ldp	x26, x25, [sp, #0x30]
1004b0b0c:	ldp	x28, x27, [sp, #0x20]
1004b0b10:	ldp	d9, d8, [sp, #0x10]
1004b0b14:	ldp	d11, d10, [sp], #0x80
1004b0b18:	ret
1004b0b1c:	brk	#0x1
1004b0b20:	stp	d11, d10, [sp, #-0x80]!
1004b0b24:	stp	d9, d8, [sp, #0x10]
1004b0b28:	stp	x28, x27, [sp, #0x20]
1004b0b2c:	stp	x26, x25, [sp, #0x30]
1004b0b30:	stp	x24, x23, [sp, #0x40]
1004b0b34:	stp	x22, x21, [sp, #0x50]
1004b0b38:	stp	x20, x19, [sp, #0x60]
1004b0b3c:	stp	x29, x30, [sp, #0x70]
1004b0b40:	add	x29, sp, #0x70
1004b0b44:	sub	sp, sp, #0x180
1004b0b48:	mov	x19, sp
1004b0b4c:	mov.16b	v8, v3
1004b0b50:	mov.16b	v9, v2
1004b0b54:	mov.16b	v10, v1
1004b0b58:	mov.16b	v11, v0
1004b0b5c:	mov	x25, x2
1004b0b60:	mov	x20, x1
1004b0b64:	mov	x26, x0
1004b0b68:	mov	x0, #0x0
1004b0b6c:	bl	0x101ac5d88 ; symbol stub for: _$s8Dispatch0A13WorkItemFlagsVMa
1004b0b70:	mov	x21, x0
1004b0b74:	ldur	x23, [x0, #-0x8]
1004b0b78:	ldr	x8, [x23, #0x40]
1004b0b7c:	mov	x9, x8
1004b0b80:	adrp	x16, 7707 ; 0x1022cb000
1004b0b84:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b0b88:	blr	x16
1004b0b8c:	mov	x9, sp
1004b0b90:	add	x8, x8, #0xf
1004b0b94:	and	x8, x8, #0xfffffffffffffff0
1004b0b98:	sub	x22, x9, x8
1004b0b9c:	mov	sp, x22
1004b0ba0:	mov	x0, #0x0
1004b0ba4:	bl	0x101ac5dc4 ; symbol stub for: _$s8Dispatch0A3QoSVMa
1004b0ba8:	mov	x28, x0
1004b0bac:	ldur	x8, [x0, #-0x8]
1004b0bb0:	str	x8, [x19, #0x10]
1004b0bb4:	ldr	x8, [x8, #0x40]
1004b0bb8:	mov	x9, x8
1004b0bbc:	adrp	x16, 7707 ; 0x1022cb000
1004b0bc0:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b0bc4:	blr	x16
1004b0bc8:	mov	x9, sp
1004b0bcc:	add	x8, x8, #0xf
1004b0bd0:	and	x8, x8, #0xfffffffffffffff0
1004b0bd4:	sub	x24, x9, x8
1004b0bd8:	mov	sp, x24
1004b0bdc:	add	x8, x19, #0xc8
1004b0be0:	mov	x0, x26
1004b0be4:	mov	x1, x20
1004b0be8:	bl	0x100582020
1004b0bec:	ldr	x27, [x19, #0xd0]
1004b0bf0:	cbz	x27, 0x1004b0e28
1004b0bf4:	stp	x23, x28, [x19]
1004b0bf8:	add	x23, x19, #0x70
1004b0bfc:	ldr	x28, [x19, #0xc8]
1004b0c00:	ldur	q0, [x19, #0xe8]
1004b0c04:	ldur	q1, [x19, #0xf8]
1004b0c08:	add	x8, x19, #0x9
1004b0c0c:	ldur	q2, [x8, #0xff]
1004b0c10:	stp	q1, q2, [x23, #0xd0]
1004b0c14:	ldrb	w8, [x19, #0x118]
1004b0c18:	sturb	w8, [x29, #-0x90]
1004b0c1c:	stur	q0, [x19, #0x97]
1004b0c20:	ldur	q3, [x19, #0xd8]
1004b0c24:	ldur	q4, [x19, #0xc8]
1004b0c28:	stp	q3, q0, [x23, #0xb0]
1004b0c2c:	stur	q1, [x23, #0x37]
1004b0c30:	stur	q2, [x23, #0x47]
1004b0c34:	strb	w8, [x19, #0xc7]
1004b0c38:	stur	q4, [x19, #0x77]
1004b0c3c:	stur	q3, [x19, #0x87]
1004b0c40:	adrp	x1, 7824 ; 0x102340000
1004b0c44:	add	x1, x1, #0xc40
1004b0c48:	adrp	x2, 7798 ; 0x102326000
1004b0c4c:	add	x2, x2, #0x9d8 ; Objc class ref: _OBJC_CLASS_$_OS_dispatch_queue
1004b0c50:	mov	x0, #0x0
1004b0c54:	bl	0x10002d97c
1004b0c58:	mov	x20, x0
1004b0c5c:	adrp	x2, 7858 ; 0x102362000
1004b0c60:	add	x2, x2, #0xd50
1004b0c64:	adrp	x3, 5701 ; 0x101af5000
1004b0c68:	add	x3, x3, #0xd80
1004b0c6c:	add	x0, x19, #0xc8
1004b0c70:	add	x1, x19, #0x18
1004b0c74:	bl	0x10002d8f4
1004b0c78:	bl	0x101ac6e44 ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE4mainABvgZ
1004b0c7c:	mov	x26, x0
1004b0c80:	adrp	x0, 7468 ; 0x1021dc000
1004b0c84:	add	x0, x0, #0x5e8
1004b0c88:	mov	w1, #0xf0
1004b0c8c:	mov	w2, #0x7
1004b0c90:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b0c94:	stp	x25, x28, [x0, #0x10]
1004b0c98:	str	x27, [x0, #0x20]
1004b0c9c:	ldp	q1, q0, [x23, #0xb0]
1004b0ca0:	stur	q0, [x0, #0x38]
1004b0ca4:	ldp	q0, q2, [x23, #0xd0]
1004b0ca8:	stur	q0, [x0, #0x48]
1004b0cac:	stur	q2, [x0, #0x58]
1004b0cb0:	ldurb	w8, [x29, #-0x90]
1004b0cb4:	strb	w8, [x0, #0x68]
1004b0cb8:	stur	q1, [x0, #0x28]
1004b0cbc:	mov	w8, #0x1
1004b0cc0:	strb	w8, [x0, #0x70]
1004b0cc4:	ldp	q0, q1, [x19, #0x70]
1004b0cc8:	stur	q0, [x0, #0x71]
1004b0ccc:	stur	q1, [x0, #0x81]
1004b0cd0:	ldr	q0, [x19, #0x90]
1004b0cd4:	ldp	q1, q2, [x23, #0x30]
1004b0cd8:	ldr	x8, [x19, #0xc0]
1004b0cdc:	stur	x8, [x0, #0xc1]
1004b0ce0:	stur	q2, [x0, #0xb1]
1004b0ce4:	stur	q1, [x0, #0xa1]
1004b0ce8:	stur	q0, [x0, #0x91]
1004b0cec:	stp	d11, d10, [x0, #0xd0]
1004b0cf0:	stp	d9, d8, [x0, #0xe0]
1004b0cf4:	adrp	x8, 23 ; 0x1004c7000
1004b0cf8:	add	x8, x8, #0x440
1004b0cfc:	stp	x8, x0, [x19, #0x38]
1004b0d00:	adrp	x8, 7707 ; 0x1022cb000
1004b0d04:	ldr	x8, [x8, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1004b0d08:	str	x8, [x19, #0x18]
1004b0d0c:	adrp	x8, 5681 ; 0x101ae1000
1004b0d10:	ldr	d0, [x8]
1004b0d14:	str	d0, [x19, #0x20]
1004b0d18:	adrp	x8, -1196 ; 0x100004000
1004b0d1c:	add	x8, x8, #0xd0
1004b0d20:	adrp	x9, 7468 ; 0x1021dc000
1004b0d24:	add	x9, x9, #0x600
1004b0d28:	stp	x8, x9, [x19, #0x28]
1004b0d2c:	add	x0, x19, #0x18
1004b0d30:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004b0d34:	mov	x27, x0
1004b0d38:	ldr	x20, [x19, #0x40]
1004b0d3c:	mov	x0, x25
1004b0d40:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b0d44:	mov	x0, x20
1004b0d48:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b0d4c:	mov	x8, x24
1004b0d50:	bl	0x101ac5da0 ; symbol stub for: _$s8Dispatch0A3QoSV11unspecifiedACvgZ
1004b0d54:	adrp	x8, 7711 ; 0x1022cf000
1004b0d58:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004b0d5c:	str	x8, [x19, #0x18]
1004b0d60:	adrp	x0, 7826 ; 0x102342000
1004b0d64:	add	x0, x0, #0x2e0
1004b0d68:	adrp	x1, 7711 ; 0x1022cf000
1004b0d6c:	ldr	x1, [x1, #0x930] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVMa
1004b0d70:	adrp	x2, 7711 ; 0x1022cf000
1004b0d74:	ldr	x2, [x2, #0x940] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVs10SetAlgebraAAMc
1004b0d78:	bl	0x10002c7c4
1004b0d7c:	mov	x25, x0
1004b0d80:	adrp	x20, 7824 ; 0x102340000
1004b0d84:	add	x20, x20, #0xc50
1004b0d88:	adrp	x28, 5681 ; 0x101ae1000
1004b0d8c:	add	x28, x28, #0x280
1004b0d90:	mov	x0, x20
1004b0d94:	mov	x1, x28
1004b0d98:	bl	0x100003c4c
1004b0d9c:	mov	x23, x0
1004b0da0:	adrp	x0, 7826 ; 0x102342000
1004b0da4:	add	x0, x0, #0x2f0
1004b0da8:	adrp	x3, 7710 ; 0x1022ce000
1004b0dac:	ldr	x3, [x3, #0x238] ; literal pool symbol address: _$sSayxGSTsMc
1004b0db0:	mov	x1, x20
1004b0db4:	mov	x2, x28
1004b0db8:	bl	0x10002b714
1004b0dbc:	mov	x2, x0
1004b0dc0:	add	x0, x19, #0x18
1004b0dc4:	mov	x8, x22
1004b0dc8:	mov	x1, x23
1004b0dcc:	mov	x20, x21
1004b0dd0:	mov	x3, x21
1004b0dd4:	mov	x4, x25
1004b0dd8:	bl	0x101ac7450 ; symbol stub for: _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
1004b0ddc:	mov	x0, #0x0
1004b0de0:	mov	x1, x24
1004b0de4:	mov	x2, x22
1004b0de8:	mov	x3, x27
1004b0dec:	mov	x20, x26
1004b0df0:	bl	0x101ac6e5c ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE5async5group3qos5flags7executeySo0a1_b1_F0CSg_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
1004b0df4:	mov	x0, x27
1004b0df8:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004b0dfc:	mov	x0, x26
1004b0e00:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b0e04:	ldr	x8, [x19]
1004b0e08:	ldr	x8, [x8, #0x8]
1004b0e0c:	mov	x0, x22
1004b0e10:	mov	x1, x21
1004b0e14:	blr	x8
1004b0e18:	ldp	x1, x8, [x19, #0x8]
1004b0e1c:	ldr	x8, [x8, #0x8]
1004b0e20:	mov	x0, x24
1004b0e24:	blr	x8
1004b0e28:	sub	sp, x29, #0x70
1004b0e2c:	ldp	x29, x30, [sp, #0x70]
1004b0e30:	ldp	x20, x19, [sp, #0x60]
1004b0e34:	ldp	x22, x21, [sp, #0x50]
1004b0e38:	ldp	x24, x23, [sp, #0x40]
1004b0e3c:	ldp	x26, x25, [sp, #0x30]
1004b0e40:	ldp	x28, x27, [sp, #0x20]
1004b0e44:	ldp	d9, d8, [sp, #0x10]
1004b0e48:	ldp	d11, d10, [sp], #0x80
1004b0e4c:	ret
1004b0e50:	sub	sp, sp, #0xb0
1004b0e54:	stp	d13, d12, [sp, #0x20]
1004b0e58:	stp	d11, d10, [sp, #0x30]
1004b0e5c:	stp	d9, d8, [sp, #0x40]
1004b0e60:	stp	x28, x27, [sp, #0x50]
1004b0e64:	stp	x26, x25, [sp, #0x60]
1004b0e68:	stp	x24, x23, [sp, #0x70]
1004b0e6c:	stp	x22, x21, [sp, #0x80]
1004b0e70:	stp	x20, x19, [sp, #0x90]
1004b0e74:	stp	x29, x30, [sp, #0xa0]
1004b0e78:	add	x29, sp, #0xa0
1004b0e7c:	adrp	x8, 7845 ; 0x102355000
1004b0e80:	ldr	x8, [x8, #0xd0]
1004b0e84:	ldr	x19, [x20, x8]
1004b0e88:	cbz	x19, 0x1004b1100
1004b0e8c:	mov	x21, x20
1004b0e90:	mov.16b	v8, v3
1004b0e94:	mov.16b	v9, v2
1004b0e98:	mov.16b	v10, v1
1004b0e9c:	mov.16b	v11, v0
1004b0ea0:	mov	x22, x0
1004b0ea4:	mov	x0, #0x0
1004b0ea8:	bl	0x1004ad03c
1004b0eac:	mov	x20, x0
1004b0eb0:	mov	x0, x19
1004b0eb4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b0eb8:	mov	x19, x0
1004b0ebc:	bl	0x1004a9cc4
1004b0ec0:	adrp	x8, 7917 ; 0x10239d000
1004b0ec4:	ldr	x20, [x8, #0x270]
1004b0ec8:	add	x0, x21, x20
1004b0ecc:	add	x1, sp, #0x8
1004b0ed0:	mov	w2, #0x1
1004b0ed4:	mov	x3, #0x0
1004b0ed8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b0edc:	ldr	x0, [x21, x20]
1004b0ee0:	adrp	x8, 7711 ; 0x1022cf000
1004b0ee4:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004b0ee8:	str	x8, [x21, x20]
1004b0eec:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b0ef0:	adrp	x8, 7917 ; 0x10239d000
1004b0ef4:	ldr	x8, [x8, #0x278]
1004b0ef8:	mov	x9, #-0x1
1004b0efc:	str	x9, [x21, x8]
1004b0f00:	mov	x0, x22
1004b0f04:	mov	x20, x21
1004b0f08:	bl	0x1004b1e10
1004b0f0c:	mov	x20, x0
1004b0f10:	bl	0x101acdcc0 ; selector frame
1004b0f14:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004b0f18:	mov.16b	v12, v0
1004b0f1c:	adrp	x8, 7845 ; 0x102355000
1004b0f20:	ldr	x8, [x8, #0xe0]
1004b0f24:	add	x0, x21, x8
1004b0f28:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004b0f2c:	cbz	x0, 0x1004b1048
1004b0f30:	mov	x21, x0
1004b0f34:	bl	0x101ad5540 ; selector subviews
1004b0f38:	mov	x29, x29
1004b0f3c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b0f40:	mov	x23, x0
1004b0f44:	adrp	x1, 7824 ; 0x102340000
1004b0f48:	add	x1, x1, #0xcd0
1004b0f4c:	adrp	x2, 7798 ; 0x102326000
1004b0f50:	add	x2, x2, #0xa40 ; Objc class ref: _OBJC_CLASS_$_NSView
1004b0f54:	mov	x0, #0x0
1004b0f58:	bl	0x10002d97c
1004b0f5c:	mov	x1, x0
1004b0f60:	mov	x0, x23
1004b0f64:	bl	0x101ac676c ; symbol stub for: _$sSa10FoundationE36_unconditionallyBridgeFromObjectiveCySayxGSo7NSArrayCSgFZ
1004b0f68:	mov	x22, x0
1004b0f6c:	mov	x0, x23
1004b0f70:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b0f74:	lsr	x8, x22, #62
1004b0f78:	cbnz	x8, 0x1004b0ff4
1004b0f7c:	and	x8, x22, #0xffffffffffffff8
1004b0f80:	ldr	x23, [x8, #0x10]
1004b0f84:	cbz	x23, 0x1004b100c
1004b0f88:	mov	x24, #0x0
1004b0f8c:	and	x26, x22, #0xc000000000000001
1004b0f90:	and	x27, x22, #0xffffffffffffff8
1004b0f94:	cbnz	x26, 0x1004b0fd8
1004b0f98:	ldr	x8, [x27, #0x10]
1004b0f9c:	cmp	x24, x8
1004b0fa0:	b.hs	0x1004b0ff0
1004b0fa4:	add	x8, x22, x24, lsl #3
1004b0fa8:	ldr	x0, [x8, #0x20]
1004b0fac:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b0fb0:	adds	x28, x24, #0x1
1004b0fb4:	b.vs	0x1004b0fec
1004b0fb8:	mov	x25, x0
1004b0fbc:	bl	0x101ad0a80 ; selector removeFromSuperview
1004b0fc0:	mov	x0, x25
1004b0fc4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b0fc8:	add	x24, x24, #0x1
1004b0fcc:	cmp	x28, x23
1004b0fd0:	b.ne	0x1004b0f94
1004b0fd4:	b	0x1004b100c
1004b0fd8:	mov	x0, x24
1004b0fdc:	mov	x1, x22
1004b0fe0:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004b0fe4:	adds	x28, x24, #0x1
1004b0fe8:	b.vc	0x1004b0fb8
1004b0fec:	brk	#0x1
1004b0ff0:	brk	#0x1
1004b0ff4:	and	x8, x22, #0xffffffffffffff8
1004b0ff8:	cmn	x22, #0x1
1004b0ffc:	csel	x0, x8, x22, gt
1004b1000:	bl	0x101ac7900 ; symbol stub for: _$ss18_CocoaArrayWrapperV8endIndexSivg
1004b1004:	mov	x23, x0
1004b1008:	cbnz	x23, 0x1004b0f88
1004b100c:	mov	x0, x22
1004b1010:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b1014:	mov	x0, x21
1004b1018:	mov	x2, x20
1004b101c:	bl	0x101acb460 ; selector addSubview:
1004b1020:	mov	x8, #0x800000000000
1004b1024:	movk	x8, #0x4071, lsl #48
1004b1028:	fmov	d2, x8
1004b102c:	movi.2d	v0, #0000000000000000
1004b1030:	movi.2d	v1, #0000000000000000
1004b1034:	mov	x0, x20
1004b1038:	mov.16b	v3, v12
1004b103c:	bl	0x101ad2b80 ; selector setFrame:
1004b1040:	mov	x0, x21
1004b1044:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1048:	mov	x0, x19
1004b104c:	bl	0x101acc7a0 ; selector contentView
1004b1050:	mov	x29, x29
1004b1054:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b1058:	cbz	x0, 0x1004b1088
1004b105c:	mov	x21, x0
1004b1060:	bl	_$s16CodeEditTextView0C13LayoutManagerC12maxLineWidth12CoreGraphics7CGFloatVvpfi
1004b1064:	fadd	d0, d0, d0
1004b1068:	fadd	d13, d12, d0
1004b106c:	mov	x0, x21
1004b1070:	bl	0x101acdcc0 ; selector frame
1004b1074:	mov	x0, x21
1004b1078:	mov.16b	v3, v13
1004b107c:	bl	0x101ad2b80 ; selector setFrame:
1004b1080:	mov	x0, x21
1004b1084:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1088:	mov.16b	v0, v11
1004b108c:	mov.16b	v1, v10
1004b1090:	mov.16b	v2, v9
1004b1094:	mov.16b	v3, v8
1004b1098:	bl	0x101ac8d88 ; symbol stub for: _CGRectGetMidX
1004b109c:	mov	x8, #0x800000000000
1004b10a0:	movk	x8, #0xc061, lsl #48
1004b10a4:	fmov	d1, x8
1004b10a8:	fadd	d13, d0, d1
1004b10ac:	mov.16b	v0, v11
1004b10b0:	mov.16b	v1, v10
1004b10b4:	mov.16b	v2, v9
1004b10b8:	mov.16b	v3, v8
1004b10bc:	bl	0x101ac8dac ; symbol stub for: _CGRectGetMinY
1004b10c0:	fsub	d0, d0, d12
1004b10c4:	fmov	d1, #-4.00000000
1004b10c8:	fadd	d1, d0, d1
1004b10cc:	mov	x8, #0x800000000000
1004b10d0:	movk	x8, #0x4071, lsl #48
1004b10d4:	fmov	d2, x8
1004b10d8:	mov.16b	v0, v13
1004b10dc:	mov.16b	v3, v12
1004b10e0:	bl	0x1004ad2a8
1004b10e4:	mov	x0, x19
1004b10e8:	mov	w2, #0x1
1004b10ec:	bl	0x101ad2ba0 ; selector setFrame:display:
1004b10f0:	mov	x0, x19
1004b10f4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b10f8:	mov	x0, x20
1004b10fc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1100:	ldp	x29, x30, [sp, #0xa0]
1004b1104:	ldp	x20, x19, [sp, #0x90]
1004b1108:	ldp	x22, x21, [sp, #0x80]
1004b110c:	ldp	x24, x23, [sp, #0x70]
1004b1110:	ldp	x26, x25, [sp, #0x60]
1004b1114:	ldp	x28, x27, [sp, #0x50]
1004b1118:	ldp	d9, d8, [sp, #0x40]
1004b111c:	ldp	d11, d10, [sp, #0x30]
1004b1120:	ldp	d13, d12, [sp, #0x20]
1004b1124:	add	sp, sp, #0xb0
1004b1128:	ret
1004b112c:	stp	d15, d14, [sp, #-0xa0]!
1004b1130:	stp	d13, d12, [sp, #0x10]
1004b1134:	stp	d11, d10, [sp, #0x20]
1004b1138:	stp	d9, d8, [sp, #0x30]
1004b113c:	stp	x28, x27, [sp, #0x40]
1004b1140:	stp	x26, x25, [sp, #0x50]
1004b1144:	stp	x24, x23, [sp, #0x60]
1004b1148:	stp	x22, x21, [sp, #0x70]
1004b114c:	stp	x20, x19, [sp, #0x80]
1004b1150:	stp	x29, x30, [sp, #0x90]
1004b1154:	add	x29, sp, #0x90
1004b1158:	sub	sp, sp, #0x80
1004b115c:	mov	x19, x20
1004b1160:	mov.16b	v8, v3
1004b1164:	mov.16b	v9, v2
1004b1168:	mov.16b	v10, v1
1004b116c:	mov.16b	v11, v0
1004b1170:	mov	x20, x0
1004b1174:	adrp	x0, 7824 ; 0x102341000
1004b1178:	add	x0, x0, #0x790
1004b117c:	adrp	x1, 5680 ; 0x101ae1000
1004b1180:	add	x1, x1, #0xd90
1004b1184:	bl	0x100003c4c
1004b1188:	ldur	x8, [x0, #-0x8]
1004b118c:	ldr	x9, [x8, #0x40]
1004b1190:	add	x8, x9, #0xf
1004b1194:	and	x8, x8, #0xfffffffffffffff0
1004b1198:	adrp	x16, 7706 ; 0x1022cb000
1004b119c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b11a0:	blr	x16
1004b11a4:	mov	x9, sp
1004b11a8:	sub	x25, x9, x8
1004b11ac:	mov	sp, x25
1004b11b0:	adrp	x8, 7916 ; 0x10239d000
1004b11b4:	ldr	x22, [x8, #0x248]
1004b11b8:	add	x0, x19, x22
1004b11bc:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b11c0:	cbz	x0, 0x1004b17a8
1004b11c4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b11c8:	bl	0x1004bf550
1004b11cc:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004b11d0:	mov	x8, #0x800000000000
1004b11d4:	movk	x8, #0x4071, lsl #48
1004b11d8:	fmov	d12, x8
1004b11dc:	mov	x8, #0x4059000000000000
1004b11e0:	fmov	d3, x8
1004b11e4:	movi.2d	v0, #0000000000000000
1004b11e8:	movi.2d	v1, #0000000000000000
1004b11ec:	mov.16b	v2, v12
1004b11f0:	mov	x2, #0x0
1004b11f4:	mov	w3, #0x2
1004b11f8:	mov	w4, #0x0
1004b11fc:	bl	0x101ace420 ; selector initWithContentRect:styleMask:backing:defer:
1004b1200:	mov	x21, x0
1004b1204:	adrp	x8, 7844 ; 0x102355000
1004b1208:	ldr	x8, [x8, #0xd8]
1004b120c:	add	x0, x0, x8
1004b1210:	mov	x1, x19
1004b1214:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004b1218:	mov	x0, x21
1004b121c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b1220:	mov	x24, x0
1004b1224:	mov	x2, x19
1004b1228:	bl	0x101ad2600 ; selector setDelegate:
1004b122c:	mov	w23, #0x1
1004b1230:	mov	x0, x24
1004b1234:	mov	w2, #0x1
1004b1238:	bl	0x101ad2a60 ; selector setFloatingPanel:
1004b123c:	mov	x0, x24
1004b1240:	mov	w2, #0x65
1004b1244:	bl	0x101ad3320 ; selector setLevel:
1004b1248:	mov	x0, x24
1004b124c:	mov	w2, #0x0
1004b1250:	bl	0x101ad3980 ; selector setOpaque:
1004b1254:	adrp	x8, 7797 ; 0x102326000
1004b1258:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004b125c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b1260:	bl	0x101acc200 ; selector clearColor
1004b1264:	mov	x29, x29
1004b1268:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b126c:	mov	x21, x0
1004b1270:	mov	x0, x24
1004b1274:	mov	x2, x21
1004b1278:	bl	0x101ad1e00 ; selector setBackgroundColor:
1004b127c:	mov	x0, x21
1004b1280:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1284:	mov	x0, x24
1004b1288:	mov	w2, #0x0
1004b128c:	bl	0x101ad3760 ; selector setMovableByWindowBackground:
1004b1290:	bl	_$s9TextStory09BufferingA7StorageC16bufferingEnabledSbvpfi
1004b1294:	bic	w2, w23, w0
1004b1298:	mov	x0, x24
1004b129c:	bl	0x101ad2d20 ; selector setHasShadow:
1004b12a0:	mov	x0, x20
1004b12a4:	mov	x20, x19
1004b12a8:	bl	0x1004b1e10
1004b12ac:	mov	x20, x0
1004b12b0:	bl	0x101acdcc0 ; selector frame
1004b12b4:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004b12b8:	mov.16b	v13, v0
1004b12bc:	fmov	d2, #8.00000000
1004b12c0:	mov.16b	v0, v12
1004b12c4:	mov.16b	v1, v13
1004b12c8:	bl	0x1004ad2c4
1004b12cc:	mov	x23, x0
1004b12d0:	mov	x21, x1
1004b12d4:	mov	x0, x1
1004b12d8:	mov	x2, x20
1004b12dc:	bl	0x101acb460 ; selector addSubview:
1004b12e0:	movi.2d	v0, #0000000000000000
1004b12e4:	movi.2d	v1, #0000000000000000
1004b12e8:	stur	x20, [x29, #-0xf0]
1004b12ec:	mov	x0, x20
1004b12f0:	mov.16b	v2, v12
1004b12f4:	mov.16b	v3, v13
1004b12f8:	bl	0x101ad2b80 ; selector setFrame:
1004b12fc:	mov	x0, x24
1004b1300:	stur	x23, [x29, #-0x100]
1004b1304:	mov	x2, x23
1004b1308:	bl	0x101ad2340 ; selector setContentView:
1004b130c:	mov	x0, x24
1004b1310:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1314:	adrp	x8, 7844 ; 0x102355000
1004b1318:	ldr	x8, [x8, #0xe0]
1004b131c:	add	x0, x19, x8
1004b1320:	stur	x21, [x29, #-0xf8]
1004b1324:	mov	x1, x21
1004b1328:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004b132c:	mov.16b	v0, v11
1004b1330:	mov.16b	v1, v10
1004b1334:	mov.16b	v2, v9
1004b1338:	mov.16b	v3, v8
1004b133c:	bl	0x101ac8d88 ; symbol stub for: _CGRectGetMidX
1004b1340:	mov	x8, #0x800000000000
1004b1344:	movk	x8, #0xc061, lsl #48
1004b1348:	fmov	d1, x8
1004b134c:	fadd	d14, d0, d1
1004b1350:	mov.16b	v0, v11
1004b1354:	mov.16b	v1, v10
1004b1358:	mov.16b	v2, v9
1004b135c:	mov.16b	v3, v8
1004b1360:	bl	0x101ac8dac ; symbol stub for: _CGRectGetMinY
1004b1364:	fsub	d0, d0, d13
1004b1368:	fmov	d1, #-4.00000000
1004b136c:	fadd	d1, d0, d1
1004b1370:	mov.16b	v0, v14
1004b1374:	mov.16b	v2, v12
1004b1378:	mov.16b	v3, v13
1004b137c:	bl	0x1004ad2a8
1004b1380:	mov	x0, x24
1004b1384:	mov	w2, #0x1
1004b1388:	bl	0x101ad2ba0 ; selector setFrame:display:
1004b138c:	mov	x0, x24
1004b1390:	mov	x2, #0x0
1004b1394:	bl	0x101acf700 ; selector makeKeyAndOrderFront:
1004b1398:	adrp	x8, 7844 ; 0x102355000
1004b139c:	ldr	x8, [x8, #0xd0]
1004b13a0:	ldr	x20, [x19, x8]
1004b13a4:	str	x24, [x19, x8]
1004b13a8:	mov	x0, x24
1004b13ac:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b13b0:	sub	x8, x29, #0x8
1004b13b4:	stur	x0, [x8, #-0x100]
1004b13b8:	mov	x0, x20
1004b13bc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b13c0:	mov	x8, x25
1004b13c4:	bl	0x101ac4fcc ; symbol stub for: _$s10Foundation4DateVACycfC
1004b13c8:	mov	x0, #0x0
1004b13cc:	bl	0x101ac4fd8 ; symbol stub for: _$s10Foundation4DateVMa
1004b13d0:	mov	x3, x0
1004b13d4:	ldur	x8, [x0, #-0x8]
1004b13d8:	ldr	x8, [x8, #0x38]
1004b13dc:	mov	x0, x25
1004b13e0:	mov	w1, #0x0
1004b13e4:	mov	w2, #0x1
1004b13e8:	blr	x8
1004b13ec:	adrp	x8, 7916 ; 0x10239d000
1004b13f0:	ldr	x20, [x8, #0x288]
1004b13f4:	add	x0, x19, x20
1004b13f8:	sub	x1, x29, #0xd0
1004b13fc:	mov	w2, #0x21
1004b1400:	mov	x3, #0x0
1004b1404:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b1408:	adrp	x2, 7824 ; 0x102341000
1004b140c:	add	x2, x2, #0x790
1004b1410:	adrp	x3, 5680 ; 0x101ae1000
1004b1414:	add	x3, x3, #0xd90
1004b1418:	add	x1, x19, x20
1004b141c:	mov	x0, x25
1004b1420:	bl	0x1004c75a8
1004b1424:	sub	x0, x29, #0xd0
1004b1428:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b142c:	add	x0, x19, x22
1004b1430:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b1434:	cbz	x0, 0x1004b145c
1004b1438:	ldr	x8, [x0]
1004b143c:	ldr	x8, [x8, #0x260]
1004b1440:	mov	x20, x0
1004b1444:	mov	x24, x0
1004b1448:	blr	x8
1004b144c:	mov	x20, x0
1004b1450:	mov	x0, x24
1004b1454:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b1458:	b	0x1004b1460
1004b145c:	mov	x20, #0x0
1004b1460:	adrp	x8, 7916 ; 0x10239d000
1004b1464:	ldr	x8, [x8, #0x280]
1004b1468:	add	x0, x19, x8
1004b146c:	mov	x1, x20
1004b1470:	bl	0x101acab28 ; symbol stub for: _swift_weakAssign
1004b1474:	mov	x0, x20
1004b1478:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b147c:	adrp	x8, 7797 ; 0x102326000
1004b1480:	ldr	x0, [x8, #0xb00] ; Objc class ref: _OBJC_CLASS_$_NSEvent
1004b1484:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b1488:	mov	x20, x0
1004b148c:	adrp	x0, 7465 ; 0x1021da000
1004b1490:	add	x0, x0, #0x978
1004b1494:	mov	w1, #0x18
1004b1498:	mov	w2, #0x7
1004b149c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b14a0:	mov	x24, x0
1004b14a4:	add	x0, x0, #0x10
1004b14a8:	mov	x1, x19
1004b14ac:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b14b0:	adrp	x8, 22 ; 0x1004c7000
1004b14b4:	add	x8, x8, #0x5f0
1004b14b8:	stp	x8, x24, [x29, #-0xb0]
1004b14bc:	adrp	x21, 7706 ; 0x1022cb000
1004b14c0:	ldr	x21, [x21, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1004b14c4:	stur	x21, [x29, #-0xd0]
1004b14c8:	adrp	x8, 5680 ; 0x101ae1000
1004b14cc:	ldr	d8, [x8]
1004b14d0:	stur	d8, [x29, #-0xc8]
1004b14d4:	adrp	x8, -1090 ; 0x10006f000
1004b14d8:	add	x8, x8, #0xb24
1004b14dc:	adrp	x9, 7467 ; 0x1021dc000
1004b14e0:	add	x9, x9, #0x628
1004b14e4:	stp	x8, x9, [x29, #-0xc0]
1004b14e8:	sub	x0, x29, #0xd0
1004b14ec:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004b14f0:	mov	x24, x0
1004b14f4:	ldur	x0, [x29, #-0xa8]
1004b14f8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b14fc:	mov	x0, x20
1004b1500:	mov	w2, #0xa
1004b1504:	mov	x3, x24
1004b1508:	bl	0x101acb360 ; selector addLocalMonitorForEventsMatchingMask:handler:
1004b150c:	mov	x29, x29
1004b1510:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b1514:	mov	x20, x0
1004b1518:	mov	x0, x24
1004b151c:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004b1520:	cbz	x20, 0x1004b153c
1004b1524:	sub	x8, x29, #0xd0
1004b1528:	mov	x0, x20
1004b152c:	bl	0x101ac7390 ; symbol stub for: _$ss018_bridgeAnyObjectToB0yypyXlSgF
1004b1530:	mov	x0, x20
1004b1534:	bl	0x101acaa68 ; symbol stub for: _swift_unknownObjectRelease
1004b1538:	b	0x1004b1544
1004b153c:	movi.2d	v0, #0000000000000000
1004b1540:	stp	q0, q0, [x29, #-0xd0]
1004b1544:	adrp	x8, 7916 ; 0x10239d000
1004b1548:	ldr	x20, [x8, #0x258]
1004b154c:	add	x0, x19, x20
1004b1550:	sub	x1, x29, #0xe8
1004b1554:	mov	w2, #0x21
1004b1558:	mov	x3, #0x0
1004b155c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b1560:	adrp	x2, 7823 ; 0x102340000
1004b1564:	add	x2, x2, #0xc30
1004b1568:	adrp	x3, 5680 ; 0x101ae1000
1004b156c:	add	x3, x3, #0x100
1004b1570:	sub	x0, x29, #0xd0
1004b1574:	add	x1, x19, x20
1004b1578:	bl	0x1004c75a8
1004b157c:	sub	x0, x29, #0xe8
1004b1580:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b1584:	adrp	x8, 7797 ; 0x102326000
1004b1588:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004b158c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b1590:	mov	x20, x0
1004b1594:	bl	0x101acce80 ; selector defaultCenter
1004b1598:	mov	x29, x29
1004b159c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b15a0:	mov	x27, x0
1004b15a4:	bl	0x10006e7b4
1004b15a8:	ldr	x24, [x0]
1004b15ac:	adrp	x8, 7797 ; 0x102326000
1004b15b0:	ldr	x0, [x8, #0xa08] ; Objc class ref: _OBJC_CLASS_$_NSOperationQueue
1004b15b4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b15b8:	mov	x25, x0
1004b15bc:	mov	x0, x24
1004b15c0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b15c4:	mov	x28, x0
1004b15c8:	mov	x0, x25
1004b15cc:	bl	0x101acf660 ; selector mainQueue
1004b15d0:	mov	x29, x29
1004b15d4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b15d8:	mov	x24, x0
1004b15dc:	adrp	x26, 7465 ; 0x1021da000
1004b15e0:	add	x26, x26, #0x978
1004b15e4:	mov	x0, x26
1004b15e8:	mov	w1, #0x18
1004b15ec:	mov	w2, #0x7
1004b15f0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b15f4:	mov	x23, x0
1004b15f8:	add	x0, x0, #0x10
1004b15fc:	mov	x1, x19
1004b1600:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b1604:	adrp	x8, 22 ; 0x1004c7000
1004b1608:	add	x8, x8, #0x61c
1004b160c:	stp	x8, x23, [x29, #-0xb0]
1004b1610:	stur	x21, [x29, #-0xd0]
1004b1614:	stur	d8, [x29, #-0xc8]
1004b1618:	adrp	x21, -1192 ; 0x100009000
1004b161c:	add	x21, x21, #0x69c
1004b1620:	adrp	x8, 7467 ; 0x1021dc000
1004b1624:	add	x8, x8, #0x650
1004b1628:	stp	x21, x8, [x29, #-0xc0]
1004b162c:	sub	x0, x29, #0xd0
1004b1630:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004b1634:	mov	x23, x0
1004b1638:	ldur	x0, [x29, #-0xa8]
1004b163c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b1640:	mov	x0, x27
1004b1644:	mov	x2, x28
1004b1648:	mov	x3, #0x0
1004b164c:	mov	x4, x24
1004b1650:	mov	x5, x23
1004b1654:	bl	0x101acb3e0 ; selector addObserverForName:object:queue:usingBlock:
1004b1658:	mov	x29, x29
1004b165c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b1660:	mov	x22, x0
1004b1664:	mov	x0, x23
1004b1668:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004b166c:	mov	x0, x27
1004b1670:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1674:	mov	x0, x28
1004b1678:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b167c:	mov	x0, x24
1004b1680:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1684:	adrp	x8, 7916 ; 0x10239d000
1004b1688:	ldr	x8, [x8, #0x260]
1004b168c:	ldr	x0, [x19, x8]
1004b1690:	str	x22, [x19, x8]
1004b1694:	bl	0x101acaa68 ; symbol stub for: _swift_unknownObjectRelease
1004b1698:	mov	x0, x20
1004b169c:	bl	0x101acce80 ; selector defaultCenter
1004b16a0:	mov	x29, x29
1004b16a4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b16a8:	mov	x20, x0
1004b16ac:	bl	0x10006e844
1004b16b0:	ldr	x0, [x0]
1004b16b4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b16b8:	mov	x27, x0
1004b16bc:	mov	x0, x25
1004b16c0:	bl	0x101acf660 ; selector mainQueue
1004b16c4:	mov	x29, x29
1004b16c8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b16cc:	mov	x25, x0
1004b16d0:	mov	x0, x26
1004b16d4:	mov	w1, #0x18
1004b16d8:	mov	w2, #0x7
1004b16dc:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b16e0:	mov	x22, x0
1004b16e4:	add	x0, x0, #0x10
1004b16e8:	mov	x1, x19
1004b16ec:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b16f0:	adrp	x8, 22 ; 0x1004c7000
1004b16f4:	add	x8, x8, #0x684
1004b16f8:	stp	x8, x22, [x29, #-0xb0]
1004b16fc:	adrp	x8, 7706 ; 0x1022cb000
1004b1700:	ldr	x8, [x8, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1004b1704:	stur	x8, [x29, #-0xd0]
1004b1708:	stur	d8, [x29, #-0xc8]
1004b170c:	adrp	x8, 7467 ; 0x1021dc000
1004b1710:	add	x8, x8, #0x678
1004b1714:	stp	x21, x8, [x29, #-0xc0]
1004b1718:	sub	x0, x29, #0xd0
1004b171c:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004b1720:	mov	x22, x0
1004b1724:	ldur	x0, [x29, #-0xa8]
1004b1728:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b172c:	mov	x0, x20
1004b1730:	mov	x2, x27
1004b1734:	mov	x3, #0x0
1004b1738:	mov	x4, x25
1004b173c:	mov	x5, x22
1004b1740:	bl	0x101acb3e0 ; selector addObserverForName:object:queue:usingBlock:
1004b1744:	mov	x29, x29
1004b1748:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b174c:	mov	x23, x0
1004b1750:	sub	x8, x29, #0x8
1004b1754:	ldur	x0, [x8, #-0x100]
1004b1758:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b175c:	ldur	x0, [x29, #-0x100]
1004b1760:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1764:	ldur	x0, [x29, #-0xf8]
1004b1768:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b176c:	ldur	x0, [x29, #-0xf0]
1004b1770:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1774:	mov	x0, x22
1004b1778:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004b177c:	mov	x0, x20
1004b1780:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1784:	mov	x0, x27
1004b1788:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b178c:	mov	x0, x25
1004b1790:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1794:	adrp	x8, 7916 ; 0x10239d000
1004b1798:	ldr	x8, [x8, #0x268]
1004b179c:	ldr	x0, [x19, x8]
1004b17a0:	str	x23, [x19, x8]
1004b17a4:	bl	0x101acaa68 ; symbol stub for: _swift_unknownObjectRelease
1004b17a8:	sub	sp, x29, #0x90
1004b17ac:	ldp	x29, x30, [sp, #0x90]
1004b17b0:	ldp	x20, x19, [sp, #0x80]
1004b17b4:	ldp	x22, x21, [sp, #0x70]
1004b17b8:	ldp	x24, x23, [sp, #0x60]
1004b17bc:	ldp	x26, x25, [sp, #0x50]
1004b17c0:	ldp	x28, x27, [sp, #0x40]
1004b17c4:	ldp	d9, d8, [sp, #0x30]
1004b17c8:	ldp	d11, d10, [sp, #0x20]
1004b17cc:	ldp	d13, d12, [sp, #0x10]
1004b17d0:	ldp	d15, d14, [sp], #0xa0
1004b17d4:	ret
1004b17d8:	stp	x29, x30, [sp, #-0x10]!
1004b17dc:	mov	x29, sp
1004b17e0:	add	x0, x20, #0x10
1004b17e4:	bl	0x101acaabc ; symbol stub for: _swift_unknownObjectWeakDestroy
1004b17e8:	mov	x0, x20
1004b17ec:	mov	w1, #0x18
1004b17f0:	mov	w2, #0x7
1004b17f4:	ldp	x29, x30, [sp], #0x10
1004b17f8:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004b17fc:	mov	w0, #0x48
1004b1800:	b	0x1004c63a8
1004b1804:	ldp	x0, x1, [x20, #0x10]
1004b1808:	ldr	x2, [x20, #0x20]
1004b180c:	ldp	d0, d1, [x20, #0x28]
1004b1810:	ldp	d2, d3, [x20, #0x38]
1004b1814:	b	0x1004b0b20
1004b1818:	ldr	x8, [x1, #0x28]
1004b181c:	ldr	q0, [x1, #0x20]
1004b1820:	str	q0, [x0, #0x20]
1004b1824:	mov	x0, x8
1004b1828:	b	0x101aca978 ; symbol stub for: _swift_retain
1004b182c:	ldr	x0, [x0, #0x28]
1004b1830:	b	0x101aca960 ; symbol stub for: _swift_release
1004b1834:	sub	sp, sp, #0xb0
1004b1838:	stp	x24, x23, [sp, #0x70]
1004b183c:	stp	x22, x21, [sp, #0x80]
1004b1840:	stp	x20, x19, [sp, #0x90]
1004b1844:	stp	x29, x30, [sp, #0xa0]
1004b1848:	add	x29, sp, #0xa0
1004b184c:	mov	x19, x20
1004b1850:	adrp	x8, 7916 ; 0x10239d000
1004b1854:	ldr	x22, [x8, #0x258]
1004b1858:	add	x0, x20, x22
1004b185c:	add	x1, sp, #0x18
1004b1860:	mov	x2, #0x0
1004b1864:	mov	x3, #0x0
1004b1868:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b186c:	adrp	x2, 7823 ; 0x102340000
1004b1870:	add	x2, x2, #0xc30
1004b1874:	adrp	x3, 5680 ; 0x101ae1000
1004b1878:	add	x3, x3, #0x100
1004b187c:	add	x0, x20, x22
1004b1880:	add	x1, sp, #0x30
1004b1884:	bl	0x10002d8f4
1004b1888:	ldr	x8, [sp, #0x48]
1004b188c:	cbz	x8, 0x1004b1928
1004b1890:	add	x0, sp, #0x30
1004b1894:	add	x1, sp, #0x50
1004b1898:	bl	0x10002b0a0
1004b189c:	adrp	x8, 7797 ; 0x102326000
1004b18a0:	ldr	x0, [x8, #0xb00] ; Objc class ref: _OBJC_CLASS_$_NSEvent
1004b18a4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b18a8:	mov	x20, x0
1004b18ac:	ldr	x21, [sp, #0x68]
1004b18b0:	add	x0, sp, #0x50
1004b18b4:	mov	x1, x21
1004b18b8:	bl	0x10002d8b0
1004b18bc:	mov	x1, x21
1004b18c0:	bl	0x101ac7c84 ; symbol stub for: _$ss27_bridgeAnythingToObjectiveCyyXlxlF
1004b18c4:	mov	x21, x0
1004b18c8:	mov	x0, x20
1004b18cc:	mov	x2, x21
1004b18d0:	bl	0x101ad0b40 ; selector removeMonitor:
1004b18d4:	mov	x0, x21
1004b18d8:	bl	0x101acaa68 ; symbol stub for: _swift_unknownObjectRelease
1004b18dc:	movi.2d	v0, #0000000000000000
1004b18e0:	stp	q0, q0, [sp, #0x30]
1004b18e4:	add	x0, x19, x22
1004b18e8:	mov	x1, sp
1004b18ec:	mov	w2, #0x21
1004b18f0:	mov	x3, #0x0
1004b18f4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b18f8:	adrp	x2, 7823 ; 0x102340000
1004b18fc:	add	x2, x2, #0xc30
1004b1900:	adrp	x3, 5680 ; 0x101ae1000
1004b1904:	add	x3, x3, #0x100
1004b1908:	add	x0, sp, #0x30
1004b190c:	add	x1, x19, x22
1004b1910:	bl	0x1004c75a8
1004b1914:	mov	x0, sp
1004b1918:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b191c:	add	x0, sp, #0x50
1004b1920:	bl	0x10002d8d4
1004b1924:	b	0x1004b1940
1004b1928:	adrp	x1, 7823 ; 0x102340000
1004b192c:	add	x1, x1, #0xc30
1004b1930:	adrp	x2, 5680 ; 0x101ae1000
1004b1934:	add	x2, x2, #0x100
1004b1938:	add	x0, sp, #0x30
1004b193c:	bl	0x10002d870
1004b1940:	adrp	x8, 7916 ; 0x10239d000
1004b1944:	ldr	x23, [x8, #0x260]
1004b1948:	ldr	x20, [x19, x23]
1004b194c:	adrp	x22, 7797 ; 0x102326000
1004b1950:	cbz	x20, 0x1004b199c
1004b1954:	ldr	x0, [x22, #0xa00]
1004b1958:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b195c:	mov	x21, x0
1004b1960:	mov	x0, x20
1004b1964:	bl	0x101acaa80 ; symbol stub for: _swift_unknownObjectRetain
1004b1968:	mov	x0, x21
1004b196c:	bl	0x101acce80 ; selector defaultCenter
1004b1970:	mov	x29, x29
1004b1974:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b1978:	mov	x21, x0
1004b197c:	mov	x2, x20
1004b1980:	bl	0x101ad0ba0 ; selector removeObserver:
1004b1984:	mov	x0, x20
1004b1988:	bl	0x101acaa68 ; symbol stub for: _swift_unknownObjectRelease
1004b198c:	mov	x0, x21
1004b1990:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1994:	ldr	x0, [x19, x23]
1004b1998:	b	0x1004b19a0
1004b199c:	mov	x0, #0x0
1004b19a0:	str	xzr, [x19, x23]
1004b19a4:	bl	0x101acaa68 ; symbol stub for: _swift_unknownObjectRelease
1004b19a8:	adrp	x8, 7916 ; 0x10239d000
1004b19ac:	ldr	x23, [x8, #0x268]
1004b19b0:	ldr	x20, [x19, x23]
1004b19b4:	cbz	x20, 0x1004b1a00
1004b19b8:	ldr	x0, [x22, #0xa00]
1004b19bc:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b19c0:	mov	x21, x0
1004b19c4:	mov	x0, x20
1004b19c8:	bl	0x101acaa80 ; symbol stub for: _swift_unknownObjectRetain
1004b19cc:	mov	x0, x21
1004b19d0:	bl	0x101acce80 ; selector defaultCenter
1004b19d4:	mov	x29, x29
1004b19d8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b19dc:	mov	x21, x0
1004b19e0:	mov	x2, x20
1004b19e4:	bl	0x101ad0ba0 ; selector removeObserver:
1004b19e8:	mov	x0, x20
1004b19ec:	bl	0x101acaa68 ; symbol stub for: _swift_unknownObjectRelease
1004b19f0:	mov	x0, x21
1004b19f4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b19f8:	ldr	x0, [x19, x23]
1004b19fc:	b	0x1004b1a04
1004b1a00:	mov	x0, #0x0
1004b1a04:	str	xzr, [x19, x23]
1004b1a08:	bl	0x101acaa68 ; symbol stub for: _swift_unknownObjectRelease
1004b1a0c:	mov	x0, #0x0
1004b1a10:	bl	0x1004ad03c
1004b1a14:	mov	x20, x0
1004b1a18:	bl	0x1004a9cc4
1004b1a1c:	adrp	x8, 7916 ; 0x10239d000
1004b1a20:	ldr	x23, [x8, #0x250]
1004b1a24:	add	x0, x19, x23
1004b1a28:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004b1a2c:	cbz	x0, 0x1004b1a80
1004b1a30:	ldr	x8, [x0]
1004b1a34:	adrp	x24, 7710 ; 0x1022cf000
1004b1a38:	ldr	x24, [x24, #0x718] ; literal pool symbol address: _swift_isaMask
1004b1a3c:	ldr	x9, [x24]
1004b1a40:	and	x8, x9, x8
1004b1a44:	ldr	x8, [x8, #0x428]
1004b1a48:	mov	x20, x0
1004b1a4c:	mov	x21, x0
1004b1a50:	blr	x8
1004b1a54:	mov	x20, x0
1004b1a58:	mov	x0, x21
1004b1a5c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1a60:	cbz	x20, 0x1004b1a80
1004b1a64:	ldr	x8, [x20]
1004b1a68:	ldr	x9, [x24]
1004b1a6c:	and	x8, x9, x8
1004b1a70:	ldr	x8, [x8, #0x1d8]
1004b1a74:	blr	x8
1004b1a78:	mov	x0, x20
1004b1a7c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1a80:	adrp	x8, 7844 ; 0x102355000
1004b1a84:	ldr	x20, [x8, #0xd0]
1004b1a88:	ldr	x0, [x19, x20]
1004b1a8c:	cbz	x0, 0x1004b1ac0
1004b1a90:	mov	x2, #0x0
1004b1a94:	bl	0x101acfec0 ; selector orderOut:
1004b1a98:	ldr	x8, [x19, x20]
1004b1a9c:	cbz	x8, 0x1004b1abc
1004b1aa0:	adrp	x9, 7844 ; 0x102355000
1004b1aa4:	ldr	x9, [x9, #0xd8]
1004b1aa8:	add	x0, x8, x9
1004b1aac:	mov	x1, #0x0
1004b1ab0:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004b1ab4:	ldr	x0, [x19, x20]
1004b1ab8:	b	0x1004b1ac0
1004b1abc:	mov	x0, #0x0
1004b1ac0:	str	xzr, [x19, x20]
1004b1ac4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1ac8:	adrp	x8, 7844 ; 0x102355000
1004b1acc:	ldr	x8, [x8, #0xe0]
1004b1ad0:	add	x0, x19, x8
1004b1ad4:	mov	x1, #0x0
1004b1ad8:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004b1adc:	adrp	x8, 7844 ; 0x102355000
1004b1ae0:	ldr	x8, [x8, #0xe8]
1004b1ae4:	ldr	x0, [x19, x8]
1004b1ae8:	str	xzr, [x19, x8]
1004b1aec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1af0:	adrp	x8, 7916 ; 0x10239d000
1004b1af4:	ldr	x20, [x8, #0x270]
1004b1af8:	add	x0, x19, x20
1004b1afc:	add	x1, sp, #0x50
1004b1b00:	mov	w2, #0x1
1004b1b04:	mov	x3, #0x0
1004b1b08:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b1b0c:	ldr	x0, [x19, x20]
1004b1b10:	adrp	x8, 7710 ; 0x1022cf000
1004b1b14:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004b1b18:	str	x8, [x19, x20]
1004b1b1c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b1b20:	adrp	x8, 7916 ; 0x10239d000
1004b1b24:	ldr	x8, [x8, #0x278]
1004b1b28:	mov	x9, #-0x1
1004b1b2c:	str	x9, [x19, x8]
1004b1b30:	adrp	x8, 7916 ; 0x10239d000
1004b1b34:	ldr	x8, [x8, #0x248]
1004b1b38:	add	x0, x19, x8
1004b1b3c:	mov	x1, #0x0
1004b1b40:	bl	0x101acab28 ; symbol stub for: _swift_weakAssign
1004b1b44:	add	x0, x19, x23
1004b1b48:	mov	x1, #0x0
1004b1b4c:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004b1b50:	adrp	x8, 7916 ; 0x10239d000
1004b1b54:	ldr	x8, [x8, #0x280]
1004b1b58:	add	x0, x19, x8
1004b1b5c:	mov	x1, #0x0
1004b1b60:	bl	0x101acab28 ; symbol stub for: _swift_weakAssign
1004b1b64:	ldr	x0, [x22, #0xa00]
1004b1b68:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b1b6c:	bl	0x101acce80 ; selector defaultCenter
1004b1b70:	mov	x29, x29
1004b1b74:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b1b78:	mov	x19, x0
1004b1b7c:	bl	0x10006eba4
1004b1b80:	ldr	x2, [x0]
1004b1b84:	mov	x0, x19
1004b1b88:	mov	x3, #0x0
1004b1b8c:	bl	0x101ad0340 ; selector postNotificationName:object:
1004b1b90:	mov	x0, x19
1004b1b94:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1b98:	ldp	x29, x30, [sp, #0xa0]
1004b1b9c:	ldp	x20, x19, [sp, #0x90]
1004b1ba0:	ldp	x22, x21, [sp, #0x80]
1004b1ba4:	ldp	x24, x23, [sp, #0x70]
1004b1ba8:	add	sp, sp, #0xb0
1004b1bac:	ret
1004b1bb0:	stp	d9, d8, [sp, #-0x70]!
1004b1bb4:	stp	x28, x27, [sp, #0x10]
1004b1bb8:	stp	x26, x25, [sp, #0x20]
1004b1bbc:	stp	x24, x23, [sp, #0x30]
1004b1bc0:	stp	x22, x21, [sp, #0x40]
1004b1bc4:	stp	x20, x19, [sp, #0x50]
1004b1bc8:	stp	x29, x30, [sp, #0x60]
1004b1bcc:	add	x29, sp, #0x60
1004b1bd0:	sub	sp, sp, #0x20
1004b1bd4:	adrp	x24, 7824 ; 0x102341000
1004b1bd8:	add	x24, x24, #0x790
1004b1bdc:	adrp	x25, 5680 ; 0x101ae1000
1004b1be0:	add	x25, x25, #0xd90
1004b1be4:	mov	x0, x24
1004b1be8:	mov	x1, x25
1004b1bec:	bl	0x100003c4c
1004b1bf0:	ldur	x8, [x0, #-0x8]
1004b1bf4:	ldr	x9, [x8, #0x40]
1004b1bf8:	add	x8, x9, #0xf
1004b1bfc:	and	x8, x8, #0xfffffffffffffff0
1004b1c00:	adrp	x16, 7706 ; 0x1022cb000
1004b1c04:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b1c08:	blr	x16
1004b1c0c:	mov	x9, sp
1004b1c10:	sub	x21, x9, x8
1004b1c14:	mov	sp, x21
1004b1c18:	mov	x0, #0x0
1004b1c1c:	bl	0x101ac4fd8 ; symbol stub for: _$s10Foundation4DateVMa
1004b1c20:	mov	x19, x0
1004b1c24:	ldur	x26, [x0, #-0x8]
1004b1c28:	ldr	x8, [x26, #0x40]
1004b1c2c:	mov	x9, x8
1004b1c30:	adrp	x16, 7706 ; 0x1022cb000
1004b1c34:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b1c38:	blr	x16
1004b1c3c:	mov	x9, sp
1004b1c40:	add	x10, x8, #0xf
1004b1c44:	and	x12, x10, #0xfffffffffffffff0
1004b1c48:	sub	x22, x9, x12
1004b1c4c:	mov	sp, x22
1004b1c50:	mov	x9, x8
1004b1c54:	adrp	x16, 7706 ; 0x1022cb000
1004b1c58:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b1c5c:	blr	x16
1004b1c60:	mov	x8, sp
1004b1c64:	sub	x23, x8, x12
1004b1c68:	mov	sp, x23
1004b1c6c:	adrp	x8, 7916 ; 0x10239d000
1004b1c70:	ldr	x27, [x8, #0x288]
1004b1c74:	add	x0, x20, x27
1004b1c78:	sub	x1, x29, #0x78
1004b1c7c:	mov	x2, #0x0
1004b1c80:	mov	x3, #0x0
1004b1c84:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b1c88:	add	x0, x20, x27
1004b1c8c:	mov	x1, x21
1004b1c90:	mov	x2, x24
1004b1c94:	mov	x3, x25
1004b1c98:	bl	0x10002d8f4
1004b1c9c:	ldr	x8, [x26, #0x30]
1004b1ca0:	mov	x0, x21
1004b1ca4:	mov	w1, #0x1
1004b1ca8:	mov	x2, x19
1004b1cac:	blr	x8
1004b1cb0:	cmp	w0, #0x1
1004b1cb4:	b.ne	0x1004b1cd4
1004b1cb8:	adrp	x1, 7824 ; 0x102341000
1004b1cbc:	add	x1, x1, #0x790
1004b1cc0:	adrp	x2, 5680 ; 0x101ae1000
1004b1cc4:	add	x2, x2, #0xd90
1004b1cc8:	mov	x0, x21
1004b1ccc:	bl	0x10002d870
1004b1cd0:	b	0x1004b1d30
1004b1cd4:	ldr	x8, [x26, #0x20]
1004b1cd8:	mov	x0, x23
1004b1cdc:	mov	x1, x21
1004b1ce0:	mov	x2, x19
1004b1ce4:	blr	x8
1004b1ce8:	mov	x8, x22
1004b1cec:	bl	0x101ac4fcc ; symbol stub for: _$s10Foundation4DateVACycfC
1004b1cf0:	mov	x0, x23
1004b1cf4:	mov	x21, x20
1004b1cf8:	mov	x20, x22
1004b1cfc:	bl	0x101ac4f48 ; symbol stub for: _$s10Foundation4DateV17timeIntervalSinceySdACF
1004b1d00:	mov	x20, x21
1004b1d04:	mov.16b	v8, v0
1004b1d08:	ldr	x21, [x26, #0x8]
1004b1d0c:	mov	x0, x22
1004b1d10:	mov	x1, x19
1004b1d14:	blr	x21
1004b1d18:	mov	x0, x23
1004b1d1c:	mov	x1, x19
1004b1d20:	blr	x21
1004b1d24:	fmov	d0, #0.50000000
1004b1d28:	fcmp	d8, d0
1004b1d2c:	b.mi	0x1004b1d4c
1004b1d30:	ldr	x8, [x20]
1004b1d34:	adrp	x9, 7710 ; 0x1022cf000
1004b1d38:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b1d3c:	ldr	x9, [x9]
1004b1d40:	and	x8, x9, x8
1004b1d44:	ldr	x8, [x8, #0x248]
1004b1d48:	blr	x8
1004b1d4c:	sub	sp, x29, #0x60
1004b1d50:	ldp	x29, x30, [sp, #0x60]
1004b1d54:	ldp	x20, x19, [sp, #0x50]
1004b1d58:	ldp	x22, x21, [sp, #0x40]
1004b1d5c:	ldp	x24, x23, [sp, #0x30]
1004b1d60:	ldp	x26, x25, [sp, #0x20]
1004b1d64:	ldp	x28, x27, [sp, #0x10]
1004b1d68:	ldp	d9, d8, [sp], #0x70
1004b1d6c:	ret
1004b1d70:	stp	x24, x23, [sp, #-0x40]!
1004b1d74:	stp	x22, x21, [sp, #0x10]
1004b1d78:	stp	x20, x19, [sp, #0x20]
1004b1d7c:	stp	x29, x30, [sp, #0x30]
1004b1d80:	add	x29, sp, #0x30
1004b1d84:	mov	x19, x2
1004b1d88:	mov	x20, x0
1004b1d8c:	mov	x0, #0x0
1004b1d90:	bl	0x101ac4a50 ; symbol stub for: _$s10Foundation12NotificationVMa
1004b1d94:	mov	x21, x0
1004b1d98:	ldur	x23, [x0, #-0x8]
1004b1d9c:	ldr	x8, [x23, #0x40]
1004b1da0:	mov	x9, x8
1004b1da4:	adrp	x16, 7706 ; 0x1022cb000
1004b1da8:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b1dac:	blr	x16
1004b1db0:	mov	x9, sp
1004b1db4:	add	x8, x8, #0xf
1004b1db8:	and	x8, x8, #0xfffffffffffffff0
1004b1dbc:	sub	x22, x9, x8
1004b1dc0:	mov	sp, x22
1004b1dc4:	mov	x8, x22
1004b1dc8:	mov	x0, x19
1004b1dcc:	bl	0x101ac4a14 ; symbol stub for: _$s10Foundation12NotificationV36_unconditionallyBridgeFromObjectiveCyACSo14NSNotificationCSgFZ
1004b1dd0:	mov	x0, x20
1004b1dd4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b1dd8:	mov	x20, x0
1004b1ddc:	bl	0x1004b1bb0
1004b1de0:	mov	x0, x20
1004b1de4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b1de8:	ldr	x8, [x23, #0x8]
1004b1dec:	mov	x0, x22
1004b1df0:	mov	x1, x21
1004b1df4:	blr	x8
1004b1df8:	sub	sp, x29, #0x30
1004b1dfc:	ldp	x29, x30, [sp, #0x30]
1004b1e00:	ldp	x20, x19, [sp, #0x20]
1004b1e04:	ldp	x22, x21, [sp, #0x10]
1004b1e08:	ldp	x24, x23, [sp], #0x40
1004b1e0c:	ret
1004b1e10:	stp	d11, d10, [sp, #-0x80]!
1004b1e14:	stp	d9, d8, [sp, #0x10]
1004b1e18:	stp	x28, x27, [sp, #0x20]
1004b1e1c:	stp	x26, x25, [sp, #0x30]
1004b1e20:	stp	x24, x23, [sp, #0x40]
1004b1e24:	stp	x22, x21, [sp, #0x50]
1004b1e28:	stp	x20, x19, [sp, #0x60]
1004b1e2c:	stp	x29, x30, [sp, #0x70]
1004b1e30:	add	x29, sp, #0x70
1004b1e34:	sub	sp, sp, #0x250
1004b1e38:	mov	x19, sp
1004b1e3c:	str	x0, [x19, #0x68]
1004b1e40:	mov	x0, #0x0
1004b1e44:	bl	0x101ac4e28 ; symbol stub for: _$s10Foundation3URLVMa
1004b1e48:	ldur	x8, [x0, #-0x8]
1004b1e4c:	stp	x8, x0, [x19, #0x48]
1004b1e50:	ldr	x8, [x8, #0x40]
1004b1e54:	mov	x9, x8
1004b1e58:	adrp	x16, 7706 ; 0x1022cb000
1004b1e5c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b1e60:	blr	x16
1004b1e64:	mov	x9, sp
1004b1e68:	add	x8, x8, #0xf
1004b1e6c:	and	x8, x8, #0xfffffffffffffff0
1004b1e70:	sub	x8, x9, x8
1004b1e74:	str	x8, [x19, #0x40]
1004b1e78:	mov	sp, x8
1004b1e7c:	adrp	x0, 7844 ; 0x102355000
1004b1e80:	add	x0, x0, #0x538
1004b1e84:	adrp	x1, 5700 ; 0x101af5000
1004b1e88:	add	x1, x1, #0xe60
1004b1e8c:	bl	0x100003c4c
1004b1e90:	ldur	x8, [x0, #-0x8]
1004b1e94:	ldr	x9, [x8, #0x40]
1004b1e98:	add	x8, x9, #0xf
1004b1e9c:	and	x8, x8, #0xfffffffffffffff0
1004b1ea0:	adrp	x16, 7706 ; 0x1022cb000
1004b1ea4:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b1ea8:	blr	x16
1004b1eac:	mov	x9, sp
1004b1eb0:	sub	x25, x9, x8
1004b1eb4:	mov	sp, x25
1004b1eb8:	mov	x0, #0x0
1004b1ebc:	bl	0x1004c1634
1004b1ec0:	mov	x28, x0
1004b1ec4:	ldur	x21, [x0, #-0x8]
1004b1ec8:	ldr	x8, [x21, #0x40]
1004b1ecc:	mov	x9, x8
1004b1ed0:	adrp	x16, 7706 ; 0x1022cb000
1004b1ed4:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b1ed8:	blr	x16
1004b1edc:	mov	x9, sp
1004b1ee0:	add	x8, x8, #0xf
1004b1ee4:	and	x8, x8, #0xfffffffffffffff0
1004b1ee8:	sub	x8, x9, x8
1004b1eec:	str	x8, [x19, #0x70]
1004b1ef0:	mov	sp, x8
1004b1ef4:	adrp	x8, 7916 ; 0x10239d000
1004b1ef8:	ldr	x27, [x8, #0x248]
1004b1efc:	str	x20, [x19, #0xa0]
1004b1f00:	add	x0, x20, x27
1004b1f04:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b1f08:	cbz	x0, 0x1004b1f7c
1004b1f0c:	mov	x20, x0
1004b1f10:	ldr	x8, [x0]
1004b1f14:	ldr	x8, [x8, #0x260]
1004b1f18:	blr	x8
1004b1f1c:	mov	x23, x0
1004b1f20:	mov	x0, x20
1004b1f24:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b1f28:	cbz	x23, 0x1004b1f90
1004b1f2c:	ldr	x8, [x23]
1004b1f30:	ldr	x22, [x8, #0x688]
1004b1f34:	mov	x0, x23
1004b1f38:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b1f3c:	mov	x20, x23
1004b1f40:	blr	x22
1004b1f44:	str	x0, [x19, #0x60]
1004b1f48:	str	x1, [x19, #0x88]
1004b1f4c:	mov	x0, x23
1004b1f50:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b1f54:	ldr	x8, [x23]
1004b1f58:	ldr	x22, [x8, #0x670]
1004b1f5c:	mov	x0, x23
1004b1f60:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b1f64:	blr	x22
1004b1f68:	mov	x24, x0
1004b1f6c:	mov	x26, x1
1004b1f70:	mov	x0, x23
1004b1f74:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b1f78:	b	0x1004b1fa8
1004b1f7c:	mov	w24, #0x744f
1004b1f80:	movk	w24, #0x7974, lsl #16
1004b1f84:	str	xzr, [x19, #0x60]
1004b1f88:	mov	x23, #0x0
1004b1f8c:	b	0x1004b1f9c
1004b1f90:	mov	w24, #0x744f
1004b1f94:	movk	w24, #0x7974, lsl #16
1004b1f98:	str	xzr, [x19, #0x60]
1004b1f9c:	mov	x8, #-0x2000000000000000
1004b1fa0:	str	x8, [x19, #0x88]
1004b1fa4:	mov	x26, #-0x1c00000000000000
1004b1fa8:	str	x23, [x19, #0x90]
1004b1fac:	ldr	x8, [x19, #0xa0]
1004b1fb0:	add	x0, x8, x27
1004b1fb4:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b1fb8:	str	x27, [x19, #0x78]
1004b1fbc:	cbz	x0, 0x1004b1fe4
1004b1fc0:	mov	x20, x0
1004b1fc4:	ldr	x8, [x0]
1004b1fc8:	ldr	x8, [x8, #0x358]
1004b1fcc:	blr	x8
1004b1fd0:	and	w22, w1, #0xff
1004b1fd4:	mov	x0, x20
1004b1fd8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b1fdc:	cmp	w22, #0x1
1004b1fe0:	b.ne	0x1004b1fec
1004b1fe4:	mov	w22, #0x1
1004b1fe8:	b	0x1004b1ff0
1004b1fec:	mov	w22, #0x0
1004b1ff0:	adrp	x8, 7916 ; 0x10239d000
1004b1ff4:	ldr	x8, [x8, #0x270]
1004b1ff8:	ldr	x27, [x19, #0xa0]
1004b1ffc:	add	x23, x27, x8
1004b2000:	add	x1, x19, #0x188
1004b2004:	mov	x0, x23
1004b2008:	mov	w2, #0x1
1004b200c:	mov	x3, #0x0
1004b2010:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b2014:	ldr	x0, [x23]
1004b2018:	adrp	x8, 7709 ; 0x1022cf000
1004b201c:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004b2020:	str	x8, [x23]
1004b2024:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b2028:	adrp	x8, 7915 ; 0x10239d000
1004b202c:	ldr	x8, [x8, #0x278]
1004b2030:	mov	x9, #-0x1
1004b2034:	str	x9, [x27, x8]
1004b2038:	mov	x0, #0x0
1004b203c:	bl	0x10006d00c
1004b2040:	mov	x8, #0x800000000000
1004b2044:	movk	x8, #0x4071, lsl #48
1004b2048:	fmov	d2, x8
1004b204c:	movi.2d	v0, #0000000000000000
1004b2050:	movi.2d	v1, #0000000000000000
1004b2054:	movi.2d	v3, #0000000000000000
1004b2058:	mov	x20, x0
1004b205c:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b2060:	str	x0, [x19, #0x80]
1004b2064:	tbz	w22, #0x0, 0x1004b2368
1004b2068:	str	x23, [x19, #0x58]
1004b206c:	add	x23, x19, #0x1a0
1004b2070:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b2074:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b2078:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b207c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b2080:	mov	x22, x0
1004b2084:	fmov	d0, #8.00000000
1004b2088:	mov	x1, x24
1004b208c:	mov	x2, x26
1004b2090:	mov	x20, x27
1004b2094:	bl	0x1004b48c0
1004b2098:	mov.16b	v8, v0
1004b209c:	mov	x0, x26
1004b20a0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b20a4:	mov	x0, x22
1004b20a8:	mov.16b	v0, v8
1004b20ac:	bl	0x1004bfddc
1004b20b0:	mov.16b	v8, v0
1004b20b4:	mov	x8, x25
1004b20b8:	bl	0x1004bb8e4
1004b20bc:	ldr	x8, [x21, #0x30]
1004b20c0:	mov	x0, x25
1004b20c4:	mov	w1, #0x1
1004b20c8:	mov	x2, x28
1004b20cc:	blr	x8
1004b20d0:	cmp	w0, #0x1
1004b20d4:	str	x22, [x19, #0x98]
1004b20d8:	b.ne	0x1004b2738
1004b20dc:	mov	x0, x22
1004b20e0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b20e4:	mov	x0, x22
1004b20e8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b20ec:	adrp	x1, 7843 ; 0x102355000
1004b20f0:	add	x1, x1, #0x538
1004b20f4:	adrp	x2, 5699 ; 0x101af5000
1004b20f8:	add	x2, x2, #0xe60
1004b20fc:	mov	x0, x25
1004b2100:	bl	0x10002d870
1004b2104:	ldp	x21, x26, [x19, #0x60]
1004b2108:	and	x8, x21, #0xffffffffffff
1004b210c:	ldr	x27, [x19, #0x88]
1004b2110:	ubfx	x9, x27, #56, #4
1004b2114:	tst	x27, #0x2000000000000000
1004b2118:	csel	x8, x8, x9, eq
1004b211c:	cbz	x8, 0x1004b28ac
1004b2120:	mov	x0, x22
1004b2124:	mov.16b	v0, v8
1004b2128:	mov	x1, x21
1004b212c:	mov	x2, x27
1004b2130:	ldr	x28, [x19, #0xa0]
1004b2134:	mov	x20, x28
1004b2138:	bl	0x1004b60f8
1004b213c:	mov	x0, x22
1004b2140:	bl	0x1004bfddc
1004b2144:	mov.16b	v8, v0
1004b2148:	ldrb	w8, [x26]
1004b214c:	ldur	q0, [x26, #0x28]
1004b2150:	ldur	q1, [x26, #0x38]
1004b2154:	add	x23, x19, #0x1a0
1004b2158:	stp	q0, q1, [x23, #0x60]
1004b215c:	ldur	q0, [x26, #0x48]
1004b2160:	str	q0, [x23, #0x80]
1004b2164:	ldrb	w9, [x26, #0x58]
1004b2168:	sturb	w9, [x29, #-0x90]
1004b216c:	ldur	q0, [x26, #0x8]
1004b2170:	ldur	q1, [x26, #0x18]
1004b2174:	stp	q0, q1, [x23, #0x40]
1004b2178:	tbz	w8, #0x0, 0x1004b3100
1004b217c:	adrp	x0, 7465 ; 0x1021db000
1004b2180:	add	x0, x0, #0xa58
1004b2184:	mov	w1, #0x61
1004b2188:	mov	w2, #0x7
1004b218c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b2190:	mov	x23, x21
1004b2194:	mov	x21, x0
1004b2198:	ldur	q0, [x26, #0x28]
1004b219c:	ldur	q1, [x26, #0x38]
1004b21a0:	stp	q0, q1, [x0, #0x30]
1004b21a4:	ldur	q0, [x26, #0x48]
1004b21a8:	str	q0, [x0, #0x50]
1004b21ac:	ldurb	w8, [x26, #0x58]
1004b21b0:	strb	w8, [x0, #0x60]
1004b21b4:	ldur	q0, [x26, #0x8]
1004b21b8:	ldur	q1, [x26, #0x18]
1004b21bc:	stp	q0, q1, [x0, #0x10]
1004b21c0:	adrp	x0, 7464 ; 0x1021da000
1004b21c4:	add	x0, x0, #0x978
1004b21c8:	mov	w1, #0x18
1004b21cc:	mov	w2, #0x7
1004b21d0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b21d4:	add	x20, x19, #0x1a0
1004b21d8:	mov	x24, x0
1004b21dc:	add	x0, x0, #0x10
1004b21e0:	mov	x1, x28
1004b21e4:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b21e8:	adrp	x0, 7465 ; 0x1021db000
1004b21ec:	add	x0, x0, #0xa80
1004b21f0:	mov	w1, #0x80
1004b21f4:	mov	w2, #0x7
1004b21f8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b21fc:	mov	x25, x0
1004b2200:	ldp	q0, q1, [x20, #0x60]
1004b2204:	stp	q0, q1, [x0, #0x30]
1004b2208:	ldr	q0, [x20, #0x80]
1004b220c:	str	q0, [x0, #0x50]
1004b2210:	ldurb	w8, [x29, #-0x90]
1004b2214:	strb	w8, [x0, #0x60]
1004b2218:	ldp	q0, q1, [x20, #0x40]
1004b221c:	stp	q0, q1, [x0, #0x10]
1004b2220:	stp	x24, x23, [x0, #0x68]
1004b2224:	str	x27, [x0, #0x78]
1004b2228:	mov	x0, #0x0
1004b222c:	bl	0x1004ad03c
1004b2230:	mov	x20, x0
1004b2234:	add	x1, x19, #0xa8
1004b2238:	mov	x0, x26
1004b223c:	bl	0x1004c59ac
1004b2240:	add	x1, x19, #0xa8
1004b2244:	mov	x0, x26
1004b2248:	bl	0x1004c59ac
1004b224c:	mov	x0, x24
1004b2250:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b2254:	mov	x0, x27
1004b2258:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b225c:	mov	x8, #0x800000000000
1004b2260:	movk	x8, #0x4071, lsl #48
1004b2264:	fmov	d9, x8
1004b2268:	fmov	d10, #28.00000000
1004b226c:	movi.2d	v0, #0000000000000000
1004b2270:	fmov	d3, #28.00000000
1004b2274:	mov.16b	v1, v8
1004b2278:	mov.16b	v2, v9
1004b227c:	bl	0x100096d60
1004b2280:	mov	x26, x0
1004b2284:	ldr	x8, [x0]
1004b2288:	adrp	x9, 7709 ; 0x1022cf000
1004b228c:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b2290:	ldr	x9, [x9]
1004b2294:	and	x8, x9, x8
1004b2298:	ldr	x8, [x8, #0x198]
1004b229c:	adrp	x3, 19 ; 0x1004c5000
1004b22a0:	add	x3, x3, #0x99c
1004b22a4:	adrp	x5, 19 ; 0x1004c5000
1004b22a8:	add	x5, x5, #0x694
1004b22ac:	mov	w0, #0x6947
1004b22b0:	movk	w0, #0x74, lsl #16
1004b22b4:	mov	x1, #-0x1d00000000000000
1004b22b8:	mov.16b	v0, v9
1004b22bc:	mov	x2, x28
1004b22c0:	mov	x4, x25
1004b22c4:	mov	x6, x21
1004b22c8:	mov	x20, x26
1004b22cc:	blr	x8
1004b22d0:	mov	x0, x22
1004b22d4:	mov	x2, x26
1004b22d8:	bl	0x101acb460 ; selector addSubview:
1004b22dc:	add	x1, x19, #0xa8
1004b22e0:	ldr	x20, [x19, #0x58]
1004b22e4:	mov	x0, x20
1004b22e8:	mov	w2, #0x21
1004b22ec:	mov	x3, #0x0
1004b22f0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b22f4:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b22f8:	ldr	x8, [x20]
1004b22fc:	and	x8, x8, #0xffffffffffffff8
1004b2300:	mov	x22, x27
1004b2304:	ldp	x27, x8, [x8, #0x10]
1004b2308:	cmp	x27, x8, lsr #1
1004b230c:	b.hs	0x1004b42a4
1004b2310:	mov	x0, x26
1004b2314:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b2318:	mov	x26, x0
1004b231c:	mov	x0, x27
1004b2320:	mov	x1, x26
1004b2324:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b2328:	add	x0, x19, #0xa8
1004b232c:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b2330:	mov	x0, x24
1004b2334:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b2338:	mov	x0, x26
1004b233c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b2340:	mov	x0, x25
1004b2344:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b2348:	mov	x0, x21
1004b234c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b2350:	mov	x0, x22
1004b2354:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b2358:	fadd	d10, d8, d10
1004b235c:	ldr	x21, [x19, #0x78]
1004b2360:	add	x23, x19, #0x1a0
1004b2364:	b	0x1004b3110
1004b2368:	mov	x20, x0
1004b236c:	ldr	x0, [x19, #0x88]
1004b2370:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b2374:	mov	x0, x26
1004b2378:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b237c:	adrp	x8, 6439 ; 0x101dd9000
1004b2380:	add	x8, x8, #0x420 ; literal pool for: "Find in All Tabs"
1004b2384:	sub	x26, x8, #0x20
1004b2388:	adrp	x0, 7464 ; 0x1021da000
1004b238c:	add	x0, x0, #0x978
1004b2390:	mov	w1, #0x18
1004b2394:	mov	w2, #0x7
1004b2398:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b239c:	mov	x24, x0
1004b23a0:	add	x0, x0, #0x10
1004b23a4:	mov	x1, x27
1004b23a8:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b23ac:	mov	x0, #0x0
1004b23b0:	bl	0x1004aede4
1004b23b4:	mov	x22, x0
1004b23b8:	mov	x0, x20
1004b23bc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b23c0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b23c4:	mov	x21, x0
1004b23c8:	mov	x0, x24
1004b23cc:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b23d0:	mov	x8, #0x800000000000
1004b23d4:	movk	x8, #0x4071, lsl #48
1004b23d8:	fmov	d2, x8
1004b23dc:	movi.2d	v0, #0000000000000000
1004b23e0:	fmov	d1, #8.00000000
1004b23e4:	fmov	d3, #28.00000000
1004b23e8:	mov	x20, x22
1004b23ec:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b23f0:	mov	x25, x0
1004b23f4:	ldr	x8, [x0]
1004b23f8:	adrp	x28, 7709 ; 0x1022cf000
1004b23fc:	ldr	x28, [x28, #0x718] ; literal pool symbol address: _swift_isaMask
1004b2400:	ldr	x9, [x28]
1004b2404:	and	x8, x9, x8
1004b2408:	ldr	x8, [x8, #0x140]
1004b240c:	str	x24, [sp, #-0x10]!
1004b2410:	adrp	x7, 22 ; 0x1004c8000
1004b2414:	add	x7, x7, #0x878
1004b2418:	mov	x2, #0x8ce2
1004b241c:	movk	x2, #0xe298, lsl #16
1004b2420:	movk	x2, #0xa787, lsl #32
1004b2424:	movk	x2, #0x46, lsl #48
1004b2428:	orr	x1, x26, #0x8000000000000000
1004b242c:	mov	x0, #0x10
1004b2430:	movk	x0, #0xd000, lsl #48
1004b2434:	mov	x3, #-0x5900000000000000
1004b2438:	mov	w4, #0x0
1004b243c:	mov	x5, #0x0
1004b2440:	mov	w6, #0x1
1004b2444:	mov	x20, x25
1004b2448:	blr	x8
1004b244c:	add	sp, sp, #0x10
1004b2450:	mov	x0, x21
1004b2454:	mov	x2, x25
1004b2458:	bl	0x101acb460 ; selector addSubview:
1004b245c:	add	x1, x19, #0xa8
1004b2460:	mov	x0, x23
1004b2464:	mov	w2, #0x21
1004b2468:	mov	x3, #0x0
1004b246c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b2470:	mov	x20, x23
1004b2474:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b2478:	ldr	x8, [x23]
1004b247c:	and	x8, x8, #0xffffffffffffff8
1004b2480:	ldp	x26, x8, [x8, #0x10]
1004b2484:	cmp	x26, x8, lsr #1
1004b2488:	b.hs	0x1004b411c
1004b248c:	mov	x0, x25
1004b2490:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b2494:	mov	x25, x0
1004b2498:	mov	x0, x26
1004b249c:	mov	x1, x25
1004b24a0:	mov	x20, x23
1004b24a4:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b24a8:	add	x0, x19, #0xa8
1004b24ac:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b24b0:	mov	x0, x25
1004b24b4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b24b8:	mov	x0, x24
1004b24bc:	mov	w1, #0x2
1004b24c0:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b24c4:	adrp	x0, 7464 ; 0x1021da000
1004b24c8:	add	x0, x0, #0x978
1004b24cc:	mov	w1, #0x18
1004b24d0:	mov	w2, #0x7
1004b24d4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b24d8:	mov	x24, x0
1004b24dc:	add	x0, x0, #0x10
1004b24e0:	mov	x1, x27
1004b24e4:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b24e8:	mov	x0, x24
1004b24ec:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b24f0:	mov	x8, #0x4042000000000000
1004b24f4:	fmov	d1, x8
1004b24f8:	mov	x8, #0x800000000000
1004b24fc:	movk	x8, #0x4071, lsl #48
1004b2500:	fmov	d2, x8
1004b2504:	movi.2d	v0, #0000000000000000
1004b2508:	fmov	d3, #28.00000000
1004b250c:	mov	x20, x22
1004b2510:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b2514:	mov	x25, x0
1004b2518:	ldr	x8, [x0]
1004b251c:	ldr	x9, [x28]
1004b2520:	and	x8, x9, x8
1004b2524:	ldr	x8, [x8, #0x140]
1004b2528:	str	x24, [sp, #-0x10]!
1004b252c:	adrp	x7, 17 ; 0x1004c3000
1004b2530:	add	x7, x7, #0xfc8
1004b2534:	mov	x0, #0x754a
1004b2538:	movk	x0, #0x706d, lsl #16
1004b253c:	movk	x0, #0x7420, lsl #32
1004b2540:	movk	x0, #0x6f, lsl #48
1004b2544:	mov	x1, #-0x1900000000000000
1004b2548:	mov	w2, #0x8ce2
1004b254c:	movk	w2, #0x4a98, lsl #16
1004b2550:	mov	x3, #-0x5c00000000000000
1004b2554:	mov	w4, #0x0
1004b2558:	mov	x5, #0x0
1004b255c:	mov	w6, #0x1
1004b2560:	mov	x20, x25
1004b2564:	blr	x8
1004b2568:	add	sp, sp, #0x10
1004b256c:	mov	x0, x21
1004b2570:	mov	x2, x25
1004b2574:	bl	0x101acb460 ; selector addSubview:
1004b2578:	add	x1, x19, #0xa8
1004b257c:	mov	x0, x23
1004b2580:	mov	w2, #0x21
1004b2584:	mov	x3, #0x0
1004b2588:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b258c:	mov	x20, x23
1004b2590:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b2594:	ldr	x8, [x23]
1004b2598:	and	x8, x8, #0xffffffffffffff8
1004b259c:	ldp	x26, x8, [x8, #0x10]
1004b25a0:	cmp	x26, x8, lsr #1
1004b25a4:	b.hs	0x1004b4138
1004b25a8:	mov	x0, x25
1004b25ac:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b25b0:	mov	x25, x0
1004b25b4:	mov	x0, x26
1004b25b8:	mov	x1, x25
1004b25bc:	mov	x20, x23
1004b25c0:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b25c4:	add	x0, x19, #0xa8
1004b25c8:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b25cc:	mov	x0, x25
1004b25d0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b25d4:	mov	x0, x24
1004b25d8:	mov	w1, #0x2
1004b25dc:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b25e0:	adrp	x0, 7464 ; 0x1021da000
1004b25e4:	add	x0, x0, #0x978
1004b25e8:	mov	w1, #0x18
1004b25ec:	mov	w2, #0x7
1004b25f0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b25f4:	mov	x24, x0
1004b25f8:	add	x0, x0, #0x10
1004b25fc:	mov	x1, x27
1004b2600:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b2604:	mov	x0, x24
1004b2608:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b260c:	mov	x8, #0x4050000000000000
1004b2610:	fmov	d1, x8
1004b2614:	mov	x8, #0x800000000000
1004b2618:	movk	x8, #0x4071, lsl #48
1004b261c:	fmov	d2, x8
1004b2620:	movi.2d	v0, #0000000000000000
1004b2624:	fmov	d3, #28.00000000
1004b2628:	mov	x20, x22
1004b262c:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b2630:	mov	x22, x0
1004b2634:	ldr	x8, [x0]
1004b2638:	ldr	x9, [x28]
1004b263c:	and	x8, x9, x8
1004b2640:	ldr	x8, [x8, #0x140]
1004b2644:	str	x24, [sp, #-0x10]!
1004b2648:	adrp	x7, 22 ; 0x1004c8000
1004b264c:	add	x7, x7, #0x880
1004b2650:	mov	x0, #0x6f43
1004b2654:	movk	x0, #0x6d6d, lsl #16
1004b2658:	movk	x0, #0x6e61, lsl #32
1004b265c:	movk	x0, #0x2064, lsl #48
1004b2660:	mov	x1, #0x6150
1004b2664:	movk	x1, #0x656c, lsl #16
1004b2668:	movk	x1, #0x7474, lsl #32
1004b266c:	movk	x1, #0xef65, lsl #48
1004b2670:	mov	x2, #0x8ce2
1004b2674:	movk	x2, #0xe298, lsl #16
1004b2678:	movk	x2, #0xa787, lsl #32
1004b267c:	movk	x2, #0x50, lsl #48
1004b2680:	mov	x3, #-0x5900000000000000
1004b2684:	mov	w4, #0x0
1004b2688:	mov	x5, #0x0
1004b268c:	mov	w6, #0x1
1004b2690:	mov	x20, x22
1004b2694:	blr	x8
1004b2698:	add	sp, sp, #0x10
1004b269c:	mov	x0, x21
1004b26a0:	mov	x2, x22
1004b26a4:	bl	0x101acb460 ; selector addSubview:
1004b26a8:	add	x1, x19, #0xa8
1004b26ac:	mov	x0, x23
1004b26b0:	mov	w2, #0x21
1004b26b4:	mov	x3, #0x0
1004b26b8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b26bc:	mov	x20, x23
1004b26c0:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b26c4:	ldr	x8, [x23]
1004b26c8:	and	x8, x8, #0xffffffffffffff8
1004b26cc:	ldp	x25, x8, [x8, #0x10]
1004b26d0:	cmp	x25, x8, lsr #1
1004b26d4:	b.hs	0x1004b4154
1004b26d8:	mov	x0, x22
1004b26dc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b26e0:	mov	x22, x0
1004b26e4:	mov	x0, x25
1004b26e8:	mov	x1, x22
1004b26ec:	mov	x20, x23
1004b26f0:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b26f4:	add	x0, x19, #0xa8
1004b26f8:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b26fc:	mov	x0, x22
1004b2700:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b2704:	mov	x0, x24
1004b2708:	mov	w1, #0x2
1004b270c:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b2710:	mov	x0, x21
1004b2714:	bl	0x101acdcc0 ; selector frame
1004b2718:	mov	x8, #0x4059000000000000
1004b271c:	fmov	d3, x8
1004b2720:	mov	x0, x21
1004b2724:	bl	0x101ad2b80 ; selector setFrame:
1004b2728:	mov	x0, x21
1004b272c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b2730:	mov	x0, x21
1004b2734:	b	0x1004b3ddc
1004b2738:	ldr	x0, [x19, #0x88]
1004b273c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b2740:	mov	x0, x22
1004b2744:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b2748:	mov	x0, x22
1004b274c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b2750:	adrp	x2, 15 ; 0x1004c1000
1004b2754:	add	x2, x2, #0x634
1004b2758:	mov	x0, x25
1004b275c:	ldr	x21, [x19, #0x70]
1004b2760:	mov	x1, x21
1004b2764:	bl	0x1000840ec
1004b2768:	ldr	x24, [x21]
1004b276c:	ldpsw	x27, x20, [x28, #0x14]
1004b2770:	ldr	x9, [x19, #0x68]
1004b2774:	ldrb	w8, [x9]
1004b2778:	str	w8, [x19, #0x60]
1004b277c:	ldur	q0, [x9, #0x28]
1004b2780:	ldur	q1, [x9, #0x38]
1004b2784:	stp	q0, q1, [x23, #0x60]
1004b2788:	ldur	q0, [x9, #0x48]
1004b278c:	str	q0, [x23, #0x80]
1004b2790:	ldrb	w8, [x9, #0x58]
1004b2794:	sturb	w8, [x29, #-0x90]
1004b2798:	ldur	q0, [x9, #0x8]
1004b279c:	ldur	q1, [x9, #0x18]
1004b27a0:	stp	q0, q1, [x23, #0x40]
1004b27a4:	mov	x0, #0x0
1004b27a8:	bl	0x10068c76c
1004b27ac:	ldrsw	x8, [x0, #0x18]
1004b27b0:	add	x8, x20, x8
1004b27b4:	add	x8, x21, x8
1004b27b8:	ldr	x25, [x8, #0x18]
1004b27bc:	cbz	x25, 0x1004b2824
1004b27c0:	ldp	x22, x20, [x8, #0x20]
1004b27c4:	ldp	x28, x26, [x8, #0x8]
1004b27c8:	ldr	x21, [x8]
1004b27cc:	mov	x0, x21
1004b27d0:	mov	x1, x28
1004b27d4:	mov	x2, x26
1004b27d8:	mov	x3, x25
1004b27dc:	mov	x4, x22
1004b27e0:	mov	x5, x20
1004b27e4:	bl	0x1000db8bc
1004b27e8:	mov	x0, x21
1004b27ec:	ldr	x21, [x19, #0x70]
1004b27f0:	mov	x1, x28
1004b27f4:	mov	x2, x26
1004b27f8:	mov	x3, x25
1004b27fc:	mov	x4, x22
1004b2800:	mov	x5, x20
1004b2804:	bl	0x1000db95c
1004b2808:	mov	x0, #0x0
1004b280c:	mov	x1, #0x0
1004b2810:	mov	x2, #0x0
1004b2814:	mov	x3, #0x0
1004b2818:	mov	x4, #0x0
1004b281c:	mov	x5, #0x0
1004b2820:	bl	0x1000db95c
1004b2824:	cmp	x25, #0x0
1004b2828:	cset	w26, eq
1004b282c:	mov	x20, x24
1004b2830:	bl	0x1000dfd04
1004b2834:	mov	x23, x0
1004b2838:	bl	0x1000e0880
1004b283c:	mov	x22, x0
1004b2840:	add	x1, x21, x27
1004b2844:	ldp	x28, x20, [x19, #0x98]
1004b2848:	mov	x0, x28
1004b284c:	mov.16b	v0, v8
1004b2850:	mov	x2, x26
1004b2854:	bl	0x1004bbbb4
1004b2858:	mov	x0, x28
1004b285c:	bl	0x1004bfddc
1004b2860:	mov	x0, x23
1004b2864:	mov.16b	v8, v0
1004b2868:	ldr	x23, [x19, #0x58]
1004b286c:	str	x0, [x19, #0x88]
1004b2870:	cbz	x0, 0x1004b28ec
1004b2874:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b2878:	mov	x26, x0
1004b287c:	mov	x0, x28
1004b2880:	mov.16b	v0, v8
1004b2884:	mov	x1, x26
1004b2888:	bl	0x1004bcdf0
1004b288c:	mov	x0, x28
1004b2890:	bl	0x1004bfddc
1004b2894:	mov.16b	v8, v0
1004b2898:	mov	x0, x26
1004b289c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b28a0:	mov	x26, x22
1004b28a4:	mov	x28, x20
1004b28a8:	b	0x1004b28f8
1004b28ac:	ldur	q0, [x26, #0x28]
1004b28b0:	ldur	q1, [x26, #0x38]
1004b28b4:	add	x23, x19, #0x1a0
1004b28b8:	stp	q0, q1, [x23, #0x60]
1004b28bc:	ldur	q0, [x26, #0x48]
1004b28c0:	str	q0, [x23, #0x80]
1004b28c4:	ldrb	w8, [x26, #0x58]
1004b28c8:	sturb	w8, [x29, #-0x90]
1004b28cc:	ldur	q0, [x26, #0x8]
1004b28d0:	ldur	q1, [x26, #0x18]
1004b28d4:	stp	q0, q1, [x23, #0x40]
1004b28d8:	mov	x0, x27
1004b28dc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b28e0:	mov.16b	v10, v8
1004b28e4:	ldr	x28, [x19, #0xa0]
1004b28e8:	b	0x1004b310c
1004b28ec:	mov	x26, x22
1004b28f0:	mov	x28, x20
1004b28f4:	cbz	x22, 0x1004b291c
1004b28f8:	ldr	x22, [x19, #0x98]
1004b28fc:	mov	x0, x22
1004b2900:	mov.16b	v0, v8
1004b2904:	mov	x1, x24
1004b2908:	mov	x20, x28
1004b290c:	bl	0x1004bd748
1004b2910:	mov	x0, x22
1004b2914:	bl	0x1004bfddc
1004b2918:	mov.16b	v8, v0
1004b291c:	cbnz	x25, 0x1004b2a48
1004b2920:	ldr	w8, [x19, #0x60]
1004b2924:	tbz	w8, #0x0, 0x1004b2a48
1004b2928:	add	x20, x21, x27
1004b292c:	ldr	x25, [x19, #0x40]
1004b2930:	mov	x8, x25
1004b2934:	bl	0x101ac4dc8 ; symbol stub for: _$s10Foundation3URLV25deletingLastPathComponentACyF
1004b2938:	mov	x20, x25
1004b293c:	bl	0x101ac4df8 ; symbol stub for: _$s10Foundation3URLV4pathSSvg
1004b2940:	mov	x20, x0
1004b2944:	mov	x24, x1
1004b2948:	ldp	x8, x1, [x19, #0x48]
1004b294c:	ldr	x8, [x8, #0x8]
1004b2950:	mov	x0, x25
1004b2954:	blr	x8
1004b2958:	mov	x0, x20
1004b295c:	mov	x1, x24
1004b2960:	bl	0x100582f94
1004b2964:	mov	x22, x0
1004b2968:	mov	x20, x21
1004b296c:	mov	x21, x1
1004b2970:	mov	x0, x24
1004b2974:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b2978:	cbz	x21, 0x1004b2a48
1004b297c:	add	x20, x20, x27
1004b2980:	bl	0x101ac4df8 ; symbol stub for: _$s10Foundation3URLV4pathSSvg
1004b2984:	mov	x25, x0
1004b2988:	mov	x28, x1
1004b298c:	stp	x22, x21, [x19, #0xa8]
1004b2990:	mov	x0, x21
1004b2994:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b2998:	add	x20, x19, #0xa8
1004b299c:	mov	w0, #0x2f
1004b29a0:	mov	x1, #-0x1f00000000000000
1004b29a4:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004b29a8:	ldp	x0, x20, [x19, #0xa8]
1004b29ac:	mov	x1, x20
1004b29b0:	mov	x2, x25
1004b29b4:	mov	x3, x28
1004b29b8:	bl	0x101ac658c ; symbol stub for: _$sSS9hasPrefixySbSSF
1004b29bc:	mov	x24, x0
1004b29c0:	mov	x0, x20
1004b29c4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b29c8:	str	x26, [x19, #0x38]
1004b29cc:	tbz	w24, #0x0, 0x1004b3f50
1004b29d0:	mov	x0, x28
1004b29d4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b29d8:	mov	x0, x22
1004b29dc:	mov	x1, x21
1004b29e0:	bl	0x101ac6430 ; symbol stub for: _$sSS5countSivg
1004b29e4:	adds	x0, x0, #0x1
1004b29e8:	ldr	x27, [x19, #0x98]
1004b29ec:	b.vs	0x1004b4310
1004b29f0:	mov	x1, x25
1004b29f4:	mov	x2, x28
1004b29f8:	bl	0x1000252e8
1004b29fc:	mov	x20, x0
1004b2a00:	mov	x24, x1
1004b2a04:	mov	x25, x2
1004b2a08:	mov	x26, x3
1004b2a0c:	mov	x0, x28
1004b2a10:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b2a14:	mov	x0, x20
1004b2a18:	mov	x1, x24
1004b2a1c:	mov	x2, x25
1004b2a20:	mov	x3, x26
1004b2a24:	bl	0x101ac6340 ; symbol stub for: _$sSS14_fromSubstringySSSshFZ
1004b2a28:	mov	x25, x0
1004b2a2c:	mov	x20, x1
1004b2a30:	mov	x0, x26
1004b2a34:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b2a38:	mov	x0, x28
1004b2a3c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b2a40:	mov	x28, x20
1004b2a44:	b	0x1004b3f54
1004b2a48:	ldr	x0, [x19, #0x88]
1004b2a4c:	ldr	x27, [x19, #0x98]
1004b2a50:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b2a54:	mov	x0, x26
1004b2a58:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b2a5c:	adrp	x0, 7464 ; 0x1021da000
1004b2a60:	add	x0, x0, #0x978
1004b2a64:	mov	w1, #0x18
1004b2a68:	mov	w2, #0x7
1004b2a6c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b2a70:	mov	x21, x0
1004b2a74:	add	x0, x0, #0x10
1004b2a78:	mov	x1, x28
1004b2a7c:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b2a80:	mov	x0, #0x0
1004b2a84:	bl	0x1004ad03c
1004b2a88:	mov	x20, x0
1004b2a8c:	mov	x0, x21
1004b2a90:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b2a94:	mov	x8, #0x800000000000
1004b2a98:	movk	x8, #0x4071, lsl #48
1004b2a9c:	fmov	d9, x8
1004b2aa0:	fmov	d10, #28.00000000
1004b2aa4:	movi.2d	v0, #0000000000000000
1004b2aa8:	fmov	d3, #28.00000000
1004b2aac:	mov.16b	v1, v8
1004b2ab0:	mov.16b	v2, v9
1004b2ab4:	bl	0x100096d60
1004b2ab8:	mov	x22, x0
1004b2abc:	ldr	x8, [x0]
1004b2ac0:	adrp	x26, 7709 ; 0x1022cf000
1004b2ac4:	ldr	x26, [x26, #0x718] ; literal pool symbol address: _swift_isaMask
1004b2ac8:	ldr	x9, [x26]
1004b2acc:	and	x8, x9, x8
1004b2ad0:	ldr	x8, [x8, #0x198]
1004b2ad4:	adrp	x3, 19 ; 0x1004c5000
1004b2ad8:	add	x3, x3, #0x9bc
1004b2adc:	mov	x0, #0x7053
1004b2ae0:	movk	x0, #0x696c, lsl #16
1004b2ae4:	movk	x0, #0x2074, lsl #32
1004b2ae8:	movk	x0, #0x6956, lsl #48
1004b2aec:	mov	x1, #0x7765
1004b2af0:	movk	x1, #0xea00, lsl #48
1004b2af4:	mov.16b	v0, v9
1004b2af8:	mov	x2, x28
1004b2afc:	mov	x4, x21
1004b2b00:	mov	x5, #0x0
1004b2b04:	mov	x6, #0x0
1004b2b08:	mov	x20, x22
1004b2b0c:	blr	x8
1004b2b10:	mov	x0, x27
1004b2b14:	mov	x2, x22
1004b2b18:	bl	0x101acb460 ; selector addSubview:
1004b2b1c:	add	x1, x19, #0xa8
1004b2b20:	mov	x0, x23
1004b2b24:	mov	w2, #0x21
1004b2b28:	mov	x3, #0x0
1004b2b2c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b2b30:	mov	x20, x23
1004b2b34:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b2b38:	ldr	x8, [x23]
1004b2b3c:	and	x8, x8, #0xffffffffffffff8
1004b2b40:	ldp	x24, x8, [x8, #0x10]
1004b2b44:	cmp	x24, x8, lsr #1
1004b2b48:	b.hs	0x1004b41fc
1004b2b4c:	mov	x0, x22
1004b2b50:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b2b54:	mov	x22, x0
1004b2b58:	mov	x0, x24
1004b2b5c:	mov	x1, x22
1004b2b60:	mov	x20, x23
1004b2b64:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b2b68:	add	x0, x19, #0xa8
1004b2b6c:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b2b70:	mov	x0, x22
1004b2b74:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b2b78:	mov	x0, x21
1004b2b7c:	mov	w1, #0x2
1004b2b80:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b2b84:	fadd	d8, d8, d10
1004b2b88:	ldr	x8, [x19, #0x78]
1004b2b8c:	add	x0, x28, x8
1004b2b90:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b2b94:	cbz	x0, 0x1004b2c0c
1004b2b98:	mov	x20, x0
1004b2b9c:	ldr	x8, [x0]
1004b2ba0:	ldr	x8, [x8, #0x260]
1004b2ba4:	blr	x8
1004b2ba8:	mov	x21, x0
1004b2bac:	mov	x0, x20
1004b2bb0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b2bb4:	cbz	x21, 0x1004b2c0c
1004b2bb8:	ldr	x20, [x21, #0x18]
1004b2bbc:	ldr	x8, [x20]
1004b2bc0:	ldr	x8, [x8, #0x78]
1004b2bc4:	blr	x8
1004b2bc8:	mov	x20, x0
1004b2bcc:	ldr	x8, [x0]
1004b2bd0:	ldr	x8, [x8, #0x108]
1004b2bd4:	blr	x8
1004b2bd8:	mov	x22, x0
1004b2bdc:	mov	x0, x20
1004b2be0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b2be4:	cmp	x22, #0x2
1004b2be8:	b.lt	0x1004b2c04
1004b2bec:	mov	x0, x27
1004b2bf0:	mov.16b	v0, v8
1004b2bf4:	mov	x1, x21
1004b2bf8:	mov	x20, x28
1004b2bfc:	bl	0x1004b8048
1004b2c00:	mov.16b	v8, v0
1004b2c04:	mov	x0, x21
1004b2c08:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b2c0c:	mov	x0, x27
1004b2c10:	mov.16b	v0, v8
1004b2c14:	bl	0x1004bfddc
1004b2c18:	mov.16b	v8, v0
1004b2c1c:	adrp	x0, 7464 ; 0x1021da000
1004b2c20:	add	x0, x0, #0x978
1004b2c24:	mov	w1, #0x18
1004b2c28:	mov	w2, #0x7
1004b2c2c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b2c30:	mov	x22, x0
1004b2c34:	add	x0, x0, #0x10
1004b2c38:	mov	x1, x28
1004b2c3c:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b2c40:	mov	x0, #0x0
1004b2c44:	bl	0x1004aede4
1004b2c48:	mov	x21, x0
1004b2c4c:	mov	x0, x22
1004b2c50:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b2c54:	mov	x8, #0x800000000000
1004b2c58:	movk	x8, #0x4071, lsl #48
1004b2c5c:	fmov	d2, x8
1004b2c60:	fmov	d9, #28.00000000
1004b2c64:	movi.2d	v0, #0000000000000000
1004b2c68:	fmov	d3, #28.00000000
1004b2c6c:	mov.16b	v1, v8
1004b2c70:	mov	x20, x21
1004b2c74:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b2c78:	mov	x24, x0
1004b2c7c:	ldr	x8, [x0]
1004b2c80:	ldr	x9, [x26]
1004b2c84:	and	x8, x9, x8
1004b2c88:	ldr	x8, [x8, #0x140]
1004b2c8c:	str	x22, [sp, #-0x10]!
1004b2c90:	adrp	x7, 22 ; 0x1004c8000
1004b2c94:	add	x7, x7, #0x88c
1004b2c98:	mov	w0, #0x6946
1004b2c9c:	movk	w0, #0x646e, lsl #16
1004b2ca0:	mov	x1, #-0x1c00000000000000
1004b2ca4:	mov	w2, #0x8ce2
1004b2ca8:	movk	w2, #0x4698, lsl #16
1004b2cac:	mov	x3, #-0x5c00000000000000
1004b2cb0:	mov	w4, #0x0
1004b2cb4:	mov	x5, #0x0
1004b2cb8:	mov	w6, #0x1
1004b2cbc:	mov	x20, x24
1004b2cc0:	blr	x8
1004b2cc4:	add	sp, sp, #0x10
1004b2cc8:	mov	x0, x27
1004b2ccc:	mov	x2, x24
1004b2cd0:	bl	0x101acb460 ; selector addSubview:
1004b2cd4:	add	x1, x19, #0xa8
1004b2cd8:	mov	x0, x23
1004b2cdc:	mov	w2, #0x21
1004b2ce0:	mov	x3, #0x0
1004b2ce4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b2ce8:	mov	x20, x23
1004b2cec:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b2cf0:	ldr	x8, [x23]
1004b2cf4:	and	x8, x8, #0xffffffffffffff8
1004b2cf8:	ldp	x25, x8, [x8, #0x10]
1004b2cfc:	cmp	x25, x8, lsr #1
1004b2d00:	b.hs	0x1004b4218
1004b2d04:	mov	x0, x24
1004b2d08:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b2d0c:	mov	x24, x0
1004b2d10:	mov	x0, x25
1004b2d14:	mov	x1, x24
1004b2d18:	mov	x20, x23
1004b2d1c:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b2d20:	add	x0, x19, #0xa8
1004b2d24:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b2d28:	mov	x0, x24
1004b2d2c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b2d30:	mov	x0, x22
1004b2d34:	mov	w1, #0x2
1004b2d38:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b2d3c:	fadd	d8, d8, d9
1004b2d40:	adrp	x8, 6439 ; 0x101dd9000
1004b2d44:	add	x8, x8, #0x420 ; literal pool for: "Find in All Tabs"
1004b2d48:	sub	x25, x8, #0x20
1004b2d4c:	adrp	x0, 7464 ; 0x1021da000
1004b2d50:	add	x0, x0, #0x978
1004b2d54:	mov	w1, #0x18
1004b2d58:	mov	w2, #0x7
1004b2d5c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b2d60:	mov	x22, x0
1004b2d64:	add	x0, x0, #0x10
1004b2d68:	mov	x1, x28
1004b2d6c:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b2d70:	mov	x0, x22
1004b2d74:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b2d78:	mov	x8, #0x800000000000
1004b2d7c:	movk	x8, #0x4071, lsl #48
1004b2d80:	fmov	d2, x8
1004b2d84:	movi.2d	v0, #0000000000000000
1004b2d88:	fmov	d3, #28.00000000
1004b2d8c:	mov.16b	v1, v8
1004b2d90:	mov	x20, x21
1004b2d94:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b2d98:	mov	x24, x0
1004b2d9c:	ldr	x8, [x0]
1004b2da0:	ldr	x9, [x26]
1004b2da4:	and	x8, x9, x8
1004b2da8:	ldr	x8, [x8, #0x140]
1004b2dac:	str	x22, [sp, #-0x10]!
1004b2db0:	adrp	x7, 22 ; 0x1004c8000
1004b2db4:	add	x7, x7, #0x878
1004b2db8:	mov	x2, #0x8ce2
1004b2dbc:	movk	x2, #0xe298, lsl #16
1004b2dc0:	movk	x2, #0xa787, lsl #32
1004b2dc4:	movk	x2, #0x46, lsl #48
1004b2dc8:	orr	x1, x25, #0x8000000000000000
1004b2dcc:	mov	x0, #0x10
1004b2dd0:	movk	x0, #0xd000, lsl #48
1004b2dd4:	mov	x3, #-0x5900000000000000
1004b2dd8:	mov	w4, #0x0
1004b2ddc:	mov	x5, #0x0
1004b2de0:	mov	w6, #0x1
1004b2de4:	mov	x20, x24
1004b2de8:	blr	x8
1004b2dec:	add	sp, sp, #0x10
1004b2df0:	mov	x0, x27
1004b2df4:	mov	x2, x24
1004b2df8:	bl	0x101acb460 ; selector addSubview:
1004b2dfc:	add	x1, x19, #0xa8
1004b2e00:	mov	x0, x23
1004b2e04:	mov	w2, #0x21
1004b2e08:	mov	x3, #0x0
1004b2e0c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b2e10:	mov	x20, x23
1004b2e14:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b2e18:	ldr	x8, [x23]
1004b2e1c:	and	x8, x8, #0xffffffffffffff8
1004b2e20:	ldp	x25, x8, [x8, #0x10]
1004b2e24:	cmp	x25, x8, lsr #1
1004b2e28:	b.hs	0x1004b4234
1004b2e2c:	mov	x0, x24
1004b2e30:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b2e34:	mov	x24, x0
1004b2e38:	mov	x0, x25
1004b2e3c:	mov	x1, x24
1004b2e40:	mov	x20, x23
1004b2e44:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b2e48:	add	x0, x19, #0xa8
1004b2e4c:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b2e50:	mov	x0, x24
1004b2e54:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b2e58:	mov	x0, x22
1004b2e5c:	mov	w1, #0x2
1004b2e60:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b2e64:	fadd	d8, d8, d9
1004b2e68:	adrp	x0, 7464 ; 0x1021da000
1004b2e6c:	add	x0, x0, #0x978
1004b2e70:	mov	w1, #0x18
1004b2e74:	mov	w2, #0x7
1004b2e78:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b2e7c:	mov	x22, x0
1004b2e80:	add	x0, x0, #0x10
1004b2e84:	mov	x1, x28
1004b2e88:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b2e8c:	mov	x0, x22
1004b2e90:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b2e94:	mov	x8, #0x800000000000
1004b2e98:	movk	x8, #0x4071, lsl #48
1004b2e9c:	fmov	d2, x8
1004b2ea0:	movi.2d	v0, #0000000000000000
1004b2ea4:	fmov	d3, #28.00000000
1004b2ea8:	mov.16b	v1, v8
1004b2eac:	mov	x20, x21
1004b2eb0:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b2eb4:	mov	x24, x0
1004b2eb8:	ldr	x8, [x0]
1004b2ebc:	ldr	x9, [x26]
1004b2ec0:	and	x8, x9, x8
1004b2ec4:	ldr	x8, [x8, #0x140]
1004b2ec8:	str	x22, [sp, #-0x10]!
1004b2ecc:	adrp	x7, 22 ; 0x1004c8000
1004b2ed0:	add	x7, x7, #0x87c
1004b2ed4:	mov	x0, #0x754a
1004b2ed8:	movk	x0, #0x706d, lsl #16
1004b2edc:	movk	x0, #0x7420, lsl #32
1004b2ee0:	movk	x0, #0x6f, lsl #48
1004b2ee4:	mov	x1, #-0x1900000000000000
1004b2ee8:	mov	w2, #0x8ce2
1004b2eec:	movk	w2, #0x4a98, lsl #16
1004b2ef0:	mov	x3, #-0x5c00000000000000
1004b2ef4:	mov	w4, #0x0
1004b2ef8:	mov	x5, #0x0
1004b2efc:	mov	w6, #0x1
1004b2f00:	mov	x20, x24
1004b2f04:	blr	x8
1004b2f08:	add	sp, sp, #0x10
1004b2f0c:	mov	x0, x27
1004b2f10:	mov	x2, x24
1004b2f14:	bl	0x101acb460 ; selector addSubview:
1004b2f18:	add	x1, x19, #0xa8
1004b2f1c:	mov	x0, x23
1004b2f20:	mov	w2, #0x21
1004b2f24:	mov	x3, #0x0
1004b2f28:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b2f2c:	mov	x20, x23
1004b2f30:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b2f34:	ldr	x8, [x23]
1004b2f38:	and	x8, x8, #0xffffffffffffff8
1004b2f3c:	ldp	x25, x8, [x8, #0x10]
1004b2f40:	cmp	x25, x8, lsr #1
1004b2f44:	b.hs	0x1004b4250
1004b2f48:	mov	x0, x24
1004b2f4c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b2f50:	mov	x24, x0
1004b2f54:	mov	x0, x25
1004b2f58:	mov	x1, x24
1004b2f5c:	mov	x20, x23
1004b2f60:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b2f64:	add	x0, x19, #0xa8
1004b2f68:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b2f6c:	mov	x0, x24
1004b2f70:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b2f74:	mov	x0, x22
1004b2f78:	mov	w1, #0x2
1004b2f7c:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b2f80:	fadd	d8, d8, d9
1004b2f84:	adrp	x0, 7464 ; 0x1021da000
1004b2f88:	add	x0, x0, #0x978
1004b2f8c:	mov	w1, #0x18
1004b2f90:	mov	w2, #0x7
1004b2f94:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b2f98:	mov	x22, x0
1004b2f9c:	add	x0, x0, #0x10
1004b2fa0:	mov	x1, x28
1004b2fa4:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b2fa8:	mov	x0, x22
1004b2fac:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b2fb0:	mov	x8, #0x800000000000
1004b2fb4:	movk	x8, #0x4071, lsl #48
1004b2fb8:	fmov	d2, x8
1004b2fbc:	movi.2d	v0, #0000000000000000
1004b2fc0:	fmov	d3, #28.00000000
1004b2fc4:	mov.16b	v1, v8
1004b2fc8:	mov	x20, x21
1004b2fcc:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b2fd0:	mov	x21, x0
1004b2fd4:	ldr	x8, [x0]
1004b2fd8:	ldr	x9, [x26]
1004b2fdc:	and	x8, x9, x8
1004b2fe0:	ldr	x8, [x8, #0x140]
1004b2fe4:	str	x22, [sp, #-0x10]!
1004b2fe8:	adrp	x7, 22 ; 0x1004c8000
1004b2fec:	add	x7, x7, #0x880
1004b2ff0:	mov	x0, #0x6f43
1004b2ff4:	movk	x0, #0x6d6d, lsl #16
1004b2ff8:	movk	x0, #0x6e61, lsl #32
1004b2ffc:	movk	x0, #0x2064, lsl #48
1004b3000:	mov	x1, #0x6150
1004b3004:	movk	x1, #0x656c, lsl #16
1004b3008:	movk	x1, #0x7474, lsl #32
1004b300c:	movk	x1, #0xef65, lsl #48
1004b3010:	mov	x2, #0x8ce2
1004b3014:	movk	x2, #0xe298, lsl #16
1004b3018:	movk	x2, #0xa787, lsl #32
1004b301c:	movk	x2, #0x50, lsl #48
1004b3020:	mov	x3, #-0x5900000000000000
1004b3024:	mov	w4, #0x0
1004b3028:	mov	x5, #0x0
1004b302c:	mov	w6, #0x1
1004b3030:	mov	x20, x21
1004b3034:	blr	x8
1004b3038:	add	sp, sp, #0x10
1004b303c:	mov	x0, x27
1004b3040:	mov	x2, x21
1004b3044:	bl	0x101acb460 ; selector addSubview:
1004b3048:	add	x1, x19, #0xa8
1004b304c:	mov	x0, x23
1004b3050:	mov	w2, #0x21
1004b3054:	mov	x3, #0x0
1004b3058:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b305c:	mov	x20, x23
1004b3060:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b3064:	ldr	x8, [x23]
1004b3068:	and	x8, x8, #0xffffffffffffff8
1004b306c:	ldp	x24, x8, [x8, #0x10]
1004b3070:	cmp	x24, x8, lsr #1
1004b3074:	b.hs	0x1004b426c
1004b3078:	mov	x0, x21
1004b307c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b3080:	mov	x21, x0
1004b3084:	mov	x0, x24
1004b3088:	mov	x1, x21
1004b308c:	mov	x20, x23
1004b3090:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b3094:	add	x0, x19, #0xa8
1004b3098:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b309c:	mov	x0, x21
1004b30a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b30a4:	mov	x0, x22
1004b30a8:	mov	w1, #0x2
1004b30ac:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b30b0:	fmov	d0, #28.00000000
1004b30b4:	fadd	d0, d8, d0
1004b30b8:	fmov	d1, #8.00000000
1004b30bc:	fadd	d8, d0, d1
1004b30c0:	mov	x0, x27
1004b30c4:	bl	0x101acdcc0 ; selector frame
1004b30c8:	mov	x0, x27
1004b30cc:	mov.16b	v3, v8
1004b30d0:	bl	0x101ad2b80 ; selector setFrame:
1004b30d4:	mov	x0, x27
1004b30d8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b30dc:	mov	x0, x27
1004b30e0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b30e4:	ldr	x0, [x19, #0x90]
1004b30e8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b30ec:	adrp	x1, 14 ; 0x1004c1000
1004b30f0:	add	x1, x1, #0x634
1004b30f4:	ldr	x0, [x19, #0x70]
1004b30f8:	bl	0x100059058
1004b30fc:	b	0x1004b3de8
1004b3100:	mov	x0, x27
1004b3104:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b3108:	mov.16b	v10, v8
1004b310c:	ldr	x21, [x19, #0x78]
1004b3110:	fcmp	d8, d10
1004b3114:	fcsel	d9, d10, d8, mi
1004b3118:	add	x0, x28, x21
1004b311c:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b3120:	mov	x20, x0
1004b3124:	add	x8, x19, #0x1a0
1004b3128:	bl	0x1004f6c60
1004b312c:	mov	x0, x20
1004b3130:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b3134:	ldr	x27, [x19, #0x1b0]
1004b3138:	cbz	x27, 0x1004b31d4
1004b313c:	ldrb	w20, [x19, #0x1a0]
1004b3140:	ldr	w24, [x19, #0x1a4]
1004b3144:	ldr	x25, [x19, #0x1a8]
1004b3148:	ldp	x26, x8, [x19, #0x1b8]
1004b314c:	str	x8, [x19, #0x88]
1004b3150:	ldp	x9, x8, [x19, #0x1c8]
1004b3154:	stp	x8, x9, [x19, #0x68]
1004b3158:	ldrb	w8, [x19, #0x1d8]
1004b315c:	str	w8, [x19, #0x60]
1004b3160:	ldurh	w8, [x23, #0x1]
1004b3164:	sturh	w8, [x29, #-0xe4]
1004b3168:	ldrb	w8, [x19, #0x1a3]
1004b316c:	sturb	w8, [x29, #-0xe2]
1004b3170:	mov	x0, x20
1004b3174:	bl	0x1004f2a1c
1004b3178:	stp	x0, x1, [x19, #0x48]
1004b317c:	add	x8, x19, #0x160
1004b3180:	mov	x0, x20
1004b3184:	bl	0x1004f4c0c
1004b3188:	add	x0, x28, x21
1004b318c:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b3190:	mov	x22, x0
1004b3194:	add	x8, x19, #0xa8
1004b3198:	bl	0x1004fa378
1004b319c:	ldr	x21, [x19, #0xb8]
1004b31a0:	str	x22, [x19, #0x40]
1004b31a4:	stp	x25, x26, [x19]
1004b31a8:	cbz	x21, 0x1004b31e4
1004b31ac:	ldp	x8, x9, [x19, #0xd0]
1004b31b0:	stp	x8, x9, [x19, #0x30]
1004b31b4:	ldp	x8, x9, [x19, #0xc0]
1004b31b8:	stp	x8, x9, [x19, #0x20]
1004b31bc:	ldr	x8, [x19, #0xb0]
1004b31c0:	str	x8, [x19, #0x18]
1004b31c4:	ldp	w8, w9, [x19, #0xa8]
1004b31c8:	stp	w8, w9, [x19, #0x10]
1004b31cc:	ldrb	w8, [x19, #0xe0]
1004b31d0:	b	0x1004b3220
1004b31d4:	fcmp	d8, d10
1004b31d8:	ldr	x23, [x19, #0x58]
1004b31dc:	b.mi	0x1004b3410
1004b31e0:	b	0x1004b3420
1004b31e4:	adrp	x2, 7822 ; 0x102341000
1004b31e8:	add	x2, x2, #0x170
1004b31ec:	adrp	x3, 5699 ; 0x101af6000
1004b31f0:	add	x3, x3, #0x950
1004b31f4:	add	x0, x19, #0x1a0
1004b31f8:	add	x1, x19, #0x120
1004b31fc:	bl	0x10002d8f4
1004b3200:	stp	w20, w24, [x19, #0x10]
1004b3204:	stp	x25, x26, [x19, #0x18]
1004b3208:	mov	x21, x27
1004b320c:	ldr	x9, [x19, #0x88]
1004b3210:	ldp	x8, x10, [x19, #0x68]
1004b3214:	stp	x9, x10, [x19, #0x28]
1004b3218:	str	x8, [x19, #0x38]
1004b321c:	ldr	w8, [x19, #0x60]
1004b3220:	ldr	x23, [x19, #0x58]
1004b3224:	and	w8, w8, #0x1
1004b3228:	str	w8, [x19, #0x58]
1004b322c:	adrp	x0, 7463 ; 0x1021da000
1004b3230:	add	x0, x0, #0x978
1004b3234:	mov	w1, #0x18
1004b3238:	mov	w2, #0x7
1004b323c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b3240:	mov	x25, x0
1004b3244:	add	x0, x0, #0x10
1004b3248:	ldr	x28, [x19, #0xa0]
1004b324c:	mov	x1, x28
1004b3250:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b3254:	add	x0, x19, #0x160
1004b3258:	add	x1, x19, #0x120
1004b325c:	bl	0x10011aaac
1004b3260:	adrp	x0, 7464 ; 0x1021db000
1004b3264:	add	x0, x0, #0xa30
1004b3268:	mov	w1, #0xc1
1004b326c:	mov	w2, #0x7
1004b3270:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b3274:	mov	x26, x0
1004b3278:	ldr	x22, [x19, #0x40]
1004b327c:	stp	x25, x22, [x0, #0x10]
1004b3280:	strb	w20, [x0, #0x20]
1004b3284:	ldurh	w8, [x29, #-0xe4]
1004b3288:	sturh	w8, [x0, #0x21]
1004b328c:	ldurb	w8, [x29, #-0xe2]
1004b3290:	strb	w8, [x0, #0x23]
1004b3294:	str	w24, [x0, #0x24]
1004b3298:	ldp	x9, x10, [x19]
1004b329c:	stp	x9, x27, [x0, #0x28]
1004b32a0:	ldr	x8, [x19, #0x88]
1004b32a4:	stp	x10, x8, [x0, #0x38]
1004b32a8:	ldp	x8, x9, [x19, #0x68]
1004b32ac:	stp	x9, x8, [x0, #0x48]
1004b32b0:	ldr	w8, [x19, #0x60]
1004b32b4:	strb	w8, [x0, #0x58]
1004b32b8:	strb	w20, [x0, #0x59]
1004b32bc:	add	x0, x19, #0x120
1004b32c0:	add	x1, x26, #0x60
1004b32c4:	bl	0x10006d158
1004b32c8:	ldp	w9, w8, [x19, #0x10]
1004b32cc:	strb	w9, [x26, #0x88]
1004b32d0:	str	w8, [x26, #0x8c]
1004b32d4:	ldp	x9, x10, [x19, #0x18]
1004b32d8:	stp	x9, x21, [x26, #0x90]
1004b32dc:	ldp	x9, x11, [x19, #0x28]
1004b32e0:	stp	x10, x9, [x26, #0xa0]
1004b32e4:	ldr	x8, [x19, #0x38]
1004b32e8:	stp	x11, x8, [x26, #0xb0]
1004b32ec:	ldr	w8, [x19, #0x58]
1004b32f0:	strb	w8, [x26, #0xc0]
1004b32f4:	mov	x0, #0x0
1004b32f8:	bl	0x1004ad03c
1004b32fc:	mov	x20, x0
1004b3300:	mov	x0, x25
1004b3304:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b3308:	mov	x0, x22
1004b330c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b3310:	mov	x8, #0x800000000000
1004b3314:	movk	x8, #0x4071, lsl #48
1004b3318:	fmov	d8, x8
1004b331c:	fmov	d10, #28.00000000
1004b3320:	movi.2d	v0, #0000000000000000
1004b3324:	fmov	d3, #28.00000000
1004b3328:	mov.16b	v1, v9
1004b332c:	mov.16b	v2, v8
1004b3330:	bl	0x100096d60
1004b3334:	mov	x27, x0
1004b3338:	ldr	x8, [x0]
1004b333c:	adrp	x9, 7708 ; 0x1022cf000
1004b3340:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b3344:	ldr	x9, [x9]
1004b3348:	and	x8, x9, x8
1004b334c:	ldr	x8, [x8, #0x198]
1004b3350:	adrp	x3, 17 ; 0x1004c4000
1004b3354:	add	x3, x3, #0x22c
1004b3358:	ldp	x0, x21, [x19, #0x48]
1004b335c:	mov	x1, x21
1004b3360:	mov.16b	v0, v8
1004b3364:	mov	x2, x28
1004b3368:	mov	x4, x26
1004b336c:	mov	x5, #0x0
1004b3370:	mov	x6, #0x0
1004b3374:	mov	x20, x27
1004b3378:	blr	x8
1004b337c:	ldr	x0, [x19, #0x98]
1004b3380:	mov	x2, x27
1004b3384:	bl	0x101acb460 ; selector addSubview:
1004b3388:	add	x1, x19, #0x108
1004b338c:	mov	x0, x23
1004b3390:	mov	w2, #0x21
1004b3394:	mov	x3, #0x0
1004b3398:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b339c:	mov	x20, x23
1004b33a0:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b33a4:	ldr	x8, [x23]
1004b33a8:	and	x8, x8, #0xffffffffffffff8
1004b33ac:	ldp	x24, x8, [x8, #0x10]
1004b33b0:	cmp	x24, x8, lsr #1
1004b33b4:	b.hs	0x1004b4288
1004b33b8:	mov	x0, x27
1004b33bc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b33c0:	mov	x27, x0
1004b33c4:	mov	x0, x24
1004b33c8:	mov	x1, x27
1004b33cc:	mov	x20, x23
1004b33d0:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b33d4:	add	x0, x19, #0x108
1004b33d8:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b33dc:	mov	x0, x22
1004b33e0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b33e4:	mov	x0, x27
1004b33e8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b33ec:	mov	x0, x21
1004b33f0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b33f4:	mov	x0, x26
1004b33f8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b33fc:	add	x0, x19, #0x160
1004b3400:	bl	0x10002d8d4
1004b3404:	mov	x0, x25
1004b3408:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b340c:	fadd	d10, d9, d10
1004b3410:	ldr	x0, [x19, #0x98]
1004b3414:	mov.16b	v0, v10
1004b3418:	bl	0x1004bfddc
1004b341c:	mov.16b	v8, v0
1004b3420:	ldr	x27, [x19, #0x90]
1004b3424:	cbz	x27, 0x1004b35e8
1004b3428:	ldr	x8, [x27]
1004b342c:	ldr	x21, [x8, #0x320]
1004b3430:	mov	x0, x27
1004b3434:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b3438:	mov	x20, x27
1004b343c:	blr	x21
1004b3440:	and	w8, w0, #0xff
1004b3444:	cmp	w8, #0x7
1004b3448:	b.ne	0x1004b3458
1004b344c:	mov	x0, x27
1004b3450:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b3454:	b	0x1004b35e8
1004b3458:	adrp	x0, 7463 ; 0x1021da000
1004b345c:	add	x0, x0, #0x978
1004b3460:	mov	w1, #0x18
1004b3464:	mov	w2, #0x7
1004b3468:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b346c:	mov	x21, x0
1004b3470:	add	x0, x0, #0x10
1004b3474:	mov	x1, x28
1004b3478:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b347c:	adrp	x0, 7464 ; 0x1021db000
1004b3480:	add	x0, x0, #0x1e8
1004b3484:	mov	w1, #0x18
1004b3488:	mov	w2, #0x7
1004b348c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b3490:	mov	x22, x0
1004b3494:	add	x0, x0, #0x10
1004b3498:	mov	x1, x27
1004b349c:	bl	0x101acab58 ; symbol stub for: _swift_weakInit
1004b34a0:	adrp	x0, 7464 ; 0x1021db000
1004b34a4:	add	x0, x0, #0xa08
1004b34a8:	mov	w1, #0x20
1004b34ac:	mov	w2, #0x7
1004b34b0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b34b4:	mov	x24, x0
1004b34b8:	stp	x22, x21, [x0, #0x10]
1004b34bc:	mov	x0, #0x0
1004b34c0:	bl	0x1004aede4
1004b34c4:	mov	x20, x0
1004b34c8:	mov	x0, x22
1004b34cc:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b34d0:	mov	x0, x21
1004b34d4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b34d8:	mov	x8, #0x800000000000
1004b34dc:	movk	x8, #0x4071, lsl #48
1004b34e0:	fmov	d2, x8
1004b34e4:	fmov	d9, #28.00000000
1004b34e8:	movi.2d	v0, #0000000000000000
1004b34ec:	fmov	d3, #28.00000000
1004b34f0:	mov.16b	v1, v8
1004b34f4:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b34f8:	mov	x25, x0
1004b34fc:	ldr	x8, [x0]
1004b3500:	adrp	x9, 7708 ; 0x1022cf000
1004b3504:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b3508:	ldr	x9, [x9]
1004b350c:	and	x8, x9, x8
1004b3510:	ldr	x8, [x8, #0x140]
1004b3514:	adrp	x7, 17 ; 0x1004c4000
1004b3518:	add	x7, x7, #0xe4
1004b351c:	str	x24, [sp, #-0x10]!
1004b3520:	mov	x0, #0x6c43
1004b3524:	movk	x0, #0x6165, lsl #16
1004b3528:	movk	x0, #0x2072, lsl #32
1004b352c:	movk	x0, #0x6142, lsl #48
1004b3530:	mov	x1, #0x6764
1004b3534:	movk	x1, #0x65, lsl #16
1004b3538:	movk	x1, #0xeb00, lsl #48
1004b353c:	mov	x2, #0x0
1004b3540:	mov	x3, #0x0
1004b3544:	mov	w4, #0x0
1004b3548:	mov	x5, #0x0
1004b354c:	mov	w6, #0x1
1004b3550:	mov	x20, x25
1004b3554:	blr	x8
1004b3558:	add	sp, sp, #0x10
1004b355c:	ldr	x0, [x19, #0x98]
1004b3560:	mov	x2, x25
1004b3564:	bl	0x101acb460 ; selector addSubview:
1004b3568:	add	x1, x19, #0x120
1004b356c:	mov	x0, x23
1004b3570:	mov	w2, #0x21
1004b3574:	mov	x3, #0x0
1004b3578:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b357c:	mov	x20, x23
1004b3580:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b3584:	ldr	x8, [x23]
1004b3588:	and	x8, x8, #0xffffffffffffff8
1004b358c:	ldp	x26, x8, [x8, #0x10]
1004b3590:	cmp	x26, x8, lsr #1
1004b3594:	b.hs	0x1004b42bc
1004b3598:	mov	x0, x25
1004b359c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b35a0:	mov	x25, x0
1004b35a4:	mov	x0, x26
1004b35a8:	mov	x1, x25
1004b35ac:	mov	x20, x23
1004b35b0:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b35b4:	add	x0, x19, #0x120
1004b35b8:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b35bc:	mov	x0, x21
1004b35c0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b35c4:	mov	x0, x22
1004b35c8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b35cc:	mov	x0, x25
1004b35d0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b35d4:	mov	x0, x27
1004b35d8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b35dc:	mov	x0, x24
1004b35e0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b35e4:	fadd	d8, d8, d9
1004b35e8:	ldr	x24, [x19, #0x98]
1004b35ec:	mov	x0, x24
1004b35f0:	mov.16b	v0, v8
1004b35f4:	mov	x20, x28
1004b35f8:	bl	0x1004b9a34
1004b35fc:	mov	x0, x24
1004b3600:	bl	0x1004bfddc
1004b3604:	mov.16b	v8, v0
1004b3608:	adrp	x0, 7463 ; 0x1021da000
1004b360c:	add	x0, x0, #0x978
1004b3610:	mov	w1, #0x18
1004b3614:	mov	w2, #0x7
1004b3618:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b361c:	mov	x21, x0
1004b3620:	add	x0, x0, #0x10
1004b3624:	mov	x1, x28
1004b3628:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b362c:	mov	x0, #0x0
1004b3630:	bl	0x1004ad03c
1004b3634:	mov	x20, x0
1004b3638:	mov	x0, x21
1004b363c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b3640:	mov	x8, #0x800000000000
1004b3644:	movk	x8, #0x4071, lsl #48
1004b3648:	fmov	d9, x8
1004b364c:	fmov	d10, #28.00000000
1004b3650:	movi.2d	v0, #0000000000000000
1004b3654:	fmov	d3, #28.00000000
1004b3658:	mov.16b	v1, v8
1004b365c:	mov.16b	v2, v9
1004b3660:	bl	0x100096d60
1004b3664:	mov	x22, x0
1004b3668:	ldr	x8, [x0]
1004b366c:	adrp	x27, 7708 ; 0x1022cf000
1004b3670:	ldr	x27, [x27, #0x718] ; literal pool symbol address: _swift_isaMask
1004b3674:	ldr	x9, [x27]
1004b3678:	and	x8, x9, x8
1004b367c:	ldr	x8, [x8, #0x198]
1004b3680:	adrp	x3, 21 ; 0x1004c8000
1004b3684:	add	x3, x3, #0x888
1004b3688:	mov	x0, #0x7053
1004b368c:	movk	x0, #0x696c, lsl #16
1004b3690:	movk	x0, #0x2074, lsl #32
1004b3694:	movk	x0, #0x6956, lsl #48
1004b3698:	mov	x1, #0x7765
1004b369c:	movk	x1, #0xea00, lsl #48
1004b36a0:	mov.16b	v0, v9
1004b36a4:	mov	x2, x28
1004b36a8:	mov	x4, x21
1004b36ac:	mov	x5, #0x0
1004b36b0:	mov	x6, #0x0
1004b36b4:	mov	x20, x22
1004b36b8:	blr	x8
1004b36bc:	mov	x0, x24
1004b36c0:	mov	x2, x22
1004b36c4:	bl	0x101acb460 ; selector addSubview:
1004b36c8:	add	x1, x19, #0x120
1004b36cc:	mov	x0, x23
1004b36d0:	mov	w2, #0x21
1004b36d4:	mov	x3, #0x0
1004b36d8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b36dc:	mov	x20, x23
1004b36e0:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b36e4:	ldr	x8, [x23]
1004b36e8:	and	x8, x8, #0xffffffffffffff8
1004b36ec:	ldp	x24, x8, [x8, #0x10]
1004b36f0:	cmp	x24, x8, lsr #1
1004b36f4:	b.hs	0x1004b4170
1004b36f8:	mov	x0, x22
1004b36fc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b3700:	mov	x22, x0
1004b3704:	mov	x0, x24
1004b3708:	mov	x1, x22
1004b370c:	mov	x20, x23
1004b3710:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b3714:	add	x0, x19, #0x120
1004b3718:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b371c:	mov	x0, x22
1004b3720:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b3724:	mov	x0, x21
1004b3728:	mov	w1, #0x2
1004b372c:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b3730:	fadd	d8, d8, d10
1004b3734:	ldr	x8, [x19, #0x78]
1004b3738:	add	x0, x28, x8
1004b373c:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b3740:	cbz	x0, 0x1004b37b8
1004b3744:	mov	x20, x0
1004b3748:	ldr	x8, [x0]
1004b374c:	ldr	x8, [x8, #0x260]
1004b3750:	blr	x8
1004b3754:	mov	x21, x0
1004b3758:	mov	x0, x20
1004b375c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b3760:	cbz	x21, 0x1004b37b8
1004b3764:	ldr	x20, [x21, #0x18]
1004b3768:	ldr	x8, [x20]
1004b376c:	ldr	x8, [x8, #0x78]
1004b3770:	blr	x8
1004b3774:	mov	x20, x0
1004b3778:	ldr	x8, [x0]
1004b377c:	ldr	x8, [x8, #0x108]
1004b3780:	blr	x8
1004b3784:	mov	x22, x0
1004b3788:	mov	x0, x20
1004b378c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b3790:	cmp	x22, #0x2
1004b3794:	b.lt	0x1004b37b0
1004b3798:	ldr	x0, [x19, #0x98]
1004b379c:	mov.16b	v0, v8
1004b37a0:	mov	x1, x21
1004b37a4:	mov	x20, x28
1004b37a8:	bl	0x1004b8048
1004b37ac:	mov.16b	v8, v0
1004b37b0:	mov	x0, x21
1004b37b4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b37b8:	ldr	x25, [x19, #0x98]
1004b37bc:	mov	x0, x25
1004b37c0:	mov.16b	v0, v8
1004b37c4:	mov	x20, x28
1004b37c8:	bl	0x1004b7b60
1004b37cc:	mov	x0, x25
1004b37d0:	bl	0x1004b7dc8
1004b37d4:	mov	x0, x25
1004b37d8:	bl	0x1004bfddc
1004b37dc:	mov.16b	v8, v0
1004b37e0:	adrp	x0, 7463 ; 0x1021da000
1004b37e4:	add	x0, x0, #0x978
1004b37e8:	mov	w1, #0x18
1004b37ec:	mov	w2, #0x7
1004b37f0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b37f4:	mov	x21, x0
1004b37f8:	add	x0, x0, #0x10
1004b37fc:	mov	x1, x28
1004b3800:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b3804:	mov	x0, #0x0
1004b3808:	bl	0x1004aede4
1004b380c:	mov	x26, x0
1004b3810:	mov	x0, x21
1004b3814:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b3818:	mov	x8, #0x800000000000
1004b381c:	movk	x8, #0x4071, lsl #48
1004b3820:	fmov	d2, x8
1004b3824:	fmov	d9, #28.00000000
1004b3828:	movi.2d	v0, #0000000000000000
1004b382c:	fmov	d3, #28.00000000
1004b3830:	mov.16b	v1, v8
1004b3834:	mov	x20, x26
1004b3838:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b383c:	mov	x22, x0
1004b3840:	ldr	x8, [x0]
1004b3844:	ldr	x9, [x27]
1004b3848:	and	x8, x9, x8
1004b384c:	ldr	x8, [x8, #0x140]
1004b3850:	str	x21, [sp, #-0x10]!
1004b3854:	adrp	x7, 16 ; 0x1004c3000
1004b3858:	add	x7, x7, #0xfd0
1004b385c:	mov	w0, #0x6946
1004b3860:	movk	w0, #0x646e, lsl #16
1004b3864:	mov	x1, #-0x1c00000000000000
1004b3868:	mov	w2, #0x8ce2
1004b386c:	movk	w2, #0x4698, lsl #16
1004b3870:	mov	x3, #-0x5c00000000000000
1004b3874:	mov	w4, #0x0
1004b3878:	mov	x5, #0x0
1004b387c:	mov	w6, #0x1
1004b3880:	mov	x20, x22
1004b3884:	blr	x8
1004b3888:	add	sp, sp, #0x10
1004b388c:	mov	x0, x25
1004b3890:	mov	x2, x22
1004b3894:	bl	0x101acb460 ; selector addSubview:
1004b3898:	add	x1, x19, #0x120
1004b389c:	mov	x0, x23
1004b38a0:	mov	w2, #0x21
1004b38a4:	mov	x3, #0x0
1004b38a8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b38ac:	mov	x20, x23
1004b38b0:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b38b4:	ldr	x8, [x23]
1004b38b8:	and	x8, x8, #0xffffffffffffff8
1004b38bc:	ldp	x24, x8, [x8, #0x10]
1004b38c0:	cmp	x24, x8, lsr #1
1004b38c4:	b.hs	0x1004b418c
1004b38c8:	mov	x0, x22
1004b38cc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b38d0:	mov	x22, x0
1004b38d4:	mov	x0, x24
1004b38d8:	mov	x1, x22
1004b38dc:	mov	x20, x23
1004b38e0:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b38e4:	add	x0, x19, #0x120
1004b38e8:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b38ec:	mov	x0, x22
1004b38f0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b38f4:	mov	x0, x21
1004b38f8:	mov	w1, #0x2
1004b38fc:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b3900:	fadd	d8, d8, d9
1004b3904:	adrp	x8, 6438 ; 0x101dd9000
1004b3908:	add	x8, x8, #0x420 ; literal pool for: "Find in All Tabs"
1004b390c:	sub	x24, x8, #0x20
1004b3910:	adrp	x0, 7463 ; 0x1021da000
1004b3914:	add	x0, x0, #0x978
1004b3918:	mov	w1, #0x18
1004b391c:	mov	w2, #0x7
1004b3920:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b3924:	mov	x21, x0
1004b3928:	add	x0, x0, #0x10
1004b392c:	mov	x1, x28
1004b3930:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b3934:	mov	x0, x21
1004b3938:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b393c:	mov	x8, #0x800000000000
1004b3940:	movk	x8, #0x4071, lsl #48
1004b3944:	fmov	d2, x8
1004b3948:	movi.2d	v0, #0000000000000000
1004b394c:	fmov	d3, #28.00000000
1004b3950:	mov.16b	v1, v8
1004b3954:	mov	x20, x26
1004b3958:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b395c:	mov	x22, x0
1004b3960:	ldr	x8, [x0]
1004b3964:	ldr	x9, [x27]
1004b3968:	and	x8, x9, x8
1004b396c:	ldr	x8, [x8, #0x140]
1004b3970:	str	x21, [sp, #-0x10]!
1004b3974:	adrp	x7, 16 ; 0x1004c3000
1004b3978:	add	x7, x7, #0xfd8
1004b397c:	mov	x2, #0x8ce2
1004b3980:	movk	x2, #0xe298, lsl #16
1004b3984:	movk	x2, #0xa787, lsl #32
1004b3988:	movk	x2, #0x46, lsl #48
1004b398c:	orr	x1, x24, #0x8000000000000000
1004b3990:	mov	x0, #0x10
1004b3994:	movk	x0, #0xd000, lsl #48
1004b3998:	mov	x3, #-0x5900000000000000
1004b399c:	mov	w4, #0x0
1004b39a0:	mov	x5, #0x0
1004b39a4:	mov	w6, #0x1
1004b39a8:	mov	x20, x22
1004b39ac:	blr	x8
1004b39b0:	add	sp, sp, #0x10
1004b39b4:	mov	x0, x25
1004b39b8:	mov	x2, x22
1004b39bc:	bl	0x101acb460 ; selector addSubview:
1004b39c0:	add	x1, x19, #0x120
1004b39c4:	mov	x0, x23
1004b39c8:	mov	w2, #0x21
1004b39cc:	mov	x3, #0x0
1004b39d0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b39d4:	mov	x20, x23
1004b39d8:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b39dc:	ldr	x8, [x23]
1004b39e0:	and	x8, x8, #0xffffffffffffff8
1004b39e4:	ldp	x24, x8, [x8, #0x10]
1004b39e8:	cmp	x24, x8, lsr #1
1004b39ec:	b.hs	0x1004b41a8
1004b39f0:	mov	x0, x22
1004b39f4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b39f8:	mov	x22, x0
1004b39fc:	mov	x0, x24
1004b3a00:	mov	x1, x22
1004b3a04:	mov	x20, x23
1004b3a08:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b3a0c:	add	x0, x19, #0x120
1004b3a10:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b3a14:	mov	x0, x22
1004b3a18:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b3a1c:	mov	x0, x21
1004b3a20:	mov	w1, #0x2
1004b3a24:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b3a28:	fadd	d8, d8, d9
1004b3a2c:	adrp	x0, 7463 ; 0x1021da000
1004b3a30:	add	x0, x0, #0x978
1004b3a34:	mov	w1, #0x18
1004b3a38:	mov	w2, #0x7
1004b3a3c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b3a40:	mov	x21, x0
1004b3a44:	add	x0, x0, #0x10
1004b3a48:	mov	x1, x28
1004b3a4c:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b3a50:	mov	x0, x21
1004b3a54:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b3a58:	mov	x8, #0x800000000000
1004b3a5c:	movk	x8, #0x4071, lsl #48
1004b3a60:	fmov	d2, x8
1004b3a64:	movi.2d	v0, #0000000000000000
1004b3a68:	fmov	d3, #28.00000000
1004b3a6c:	mov.16b	v1, v8
1004b3a70:	mov	x20, x26
1004b3a74:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b3a78:	mov	x22, x0
1004b3a7c:	ldr	x8, [x0]
1004b3a80:	ldr	x9, [x27]
1004b3a84:	and	x8, x9, x8
1004b3a88:	ldr	x8, [x8, #0x140]
1004b3a8c:	str	x21, [sp, #-0x10]!
1004b3a90:	adrp	x7, 21 ; 0x1004c8000
1004b3a94:	add	x7, x7, #0x87c
1004b3a98:	mov	x0, #0x754a
1004b3a9c:	movk	x0, #0x706d, lsl #16
1004b3aa0:	movk	x0, #0x7420, lsl #32
1004b3aa4:	movk	x0, #0x6f, lsl #48
1004b3aa8:	mov	x1, #-0x1900000000000000
1004b3aac:	mov	w2, #0x8ce2
1004b3ab0:	movk	w2, #0x4a98, lsl #16
1004b3ab4:	mov	x3, #-0x5c00000000000000
1004b3ab8:	mov	w4, #0x0
1004b3abc:	mov	x5, #0x0
1004b3ac0:	mov	w6, #0x1
1004b3ac4:	mov	x20, x22
1004b3ac8:	blr	x8
1004b3acc:	add	sp, sp, #0x10
1004b3ad0:	mov	x0, x25
1004b3ad4:	mov	x2, x22
1004b3ad8:	bl	0x101acb460 ; selector addSubview:
1004b3adc:	add	x1, x19, #0x120
1004b3ae0:	mov	x0, x23
1004b3ae4:	mov	w2, #0x21
1004b3ae8:	mov	x3, #0x0
1004b3aec:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b3af0:	mov	x20, x23
1004b3af4:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b3af8:	ldr	x8, [x23]
1004b3afc:	and	x8, x8, #0xffffffffffffff8
1004b3b00:	ldp	x24, x8, [x8, #0x10]
1004b3b04:	cmp	x24, x8, lsr #1
1004b3b08:	b.hs	0x1004b41c4
1004b3b0c:	mov	x0, x22
1004b3b10:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b3b14:	mov	x22, x0
1004b3b18:	mov	x0, x24
1004b3b1c:	mov	x1, x22
1004b3b20:	mov	x20, x23
1004b3b24:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b3b28:	add	x0, x19, #0x120
1004b3b2c:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b3b30:	mov	x0, x22
1004b3b34:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b3b38:	mov	x0, x21
1004b3b3c:	mov	w1, #0x2
1004b3b40:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b3b44:	fadd	d8, d8, d9
1004b3b48:	adrp	x0, 7463 ; 0x1021da000
1004b3b4c:	add	x0, x0, #0x978
1004b3b50:	mov	w1, #0x18
1004b3b54:	mov	w2, #0x7
1004b3b58:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b3b5c:	mov	x21, x0
1004b3b60:	add	x0, x0, #0x10
1004b3b64:	mov	x1, x28
1004b3b68:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b3b6c:	mov	x0, x21
1004b3b70:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b3b74:	mov	x8, #0x800000000000
1004b3b78:	movk	x8, #0x4071, lsl #48
1004b3b7c:	fmov	d2, x8
1004b3b80:	movi.2d	v0, #0000000000000000
1004b3b84:	fmov	d3, #28.00000000
1004b3b88:	mov.16b	v1, v8
1004b3b8c:	mov	x20, x26
1004b3b90:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b3b94:	mov	x22, x0
1004b3b98:	ldr	x8, [x0]
1004b3b9c:	ldr	x9, [x27]
1004b3ba0:	and	x8, x9, x8
1004b3ba4:	ldr	x8, [x8, #0x140]
1004b3ba8:	str	x21, [sp, #-0x10]!
1004b3bac:	adrp	x7, 16 ; 0x1004c3000
1004b3bb0:	add	x7, x7, #0xfe0
1004b3bb4:	mov	x0, #0x6f43
1004b3bb8:	movk	x0, #0x6d6d, lsl #16
1004b3bbc:	movk	x0, #0x6e61, lsl #32
1004b3bc0:	movk	x0, #0x2064, lsl #48
1004b3bc4:	mov	x1, #0x6150
1004b3bc8:	movk	x1, #0x656c, lsl #16
1004b3bcc:	movk	x1, #0x7474, lsl #32
1004b3bd0:	movk	x1, #0xef65, lsl #48
1004b3bd4:	mov	x2, #0x8ce2
1004b3bd8:	movk	x2, #0xe298, lsl #16
1004b3bdc:	movk	x2, #0xa787, lsl #32
1004b3be0:	movk	x2, #0x50, lsl #48
1004b3be4:	mov	x3, #-0x5900000000000000
1004b3be8:	mov	w4, #0x0
1004b3bec:	mov	x5, #0x0
1004b3bf0:	mov	w6, #0x1
1004b3bf4:	mov	x20, x22
1004b3bf8:	blr	x8
1004b3bfc:	add	sp, sp, #0x10
1004b3c00:	mov	x0, x25
1004b3c04:	mov	x2, x22
1004b3c08:	bl	0x101acb460 ; selector addSubview:
1004b3c0c:	add	x1, x19, #0x120
1004b3c10:	mov	x0, x23
1004b3c14:	mov	w2, #0x21
1004b3c18:	mov	x3, #0x0
1004b3c1c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b3c20:	mov	x20, x23
1004b3c24:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b3c28:	ldr	x8, [x23]
1004b3c2c:	and	x8, x8, #0xffffffffffffff8
1004b3c30:	ldp	x24, x8, [x8, #0x10]
1004b3c34:	cmp	x24, x8, lsr #1
1004b3c38:	b.hs	0x1004b41e0
1004b3c3c:	mov	x0, x22
1004b3c40:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b3c44:	mov	x22, x0
1004b3c48:	mov	x0, x24
1004b3c4c:	mov	x1, x22
1004b3c50:	mov	x20, x23
1004b3c54:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b3c58:	add	x0, x19, #0x120
1004b3c5c:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b3c60:	mov	x0, x22
1004b3c64:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b3c68:	mov	x0, x21
1004b3c6c:	mov	w1, #0x2
1004b3c70:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b3c74:	fmov	d0, #28.00000000
1004b3c78:	fadd	d8, d8, d0
1004b3c7c:	ldr	x8, [x19, #0x78]
1004b3c80:	add	x0, x28, x8
1004b3c84:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b3c88:	cbz	x0, 0x1004b3db0
1004b3c8c:	ldr	x8, [x0]
1004b3c90:	ldr	x8, [x8, #0x260]
1004b3c94:	mov	x20, x0
1004b3c98:	mov	x21, x0
1004b3c9c:	blr	x8
1004b3ca0:	mov	x20, x0
1004b3ca4:	mov	x0, x21
1004b3ca8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b3cac:	cbz	x20, 0x1004b3db0
1004b3cb0:	ldr	x21, [x20, #0x18]
1004b3cb4:	mov	x0, x21
1004b3cb8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b3cbc:	mov	x0, x20
1004b3cc0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b3cc4:	ldr	x8, [x21]
1004b3cc8:	ldr	x8, [x8, #0x78]
1004b3ccc:	mov	x20, x21
1004b3cd0:	blr	x8
1004b3cd4:	mov	x20, x0
1004b3cd8:	mov	x0, x21
1004b3cdc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b3ce0:	ldr	x8, [x20]
1004b3ce4:	ldr	x8, [x8, #0x108]
1004b3ce8:	blr	x8
1004b3cec:	mov	x21, x0
1004b3cf0:	mov	x0, x20
1004b3cf4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b3cf8:	cmp	x21, #0x2
1004b3cfc:	b.lt	0x1004b3db0
1004b3d00:	ldr	x0, [x19, #0x98]
1004b3d04:	mov.16b	v0, v8
1004b3d08:	bl	0x1004bfddc
1004b3d0c:	mov.16b	v8, v0
1004b3d10:	bl	0x100609210
1004b3d14:	ldr	x20, [x0]
1004b3d18:	ldr	x8, [x20]
1004b3d1c:	ldr	x21, [x8, #0x108]
1004b3d20:	mov	x0, x20
1004b3d24:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b3d28:	mov	w0, #0xd
1004b3d2c:	blr	x21
1004b3d30:	mov	x22, x0
1004b3d34:	mov	x0, x20
1004b3d38:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b3d3c:	ldr	x8, [x22, #0x10]
1004b3d40:	cbz	x8, 0x1004b3e14
1004b3d44:	str	x22, [x19, #0x120]
1004b3d48:	adrp	x20, 7823 ; 0x102342000
1004b3d4c:	add	x20, x20, #0xa20
1004b3d50:	adrp	x21, 5679 ; 0x101ae2000
1004b3d54:	add	x21, x21, #0x2f0
1004b3d58:	mov	x0, x20
1004b3d5c:	mov	x1, x21
1004b3d60:	bl	0x100003c4c
1004b3d64:	mov	x24, x0
1004b3d68:	adrp	x0, 7822 ; 0x102341000
1004b3d6c:	add	x0, x0, #0x7a0
1004b3d70:	adrp	x3, 7707 ; 0x1022ce000
1004b3d74:	ldr	x3, [x3, #0x220] ; literal pool symbol address: _$sSayxGSKsMc
1004b3d78:	mov	x1, x20
1004b3d7c:	mov	x2, x21
1004b3d80:	bl	0x10002b714
1004b3d84:	mov	x3, x0
1004b3d88:	add	x20, x19, #0x120
1004b3d8c:	mov	x0, #0x0
1004b3d90:	mov	x1, #-0x2000000000000000
1004b3d94:	mov	x2, x24
1004b3d98:	bl	0x101ac60b8 ; symbol stub for: _$sSKsSS7ElementRtzrlE6joined9separatorS2S_tF
1004b3d9c:	mov	x24, x0
1004b3da0:	mov	x21, x1
1004b3da4:	mov	x0, x22
1004b3da8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b3dac:	b	0x1004b3e24
1004b3db0:	ldr	x26, [x19, #0x98]
1004b3db4:	fmov	d0, #8.00000000
1004b3db8:	fadd	d8, d8, d0
1004b3dbc:	mov	x0, x26
1004b3dc0:	bl	0x101acdcc0 ; selector frame
1004b3dc4:	mov	x0, x26
1004b3dc8:	mov.16b	v3, v8
1004b3dcc:	bl	0x101ad2b80 ; selector setFrame:
1004b3dd0:	mov	x0, x26
1004b3dd4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b3dd8:	mov	x0, x26
1004b3ddc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b3de0:	ldr	x0, [x19, #0x90]
1004b3de4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b3de8:	ldr	x0, [x19, #0x80]
1004b3dec:	sub	sp, x29, #0x70
1004b3df0:	ldp	x29, x30, [sp, #0x70]
1004b3df4:	ldp	x20, x19, [sp, #0x60]
1004b3df8:	ldp	x22, x21, [sp, #0x50]
1004b3dfc:	ldp	x24, x23, [sp, #0x40]
1004b3e00:	ldp	x26, x25, [sp, #0x30]
1004b3e04:	ldp	x28, x27, [sp, #0x20]
1004b3e08:	ldp	d9, d8, [sp, #0x10]
1004b3e0c:	ldp	d11, d10, [sp], #0x80
1004b3e10:	ret
1004b3e14:	mov	x0, x22
1004b3e18:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b3e1c:	mov	x24, #0x0
1004b3e20:	mov	x21, #0x0
1004b3e24:	adrp	x0, 7463 ; 0x1021da000
1004b3e28:	add	x0, x0, #0x978
1004b3e2c:	mov	w1, #0x18
1004b3e30:	mov	w2, #0x7
1004b3e34:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b3e38:	mov	x22, x0
1004b3e3c:	add	x0, x0, #0x10
1004b3e40:	mov	x1, x28
1004b3e44:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b3e48:	mov	x0, x22
1004b3e4c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b3e50:	mov	x8, #0x800000000000
1004b3e54:	movk	x8, #0x4071, lsl #48
1004b3e58:	fmov	d2, x8
1004b3e5c:	movi.2d	v0, #0000000000000000
1004b3e60:	fmov	d3, #28.00000000
1004b3e64:	mov.16b	v1, v8
1004b3e68:	mov	x20, x26
1004b3e6c:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b3e70:	mov	x25, x0
1004b3e74:	ldr	x8, [x0]
1004b3e78:	ldr	x9, [x27]
1004b3e7c:	and	x8, x9, x8
1004b3e80:	ldr	x8, [x8, #0x140]
1004b3e84:	str	x22, [sp, #-0x10]!
1004b3e88:	adrp	x7, 16 ; 0x1004c3000
1004b3e8c:	add	x7, x7, #0xfe8
1004b3e90:	mov	x0, #0x6c43
1004b3e94:	movk	x0, #0x736f, lsl #16
1004b3e98:	movk	x0, #0x2065, lsl #32
1004b3e9c:	movk	x0, #0x6150, lsl #48
1004b3ea0:	mov	x1, #0x656e
1004b3ea4:	movk	x1, #0xea00, lsl #48
1004b3ea8:	mov	x2, x24
1004b3eac:	mov	x3, x21
1004b3eb0:	mov	w4, #0x0
1004b3eb4:	mov	x5, #0x0
1004b3eb8:	mov	w6, #0x1
1004b3ebc:	mov	x20, x25
1004b3ec0:	blr	x8
1004b3ec4:	add	sp, sp, #0x10
1004b3ec8:	ldr	x26, [x19, #0x98]
1004b3ecc:	mov	x0, x26
1004b3ed0:	mov	x2, x25
1004b3ed4:	bl	0x101acb460 ; selector addSubview:
1004b3ed8:	add	x1, x19, #0x120
1004b3edc:	mov	x0, x23
1004b3ee0:	mov	w2, #0x21
1004b3ee4:	mov	x3, #0x0
1004b3ee8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b3eec:	mov	x20, x23
1004b3ef0:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b3ef4:	ldr	x8, [x23]
1004b3ef8:	and	x8, x8, #0xffffffffffffff8
1004b3efc:	ldp	x24, x8, [x8, #0x10]
1004b3f00:	cmp	x24, x8, lsr #1
1004b3f04:	b.hs	0x1004b42d8
1004b3f08:	mov	x0, x25
1004b3f0c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b3f10:	mov	x25, x0
1004b3f14:	mov	x0, x24
1004b3f18:	mov	x1, x25
1004b3f1c:	mov	x20, x23
1004b3f20:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b3f24:	add	x0, x19, #0x120
1004b3f28:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b3f2c:	mov	x0, x25
1004b3f30:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b3f34:	mov	x0, x22
1004b3f38:	mov	w1, #0x2
1004b3f3c:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b3f40:	mov	x0, x21
1004b3f44:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b3f48:	fadd	d8, d8, d9
1004b3f4c:	b	0x1004b3db4
1004b3f50:	ldr	x27, [x19, #0x98]
1004b3f54:	adrp	x0, 7463 ; 0x1021da000
1004b3f58:	add	x0, x0, #0x978
1004b3f5c:	mov	w1, #0x18
1004b3f60:	mov	w2, #0x7
1004b3f64:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b3f68:	mov	x24, x0
1004b3f6c:	add	x0, x0, #0x10
1004b3f70:	ldr	x20, [x19, #0xa0]
1004b3f74:	mov	x1, x20
1004b3f78:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b3f7c:	adrp	x0, 7464 ; 0x1021db000
1004b3f80:	add	x0, x0, #0xaa8
1004b3f84:	mov	w1, #0x98
1004b3f88:	mov	w2, #0x7
1004b3f8c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b3f90:	mov	x26, x0
1004b3f94:	add	x9, x19, #0x1a0
1004b3f98:	ldp	q0, q1, [x9, #0x60]
1004b3f9c:	stp	q0, q1, [x0, #0x30]
1004b3fa0:	ldr	q0, [x9, #0x80]
1004b3fa4:	str	q0, [x0, #0x50]
1004b3fa8:	ldurb	w8, [x29, #-0x90]
1004b3fac:	strb	w8, [x0, #0x60]
1004b3fb0:	ldp	q0, q1, [x9, #0x40]
1004b3fb4:	stp	q0, q1, [x0, #0x10]
1004b3fb8:	stp	x24, x22, [x0, #0x68]
1004b3fbc:	stp	x21, x25, [x0, #0x78]
1004b3fc0:	str	x28, [x0, #0x88]
1004b3fc4:	mov	x28, x20
1004b3fc8:	ldr	x22, [x19, #0x88]
1004b3fcc:	str	x22, [x0, #0x90]
1004b3fd0:	mov	x0, #0x0
1004b3fd4:	bl	0x1004ad03c
1004b3fd8:	mov	x20, x0
1004b3fdc:	mov	x0, x22
1004b3fe0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b3fe4:	str	x0, [x19, #0x88]
1004b3fe8:	mov	x0, x21
1004b3fec:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b3ff0:	add	x1, x19, #0xa8
1004b3ff4:	ldr	x0, [x19, #0x68]
1004b3ff8:	bl	0x1004c59ac
1004b3ffc:	mov	x22, x24
1004b4000:	mov	x0, x24
1004b4004:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b4008:	mov	x8, #0x800000000000
1004b400c:	movk	x8, #0x4071, lsl #48
1004b4010:	fmov	d9, x8
1004b4014:	fmov	d10, #28.00000000
1004b4018:	movi.2d	v0, #0000000000000000
1004b401c:	fmov	d3, #28.00000000
1004b4020:	mov.16b	v1, v8
1004b4024:	mov.16b	v2, v9
1004b4028:	bl	0x100096d60
1004b402c:	mov	x25, x0
1004b4030:	ldr	x8, [x0]
1004b4034:	adrp	x9, 7707 ; 0x1022cf000
1004b4038:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b403c:	ldr	x9, [x9]
1004b4040:	and	x8, x9, x8
1004b4044:	ldr	x8, [x8, #0x198]
1004b4048:	adrp	x3, 17 ; 0x1004c5000
1004b404c:	add	x3, x3, #0xae8
1004b4050:	mov	w0, #0x6947
1004b4054:	movk	w0, #0x74, lsl #16
1004b4058:	mov	x1, #-0x1d00000000000000
1004b405c:	mov.16b	v0, v9
1004b4060:	mov	x2, x28
1004b4064:	mov	x4, x26
1004b4068:	mov	x5, #0x0
1004b406c:	mov	x6, #0x0
1004b4070:	mov	x20, x25
1004b4074:	blr	x8
1004b4078:	mov	x0, x27
1004b407c:	mov	x2, x25
1004b4080:	bl	0x101acb460 ; selector addSubview:
1004b4084:	add	x1, x19, #0xa8
1004b4088:	mov	x0, x23
1004b408c:	mov	w2, #0x21
1004b4090:	mov	x3, #0x0
1004b4094:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b4098:	mov	x20, x23
1004b409c:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b40a0:	ldr	x8, [x23]
1004b40a4:	and	x8, x8, #0xffffffffffffff8
1004b40a8:	mov	x24, x27
1004b40ac:	ldp	x27, x8, [x8, #0x10]
1004b40b0:	cmp	x27, x8, lsr #1
1004b40b4:	b.hs	0x1004b42f4
1004b40b8:	mov	x0, x25
1004b40bc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b40c0:	mov	x25, x0
1004b40c4:	mov	x0, x27
1004b40c8:	mov	x1, x25
1004b40cc:	mov	x20, x23
1004b40d0:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b40d4:	add	x0, x19, #0xa8
1004b40d8:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b40dc:	mov	x0, x22
1004b40e0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b40e4:	mov	x0, x25
1004b40e8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b40ec:	mov	x0, x26
1004b40f0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b40f4:	mov	x0, x21
1004b40f8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b40fc:	fadd	d0, d8, d10
1004b4100:	mov	x0, x24
1004b4104:	bl	0x1004bfddc
1004b4108:	mov.16b	v8, v0
1004b410c:	mov	x27, x24
1004b4110:	ldr	x26, [x19, #0x38]
1004b4114:	ldr	x0, [x19, #0x88]
1004b4118:	b	0x1004b2a50
1004b411c:	cmp	x8, #0x1
1004b4120:	cset	w0, hi
1004b4124:	add	x1, x26, #0x1
1004b4128:	mov	w2, #0x1
1004b412c:	mov	x20, x23
1004b4130:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b4134:	b	0x1004b248c
1004b4138:	cmp	x8, #0x1
1004b413c:	cset	w0, hi
1004b4140:	add	x1, x26, #0x1
1004b4144:	mov	w2, #0x1
1004b4148:	mov	x20, x23
1004b414c:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b4150:	b	0x1004b25a8
1004b4154:	cmp	x8, #0x1
1004b4158:	cset	w0, hi
1004b415c:	add	x1, x25, #0x1
1004b4160:	mov	w2, #0x1
1004b4164:	mov	x20, x23
1004b4168:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b416c:	b	0x1004b26d8
1004b4170:	cmp	x8, #0x1
1004b4174:	cset	w0, hi
1004b4178:	add	x1, x24, #0x1
1004b417c:	mov	w2, #0x1
1004b4180:	mov	x20, x23
1004b4184:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b4188:	b	0x1004b36f8
1004b418c:	cmp	x8, #0x1
1004b4190:	cset	w0, hi
1004b4194:	add	x1, x24, #0x1
1004b4198:	mov	w2, #0x1
1004b419c:	mov	x20, x23
1004b41a0:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b41a4:	b	0x1004b38c8
1004b41a8:	cmp	x8, #0x1
1004b41ac:	cset	w0, hi
1004b41b0:	add	x1, x24, #0x1
1004b41b4:	mov	w2, #0x1
1004b41b8:	mov	x20, x23
1004b41bc:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b41c0:	b	0x1004b39f0
1004b41c4:	cmp	x8, #0x1
1004b41c8:	cset	w0, hi
1004b41cc:	add	x1, x24, #0x1
1004b41d0:	mov	w2, #0x1
1004b41d4:	mov	x20, x23
1004b41d8:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b41dc:	b	0x1004b3b0c
1004b41e0:	cmp	x8, #0x1
1004b41e4:	cset	w0, hi
1004b41e8:	add	x1, x24, #0x1
1004b41ec:	mov	w2, #0x1
1004b41f0:	mov	x20, x23
1004b41f4:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b41f8:	b	0x1004b3c3c
1004b41fc:	cmp	x8, #0x1
1004b4200:	cset	w0, hi
1004b4204:	add	x1, x24, #0x1
1004b4208:	mov	w2, #0x1
1004b420c:	mov	x20, x23
1004b4210:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b4214:	b	0x1004b2b4c
1004b4218:	cmp	x8, #0x1
1004b421c:	cset	w0, hi
1004b4220:	add	x1, x25, #0x1
1004b4224:	mov	w2, #0x1
1004b4228:	mov	x20, x23
1004b422c:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b4230:	b	0x1004b2d04
1004b4234:	cmp	x8, #0x1
1004b4238:	cset	w0, hi
1004b423c:	add	x1, x25, #0x1
1004b4240:	mov	w2, #0x1
1004b4244:	mov	x20, x23
1004b4248:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b424c:	b	0x1004b2e2c
1004b4250:	cmp	x8, #0x1
1004b4254:	cset	w0, hi
1004b4258:	add	x1, x25, #0x1
1004b425c:	mov	w2, #0x1
1004b4260:	mov	x20, x23
1004b4264:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b4268:	b	0x1004b2f48
1004b426c:	cmp	x8, #0x1
1004b4270:	cset	w0, hi
1004b4274:	add	x1, x24, #0x1
1004b4278:	mov	w2, #0x1
1004b427c:	mov	x20, x23
1004b4280:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b4284:	b	0x1004b3078
1004b4288:	cmp	x8, #0x1
1004b428c:	cset	w0, hi
1004b4290:	add	x1, x24, #0x1
1004b4294:	mov	w2, #0x1
1004b4298:	mov	x20, x23
1004b429c:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b42a0:	b	0x1004b33b8
1004b42a4:	cmp	x8, #0x1
1004b42a8:	cset	w0, hi
1004b42ac:	add	x1, x27, #0x1
1004b42b0:	mov	w2, #0x1
1004b42b4:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b42b8:	b	0x1004b2310
1004b42bc:	cmp	x8, #0x1
1004b42c0:	cset	w0, hi
1004b42c4:	add	x1, x26, #0x1
1004b42c8:	mov	w2, #0x1
1004b42cc:	mov	x20, x23
1004b42d0:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b42d4:	b	0x1004b3598
1004b42d8:	cmp	x8, #0x1
1004b42dc:	cset	w0, hi
1004b42e0:	add	x1, x24, #0x1
1004b42e4:	mov	w2, #0x1
1004b42e8:	mov	x20, x23
1004b42ec:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b42f0:	b	0x1004b3f08
1004b42f4:	cmp	x8, #0x1
1004b42f8:	cset	w0, hi
1004b42fc:	add	x1, x27, #0x1
1004b4300:	mov	w2, #0x1
1004b4304:	mov	x20, x23
1004b4308:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004b430c:	b	0x1004b40b8
1004b4310:	brk	#0x1
1004b4314:	stp	x28, x27, [sp, #-0x60]!
1004b4318:	stp	x26, x25, [sp, #0x10]
1004b431c:	stp	x24, x23, [sp, #0x20]
1004b4320:	stp	x22, x21, [sp, #0x30]
1004b4324:	stp	x20, x19, [sp, #0x40]
1004b4328:	stp	x29, x30, [sp, #0x50]
1004b432c:	add	x29, sp, #0x50
1004b4330:	sub	sp, sp, #0xb0
1004b4334:	mov	x24, x2
1004b4338:	mov	x25, x1
1004b433c:	mov	x26, x0
1004b4340:	mov	x0, #0x0
1004b4344:	bl	0x101ac5d88 ; symbol stub for: _$s8Dispatch0A13WorkItemFlagsVMa
1004b4348:	mov	x19, x0
1004b434c:	ldur	x28, [x0, #-0x8]
1004b4350:	ldr	x8, [x28, #0x40]
1004b4354:	mov	x9, x8
1004b4358:	adrp	x16, 7703 ; 0x1022cb000
1004b435c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b4360:	blr	x16
1004b4364:	mov	x9, sp
1004b4368:	add	x8, x8, #0xf
1004b436c:	and	x8, x8, #0xfffffffffffffff0
1004b4370:	sub	x21, x9, x8
1004b4374:	mov	sp, x21
1004b4378:	mov	x0, #0x0
1004b437c:	bl	0x101ac5dc4 ; symbol stub for: _$s8Dispatch0A3QoSVMa
1004b4380:	ldur	x8, [x0, #-0x8]
1004b4384:	stp	x8, x0, [x29, #-0xf0]
1004b4388:	ldr	x8, [x8, #0x40]
1004b438c:	mov	x9, x8
1004b4390:	adrp	x16, 7703 ; 0x1022cb000
1004b4394:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b4398:	blr	x16
1004b439c:	mov	x9, sp
1004b43a0:	add	x8, x8, #0xf
1004b43a4:	and	x8, x8, #0xfffffffffffffff0
1004b43a8:	sub	x23, x9, x8
1004b43ac:	mov	sp, x23
1004b43b0:	bl	0x100603a08
1004b43b4:	adrp	x22, 7707 ; 0x1022cf000
1004b43b8:	ldr	x22, [x22, #0x718] ; literal pool symbol address: _swift_isaMask
1004b43bc:	cbz	x0, 0x1004b43e8
1004b43c0:	mov	x20, x0
1004b43c4:	ldr	x8, [x0]
1004b43c8:	ldr	x9, [x22]
1004b43cc:	and	x8, x9, x8
1004b43d0:	ldr	x8, [x8, #0x278]
1004b43d4:	blr	x8
1004b43d8:	mov	x27, x0
1004b43dc:	mov	x0, x20
1004b43e0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b43e4:	cbnz	x27, 0x1004b4408
1004b43e8:	adrp	x8, 7702 ; 0x1022ca000
1004b43ec:	ldr	x8, [x8, #0x558] ; literal pool symbol address: _NSApp
1004b43f0:	ldr	x0, [x8]
1004b43f4:	cbz	x0, 0x1004b461c
1004b43f8:	bl	0x101acf6c0 ; selector mainWindow
1004b43fc:	mov	x29, x29
1004b4400:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4404:	mov	x27, x0
1004b4408:	stur	x28, [x29, #-0xf8]
1004b440c:	add	x0, x26, #0x10
1004b4410:	sub	x1, x29, #0x70
1004b4414:	mov	x2, #0x0
1004b4418:	mov	x3, #0x0
1004b441c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b4420:	add	x0, x26, #0x10
1004b4424:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004b4428:	cbz	x0, 0x1004b444c
1004b442c:	mov	x20, x0
1004b4430:	ldr	x8, [x0]
1004b4434:	ldr	x9, [x22]
1004b4438:	and	x8, x9, x8
1004b443c:	ldr	x8, [x8, #0x248]
1004b4440:	blr	x8
1004b4444:	mov	x0, x20
1004b4448:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b444c:	adrp	x1, 7820 ; 0x102340000
1004b4450:	add	x1, x1, #0xc40
1004b4454:	adrp	x2, 7794 ; 0x102326000
1004b4458:	add	x2, x2, #0x9d8 ; Objc class ref: _OBJC_CLASS_$_OS_dispatch_queue
1004b445c:	mov	x0, #0x0
1004b4460:	bl	0x10002d97c
1004b4464:	mov	x20, x0
1004b4468:	bl	0x101ac6e44 ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE4mainABvgZ
1004b446c:	mov	x26, x0
1004b4470:	adrp	x0, 7464 ; 0x1021dc000
1004b4474:	add	x0, x0, #0x598
1004b4478:	mov	w1, #0x60
1004b447c:	mov	w2, #0x7
1004b4480:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b4484:	ldp	q0, q1, [x24]
1004b4488:	stur	q0, [x0, #0x18]
1004b448c:	str	x25, [x0, #0x10]
1004b4490:	stur	q1, [x0, #0x28]
1004b4494:	ldr	q0, [x24, #0x20]
1004b4498:	stur	q0, [x0, #0x38]
1004b449c:	ldur	q0, [x24, #0x29]
1004b44a0:	stur	q0, [x0, #0x41]
1004b44a4:	str	x27, [x0, #0x58]
1004b44a8:	adrp	x8, 19 ; 0x1004c7000
1004b44ac:	add	x8, x8, #0x320
1004b44b0:	stp	x8, x0, [x29, #-0x80]
1004b44b4:	adrp	x8, 7703 ; 0x1022cb000
1004b44b8:	ldr	x8, [x8, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1004b44bc:	stur	x8, [x29, #-0xa0]
1004b44c0:	adrp	x8, 5677 ; 0x101ae1000
1004b44c4:	ldr	d0, [x8]
1004b44c8:	stur	d0, [x29, #-0x98]
1004b44cc:	adrp	x8, -1200 ; 0x100004000
1004b44d0:	add	x8, x8, #0xd0
1004b44d4:	adrp	x9, 7464 ; 0x1021dc000
1004b44d8:	add	x9, x9, #0x5b0
1004b44dc:	stp	x8, x9, [x29, #-0x90]
1004b44e0:	sub	x0, x29, #0xa0
1004b44e4:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004b44e8:	mov	x28, x0
1004b44ec:	ldur	x20, [x29, #-0x78]
1004b44f0:	mov	x0, x25
1004b44f4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b44f8:	sub	x1, x29, #0xe0
1004b44fc:	mov	x0, x24
1004b4500:	bl	0x1004c6644
1004b4504:	mov	x0, x27
1004b4508:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b450c:	mov	x24, x0
1004b4510:	mov	x0, x20
1004b4514:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b4518:	mov	x8, x23
1004b451c:	bl	0x101ac5da0 ; symbol stub for: _$s8Dispatch0A3QoSV11unspecifiedACvgZ
1004b4520:	adrp	x8, 7707 ; 0x1022cf000
1004b4524:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004b4528:	stur	x8, [x29, #-0xe0]
1004b452c:	adrp	x0, 7822 ; 0x102342000
1004b4530:	add	x0, x0, #0x2e0
1004b4534:	adrp	x1, 7707 ; 0x1022cf000
1004b4538:	ldr	x1, [x1, #0x930] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVMa
1004b453c:	adrp	x2, 7707 ; 0x1022cf000
1004b4540:	ldr	x2, [x2, #0x940] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVs10SetAlgebraAAMc
1004b4544:	bl	0x10002c7c4
1004b4548:	mov	x25, x0
1004b454c:	adrp	x20, 7820 ; 0x102340000
1004b4550:	add	x20, x20, #0xc50
1004b4554:	adrp	x27, 5677 ; 0x101ae1000
1004b4558:	add	x27, x27, #0x280
1004b455c:	mov	x0, x20
1004b4560:	mov	x1, x27
1004b4564:	bl	0x100003c4c
1004b4568:	mov	x22, x0
1004b456c:	adrp	x0, 7822 ; 0x102342000
1004b4570:	add	x0, x0, #0x2f0
1004b4574:	adrp	x3, 7706 ; 0x1022ce000
1004b4578:	ldr	x3, [x3, #0x238] ; literal pool symbol address: _$sSayxGSTsMc
1004b457c:	mov	x1, x20
1004b4580:	mov	x2, x27
1004b4584:	bl	0x10002b714
1004b4588:	mov	x2, x0
1004b458c:	sub	x0, x29, #0xe0
1004b4590:	mov	x8, x21
1004b4594:	mov	x1, x22
1004b4598:	mov	x20, x19
1004b459c:	mov	x3, x19
1004b45a0:	mov	x4, x25
1004b45a4:	bl	0x101ac7450 ; symbol stub for: _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
1004b45a8:	mov	x0, #0x0
1004b45ac:	mov	x1, x23
1004b45b0:	mov	x2, x21
1004b45b4:	mov	x3, x28
1004b45b8:	mov	x20, x26
1004b45bc:	bl	0x101ac6e5c ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE5async5group3qos5flags7executeySo0a1_b1_F0CSg_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
1004b45c0:	mov	x0, x28
1004b45c4:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004b45c8:	mov	x0, x24
1004b45cc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b45d0:	mov	x0, x26
1004b45d4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b45d8:	ldur	x8, [x29, #-0xf8]
1004b45dc:	ldr	x8, [x8, #0x8]
1004b45e0:	mov	x0, x21
1004b45e4:	mov	x1, x19
1004b45e8:	blr	x8
1004b45ec:	ldp	x8, x1, [x29, #-0xf0]
1004b45f0:	ldr	x8, [x8, #0x8]
1004b45f4:	mov	x0, x23
1004b45f8:	blr	x8
1004b45fc:	sub	sp, x29, #0x50
1004b4600:	ldp	x29, x30, [sp, #0x50]
1004b4604:	ldp	x20, x19, [sp, #0x40]
1004b4608:	ldp	x22, x21, [sp, #0x30]
1004b460c:	ldp	x24, x23, [sp, #0x20]
1004b4610:	ldp	x26, x25, [sp, #0x10]
1004b4614:	ldp	x28, x27, [sp], #0x60
1004b4618:	ret
1004b461c:	brk	#0x1
1004b4620:	stp	x28, x27, [sp, #-0x60]!
1004b4624:	stp	x26, x25, [sp, #0x10]
1004b4628:	stp	x24, x23, [sp, #0x20]
1004b462c:	stp	x22, x21, [sp, #0x30]
1004b4630:	stp	x20, x19, [sp, #0x40]
1004b4634:	stp	x29, x30, [sp, #0x50]
1004b4638:	add	x29, sp, #0x50
1004b463c:	sub	sp, sp, #0xa0
1004b4640:	mov	x24, x2
1004b4644:	mov	x25, x1
1004b4648:	mov	x20, x0
1004b464c:	mov	x0, #0x0
1004b4650:	bl	0x101ac5d88 ; symbol stub for: _$s8Dispatch0A13WorkItemFlagsVMa
1004b4654:	mov	x19, x0
1004b4658:	ldur	x8, [x0, #-0x8]
1004b465c:	stur	x8, [x29, #-0xe8]
1004b4660:	ldr	x8, [x8, #0x40]
1004b4664:	mov	x9, x8
1004b4668:	adrp	x16, 7703 ; 0x1022cb000
1004b466c:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b4670:	blr	x16
1004b4674:	mov	x9, sp
1004b4678:	add	x8, x8, #0xf
1004b467c:	and	x8, x8, #0xfffffffffffffff0
1004b4680:	sub	x21, x9, x8
1004b4684:	mov	sp, x21
1004b4688:	mov	x0, #0x0
1004b468c:	bl	0x101ac5dc4 ; symbol stub for: _$s8Dispatch0A3QoSVMa
1004b4690:	stur	x0, [x29, #-0xf0]
1004b4694:	ldur	x22, [x0, #-0x8]
1004b4698:	ldr	x8, [x22, #0x40]
1004b469c:	mov	x9, x8
1004b46a0:	adrp	x16, 7703 ; 0x1022cb000
1004b46a4:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b46a8:	blr	x16
1004b46ac:	mov	x9, sp
1004b46b0:	add	x8, x8, #0xf
1004b46b4:	and	x8, x8, #0xfffffffffffffff0
1004b46b8:	sub	x23, x9, x8
1004b46bc:	mov	sp, x23
1004b46c0:	add	x0, x20, #0x10
1004b46c4:	sub	x1, x29, #0x70
1004b46c8:	mov	x2, #0x0
1004b46cc:	mov	x3, #0x0
1004b46d0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b46d4:	add	x0, x20, #0x10
1004b46d8:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004b46dc:	cbz	x0, 0x1004b4708
1004b46e0:	mov	x20, x0
1004b46e4:	ldr	x8, [x0]
1004b46e8:	adrp	x9, 7707 ; 0x1022cf000
1004b46ec:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b46f0:	ldr	x9, [x9]
1004b46f4:	and	x8, x9, x8
1004b46f8:	ldr	x8, [x8, #0x248]
1004b46fc:	blr	x8
1004b4700:	mov	x0, x20
1004b4704:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4708:	adrp	x1, 7820 ; 0x102340000
1004b470c:	add	x1, x1, #0xc40
1004b4710:	adrp	x2, 7794 ; 0x102326000
1004b4714:	add	x2, x2, #0x9d8 ; Objc class ref: _OBJC_CLASS_$_OS_dispatch_queue
1004b4718:	mov	x0, #0x0
1004b471c:	bl	0x10002d97c
1004b4720:	mov	x20, x0
1004b4724:	bl	0x101ac6e44 ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE4mainABvgZ
1004b4728:	mov	x26, x0
1004b472c:	adrp	x0, 7464 ; 0x1021dc000
1004b4730:	add	x0, x0, #0x4d0
1004b4734:	mov	w1, #0x51
1004b4738:	mov	w2, #0x7
1004b473c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b4740:	ldp	q0, q1, [x24]
1004b4744:	stur	q0, [x0, #0x18]
1004b4748:	str	x25, [x0, #0x10]
1004b474c:	stur	q1, [x0, #0x28]
1004b4750:	ldr	q0, [x24, #0x20]
1004b4754:	stur	q0, [x0, #0x38]
1004b4758:	ldur	q0, [x24, #0x29]
1004b475c:	stur	q0, [x0, #0x41]
1004b4760:	adrp	x8, 18 ; 0x1004c6000
1004b4764:	add	x8, x8, #0xd70
1004b4768:	stp	x8, x0, [x29, #-0x80]
1004b476c:	adrp	x8, 7703 ; 0x1022cb000
1004b4770:	ldr	x8, [x8, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1004b4774:	stur	x8, [x29, #-0xa0]
1004b4778:	adrp	x8, 5677 ; 0x101ae1000
1004b477c:	ldr	d0, [x8]
1004b4780:	stur	d0, [x29, #-0x98]
1004b4784:	adrp	x8, -1200 ; 0x100004000
1004b4788:	add	x8, x8, #0xd0
1004b478c:	adrp	x9, 7464 ; 0x1021dc000
1004b4790:	add	x9, x9, #0x4e8
1004b4794:	stp	x8, x9, [x29, #-0x90]
1004b4798:	sub	x0, x29, #0xa0
1004b479c:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004b47a0:	mov	x27, x0
1004b47a4:	ldur	x20, [x29, #-0x78]
1004b47a8:	mov	x0, x25
1004b47ac:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b47b0:	sub	x1, x29, #0xe0
1004b47b4:	mov	x0, x24
1004b47b8:	bl	0x1004c6644
1004b47bc:	mov	x0, x20
1004b47c0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b47c4:	mov	x8, x23
1004b47c8:	bl	0x101ac5da0 ; symbol stub for: _$s8Dispatch0A3QoSV11unspecifiedACvgZ
1004b47cc:	adrp	x8, 7707 ; 0x1022cf000
1004b47d0:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004b47d4:	stur	x8, [x29, #-0xe0]
1004b47d8:	adrp	x0, 7822 ; 0x102342000
1004b47dc:	add	x0, x0, #0x2e0
1004b47e0:	adrp	x1, 7707 ; 0x1022cf000
1004b47e4:	ldr	x1, [x1, #0x930] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVMa
1004b47e8:	adrp	x2, 7707 ; 0x1022cf000
1004b47ec:	ldr	x2, [x2, #0x940] ; literal pool symbol address: _$s8Dispatch0A13WorkItemFlagsVs10SetAlgebraAAMc
1004b47f0:	bl	0x10002c7c4
1004b47f4:	mov	x24, x0
1004b47f8:	adrp	x20, 7820 ; 0x102340000
1004b47fc:	add	x20, x20, #0xc50
1004b4800:	adrp	x25, 5677 ; 0x101ae1000
1004b4804:	add	x25, x25, #0x280
1004b4808:	mov	x0, x20
1004b480c:	mov	x1, x25
1004b4810:	bl	0x100003c4c
1004b4814:	mov	x28, x0
1004b4818:	adrp	x0, 7822 ; 0x102342000
1004b481c:	add	x0, x0, #0x2f0
1004b4820:	adrp	x3, 7706 ; 0x1022ce000
1004b4824:	ldr	x3, [x3, #0x238] ; literal pool symbol address: _$sSayxGSTsMc
1004b4828:	mov	x1, x20
1004b482c:	mov	x2, x25
1004b4830:	bl	0x10002b714
1004b4834:	mov	x2, x0
1004b4838:	sub	x0, x29, #0xe0
1004b483c:	mov	x8, x21
1004b4840:	mov	x1, x28
1004b4844:	mov	x20, x19
1004b4848:	mov	x3, x19
1004b484c:	mov	x4, x24
1004b4850:	bl	0x101ac7450 ; symbol stub for: _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
1004b4854:	mov	x0, #0x0
1004b4858:	mov	x1, x23
1004b485c:	mov	x2, x21
1004b4860:	mov	x3, x27
1004b4864:	mov	x20, x26
1004b4868:	bl	0x101ac6e5c ; symbol stub for: _$sSo17OS_dispatch_queueC8DispatchE5async5group3qos5flags7executeySo0a1_b1_F0CSg_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
1004b486c:	mov	x0, x27
1004b4870:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004b4874:	mov	x0, x26
1004b4878:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b487c:	ldur	x8, [x29, #-0xe8]
1004b4880:	ldr	x8, [x8, #0x8]
1004b4884:	mov	x0, x21
1004b4888:	mov	x1, x19
1004b488c:	blr	x8
1004b4890:	ldr	x8, [x22, #0x8]
1004b4894:	mov	x0, x23
1004b4898:	ldur	x1, [x29, #-0xf0]
1004b489c:	blr	x8
1004b48a0:	sub	sp, x29, #0x50
1004b48a4:	ldp	x29, x30, [sp, #0x50]
1004b48a8:	ldp	x20, x19, [sp, #0x40]
1004b48ac:	ldp	x22, x21, [sp, #0x30]
1004b48b0:	ldp	x24, x23, [sp, #0x20]
1004b48b4:	ldp	x26, x25, [sp, #0x10]
1004b48b8:	ldp	x28, x27, [sp], #0x60
1004b48bc:	ret
1004b48c0:	sub	sp, sp, #0xe0
1004b48c4:	stp	d13, d12, [sp, #0x50]
1004b48c8:	stp	d11, d10, [sp, #0x60]
1004b48cc:	stp	d9, d8, [sp, #0x70]
1004b48d0:	stp	x28, x27, [sp, #0x80]
1004b48d4:	stp	x26, x25, [sp, #0x90]
1004b48d8:	stp	x24, x23, [sp, #0xa0]
1004b48dc:	stp	x22, x21, [sp, #0xb0]
1004b48e0:	stp	x20, x19, [sp, #0xc0]
1004b48e4:	stp	x29, x30, [sp, #0xd0]
1004b48e8:	add	x29, sp, #0xd0
1004b48ec:	mov	x19, x20
1004b48f0:	stp	x1, x2, [sp, #0x8]
1004b48f4:	mov.16b	v8, v0
1004b48f8:	mov	x23, x0
1004b48fc:	fmov	d9, #4.00000000
1004b4900:	adrp	x8, 7913 ; 0x10239d000
1004b4904:	ldr	x8, [x8, #0x248]
1004b4908:	add	x0, x20, x8
1004b490c:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b4910:	cbz	x0, 0x1004b4988
1004b4914:	mov	x20, x0
1004b4918:	ldr	x8, [x0]
1004b491c:	ldr	x8, [x8, #0x260]
1004b4920:	blr	x8
1004b4924:	mov	x21, x0
1004b4928:	mov	x0, x20
1004b492c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b4930:	cbz	x21, 0x1004b4990
1004b4934:	ldr	x8, [x21]
1004b4938:	ldr	x22, [x8, #0x5e8]
1004b493c:	mov	x0, x21
1004b4940:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b4944:	mov	x20, x21
1004b4948:	blr	x22
1004b494c:	mov	x20, x0
1004b4950:	mov	x0, x21
1004b4954:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b4958:	strb	w20, [sp, #0x4f]
1004b495c:	mov	w8, #0x2
1004b4960:	strb	w8, [sp, #0x4e]
1004b4964:	bl	0x100318e10
1004b4968:	mov	x3, x0
1004b496c:	adrp	x2, 7476 ; 0x1021e8000
1004b4970:	add	x2, x2, #0xec0
1004b4974:	add	x0, sp, #0x4f
1004b4978:	add	x1, sp, #0x4e
1004b497c:	mov	x20, x2
1004b4980:	bl	0x101ac619c ; symbol stub for: _$sSQ2eeoiySbx_xtFZTj
1004b4984:	b	0x1004b4994
1004b4988:	mov	x21, #0x0
1004b498c:	b	0x1004b4994
1004b4990:	mov	w0, #0x0
1004b4994:	adrp	x8, 7913 ; 0x10239d000
1004b4998:	ldr	x22, [x8, #0x2d0]
1004b499c:	and	w8, w0, #0x1
1004b49a0:	strb	w8, [x19, x22]
1004b49a4:	adrp	x8, 7913 ; 0x10239d000
1004b49a8:	ldr	x8, [x8, #0x2d8]
1004b49ac:	mov	x9, #0x800000000000
1004b49b0:	movk	x9, #0x4061, lsl #48
1004b49b4:	str	x9, [x19, x8]
1004b49b8:	fadd	d8, d8, d9
1004b49bc:	adrp	x8, 7913 ; 0x10239d000
1004b49c0:	ldr	x8, [x8, #0x2e0]
1004b49c4:	mov	x9, #0x4008000000000000
1004b49c8:	str	x9, [x19, x8]
1004b49cc:	str	x23, [sp, #0x40]
1004b49d0:	mov	x0, x23
1004b49d4:	bl	0x101acd560 ; selector effectiveAppearance
1004b49d8:	mov	x29, x29
1004b49dc:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b49e0:	mov	x23, x0
1004b49e4:	adrp	x0, 7821 ; 0x102341000
1004b49e8:	add	x0, x0, #0x160
1004b49ec:	adrp	x1, 5679 ; 0x101ae3000
1004b49f0:	add	x1, x1, #0xa20
1004b49f4:	bl	0x100003c4c
1004b49f8:	mov	w1, #0x30
1004b49fc:	mov	w2, #0x7
1004b4a00:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b4a04:	mov	x24, x0
1004b4a08:	adrp	x8, 5677 ; 0x101ae1000
1004b4a0c:	ldr	q0, [x8, #0x140]
1004b4a10:	str	q0, [x0, #0x10]
1004b4a14:	adrp	x8, 7702 ; 0x1022ca000
1004b4a18:	ldr	x8, [x8, #0x560] ; literal pool symbol address: _NSAppearanceNameAqua
1004b4a1c:	ldr	x25, [x8]
1004b4a20:	adrp	x8, 7702 ; 0x1022ca000
1004b4a24:	ldr	x8, [x8, #0x568] ; literal pool symbol address: _NSAppearanceNameDarkAqua
1004b4a28:	ldr	x20, [x8]
1004b4a2c:	stp	x25, x20, [x0, #0x20]
1004b4a30:	mov	x0, #0x0
1004b4a34:	bl	0x10002d3dc
1004b4a38:	mov	x26, x0
1004b4a3c:	mov	x0, x20
1004b4a40:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b4a44:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b4a48:	mov	x20, x0
1004b4a4c:	mov	x0, x25
1004b4a50:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b4a54:	mov	x0, x24
1004b4a58:	mov	x1, x26
1004b4a5c:	bl	0x101ac6754 ; symbol stub for: _$sSa10FoundationE19_bridgeToObjectiveCSo7NSArrayCyF
1004b4a60:	mov	x25, x0
1004b4a64:	mov	x0, x24
1004b4a68:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b4a6c:	mov	x0, x23
1004b4a70:	mov	x2, x25
1004b4a74:	bl	0x101acbbe0 ; selector bestMatchFromAppearancesWithNames:
1004b4a78:	mov	x29, x29
1004b4a7c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4a80:	mov	x24, x0
1004b4a84:	mov	x0, x23
1004b4a88:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4a8c:	mov	x0, x25
1004b4a90:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4a94:	adrp	x25, 7794 ; 0x102326000
1004b4a98:	cbz	x24, 0x1004b4af8
1004b4a9c:	mov	x0, x24
1004b4aa0:	bl	0x101ac625c ; symbol stub for: _$sSS10FoundationE36_unconditionallyBridgeFromObjectiveCySSSo8NSStringCSgFZ
1004b4aa4:	mov	x23, x0
1004b4aa8:	mov	x25, x1
1004b4aac:	mov	x0, x20
1004b4ab0:	bl	0x101ac625c ; symbol stub for: _$sSS10FoundationE36_unconditionallyBridgeFromObjectiveCySSSo8NSStringCSgFZ
1004b4ab4:	mov	x2, x0
1004b4ab8:	mov	x0, x23
1004b4abc:	mov	x23, x1
1004b4ac0:	cmp	x0, x2
1004b4ac4:	b.ne	0x1004b4b04
1004b4ac8:	cmp	x25, x23
1004b4acc:	b.ne	0x1004b4b04
1004b4ad0:	mov	x0, x24
1004b4ad4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4ad8:	mov	x0, x20
1004b4adc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4ae0:	mov	x0, x25
1004b4ae4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b4ae8:	mov	x0, x23
1004b4aec:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b4af0:	adrp	x25, 7794 ; 0x102326000
1004b4af4:	b	0x1004b4b40
1004b4af8:	mov	x0, x20
1004b4afc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4b00:	b	0x1004b4bc8
1004b4b04:	mov	x1, x25
1004b4b08:	mov	x3, x23
1004b4b0c:	mov	w4, #0x0
1004b4b10:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004b4b14:	mov	x26, x0
1004b4b18:	mov	x0, x24
1004b4b1c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4b20:	mov	x0, x20
1004b4b24:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4b28:	mov	x0, x25
1004b4b2c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b4b30:	mov	x0, x23
1004b4b34:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b4b38:	adrp	x25, 7794 ; 0x102326000
1004b4b3c:	tbz	w26, #0x0, 0x1004b4bc8
1004b4b40:	ldr	x0, [x25, #0x9c8]
1004b4b44:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b4b48:	mov	x20, x0
1004b4b4c:	bl	0x101ad61a0 ; selector whiteColor
1004b4b50:	mov	x29, x29
1004b4b54:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4b58:	mov	x23, x0
1004b4b5c:	mov	x8, #0xd70a
1004b4b60:	movk	x8, #0x70a3, lsl #16
1004b4b64:	movk	x8, #0xa3d, lsl #32
1004b4b68:	movk	x8, #0x3fb7, lsl #48
1004b4b6c:	fmov	d0, x8
1004b4b70:	bl	0x101acc400 ; selector colorWithAlphaComponent:
1004b4b74:	mov	x29, x29
1004b4b78:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4b7c:	mov	x26, x0
1004b4b80:	mov	x0, x23
1004b4b84:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4b88:	mov	x0, x20
1004b4b8c:	bl	0x101ad61a0 ; selector whiteColor
1004b4b90:	mov	x29, x29
1004b4b94:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4b98:	mov	x20, x0
1004b4b9c:	mov	x8, #-0x6666666666666667
1004b4ba0:	movk	x8, #0x999a
1004b4ba4:	movk	x8, #0x3fc9, lsl #48
1004b4ba8:	fmov	d0, x8
1004b4bac:	bl	0x101acc400 ; selector colorWithAlphaComponent:
1004b4bb0:	mov	x29, x29
1004b4bb4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4bb8:	mov	x28, x0
1004b4bbc:	mov	x0, x20
1004b4bc0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4bc4:	b	0x1004b4c24
1004b4bc8:	ldr	x0, [x25, #0x9c8]
1004b4bcc:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b4bd0:	mov	x20, x0
1004b4bd4:	bl	0x101acbc80 ; selector blackColor
1004b4bd8:	mov	x29, x29
1004b4bdc:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4be0:	mov	x23, x0
1004b4be4:	mov	x8, #0x1eb8
1004b4be8:	movk	x8, #0xeb85, lsl #16
1004b4bec:	movk	x8, #0xb851, lsl #32
1004b4bf0:	movk	x8, #0x3fae, lsl #48
1004b4bf4:	fmov	d0, x8
1004b4bf8:	bl	0x101acc400 ; selector colorWithAlphaComponent:
1004b4bfc:	mov	x29, x29
1004b4c00:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4c04:	mov	x26, x0
1004b4c08:	mov	x0, x23
1004b4c0c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4c10:	mov	x0, x20
1004b4c14:	bl	0x101ad61a0 ; selector whiteColor
1004b4c18:	mov	x29, x29
1004b4c1c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4c20:	mov	x28, x0
1004b4c24:	adrp	x24, 7794 ; 0x102326000
1004b4c28:	ldr	x0, [x24, #0xa40] ; Objc class ref: _OBJC_CLASS_$_NSView
1004b4c2c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004b4c30:	mov	x8, #0x800000000000
1004b4c34:	movk	x8, #0x4061, lsl #48
1004b4c38:	fmov	d2, x8
1004b4c3c:	fmov	d0, #16.00000000
1004b4c40:	fmov	d3, #24.00000000
1004b4c44:	mov.16b	v1, v8
1004b4c48:	bl	0x101ace5a0 ; selector initWithFrame:
1004b4c4c:	mov	x27, x0
1004b4c50:	mov	w2, #0x1
1004b4c54:	bl	0x101ad4ca0 ; selector setWantsLayer:
1004b4c58:	mov	x0, x27
1004b4c5c:	bl	0x101acf2c0 ; selector layer
1004b4c60:	mov	x29, x29
1004b4c64:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4c68:	cbz	x0, 0x1004b4c80
1004b4c6c:	fmov	d0, #12.00000000
1004b4c70:	mov	x20, x0
1004b4c74:	bl	0x101ad2440 ; selector setCornerRadius:
1004b4c78:	mov	x0, x20
1004b4c7c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4c80:	mov	x0, x27
1004b4c84:	bl	0x101acf2c0 ; selector layer
1004b4c88:	mov	x29, x29
1004b4c8c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4c90:	cbz	x0, 0x1004b4cc8
1004b4c94:	mov	x20, x0
1004b4c98:	mov	x0, x26
1004b4c9c:	bl	0x101acad00 ; selector CGColor
1004b4ca0:	mov	x29, x29
1004b4ca4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4ca8:	mov	x23, x0
1004b4cac:	mov	x0, x20
1004b4cb0:	mov	x2, x23
1004b4cb4:	bl	0x101ad1e00 ; selector setBackgroundColor:
1004b4cb8:	mov	x0, x20
1004b4cbc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4cc0:	mov	x0, x23
1004b4cc4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4cc8:	ldrb	w8, [x19, x22]
1004b4ccc:	cmp	w8, #0x0
1004b4cd0:	mov	x8, #0x800000000000
1004b4cd4:	movk	x8, #0x4051, lsl #48
1004b4cd8:	fmov	d0, x8
1004b4cdc:	fmov	d1, #3.00000000
1004b4ce0:	fcsel	d9, d0, d1, ne
1004b4ce4:	ldr	x0, [x24, #0xa40]
1004b4ce8:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004b4cec:	mov	x8, #0xc00000000000
1004b4cf0:	movk	x8, #0x4050, lsl #48
1004b4cf4:	fmov	d2, x8
1004b4cf8:	fmov	d1, #3.00000000
1004b4cfc:	fmov	d3, #18.00000000
1004b4d00:	mov.16b	v0, v9
1004b4d04:	bl	0x101ace5a0 ; selector initWithFrame:
1004b4d08:	mov	x20, x0
1004b4d0c:	mov	w2, #0x1
1004b4d10:	bl	0x101ad4ca0 ; selector setWantsLayer:
1004b4d14:	mov	x0, x20
1004b4d18:	bl	0x101acf2c0 ; selector layer
1004b4d1c:	mov	x29, x29
1004b4d20:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4d24:	cbz	x0, 0x1004b4d3c
1004b4d28:	fmov	d0, #9.00000000
1004b4d2c:	mov	x23, x0
1004b4d30:	bl	0x101ad2440 ; selector setCornerRadius:
1004b4d34:	mov	x0, x23
1004b4d38:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4d3c:	mov	x0, x20
1004b4d40:	bl	0x101acf2c0 ; selector layer
1004b4d44:	mov	x29, x29
1004b4d48:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4d4c:	cbz	x0, 0x1004b4d84
1004b4d50:	mov	x23, x0
1004b4d54:	mov	x0, x28
1004b4d58:	bl	0x101acad00 ; selector CGColor
1004b4d5c:	mov	x29, x29
1004b4d60:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4d64:	mov	x24, x0
1004b4d68:	mov	x0, x23
1004b4d6c:	mov	x2, x24
1004b4d70:	bl	0x101ad1e00 ; selector setBackgroundColor:
1004b4d74:	mov	x0, x23
1004b4d78:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4d7c:	mov	x0, x24
1004b4d80:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4d84:	adrp	x8, 7794 ; 0x102326000
1004b4d88:	ldr	x0, [x8, #0xcb0] ; Objc class ref: _OBJC_CLASS_$_NSShadow
1004b4d8c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004b4d90:	bl	0x101ace2c0 ; selector init
1004b4d94:	mov	x23, x0
1004b4d98:	mov	x0, x20
1004b4d9c:	mov	x2, x23
1004b4da0:	bl	0x101ad40a0 ; selector setShadow:
1004b4da4:	mov	x0, x23
1004b4da8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4dac:	mov	x0, x20
1004b4db0:	bl	0x101acf2c0 ; selector layer
1004b4db4:	mov	x29, x29
1004b4db8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4dbc:	cbz	x0, 0x1004b4e44
1004b4dc0:	mov	x23, x0
1004b4dc4:	ldr	x0, [x25, #0x9c8]
1004b4dc8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b4dcc:	bl	0x101acbc80 ; selector blackColor
1004b4dd0:	mov	x29, x29
1004b4dd4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4dd8:	mov	x24, x0
1004b4ddc:	mov	x8, #0x1eb8
1004b4de0:	movk	x8, #0xeb85, lsl #16
1004b4de4:	movk	x8, #0xb851, lsl #32
1004b4de8:	movk	x8, #0x3fbe, lsl #48
1004b4dec:	fmov	d0, x8
1004b4df0:	bl	0x101acc400 ; selector colorWithAlphaComponent:
1004b4df4:	mov	x29, x29
1004b4df8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4dfc:	mov	x25, x0
1004b4e00:	mov	x0, x24
1004b4e04:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4e08:	mov	x0, x25
1004b4e0c:	bl	0x101acad00 ; selector CGColor
1004b4e10:	mov	x29, x29
1004b4e14:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4e18:	mov	x24, x0
1004b4e1c:	mov	x0, x25
1004b4e20:	adrp	x25, 7794 ; 0x102326000
1004b4e24:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4e28:	mov	x0, x23
1004b4e2c:	mov	x2, x24
1004b4e30:	bl	0x101ad40e0 ; selector setShadowColor:
1004b4e34:	mov	x0, x23
1004b4e38:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4e3c:	mov	x0, x24
1004b4e40:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4e44:	mov	x0, x20
1004b4e48:	bl	0x101acf2c0 ; selector layer
1004b4e4c:	mov	x29, x29
1004b4e50:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4e54:	cbz	x0, 0x1004b4e70
1004b4e58:	movi.2d	v0, #0000000000000000
1004b4e5c:	fmov	d1, #-0.50000000
1004b4e60:	mov	x23, x0
1004b4e64:	bl	0x101ad4100 ; selector setShadowOffset:
1004b4e68:	mov	x0, x23
1004b4e6c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4e70:	mov	x0, x20
1004b4e74:	bl	0x101acf2c0 ; selector layer
1004b4e78:	mov	x29, x29
1004b4e7c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4e80:	cbz	x0, 0x1004b4e98
1004b4e84:	fmov	d0, #1.00000000
1004b4e88:	mov	x23, x0
1004b4e8c:	bl	0x101ad4160 ; selector setShadowRadius:
1004b4e90:	mov	x0, x23
1004b4e94:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4e98:	mov	x0, x20
1004b4e9c:	bl	0x101acf2c0 ; selector layer
1004b4ea0:	mov	x29, x29
1004b4ea4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4ea8:	cbz	x0, 0x1004b4ec0
1004b4eac:	fmov	s0, #1.00000000
1004b4eb0:	mov	x23, x0
1004b4eb4:	bl	0x101ad4120 ; selector setShadowOpacity:
1004b4eb8:	mov	x0, x23
1004b4ebc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4ec0:	fmov	d12, #24.00000000
1004b4ec4:	mov	x0, x27
1004b4ec8:	mov	x2, x20
1004b4ecc:	bl	0x101acb460 ; selector addSubview:
1004b4ed0:	adrp	x8, 7913 ; 0x10239d000
1004b4ed4:	ldr	x8, [x8, #0x290]
1004b4ed8:	ldr	x23, [x19, x8]
1004b4edc:	str	x20, [x19, x8]
1004b4ee0:	mov	x0, x20
1004b4ee4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b4ee8:	str	x0, [sp, #0x28]
1004b4eec:	mov	x0, x23
1004b4ef0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4ef4:	adrp	x24, 7794 ; 0x102326000
1004b4ef8:	ldr	x0, [x24, #0xb88] ; Objc class ref: _OBJC_CLASS_$_NSButton
1004b4efc:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004b4f00:	mov	x8, #0x800000000000
1004b4f04:	movk	x8, #0x4051, lsl #48
1004b4f08:	fmov	d2, x8
1004b4f0c:	movi.2d	v0, #0000000000000000
1004b4f10:	movi.2d	v1, #0000000000000000
1004b4f14:	fmov	d3, #24.00000000
1004b4f18:	bl	0x101ace5a0 ; selector initWithFrame:
1004b4f1c:	mov	x20, x0
1004b4f20:	mov	w0, #0x614e
1004b4f24:	movk	w0, #0x656d, lsl #16
1004b4f28:	mov	x1, #-0x1c00000000000000
1004b4f2c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b4f30:	mov	x23, x0
1004b4f34:	mov	x0, x20
1004b4f38:	mov	x2, x23
1004b4f3c:	bl	0x101ad4780 ; selector setTitle:
1004b4f40:	mov	x0, x23
1004b4f44:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4f48:	mov	x0, x20
1004b4f4c:	mov	w2, #0x0
1004b4f50:	bl	0x101ad1fa0 ; selector setBordered:
1004b4f54:	ldrb	w8, [x19, x22]
1004b4f58:	adrp	x9, 7702 ; 0x1022ca000
1004b4f5c:	ldr	x9, [x9, #0x610] ; literal pool symbol address: _NSFontWeightMedium
1004b4f60:	ldr	d10, [x9]
1004b4f64:	adrp	x9, 7702 ; 0x1022ca000
1004b4f68:	ldr	x9, [x9, #0x618] ; literal pool symbol address: _NSFontWeightRegular
1004b4f6c:	ldr	d11, [x9]
1004b4f70:	cmp	w8, #0x0
1004b4f74:	fcsel	d9, d11, d10, ne
1004b4f78:	mov	x0, x20
1004b4f7c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b4f80:	mov	x20, x0
1004b4f84:	fmov	d0, #11.00000000
1004b4f88:	mov.16b	v1, v9
1004b4f8c:	bl	0x100004700
1004b4f90:	mov	x23, x0
1004b4f94:	mov	x0, x20
1004b4f98:	mov	x2, x23
1004b4f9c:	bl	0x101ad2aa0 ; selector setFont:
1004b4fa0:	mov	x0, x23
1004b4fa4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4fa8:	ldrb	w23, [x19, x22]
1004b4fac:	ldr	x0, [x25, #0x9c8]
1004b4fb0:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b4fb4:	cmp	w23, #0x1
1004b4fb8:	b.ne	0x1004b4fc4
1004b4fbc:	bl	0x101ad12e0 ; selector secondaryLabelColor
1004b4fc0:	b	0x1004b4fc8
1004b4fc4:	bl	0x101acf220 ; selector labelColor
1004b4fc8:	fadd	d12, d8, d12
1004b4fcc:	fmov	d13, #8.00000000
1004b4fd0:	mov	x29, x29
1004b4fd4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b4fd8:	mov	x23, x0
1004b4fdc:	mov	x0, x20
1004b4fe0:	mov	x2, x23
1004b4fe4:	bl	0x101ad2300 ; selector setContentTintColor:
1004b4fe8:	mov	x0, x23
1004b4fec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b4ff0:	mov	x0, x20
1004b4ff4:	mov	w2, #0x5
1004b4ff8:	bl	0x101ad2040 ; selector setButtonType:
1004b4ffc:	mov	x0, x20
1004b5000:	mov	x2, x19
1004b5004:	bl	0x101ad45e0 ; selector setTarget:
1004b5008:	adrp	x8, 7788 ; 0x102321000
1004b500c:	ldr	x2, [x8, #0x830] ; Objc selector ref: renameNameClicked
1004b5010:	mov	x0, x20
1004b5014:	bl	0x101ad1780 ; selector setAction:
1004b5018:	mov	x0, x20
1004b501c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5020:	mov	x0, x27
1004b5024:	mov	x2, x20
1004b5028:	bl	0x101acb460 ; selector addSubview:
1004b502c:	adrp	x8, 7912 ; 0x10239d000
1004b5030:	ldr	x8, [x8, #0x298]
1004b5034:	ldr	x23, [x19, x8]
1004b5038:	str	x20, [x19, x8]
1004b503c:	mov	x0, x20
1004b5040:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b5044:	str	x0, [sp, #0x20]
1004b5048:	mov	x0, x23
1004b504c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5050:	ldr	x0, [x24, #0xb88]
1004b5054:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004b5058:	mov	x8, #0x800000000000
1004b505c:	movk	x8, #0x4051, lsl #48
1004b5060:	fmov	d0, x8
1004b5064:	movi.2d	v1, #0000000000000000
1004b5068:	fmov	d3, #24.00000000
1004b506c:	mov.16b	v2, v0
1004b5070:	bl	0x101ace5a0 ; selector initWithFrame:
1004b5074:	mov	x20, x0
1004b5078:	mov	x0, #0x7250
1004b507c:	movk	x0, #0x6665, lsl #16
1004b5080:	movk	x0, #0x7869, lsl #32
1004b5084:	mov	x1, #-0x1a00000000000000
1004b5088:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b508c:	mov	x23, x0
1004b5090:	mov	x0, x20
1004b5094:	mov	x2, x23
1004b5098:	bl	0x101ad4780 ; selector setTitle:
1004b509c:	mov	x0, x23
1004b50a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b50a4:	mov	x0, x20
1004b50a8:	mov	w2, #0x0
1004b50ac:	bl	0x101ad1fa0 ; selector setBordered:
1004b50b0:	ldrb	w8, [x19, x22]
1004b50b4:	cmp	w8, #0x0
1004b50b8:	fcsel	d9, d10, d11, ne
1004b50bc:	mov	x0, x20
1004b50c0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b50c4:	mov	x20, x0
1004b50c8:	fmov	d0, #11.00000000
1004b50cc:	mov.16b	v1, v9
1004b50d0:	bl	0x100004700
1004b50d4:	mov	x23, x0
1004b50d8:	mov	x0, x20
1004b50dc:	mov	x2, x23
1004b50e0:	bl	0x101ad2aa0 ; selector setFont:
1004b50e4:	mov	x0, x23
1004b50e8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b50ec:	ldrb	w23, [x19, x22]
1004b50f0:	ldr	x0, [x25, #0x9c8]
1004b50f4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b50f8:	cmp	w23, #0x1
1004b50fc:	stp	x28, x26, [sp, #0x30]
1004b5100:	b.ne	0x1004b510c
1004b5104:	bl	0x101acf220 ; selector labelColor
1004b5108:	b	0x1004b5110
1004b510c:	bl	0x101ad12e0 ; selector secondaryLabelColor
1004b5110:	ldr	x24, [sp, #0x40]
1004b5114:	fadd	d9, d12, d13
1004b5118:	mov	x29, x29
1004b511c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b5120:	mov	x23, x0
1004b5124:	mov	x0, x20
1004b5128:	mov	x2, x23
1004b512c:	bl	0x101ad2300 ; selector setContentTintColor:
1004b5130:	mov	x0, x23
1004b5134:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5138:	mov	x0, x20
1004b513c:	mov	w2, #0x5
1004b5140:	bl	0x101ad2040 ; selector setButtonType:
1004b5144:	mov	x0, x20
1004b5148:	mov	x2, x19
1004b514c:	bl	0x101ad45e0 ; selector setTarget:
1004b5150:	adrp	x8, 7788 ; 0x102321000
1004b5154:	ldr	x2, [x8, #0x838] ; Objc selector ref: renamePrefixClicked
1004b5158:	mov	x0, x20
1004b515c:	bl	0x101ad1780 ; selector setAction:
1004b5160:	mov	x0, x20
1004b5164:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5168:	mov	x0, x27
1004b516c:	mov	x2, x20
1004b5170:	bl	0x101acb460 ; selector addSubview:
1004b5174:	adrp	x8, 7912 ; 0x10239d000
1004b5178:	ldr	x8, [x8, #0x2a0]
1004b517c:	ldr	x23, [x19, x8]
1004b5180:	str	x20, [x19, x8]
1004b5184:	mov	x0, x20
1004b5188:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b518c:	str	x0, [sp, #0x18]
1004b5190:	mov	x0, x23
1004b5194:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5198:	mov	x0, x24
1004b519c:	mov	x2, x27
1004b51a0:	bl	0x101acb460 ; selector addSubview:
1004b51a4:	fmov	d0, #1.00000000
1004b51a8:	fadd	d8, d8, d0
1004b51ac:	bl	0x1004bfa04
1004b51b0:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004b51b4:	mov	x8, #0x400000000000
1004b51b8:	movk	x8, #0x406e, lsl #48
1004b51bc:	fmov	d0, x8
1004b51c0:	fmov	d2, #22.00000000
1004b51c4:	fmov	d3, #22.00000000
1004b51c8:	mov.16b	v1, v8
1004b51cc:	bl	0x101ace5a0 ; selector initWithFrame:
1004b51d0:	mov	x25, x0
1004b51d4:	adrp	x8, 6436 ; 0x101dd9000
1004b51d8:	add	x8, x8, #0x3e0 ; literal pool for: "arrow.uturn.backward"
1004b51dc:	sub	x8, x8, #0x20
1004b51e0:	adrp	x9, 6436 ; 0x101dd9000
1004b51e4:	add	x9, x9, #0x400 ; literal pool for: "Reset to Default"
1004b51e8:	sub	x24, x9, #0x20
1004b51ec:	adrp	x9, 7788 ; 0x102321000
1004b51f0:	ldr	x20, [x9, #0x840] ; Objc selector ref: renameResetClicked
1004b51f4:	mov	x9, #0x10
1004b51f8:	movk	x9, #0xd000, lsl #48
1004b51fc:	orr	x0, x9, #0x4
1004b5200:	orr	x1, x8, #0x8000000000000000
1004b5204:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b5208:	mov	x23, x0
1004b520c:	orr	x1, x24, #0x8000000000000000
1004b5210:	mov	x0, #0x10
1004b5214:	movk	x0, #0xd000, lsl #48
1004b5218:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b521c:	mov	x26, x0
1004b5220:	adrp	x8, 7793 ; 0x102326000
1004b5224:	ldr	x0, [x8, #0xb28] ; Objc class ref: _OBJC_CLASS_$_NSImage
1004b5228:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b522c:	mov	x2, x23
1004b5230:	mov	x3, x26
1004b5234:	bl	0x101ace220 ; selector imageWithSystemSymbolName:accessibilityDescription:
1004b5238:	mov	x29, x29
1004b523c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b5240:	mov	x28, x0
1004b5244:	mov	x0, x23
1004b5248:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b524c:	mov	x0, x26
1004b5250:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5254:	mov	x0, x25
1004b5258:	mov	x2, x28
1004b525c:	bl	0x101ad2f60 ; selector setImage:
1004b5260:	mov	x0, x28
1004b5264:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5268:	mov	x0, x25
1004b526c:	mov	w2, #0x0
1004b5270:	bl	0x101ad1fa0 ; selector setBordered:
1004b5274:	adrp	x8, 7793 ; 0x102326000
1004b5278:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004b527c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b5280:	mov	x26, x0
1004b5284:	bl	0x101ad12e0 ; selector secondaryLabelColor
1004b5288:	mov	x29, x29
1004b528c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b5290:	mov	x23, x0
1004b5294:	mov	x0, x25
1004b5298:	mov	x2, x23
1004b529c:	bl	0x101ad2300 ; selector setContentTintColor:
1004b52a0:	mov	x0, x23
1004b52a4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b52a8:	bl	_$s9TextStory09BufferingA7StorageC16bufferingEnabledSbvpfi
1004b52ac:	mov	x4, x0
1004b52b0:	orr	x1, x24, #0x8000000000000000
1004b52b4:	mov	x0, #0x10
1004b52b8:	movk	x0, #0xd000, lsl #48
1004b52bc:	mov	w2, #0x96
1004b52c0:	mov	x3, x25
1004b52c4:	bl	0x10012b948
1004b52c8:	mov	x0, x25
1004b52cc:	mov	w2, #0x5
1004b52d0:	bl	0x101ad2040 ; selector setButtonType:
1004b52d4:	mov	x0, x25
1004b52d8:	mov	x2, #0x0
1004b52dc:	bl	0x101ad3000 ; selector setImageScaling:
1004b52e0:	mov	x0, x25
1004b52e4:	mov	x2, x19
1004b52e8:	bl	0x101ad45e0 ; selector setTarget:
1004b52ec:	mov	x0, x25
1004b52f0:	mov	x2, x20
1004b52f4:	bl	0x101ad1780 ; selector setAction:
1004b52f8:	mov	x0, x25
1004b52fc:	mov	w2, #0x1
1004b5300:	bl	0x101ad4ca0 ; selector setWantsLayer:
1004b5304:	mov	x0, x25
1004b5308:	bl	0x101acf2c0 ; selector layer
1004b530c:	mov	x29, x29
1004b5310:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b5314:	cbz	x0, 0x1004b5340
1004b5318:	mov	x20, x0
1004b531c:	mov	x0, x25
1004b5320:	bl	0x101acbde0 ; selector bounds
1004b5324:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004b5328:	fmov	d1, #0.50000000
1004b532c:	fmul	d0, d0, d1
1004b5330:	mov	x0, x20
1004b5334:	bl	0x101ad2440 ; selector setCornerRadius:
1004b5338:	mov	x0, x20
1004b533c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5340:	ldr	x24, [sp, #0x40]
1004b5344:	mov	x0, x24
1004b5348:	mov	x2, x25
1004b534c:	bl	0x101acb460 ; selector addSubview:
1004b5350:	adrp	x8, 7793 ; 0x102326000
1004b5354:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004b5358:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004b535c:	mov	x8, #0x406f000000000000
1004b5360:	fmov	d2, x8
1004b5364:	fmov	d0, #16.00000000
1004b5368:	fmov	d3, #28.00000000
1004b536c:	mov.16b	v1, v9
1004b5370:	bl	0x101ace5a0 ; selector initWithFrame:
1004b5374:	mov	x28, x0
1004b5378:	ldrb	w8, [x19, x22]
1004b537c:	cmp	w8, #0x1
1004b5380:	b.ne	0x1004b53bc
1004b5384:	cbz	x21, 0x1004b5408
1004b5388:	ldr	x8, [x21]
1004b538c:	ldr	x22, [x8, #0x618]
1004b5390:	mov	x0, x28
1004b5394:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b5398:	mov	x0, x21
1004b539c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b53a0:	mov	x20, x21
1004b53a4:	blr	x22
1004b53a8:	mov	x23, x0
1004b53ac:	mov	x20, x1
1004b53b0:	mov	x0, x21
1004b53b4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b53b8:	b	0x1004b5418
1004b53bc:	mov	x0, x28
1004b53c0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b53c4:	mov	x20, x0
1004b53c8:	ldp	x0, x1, [sp, #0x8]
1004b53cc:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b53d0:	mov	x23, x0
1004b53d4:	mov	x0, x20
1004b53d8:	mov	x2, x23
1004b53dc:	bl	0x101ad4440 ; selector setStringValue:
1004b53e0:	mov	x0, x20
1004b53e4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b53e8:	mov	x0, x23
1004b53ec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b53f0:	mov	x0, #0x6154
1004b53f4:	movk	x0, #0x2062, lsl #16
1004b53f8:	movk	x0, #0x616e, lsl #32
1004b53fc:	movk	x0, #0x656d, lsl #48
1004b5400:	mov	x1, #-0x1800000000000000
1004b5404:	b	0x1004b5464
1004b5408:	mov	x0, x28
1004b540c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b5410:	mov	x23, #0x0
1004b5414:	mov	x20, #-0x2000000000000000
1004b5418:	mov	x0, x23
1004b541c:	mov	x1, x20
1004b5420:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b5424:	mov	x23, x0
1004b5428:	mov	x0, x20
1004b542c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b5430:	mov	x0, x28
1004b5434:	mov	x2, x23
1004b5438:	bl	0x101ad4440 ; selector setStringValue:
1004b543c:	mov	x0, x28
1004b5440:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5444:	mov	x0, x23
1004b5448:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b544c:	mov	x0, #0x7250
1004b5450:	movk	x0, #0x6665, lsl #16
1004b5454:	movk	x0, #0x7869, lsl #32
1004b5458:	movk	x0, #0x2e2e, lsl #48
1004b545c:	mov	x1, #0x2e
1004b5460:	movk	x1, #0xe900, lsl #48
1004b5464:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b5468:	mov	x20, x0
1004b546c:	mov	x0, x28
1004b5470:	mov	x2, x20
1004b5474:	bl	0x101ad3aa0 ; selector setPlaceholderString:
1004b5478:	mov	x0, x20
1004b547c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5480:	mov	x0, x28
1004b5484:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b5488:	mov	x20, x0
1004b548c:	bl	0x10002dd04
1004b5490:	mov.16b	v1, v0
1004b5494:	fmov	d0, #13.00000000
1004b5498:	bl	0x100004700
1004b549c:	mov	x23, x0
1004b54a0:	mov	x0, x20
1004b54a4:	mov	x2, x23
1004b54a8:	bl	0x101ad2aa0 ; selector setFont:
1004b54ac:	mov	x0, x23
1004b54b0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b54b4:	mov	x0, x26
1004b54b8:	bl	0x101acf220 ; selector labelColor
1004b54bc:	mov	x29, x29
1004b54c0:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b54c4:	mov	x23, x0
1004b54c8:	mov	x0, x20
1004b54cc:	mov	x2, x23
1004b54d0:	bl	0x101ad4660 ; selector setTextColor:
1004b54d4:	mov	x0, x23
1004b54d8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b54dc:	mov	x0, x20
1004b54e0:	mov	w2, #0x1
1004b54e4:	bl	0x101ad1ea0 ; selector setBezeled:
1004b54e8:	mov	x0, x20
1004b54ec:	mov	w2, #0x1
1004b54f0:	bl	0x101ad1e80 ; selector setBezelStyle:
1004b54f4:	mov	x0, x20
1004b54f8:	mov	w2, #0x1
1004b54fc:	bl	0x101ad2860 ; selector setDrawsBackground:
1004b5500:	mov	x0, x20
1004b5504:	mov	x2, #0x0
1004b5508:	bl	0x101ad2a80 ; selector setFocusRingType:
1004b550c:	mov	x0, x20
1004b5510:	mov	w2, #0x1
1004b5514:	bl	0x101ad28e0 ; selector setEditable:
1004b5518:	mov	x0, x20
1004b551c:	mov	w2, #0x1
1004b5520:	bl	0x101ad4ae0 ; selector setUsesSingleLineMode:
1004b5524:	mov	x0, x20
1004b5528:	bl	0x101acc040 ; selector cell
1004b552c:	mov	x29, x29
1004b5530:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b5534:	mov	x23, x0
1004b5538:	mov	w2, #0x0
1004b553c:	bl	0x101ad4dc0 ; selector setWraps:
1004b5540:	mov	x0, x23
1004b5544:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5548:	mov	x0, x20
1004b554c:	bl	0x101acc040 ; selector cell
1004b5550:	mov	x29, x29
1004b5554:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b5558:	mov	x23, x0
1004b555c:	mov	w2, #0x1
1004b5560:	bl	0x101ad3ee0 ; selector setScrollable:
1004b5564:	mov	x0, x23
1004b5568:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b556c:	mov	x0, x20
1004b5570:	mov	w2, #0x4
1004b5574:	bl	0x101ad3340 ; selector setLineBreakMode:
1004b5578:	mov	x0, x20
1004b557c:	mov	x2, x19
1004b5580:	bl	0x101ad2600 ; selector setDelegate:
1004b5584:	mov	x0, x20
1004b5588:	mov	x2, x19
1004b558c:	bl	0x101ad45e0 ; selector setTarget:
1004b5590:	adrp	x8, 7788 ; 0x102321000
1004b5594:	ldr	x2, [x8, #0x848] ; Objc selector ref: renameFieldAction:
1004b5598:	mov	x0, x20
1004b559c:	bl	0x101ad1780 ; selector setAction:
1004b55a0:	mov	x0, x20
1004b55a4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b55a8:	mov	x0, x24
1004b55ac:	mov	x2, x20
1004b55b0:	bl	0x101acb460 ; selector addSubview:
1004b55b4:	ldr	x0, [sp, #0x28]
1004b55b8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b55bc:	ldr	x0, [sp, #0x20]
1004b55c0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b55c4:	ldr	x0, [sp, #0x18]
1004b55c8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b55cc:	mov	x0, x25
1004b55d0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b55d4:	ldr	x0, [sp, #0x38]
1004b55d8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b55dc:	ldr	x0, [sp, #0x30]
1004b55e0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b55e4:	mov	x0, x27
1004b55e8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b55ec:	mov	x0, x21
1004b55f0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b55f4:	adrp	x8, 7840 ; 0x102355000
1004b55f8:	ldr	x8, [x8, #0xe8]
1004b55fc:	ldr	x0, [x19, x8]
1004b5600:	str	x20, [x19, x8]
1004b5604:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5608:	fmov	d0, #28.00000000
1004b560c:	fadd	d0, d9, d0
1004b5610:	fmov	d1, #4.00000000
1004b5614:	fadd	d0, d0, d1
1004b5618:	ldp	x29, x30, [sp, #0xd0]
1004b561c:	ldp	x20, x19, [sp, #0xc0]
1004b5620:	ldp	x22, x21, [sp, #0xb0]
1004b5624:	ldp	x24, x23, [sp, #0xa0]
1004b5628:	ldp	x26, x25, [sp, #0x90]
1004b562c:	ldp	x28, x27, [sp, #0x80]
1004b5630:	ldp	d9, d8, [sp, #0x70]
1004b5634:	ldp	d11, d10, [sp, #0x60]
1004b5638:	ldp	d13, d12, [sp, #0x50]
1004b563c:	add	sp, sp, #0xe0
1004b5640:	ret
1004b5644:	sub	sp, sp, #0x50
1004b5648:	stp	x24, x23, [sp, #0x10]
1004b564c:	stp	x22, x21, [sp, #0x20]
1004b5650:	stp	x20, x19, [sp, #0x30]
1004b5654:	stp	x29, x30, [sp, #0x40]
1004b5658:	add	x29, sp, #0x40
1004b565c:	adrp	x8, 7912 ; 0x10239d000
1004b5660:	ldr	x23, [x8, #0x2d0]
1004b5664:	ldrb	w8, [x20, x23]
1004b5668:	cmp	w8, #0x1
1004b566c:	b.ne	0x1004b57a8
1004b5670:	adrp	x8, 7840 ; 0x102355000
1004b5674:	ldr	x8, [x8, #0xe8]
1004b5678:	ldr	x19, [x20, x8]
1004b567c:	cbz	x19, 0x1004b57a8
1004b5680:	adrp	x8, 7912 ; 0x10239d000
1004b5684:	ldr	x8, [x8, #0x248]
1004b5688:	add	x0, x20, x8
1004b568c:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b5690:	cbz	x0, 0x1004b57a8
1004b5694:	mov	x21, x20
1004b5698:	ldr	x8, [x0]
1004b569c:	ldr	x24, [x8, #0x260]
1004b56a0:	mov	x20, x0
1004b56a4:	mov	x0, x19
1004b56a8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b56ac:	mov	x22, x0
1004b56b0:	blr	x24
1004b56b4:	mov	x19, x0
1004b56b8:	mov	x0, x20
1004b56bc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b56c0:	cbz	x19, 0x1004b57c0
1004b56c4:	strb	wzr, [x21, x23]
1004b56c8:	ldr	x8, [x19]
1004b56cc:	ldr	x23, [x8, #0x5e8]
1004b56d0:	mov	x0, x22
1004b56d4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b56d8:	mov	x22, x0
1004b56dc:	mov	x20, x19
1004b56e0:	blr	x23
1004b56e4:	strb	w0, [sp, #0xf]
1004b56e8:	mov	w8, #0x1
1004b56ec:	strb	w8, [sp, #0xe]
1004b56f0:	bl	0x100318e10
1004b56f4:	mov	x3, x0
1004b56f8:	adrp	x2, 7475 ; 0x1021e8000
1004b56fc:	add	x2, x2, #0xec0
1004b5700:	add	x0, sp, #0xf
1004b5704:	add	x1, sp, #0xe
1004b5708:	mov	x20, x2
1004b570c:	bl	0x101ac619c ; symbol stub for: _$sSQ2eeoiySbx_xtFZTj
1004b5710:	ldr	x8, [x19]
1004b5714:	tst	w0, #0x1
1004b5718:	mov	w9, #0x650
1004b571c:	mov	w10, #0x600
1004b5720:	csel	x9, x10, x9, ne
1004b5724:	ldr	x8, [x8, x9]
1004b5728:	mov	x20, x19
1004b572c:	blr	x8
1004b5730:	mov	x20, x1
1004b5734:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b5738:	mov	x23, x0
1004b573c:	mov	x0, x20
1004b5740:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b5744:	mov	x0, x22
1004b5748:	mov	x2, x23
1004b574c:	bl	0x101ad4440 ; selector setStringValue:
1004b5750:	mov	x0, x22
1004b5754:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5758:	mov	x0, x23
1004b575c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5760:	mov	x0, #0x6154
1004b5764:	movk	x0, #0x2062, lsl #16
1004b5768:	movk	x0, #0x616e, lsl #32
1004b576c:	movk	x0, #0x656d, lsl #48
1004b5770:	mov	x1, #-0x1800000000000000
1004b5774:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b5778:	mov	x20, x0
1004b577c:	mov	x0, x22
1004b5780:	mov	x2, x20
1004b5784:	bl	0x101ad3aa0 ; selector setPlaceholderString:
1004b5788:	mov	x0, x20
1004b578c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5790:	mov	x20, x21
1004b5794:	bl	0x1004b5a6c
1004b5798:	mov	x0, x22
1004b579c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b57a0:	mov	x0, x19
1004b57a4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b57a8:	ldp	x29, x30, [sp, #0x40]
1004b57ac:	ldp	x20, x19, [sp, #0x30]
1004b57b0:	ldp	x22, x21, [sp, #0x20]
1004b57b4:	ldp	x24, x23, [sp, #0x10]
1004b57b8:	add	sp, sp, #0x50
1004b57bc:	ret
1004b57c0:	mov	x0, x22
1004b57c4:	ldp	x29, x30, [sp, #0x40]
1004b57c8:	ldp	x20, x19, [sp, #0x30]
1004b57cc:	ldp	x22, x21, [sp, #0x20]
1004b57d0:	ldp	x24, x23, [sp, #0x10]
1004b57d4:	add	sp, sp, #0x50
1004b57d8:	b	0x101ac9d30 ; symbol stub for: _objc_release
