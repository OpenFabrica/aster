1004c5a24:     	sub	sp, sp, #0x40
1004c5a28:     	stp	x20, x19, [sp, #0x20]
1004c5a2c:     	stp	x29, x30, [sp, #0x30]
1004c5a30:     	add	x29, sp, #0x30
1004c5a34:     	bl	0x100603d88
1004c5a38:     	add	x0, x20, #0x10
1004c5a3c:     	add	x1, sp, #0x8
1004c5a40:     	mov	x2, #0x0                ; =0
1004c5a44:     	mov	x3, #0x0                ; =0
1004c5a48:     	bl	0x101aca600 ; symbol _swift_beginAccess
1004c5a4c:     	add	x0, x20, #0x10
1004c5a50:     	bl	0x101acaad4 ; symbol _swift_unknownObjectWeakLoadStrong
1004c5a54:     	cbz	x0, 0x1004c5a80
1004c5a58:     	mov	x20, x0
1004c5a5c:     	ldr	x8, [x0]
1004c5a60:     	adrp	x9, 0x1022cf000
1004c5a64:     	ldr	x9, [x9, #0x718]
1004c5a68:     	ldr	x9, [x9]
1004c5a6c:     	and	x8, x9, x8
1004c5a70:     	ldr	x8, [x8, #0x248]
1004c5a74:     	blr	x8
1004c5a78:     	mov	x0, x20
1004c5a7c:     	bl	0x101ac9d30 ; symbol _objc_release
1004c5a80:     	ldp	x29, x30, [sp, #0x30]
1004c5a84:     	ldp	x20, x19, [sp, #0x20]
1004c5a88:     	add	sp, sp, #0x40
1004c5a8c:     	ret
1004c5a90:     	stp	x29, x30, [sp, #-0x10]!
1004c5a94:     	mov	x29, sp
1004c5a98:     	ldr	x0, [x20, #0x18]
1004c5a9c:     	cbz	x0, 0x1004c5ab4
1004c5aa0:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1004c5aa4:     	ldr	x0, [x20, #0x40]
1004c5aa8:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1004c5aac:     	ldr	x0, [x20, #0x48]
1004c5ab0:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1004c5ab4:     	ldr	x0, [x20, #0x68]
1004c5ab8:     	bl	0x101aca960 ; symbol _swift_release
1004c5abc:     	ldr	x0, [x20, #0x78]
1004c5ac0:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1004c5ac4:     	ldr	x0, [x20, #0x88]
1004c5ac8:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1004c5acc:     	ldr	x0, [x20, #0x90]
1004c5ad0:     	bl	0x101ac9d30 ; symbol _objc_release
1004c5ad4:     	mov	x0, x20
1004c5ad8:     	mov	w1, #0x98               ; =152
1004c5adc:     	mov	w2, #0x7                ; =7
1004c5ae0:     	ldp	x29, x30, [sp], #0x10
1004c5ae4:     	b	0x101aca6a8 ; symbol _swift_deallocObject
1004c5ae8:     	ldp	x1, x2, [x20, #0x68]
1004c5aec:     	ldp	x3, x4, [x20, #0x78]
1004c5af0:     	ldp	x5, x6, [x20, #0x88]
1004c5af4:     	add	x0, x20, #0x10
1004c5af8:     	b	0x1004bd944
1004c5afc:     	b	0x1004c5fdc
1004c5b00:     	adrp	x0, 0x100584000
1004c5b04:     	add	x0, x0, #0xaac
1004c5b08:     	b	0x1004c5b18
1004c5b0c:     	adrp	x0, 0x100584000
1004c5b10:     	add	x0, x0, #0xc38
1004c5b14:     	b	0x1004c5b18
1004c5b18:     	sub	sp, sp, #0xb0
1004c5b1c:     	stp	x26, x25, [sp, #0x60]
1004c5b20:     	stp	x24, x23, [sp, #0x70]
1004c5b24:     	stp	x22, x21, [sp, #0x80]
1004c5b28:     	stp	x20, x19, [sp, #0x90]
1004c5b2c:     	stp	x29, x30, [sp, #0xa0]
1004c5b30:     	add	x29, sp, #0xa0
1004c5b34:     	mov	x19, x0
1004c5b38:     	ldp	x25, x21, [x20, #0x10]
1004c5b3c:     	ldp	x22, x24, [x20, #0x20]
1004c5b40:     	ldr	x23, [x20, #0x30]
1004c5b44:     	add	x0, x25, #0x10
1004c5b48:     	mov	x1, sp
1004c5b4c:     	mov	x2, #0x0                ; =0
1004c5b50:     	mov	x3, #0x0                ; =0
1004c5b54:     	bl	0x101aca600 ; symbol _swift_beginAccess
1004c5b58:     	add	x0, x25, #0x10
1004c5b5c:     	bl	0x101acaad4 ; symbol _swift_unknownObjectWeakLoadStrong
1004c5b60:     	cbz	x0, 0x1004c5b8c
1004c5b64:     	mov	x20, x0
1004c5b68:     	ldr	x8, [x0]
1004c5b6c:     	adrp	x9, 0x1022cf000
1004c5b70:     	ldr	x9, [x9, #0x718]
1004c5b74:     	ldr	x9, [x9]
1004c5b78:     	and	x8, x9, x8
1004c5b7c:     	ldr	x8, [x8, #0x248]
1004c5b80:     	blr	x8
1004c5b84:     	mov	x0, x20
1004c5b88:     	bl	0x101ac9d30 ; symbol _objc_release
1004c5b8c:     	adrp	x0, 0x102341000
1004c5b90:     	add	x0, x0, #0x6d0
1004c5b94:     	adrp	x1, 0x101ae1000
