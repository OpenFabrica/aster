10066423c:     	stp	x20, x19, [sp, #-0x20]!
100664240:     	stp	x29, x30, [sp, #0x10]
100664244:     	add	x29, sp, #0x10
100664248:     	ldr	x8, [x20]
10066424c:     	ldr	x8, [x8, #0x90]
100664250:     	blr	x8
100664254:     	ldr	x19, [x0, #0x10]
100664258:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066425c:     	cmp	x19, #0x1
100664260:     	cset	w0, hi
100664264:     	ldp	x29, x30, [sp, #0x10]
100664268:     	ldp	x20, x19, [sp], #0x20
10066426c:     	ret
100664270:     	stp	x20, x19, [sp, #-0x20]!
100664274:     	stp	x29, x30, [sp, #0x10]
100664278:     	add	x29, sp, #0x10
10066427c:     	ldr	x8, [x20]
100664280:     	ldr	x8, [x8, #0x78]
100664284:     	blr	x8
100664288:     	mov	x20, x0
10066428c:     	ldr	x8, [x0]
100664290:     	ldr	x8, [x8, #0xd8]
100664294:     	blr	x8
100664298:     	mov	x19, x0
10066429c:     	mov	x0, x20
1006642a0:     	bl	0x101aca960 ; symbol _swift_release
1006642a4:     	and	w0, w19, #0x1
1006642a8:     	ldp	x29, x30, [sp, #0x10]
1006642ac:     	ldp	x20, x19, [sp], #0x20
1006642b0:     	ret
1006642b4:     	stp	x20, x19, [sp, #-0x20]!
1006642b8:     	stp	x29, x30, [sp, #0x10]
1006642bc:     	add	x29, sp, #0x10
1006642c0:     	mov	x19, x0
1006642c4:     	ldr	x8, [x20]
1006642c8:     	ldr	x8, [x8, #0x78]
1006642cc:     	blr	x8
1006642d0:     	mov	x20, x0
1006642d4:     	ldr	x8, [x0]
1006642d8:     	ldr	x8, [x8, #0xe0]
1006642dc:     	mov	x0, x19
1006642e0:     	blr	x8
1006642e4:     	mov	x0, x20
1006642e8:     	ldp	x29, x30, [sp, #0x10]
1006642ec:     	ldp	x20, x19, [sp], #0x20
1006642f0:     	b	0x101aca960 ; symbol _swift_release
1006642f4:     	stp	x22, x21, [sp, #-0x30]!
1006642f8:     	stp	x20, x19, [sp, #0x10]
1006642fc:     	stp	x29, x30, [sp, #0x20]
100664300:     	add	x29, sp, #0x20
100664304:     	mov	x19, x0
100664308:     	str	x20, [x0]
10066430c:     	ldr	x8, [x20]
100664310:     	ldr	x8, [x8, #0x78]
100664314:     	str	x8, [x0, #0x8]
100664318:     	blr	x8
10066431c:     	mov	x20, x0
100664320:     	ldr	x8, [x0]
100664324:     	ldr	x8, [x8, #0xd8]
100664328:     	blr	x8
10066432c:     	mov	x21, x0
100664330:     	mov	x0, x20
100664334:     	bl	0x101aca960 ; symbol _swift_release
100664338:     	and	w8, w21, #0x1
10066433c:     	strb	w8, [x19, #0x10]!
100664340:     	adrp	x0, 0x100664000
100664344:     	add	x0, x0, #0x35c
100664348:     	mov	x1, x19
10066434c:     	ldp	x29, x30, [sp, #0x20]
100664350:     	ldp	x20, x19, [sp, #0x10]
100664354:     	ldp	x22, x21, [sp], #0x30
100664358:     	ret
10066435c:     	stp	x20, x19, [sp, #-0x20]!
100664360:     	stp	x29, x30, [sp, #0x10]
100664364:     	add	x29, sp, #0x10
100664368:     	ldp	x20, x8, [x0]
10066436c:     	ldrb	w19, [x0, #0x10]
100664370:     	blr	x8
100664374:     	mov	x20, x0
100664378:     	ldr	x8, [x0]
10066437c:     	ldr	x8, [x8, #0xe0]
100664380:     	mov	x0, x19
100664384:     	blr	x8
100664388:     	mov	x0, x20
10066438c:     	ldp	x29, x30, [sp, #0x10]
100664390:     	ldp	x20, x19, [sp], #0x20
100664394:     	b	0x101aca960 ; symbol _swift_release
100664398:     	stp	x22, x21, [sp, #-0x30]!
10066439c:     	stp	x20, x19, [sp, #0x10]
1006643a0:     	stp	x29, x30, [sp, #0x20]
1006643a4:     	add	x29, sp, #0x20
1006643a8:     	mov	x19, x1
1006643ac:     	mov	x21, x0
1006643b0:     	mov	x0, x20
1006643b4:     	mov	w1, #0x38               ; =56
1006643b8:     	mov	w2, #0x7                ; =7
1006643bc:     	bl	0x101aca588 ; symbol _swift_allocObject
1006643c0:     	mov	x22, x0
1006643c4:     	adrp	x20, 0x1022cf000
1006643c8:     	ldr	x20, [x20, #0x4a8]
1006643cc:     	mov	x0, x20
1006643d0:     	bl	0x10068b5e0
1006643d4:     	stp	x0, x20, [x22, #0x18]
1006643d8:     	stp	x20, x20, [x22, #0x28]
1006643dc:     	mov	x0, #0x0                ; =0
1006643e0:     	bl	0x100655cf0
1006643e4:     	mov	x20, x0
1006643e8:     	mov	x0, x21
1006643ec:     	mov	x1, x19
1006643f0:     	bl	0x100651b38
1006643f4:     	str	x0, [x22, #0x10]
1006643f8:     	mov	x0, x22
1006643fc:     	ldp	x29, x30, [sp, #0x20]
100664400:     	ldp	x20, x19, [sp, #0x10]
100664404:     	ldp	x22, x21, [sp], #0x30
100664408:     	ret
10066440c:     	stp	x22, x21, [sp, #-0x30]!
100664410:     	stp	x20, x19, [sp, #0x10]
100664414:     	stp	x29, x30, [sp, #0x20]
100664418:     	add	x29, sp, #0x20
10066441c:     	mov	x19, x20
100664420:     	mov	x20, x1
100664424:     	mov	x21, x0
100664428:     	adrp	x22, 0x1022cf000
10066442c:     	ldr	x22, [x22, #0x4a8]
100664430:     	mov	x0, x22
100664434:     	bl	0x10068b5e0
100664438:     	stp	x0, x22, [x19, #0x18]
10066443c:     	stp	x22, x22, [x19, #0x28]
100664440:     	mov	x0, #0x0                ; =0
100664444:     	bl	0x100655cf0
100664448:     	mov	x2, x0
10066444c:     	mov	x0, x21
100664450:     	mov	x1, x20
100664454:     	mov	x20, x2
100664458:     	bl	0x100651b38
10066445c:     	str	x0, [x19, #0x10]
100664460:     	mov	x0, x19
100664464:     	ldp	x29, x30, [sp, #0x20]
100664468:     	ldp	x20, x19, [sp, #0x10]
10066446c:     	ldp	x22, x21, [sp], #0x30
100664470:     	ret
100664474:     	stp	x29, x30, [sp, #-0x10]!
100664478:     	mov	x29, sp
10066447c:     	ldr	x0, [x20, #0x10]
100664480:     	bl	0x101aca960 ; symbol _swift_release
100664484:     	ldr	x0, [x20, #0x18]
100664488:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066448c:     	ldr	x0, [x20, #0x20]
100664490:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100664494:     	ldr	x0, [x20, #0x28]
100664498:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066449c:     	ldr	x0, [x20, #0x30]
1006644a0:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1006644a4:     	mov	x0, x20
1006644a8:     	ldp	x29, x30, [sp], #0x10
1006644ac:     	ret
1006644b0:     	stp	x29, x30, [sp, #-0x10]!
1006644b4:     	mov	x29, sp
1006644b8:     	ldr	x0, [x20, #0x10]
1006644bc:     	bl	0x101aca960 ; symbol _swift_release
1006644c0:     	ldr	x0, [x20, #0x18]
1006644c4:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1006644c8:     	ldr	x0, [x20, #0x20]
1006644cc:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1006644d0:     	ldr	x0, [x20, #0x28]
1006644d4:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1006644d8:     	ldr	x0, [x20, #0x30]
1006644dc:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1006644e0:     	mov	x0, x20
1006644e4:     	mov	w1, #0x38               ; =56
1006644e8:     	mov	w2, #0x7                ; =7
1006644ec:     	ldp	x29, x30, [sp], #0x10
1006644f0:     	b	0x101aca69c
1006644f4:     	stp	x22, x21, [sp, #-0x30]!
1006644f8:     	stp	x20, x19, [sp, #0x10]
1006644fc:     	stp	x29, x30, [sp, #0x20]
100664500:     	add	x29, sp, #0x20
100664504:     	ldr	x8, [x20]
100664508:     	ldr	x8, [x8, #0x78]
10066450c:     	blr	x8
100664510:     	mov	x20, x0
100664514:     	ldr	x8, [x0]
100664518:     	ldr	x8, [x8, #0x90]
10066451c:     	blr	x8
100664520:     	mov	x19, x0
100664524:     	mov	x21, x1
100664528:     	mov	x0, x20
10066452c:     	bl	0x101aca960 ; symbol _swift_release
100664530:     	mov	x0, x19
100664534:     	mov	x1, x21
100664538:     	ldp	x29, x30, [sp, #0x20]
10066453c:     	ldp	x20, x19, [sp, #0x10]
100664540:     	ldp	x22, x21, [sp], #0x30
100664544:     	ret
100664548:     	stp	x28, x27, [sp, #-0x60]!
10066454c:     	stp	x26, x25, [sp, #0x10]
100664550:     	stp	x24, x23, [sp, #0x20]
100664554:     	stp	x22, x21, [sp, #0x30]
100664558:     	stp	x20, x19, [sp, #0x40]
10066455c:     	stp	x29, x30, [sp, #0x50]
100664560:     	add	x29, sp, #0x50
100664564:     	mov	x22, x20
100664568:     	mov	x21, x8
10066456c:     	adrp	x0, 0x102341000
100664570:     	add	x0, x0, #0x4a0
100664574:     	adrp	x1, 0x101ae1000
100664578:     	add	x1, x1, #0xc60 ; possible literal ',)4'
10066457c:     	bl	0x100003c4c
100664580:     	ldur	x8, [x0, #-0x8]
100664584:     	ldr	x9, [x8, #0x40]
100664588:     	add	x8, x9, #0xf
10066458c:     	and	x8, x8, #0xfffffffffffffff0
100664590:     	adrp	x16, 0x1022cb000
100664594:     	ldr	x16, [x16, #0x398]
100664598:     	blr	x16
10066459c:     	mov	x9, sp
1006645a0:     	sub	x19, x9, x8
1006645a4:     	mov	sp, x19
1006645a8:     	ldr	x8, [x20]
1006645ac:     	ldr	x8, [x8, #0x118]
1006645b0:     	blr	x8
1006645b4:     	mov	x24, x0
1006645b8:     	mov	x23, x1
1006645bc:     	ldr	x8, [x20]
1006645c0:     	ldr	x25, [x8, #0x90]
1006645c4:     	blr	x25
1006645c8:     	mov	x20, x0
1006645cc:     	ldr	x8, [x0, #0x10]
1006645d0:     	cbz	x8, 0x100664668
1006645d4:     	mov	x0, x24
1006645d8:     	mov	x1, x23
1006645dc:     	bl	0x1000240a8
1006645e0:     	tbz	w1, #0x0, 0x100664668
1006645e4:     	mov	x24, x0
1006645e8:     	ldr	x26, [x20, #0x38]
1006645ec:     	mov	x0, #0x0                ; =0
1006645f0:     	bl	0x10068c794
1006645f4:     	mov	x22, x0
1006645f8:     	adrp	x25, 0x10068c000
1006645fc:     	add	x25, x25, #0x794 ; possible literal '��'
100664600:     	ldur	x27, [x0, #-0x8]
100664604:     	ldr	x8, [x27, #0x48]
100664608:     	madd	x0, x8, x24, x26
10066460c:     	mov	x1, x19
100664610:     	mov	x2, x25
100664614:     	bl	0x1000e73b0
100664618:     	mov	x0, x20
10066461c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100664620:     	mov	x0, x23
100664624:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100664628:     	ldr	x20, [x27, #0x38]
10066462c:     	mov	x0, x19
100664630:     	mov	w1, #0x0                ; =0
100664634:     	mov	w2, #0x1                ; =1
100664638:     	mov	x3, x22
10066463c:     	blr	x20
100664640:     	mov	x0, x19
100664644:     	mov	x1, x21
100664648:     	mov	x2, x25
10066464c:     	bl	0x1000840ec
100664650:     	mov	x0, x21
100664654:     	mov	w1, #0x0                ; =0
100664658:     	mov	w2, #0x1                ; =1
10066465c:     	mov	x3, x22
100664660:     	blr	x20
100664664:     	b	0x1006646f0
100664668:     	mov	x0, x20
10066466c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100664670:     	mov	x0, x23
100664674:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100664678:     	mov	x0, #0x0                ; =0
10066467c:     	bl	0x10068c794
100664680:     	mov	x23, x0
100664684:     	ldur	x24, [x0, #-0x8]
100664688:     	ldr	x8, [x24, #0x38]
10066468c:     	mov	x0, x19
100664690:     	mov	w1, #0x1                ; =1
100664694:     	mov	w2, #0x1                ; =1
100664698:     	mov	x3, x23
10066469c:     	blr	x8
1006646a0:     	mov	x20, x22
1006646a4:     	blr	x25
1006646a8:     	mov	x20, x0
1006646ac:     	mov	x8, x21
1006646b0:     	bl	0x1006647b8
1006646b4:     	mov	x0, x20
1006646b8:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1006646bc:     	ldr	x8, [x24, #0x30]
1006646c0:     	mov	x0, x19
1006646c4:     	mov	w1, #0x1                ; =1
1006646c8:     	mov	x2, x23
1006646cc:     	blr	x8
1006646d0:     	cmp	w0, #0x1
1006646d4:     	b.eq	0x1006646f0
1006646d8:     	adrp	x1, 0x102341000
1006646dc:     	add	x1, x1, #0x4a0
1006646e0:     	adrp	x2, 0x101ae1000
1006646e4:     	add	x2, x2, #0xc60 ; possible literal ',)4'
1006646e8:     	mov	x0, x19
1006646ec:     	bl	0x10002d870
1006646f0:     	sub	sp, x29, #0x50
1006646f4:     	ldp	x29, x30, [sp, #0x50]
1006646f8:     	ldp	x20, x19, [sp, #0x40]
1006646fc:     	ldp	x22, x21, [sp, #0x30]
100664700:     	ldp	x24, x23, [sp, #0x20]
100664704:     	ldp	x26, x25, [sp, #0x10]
100664708:     	ldp	x28, x27, [sp], #0x60
10066470c:     	ret
100664710:     	stp	x24, x23, [sp, #-0x40]!
100664714:     	stp	x22, x21, [sp, #0x10]
100664718:     	stp	x20, x19, [sp, #0x20]
10066471c:     	stp	x29, x30, [sp, #0x30]
100664720:     	add	x29, sp, #0x30
100664724:     	mov	x19, x8
100664728:     	ldr	x8, [x2, #0x10]
10066472c:     	cbz	x8, 0x100664784
100664730:     	mov	x20, x2
100664734:     	bl	0x1000240a8
100664738:     	tbz	w1, #0x0, 0x100664784
10066473c:     	mov	x21, x0
100664740:     	ldr	x22, [x20, #0x38]
100664744:     	mov	x0, #0x0                ; =0
100664748:     	bl	0x10068c794
10066474c:     	mov	x20, x0
100664750:     	adrp	x2, 0x10068c000
100664754:     	add	x2, x2, #0x794 ; possible literal '��'
100664758:     	ldur	x23, [x0, #-0x8]
10066475c:     	ldr	x8, [x23, #0x48]
100664760:     	madd	x0, x8, x21, x22
100664764:     	mov	x1, x19
100664768:     	bl	0x1000e73b0
10066476c:     	ldr	x4, [x23, #0x38]
100664770:     	mov	x0, x19
100664774:     	mov	w1, #0x0                ; =0
100664778:     	mov	w2, #0x1                ; =1
10066477c:     	mov	x3, x20
100664780:     	b	0x1006647a4
100664784:     	mov	x0, #0x0                ; =0
100664788:     	bl	0x10068c794
10066478c:     	mov	x3, x0
100664790:     	ldur	x8, [x0, #-0x8]
100664794:     	ldr	x4, [x8, #0x38]
100664798:     	mov	x0, x19
10066479c:     	mov	w1, #0x1                ; =1
1006647a0:     	mov	w2, #0x1                ; =1
1006647a4:     	ldp	x29, x30, [sp, #0x30]
1006647a8:     	ldp	x20, x19, [sp, #0x20]
1006647ac:     	ldp	x22, x21, [sp, #0x10]
1006647b0:     	ldp	x24, x23, [sp], #0x40
1006647b4:     	br	x4
1006647b8:     	stp	x22, x21, [sp, #-0x30]!
1006647bc:     	stp	x20, x19, [sp, #0x10]
1006647c0:     	stp	x29, x30, [sp, #0x20]
1006647c4:     	add	x29, sp, #0x20
1006647c8:     	mov	x20, x0
1006647cc:     	mov	x19, x8
1006647d0:     	ldrb	w8, [x0, #0x20]
1006647d4:     	mov	x9, #-0x1               ; =-1
1006647d8:     	lsl	x8, x9, x8
1006647dc:     	add	x0, x0, #0x40
1006647e0:     	mvn	x1, x8
1006647e4:     	bl	0x101ac745c
1006647e8:     	ldrb	w8, [x20, #0x20]
1006647ec:     	mov	w21, #0x1               ; =1
1006647f0:     	lsl	x8, x21, x8
1006647f4:     	cmp	x0, x8
1006647f8:     	b.eq	0x100664814
1006647fc:     	ldr	w1, [x20, #0x24]
100664800:     	mov	x8, x19
100664804:     	mov	w2, #0x0                ; =0
100664808:     	mov	x3, x20
10066480c:     	bl	0x10068ae7c
100664810:     	mov	w21, #0x0               ; =0
100664814:     	mov	x0, #0x0                ; =0
100664818:     	bl	0x10068c794
10066481c:     	mov	x3, x0
100664820:     	ldur	x8, [x0, #-0x8]
100664824:     	ldr	x4, [x8, #0x38]
100664828:     	mov	x0, x19
10066482c:     	mov	x1, x21
100664830:     	mov	w2, #0x1                ; =1
100664834:     	ldp	x29, x30, [sp, #0x20]
100664838:     	ldp	x20, x19, [sp, #0x10]
10066483c:     	ldp	x22, x21, [sp], #0x30
100664840:     	br	x4
100664844:     	stp	x29, x30, [sp, #-0x10]!
100664848:     	mov	x29, sp
10066484c:     	mov	x2, x1
100664850:     	and	x8, x0, #0xffffffffffff
100664854:     	ubfx	x9, x1, #56, #4
100664858:     	tst	x1, #0x2000000000000000
10066485c:     	csel	x8, x8, x9, eq
100664860:     	cbz	x8, 0x100664888
100664864:     	mov	x1, x0
100664868:     	tbnz	x2, #0x3c, 0x100664894
10066486c:     	tbnz	x2, #0x3d, 0x1006648a0
100664870:     	tbz	x1, #0x3c, 0x1006648b4
100664874:     	and	x8, x2, #0xfffffffffffffff
100664878:     	add	x0, x8, #0x20
10066487c:     	mov	w8, #0x0                ; =0
100664880:     	ldrb	w1, [x0]
100664884:     	b	0x1006648a4
100664888:     	mov	w1, #0x0                ; =0
10066488c:     	mov	w8, #0x1                ; =1
100664890:     	b	0x1006648a4
100664894:     	mov	w0, #0xf                ; =15
100664898:     	bl	0x101ac652c
10066489c:     	mov	x1, x0
1006648a0:     	mov	w8, #0x0                ; =0
1006648a4:     	and	w9, w1, #0xff
1006648a8:     	orr	w0, w9, w8, lsl #8
1006648ac:     	ldp	x29, x30, [sp], #0x10
1006648b0:     	ret
1006648b4:     	mov	x0, x1
1006648b8:     	mov	x1, x2
1006648bc:     	bl	0x101ac7684
1006648c0:     	b	0x10066487c
1006648c4:     	stp	x22, x21, [sp, #-0x30]!
1006648c8:     	stp	x20, x19, [sp, #0x10]
1006648cc:     	stp	x29, x30, [sp, #0x20]
1006648d0:     	add	x29, sp, #0x20
1006648d4:     	ldr	x8, [x0, #0x10]
1006648d8:     	cbz	x8, 0x1006648f0
1006648dc:     	ldp	x19, x20, [x0, #0x20]
1006648e0:     	ldp	x21, x22, [x0, #0x30]
1006648e4:     	mov	x0, x22
1006648e8:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
1006648ec:     	b	0x100664900
1006648f0:     	mov	x19, #0x0               ; =0
1006648f4:     	mov	x20, #0x0               ; =0
1006648f8:     	mov	x21, #0x0               ; =0
1006648fc:     	mov	x22, #0x0               ; =0
100664900:     	mov	x0, x19
100664904:     	mov	x1, x20
100664908:     	mov	x2, x21
10066490c:     	mov	x3, x22
100664910:     	ldp	x29, x30, [sp, #0x20]
100664914:     	ldp	x20, x19, [sp, #0x10]
100664918:     	ldp	x22, x21, [sp], #0x30
10066491c:     	ret
100664920:     	stp	x20, x19, [sp, #-0x20]!
100664924:     	stp	x29, x30, [sp, #0x10]
100664928:     	add	x29, sp, #0x10
10066492c:     	adrp	x0, 0x102341000
100664930:     	add	x0, x0, #0x4a0
100664934:     	adrp	x1, 0x101ae1000
100664938:     	add	x1, x1, #0xc60 ; possible literal ',)4'
10066493c:     	bl	0x100003c4c
100664940:     	ldur	x8, [x0, #-0x8]
100664944:     	ldr	x9, [x8, #0x40]
100664948:     	add	x8, x9, #0xf
10066494c:     	and	x8, x8, #0xfffffffffffffff0
100664950:     	adrp	x16, 0x1022cb000
100664954:     	ldr	x16, [x16, #0x398]
100664958:     	blr	x16
10066495c:     	mov	x9, sp
100664960:     	sub	x19, x9, x8
100664964:     	mov	sp, x19
100664968:     	ldr	x8, [x20]
10066496c:     	ldr	x9, [x8, #0x120]
100664970:     	mov	x8, x19
100664974:     	blr	x9
100664978:     	mov	x0, #0x0                ; =0
10066497c:     	bl	0x10068c794
100664980:     	mov	x20, x0
100664984:     	ldur	x8, [x0, #-0x8]
100664988:     	ldr	x8, [x8, #0x30]
10066498c:     	mov	x0, x19
100664990:     	mov	w1, #0x1                ; =1
100664994:     	mov	x2, x20
100664998:     	blr	x8
10066499c:     	cmp	w0, #0x1
1006649a0:     	b.ne	0x1006649c4
1006649a4:     	adrp	x1, 0x102341000
1006649a8:     	add	x1, x1, #0x4a0
1006649ac:     	adrp	x2, 0x101ae1000
1006649b0:     	add	x2, x2, #0xc60 ; possible literal ',)4'
1006649b4:     	mov	x0, x19
1006649b8:     	bl	0x10002d870
1006649bc:     	mov	x20, #0x0               ; =0
1006649c0:     	b	0x1006649f8
1006649c4:     	mov	x0, x19
1006649c8:     	mov	x1, x20
1006649cc:     	bl	0x101aca78c ; symbol _swift_getEnumCaseMultiPayload
1006649d0:     	cbz	w0, 0x1006649dc
1006649d4:     	mov	x20, #0x0               ; =0
1006649d8:     	b	0x1006649e8
1006649dc:     	ldr	x20, [x19]
1006649e0:     	mov	x0, x20
1006649e4:     	bl	0x101aca978 ; symbol _swift_retain
1006649e8:     	adrp	x1, 0x10068c000
1006649ec:     	add	x1, x1, #0x794 ; possible literal '��'
1006649f0:     	mov	x0, x19
1006649f4:     	bl	0x100059058
1006649f8:     	mov	x0, x20
1006649fc:     	sub	sp, x29, #0x10
100664a00:     	ldp	x29, x30, [sp, #0x10]
100664a04:     	ldp	x20, x19, [sp], #0x20
100664a08:     	ret
100664a0c:     	stp	x20, x19, [sp, #-0x20]!
100664a10:     	stp	x29, x30, [sp, #0x10]
100664a14:     	add	x29, sp, #0x10
100664a18:     	adrp	x0, 0x102341000
100664a1c:     	add	x0, x0, #0x4a0
100664a20:     	adrp	x1, 0x101ae1000
100664a24:     	add	x1, x1, #0xc60 ; possible literal ',)4'
100664a28:     	bl	0x100003c4c
100664a2c:     	ldur	x8, [x0, #-0x8]
100664a30:     	ldr	x9, [x8, #0x40]
100664a34:     	add	x8, x9, #0xf
100664a38:     	and	x8, x8, #0xfffffffffffffff0
100664a3c:     	adrp	x16, 0x1022cb000
100664a40:     	ldr	x16, [x16, #0x398]
100664a44:     	blr	x16
100664a48:     	mov	x9, sp
100664a4c:     	sub	x19, x9, x8
100664a50:     	mov	sp, x19
100664a54:     	ldr	x8, [x20]
100664a58:     	ldr	x9, [x8, #0x120]
100664a5c:     	mov	x8, x19
100664a60:     	blr	x9
100664a64:     	mov	x0, #0x0                ; =0
100664a68:     	bl	0x10068c794
100664a6c:     	mov	x20, x0
100664a70:     	ldur	x8, [x0, #-0x8]
100664a74:     	ldr	x8, [x8, #0x30]
100664a78:     	mov	x0, x19
100664a7c:     	mov	w1, #0x1                ; =1
100664a80:     	mov	x2, x20
100664a84:     	blr	x8
100664a88:     	cmp	w0, #0x1
100664a8c:     	b.ne	0x100664ab0
100664a90:     	adrp	x1, 0x102341000
100664a94:     	add	x1, x1, #0x4a0
100664a98:     	adrp	x2, 0x101ae1000
100664a9c:     	add	x2, x2, #0xc60 ; possible literal ',)4'
100664aa0:     	mov	x0, x19
100664aa4:     	bl	0x10002d870
100664aa8:     	mov	x20, #0x0               ; =0
100664aac:     	b	0x100664ae4
100664ab0:     	mov	x0, x19
100664ab4:     	mov	x1, x20
100664ab8:     	bl	0x101aca78c ; symbol _swift_getEnumCaseMultiPayload
100664abc:     	cbz	w0, 0x100664ac8
100664ac0:     	mov	x20, #0x0               ; =0
100664ac4:     	b	0x100664ad4
100664ac8:     	ldr	x20, [x19, #0x8]
100664acc:     	mov	x0, x20
100664ad0:     	bl	0x101ac9d3c ; symbol _objc_retain
100664ad4:     	adrp	x1, 0x10068c000
100664ad8:     	add	x1, x1, #0x794 ; possible literal '��'
100664adc:     	mov	x0, x19
100664ae0:     	bl	0x100059058
100664ae4:     	mov	x0, x20
100664ae8:     	sub	sp, x29, #0x10
100664aec:     	ldp	x29, x30, [sp, #0x10]
100664af0:     	ldp	x20, x19, [sp], #0x20
100664af4:     	ret
100664af8:     	stp	x20, x19, [sp, #-0x20]!
100664afc:     	stp	x29, x30, [sp, #0x10]
100664b00:     	add	x29, sp, #0x10
100664b04:     	adrp	x0, 0x102341000
100664b08:     	add	x0, x0, #0x4a0
100664b0c:     	adrp	x1, 0x101ae1000
100664b10:     	add	x1, x1, #0xc60 ; possible literal ',)4'
100664b14:     	bl	0x100003c4c
100664b18:     	ldur	x8, [x0, #-0x8]
100664b1c:     	ldr	x9, [x8, #0x40]
100664b20:     	add	x8, x9, #0xf
100664b24:     	and	x8, x8, #0xfffffffffffffff0
100664b28:     	adrp	x16, 0x1022cb000
100664b2c:     	ldr	x16, [x16, #0x398]
100664b30:     	blr	x16
100664b34:     	mov	x9, sp
100664b38:     	sub	x19, x9, x8
100664b3c:     	mov	sp, x19
100664b40:     	ldr	x8, [x20]
100664b44:     	ldr	x9, [x8, #0x120]
100664b48:     	mov	x8, x19
100664b4c:     	blr	x9
100664b50:     	mov	x0, #0x0                ; =0
100664b54:     	bl	0x10068c794
100664b58:     	mov	x20, x0
100664b5c:     	ldur	x8, [x0, #-0x8]
100664b60:     	ldr	x8, [x8, #0x30]
100664b64:     	mov	x0, x19
100664b68:     	mov	w1, #0x1                ; =1
100664b6c:     	mov	x2, x20
100664b70:     	blr	x8
100664b74:     	cmp	w0, #0x1
100664b78:     	b.ne	0x100664b9c
100664b7c:     	adrp	x1, 0x102341000
100664b80:     	add	x1, x1, #0x4a0
100664b84:     	adrp	x2, 0x101ae1000
100664b88:     	add	x2, x2, #0xc60 ; possible literal ',)4'
100664b8c:     	mov	x0, x19
100664b90:     	bl	0x10002d870
100664b94:     	mov	x0, #0x0                ; =0
100664b98:     	b	0x100664bf8
100664b9c:     	mov	x0, x19
100664ba0:     	mov	x1, x20
100664ba4:     	bl	0x101aca78c ; symbol _swift_getEnumCaseMultiPayload
100664ba8:     	mov	w8, #0x8                ; =8
100664bac:     	cmp	w0, #0x1
100664bb0:     	b.gt	0x100664bc4
100664bb4:     	cbz	w0, 0x100664bd8
100664bb8:     	mov	x0, #0x0                ; =0
100664bbc:     	bl	0x10068c76c
100664bc0:     	b	0x100664bd4
100664bc4:     	cmp	w0, #0x2
100664bc8:     	b.ne	0x100664bd8
100664bcc:     	mov	x0, #0x0                ; =0
100664bd0:     	bl	0x10068c780
100664bd4:     	ldrsw	x8, [x0, #0x14]
100664bd8:     	ldr	x0, [x19, x8]
100664bdc:     	bl	0x101ac9d3c ; symbol _objc_retain
100664be0:     	mov	x20, x0
100664be4:     	adrp	x1, 0x10068c000
100664be8:     	add	x1, x1, #0x794 ; possible literal '��'
100664bec:     	mov	x0, x19
100664bf0:     	bl	0x100059058
100664bf4:     	mov	x0, x20
100664bf8:     	sub	sp, x29, #0x10
100664bfc:     	ldp	x29, x30, [sp, #0x10]
100664c00:     	ldp	x20, x19, [sp], #0x20
100664c04:     	ret
100664c08:     	stp	x22, x21, [sp, #-0x30]!
100664c0c:     	stp	x20, x19, [sp, #0x10]
100664c10:     	stp	x29, x30, [sp, #0x20]
100664c14:     	add	x29, sp, #0x20
100664c18:     	mov	x19, x8
100664c1c:     	adrp	x0, 0x102341000
100664c20:     	add	x0, x0, #0x4a0
100664c24:     	adrp	x1, 0x101ae1000
100664c28:     	add	x1, x1, #0xc60 ; possible literal ',)4'
100664c2c:     	bl	0x100003c4c
100664c30:     	ldur	x8, [x0, #-0x8]
100664c34:     	ldr	x9, [x8, #0x40]
100664c38:     	add	x8, x9, #0xf
100664c3c:     	and	x8, x8, #0xfffffffffffffff0
100664c40:     	adrp	x16, 0x1022cb000
100664c44:     	ldr	x16, [x16, #0x398]
100664c48:     	blr	x16
100664c4c:     	mov	x9, sp
100664c50:     	sub	x21, x9, x8
100664c54:     	mov	sp, x21
100664c58:     	ldr	x8, [x20]
100664c5c:     	ldr	x9, [x8, #0x120]
100664c60:     	mov	x8, x21
100664c64:     	blr	x9
100664c68:     	mov	x0, #0x0                ; =0
100664c6c:     	bl	0x10068c794
100664c70:     	mov	x20, x0
100664c74:     	ldur	x8, [x0, #-0x8]
100664c78:     	ldr	x8, [x8, #0x30]
100664c7c:     	mov	x0, x21
100664c80:     	mov	w1, #0x1                ; =1
100664c84:     	mov	x2, x20
100664c88:     	blr	x8
100664c8c:     	cmp	w0, #0x1
100664c90:     	b.ne	0x100664cd4
100664c94:     	adrp	x1, 0x102341000
100664c98:     	add	x1, x1, #0x4a0
100664c9c:     	adrp	x2, 0x101ae1000
100664ca0:     	add	x2, x2, #0xc60 ; possible literal ',)4'
100664ca4:     	mov	x0, x21
100664ca8:     	bl	0x10002d870
100664cac:     	mov	x0, #0x0                ; =0
100664cb0:     	bl	0x10068c76c
100664cb4:     	mov	x3, x0
100664cb8:     	ldur	x8, [x0, #-0x8]
100664cbc:     	ldr	x8, [x8, #0x38]
100664cc0:     	mov	x0, x19
100664cc4:     	mov	w1, #0x1                ; =1
100664cc8:     	mov	w2, #0x1                ; =1
100664ccc:     	blr	x8
100664cd0:     	b	0x100664d3c
100664cd4:     	mov	x0, x21
100664cd8:     	mov	x1, x20
100664cdc:     	bl	0x101aca78c ; symbol _swift_getEnumCaseMultiPayload
100664ce0:     	cmp	w0, #0x1
100664ce4:     	b.ne	0x100664d04
100664ce8:     	adrp	x2, 0x10068c000
100664cec:     	add	x2, x2, #0x76c ; possible literal '��'
100664cf0:     	mov	x0, x21
100664cf4:     	mov	x1, x19
100664cf8:     	bl	0x1000e73b0
100664cfc:     	mov	w20, #0x0               ; =0
100664d00:     	b	0x100664d08
100664d04:     	mov	w20, #0x1               ; =1
100664d08:     	mov	x0, #0x0                ; =0
100664d0c:     	bl	0x10068c76c
100664d10:     	mov	x3, x0
100664d14:     	ldur	x8, [x0, #-0x8]
100664d18:     	ldr	x8, [x8, #0x38]
100664d1c:     	mov	x0, x19
100664d20:     	mov	x1, x20
100664d24:     	mov	w2, #0x1                ; =1
100664d28:     	blr	x8
100664d2c:     	adrp	x1, 0x10068c000
100664d30:     	add	x1, x1, #0x794 ; possible literal '��'
100664d34:     	mov	x0, x21
100664d38:     	bl	0x100059058
100664d3c:     	sub	sp, x29, #0x20
100664d40:     	ldp	x29, x30, [sp, #0x20]
100664d44:     	ldp	x20, x19, [sp, #0x10]
100664d48:     	ldp	x22, x21, [sp], #0x30
100664d4c:     	ret
100664d50:     	stp	x28, x27, [sp, #-0x60]!
100664d54:     	stp	x26, x25, [sp, #0x10]
100664d58:     	stp	x24, x23, [sp, #0x20]
100664d5c:     	stp	x22, x21, [sp, #0x30]
100664d60:     	stp	x20, x19, [sp, #0x40]
100664d64:     	stp	x29, x30, [sp, #0x50]
100664d68:     	add	x29, sp, #0x50
100664d6c:     	mov	x24, x20
100664d70:     	mov	x0, #0x0                ; =0
100664d74:     	bl	0x10068c794
100664d78:     	mov	x19, x0
100664d7c:     	ldur	x27, [x0, #-0x8]
100664d80:     	ldr	x8, [x27, #0x40]
100664d84:     	mov	x9, x8
100664d88:     	adrp	x16, 0x1022cb000
100664d8c:     	ldr	x16, [x16, #0x398]
100664d90:     	blr	x16
100664d94:     	mov	x9, sp
100664d98:     	add	x8, x8, #0xf
100664d9c:     	and	x8, x8, #0xfffffffffffffff0
100664da0:     	sub	x21, x9, x8
100664da4:     	mov	sp, x21
100664da8:     	adrp	x0, 0x102341000
100664dac:     	add	x0, x0, #0x4a0
100664db0:     	adrp	x1, 0x101ae1000
100664db4:     	add	x1, x1, #0xc60 ; possible literal ',)4'
100664db8:     	bl	0x100003c4c
100664dbc:     	ldur	x8, [x0, #-0x8]
100664dc0:     	ldr	x8, [x8, #0x40]
100664dc4:     	mov	x9, x8
100664dc8:     	adrp	x16, 0x1022cb000
100664dcc:     	ldr	x16, [x16, #0x398]
100664dd0:     	blr	x16
100664dd4:     	mov	x9, sp
100664dd8:     	add	x10, x8, #0xf
100664ddc:     	and	x12, x10, #0xfffffffffffffff0
100664de0:     	sub	x23, x9, x12
100664de4:     	mov	sp, x23
100664de8:     	mov	x9, x8
100664dec:     	adrp	x16, 0x1022cb000
100664df0:     	ldr	x16, [x16, #0x398]
100664df4:     	blr	x16
100664df8:     	mov	x8, sp
100664dfc:     	sub	x22, x8, x12
100664e00:     	mov	sp, x22
100664e04:     	ldr	x8, [x20]
100664e08:     	ldr	x8, [x8, #0x78]
100664e0c:     	blr	x8
100664e10:     	mov	x20, x0
100664e14:     	ldr	x8, [x0]
100664e18:     	ldr	x8, [x8, #0x118]
100664e1c:     	blr	x8
100664e20:     	mov	x26, x0
100664e24:     	mov	x25, x1
100664e28:     	mov	x0, x20
100664e2c:     	bl	0x101aca960 ; symbol _swift_release
100664e30:     	cbz	x25, 0x100664eec
100664e34:     	ldr	x8, [x24]
100664e38:     	ldr	x8, [x8, #0x90]
100664e3c:     	mov	x20, x24
100664e40:     	blr	x8
100664e44:     	mov	x20, x0
100664e48:     	ldr	x8, [x0, #0x10]
100664e4c:     	cbz	x8, 0x100664e94
100664e50:     	mov	x0, x26
100664e54:     	mov	x1, x25
100664e58:     	bl	0x1000240a8
100664e5c:     	tbz	w1, #0x0, 0x100664e94
100664e60:     	ldr	x8, [x20, #0x38]
100664e64:     	ldr	x9, [x27, #0x48]
100664e68:     	madd	x0, x9, x0, x8
100664e6c:     	adrp	x2, 0x10068c000
100664e70:     	add	x2, x2, #0x794 ; possible literal '��'
100664e74:     	mov	x1, x22
100664e78:     	bl	0x1000e73b0
100664e7c:     	mov	x0, x20
100664e80:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100664e84:     	mov	x0, x25
100664e88:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100664e8c:     	mov	w1, #0x0                ; =0
100664e90:     	b	0x100664ea8
100664e94:     	mov	x0, x20
100664e98:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100664e9c:     	mov	x0, x25
100664ea0:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100664ea4:     	mov	w1, #0x1                ; =1
100664ea8:     	ldr	x8, [x27, #0x38]
100664eac:     	mov	x0, x22
100664eb0:     	mov	w2, #0x1                ; =1
100664eb4:     	mov	x3, x19
100664eb8:     	blr	x8
100664ebc:     	ldr	x8, [x27, #0x30]
100664ec0:     	mov	x0, x22
100664ec4:     	mov	w1, #0x1                ; =1
100664ec8:     	mov	x2, x19
100664ecc:     	blr	x8
100664ed0:     	cbz	w0, 0x100664f4c
100664ed4:     	adrp	x1, 0x102341000
100664ed8:     	add	x1, x1, #0x4a0
100664edc:     	adrp	x2, 0x101ae1000
100664ee0:     	add	x2, x2, #0xc60 ; possible literal ',)4'
100664ee4:     	mov	x0, x22
100664ee8:     	b	0x100664f40
100664eec:     	ldr	x8, [x24]
100664ef0:     	ldr	x8, [x8, #0x90]
100664ef4:     	mov	x20, x24
100664ef8:     	blr	x8
100664efc:     	mov	x20, x0
100664f00:     	mov	x8, x23
100664f04:     	bl	0x1006647b8
100664f08:     	mov	x0, x20
100664f0c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100664f10:     	ldr	x8, [x27, #0x30]
100664f14:     	mov	x0, x23
100664f18:     	mov	w1, #0x1                ; =1
100664f1c:     	mov	x2, x19
100664f20:     	blr	x8
100664f24:     	cmp	w0, #0x1
100664f28:     	b.ne	0x100664f90
100664f2c:     	adrp	x1, 0x102341000
100664f30:     	add	x1, x1, #0x4a0
100664f34:     	adrp	x2, 0x101ae1000
100664f38:     	add	x2, x2, #0xc60 ; possible literal ',)4'
100664f3c:     	mov	x0, x23
100664f40:     	bl	0x10002d870
100664f44:     	mov	x19, #0x0               ; =0
100664f48:     	b	0x100664fe0
100664f4c:     	adrp	x2, 0x10068c000
100664f50:     	add	x2, x2, #0x794 ; possible literal '��'
100664f54:     	mov	x0, x22
100664f58:     	mov	x1, x21
100664f5c:     	bl	0x1000e73b0
100664f60:     	adrp	x1, 0x102341000
100664f64:     	add	x1, x1, #0x4a0
100664f68:     	adrp	x2, 0x101ae1000
100664f6c:     	add	x2, x2, #0xc60 ; possible literal ',)4'
100664f70:     	mov	x0, x22
100664f74:     	bl	0x10002d870
100664f78:     	mov	x0, x21
100664f7c:     	mov	x1, x19
100664f80:     	bl	0x101aca78c ; symbol _swift_getEnumCaseMultiPayload
100664f84:     	cbz	w0, 0x100664fa8
100664f88:     	mov	x19, #0x0               ; =0
100664f8c:     	b	0x100664fb4
100664f90:     	mov	x0, x23
100664f94:     	mov	x1, x19
100664f98:     	bl	0x101aca78c ; symbol _swift_getEnumCaseMultiPayload
100664f9c:     	cbz	w0, 0x100664fc4
100664fa0:     	mov	x19, #0x0               ; =0
100664fa4:     	b	0x100664fd0
100664fa8:     	ldr	x19, [x21]
100664fac:     	mov	x0, x19
100664fb0:     	bl	0x101aca978 ; symbol _swift_retain
100664fb4:     	adrp	x1, 0x10068c000
100664fb8:     	add	x1, x1, #0x794 ; possible literal '��'
100664fbc:     	mov	x0, x21
100664fc0:     	b	0x100664fdc
100664fc4:     	ldr	x19, [x23]
100664fc8:     	mov	x0, x19
100664fcc:     	bl	0x101aca978 ; symbol _swift_retain
100664fd0:     	adrp	x1, 0x10068c000
100664fd4:     	add	x1, x1, #0x794 ; possible literal '��'
100664fd8:     	mov	x0, x23
100664fdc:     	bl	0x100059058
100664fe0:     	mov	x0, x19
100664fe4:     	sub	sp, x29, #0x50
100664fe8:     	ldp	x29, x30, [sp, #0x50]
100664fec:     	ldp	x20, x19, [sp, #0x40]
100664ff0:     	ldp	x22, x21, [sp, #0x30]
100664ff4:     	ldp	x24, x23, [sp, #0x20]
100664ff8:     	ldp	x26, x25, [sp, #0x10]
100664ffc:     	ldp	x28, x27, [sp], #0x60
100665000:     	ret
100665004:     	stp	x28, x27, [sp, #-0x60]!
100665008:     	stp	x26, x25, [sp, #0x10]
10066500c:     	stp	x24, x23, [sp, #0x20]
100665010:     	stp	x22, x21, [sp, #0x30]
100665014:     	stp	x20, x19, [sp, #0x40]
100665018:     	stp	x29, x30, [sp, #0x50]
10066501c:     	add	x29, sp, #0x50
100665020:     	sub	sp, sp, #0x30
100665024:     	mov	x25, x20
100665028:     	mov	x22, x1
10066502c:     	mov	x23, x0
100665030:     	mov	x28, x8
100665034:     	adrp	x0, 0x102341000
100665038:     	add	x0, x0, #0x4a0
10066503c:     	adrp	x1, 0x101ae1000
100665040:     	add	x1, x1, #0xc60 ; possible literal ',)4'
100665044:     	bl	0x100003c4c
100665048:     	ldur	x8, [x0, #-0x8]
10066504c:     	ldr	x9, [x8, #0x40]
100665050:     	add	x8, x9, #0xf
100665054:     	and	x8, x8, #0xfffffffffffffff0
100665058:     	adrp	x16, 0x1022cb000
10066505c:     	ldr	x16, [x16, #0x398]
100665060:     	blr	x16
100665064:     	mov	x9, sp
100665068:     	sub	x24, x9, x8
10066506c:     	mov	sp, x24
100665070:     	mov	x0, #0x0                ; =0
100665074:     	bl	0x10068c794
100665078:     	mov	x21, x0
10066507c:     	ldur	x19, [x0, #-0x8]
100665080:     	ldr	x8, [x19, #0x40]
100665084:     	mov	x9, x8
100665088:     	adrp	x16, 0x1022cb000
10066508c:     	ldr	x16, [x16, #0x398]
100665090:     	blr	x16
100665094:     	mov	x9, sp
100665098:     	add	x10, x8, #0xf
10066509c:     	and	x12, x10, #0xfffffffffffffff0
1006650a0:     	sub	x27, x9, x12
1006650a4:     	mov	sp, x27
1006650a8:     	mov	x9, x8
1006650ac:     	adrp	x16, 0x1022cb000
1006650b0:     	ldr	x16, [x16, #0x398]
1006650b4:     	blr	x16
1006650b8:     	mov	x8, sp
1006650bc:     	sub	x26, x8, x12
1006650c0:     	mov	sp, x26
1006650c4:     	ldr	x8, [x20]
1006650c8:     	ldr	x8, [x8, #0x90]
1006650cc:     	blr	x8
1006650d0:     	mov	x20, x0
1006650d4:     	ldr	x8, [x0, #0x10]
1006650d8:     	cbz	x8, 0x1006651e0
1006650dc:     	mov	x0, x23
1006650e0:     	mov	x1, x22
1006650e4:     	bl	0x1000240a8
1006650e8:     	tbz	w1, #0x0, 0x1006651e0
1006650ec:     	stur	x28, [x29, #-0x78]
1006650f0:     	ldr	x8, [x20, #0x38]
1006650f4:     	ldr	x9, [x19, #0x48]
1006650f8:     	madd	x0, x9, x0, x8
1006650fc:     	adrp	x28, 0x10068c000
100665100:     	add	x28, x28, #0x794 ; possible literal '��'
100665104:     	mov	x1, x27
100665108:     	mov	x2, x28
10066510c:     	bl	0x1000e73b0
100665110:     	mov	x0, x20
100665114:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100665118:     	mov	x0, x27
10066511c:     	mov	x1, x26
100665120:     	mov	x2, x28
100665124:     	bl	0x1000840ec
100665128:     	ldr	x8, [x25]
10066512c:     	ldr	x8, [x8, #0x78]
100665130:     	mov	x20, x25
100665134:     	blr	x8
100665138:     	mov	x20, x0
10066513c:     	ldr	x8, [x0]
100665140:     	ldr	x8, [x8, #0x1e0]
100665144:     	mov	x0, x23
100665148:     	mov	x1, x22
10066514c:     	blr	x8
100665150:     	mov	x0, x20
100665154:     	bl	0x101aca960 ; symbol _swift_release
100665158:     	mov	x0, x26
10066515c:     	mov	x1, x21
100665160:     	bl	0x101aca78c ; symbol _swift_getEnumCaseMultiPayload
100665164:     	cbnz	w0, 0x1006651b4
100665168:     	ldr	x0, [x26, #0x8]
10066516c:     	ldr	x8, [x0]
100665170:     	adrp	x9, 0x1022cf000
100665174:     	ldr	x9, [x9, #0x718]
100665178:     	ldr	x9, [x9]
10066517c:     	and	x8, x9, x8
100665180:     	ldr	x28, [x8, #0xa18]
100665184:     	bl	0x101ac9d3c ; symbol _objc_retain
100665188:     	mov	x27, x0
10066518c:     	mov	x20, x0
100665190:     	blr	x28
100665194:     	mov	x20, x0
100665198:     	mov	x0, x27
10066519c:     	bl	0x101ac9d30 ; symbol _objc_release
1006651a0:     	cbz	x20, 0x1006651b4
1006651a4:     	mov	x0, x20
1006651a8:     	bl	0x101ad0a80 ; selector removeFromSuperview
1006651ac:     	mov	x0, x20
1006651b0:     	bl	0x101ac9d30 ; symbol _objc_release
1006651b4:     	mov	x0, x26
1006651b8:     	mov	x1, x21
1006651bc:     	bl	0x101aca78c ; symbol _swift_getEnumCaseMultiPayload
1006651c0:     	mov	w8, #0x8                ; =8
1006651c4:     	cmp	w0, #0x1
