1004b57dc:	stp	x20, x19, [sp, #-0x20]!
1004b57e0:	stp	x29, x30, [sp, #0x10]
1004b57e4:	add	x29, sp, #0x10
1004b57e8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b57ec:	mov	x20, x0
1004b57f0:	bl	0x1004b5644
1004b57f4:	mov	x0, x20
1004b57f8:	ldp	x29, x30, [sp, #0x10]
1004b57fc:	ldp	x20, x19, [sp], #0x20
1004b5800:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004b5804:	stp	x24, x23, [sp, #-0x40]!
1004b5808:	stp	x22, x21, [sp, #0x10]
1004b580c:	stp	x20, x19, [sp, #0x20]
1004b5810:	stp	x29, x30, [sp, #0x30]
1004b5814:	add	x29, sp, #0x30
1004b5818:	adrp	x8, 7912 ; 0x10239d000
1004b581c:	ldr	x23, [x8, #0x2d0]
1004b5820:	ldrb	w8, [x20, x23]
1004b5824:	tbnz	w8, #0x0, 0x1004b592c
1004b5828:	adrp	x8, 7840 ; 0x102355000
1004b582c:	ldr	x8, [x8, #0xe8]
1004b5830:	ldr	x19, [x20, x8]
1004b5834:	cbz	x19, 0x1004b592c
1004b5838:	adrp	x8, 7912 ; 0x10239d000
1004b583c:	ldr	x8, [x8, #0x248]
1004b5840:	add	x0, x20, x8
1004b5844:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b5848:	cbz	x0, 0x1004b592c
1004b584c:	mov	x22, x20
1004b5850:	ldr	x8, [x0]
1004b5854:	ldr	x24, [x8, #0x260]
1004b5858:	mov	x20, x0
1004b585c:	mov	x0, x19
1004b5860:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b5864:	mov	x21, x0
1004b5868:	blr	x24
1004b586c:	mov	x19, x0
1004b5870:	mov	x0, x20
1004b5874:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b5878:	cbz	x19, 0x1004b5940
1004b587c:	mov	w8, #0x1
1004b5880:	strb	w8, [x22, x23]
1004b5884:	ldr	x8, [x19]
1004b5888:	ldr	x23, [x8, #0x618]
1004b588c:	mov	x0, x21
1004b5890:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b5894:	mov	x21, x0
1004b5898:	mov	x20, x19
1004b589c:	blr	x23
1004b58a0:	mov	x20, x1
1004b58a4:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b58a8:	mov	x23, x0
1004b58ac:	mov	x0, x20
1004b58b0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b58b4:	mov	x0, x21
1004b58b8:	mov	x2, x23
1004b58bc:	bl	0x101ad4440 ; selector setStringValue:
1004b58c0:	mov	x0, x21
1004b58c4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b58c8:	mov	x0, x23
1004b58cc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b58d0:	mov	x0, #0x7250
1004b58d4:	movk	x0, #0x6665, lsl #16
1004b58d8:	movk	x0, #0x7869, lsl #32
1004b58dc:	movk	x0, #0x2e2e, lsl #48
1004b58e0:	mov	x1, #0x2e
1004b58e4:	movk	x1, #0xe900, lsl #48
1004b58e8:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b58ec:	mov	x20, x0
1004b58f0:	mov	x0, x21
1004b58f4:	mov	x2, x20
1004b58f8:	bl	0x101ad3aa0 ; selector setPlaceholderString:
1004b58fc:	mov	x0, x20
1004b5900:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5904:	mov	x20, x22
1004b5908:	bl	0x1004b5a6c
1004b590c:	mov	x0, x21
1004b5910:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5914:	mov	x0, x19
1004b5918:	ldp	x29, x30, [sp, #0x30]
1004b591c:	ldp	x20, x19, [sp, #0x20]
1004b5920:	ldp	x22, x21, [sp, #0x10]
1004b5924:	ldp	x24, x23, [sp], #0x40
1004b5928:	b	0x101aca960 ; symbol stub for: _swift_release
1004b592c:	ldp	x29, x30, [sp, #0x30]
1004b5930:	ldp	x20, x19, [sp, #0x20]
1004b5934:	ldp	x22, x21, [sp, #0x10]
1004b5938:	ldp	x24, x23, [sp], #0x40
1004b593c:	ret
1004b5940:	mov	x0, x21
1004b5944:	ldp	x29, x30, [sp, #0x30]
1004b5948:	ldp	x20, x19, [sp, #0x20]
1004b594c:	ldp	x22, x21, [sp, #0x10]
1004b5950:	ldp	x24, x23, [sp], #0x40
1004b5954:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004b5958:	stp	x20, x19, [sp, #-0x20]!
1004b595c:	stp	x29, x30, [sp, #0x10]
1004b5960:	add	x29, sp, #0x10
1004b5964:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b5968:	mov	x20, x0
1004b596c:	bl	0x1004b5804
1004b5970:	mov	x0, x20
1004b5974:	ldp	x29, x30, [sp, #0x10]
1004b5978:	ldp	x20, x19, [sp], #0x20
1004b597c:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004b5980:	stp	x22, x21, [sp, #-0x30]!
1004b5984:	stp	x20, x19, [sp, #0x10]
1004b5988:	stp	x29, x30, [sp, #0x20]
1004b598c:	add	x29, sp, #0x20
1004b5990:	adrp	x8, 7840 ; 0x102355000
1004b5994:	ldr	x8, [x8, #0xe8]
1004b5998:	ldr	x0, [x20, x8]
1004b599c:	cbz	x0, 0x1004b5a34
1004b59a0:	adrp	x8, 7912 ; 0x10239d000
1004b59a4:	ldr	x8, [x8, #0x2d0]
1004b59a8:	strb	wzr, [x20, x8]
1004b59ac:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b59b0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b59b4:	mov	x19, x0
1004b59b8:	mov	x0, #0x0
1004b59bc:	mov	x1, #-0x2000000000000000
1004b59c0:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b59c4:	mov	x21, x0
1004b59c8:	mov	x0, x19
1004b59cc:	mov	x2, x21
1004b59d0:	bl	0x101ad4440 ; selector setStringValue:
1004b59d4:	mov	x0, x19
1004b59d8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b59dc:	mov	x0, x21
1004b59e0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b59e4:	mov	x0, #0x6154
1004b59e8:	movk	x0, #0x2062, lsl #16
1004b59ec:	movk	x0, #0x616e, lsl #32
1004b59f0:	movk	x0, #0x656d, lsl #48
1004b59f4:	mov	x1, #-0x1800000000000000
1004b59f8:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b59fc:	mov	x21, x0
1004b5a00:	mov	x0, x19
1004b5a04:	mov	x2, x21
1004b5a08:	bl	0x101ad3aa0 ; selector setPlaceholderString:
1004b5a0c:	mov	x0, x21
1004b5a10:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5a14:	bl	0x1004b5a6c
1004b5a18:	mov	x0, x19
1004b5a1c:	bl	0x1004b5d84
1004b5a20:	mov	x0, x19
1004b5a24:	ldp	x29, x30, [sp, #0x20]
1004b5a28:	ldp	x20, x19, [sp, #0x10]
1004b5a2c:	ldp	x22, x21, [sp], #0x30
1004b5a30:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004b5a34:	ldp	x29, x30, [sp, #0x20]
1004b5a38:	ldp	x20, x19, [sp, #0x10]
1004b5a3c:	ldp	x22, x21, [sp], #0x30
1004b5a40:	ret
1004b5a44:	stp	x20, x19, [sp, #-0x20]!
1004b5a48:	stp	x29, x30, [sp, #0x10]
1004b5a4c:	add	x29, sp, #0x10
1004b5a50:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b5a54:	mov	x20, x0
1004b5a58:	bl	0x1004b5980
1004b5a5c:	mov	x0, x20
1004b5a60:	ldp	x29, x30, [sp, #0x10]
1004b5a64:	ldp	x20, x19, [sp], #0x20
1004b5a68:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004b5a6c:	sub	sp, sp, #0xa0
1004b5a70:	stp	d9, d8, [sp, #0x30]
1004b5a74:	stp	x28, x27, [sp, #0x40]
1004b5a78:	stp	x26, x25, [sp, #0x50]
1004b5a7c:	stp	x24, x23, [sp, #0x60]
1004b5a80:	stp	x22, x21, [sp, #0x70]
1004b5a84:	stp	x20, x19, [sp, #0x80]
1004b5a88:	stp	x29, x30, [sp, #0x90]
1004b5a8c:	add	x29, sp, #0x90
1004b5a90:	adrp	x8, 7912 ; 0x10239d000
1004b5a94:	ldr	x26, [x8, #0x2d0]
1004b5a98:	ldrb	w8, [x20, x26]
1004b5a9c:	tbz	w8, #0x0, 0x1004b5ab8
1004b5aa0:	adrp	x8, 7912 ; 0x10239d000
1004b5aa4:	ldr	x8, [x8, #0x2d8]
1004b5aa8:	ldr	d0, [x20, x8]
1004b5aac:	fmov	d1, #0.50000000
1004b5ab0:	fmul	d8, d0, d1
1004b5ab4:	b	0x1004b5ac4
1004b5ab8:	adrp	x8, 7912 ; 0x10239d000
1004b5abc:	ldr	x8, [x8, #0x2e0]
1004b5ac0:	ldr	d8, [x20, x8]
1004b5ac4:	adrp	x8, 7793 ; 0x102326000
1004b5ac8:	ldr	x0, [x8, #0x9d0] ; Objc class ref: _OBJC_CLASS_$_NSAnimationContext
1004b5acc:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b5ad0:	mov	x22, x0
1004b5ad4:	adrp	x0, 7462 ; 0x1021db000
1004b5ad8:	add	x0, x0, #0x990
1004b5adc:	mov	w1, #0x20
1004b5ae0:	mov	w2, #0x7
1004b5ae4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b5ae8:	mov	x19, x0
1004b5aec:	str	x20, [x0, #0x10]
1004b5af0:	str	d8, [x0, #0x18]
1004b5af4:	adrp	x0, 7462 ; 0x1021db000
1004b5af8:	add	x0, x0, #0x9b8
1004b5afc:	mov	w1, #0x20
1004b5b00:	mov	w2, #0x7
1004b5b04:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b5b08:	mov	x23, x0
1004b5b0c:	adrp	x8, 14 ; 0x1004c3000
1004b5b10:	add	x8, x8, #0xf38
1004b5b14:	stp	x8, x19, [x0, #0x10]
1004b5b18:	adrp	x8, -1202 ; 0x100003000
1004b5b1c:	add	x8, x8, #0x8c4
1004b5b20:	stp	x8, x0, [sp, #0x20]
1004b5b24:	adrp	x8, 7702 ; 0x1022cb000
1004b5b28:	ldr	x8, [x8, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1004b5b2c:	str	x8, [sp]
1004b5b30:	adrp	x8, 5676 ; 0x101ae1000
1004b5b34:	ldr	d0, [x8]
1004b5b38:	str	d0, [sp, #0x8]
1004b5b3c:	adrp	x8, -1203 ; 0x100002000
1004b5b40:	add	x8, x8, #0xfdc
1004b5b44:	adrp	x9, 7462 ; 0x1021db000
1004b5b48:	add	x9, x9, #0x9d0
1004b5b4c:	stp	x8, x9, [sp, #0x10]
1004b5b50:	mov	x0, sp
1004b5b54:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004b5b58:	mov	x24, x0
1004b5b5c:	ldr	x25, [sp, #0x28]
1004b5b60:	mov	x0, x20
1004b5b64:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b5b68:	mov	x21, x0
1004b5b6c:	mov	x0, x23
1004b5b70:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b5b74:	mov	x0, x25
1004b5b78:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b5b7c:	mov	x0, x22
1004b5b80:	mov	x2, x24
1004b5b84:	bl	0x101ad1000 ; selector runAnimationGroup:
1004b5b88:	mov	x0, x24
1004b5b8c:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004b5b90:	adrp	x1, 6414 ; 0x101dc3000
1004b5b94:	add	x1, x1, #0x8e0 ; literal pool for: ""
1004b5b98:	mov	x0, x23
1004b5b9c:	mov	w2, #0x6c
1004b5ba0:	mov	w3, #0x2ca
1004b5ba4:	mov	w4, #0x2e
1004b5ba8:	mov	w5, #0x1
1004b5bac:	bl	0x101aca8e8 ; symbol stub for: _swift_isEscapingClosureAtFileLocation
1004b5bb0:	mov	x22, x0
1004b5bb4:	mov	x0, x23
1004b5bb8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b5bbc:	tbnz	w22, #0x0, 0x1004b5d80
1004b5bc0:	adrp	x8, 7912 ; 0x10239d000
1004b5bc4:	ldr	x27, [x8, #0x298]
1004b5bc8:	ldr	x0, [x21, x27]
1004b5bcc:	adrp	x24, 7701 ; 0x1022ca000
1004b5bd0:	ldr	x24, [x24, #0x618] ; literal pool symbol address: _NSFontWeightRegular
1004b5bd4:	adrp	x25, 7701 ; 0x1022ca000
1004b5bd8:	ldr	x25, [x25, #0x610] ; literal pool symbol address: _NSFontWeightMedium
1004b5bdc:	cbz	x0, 0x1004b5c8c
1004b5be0:	ldrb	w8, [x20, x26]
1004b5be4:	cmp	w8, #0x0
1004b5be8:	csel	x8, x24, x25, ne
1004b5bec:	ldr	d8, [x8]
1004b5bf0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b5bf4:	mov	x22, x0
1004b5bf8:	fmov	d0, #11.00000000
1004b5bfc:	mov.16b	v1, v8
1004b5c00:	bl	0x100004700
1004b5c04:	mov	x23, x0
1004b5c08:	mov	x0, x22
1004b5c0c:	mov	x2, x23
1004b5c10:	bl	0x101ad2aa0 ; selector setFont:
1004b5c14:	mov	x0, x22
1004b5c18:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5c1c:	mov	x0, x23
1004b5c20:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5c24:	ldr	x22, [x21, x27]
1004b5c28:	cbz	x22, 0x1004b5c8c
1004b5c2c:	ldrb	w27, [x20, x26]
1004b5c30:	adrp	x8, 7793 ; 0x102326000
1004b5c34:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004b5c38:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b5c3c:	mov	x23, x0
1004b5c40:	mov	x0, x22
1004b5c44:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b5c48:	mov	x22, x0
1004b5c4c:	mov	x0, x23
1004b5c50:	cmp	w27, #0x1
1004b5c54:	b.ne	0x1004b5c60
1004b5c58:	bl	0x101ad12e0 ; selector secondaryLabelColor
1004b5c5c:	b	0x1004b5c64
1004b5c60:	bl	0x101acf220 ; selector labelColor
1004b5c64:	mov	x29, x29
1004b5c68:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b5c6c:	mov	x23, x0
1004b5c70:	mov	x0, x22
1004b5c74:	mov	x2, x23
1004b5c78:	bl	0x101ad2300 ; selector setContentTintColor:
1004b5c7c:	mov	x0, x22
1004b5c80:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5c84:	mov	x0, x23
1004b5c88:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5c8c:	adrp	x8, 7912 ; 0x10239d000
1004b5c90:	ldr	x27, [x8, #0x2a0]
1004b5c94:	ldr	x0, [x21, x27]
1004b5c98:	cbz	x0, 0x1004b5d1c
1004b5c9c:	ldrb	w8, [x20, x26]
1004b5ca0:	cmp	w8, #0x0
1004b5ca4:	csel	x8, x25, x24, ne
1004b5ca8:	ldr	d8, [x8]
1004b5cac:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b5cb0:	mov	x22, x0
1004b5cb4:	fmov	d0, #11.00000000
1004b5cb8:	mov.16b	v1, v8
1004b5cbc:	bl	0x100004700
1004b5cc0:	mov	x23, x0
1004b5cc4:	mov	x0, x22
1004b5cc8:	mov	x2, x23
1004b5ccc:	bl	0x101ad2aa0 ; selector setFont:
1004b5cd0:	mov	x0, x22
1004b5cd4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5cd8:	mov	x0, x23
1004b5cdc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5ce0:	ldr	x22, [x21, x27]
1004b5ce4:	cbz	x22, 0x1004b5d1c
1004b5ce8:	ldrb	w23, [x20, x26]
1004b5cec:	adrp	x8, 7793 ; 0x102326000
1004b5cf0:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004b5cf4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b5cf8:	mov	x21, x0
1004b5cfc:	mov	x0, x22
1004b5d00:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b5d04:	mov	x20, x0
1004b5d08:	mov	x0, x21
1004b5d0c:	cmp	w23, #0x1
1004b5d10:	b.ne	0x1004b5d28
1004b5d14:	bl	0x101acf220 ; selector labelColor
1004b5d18:	b	0x1004b5d2c
1004b5d1c:	mov	x0, x19
1004b5d20:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b5d24:	b	0x1004b5d5c
1004b5d28:	bl	0x101ad12e0 ; selector secondaryLabelColor
1004b5d2c:	mov	x29, x29
1004b5d30:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b5d34:	mov	x21, x0
1004b5d38:	mov	x0, x20
1004b5d3c:	mov	x2, x21
1004b5d40:	bl	0x101ad2300 ; selector setContentTintColor:
1004b5d44:	mov	x0, x19
1004b5d48:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b5d4c:	mov	x0, x20
1004b5d50:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5d54:	mov	x0, x21
1004b5d58:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5d5c:	ldp	x29, x30, [sp, #0x90]
1004b5d60:	ldp	x20, x19, [sp, #0x80]
1004b5d64:	ldp	x22, x21, [sp, #0x70]
1004b5d68:	ldp	x24, x23, [sp, #0x60]
1004b5d6c:	ldp	x26, x25, [sp, #0x50]
1004b5d70:	ldp	x28, x27, [sp, #0x40]
1004b5d74:	ldp	d9, d8, [sp, #0x30]
1004b5d78:	add	sp, sp, #0xa0
1004b5d7c:	ret
1004b5d80:	brk	#0x1
1004b5d84:	stp	x28, x27, [sp, #-0x60]!
1004b5d88:	stp	x26, x25, [sp, #0x10]
1004b5d8c:	stp	x24, x23, [sp, #0x20]
1004b5d90:	stp	x22, x21, [sp, #0x30]
1004b5d94:	stp	x20, x19, [sp, #0x40]
1004b5d98:	stp	x29, x30, [sp, #0x50]
1004b5d9c:	add	x29, sp, #0x50
1004b5da0:	sub	sp, sp, #0x10
1004b5da4:	mov	x19, x20
1004b5da8:	mov	x24, x0
1004b5dac:	mov	x0, #0x0
1004b5db0:	bl	0x101ac49fc ; symbol stub for: _$s10Foundation12CharacterSetVMa
1004b5db4:	mov	x22, x0
1004b5db8:	ldur	x28, [x0, #-0x8]
1004b5dbc:	ldr	x8, [x28, #0x40]
1004b5dc0:	mov	x9, x8
1004b5dc4:	adrp	x16, 7702 ; 0x1022cb000
1004b5dc8:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004b5dcc:	blr	x16
1004b5dd0:	mov	x9, sp
1004b5dd4:	add	x8, x8, #0xf
1004b5dd8:	and	x8, x8, #0xfffffffffffffff0
1004b5ddc:	sub	x23, x9, x8
1004b5de0:	mov	sp, x23
1004b5de4:	adrp	x8, 7912 ; 0x10239d000
1004b5de8:	ldr	x27, [x8, #0x248]
1004b5dec:	add	x0, x20, x27
1004b5df0:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b5df4:	cbz	x0, 0x1004b6088
1004b5df8:	mov	x20, x0
1004b5dfc:	ldr	x8, [x0]
1004b5e00:	ldr	x8, [x8, #0x260]
1004b5e04:	blr	x8
1004b5e08:	mov	x21, x0
1004b5e0c:	mov	x0, x20
1004b5e10:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b5e14:	cbz	x21, 0x1004b6088
1004b5e18:	adrp	x8, 7912 ; 0x10239d000
1004b5e1c:	ldr	x8, [x8, #0x2d0]
1004b5e20:	ldrb	w8, [x19, x8]
1004b5e24:	cmp	w8, #0x1
1004b5e28:	b.ne	0x1004b5e80
1004b5e2c:	ldr	x8, [x21]
1004b5e30:	ldr	x8, [x8, #0x5f0]
1004b5e34:	mov	w0, #0x2
1004b5e38:	mov	x20, x21
1004b5e3c:	blr	x8
1004b5e40:	mov	x0, x24
1004b5e44:	bl	0x101ad5440 ; selector stringValue
1004b5e48:	mov	x29, x29
1004b5e4c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b5e50:	mov	x20, x0
1004b5e54:	bl	0x101ac625c ; symbol stub for: _$sSS10FoundationE36_unconditionallyBridgeFromObjectiveCySSSo8NSStringCSgFZ
1004b5e58:	mov	x22, x0
1004b5e5c:	mov	x23, x1
1004b5e60:	mov	x0, x20
1004b5e64:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5e68:	ldr	x8, [x21]
1004b5e6c:	ldr	x8, [x8, #0x620]
1004b5e70:	mov	x0, x22
1004b5e74:	mov	x1, x23
1004b5e78:	mov	x20, x21
1004b5e7c:	b	0x1004b5f78
1004b5e80:	mov	x0, x24
1004b5e84:	bl	0x101ad5440 ; selector stringValue
1004b5e88:	mov	x29, x29
1004b5e8c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b5e90:	mov	x20, x0
1004b5e94:	bl	0x101ac625c ; symbol stub for: _$sSS10FoundationE36_unconditionallyBridgeFromObjectiveCySSSo8NSStringCSgFZ
1004b5e98:	mov	x24, x0
1004b5e9c:	mov	x26, x1
1004b5ea0:	mov	x0, x20
1004b5ea4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b5ea8:	stp	x24, x26, [x29, #-0x60]
1004b5eac:	mov	x8, x23
1004b5eb0:	bl	0x101ac496c ; symbol stub for: _$s10Foundation12CharacterSetV11whitespacesACvgZ
1004b5eb4:	bl	0x10002a718
1004b5eb8:	mov	x2, x0
1004b5ebc:	adrp	x1, 7705 ; 0x1022ce000
1004b5ec0:	ldr	x1, [x1, #0x38] ; literal pool symbol address: _$sSSN
1004b5ec4:	sub	x20, x29, #0x60
1004b5ec8:	mov	x0, x23
1004b5ecc:	bl	0x101ac7288 ; symbol stub for: _$sSy10FoundationE18trimmingCharacters2inSSAA12CharacterSetV_tF
1004b5ed0:	mov	x25, x0
1004b5ed4:	mov	x24, x1
1004b5ed8:	ldr	x8, [x28, #0x8]
1004b5edc:	mov	x0, x23
1004b5ee0:	mov	x1, x22
1004b5ee4:	blr	x8
1004b5ee8:	mov	x0, x26
1004b5eec:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b5ef0:	and	x8, x25, #0xffffffffffff
1004b5ef4:	ubfx	x9, x24, #56, #4
1004b5ef8:	tst	x24, #0x2000000000000000
1004b5efc:	csel	x8, x8, x9, eq
1004b5f00:	cbz	x8, 0x1004b5f38
1004b5f04:	ldr	x8, [x21]
1004b5f08:	ldr	x8, [x8, #0x5f0]
1004b5f0c:	mov	w0, #0x1
1004b5f10:	mov	x20, x21
1004b5f14:	blr	x8
1004b5f18:	ldr	x8, [x21]
1004b5f1c:	ldr	x8, [x8, #0x608]
1004b5f20:	mov	x0, x25
1004b5f24:	mov	x1, x24
1004b5f28:	blr	x8
1004b5f2c:	ldr	x8, [x21]
1004b5f30:	ldr	x8, [x8, #0x620]
1004b5f34:	b	0x1004b5f70
1004b5f38:	mov	x0, x24
1004b5f3c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b5f40:	ldr	x8, [x21]
1004b5f44:	ldr	x8, [x8, #0x5f0]
1004b5f48:	mov	w0, #0x0
1004b5f4c:	mov	x20, x21
1004b5f50:	blr	x8
1004b5f54:	ldr	x8, [x21]
1004b5f58:	ldr	x8, [x8, #0x620]
1004b5f5c:	mov	x0, #0x0
1004b5f60:	mov	x1, #-0x2000000000000000
1004b5f64:	blr	x8
1004b5f68:	ldr	x8, [x21]
1004b5f6c:	ldr	x8, [x8, #0x608]
1004b5f70:	mov	x0, #0x0
1004b5f74:	mov	x1, #-0x2000000000000000
1004b5f78:	blr	x8
1004b5f7c:	adrp	x8, 7912 ; 0x10239d000
1004b5f80:	ldr	x8, [x8, #0x250]
1004b5f84:	add	x0, x19, x8
1004b5f88:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004b5f8c:	cbz	x0, 0x1004b6018
1004b5f90:	mov	x22, x0
1004b5f94:	ldr	x8, [x21]
1004b5f98:	ldr	x24, [x8, #0x670]
1004b5f9c:	mov	x20, x21
1004b5fa0:	blr	x24
1004b5fa4:	mov	x20, x0
1004b5fa8:	mov	x23, x1
1004b5fac:	mov	x0, x1
1004b5fb0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b5fb4:	and	x8, x20, #0xffffffffffff
1004b5fb8:	ubfx	x9, x23, #56, #4
1004b5fbc:	tst	x23, #0x2000000000000000
1004b5fc0:	csel	x8, x8, x9, eq
1004b5fc4:	cbz	x8, 0x1004b5fd8
1004b5fc8:	mov	x20, x21
1004b5fcc:	blr	x24
1004b5fd0:	mov	x23, x1
1004b5fd4:	b	0x1004b5fe4
1004b5fd8:	mov	x23, #-0x1c00000000000000
1004b5fdc:	mov	w0, #0x744f
1004b5fe0:	movk	w0, #0x7974, lsl #16
1004b5fe4:	ldr	x8, [x22]
1004b5fe8:	adrp	x9, 7706 ; 0x1022cf000
1004b5fec:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b5ff0:	ldr	x9, [x9]
1004b5ff4:	and	x8, x9, x8
1004b5ff8:	ldr	x8, [x8, #0x938]
1004b5ffc:	mov	x1, x23
1004b6000:	mov	x20, x22
1004b6004:	blr	x8
1004b6008:	mov	x0, x22
1004b600c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6010:	mov	x0, x23
1004b6014:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b6018:	adrp	x8, 7792 ; 0x102326000
1004b601c:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004b6020:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b6024:	bl	0x101acce80 ; selector defaultCenter
1004b6028:	mov	x29, x29
1004b602c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b6030:	mov	x20, x0
1004b6034:	bl	0x10006e844
1004b6038:	ldr	x2, [x0]
1004b603c:	mov	x0, x20
1004b6040:	mov	x3, #0x0
1004b6044:	bl	0x101ad0340 ; selector postNotificationName:object:
1004b6048:	mov	x0, x20
1004b604c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6050:	add	x0, x19, x27
1004b6054:	bl	0x101acab64 ; symbol stub for: _swift_weakLoadStrong
1004b6058:	cbz	x0, 0x1004b6080
1004b605c:	mov	x20, x0
1004b6060:	bl	_$s9TextStory09BufferingA7StorageC16bufferingEnabledSbvpfi
1004b6064:	ldr	x8, [x20]
1004b6068:	ldr	x8, [x8, #0x280]
1004b606c:	and	w1, w0, #0x1
1004b6070:	mov	x0, x21
1004b6074:	blr	x8
1004b6078:	mov	x0, x20
1004b607c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b6080:	mov	x0, x21
1004b6084:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b6088:	sub	sp, x29, #0x50
1004b608c:	ldp	x29, x30, [sp, #0x50]
1004b6090:	ldp	x20, x19, [sp, #0x40]
1004b6094:	ldp	x22, x21, [sp, #0x30]
1004b6098:	ldp	x24, x23, [sp, #0x20]
1004b609c:	ldp	x26, x25, [sp, #0x10]
1004b60a0:	ldp	x28, x27, [sp], #0x60
1004b60a4:	ret
1004b60a8:	stp	x22, x21, [sp, #-0x30]!
1004b60ac:	stp	x20, x19, [sp, #0x10]
1004b60b0:	stp	x29, x30, [sp, #0x20]
1004b60b4:	add	x29, sp, #0x20
1004b60b8:	mov	x19, x0
1004b60bc:	mov	x0, x2
1004b60c0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b60c4:	mov	x21, x0
1004b60c8:	mov	x0, x19
1004b60cc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b60d0:	mov	x20, x0
1004b60d4:	mov	x0, x21
1004b60d8:	bl	0x1004b5d84
1004b60dc:	mov	x0, x21
1004b60e0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b60e4:	mov	x0, x20
1004b60e8:	ldp	x29, x30, [sp, #0x20]
1004b60ec:	ldp	x20, x19, [sp, #0x10]
1004b60f0:	ldp	x22, x21, [sp], #0x30
1004b60f4:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004b60f8:	sub	sp, sp, #0xa0
1004b60fc:	stp	d11, d10, [sp, #0x20]
1004b6100:	stp	d9, d8, [sp, #0x30]
1004b6104:	stp	x28, x27, [sp, #0x40]
1004b6108:	stp	x26, x25, [sp, #0x50]
1004b610c:	stp	x24, x23, [sp, #0x60]
1004b6110:	stp	x22, x21, [sp, #0x70]
1004b6114:	stp	x20, x19, [sp, #0x80]
1004b6118:	stp	x29, x30, [sp, #0x90]
1004b611c:	add	x29, sp, #0x90
1004b6120:	mov	x19, x20
1004b6124:	mov	x22, x2
1004b6128:	mov	x28, x1
1004b612c:	mov	x21, x0
1004b6130:	mov	x8, #0x10
1004b6134:	movk	x8, #0xd000, lsl #48
1004b6138:	adrp	x9, 6435 ; 0x101dd9000
1004b613c:	add	x9, x9, #0x3a0 ; literal pool for: "WORKING DIRECTORY"
1004b6140:	sub	x9, x9, #0x20
1004b6144:	orr	x1, x8, #0x1
1004b6148:	orr	x2, x9, #0x8000000000000000
1004b614c:	bl	0x1004bfed0
1004b6150:	mov.16b	v8, v0
1004b6154:	adrp	x8, 7792 ; 0x102326000
1004b6158:	ldr	x0, [x8, #0xa40] ; Objc class ref: _OBJC_CLASS_$_NSView
1004b615c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004b6160:	mov	x8, #0x406f000000000000
1004b6164:	fmov	d2, x8
1004b6168:	fmov	d10, #28.00000000
1004b616c:	fmov	d0, #16.00000000
1004b6170:	fmov	d3, #28.00000000
1004b6174:	mov.16b	v1, v8
1004b6178:	bl	0x101ace5a0 ; selector initWithFrame:
1004b617c:	mov	x24, x0
1004b6180:	adrp	x8, 7700 ; 0x1022ca000
1004b6184:	ldr	x8, [x8, #0x618] ; literal pool symbol address: _NSFontWeightRegular
1004b6188:	ldr	d9, [x8]
1004b618c:	adrp	x8, 7792 ; 0x102326000
1004b6190:	ldr	x0, [x8, #0xb20] ; Objc class ref: _OBJC_CLASS_$_NSImageSymbolConfiguration
1004b6194:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b6198:	fmov	d0, #12.00000000
1004b619c:	mov.16b	v1, v9
1004b61a0:	bl	0x101acc5c0 ; selector configurationWithPointSize:weight:
1004b61a4:	mov	x29, x29
1004b61a8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b61ac:	mov	x25, x0
1004b61b0:	mov	x0, #0x6f66
1004b61b4:	movk	x0, #0x646c, lsl #16
1004b61b8:	movk	x0, #0x7265, lsl #32
1004b61bc:	movk	x0, #0x662e, lsl #48
1004b61c0:	mov	x1, #0x6c69
1004b61c4:	movk	x1, #0x6c, lsl #16
1004b61c8:	movk	x1, #0xeb00, lsl #48
1004b61cc:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b61d0:	mov	x20, x0
1004b61d4:	adrp	x8, 7792 ; 0x102326000
1004b61d8:	ldr	x0, [x8, #0xb28] ; Objc class ref: _OBJC_CLASS_$_NSImage
1004b61dc:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b61e0:	mov	x2, x20
1004b61e4:	mov	x3, #0x0
1004b61e8:	bl	0x101ace220 ; selector imageWithSystemSymbolName:accessibilityDescription:
1004b61ec:	mov	x29, x29
1004b61f0:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b61f4:	mov	x26, x0
1004b61f8:	mov	x0, x20
1004b61fc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6200:	adrp	x23, 7792 ; 0x102326000
1004b6204:	cbz	x26, 0x1004b62ac
1004b6208:	mov	x0, x26
1004b620c:	mov	x2, x25
1004b6210:	bl	0x101ace200 ; selector imageWithSymbolConfiguration:
1004b6214:	mov	x29, x29
1004b6218:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b621c:	mov	x20, x0
1004b6220:	mov	x0, x26
1004b6224:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6228:	cbz	x20, 0x1004b62ac
1004b622c:	adrp	x8, 7792 ; 0x102326000
1004b6230:	ldr	x0, [x8, #0xb50] ; Objc class ref: _OBJC_CLASS_$_NSImageView
1004b6234:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004b6238:	movi.2d	v0, #0000000000000000
1004b623c:	fmov	d1, #7.00000000
1004b6240:	fmov	d2, #14.00000000
1004b6244:	fmov	d3, #14.00000000
1004b6248:	bl	0x101ace5a0 ; selector initWithFrame:
1004b624c:	mov	x26, x0
1004b6250:	mov	x2, x20
1004b6254:	bl	0x101ad2f60 ; selector setImage:
1004b6258:	ldr	x0, [x23, #0x9c8]
1004b625c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b6260:	bl	0x101ad12e0 ; selector secondaryLabelColor
1004b6264:	mov	x29, x29
1004b6268:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b626c:	mov	x27, x0
1004b6270:	mov	x0, x26
1004b6274:	mov	x2, x27
1004b6278:	bl	0x101ad2300 ; selector setContentTintColor:
1004b627c:	mov	x0, x27
1004b6280:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6284:	mov	x0, x26
1004b6288:	mov	x2, #0x0
1004b628c:	bl	0x101ad3000 ; selector setImageScaling:
1004b6290:	mov	x0, x24
1004b6294:	mov	x2, x26
1004b6298:	bl	0x101acb460 ; selector addSubview:
1004b629c:	mov	x0, x26
1004b62a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b62a4:	mov	x0, x20
1004b62a8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b62ac:	mov	x0, x28
1004b62b0:	mov	x1, x22
1004b62b4:	bl	0x10006aee0
1004b62b8:	mov	x26, x1
1004b62bc:	stp	x0, x1, [sp, #0x8]
1004b62c0:	mov	x0, x1
1004b62c4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b62c8:	add	x20, sp, #0x8
1004b62cc:	mov	w0, #0x2f
1004b62d0:	mov	x1, #-0x1f00000000000000
1004b62d4:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004b62d8:	mov	x0, x26
1004b62dc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b62e0:	ldp	x0, x20, [sp, #0x8]
1004b62e4:	mov	x1, x20
1004b62e8:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004b62ec:	mov	x26, x0
1004b62f0:	mov	x0, x20
1004b62f4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004b62f8:	adrp	x8, 7792 ; 0x102326000
1004b62fc:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004b6300:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b6304:	mov	x2, x26
1004b6308:	bl	0x101acf240 ; selector labelWithString:
1004b630c:	mov	x29, x29
1004b6310:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b6314:	mov	x20, x0
1004b6318:	mov	x0, x26
1004b631c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6320:	mov	x0, x20
1004b6324:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b6328:	mov	x20, x0
1004b632c:	bl	0x10002dd04
1004b6330:	mov.16b	v1, v0
1004b6334:	fmov	d0, #12.00000000
1004b6338:	bl	0x100004700
1004b633c:	mov	x26, x0
1004b6340:	mov	x0, x20
1004b6344:	mov	x2, x26
1004b6348:	bl	0x101ad2aa0 ; selector setFont:
1004b634c:	mov	x0, x26
1004b6350:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6354:	ldr	x0, [x23, #0x9c8]
1004b6358:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004b635c:	bl	0x101ad12e0 ; selector secondaryLabelColor
1004b6360:	mov	x29, x29
1004b6364:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004b6368:	mov	x26, x0
1004b636c:	mov	x0, x20
1004b6370:	mov	x2, x26
1004b6374:	bl	0x101ad4660 ; selector setTextColor:
1004b6378:	mov	x0, x26
1004b637c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6380:	mov	x0, x20
1004b6384:	mov	w2, #0x5
1004b6388:	bl	0x101ad3340 ; selector setLineBreakMode:
1004b638c:	mov	x0, x20
1004b6390:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6394:	mov	x0, x20
1004b6398:	mov	w2, #0x0
1004b639c:	bl	0x101ad28e0 ; selector setEditable:
1004b63a0:	mov	x0, x20
1004b63a4:	mov	w2, #0x0
1004b63a8:	bl	0x101ad1fa0 ; selector setBordered:
1004b63ac:	mov	x0, x20
1004b63b0:	mov	w2, #0x0
1004b63b4:	bl	0x101ad2860 ; selector setDrawsBackground:
1004b63b8:	mov	x0, x20
1004b63bc:	bl	0x101ad4fe0 ; selector sizeToFit
1004b63c0:	mov	x0, x20
1004b63c4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b63c8:	mov	x20, x0
1004b63cc:	bl	0x101acdcc0 ; selector frame
1004b63d0:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004b63d4:	fsub	d0, d10, d0
1004b63d8:	fmov	d1, #0.50000000
1004b63dc:	fmul	d9, d0, d1
1004b63e0:	mov	x0, x20
1004b63e4:	bl	0x101acdcc0 ; selector frame
1004b63e8:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004b63ec:	mov.16b	v3, v0
1004b63f0:	mov	x8, #0xc00000000000
1004b63f4:	movk	x8, #0x406c, lsl #48
1004b63f8:	fmov	d2, x8
1004b63fc:	fmov	d0, #18.00000000
1004b6400:	mov	x0, x20
1004b6404:	mov.16b	v1, v9
1004b6408:	bl	0x101ad2b80 ; selector setFrame:
1004b640c:	mov	x0, x20
1004b6410:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6414:	mov	x0, x24
1004b6418:	mov	x2, x20
1004b641c:	bl	0x101acb460 ; selector addSubview:
1004b6420:	mov	x0, x21
1004b6424:	mov	x2, x24
1004b6428:	bl	0x101acb460 ; selector addSubview:
1004b642c:	mov	x0, x25
1004b6430:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6434:	mov	x0, x24
1004b6438:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b643c:	mov	x0, x20
1004b6440:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6444:	fadd	d8, d8, d10
1004b6448:	adrp	x0, 7460 ; 0x1021da000
1004b644c:	add	x0, x0, #0x978
1004b6450:	mov	w1, #0x18
1004b6454:	mov	w2, #0x7
1004b6458:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b645c:	mov	x25, x0
1004b6460:	add	x0, x0, #0x10
1004b6464:	mov	x1, x19
1004b6468:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b646c:	mov	x0, #0x0
1004b6470:	bl	0x1004aede4
1004b6474:	mov	x24, x0
1004b6478:	mov	x0, x25
1004b647c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b6480:	mov	x8, #0x800000000000
1004b6484:	movk	x8, #0x4071, lsl #48
1004b6488:	fmov	d2, x8
1004b648c:	movi.2d	v0, #0000000000000000
1004b6490:	fmov	d3, #28.00000000
1004b6494:	mov.16b	v1, v8
1004b6498:	mov	x20, x24
1004b649c:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b64a0:	mov	x26, x0
1004b64a4:	ldr	x8, [x0]
1004b64a8:	adrp	x9, 7705 ; 0x1022cf000
1004b64ac:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b64b0:	ldr	x9, [x9]
1004b64b4:	and	x8, x9, x8
1004b64b8:	ldr	x8, [x8, #0x140]
1004b64bc:	str	x25, [sp]
1004b64c0:	adrp	x7, 13 ; 0x1004c3000
1004b64c4:	add	x7, x7, #0x9fc
1004b64c8:	mov	x0, #0x6f43
1004b64cc:	movk	x0, #0x7970, lsl #16
1004b64d0:	movk	x0, #0x5020, lsl #32
1004b64d4:	movk	x0, #0x7461, lsl #48
1004b64d8:	mov	x1, #0x68
1004b64dc:	movk	x1, #0xe900, lsl #48
1004b64e0:	mov	x2, #0x0
1004b64e4:	mov	x3, #0x0
1004b64e8:	mov	w4, #0x0
1004b64ec:	mov	x5, #0x0
1004b64f0:	mov	w6, #0x1
1004b64f4:	mov	x20, x26
1004b64f8:	blr	x8
1004b64fc:	mov	x0, x21
1004b6500:	mov	x2, x26
1004b6504:	bl	0x101acb460 ; selector addSubview:
1004b6508:	adrp	x8, 7911 ; 0x10239d000
1004b650c:	mov	x23, x28
1004b6510:	ldr	x28, [x8, #0x270]
1004b6514:	add	x0, x19, x28
1004b6518:	add	x1, sp, #0x8
1004b651c:	mov	w2, #0x21
1004b6520:	mov	x3, #0x0
1004b6524:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b6528:	add	x20, x19, x28
1004b652c:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b6530:	ldr	x8, [x19, x28]
1004b6534:	and	x8, x8, #0xffffffffffffff8
1004b6538:	ldp	x27, x8, [x8, #0x10]
1004b653c:	cmp	x27, x8, lsr #1
1004b6540:	b.hs	0x1004b6814
1004b6544:	mov	x0, x26
1004b6548:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b654c:	mov	x26, x0
1004b6550:	add	x20, x19, x28
1004b6554:	mov	x0, x27
1004b6558:	mov	x1, x26
1004b655c:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b6560:	add	x0, sp, #0x8
1004b6564:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b6568:	mov	x0, x26
1004b656c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b6570:	mov	x0, x25
1004b6574:	mov	w1, #0x2
1004b6578:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004b657c:	fmov	d9, #28.00000000
1004b6580:	fadd	d8, d8, d9
1004b6584:	adrp	x8, 6414 ; 0x101dc4000
1004b6588:	add	x8, x8, #0x430 ; literal pool for: "Reveal in Finder"
1004b658c:	sub	x27, x8, #0x20
1004b6590:	adrp	x0, 7460 ; 0x1021da000
1004b6594:	add	x0, x0, #0x978
1004b6598:	mov	w1, #0x18
1004b659c:	mov	w2, #0x7
1004b65a0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b65a4:	mov	x25, x0
1004b65a8:	add	x0, x0, #0x10
1004b65ac:	mov	x1, x19
1004b65b0:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004b65b4:	adrp	x0, 7461 ; 0x1021db000
1004b65b8:	add	x0, x0, #0x850
1004b65bc:	mov	w1, #0x28
1004b65c0:	mov	w2, #0x7
1004b65c4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b65c8:	mov	x26, x0
1004b65cc:	stp	x23, x22, [x0, #0x10]
1004b65d0:	str	x25, [x0, #0x20]
1004b65d4:	mov	x0, x22
1004b65d8:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b65dc:	mov	x0, x25
1004b65e0:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004b65e4:	mov	x8, #0x800000000000
1004b65e8:	movk	x8, #0x4071, lsl #48
1004b65ec:	fmov	d2, x8
1004b65f0:	movi.2d	v0, #0000000000000000
1004b65f4:	fmov	d3, #28.00000000
1004b65f8:	mov.16b	v1, v8
1004b65fc:	mov	x20, x24
1004b6600:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004b6604:	mov	x24, x0
1004b6608:	ldr	x8, [x0]
1004b660c:	adrp	x9, 7705 ; 0x1022cf000
1004b6610:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b6614:	ldr	x9, [x9]
1004b6618:	and	x8, x9, x8
1004b661c:	ldr	x8, [x8, #0x140]
1004b6620:	str	x26, [sp]
1004b6624:	adrp	x7, 13 ; 0x1004c3000
1004b6628:	add	x7, x7, #0xa78
1004b662c:	orr	x1, x27, #0x8000000000000000
1004b6630:	mov	x0, #0x10
1004b6634:	movk	x0, #0xd000, lsl #48
1004b6638:	mov	x2, #0x0
1004b663c:	mov	x3, #0x0
1004b6640:	mov	w4, #0x0
1004b6644:	mov	x5, #0x0
1004b6648:	mov	w6, #0x1
1004b664c:	mov	x20, x24
1004b6650:	blr	x8
1004b6654:	mov	x0, x21
1004b6658:	mov	x2, x24
1004b665c:	bl	0x101acb460 ; selector addSubview:
1004b6660:	add	x0, x19, x28
1004b6664:	add	x1, sp, #0x8
1004b6668:	mov	w2, #0x21
1004b666c:	mov	x3, #0x0
1004b6670:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004b6674:	add	x20, x19, x28
1004b6678:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004b667c:	ldr	x8, [x19, x28]
1004b6680:	and	x8, x8, #0xffffffffffffff8
1004b6684:	ldp	x27, x8, [x8, #0x10]
1004b6688:	cmp	x27, x8, lsr #1
1004b668c:	b.hs	0x1004b6830
1004b6690:	mov	x0, x24
1004b6694:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004b6698:	mov	x24, x0
1004b669c:	add	x20, x19, x28
1004b66a0:	mov	x0, x27
1004b66a4:	mov	x1, x24
1004b66a8:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004b66ac:	add	x0, sp, #0x8
1004b66b0:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004b66b4:	mov	x0, x25
1004b66b8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b66bc:	mov	x0, x24
1004b66c0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004b66c4:	mov	x0, x26
1004b66c8:	bl	0x101aca960 ; symbol stub for: _swift_release
1004b66cc:	fadd	d8, d8, d9
1004b66d0:	adrp	x0, 7461 ; 0x1021db000
1004b66d4:	add	x0, x0, #0x878
1004b66d8:	mov	w1, #0x20
1004b66dc:	mov	w2, #0x7
1004b66e0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004b66e4:	mov	x24, x0
1004b66e8:	stp	x23, x22, [x0, #0x10]
1004b66ec:	mov	x0, #0x0
1004b66f0:	bl	0x1004ad03c
1004b66f4:	mov	x20, x0
1004b66f8:	mov	x0, x22
1004b66fc:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004b6700:	mov	x8, #0x800000000000
1004b6704:	movk	x8, #0x4071, lsl #48
1004b6708:	fmov	d9, x8
1004b670c:	movi.2d	v0, #0000000000000000
1004b6710:	fmov	d3, #28.00000000
1004b6714:	mov.16b	v1, v8
1004b6718:	mov.16b	v2, v9
1004b671c:	bl	0x100096d60
1004b6720:	mov	x22, x0
1004b6724:	ldr	x8, [x0]
1004b6728:	adrp	x9, 7705 ; 0x1022cf000
1004b672c:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004b6730:	ldr	x9, [x9]
1004b6734:	and	x8, x9, x8
1004b6738:	ldr	x8, [x8, #0x198]
1004b673c:	adrp	x3, 13 ; 0x1004c3000
1004b6740:	add	x3, x3, #0xb10
1004b6744:	mov	x0, #0x704f
1004b6748:	movk	x0, #0x6e65, lsl #16
1004b674c:	movk	x0, #0x6920, lsl #32
1004b6750:	movk	x0, #0x6e, lsl #48
1004b6754:	mov	x1, #-0x1900000000000000
1004b6758:	mov.16b	v0, v9
1004b675c:	mov	x2, x19
1004b6760:	mov	x4, x24
1004b6764:	mov	x5, #0x0
1004b6768:	mov	x6, #0x0
1004b676c:	mov	x20, x22
