
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101433c6c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E>:
101433c6c: d10583ff    	sub	sp, sp, #0x160
101433c70: a9106ffc    	stp	x28, x27, [sp, #0x100]
101433c74: a91167fa    	stp	x26, x25, [sp, #0x110]
101433c78: a9125ff8    	stp	x24, x23, [sp, #0x120]
101433c7c: a91357f6    	stp	x22, x21, [sp, #0x130]
101433c80: a9144ff4    	stp	x20, x19, [sp, #0x140]
101433c84: a9157bfd    	stp	x29, x30, [sp, #0x150]
101433c88: 910543fd    	add	x29, sp, #0x150
101433c8c: aa0403f7    	mov	x23, x4
101433c90: aa0303f8    	mov	x24, x3
101433c94: aa0203f6    	mov	x22, x2
101433c98: aa0103f9    	mov	x25, x1
101433c9c: aa0003f5    	mov	x21, x0
101433ca0: 9100c3e8    	add	x8, sp, #0x30
101433ca4: aa0103e0    	mov	x0, x1
101433ca8: aa0203e1    	mov	x1, x2
101433cac: 94005a43    	bl	0x10144a5b8 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E>
101433cb0: f94023e2    	ldr	x2, [sp, #0x40]
101433cb4: b40018e2    	cbz	x2, 0x101433fd0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x364>
101433cb8: f9401ffc    	ldr	x28, [sp, #0x38]
101433cbc: 910183e8    	add	x8, sp, #0x60
101433cc0: aa1503e0    	mov	x0, x21
101433cc4: aa1c03e1    	mov	x1, x28
101433cc8: 940014cf    	bl	0x101439004 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E>
101433ccc: a94623e9    	ldp	x9, x8, [sp, #0x60]
101433cd0: a90223e9    	stp	x9, x8, [sp, #0x20]
101433cd4: a94753fa    	ldp	x26, x20, [sp, #0x70]
101433cd8: 394342bb    	ldrb	w27, [x21, #0xd0]
101433cdc: aa1503e0    	mov	x0, x21
101433ce0: f84d8c08    	ldr	x8, [x0, #0xd8]!
101433ce4: d2f00013    	mov	x19, #-0x8000000000000000 ; =-9223372036854775808
101433ce8: eb13011f    	cmp	x8, x19
101433cec: 54000220    	b.eq	0x101433d30 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xc4>
101433cf0: a9408b81    	ldp	x1, x2, [x28, #0x8]
101433cf4: 97ffb0ce    	bl	0x10142002c <__ZN17otty_autocomplete2db13CompletionsDb11lookup_spec17h895ef0a520e673c6E>
101433cf8: f90033e0    	str	x0, [sp, #0x60]
101433cfc: b40001a0    	cbz	x0, 0x101433d30 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xc4>
101433d00: 92800008    	mov	x8, #-0x1               ; =-1
101433d04: f8680008    	ldaddl	x8, x8, [x0]
101433d08: f100051f    	cmp	x8, #0x1
101433d0c: 54000081    	b.ne	0x101433d1c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xb0>
101433d10: d50339bf    	dmb	ishld
101433d14: 910183e0    	add	x0, sp, #0x60
101433d18: 9400de86    	bl	0x10146b730 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E>
101433d1c: 5280001c    	mov	w28, #0x0               ; =0
101433d20: f940d2a8    	ldr	x8, [x21, #0x1a0]
101433d24: eb13011f    	cmp	x8, x19
101433d28: 540000c1    	b.ne	0x101433d40 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xd4>
101433d2c: 14000097    	b	0x101433f88 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x31c>
101433d30: 5280003c    	mov	w28, #0x1               ; =1
101433d34: f940d2a8    	ldr	x8, [x21, #0x1a0]
101433d38: eb13011f    	cmp	x8, x19
101433d3c: 54001260    	b.eq	0x101433f88 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x31c>
101433d40: f90003f4    	str	x20, [sp]
101433d44: 910682a0    	add	x0, x21, #0x1a0
101433d48: aa1903e1    	mov	x1, x25
101433d4c: aa1603e2    	mov	x2, x22
101433d50: aa1803e3    	mov	x3, x24
101433d54: aa1703e4    	mov	x4, x23
101433d58: aa1b03e5    	mov	x5, x27
101433d5c: f94017e6    	ldr	x6, [sp, #0x28]
101433d60: aa1a03e7    	mov	x7, x26
101433d64: 940035d2    	bl	0x1014414ac <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E>
101433d68: 36001100    	tbz	w0, #0x0, 0x101433f88 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x31c>
101433d6c: aa0103f6    	mov	x22, x1
101433d70: 3600163c    	tbz	w28, #0x0, 0x101434034 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3c8>
101433d74: f94023e8    	ldr	x8, [sp, #0x40]
101433d78: b4001948    	cbz	x8, 0x1014340a0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x434>
101433d7c: f1000508    	subs	x8, x8, #0x1
101433d80: 540015a0    	b.eq	0x101434034 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3c8>
101433d84: f9401ff3    	ldr	x19, [sp, #0x38]
101433d88: 91006279    	add	x25, x19, #0x18
101433d8c: 52800309    	mov	w9, #0x18               ; =24
101433d90: 9b09651c    	madd	x28, x8, x9, x25
101433d94: 52800028    	mov	w8, #0x1                ; =1
101433d98: d0004562    	adrp	x2, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101433d9c: 9129a842    	add	x2, x2, #0xa6a
101433da0: 91006339    	add	x25, x25, #0x18
101433da4: 14000004    	b	0x101433db4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x148>
101433da8: eb1c033f    	cmp	x25, x28
101433dac: 91006339    	add	x25, x25, #0x18
101433db0: 54001340    	b.eq	0x101434018 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3ac>
101433db4: f85f833a    	ldur	x26, [x25, #-0x8]
101433db8: b4ffff9a    	cbz	x26, 0x101433da8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x13c>
101433dbc: f85f033b    	ldur	x27, [x25, #-0x10]
101433dc0: 39400369    	ldrb	w9, [x27]
101433dc4: 7100b53f    	cmp	w9, #0x2d
101433dc8: 54ffff00    	b.eq	0x101433da8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x13c>
101433dcc: f100135f    	cmp	x26, #0x4
101433dd0: 540001a3    	b.lo	0x101433e04 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x198>
101433dd4: 910183e8    	add	x8, sp, #0x60
101433dd8: aa1b03e0    	mov	x0, x27
101433ddc: aa1a03e1    	mov	x1, x26
101433de0: aa0203f4    	mov	x20, x2
101433de4: 52800063    	mov	w3, #0x3                ; =3
101433de8: 940fc0f1    	bl	0x1018241ac <__ZN4core3str7pattern11StrSearcher3new17hb0ec4e7243414bb1E>
101433dec: 910123e0    	add	x0, sp, #0x48
101433df0: 910183e1    	add	x1, sp, #0x60
101433df4: 9400e211    	bl	0x10146c638 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xf08>
101433df8: b9404be8    	ldr	w8, [sp, #0x48]
101433dfc: 36000188    	tbz	w8, #0x0, 0x101433e2c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1c0>
101433e00: 1400005c    	b	0x101433f70 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x304>
101433e04: aa0203f4    	mov	x20, x2
101433e08: f1000f5f    	cmp	x26, #0x3
101433e0c: 54000101    	b.ne	0x101433e2c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1c0>
101433e10: 79400368    	ldrh	w8, [x27]
101433e14: 39400b69    	ldrb	w9, [x27, #0x2]
101433e18: 5285e74a    	mov	w10, #0x2f3a            ; =12090
101433e1c: 6b0a011f    	cmp	w8, w10
101433e20: 528005e8    	mov	w8, #0x2f               ; =47
101433e24: 7a480120    	ccmp	w9, w8, #0x0, eq
101433e28: 54000a40    	b.eq	0x101433f70 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x304>
101433e2c: 8b1a0368    	add	x8, x27, x26
101433e30: aa1b03e9    	mov	x9, x27
101433e34: 14000004    	b	0x101433e44 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1d8>
101433e38: aa0b03e9    	mov	x9, x11
101433e3c: 7100bd5f    	cmp	w10, #0x2f
101433e40: 54000f20    	b.eq	0x101434024 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3b8>
101433e44: eb08013f    	cmp	x9, x8
101433e48: 540003c0    	b.eq	0x101433ec0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x254>
101433e4c: aa0903eb    	mov	x11, x9
101433e50: 38c0156c    	ldrsb	w12, [x11], #0x1
101433e54: 12001d8a    	and	w10, w12, #0xff
101433e58: 36ffff0c    	tbz	w12, #0x1f, 0x101433e38 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1cc>
101433e5c: 3940052b    	ldrb	w11, [x9, #0x1]
101433e60: 1200156c    	and	w12, w11, #0x3f
101433e64: 7103815f    	cmp	w10, #0xe0
101433e68: 540001e3    	b.lo	0x101433ea4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x238>
101433e6c: 1200114b    	and	w11, w10, #0x1f
101433e70: 3940092d    	ldrb	w13, [x9, #0x2]
101433e74: 120015ad    	and	w13, w13, #0x3f
101433e78: 2a0c19ac    	orr	w12, w13, w12, lsl #6
101433e7c: 7103c15f    	cmp	w10, #0xf0
101433e80: 540001a3    	b.lo	0x101433eb4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x248>
101433e84: 39400d2a    	ldrb	w10, [x9, #0x3]
101433e88: 1200154a    	and	w10, w10, #0x3f
101433e8c: 2a0c194a    	orr	w10, w10, w12, lsl #6
101433e90: 330e096a    	bfi	w10, w11, #18, #3
101433e94: 7144415f    	cmp	w10, #0x110, lsl #12    ; =0x110000
101433e98: 54000140    	b.eq	0x101433ec0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x254>
101433e9c: 91001129    	add	x9, x9, #0x4
101433ea0: 17ffffe7    	b	0x101433e3c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1d0>
101433ea4: 91000929    	add	x9, x9, #0x2
101433ea8: 331a114c    	bfi	w12, w10, #6, #5
101433eac: aa0c03ea    	mov	x10, x12
101433eb0: 17ffffe3    	b	0x101433e3c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1d0>
101433eb4: 91000d29    	add	x9, x9, #0x3
101433eb8: 2a0b318a    	orr	w10, w12, w11, lsl #12
101433ebc: 17ffffe0    	b	0x101433e3c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1d0>
101433ec0: 39400368    	ldrb	w8, [x27]
101433ec4: 7101f91f    	cmp	w8, #0x7e
101433ec8: 54000ae0    	b.eq	0x101434024 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3b8>
101433ecc: b4000537    	cbz	x23, 0x101433f70 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x304>
101433ed0: 910123e8    	add	x8, sp, #0x48
101433ed4: aa1803e0    	mov	x0, x24
101433ed8: aa1703e1    	mov	x1, x23
101433edc: aa1b03e2    	mov	x2, x27
101433ee0: aa1a03e3    	mov	x3, x26
101433ee4: 940e40ee    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101433ee8: a94507fa    	ldp	x26, x1, [sp, #0x50]
101433eec: 910183e8    	add	x8, sp, #0x60
101433ef0: aa1a03e0    	mov	x0, x26
101433ef4: 940e1d02    	bl	0x1017bb2fc <__ZN3std3sys2fs8metadata17h317aa82d489c5e37E>
101433ef8: b94063fb    	ldr	w27, [sp, #0x60]
101433efc: 360002fb    	tbz	w27, #0x0, 0x101433f58 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2ec>
101433f00: f94037e9    	ldr	x9, [sp, #0x68]
101433f04: 92400528    	and	x8, x9, #0x3
101433f08: f100051f    	cmp	x8, #0x1
101433f0c: 54000261    	b.ne	0x101433f58 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2ec>
101433f10: f85ffd28    	ldr	x8, [x9, #-0x1]!
101433f14: f9000fe8    	str	x8, [sp, #0x18]
101433f18: a900a7f3    	stp	x19, x9, [sp, #0x8]
101433f1c: f9400533    	ldr	x19, [x9, #0x8]
101433f20: f9400268    	ldr	x8, [x19]
101433f24: b4000068    	cbz	x8, 0x101433f30 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2c4>
101433f28: f9400fe0    	ldr	x0, [sp, #0x18]
101433f2c: d63f0100    	blr	x8
101433f30: f9400fe0    	ldr	x0, [sp, #0x18]
101433f34: f9400661    	ldr	x1, [x19, #0x8]
101433f38: b4000061    	cbz	x1, 0x101433f44 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2d8>
101433f3c: f9400a62    	ldr	x2, [x19, #0x10]
101433f40: 97d9a9e7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433f44: f9400be0    	ldr	x0, [sp, #0x10]
101433f48: 52800301    	mov	w1, #0x18               ; =24
101433f4c: 52800102    	mov	w2, #0x8                ; =8
101433f50: 97d9a9e3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433f54: f94007f3    	ldr	x19, [sp, #0x8]
101433f58: f94027e1    	ldr	x1, [sp, #0x48]
101433f5c: b4000081    	cbz	x1, 0x101433f6c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x300>
101433f60: aa1a03e0    	mov	x0, x26
101433f64: 52800022    	mov	w2, #0x1                ; =1
101433f68: 97d9a9dd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433f6c: 340005db    	cbz	w27, 0x101434024 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3b8>
101433f70: 52800008    	mov	w8, #0x0                ; =0
101433f74: 52800003    	mov	w3, #0x0                ; =0
101433f78: eb1c033f    	cmp	x25, x28
101433f7c: aa1403e2    	mov	x2, x20
101433f80: 54fff101    	b.ne	0x101433da0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x134>
101433f84: 14000029    	b	0x101434028 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3bc>
101433f88: f94013e1    	ldr	x1, [sp, #0x20]
101433f8c: b4000081    	cbz	x1, 0x101433f9c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x330>
101433f90: f94017e0    	ldr	x0, [sp, #0x28]
101433f94: 52800022    	mov	w2, #0x1                ; =1
101433f98: 97d9a9d1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433f9c: a943d3f3    	ldp	x19, x20, [sp, #0x38]
101433fa0: b40001b4    	cbz	x20, 0x101433fd4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x368>
101433fa4: 91002275    	add	x21, x19, #0x8
101433fa8: 14000004    	b	0x101433fb8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x34c>
101433fac: 910062b5    	add	x21, x21, #0x18
101433fb0: f1000694    	subs	x20, x20, #0x1
101433fb4: 54000100    	b.eq	0x101433fd4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x368>
101433fb8: f85f82a1    	ldur	x1, [x21, #-0x8]
101433fbc: b4ffff81    	cbz	x1, 0x101433fac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x340>
101433fc0: f94002a0    	ldr	x0, [x21]
101433fc4: 52800022    	mov	w2, #0x1                ; =1
101433fc8: 97d9a9c5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433fcc: 17fffff8    	b	0x101433fac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x340>
101433fd0: f9401ff3    	ldr	x19, [sp, #0x38]
101433fd4: f9401be8    	ldr	x8, [sp, #0x30]
101433fd8: b40000c8    	cbz	x8, 0x101433ff0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x384>
101433fdc: 8b080508    	add	x8, x8, x8, lsl #1
101433fe0: d37df101    	lsl	x1, x8, #3
101433fe4: aa1303e0    	mov	x0, x19
101433fe8: 52800102    	mov	w2, #0x8                ; =8
101433fec: 97d9a9bc    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101433ff0: d2800000    	mov	x0, #0x0                ; =0
101433ff4: aa1603e1    	mov	x1, x22
101433ff8: a9557bfd    	ldp	x29, x30, [sp, #0x150]
101433ffc: a9544ff4    	ldp	x20, x19, [sp, #0x140]
101434000: a95357f6    	ldp	x22, x21, [sp, #0x130]
101434004: a9525ff8    	ldp	x24, x23, [sp, #0x120]
101434008: a95167fa    	ldp	x26, x25, [sp, #0x110]
10143400c: a9506ffc    	ldp	x28, x27, [sp, #0x100]
101434010: 910583ff    	add	sp, sp, #0x160
101434014: d65f03c0    	ret
101434018: 370000e8    	tbnz	w8, #0x0, 0x101434034 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3c8>
10143401c: 52800003    	mov	w3, #0x0                ; =0
101434020: 14000002    	b	0x101434028 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3bc>
101434024: 52800023    	mov	w3, #0x1                ; =1
101434028: a9408a61    	ldp	x1, x2, [x19, #0x8]
10143402c: 910682a0    	add	x0, x21, #0x1a0
101434030: 94003003    	bl	0x10144003c <__ZN17otty_autocomplete7history14CommandHistory19note_argument_paths17h24d29343cd6bd71eE>
101434034: f94013e1    	ldr	x1, [sp, #0x20]
101434038: b4000081    	cbz	x1, 0x101434048 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3dc>
10143403c: f94017e0    	ldr	x0, [sp, #0x28]
101434040: 52800022    	mov	w2, #0x1                ; =1
101434044: 97d9a9a6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101434048: a943d3f3    	ldp	x19, x20, [sp, #0x38]
10143404c: b4000194    	cbz	x20, 0x10143407c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x410>
101434050: 91002275    	add	x21, x19, #0x8
101434054: 14000004    	b	0x101434064 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3f8>
101434058: 910062b5    	add	x21, x21, #0x18
10143405c: f1000694    	subs	x20, x20, #0x1
101434060: 540000e0    	b.eq	0x10143407c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x410>
101434064: f85f82a1    	ldur	x1, [x21, #-0x8]
101434068: b4ffff81    	cbz	x1, 0x101434058 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3ec>
10143406c: f94002a0    	ldr	x0, [x21]
101434070: 52800022    	mov	w2, #0x1                ; =1
101434074: 97d9a99a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101434078: 17fffff8    	b	0x101434058 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3ec>
10143407c: f9401be8    	ldr	x8, [sp, #0x30]
