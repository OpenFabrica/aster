
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101432360 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E>:
101432528: d101c3ff    	sub	sp, sp, #0x70
10143252c: a90267fa    	stp	x26, x25, [sp, #0x20]
101432530: a9035ff8    	stp	x24, x23, [sp, #0x30]
101432534: a90457f6    	stp	x22, x21, [sp, #0x40]
101432538: a9054ff4    	stp	x20, x19, [sp, #0x50]
10143253c: a9067bfd    	stp	x29, x30, [sp, #0x60]
101432540: 910183fd    	add	x29, sp, #0x60
101432544: aa0103f3    	mov	x19, x1
101432548: aa0003f4    	mov	x20, x0
10143254c: f9405808    	ldr	x8, [x0, #0xb0]
101432550: d2f00016    	mov	x22, #-0x8000000000000000 ; =-9223372036854775808
101432554: eb16011f    	cmp	x8, x22
101432558: 54000460    	b.eq	0x1014325e4 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x284>
10143255c: f9406288    	ldr	x8, [x20, #0xc0]
101432560: b4000428    	cbz	x8, 0x1014325e4 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x284>
101432564: f9405e97    	ldr	x23, [x20, #0xb8]
101432568: 52801309    	mov	w9, #0x98               ; =152
10143256c: 9b095d18    	madd	x24, x8, x9, x23
101432570: 14000004    	b	0x101432580 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x220>
101432574: 910262f7    	add	x23, x23, #0x98
101432578: eb1802ff    	cmp	x23, x24
10143257c: 54000340    	b.eq	0x1014325e4 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x284>
101432580: a94766f5    	ldp	x21, x25, [x23, #0x70]
101432584: 91000728    	add	x8, x25, #0x1
101432588: d341fd08    	lsr	x8, x8, #1
10143258c: a941266a    	ldp	x10, x9, [x19, #0x10]
101432590: f100013f    	cmp	x9, #0x0
101432594: 9a880321    	csel	x1, x25, x8, eq
101432598: eb0a003f    	cmp	x1, x10
10143259c: 54000188    	b.hi	0x1014325cc <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x26c>
1014325a0: b4fffeb9    	cbz	x25, 0x101432574 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x214>
1014325a4: 910023e8    	add	x8, sp, #0x8
1014325a8: aa1503e0    	mov	x0, x21
1014325ac: 940f7308    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1014325b0: 910023e1    	add	x1, sp, #0x8
1014325b4: aa1303e0    	mov	x0, x19
1014325b8: 94011165    	bl	0x101476b4c <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xee0>
1014325bc: 910062b5    	add	x21, x21, #0x18
1014325c0: f1000739    	subs	x25, x25, #0x1
1014325c4: 54ffff01    	b.ne	0x1014325a4 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x244>
1014325c8: 17ffffeb    	b	0x101432574 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x214>
1014325cc: 91008262    	add	x2, x19, #0x20
1014325d0: aa1303e0    	mov	x0, x19
1014325d4: 52800023    	mov	w3, #0x1                ; =1
1014325d8: 941a06f4    	bl	0x101ab41a8 <__ZN9hashbrown3raw21RawTable$LT$T$C$A$GT$14reserve_rehash17h8ad6e75f269338c4E>
1014325dc: b5fffe59    	cbnz	x25, 0x1014325a4 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x244>
1014325e0: 17ffffe5    	b	0x101432574 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x214>
1014325e4: f9404e88    	ldr	x8, [x20, #0x98]
1014325e8: eb16011f    	cmp	x8, x22
1014325ec: 54000180    	b.eq	0x10143261c <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x2bc>
1014325f0: f9405688    	ldr	x8, [x20, #0xa8]
1014325f4: b4000148    	cbz	x8, 0x10143261c <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x2bc>
1014325f8: f9405280    	ldr	x0, [x20, #0xa0]
1014325fc: d378dd09    	lsl	x9, x8, #8
101432600: cb081534    	sub	x20, x9, x8, lsl #5
101432604: 91038015    	add	x21, x0, #0xe0
101432608: aa1303e1    	mov	x1, x19
10143260c: 97ffffc7    	bl	0x101432528 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x1c8>
101432610: aa1503e0    	mov	x0, x21
101432614: f1038294    	subs	x20, x20, #0xe0
101432618: 54ffff61    	b.ne	0x101432604 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x2a4>
10143261c: a9467bfd    	ldp	x29, x30, [sp, #0x60]
101432620: a9454ff4    	ldp	x20, x19, [sp, #0x50]
101432624: a94457f6    	ldp	x22, x21, [sp, #0x40]
101432628: a9435ff8    	ldp	x24, x23, [sp, #0x30]
10143262c: a94267fa    	ldp	x26, x25, [sp, #0x20]
101432630: 9101c3ff    	add	sp, sp, #0x70
101432634: d65f03c0    	ret
