101411cf4: f90973f3    	str	x19, [sp, #0x12e0]
101411cf8: f90977e3    	str	x3, [sp, #0x12e8]
101411cfc: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
101411d00: 910be108    	add	x8, x8, #0x2f8
101411d04: 94062426    	bl	0x10159ad9c <__ZN11otty_config6Config13user_home_dir17hfc53f12b1c41c57eE>
101411d08: f9497fe8    	ldr	x8, [sp, #0x12f8]
101411d0c: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101411d10: eb09011f    	cmp	x8, x9
101411d14: 540000e1    	b.ne	0x101411d30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x20c8>
101411d18: d2800009    	mov	x9, #0x0                ; =0
101411d1c: d2800008    	mov	x8, #0x0                ; =0
101411d20: 5280010a    	mov	w10, #0x8               ; =8
101411d24: a9102bea    	stp	x10, x10, [sp, #0x100]
101411d28: a9112bff    	stp	xzr, x10, [sp, #0x110]
101411d2c: 14001154    	b	0x10141627c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6614>
101411d30: f94983f3    	ldr	x19, [sp, #0x1300]
101411d34: f94987f4    	ldr	x20, [sp, #0x1308]
101411d38: 912783e8    	add	x8, sp, #0x9e0
101411d3c: 94061ebc    	bl	0x10159982c <__ZN11otty_config6Config10config_dir17h840d21c19fd23261E>
101411d40: f944f7f8    	ldr	x24, [sp, #0x9e8]
101411d44: f944fbe1    	ldr	x1, [sp, #0x9f0]
101411d48: d0004662    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101411d4c: 91202442    	add	x2, x2, #0x809
101411d50: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
101411d54: 910ca108    	add	x8, x8, #0x328
101411d58: aa1803e0    	mov	x0, x24
101411d5c: 52800143    	mov	w3, #0xa                ; =10
101411d60: 940ec94f    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101411d64: f944f3e1    	ldr	x1, [sp, #0x9e0]
101411d68: b4000081    	cbz	x1, 0x101411d78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2110>
101411d6c: aa1803e0    	mov	x0, x24
101411d70: 52800022    	mov	w2, #0x1                ; =1
101411d74: 97da325a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411d78: f9499bf8    	ldr	x24, [sp, #0x1330]
101411d7c: f9499fe3    	ldr	x3, [sp, #0x1338]
101411d80: d10363a8    	sub	x8, x29, #0xd8
101411d84: aa1303e0    	mov	x0, x19
101411d88: aa1403e1    	mov	x1, x20
101411d8c: aa1803e2    	mov	x2, x24
101411d90: 94019aef    	bl	0x10147894c <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE>
101411d94: 912783e8    	add	x8, sp, #0x9e0
101411d98: 9406255a    	bl	0x10159b300 <__ZN11otty_config6Config15app_support_dir17h7e5345c1919e313bE>
101411d9c: f944f7f3    	ldr	x19, [sp, #0x9e8]
101411da0: f944fbe1    	ldr	x1, [sp, #0x9f0]
101411da4: d00037a2    	adrp	x2, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
101411da8: 912a4042    	add	x2, x2, #0xa90
101411dac: d10303a8    	sub	x8, x29, #0xc0
101411db0: aa1303e0    	mov	x0, x19
101411db4: 52800103    	mov	w3, #0x8                ; =8
101411db8: 940ec939    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101411dbc: f944f3e1    	ldr	x1, [sp, #0x9e0]
101411dc0: b4000081    	cbz	x1, 0x101411dd0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2168>
101411dc4: aa1303e0    	mov	x0, x19
101411dc8: 52800022    	mov	w2, #0x1                ; =1
101411dcc: 97da3244    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411dd0: a974cfb9    	ldp	x25, x19, [x29, #-0xb8]
101411dd4: 912783e8    	add	x8, sp, #0x9e0
101411dd8: aa1903e0    	mov	x0, x25
101411ddc: aa1303e1    	mov	x1, x19
101411de0: 940ea547    	bl	0x1017bb2fc <__ZN3std3sys2fs8metadata17h317aa82d489c5e37E>
101411de4: b949e3e8    	ldr	w8, [sp, #0x9e0]
101411de8: 7100051f    	cmp	w8, #0x1
101411dec: 54000501    	b.ne	0x101411e8c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2224>
101411df0: f944f7f3    	ldr	x19, [sp, #0x9e8]
101411df4: 92400668    	and	x8, x19, #0x3
101411df8: f100051f    	cmp	x8, #0x1
101411dfc: 54000201    	b.ne	0x101411e3c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x21d4>
101411e00: f85ffe74    	ldr	x20, [x19, #-0x1]!
101411e04: f9400675    	ldr	x21, [x19, #0x8]
101411e08: f94002a8    	ldr	x8, [x21]
101411e0c: b4000068    	cbz	x8, 0x101411e18 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x21b0>
101411e10: aa1403e0    	mov	x0, x20
101411e14: d63f0100    	blr	x8
101411e18: f94006a1    	ldr	x1, [x21, #0x8]
101411e1c: b4000081    	cbz	x1, 0x101411e2c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x21c4>
101411e20: f9400aa2    	ldr	x2, [x21, #0x10]
101411e24: aa1403e0    	mov	x0, x20
101411e28: 97da322d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411e2c: aa1303e0    	mov	x0, x19
101411e30: 52800301    	mov	w1, #0x18               ; =24
101411e34: 52800102    	mov	w2, #0x8                ; =8
101411e38: 97da3229    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411e3c: f0007b40    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101411e40: 9131a000    	add	x0, x0, #0xc68
101411e44: f9400008    	ldr	x8, [x0]
101411e48: d63f0100    	blr	x8
101411e4c: aa0003fa    	mov	x26, x0
101411e50: 39404008    	ldrb	w8, [x0, #0x10]
101411e54: 7100051f    	cmp	w8, #0x1
101411e58: 54021901    	b.ne	0x101416178 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6510>
101411e5c: a9402354    	ldp	x20, x8, [x26]
101411e60: f90057e8    	str	x8, [sp, #0xa8]
101411e64: 91000688    	add	x8, x20, #0x1
101411e68: f9000348    	str	x8, [x26]
101411e6c: f85403a1    	ldur	x1, [x29, #-0xc0]
101411e70: b4021981    	cbz	x1, 0x1014161a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6538>
101411e74: d280001c    	mov	x28, #0x0               ; =0
101411e78: d2800017    	mov	x23, #0x0               ; =0
101411e7c: d00037a8    	adrp	x8, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
101411e80: 91242108    	add	x8, x8, #0x908
101411e84: f9005be8    	str	x8, [sp, #0xb0]
101411e88: 14000267    	b	0x101412824 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2bbc>
101411e8c: 910403e8    	add	x8, sp, #0x100
101411e90: aa1903e0    	mov	x0, x25
101411e94: aa1303e1    	mov	x1, x19
101411e98: 9401f363    	bl	0x10148ec24 <__ZN10otty_state4open17h1d9a351a8e583abfE>
101411e9c: 394583fb    	ldrb	w27, [sp, #0x160]
101411ea0: 71000f7f    	cmp	w27, #0x3
101411ea4: 54002f01    	b.ne	0x101412484 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x281c>
101411ea8: f0007b40    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101411eac: 9131a000    	add	x0, x0, #0xc68
101411eb0: f9400008    	ldr	x8, [x0]
101411eb4: d63f0100    	blr	x8
101411eb8: aa0003fa    	mov	x26, x0
101411ebc: 39404008    	ldrb	w8, [x0, #0x10]
101411ec0: 7100051f    	cmp	w8, #0x1
101411ec4: 54025201    	b.ne	0x101416904 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c9c>
101411ec8: a9402354    	ldp	x20, x8, [x26]
101411ecc: f90057e8    	str	x8, [sp, #0xa8]
101411ed0: 91000688    	add	x8, x20, #0x1
101411ed4: f9000348    	str	x8, [x26]
101411ed8: 910403e0    	add	x0, sp, #0x100
101411edc: 94010596    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
101411ee0: d280001c    	mov	x28, #0x0               ; =0
101411ee4: d2800017    	mov	x23, #0x0               ; =0
101411ee8: d00037a8    	adrp	x8, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
101411eec: 91242108    	add	x8, x8, #0x908
101411ef0: f9005be8    	str	x8, [sp, #0xb0]
101411ef4: 1400024a    	b	0x10141281c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2bb4>
101411ef8: f9401f29    	ldr	x9, [x25, #0x38]
101411efc: f9401728    	ldr	x8, [x25, #0x28]
101411f00: f100050a    	subs	x10, x8, #0x1
101411f04: 9a8a33ea    	csel	x10, xzr, x10, lo
101411f08: f100013f    	cmp	x9, #0x0
101411f0c: 9a8a0109    	csel	x9, x8, x10, eq
101411f10: 9100044a    	add	x10, x2, #0x1
101411f14: eb09015f    	cmp	x10, x9
101411f18: 54003002    	b.hs	0x101412518 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28b0>
101411f1c: d280000b    	mov	x11, #0x0               ; =0
101411f20: f940132c    	ldr	x12, [x25, #0x20]
101411f24: 5280030d    	mov	w13, #0x18              ; =24
101411f28: 9b0d304c    	madd	x12, x2, x13, x12
101411f2c: 9100a18c    	add	x12, x12, #0x28
101411f30: 14000007    	b	0x101411f4c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x22e4>
101411f34: d280000d    	mov	x13, #0x0               ; =0
101411f38: 9100054a    	add	x10, x10, #0x1
101411f3c: 8b0b01ab    	add	x11, x13, x11
101411f40: 9100618c    	add	x12, x12, #0x18
101411f44: eb0a013f    	cmp	x9, x10
101411f48: 54002d00    	b.eq	0x1014124e8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2880>
101411f4c: eb08015f    	cmp	x10, x8
101411f50: 54ffff22    	b.hs	0x101411f34 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x22cc>
101411f54: f940018d    	ldr	x13, [x12]
101411f58: b40000cd    	cbz	x13, 0x101411f70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2308>
101411f5c: f85f818d    	ldur	x13, [x12, #-0x8]
101411f60: 394001ad    	ldrb	w13, [x13]
101411f64: 7100b5bf    	cmp	w13, #0x2d
101411f68: 1a9f07ed    	cset	w13, ne
101411f6c: 17fffff3    	b	0x101411f38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x22d0>
101411f70: 5280002d    	mov	w13, #0x1               ; =1
101411f74: 17fffff1    	b	0x101411f38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x22d0>
101411f78: f9401f29    	ldr	x9, [x25, #0x38]
101411f7c: f100013f    	cmp	x9, #0x0
101411f80: 1a9f07e9    	cset	w9, ne
101411f84: cb090109    	sub	x9, x8, x9
101411f88: f100093f    	cmp	x9, #0x2
101411f8c: 54002e83    	b.lo	0x10141255c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28f4>
101411f90: d280000a    	mov	x10, #0x0               ; =0
101411f94: 9100a16b    	add	x11, x11, #0x28
101411f98: 5280002c    	mov	w12, #0x1               ; =1
101411f9c: 14000007    	b	0x101411fb8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2350>
101411fa0: d280000d    	mov	x13, #0x0               ; =0
101411fa4: 9100058c    	add	x12, x12, #0x1
101411fa8: 8b0a01aa    	add	x10, x13, x10
101411fac: 9100616b    	add	x11, x11, #0x18
101411fb0: eb0c013f    	cmp	x9, x12
101411fb4: 54002c40    	b.eq	0x10141253c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d4>
101411fb8: eb08019f    	cmp	x12, x8
101411fbc: 54ffff22    	b.hs	0x101411fa0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2338>
101411fc0: f940016d    	ldr	x13, [x11]
101411fc4: b40000ed    	cbz	x13, 0x101411fe0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2378>
101411fc8: f85f816d    	ldur	x13, [x11, #-0x8]
101411fcc: 394001ad    	ldrb	w13, [x13]
101411fd0: 12001dad    	and	w13, w13, #0xff
101411fd4: 7100b5bf    	cmp	w13, #0x2d
101411fd8: 1a9f07ed    	cset	w13, ne
101411fdc: 17fffff2    	b	0x101411fa4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x233c>
101411fe0: 5280002d    	mov	w13, #0x1               ; =1
101411fe4: 17fffff0    	b	0x101411fa4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x233c>
101411fe8: 97da31c2    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101411fec: 52800073    	mov	w19, #0x3               ; =3
101411ff0: 52800060    	mov	w0, #0x3                ; =3
101411ff4: 52800021    	mov	w1, #0x1                ; =1
101411ff8: 97da31b8    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101411ffc: b401d220    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
101412000: aa0003e9    	mov	x9, x0
101412004: 52802008    	mov	w8, #0x100              ; =256
101412008: 79000008    	strh	w8, [x0]
10141200c: 39000813    	strb	w19, [x0, #0x2]
101412010: 52800068    	mov	w8, #0x3                ; =3
101412014: 1400061e    	b	0x10141388c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3c24>
101412018: f100153f    	cmp	x9, #0x5
10141201c: 54005520    	b.eq	0x101412ac0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2e58>
101412020: f100193f    	cmp	x9, #0x6
101412024: 54005960    	b.eq	0x101412b50 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2ee8>
101412028: aa1703f6    	mov	x22, x23
10141202c: aa1303f7    	mov	x23, x19
101412030: f1001d3f    	cmp	x9, #0x7
101412034: 54ff8a01    	b.ne	0x101411174 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x150c>
101412038: b9400109    	ldr	w9, [x8]
10141203c: b840310a    	ldur	w10, [x8, #0x3]
101412040: 528cae4b    	mov	w11, #0x6572            ; =25970
101412044: 72ae8e6b    	movk	w11, #0x7473, lsl #16
101412048: 6b0b013f    	cmp	w9, w11
10141204c: 528c2e89    	mov	w9, #0x6174             ; =24948
101412050: 72ae8e49    	movk	w9, #0x7472, lsl #16
101412054: 7a490140    	ccmp	w10, w9, #0x0, eq
101412058: aa1603f7    	mov	x23, x22
10141205c: 540058a0    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412060: b9400109    	ldr	w9, [x8]
101412064: b8403108    	ldur	w8, [x8, #0x3]
101412068: 528cae4a    	mov	w10, #0x6572            ; =25970
10141206c: 72acae6a    	movk	w10, #0x6573, lsl #16
101412070: 113fbd4a    	add	w10, w10, #0xfef
101412074: 528dceab    	mov	w11, #0x6e75            ; =28277
101412078: 72ac2e0b    	movk	w11, #0x6170, lsl #16
10141207c: 6b0b013f    	cmp	w9, w11
101412080: 7a480140    	ccmp	w10, w8, #0x0, eq
101412084: 54ff8721    	b.ne	0x101411168 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1500>
101412088: 140002ba    	b	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
10141208c: 39400108    	ldrb	w8, [x8]
101412090: 7101e11f    	cmp	w8, #0x78
101412094: 14000005    	b	0x1014120a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2440>
101412098: b9400108    	ldr	w8, [x8]
10141209c: 528f0ca9    	mov	w9, #0x7865             ; =30821
1014120a0: 72ac6ca9    	movk	w9, #0x6365, lsl #16
1014120a4: 6b09011f    	cmp	w8, w9
1014120a8: aa1c03f7    	mov	x23, x28
1014120ac: 540024c1    	b.ne	0x101412544 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28dc>
1014120b0: 14000051    	b	0x1014121f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x258c>
1014120b4: aa0803fb    	mov	x27, x8
1014120b8: eb08001f    	cmp	x0, x8
1014120bc: 5400086a    	b.ge	0x1014121c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2560>
1014120c0: f9401720    	ldr	x0, [x25, #0x28]
1014120c4: f100041f    	cmp	x0, #0x1
1014120c8: 54000349    	b.ls	0x101412130 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x24c8>
1014120cc: f9401328    	ldr	x8, [x25, #0x20]
1014120d0: f9400909    	ldr	x9, [x8, #0x10]
1014120d4: f100113f    	cmp	x9, #0x4
1014120d8: 540002c1    	b.ne	0x101412130 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x24c8>
1014120dc: f9400509    	ldr	x9, [x8, #0x8]
1014120e0: b9400129    	ldr	w9, [x9]
1014120e4: 528e8dea    	mov	w10, #0x746f            ; =29807
1014120e8: 72af2e8a    	movk	w10, #0x7974, lsl #16
1014120ec: 6b0a013f    	cmp	w9, w10
1014120f0: 54000201    	b.ne	0x101412130 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x24c8>
1014120f4: f9401509    	ldr	x9, [x8, #0x28]
1014120f8: f100113f    	cmp	x9, #0x4
1014120fc: 540001a1    	b.ne	0x101412130 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x24c8>
101412100: f9401108    	ldr	x8, [x8, #0x20]
101412104: b9400108    	ldr	w8, [x8]
101412108: 5ac00908    	rev	w8, w8
10141210c: 528dae09    	mov	w9, #0x6d70             ; =28016
101412110: 72ad4ea9    	movk	w9, #0x6a75, lsl #16
101412114: 6b09011f    	cmp	w8, w9
101412118: 1a9f97e8    	cset	w8, hi
10141211c: 5a9f2108    	csinv	w8, w8, wzr, hs
101412120: 7100011f    	cmp	w8, #0x0
101412124: 52800028    	mov	w8, #0x1                ; =1
101412128: 9a881509    	cinc	x9, x8, eq
10141212c: 14000002    	b	0x101412134 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x24cc>
101412130: 52800029    	mov	w9, #0x1                ; =1
101412134: f1000408    	subs	x8, x0, #0x1
101412138: 9a8833e8    	csel	x8, xzr, x8, lo
10141213c: eb08013f    	cmp	x9, x8
101412140: 54002ae2    	b.hs	0x10141269c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2a34>
101412144: aa2903e8    	mvn	x8, x9
101412148: 8b080008    	add	x8, x0, x8
10141214c: d1000508    	sub	x8, x8, #0x1
101412150: cb09000a    	sub	x10, x0, x9
101412154: eb08015f    	cmp	x10, x8
101412158: 54024e89    	b.ls	0x101416b28 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6ec0>
10141215c: 52800008    	mov	w8, #0x0                ; =0
101412160: f940132a    	ldr	x10, [x25, #0x20]
101412164: 5280030b    	mov	w11, #0x18              ; =24
101412168: 9b0b292a    	madd	x10, x9, x11, x10
10141216c: 9100414a    	add	x10, x10, #0x10
101412170: f100041f    	cmp	x0, #0x1
101412174: 9a9f340b    	csinc	x11, x0, xzr, lo
101412178: 8b0b0129    	add	x9, x9, x11
10141217c: cb000129    	sub	x9, x9, x0
101412180: 14000006    	b	0x101412198 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2530>
101412184: 5280002b    	mov	w11, #0x1               ; =1
101412188: 0b080168    	add	w8, w11, w8
10141218c: 9100614a    	add	x10, x10, #0x18
101412190: b1000529    	adds	x9, x9, #0x1
101412194: 54000182    	b.hs	0x1014121c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x255c>
101412198: f940014b    	ldr	x11, [x10]
10141219c: b4ffff4b    	cbz	x11, 0x101412184 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x251c>
1014121a0: f85f814b    	ldur	x11, [x10, #-0x8]
1014121a4: 3940016b    	ldrb	w11, [x11]
1014121a8: 12001d6b    	and	w11, w11, #0xff
1014121ac: 7100b57f    	cmp	w11, #0x2d
1014121b0: 1a9f07eb    	cset	w11, ne
1014121b4: 0b080168    	add	w8, w11, w8
1014121b8: 9100614a    	add	x10, x10, #0x18
1014121bc: b1000529    	adds	x9, x9, #0x1
1014121c0: 54fffec3    	b.lo	0x101412198 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2530>
1014121c4: 340026c8    	cbz	w8, 0x10141269c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2a34>
1014121c8: d2800008    	mov	x8, #0x0                ; =0
1014121cc: d2800013    	mov	x19, #0x0               ; =0
1014121d0: 52800114    	mov	w20, #0x8               ; =8
1014121d4: a90052f3    	stp	x19, x20, [x23]
1014121d8: f9000ae8    	str	x8, [x23, #0x10]
1014121dc: 140011ba    	b	0x1014168c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c5c>
1014121e0: b9400108    	ldr	w8, [x8]
1014121e4: 528f0ca9    	mov	w9, #0x7865             ; =30821
1014121e8: 72ac6ca9    	movk	w9, #0x6365, lsl #16
1014121ec: 6b09011f    	cmp	w8, w9
1014121f0: 54001a81    	b.ne	0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
1014121f4: f9400333    	ldr	x19, [x25]
1014121f8: b4001a53    	cbz	x19, 0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
1014121fc: f9400734    	ldr	x20, [x25, #0x8]
101412200: 940ed0ab    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101412204: eb1a001f    	cmp	x0, x26
101412208: 540000a1    	b.ne	0x10141221c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x25b4>
10141220c: b9407b28    	ldr	w8, [x25, #0x78]
101412210: 6b08003f    	cmp	w1, w8
101412214: 54001962    	b.hs	0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
101412218: 14000003    	b	0x101412224 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x25bc>
10141221c: eb1a001f    	cmp	x0, x26
101412220: 5400190a    	b.ge	0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
101412224: b0004662    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101412228: 911ed842    	add	x2, x2, #0x7b6
10141222c: 912783e8    	add	x8, sp, #0x9e0
101412230: aa1303e0    	mov	x0, x19
101412234: aa1403e1    	mov	x1, x20
101412238: 52800183    	mov	w3, #0xc                ; =12
10141223c: 940ec818    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101412240: f944f7f3    	ldr	x19, [sp, #0x9e8]
101412244: f944fbe1    	ldr	x1, [sp, #0x9f0]
101412248: b0004682    	adrp	x2, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10141224c: 910a6042    	add	x2, x2, #0x298
101412250: d10283a8    	sub	x8, x29, #0xa0
101412254: aa1303e0    	mov	x0, x19
101412258: 52800083    	mov	w3, #0x4                ; =4
10141225c: 940ec810    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101412260: f944f3e1    	ldr	x1, [sp, #0x9e0]
101412264: b4000081    	cbz	x1, 0x101412274 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x260c>
101412268: aa1303e0    	mov	x0, x19
10141226c: 52800022    	mov	w2, #0x1                ; =1
101412270: 97da311b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412274: a97687b5    	ldp	x21, x1, [x29, #-0x98]
101412278: 912783e8    	add	x8, sp, #0x9e0
10141227c: aa1503e0    	mov	x0, x21
101412280: 940ea469    	bl	0x1017bb424 <__ZN3std3sys2fs8read_dir17h3de3d951fc53246fE>
101412284: 3967a3e8    	ldrb	w8, [sp, #0x9e8]
101412288: f944f3f4    	ldr	x20, [sp, #0x9e0]
10141228c: 7100091f    	cmp	w8, #0x2
101412290: 54000341    	b.ne	0x1014122f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2690>
101412294: 92400688    	and	x8, x20, #0x3
101412298: f100051f    	cmp	x8, #0x1
10141229c: 54000201    	b.ne	0x1014122dc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2674>
1014122a0: f85ffe93    	ldr	x19, [x20, #-0x1]!
1014122a4: f9400696    	ldr	x22, [x20, #0x8]
1014122a8: f94002c8    	ldr	x8, [x22]
1014122ac: b4000068    	cbz	x8, 0x1014122b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2650>
1014122b0: aa1303e0    	mov	x0, x19
1014122b4: d63f0100    	blr	x8
1014122b8: f94006c1    	ldr	x1, [x22, #0x8]
1014122bc: b4000081    	cbz	x1, 0x1014122cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2664>
1014122c0: f9400ac2    	ldr	x2, [x22, #0x10]
1014122c4: aa1303e0    	mov	x0, x19
1014122c8: 97da3105    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014122cc: aa1403e0    	mov	x0, x20
1014122d0: 52800301    	mov	w1, #0x18               ; =24
1014122d4: 52800102    	mov	w2, #0x8                ; =8
1014122d8: 97da3101    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014122dc: aa1703fc    	mov	x28, x23
1014122e0: d2800018    	mov	x24, #0x0               ; =0
1014122e4: d280001b    	mov	x27, #0x0               ; =0
1014122e8: f85603a1    	ldur	x1, [x29, #-0xa0]
1014122ec: 52800117    	mov	w23, #0x8               ; =8
1014122f0: b5000c21    	cbnz	x1, 0x101412474 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x280c>
1014122f4: 14000097    	b	0x101412550 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28e8>
1014122f8: f90083ff    	str	xzr, [sp, #0x100]
1014122fc: f90297ff    	str	xzr, [sp, #0x528]
101412300: f904abf4    	str	x20, [sp, #0x950]
101412304: 392563e8    	strb	w8, [sp, #0x958]
101412308: 52801908    	mov	w8, #0xc8               ; =200
10141230c: f904b3e8    	str	x8, [sp, #0x960]
101412310: f904b7f9    	str	x25, [sp, #0x968]
101412314: 9125c3e0    	add	x0, sp, #0x970
101412318: 910403e1    	add	x1, sp, #0x100
10141231c: 97ffafa4    	bl	0x1013fe1ac <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x484>
101412320: f944bbe8    	ldr	x8, [sp, #0x970]
101412324: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101412328: aa1703fc    	mov	x28, x23
10141232c: eb09011f    	cmp	x8, x9
101412330: 540000e1    	b.ne	0x10141234c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x26e4>
101412334: f904f3ff    	str	xzr, [sp, #0x9e0]
101412338: 910403e0    	add	x0, sp, #0x100
10141233c: 94010f16    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
101412340: d2800018    	mov	x24, #0x0               ; =0
101412344: 52800117    	mov	w23, #0x8               ; =8
101412348: 14000048    	b	0x101412468 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2800>
10141234c: 97da30e9    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101412350: 52803400    	mov	w0, #0x1a0              ; =416
101412354: 52800101    	mov	w1, #0x8                ; =8
101412358: 97da30e0    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10141235c: b4023c60    	cbz	x0, 0x101416ae8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6e80>
101412360: aa0003f3    	mov	x19, x0
101412364: 3dc26fe0    	ldr	q0, [sp, #0x9b0]
101412368: 3dc273e1    	ldr	q1, [sp, #0x9c0]
10141236c: ad020400    	stp	q0, q1, [x0, #0x40]
101412370: f944ebe8    	ldr	x8, [sp, #0x9d0]
101412374: f9003008    	str	x8, [x0, #0x60]
101412378: 3dc25fe0    	ldr	q0, [sp, #0x970]
10141237c: 3dc263e1    	ldr	q1, [sp, #0x980]
101412380: ad000400    	stp	q0, q1, [x0]
101412384: 3dc26be0    	ldr	q0, [sp, #0x9a0]
101412388: 3dc267e1    	ldr	q1, [sp, #0x990]
10141238c: ad010001    	stp	q1, q0, [x0, #0x20]
101412390: 52800088    	mov	w8, #0x4                ; =4
101412394: a90c03e8    	stp	x8, x0, [sp, #0xc0]
101412398: 52800034    	mov	w20, #0x1               ; =1
10141239c: f9006bf4    	str	x20, [sp, #0xd0]
1014123a0: 912783e0    	add	x0, sp, #0x9e0
1014123a4: 910403e1    	add	x1, sp, #0x100
1014123a8: 52810e02    	mov	w2, #0x870              ; =2160
1014123ac: 941ade1f    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014123b0: 52800d16    	mov	w22, #0x68              ; =104
1014123b4: d2f00017    	mov	x23, #-0x8000000000000000 ; =-9223372036854775808
1014123b8: 14000012    	b	0x101412400 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2798>
1014123bc: f94067f3    	ldr	x19, [sp, #0xc8]
1014123c0: 8b160268    	add	x8, x19, x22
1014123c4: 3dc497e0    	ldr	q0, [sp, #0x1250]
1014123c8: 3dc49be1    	ldr	q1, [sp, #0x1260]
1014123cc: 3dc49fe2    	ldr	q2, [sp, #0x1270]
1014123d0: ad008901    	stp	q1, q2, [x8, #0x10]
1014123d4: 3d800100    	str	q0, [x8]
1014123d8: 3dc4a3e0    	ldr	q0, [sp, #0x1280]
1014123dc: 3dc4a7e1    	ldr	q1, [sp, #0x1290]
1014123e0: 3dc4abe2    	ldr	q2, [sp, #0x12a0]
1014123e4: f9495be9    	ldr	x9, [sp, #0x12b0]
1014123e8: f9003109    	str	x9, [x8, #0x60]
1014123ec: ad020901    	stp	q1, q2, [x8, #0x40]
1014123f0: 3d800d00    	str	q0, [x8, #0x30]
1014123f4: 91000694    	add	x20, x20, #0x1
1014123f8: f9006bf4    	str	x20, [sp, #0xd0]
1014123fc: 9101a2d6    	add	x22, x22, #0x68
101412400: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101412404: 91094000    	add	x0, x0, #0x250
101412408: 912783e1    	add	x1, sp, #0x9e0
10141240c: 97ffaf68    	bl	0x1013fe1ac <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x484>
101412410: f9492be8    	ldr	x8, [sp, #0x1250]
101412414: eb17011f    	cmp	x8, x23
101412418: 54000160    	b.eq	0x101412444 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x27dc>
10141241c: f94063e8    	ldr	x8, [sp, #0xc0]
101412420: eb08029f    	cmp	x20, x8
101412424: 54fffce1    	b.ne	0x1014123c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2758>
101412428: 910303e0    	add	x0, sp, #0xc0
10141242c: aa1403e1    	mov	x1, x20
101412430: 52800022    	mov	w2, #0x1                ; =1
101412434: 52800103    	mov	w3, #0x8                ; =8
101412438: 52800d04    	mov	w4, #0x68               ; =104
10141243c: 94185905    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101412440: 17ffffdf    	b	0x1014123bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2754>
101412444: 912783e0    	add	x0, sp, #0x9e0
101412448: 94010ed3    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
10141244c: 3dc033e0    	ldr	q0, [sp, #0xc0]
101412450: 3d827be0    	str	q0, [sp, #0x9e0]
101412454: f9406bf8    	ldr	x24, [sp, #0xd0]
101412458: f904fbf8    	str	x24, [sp, #0x9f0]
10141245c: f944f7f7    	ldr	x23, [sp, #0x9e8]
101412460: f1000b1f    	cmp	x24, #0x2
101412464: 5401e7e2    	b.hs	0x101416160 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x64f8>
101412468: f944f3fb    	ldr	x27, [sp, #0x9e0]
10141246c: f85603a1    	ldur	x1, [x29, #-0xa0]
101412470: b4000701    	cbz	x1, 0x101412550 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28e8>
101412474: aa1503e0    	mov	x0, x21
101412478: 52800022    	mov	w2, #0x1                ; =1
10141247c: 97da3098    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412480: 14000034    	b	0x101412550 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28e8>
101412484: ad4a07e0    	ldp	q0, q1, [sp, #0x140]
101412488: 3d828be0    	str	q0, [sp, #0xa20]
10141248c: 3d828fe1    	str	q1, [sp, #0xa30]
101412490: f940b3e8    	ldr	x8, [sp, #0x160]
101412494: f90523e8    	str	x8, [sp, #0xa40]
101412498: ad4807e0    	ldp	q0, q1, [sp, #0x100]
10141249c: 3d827be0    	str	q0, [sp, #0x9e0]
1014124a0: 3d827fe1    	str	q1, [sp, #0x9f0]
1014124a4: ad4903e1    	ldp	q1, q0, [sp, #0x120]
1014124a8: 3d8287e0    	str	q0, [sp, #0xa10]
1014124ac: 3d8283e1    	str	q1, [sp, #0xa00]
1014124b0: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
1014124b4: 91094108    	add	x8, x8, #0x250
1014124b8: 912783e0    	add	x0, sp, #0x9e0
1014124bc: 94020481    	bl	0x1014936c0 <__ZN10otty_state8anywhere3sql19hidden_host_aliases17h5a502cbbca5ac6edE>
1014124c0: 928000c8    	mov	x8, #-0x7               ; =-7
1014124c4: f2efffe8    	movk	x8, #0x7fff, lsl #48
1014124c8: f9492be9    	ldr	x9, [sp, #0x1250]
1014124cc: 91006908    	add	x8, x8, #0x1a
1014124d0: eb08013f    	cmp	x9, x8
1014124d4: 540012a1    	b.ne	0x101412728 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2ac0>
1014124d8: f9492fe8    	ldr	x8, [sp, #0x1258]
1014124dc: f94933e9    	ldr	x9, [sp, #0x1260]
1014124e0: f94937f3    	ldr	x19, [sp, #0x1268]
1014124e4: 14000097    	b	0x101412740 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2ad8>
1014124e8: b400018b    	cbz	x11, 0x101412518 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28b0>
1014124ec: f100057f    	cmp	x11, #0x1
1014124f0: 54ffba81    	b.ne	0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
1014124f4: 97da307f    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014124f8: 52800033    	mov	w19, #0x1               ; =1
1014124fc: 52800020    	mov	w0, #0x1                ; =1
101412500: 52800021    	mov	w1, #0x1                ; =1
101412504: 97da3075    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101412508: b401a9c0    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
10141250c: aa0003e9    	mov	x9, x0
101412510: 3900001f    	strb	wzr, [x0]
101412514: 140004a5    	b	0x1014137a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b40>
101412518: 97da3076    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10141251c: 52800033    	mov	w19, #0x1               ; =1
101412520: 52800020    	mov	w0, #0x1                ; =1
101412524: 52800021    	mov	w1, #0x1                ; =1
101412528: 97da306c    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10141252c: b401a8a0    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
101412530: aa0003e9    	mov	x9, x0
101412534: 52800048    	mov	w8, #0x2                ; =2
101412538: 1400049b    	b	0x1014137a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b3c>
10141253c: b400010a    	cbz	x10, 0x10141255c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28f4>
101412540: aa1703fc    	mov	x28, x23
101412544: d2800018    	mov	x24, #0x0               ; =0
101412548: d280001b    	mov	x27, #0x0               ; =0
10141254c: 52800117    	mov	w23, #0x8               ; =8
101412550: a9005f9b    	stp	x27, x23, [x28]
101412554: f9000b98    	str	x24, [x28, #0x10]
101412558: 140010db    	b	0x1014168c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c5c>
10141255c: aa1703fc    	mov	x28, x23
101412560: f9400333    	ldr	x19, [x25]
101412564: b4ffff13    	cbz	x19, 0x101412544 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28dc>
101412568: f9400734    	ldr	x20, [x25, #0x8]
10141256c: b9407b28    	ldr	w8, [x25, #0x78]
101412570: b900bbe8    	str	w8, [sp, #0xb8]
101412574: 52800156    	mov	w22, #0xa               ; =10
101412578: 52800117    	mov	w23, #0x8               ; =8
10141257c: 14000005    	b	0x101412590 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2928>
101412580: d2800018    	mov	x24, #0x0               ; =0
101412584: d280001b    	mov	x27, #0x0               ; =0
101412588: f10006d6    	subs	x22, x22, #0x1
10141258c: 54fffe20    	b.eq	0x101412550 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28e8>
101412590: 940ecfc7    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101412594: eb1a001f    	cmp	x0, x26
101412598: 540000a1    	b.ne	0x1014125ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2944>
10141259c: b940bbe8    	ldr	w8, [sp, #0xb8]
1014125a0: 6b08003f    	cmp	w1, w8
1014125a4: 54000083    	b.lo	0x1014125b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x294c>
1014125a8: 1400036e    	b	0x101413360 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x36f8>
1014125ac: eb1a001f    	cmp	x0, x26
1014125b0: 54006d8a    	b.ge	0x101413360 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x36f8>
1014125b4: 910403e8    	add	x8, sp, #0x100
1014125b8: aa1303e0    	mov	x0, x19
1014125bc: aa1403e1    	mov	x1, x20
1014125c0: b0004662    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014125c4: 911f1442    	add	x2, x2, #0x7c5
1014125c8: 52800183    	mov	w3, #0xc                ; =12
1014125cc: 940ec734    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
1014125d0: a950e3f5    	ldp	x21, x24, [sp, #0x108]
1014125d4: 912783e8    	add	x8, sp, #0x9e0
1014125d8: aa1503e0    	mov	x0, x21
1014125dc: aa1803e1    	mov	x1, x24
1014125e0: 940ea347    	bl	0x1017bb2fc <__ZN3std3sys2fs8metadata17h317aa82d489c5e37E>
1014125e4: b949e3e8    	ldr	w8, [sp, #0x9e0]
1014125e8: 36006c28    	tbz	w8, #0x0, 0x10141336c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3704>
1014125ec: f944f7f8    	ldr	x24, [sp, #0x9e8]
1014125f0: 92400708    	and	x8, x24, #0x3
1014125f4: f100051f    	cmp	x8, #0x1
1014125f8: 54000281    	b.ne	0x101412648 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x29e0>
1014125fc: f9005bf5    	str	x21, [sp, #0xb0]
101412600: aa1903f5    	mov	x21, x25
101412604: f85fff19    	ldr	x25, [x24, #-0x1]!
101412608: f940071b    	ldr	x27, [x24, #0x8]
10141260c: f9400368    	ldr	x8, [x27]
101412610: b4000068    	cbz	x8, 0x10141261c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x29b4>
101412614: aa1903e0    	mov	x0, x25
101412618: d63f0100    	blr	x8
10141261c: f9400761    	ldr	x1, [x27, #0x8]
101412620: b4000081    	cbz	x1, 0x101412630 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x29c8>
101412624: f9400b62    	ldr	x2, [x27, #0x10]
101412628: aa1903e0    	mov	x0, x25
10141262c: 97da302c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412630: aa1803e0    	mov	x0, x24
101412634: 52800301    	mov	w1, #0x18               ; =24
101412638: 52800102    	mov	w2, #0x8                ; =8
10141263c: 97da3028    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412640: aa1503f9    	mov	x25, x21
101412644: f9405bf5    	ldr	x21, [sp, #0xb0]
101412648: aa1303e0    	mov	x0, x19
10141264c: aa1403e1    	mov	x1, x20
101412650: 940ec7e6    	bl	0x1017c45e8 <__ZN3std4path4Path6parent17h81615573672c555dE>
101412654: aa0003f3    	mov	x19, x0
101412658: b4006a00    	cbz	x0, 0x101413398 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3730>
10141265c: aa0103f4    	mov	x20, x1
101412660: f94083e1    	ldr	x1, [sp, #0x100]
101412664: b4fff8e1    	cbz	x1, 0x101412580 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2918>
101412668: aa1503e0    	mov	x0, x21
10141266c: 52800022    	mov	w2, #0x1                ; =1
101412670: 97da301b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412674: 17ffffc3    	b	0x101412580 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2918>
101412678: 97da301e    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10141267c: 52800033    	mov	w19, #0x1               ; =1
101412680: 52800020    	mov	w0, #0x1                ; =1
101412684: 52800021    	mov	w1, #0x1                ; =1
101412688: 97da3014    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10141268c: b4019da0    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
101412690: aa0003e9    	mov	x9, x0
101412694: 528000a8    	mov	w8, #0x5                ; =5
101412698: 14000443    	b	0x1014137a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b3c>
10141269c: f9401b33    	ldr	x19, [x25, #0x30]
1014126a0: f1003ebf    	cmp	x21, #0xf
1014126a4: 54006828    	b.hi	0x1014133a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3740>
1014126a8: aa1303e8    	mov	x8, x19
1014126ac: aa1503e9    	mov	x9, x21
1014126b0: 3840150a    	ldrb	w10, [x8], #0x1
1014126b4: 7100bd5f    	cmp	w10, #0x2f
1014126b8: 54006840    	b.eq	0x1014133c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3758>
1014126bc: f1000529    	subs	x9, x9, #0x1
1014126c0: 54ffff81    	b.ne	0x1014126b0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2a48>
1014126c4: 1400036d    	b	0x101413478 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3810>
1014126c8: f100093f    	cmp	x9, #0x2
1014126cc: 54008b60    	b.eq	0x101413838 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3bd0>
1014126d0: aa1303f5    	mov	x21, x19
1014126d4: f100153f    	cmp	x9, #0x5
1014126d8: 5400efa1    	b.ne	0x1014144cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4864>
1014126dc: b9400109    	ldr	w9, [x8]
1014126e0: 39401108    	ldrb	w8, [x8, #0x4]
1014126e4: 5285a5aa    	mov	w10, #0x2d2d            ; =11565
1014126e8: 72ad2c4a    	movk	w10, #0x6962, lsl #16
1014126ec: 6b0a013f    	cmp	w9, w10
1014126f0: 52800dc9    	mov	w9, #0x6e               ; =110
1014126f4: 7a490100    	ccmp	w8, w9, #0x0, eq
1014126f8: 5400ee41    	b.ne	0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
1014126fc: b900b3ff    	str	wzr, [sp, #0xb0]
101412700: 1400068d    	b	0x101414134 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44cc>
101412704: 97da2ffb    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101412708: 52800033    	mov	w19, #0x1               ; =1
10141270c: 52800020    	mov	w0, #0x1                ; =1
101412710: 52800021    	mov	w1, #0x1                ; =1
101412714: 97da2ff1    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101412718: b4019940    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
10141271c: aa0003e9    	mov	x9, x0
101412720: 528000e8    	mov	w8, #0x7                ; =7
101412724: 14000420    	b	0x1014137a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b3c>
101412728: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10141272c: 91094000    	add	x0, x0, #0x250
101412730: 94010381    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
101412734: d2800013    	mov	x19, #0x0               ; =0
101412738: d2800008    	mov	x8, #0x0                ; =0
10141273c: 52800109    	mov	w9, #0x8                ; =8
101412740: 5280030a    	mov	w10, #0x18              ; =24
101412744: 9b0a266a    	madd	x10, x19, x10, x9
101412748: a90c27e9    	stp	x9, x9, [sp, #0xc0]
10141274c: a90d2be8    	stp	x8, x10, [sp, #0xd0]
101412750: d0007b40    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101412754: 9131a000    	add	x0, x0, #0xc68
101412758: f9400008    	ldr	x8, [x0]
10141275c: d63f0100    	blr	x8
101412760: aa0003f4    	mov	x20, x0
101412764: 39404008    	ldrb	w8, [x0, #0x10]
101412768: 7100051f    	cmp	w8, #0x1
10141276c: 54020dc1    	b.ne	0x101416924 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6cbc>
101412770: a9400680    	ldp	x0, x1, [x20]
101412774: 91000408    	add	x8, x0, #0x1
101412778: f9000288    	str	x8, [x20]
10141277c: d00072a8    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101412780: 91166108    	add	x8, x8, #0x598
101412784: ad400500    	ldp	q0, q1, [x8]
101412788: 3d8497e0    	str	q0, [sp, #0x1250]
10141278c: 3d849be1    	str	q1, [sp, #0x1260]
101412790: f9093be0    	str	x0, [sp, #0x1270]
101412794: f9093fe1    	str	x1, [sp, #0x1278]
101412798: b5020d13    	cbnz	x19, 0x101416938 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6cd0>
10141279c: ad4603e1    	ldp	q1, q0, [sp, #0xc0]
1014127a0: 3d8263e0    	str	q0, [sp, #0x980]
1014127a4: 3d825fe1    	str	q1, [sp, #0x970]
1014127a8: f944c7f4    	ldr	x20, [sp, #0x988]
1014127ac: f944bff3    	ldr	x19, [sp, #0x978]
1014127b0: eb14027f    	cmp	x19, x20
1014127b4: 54000160    	b.eq	0x1014127e0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2b78>
1014127b8: 3dc00260    	ldr	q0, [x19]
1014127bc: 3c9603a0    	stur	q0, [x29, #-0xa0]
1014127c0: f9400a68    	ldr	x8, [x19, #0x10]
1014127c4: f81703a8    	stur	x8, [x29, #-0x90]
1014127c8: 91006273    	add	x19, x19, #0x18
1014127cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014127d0: 91094000    	add	x0, x0, #0x250
1014127d4: d10283a1    	sub	x1, x29, #0xa0
1014127d8: 940190dd    	bl	0x101476b4c <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xee0>
1014127dc: 17fffff5    	b	0x1014127b0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2b48>
1014127e0: f944c3e8    	ldr	x8, [sp, #0x980]
1014127e4: b40000c8    	cbz	x8, 0x1014127fc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2b94>
1014127e8: f944bbe0    	ldr	x0, [sp, #0x970]
1014127ec: 8b080508    	add	x8, x8, x8, lsl #1
1014127f0: d37df101    	lsl	x1, x8, #3
1014127f4: 52800102    	mov	w2, #0x8                ; =8
1014127f8: 97da2fb9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014127fc: f9492be9    	ldr	x9, [sp, #0x1250]
101412800: f9492ffc    	ldr	x28, [sp, #0x1258]
101412804: f94937f7    	ldr	x23, [sp, #0x1268]
101412808: f9493bf4    	ldr	x20, [sp, #0x1270]
10141280c: f9493fe8    	ldr	x8, [sp, #0x1278]
101412810: a90aa7e8    	stp	x8, x9, [sp, #0xa8]
101412814: 912783e0    	add	x0, sp, #0x9e0
101412818: 94010211    	bl	0x10145305c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5bd4>
10141281c: f85403a1    	ldur	x1, [x29, #-0xc0]
101412820: b4000081    	cbz	x1, 0x101412830 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2bc8>
101412824: aa1903e0    	mov	x0, x25
101412828: 52800022    	mov	w2, #0x1                ; =1
10141282c: 97da2fac    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412830: a972ebb3    	ldp	x19, x26, [x29, #-0xd8]
101412834: f85383b9    	ldur	x25, [x29, #-0xc8]
101412838: b4001137    	cbz	x23, 0x101412a5c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2df4>
10141283c: f90053f4    	str	x20, [sp, #0xa0]
101412840: a9085bf3    	stp	x19, x22, [sp, #0x80]
101412844: aa1a03fb    	mov	x27, x26
101412848: b4000a19    	cbz	x25, 0x101412988 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d20>
10141284c: 52800308    	mov	w8, #0x18               ; =24
101412850: 9b086b28    	madd	x8, x25, x8, x26
101412854: f9004fe8    	str	x8, [sp, #0x98]
101412858: aa1a03f4    	mov	x20, x26
10141285c: aa1a03fb    	mov	x27, x26
101412860: 14000034    	b	0x101412930 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2cc8>
101412864: aa1c03f6    	mov	x22, x28
101412868: 8a1c001c    	and	x28, x0, x28
10141286c: f9405be8    	ldr	x8, [sp, #0xb0]
101412870: fc7c6909    	ldr	d9, [x8, x28]
101412874: 2e288d20    	cmeq.8b	v0, v9, v8
101412878: 9e660008    	fmov	x8, d0
10141287c: f201c11a    	ands	x26, x8, #0x8080808080808080
101412880: 54000280    	b.eq	0x1014128d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2c68>
101412884: dac00348    	rbit	x8, x26
101412888: dac01108    	clz	x8, x8
10141288c: 8b480f88    	add	x8, x28, x8, lsr #3
101412890: 8a160108    	and	x8, x8, x22
101412894: 52800309    	mov	w9, #0x18               ; =24
101412898: 9b09fd08    	mneg	x8, x8, x9
10141289c: f9405be9    	ldr	x9, [sp, #0xb0]
1014128a0: 8b080128    	add	x8, x9, x8
1014128a4: f85f8109    	ldur	x9, [x8, #-0x8]
1014128a8: eb09033f    	cmp	x25, x9
1014128ac: 540000c1    	b.ne	0x1014128c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2c5c>
1014128b0: f85f0101    	ldur	x1, [x8, #-0x10]
1014128b4: aa1803e0    	mov	x0, x24
1014128b8: aa1903e2    	mov	x2, x25
1014128bc: 941adcd8    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
1014128c0: 340001a0    	cbz	w0, 0x1014128f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2c8c>
1014128c4: d1000748    	sub	x8, x26, #0x1
1014128c8: ea1a011a    	ands	x26, x8, x26
1014128cc: 54fffdc1    	b.ne	0x101412884 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2c1c>
1014128d0: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
1014128d4: 2e208d20    	cmeq.8b	v0, v9, v0
1014128d8: 2e30a800    	umaxv.8b	b0, v0
1014128dc: 1e260008    	fmov	w8, s0
1014128e0: 37000168    	tbnz	w8, #0x0, 0x10141290c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2ca4>
1014128e4: 91002273    	add	x19, x19, #0x8
1014128e8: 8b130380    	add	x0, x28, x19
1014128ec: aa1603fc    	mov	x28, x22
1014128f0: 17ffffdd    	b	0x101412864 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2bfc>
1014128f4: f944fbe1    	ldr	x1, [sp, #0x9f0]
1014128f8: b4000121    	cbz	x1, 0x10141291c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2cb4>
1014128fc: aa1803e0    	mov	x0, x24
101412900: 52800022    	mov	w2, #0x1                ; =1
101412904: 97da2f76    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412908: 14000005    	b	0x10141291c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2cb4>
10141290c: 3dc043e0    	ldr	q0, [sp, #0x100]
101412910: f9408be8    	ldr	x8, [sp, #0x110]
101412914: f9000b68    	str	x8, [x27, #0x10]
101412918: 3c818760    	str	q0, [x27], #0x18
10141291c: aa1503fa    	mov	x26, x21
101412920: aa1603fc    	mov	x28, x22
101412924: f9404fe8    	ldr	x8, [sp, #0x98]
101412928: eb08029f    	cmp	x20, x8
10141292c: 540002e0    	b.eq	0x101412988 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d20>
101412930: 3dc00280    	ldr	q0, [x20]
101412934: 3d8043e0    	str	q0, [sp, #0x100]
101412938: f9400a88    	ldr	x8, [x20, #0x10]
10141293c: f9008be8    	str	x8, [sp, #0x110]
101412940: aa1a03f5    	mov	x21, x26
101412944: f904f3fa    	str	x26, [sp, #0x9e0]
101412948: f904f7fb    	str	x27, [sp, #0x9e8]
10141294c: 3dc00280    	ldr	q0, [x20]
101412950: 912783e9    	add	x9, sp, #0x9e0
101412954: 3c810120    	stur	q0, [x9, #0x10]
101412958: f9400a88    	ldr	x8, [x20, #0x10]
10141295c: 91006294    	add	x20, x20, #0x18
101412960: f8020128    	stur	x8, [x9, #0x20]
101412964: 91004122    	add	x2, x9, #0x10
101412968: a94a07e0    	ldp	x0, x1, [sp, #0xa0]
10141296c: 97d4ebc4    	bl	0x10094d87c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a854>
101412970: d2800013    	mov	x19, #0x0               ; =0
101412974: d379fc08    	lsr	x8, x0, #57
101412978: 0e010d08    	dup.8b	v8, w8
10141297c: f94503f9    	ldr	x25, [sp, #0xa00]
101412980: f944fff8    	ldr	x24, [sp, #0x9f8]
101412984: 17ffffb8    	b	0x101412864 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2bfc>
101412988: cb1a0368    	sub	x8, x27, x26
10141298c: d343fd08    	lsr	x8, x8, #3
101412990: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
101412994: f2955569    	movk	x9, #0xaaab
101412998: 9b097d19    	mul	x25, x8, x9
10141299c: b400051c    	cbz	x28, 0x101412a3c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2dd4>
1014129a0: f9405bf3    	ldr	x19, [sp, #0xb0]
1014129a4: aa1303f4    	mov	x20, x19
1014129a8: fc408680    	ldr	d0, [x20], #0x8
1014129ac: 2e208800    	cmge.8b	v0, v0, #0
1014129b0: 9e660008    	fmov	x8, d0
1014129b4: 9201c116    	and	x22, x8, #0x8080808080808080
1014129b8: 52800315    	mov	w21, #0x18              ; =24
1014129bc: 14000005    	b	0x1014129d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d68>
1014129c0: d10006c8    	sub	x8, x22, #0x1
1014129c4: 8a160116    	and	x22, x8, x22
1014129c8: d10006f7    	sub	x23, x23, #0x1
1014129cc: b4000257    	cbz	x23, 0x101412a14 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2dac>
1014129d0: b50000f6    	cbnz	x22, 0x1014129ec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d84>
1014129d4: fc408680    	ldr	d0, [x20], #0x8
1014129d8: 2e208800    	cmge.8b	v0, v0, #0
1014129dc: 9e660008    	fmov	x8, d0
1014129e0: d1030273    	sub	x19, x19, #0xc0
1014129e4: 9201c116    	and	x22, x8, #0x8080808080808080
1014129e8: b4ffff76    	cbz	x22, 0x1014129d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d6c>
1014129ec: dac002c8    	rbit	x8, x22
1014129f0: dac01108    	clz	x8, x8
1014129f4: cb480fe8    	neg	x8, x8, lsr #3
1014129f8: 9b354d08    	smaddl	x8, w8, w21, x19
1014129fc: f85e8101    	ldur	x1, [x8, #-0x18]
101412a00: b4fffe01    	cbz	x1, 0x1014129c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d58>
101412a04: f85f0100    	ldur	x0, [x8, #-0x10]
101412a08: 52800022    	mov	w2, #0x1                ; =1
101412a0c: 97da2f34    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412a10: 17ffffec    	b	0x1014129c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d58>
101412a14: 8b1c0788    	add	x8, x28, x28, lsl #1
101412a18: d37df108    	lsl	x8, x8, #3
101412a1c: 8b1c0109    	add	x9, x8, x28
101412a20: b1008521    	adds	x1, x9, #0x21
101412a24: 540000c0    	b.eq	0x101412a3c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2dd4>
101412a28: f9405be9    	ldr	x9, [sp, #0xb0]
101412a2c: cb080128    	sub	x8, x9, x8
101412a30: d1006100    	sub	x0, x8, #0x18
101412a34: 52800102    	mov	w2, #0x8                ; =8
101412a38: 97da2f29    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412a3c: f94997e1    	ldr	x1, [sp, #0x1328]
101412a40: f94043f3    	ldr	x19, [sp, #0x80]
101412a44: b4000081    	cbz	x1, 0x101412a54 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2dec>
101412a48: f9499be0    	ldr	x0, [sp, #0x1330]
101412a4c: 52800022    	mov	w2, #0x1                ; =1
101412a50: 97da2f23    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412a54: f94047f6    	ldr	x22, [sp, #0x88]
101412a58: 14000dd9    	b	0x1014161bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6554>
101412a5c: b401ba7c    	cbz	x28, 0x1014161a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6540>
101412a60: 8b1c0788    	add	x8, x28, x28, lsl #1
101412a64: d37df108    	lsl	x8, x8, #3
101412a68: 8b1c0109    	add	x9, x8, x28
101412a6c: b1008521    	adds	x1, x9, #0x21
101412a70: 5401b9c0    	b.eq	0x1014161a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6540>
101412a74: f9405be9    	ldr	x9, [sp, #0xb0]
101412a78: cb080128    	sub	x8, x9, x8
101412a7c: d1006100    	sub	x0, x8, #0x18
101412a80: 52800102    	mov	w2, #0x8                ; =8
101412a84: 97da2f16    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412a88: 14000dc8    	b	0x1014161a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6540>
101412a8c: 79400109    	ldrh	w9, [x8]
101412a90: 528e0eaa    	mov	w10, #0x7075            ; =28789
101412a94: 6b0a013f    	cmp	w9, w10
101412a98: 540006c0    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412a9c: 79400109    	ldrh	w9, [x8]
101412aa0: 528dae4a    	mov	w10, #0x6d72            ; =28018
101412aa4: 6b0a013f    	cmp	w9, w10
101412aa8: 54000640    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412aac: 79400108    	ldrh	w8, [x8]
101412ab0: 528e6e09    	mov	w9, #0x7370             ; =29552
101412ab4: 6b09011f    	cmp	w8, w9
101412ab8: 54ff3561    	b.ne	0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
101412abc: 1400002d    	b	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412ac0: b9400109    	ldr	w9, [x8]
101412ac4: 3940110a    	ldrb	w10, [x8, #0x4]
101412ac8: 528e8e6b    	mov	w11, #0x7473            ; =29811
101412acc: 72ae4c2b    	movk	w11, #0x7261, lsl #16
101412ad0: 6b0b013f    	cmp	w9, w11
101412ad4: 52800e89    	mov	w9, #0x74               ; =116
101412ad8: 7a490140    	ccmp	w10, w9, #0x0, eq
101412adc: 540004a0    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412ae0: b9400109    	ldr	w9, [x8]
101412ae4: 3940110a    	ldrb	w10, [x8, #0x4]
101412ae8: 528c2e0b    	mov	w11, #0x6170            ; =24944
101412aec: 72ae6eab    	movk	w11, #0x7375, lsl #16
101412af0: 6b0b013f    	cmp	w9, w11
101412af4: 52800ca9    	mov	w9, #0x65               ; =101
101412af8: 7a490140    	ccmp	w10, w9, #0x0, eq
101412afc: 540003a0    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412b00: b9400109    	ldr	w9, [x8]
101412b04: 39401108    	ldrb	w8, [x8, #0x4]
101412b08: 528eac4a    	mov	w10, #0x7562            ; =30050
101412b0c: 72ad8d2a    	movk	w10, #0x6c69, lsl #16
101412b10: 6b0a013f    	cmp	w9, w10
101412b14: 52800c89    	mov	w9, #0x64               ; =100
101412b18: 14000014    	b	0x101412b68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f00>
101412b1c: 79400109    	ldrh	w9, [x8]
101412b20: 3940090a    	ldrb	w10, [x8, #0x2]
101412b24: 528eae4b    	mov	w11, #0x7572            ; =30066
101412b28: 6b0b013f    	cmp	w9, w11
101412b2c: 52800dc9    	mov	w9, #0x6e               ; =110
101412b30: 7a490140    	ccmp	w10, w9, #0x0, eq
101412b34: 540001e0    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412b38: 79400109    	ldrh	w9, [x8]
101412b3c: 39400908    	ldrb	w8, [x8, #0x2]
101412b40: 528dee8a    	mov	w10, #0x6f74            ; =28532
101412b44: 6b0a013f    	cmp	w9, w10
101412b48: 52800e09    	mov	w9, #0x70               ; =112
101412b4c: 14000007    	b	0x101412b68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f00>
101412b50: b9400109    	ldr	w9, [x8]
101412b54: 79400908    	ldrh	w8, [x8, #0x4]
101412b58: 528e4c6a    	mov	w10, #0x7263            ; =29283
101412b5c: 72ac2caa    	movk	w10, #0x6165, lsl #16
101412b60: 6b0a013f    	cmp	w9, w10
101412b64: 528cae89    	mov	w9, #0x6574             ; =25972
101412b68: 7a490100    	ccmp	w8, w9, #0x0, eq
101412b6c: 54ff2fc1    	b.ne	0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
