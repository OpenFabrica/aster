10066a720:     	sub	sp, sp, #0x40
10066a724:     	stp	x20, x19, [sp, #0x20]
10066a728:     	stp	x29, x30, [sp, #0x30]
10066a72c:     	add	x29, sp, #0x30
10066a730:     	adrp	x8, 0x1023da000
10066a734:     	ldr	x19, [x8, #0x398]
10066a738:     	add	x0, x20, x19
10066a73c:     	add	x1, sp, #0x8
10066a740:     	mov	x2, #0x0                ; =0
10066a744:     	mov	x3, #0x0                ; =0
10066a748:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066a74c:     	ldrb	w0, [x20, x19]
10066a750:     	ldp	x29, x30, [sp, #0x30]
10066a754:     	ldp	x20, x19, [sp, #0x20]
10066a758:     	add	sp, sp, #0x40
10066a75c:     	ret
10066a760:     	sub	sp, sp, #0x50
10066a764:     	stp	x22, x21, [sp, #0x20]
10066a768:     	stp	x20, x19, [sp, #0x30]
10066a76c:     	stp	x29, x30, [sp, #0x40]
10066a770:     	add	x29, sp, #0x40
10066a774:     	mov	x19, x0
10066a778:     	adrp	x8, 0x1023da000
10066a77c:     	ldr	x21, [x8, #0x398]
10066a780:     	add	x0, x20, x21
10066a784:     	add	x1, sp, #0x8
10066a788:     	mov	w2, #0x1                ; =1
10066a78c:     	mov	x3, #0x0                ; =0
10066a790:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066a794:     	strb	w19, [x20, x21]
10066a798:     	ldp	x29, x30, [sp, #0x40]
10066a79c:     	ldp	x20, x19, [sp, #0x30]
10066a7a0:     	ldp	x22, x21, [sp, #0x20]
10066a7a4:     	add	sp, sp, #0x50
10066a7a8:     	ret
10066a7ac:     	stp	x20, x19, [sp, #-0x20]!
10066a7b0:     	stp	x29, x30, [sp, #0x10]
10066a7b4:     	add	x29, sp, #0x10
10066a7b8:     	mov	x1, x0
10066a7bc:     	adrp	x8, 0x1023da000
10066a7c0:     	ldr	x19, [x8, #0x398]
10066a7c4:     	add	x0, x20, x19
10066a7c8:     	mov	w2, #0x21               ; =33
10066a7cc:     	mov	x3, #0x0                ; =0
10066a7d0:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066a7d4:     	adrp	x0, 0x10002d000
10066a7d8:     	add	x0, x0, #0xd0c
10066a7dc:     	add	x1, x20, x19
10066a7e0:     	ldp	x29, x30, [sp, #0x10]
10066a7e4:     	ldp	x20, x19, [sp], #0x20
10066a7e8:     	ret
10066a7ec:     	sub	sp, sp, #0x40
10066a7f0:     	stp	x20, x19, [sp, #0x20]
10066a7f4:     	stp	x29, x30, [sp, #0x30]
10066a7f8:     	add	x29, sp, #0x30
10066a7fc:     	adrp	x8, 0x1023da000
10066a800:     	ldr	x19, [x8, #0x3a0]
10066a804:     	add	x0, x20, x19
10066a808:     	add	x1, sp, #0x8
10066a80c:     	mov	x2, #0x0                ; =0
10066a810:     	mov	x3, #0x0                ; =0
10066a814:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066a818:     	ldrb	w0, [x20, x19]
10066a81c:     	ldp	x29, x30, [sp, #0x30]
10066a820:     	ldp	x20, x19, [sp, #0x20]
10066a824:     	add	sp, sp, #0x40
10066a828:     	ret
10066a82c:     	sub	sp, sp, #0x50
10066a830:     	stp	x22, x21, [sp, #0x20]
10066a834:     	stp	x20, x19, [sp, #0x30]
10066a838:     	stp	x29, x30, [sp, #0x40]
10066a83c:     	add	x29, sp, #0x40
10066a840:     	mov	x19, x0
10066a844:     	adrp	x8, 0x1023da000
10066a848:     	ldr	x21, [x8, #0x3a0]
10066a84c:     	add	x0, x20, x21
10066a850:     	add	x1, sp, #0x8
10066a854:     	mov	w2, #0x1                ; =1
10066a858:     	mov	x3, #0x0                ; =0
10066a85c:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066a860:     	strb	w19, [x20, x21]
10066a864:     	ldp	x29, x30, [sp, #0x40]
10066a868:     	ldp	x20, x19, [sp, #0x30]
10066a86c:     	ldp	x22, x21, [sp, #0x20]
10066a870:     	add	sp, sp, #0x50
10066a874:     	ret
10066a878:     	stp	x20, x19, [sp, #-0x20]!
10066a87c:     	stp	x29, x30, [sp, #0x10]
10066a880:     	add	x29, sp, #0x10
10066a884:     	mov	x1, x0
10066a888:     	adrp	x8, 0x1023da000
10066a88c:     	ldr	x19, [x8, #0x3a0]
10066a890:     	add	x0, x20, x19
10066a894:     	mov	w2, #0x21               ; =33
10066a898:     	mov	x3, #0x0                ; =0
10066a89c:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066a8a0:     	adrp	x0, 0x10002d000
10066a8a4:     	add	x0, x0, #0xd0c
10066a8a8:     	add	x1, x20, x19
10066a8ac:     	ldp	x29, x30, [sp, #0x10]
10066a8b0:     	ldp	x20, x19, [sp], #0x20
10066a8b4:     	ret
10066a8b8:     	sub	sp, sp, #0x40
10066a8bc:     	stp	x20, x19, [sp, #0x20]
