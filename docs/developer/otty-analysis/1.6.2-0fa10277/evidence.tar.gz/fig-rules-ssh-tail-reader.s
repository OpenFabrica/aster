101416600: aa1803fa    	mov	x26, x24
101416604: 5280003b    	mov	w27, #0x1               ; =1
101416608: 52800155    	mov	w21, #0xa               ; =10
10141660c: a94086e0    	ldp	x0, x1, [x23, #0x8]
101416610: a93283a8    	stp	x8, x0, [x29, #-0xd8]
101416614: f81383a1    	stur	x1, [x29, #-0xc8]
101416618: f94993f8    	ldr	x24, [sp, #0x1320]
10141661c: b5fffb58    	cbnz	x24, 0x101416584 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x691c>
101416620: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
101416624: 910b8108    	add	x8, x8, #0x2e0
101416628: f904f3e8    	str	x8, [sp, #0x9e0]
10141662c: b00001c8    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101416630: 91117108    	add	x8, x8, #0x45c
101416634: f904f7e8    	str	x8, [sp, #0x9e8]
101416638: d10363a8    	sub	x8, x29, #0xd8
10141663c: f904fbe8    	str	x8, [sp, #0x9f0]
101416640: b00002a8    	adrp	x8, 0x10146b000 <__ZN4core5slice4sort8unstable8heapsort8heapsort17h14b311923aeea277E+0x3bbc>
101416644: 913b4108    	add	x8, x8, #0xed0
101416648: f904ffe8    	str	x8, [sp, #0x9f8]
10141664c: 910303e8    	add	x8, sp, #0xc0
101416650: 912783e1    	add	x1, sp, #0x9e0
101416654: b0005020    	adrp	x0, 0x101e1b000 <_writev+0x101e1b000>
101416658: 9102d000    	add	x0, x0, #0xb4
10141665c: 940fd3c9    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
101416660: 3dc033e0    	ldr	q0, [sp, #0xc0]
101416664: 3c9403a0    	stur	q0, [x29, #-0xc0]
101416668: f9406be8    	ldr	x8, [sp, #0xd0]
10141666c: f81503a8    	stur	x8, [x29, #-0xb0]
101416670: 912783e8    	add	x8, sp, #0x9e0
101416674: d10303a0    	sub	x0, x29, #0xc0
101416678: 940fe2d5    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10141667c: 9125c3e0    	add	x0, sp, #0x970
101416680: 912783e1    	add	x1, sp, #0x9e0
101416684: 94018132    	bl	0x101476b4c <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xee0>
101416688: 34000120    	cbz	w0, 0x1014166ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6a44>
10141668c: f85403a1    	ldur	x1, [x29, #-0xc0]
101416690: b4000081    	cbz	x1, 0x1014166a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6a38>
101416694: f85483a0    	ldur	x0, [x29, #-0xb8]
101416698: 52800022    	mov	w2, #0x1                ; =1
10141669c: 97da2010    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014166a0: f85283a1    	ldur	x1, [x29, #-0xd8]
1014166a4: b5ffec41    	cbnz	x1, 0x10141642c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x67c4>
1014166a8: 17ffff64    	b	0x101416438 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x67d0>
1014166ac: f9005ffa    	str	x26, [sp, #0xb8]
1014166b0: aa1b03fa    	mov	x26, x27
1014166b4: aa1303fb    	mov	x27, x19
1014166b8: aa1403f3    	mov	x19, x20
1014166bc: a97463b7    	ldp	x23, x24, [x29, #-0xc0]
1014166c0: f85503b4    	ldur	x20, [x29, #-0xb0]
1014166c4: 97da200b    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014166c8: aa1503e0    	mov	x0, x21
1014166cc: 52800021    	mov	w1, #0x1                ; =1
1014166d0: 97da2002    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014166d4: b40016a0    	cbz	x0, 0x1014169a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6d40>
1014166d8: aa0003f9    	mov	x25, x0
1014166dc: aa1603e1    	mov	x1, x22
1014166e0: aa1503e2    	mov	x2, x21
1014166e4: 941acd51    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014166e8: a93663b7    	stp	x23, x24, [x29, #-0xa0]
1014166ec: f81703b4    	stur	x20, [x29, #-0x90]
1014166f0: 910303e8    	add	x8, sp, #0xc0
1014166f4: d10283a0    	sub	x0, x29, #0xa0
1014166f8: 940fe2b5    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1014166fc: f90503f8    	str	x24, [sp, #0xa00]
101416700: f90507f4    	str	x20, [sp, #0xa08]
101416704: 3dc033e0    	ldr	q0, [sp, #0xc0]
101416708: f9406be8    	ldr	x8, [sp, #0xd0]
10141670c: 3d827be0    	str	q0, [sp, #0x9e0]
101416710: f904fff7    	str	x23, [sp, #0x9f8]
101416714: f904fbe8    	str	x8, [sp, #0x9f0]
101416718: f9050bf5    	str	x21, [sp, #0xa10]
10141671c: f9050ff9    	str	x25, [sp, #0xa18]
101416720: f90513f5    	str	x21, [sp, #0xa20]
101416724: d2f00019    	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
101416728: f90517f9    	str	x25, [sp, #0xa28]
10141672c: 52804008    	mov	w8, #0x200              ; =512
101416730: 791483e8    	strh	w8, [sp, #0xa40]
101416734: f9499ff4    	ldr	x20, [sp, #0x1338]
101416738: f94997e8    	ldr	x8, [sp, #0x1328]
10141673c: eb08029f    	cmp	x20, x8
101416740: 54ffe441    	b.ne	0x1014163c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6760>
101416744: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101416748: 910ca000    	add	x0, x0, #0x328
10141674c: 9419e5e6    	bl	0x101a8fee4 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h79ba5ff6649e4cf8E>
101416750: 17ffff1e    	b	0x1014163c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6760>
101416754: f94083e8    	ldr	x8, [sp, #0x100]
101416758: b4000088    	cbz	x8, 0x101416768 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b00>
10141675c: 910403e8    	add	x8, sp, #0x100
101416760: b27d0100    	orr	x0, x8, #0x8
101416764: 97ec534d    	bl	0x100f2b498 <__ZN200_$LT$otty_sync_dotfiles..catalog.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_sync_dotfiles..catalog..CatalogAppSpec$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hace6feb1294ba67fE+0x6bc0>
101416768: b4000375    	cbz	x21, 0x1014167d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b6c>
10141676c: f940abe8    	ldr	x8, [sp, #0x150]
101416770: f940b3e9    	ldr	x9, [sp, #0x160]
101416774: eb080129    	subs	x9, x9, x8
101416778: 54000200    	b.eq	0x1014167b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b50>
10141677c: b201f3ea    	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
101416780: f295556a    	movk	x10, #0xaaab
101416784: 9bca7d29    	umulh	x9, x9, x10
101416788: d344fd33    	lsr	x19, x9, #4
10141678c: 91002114    	add	x20, x8, #0x8
101416790: 14000004    	b	0x1014167a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b38>
101416794: 91006294    	add	x20, x20, #0x18
101416798: f1000673    	subs	x19, x19, #0x1
10141679c: 540000e0    	b.eq	0x1014167b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b50>
1014167a0: f85f8281    	ldur	x1, [x20, #-0x8]
1014167a4: b4ffff81    	cbz	x1, 0x101416794 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b2c>
1014167a8: f9400280    	ldr	x0, [x20]
1014167ac: 52800022    	mov	w2, #0x1                ; =1
1014167b0: 97da1fcb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014167b4: 17fffff8    	b	0x101416794 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b2c>
1014167b8: f940afe8    	ldr	x8, [sp, #0x158]
1014167bc: b40000c8    	cbz	x8, 0x1014167d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b6c>
1014167c0: 8b080508    	add	x8, x8, x8, lsl #1
1014167c4: d37df101    	lsl	x1, x8, #3
1014167c8: aa1503e0    	mov	x0, x21
1014167cc: 52800102    	mov	w2, #0x8                ; =8
1014167d0: 97da1fc3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014167d4: f94997f5    	ldr	x21, [sp, #0x1328]
1014167d8: f9499bf3    	ldr	x19, [sp, #0x1330]
1014167dc: f9499ff4    	ldr	x20, [sp, #0x1338]
1014167e0: f944bff6    	ldr	x22, [sp, #0x978]
1014167e4: b4000556    	cbz	x22, 0x10141688c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c24>
1014167e8: f944c7f7    	ldr	x23, [sp, #0x988]
1014167ec: b40003d7    	cbz	x23, 0x101416864 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6bfc>
1014167f0: f944bbf8    	ldr	x24, [sp, #0x970]
1014167f4: aa1803f9    	mov	x25, x24
1014167f8: fc408720    	ldr	d0, [x25], #0x8
1014167fc: 2e208800    	cmge.8b	v0, v0, #0
101416800: 9e660008    	fmov	x8, d0
101416804: 9201c11b    	and	x27, x8, #0x8080808080808080
101416808: 5280031a    	mov	w26, #0x18              ; =24
10141680c: 14000005    	b	0x101416820 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6bb8>
101416810: d1000768    	sub	x8, x27, #0x1
101416814: 8a1b011b    	and	x27, x8, x27
101416818: d10006f7    	sub	x23, x23, #0x1
10141681c: b4000257    	cbz	x23, 0x101416864 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6bfc>
101416820: b50000fb    	cbnz	x27, 0x10141683c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6bd4>
101416824: fc408720    	ldr	d0, [x25], #0x8
101416828: 2e208800    	cmge.8b	v0, v0, #0
10141682c: 9e660008    	fmov	x8, d0
101416830: d1030318    	sub	x24, x24, #0xc0
101416834: 9201c11b    	and	x27, x8, #0x8080808080808080
101416838: b4ffff7b    	cbz	x27, 0x101416824 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6bbc>
10141683c: dac00368    	rbit	x8, x27
101416840: dac01108    	clz	x8, x8
101416844: cb480fe8    	neg	x8, x8, lsr #3
101416848: 9b3a6108    	smaddl	x8, w8, w26, x24
10141684c: f85e8101    	ldur	x1, [x8, #-0x18]
101416850: b4fffe01    	cbz	x1, 0x101416810 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6ba8>
101416854: f85f0100    	ldur	x0, [x8, #-0x10]
101416858: 52800022    	mov	w2, #0x1                ; =1
10141685c: 97da1fa0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416860: 17ffffec    	b	0x101416810 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6ba8>
101416864: 8b1606c8    	add	x8, x22, x22, lsl #1
101416868: d37df108    	lsl	x8, x8, #3
10141686c: 8b160109    	add	x9, x8, x22
101416870: b1008521    	adds	x1, x9, #0x21
101416874: 540000c0    	b.eq	0x10141688c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c24>
101416878: f944bbe9    	ldr	x9, [sp, #0x970]
10141687c: cb080128    	sub	x8, x9, x8
101416880: d1006100    	sub	x0, x8, #0x18
101416884: 52800102    	mov	w2, #0x8                ; =8
101416888: 97da1f95    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141688c: f9498be1    	ldr	x1, [sp, #0x1310]
101416890: b4000081    	cbz	x1, 0x1014168a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c38>
101416894: f9498fe0    	ldr	x0, [sp, #0x1318]
101416898: 52800022    	mov	w2, #0x1                ; =1
10141689c: 97da1f90    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014168a0: f9497fe1    	ldr	x1, [sp, #0x12f8]
1014168a4: f240f83f    	tst	x1, #0x7fffffffffffffff
1014168a8: f94037f7    	ldr	x23, [sp, #0x68]
1014168ac: 54000080    	b.eq	0x1014168bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c54>
1014168b0: f94983e0    	ldr	x0, [sp, #0x1300]
1014168b4: 52800022    	mov	w2, #0x1                ; =1
1014168b8: 97da1f89    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014168bc: a9004ef5    	stp	x21, x19, [x23]
1014168c0: f9000af4    	str	x20, [x23, #0x10]
1014168c4: 914007ff    	add	sp, sp, #0x1, lsl #12   ; =0x1000
1014168c8: 910f03ff    	add	sp, sp, #0x3c0
1014168cc: a9477bfd    	ldp	x29, x30, [sp, #0x70]
1014168d0: a9464ff4    	ldp	x20, x19, [sp, #0x60]
1014168d4: a94557f6    	ldp	x22, x21, [sp, #0x50]
1014168d8: a9445ff8    	ldp	x24, x23, [sp, #0x40]
1014168dc: a94367fa    	ldp	x26, x25, [sp, #0x30]
1014168e0: a9426ffc    	ldp	x28, x27, [sp, #0x20]
1014168e4: 6d4123e9    	ldp	d9, d8, [sp, #0x10]
1014168e8: 6cc82beb    	ldp	d11, d10, [sp], #0x80
1014168ec: d65f03c0    	ret
1014168f0: 940ea426    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
1014168f4: f9000661    	str	x1, [x19, #0x8]
1014168f8: 52800028    	mov	w8, #0x1                ; =1
1014168fc: 39004268    	strb	w8, [x19, #0x10]
101416900: 17fffe94    	b	0x101416350 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x66e8>
101416904: 940ea421    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101416908: f90057e1    	str	x1, [sp, #0xa8]
10141690c: aa0003f4    	mov	x20, x0
101416910: f94057e8    	ldr	x8, [sp, #0xa8]
101416914: f9000748    	str	x8, [x26, #0x8]
101416918: 52800028    	mov	w8, #0x1                ; =1
10141691c: 39004348    	strb	w8, [x26, #0x10]
101416920: 17ffed6c    	b	0x101411ed0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2268>
101416924: 940ea419    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101416928: f9000681    	str	x1, [x20, #0x8]
10141692c: 52800028    	mov	w8, #0x1                ; =1
101416930: 39004288    	strb	w8, [x20, #0x10]
101416934: 17ffef90    	b	0x101412774 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2b0c>
101416938: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10141693c: 91094108    	add	x8, x8, #0x250
101416940: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101416944: 91094000    	add	x0, x0, #0x250
101416948: 91008102    	add	x2, x8, #0x20
10141694c: aa1303e1    	mov	x1, x19
101416950: 52800023    	mov	w3, #0x1                ; =1
101416954: 941a7615    	bl	0x101ab41a8 <__ZN9hashbrown3raw21RawTable$LT$T$C$A$GT$14reserve_rehash17h8ad6e75f269338c4E>
101416958: 17ffef91    	b	0x10141279c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2b34>
10141695c: 940ea40b    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101416960: f9000681    	str	x1, [x20, #0x8]
101416964: 52800028    	mov	w8, #0x1                ; =1
101416968: 39004288    	strb	w8, [x20, #0x10]
10141696c: 17fff2ce    	b	0x1014134a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x383c>
101416970: d0007282    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101416974: 91216042    	add	x2, x2, #0x858
101416978: f9405fe1    	ldr	x1, [sp, #0xb8]
10141697c: 941ab4f0    	bl	0x101ac3d3c <__ZN4core9panicking18panic_bounds_check17hd6142ed38f8c399dE>
101416980: 52800020    	mov	w0, #0x1                ; =1
101416984: aa1403e1    	mov	x1, x20
101416988: 941ab27b    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10141698c: 140000c3    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416990: f100567f    	cmp	x19, #0x15
101416994: 54001082    	b.hs	0x101416ba4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6f3c>
101416998: aa1403e0    	mov	x0, x20
10141699c: aa1303e1    	mov	x1, x19
1014169a0: 94010a0b    	bl	0x1014591cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbd44>
1014169a4: 17fff820    	b	0x101414a24 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4dbc>
1014169a8: 52800020    	mov	w0, #0x1                ; =1
1014169ac: aa1503e1    	mov	x1, x21
1014169b0: 941ab271    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014169b4: 140000b9    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
1014169b8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014169bc: 91094000    	add	x0, x0, #0x250
1014169c0: d2800001    	mov	x1, #0x0                ; =0
1014169c4: 52800103    	mov	w3, #0x8                ; =8
1014169c8: 52800304    	mov	w4, #0x18               ; =24
1014169cc: 941847a1    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1014169d0: f94933e8    	ldr	x8, [sp, #0x1260]
1014169d4: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1014169d8: eb09029f    	cmp	x20, x9
1014169dc: 54ff0481    	b.ne	0x101414a6c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e04>
1014169e0: 17fff829    	b	0x101414a84 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e1c>
1014169e4: 52800100    	mov	w0, #0x8                ; =8
1014169e8: 52800d01    	mov	w1, #0x68               ; =104
1014169ec: 941ab262    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014169f0: 140000aa    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
1014169f4: f904f7fb    	str	x27, [sp, #0x9e8]
1014169f8: f90503ff    	str	xzr, [sp, #0xa00]
1014169fc: 52800020    	mov	w0, #0x1                ; =1
101416a00: 528000c1    	mov	w1, #0x6                ; =6
101416a04: 941ab25c    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416a08: 140000a4    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416a0c: d0007282    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101416a10: 91210042    	add	x2, x2, #0x840
101416a14: d2800000    	mov	x0, #0x0                ; =0
101416a18: d2800001    	mov	x1, #0x0                ; =0
101416a1c: 941ab4c8    	bl	0x101ac3d3c <__ZN4core9panicking18panic_bounds_check17hd6142ed38f8c399dE>
101416a20: 1400009e    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416a24: 52800100    	mov	w0, #0x8                ; =8
101416a28: 52803401    	mov	w1, #0x1a0              ; =416
101416a2c: 941ab252    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416a30: 1400009a    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416a34: 910403e2    	add	x2, sp, #0x100
101416a38: aa1403e0    	mov	x0, x20
101416a3c: aa1503e1    	mov	x1, x21
101416a40: 94010d62    	bl	0x101459fc8 <__ZN4core5slice4sort6stable14driftsort_main17h86247584ffefca32E>
101416a44: f112c27f    	cmp	x19, #0x4b0
101416a48: f9405ff9    	ldr	x25, [sp, #0xb8]
101416a4c: 54fceba3    	b.lo	0x1014107c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xb58>
101416a50: 9112c297    	add	x23, x20, #0x4b0
101416a54: f100cab3    	subs	x19, x21, #0x32
101416a58: 54000300    	b.eq	0x101416ab8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6e50>
101416a5c: 9112e295    	add	x21, x20, #0x4b8
101416a60: 14000004    	b	0x101416a70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6e08>
101416a64: 910062b5    	add	x21, x21, #0x18
101416a68: f1000673    	subs	x19, x19, #0x1
101416a6c: 54000260    	b.eq	0x101416ab8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6e50>
101416a70: f85f82a1    	ldur	x1, [x21, #-0x8]
101416a74: b4ffff81    	cbz	x1, 0x101416a64 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6dfc>
101416a78: f94002a0    	ldr	x0, [x21]
101416a7c: 52800022    	mov	w2, #0x1                ; =1
101416a80: 97da1f17    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416a84: 17fffff8    	b	0x101416a64 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6dfc>
101416a88: f100571f    	cmp	x24, #0x15
101416a8c: 54000b02    	b.hs	0x101416bec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6f84>
101416a90: aa1703e0    	mov	x0, x23
101416a94: aa1803e1    	mov	x1, x24
101416a98: 940109cd    	bl	0x1014591cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbd44>
101416a9c: 17fffd67    	b	0x101416038 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x63d0>
101416aa0: f100573f    	cmp	x25, #0x15
101416aa4: 54000ae2    	b.hs	0x101416c00 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6f98>
101416aa8: f94047e0    	ldr	x0, [sp, #0x88]
101416aac: aa1903e1    	mov	x1, x25
101416ab0: 97d4e613    	bl	0x1009502fc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3d2d4>
101416ab4: 17fffc21    	b	0x101415b38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5ed0>
101416ab8: 52828a16    	mov	w22, #0x1450            ; =5200
101416abc: 52800655    	mov	w21, #0x32              ; =50
101416ac0: f9405ff9    	ldr	x25, [sp, #0xb8]
101416ac4: 97da1f0b    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101416ac8: aa1603e0    	mov	x0, x22
101416acc: 52800101    	mov	w1, #0x8                ; =8
101416ad0: 97da1f02    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101416ad4: b5fce880    	cbnz	x0, 0x1014107e4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xb7c>
101416ad8: 52800100    	mov	w0, #0x8                ; =8
101416adc: aa1603e1    	mov	x1, x22
101416ae0: 941ab225    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416ae4: 1400006d    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416ae8: 52800100    	mov	w0, #0x8                ; =8
101416aec: 52803401    	mov	w1, #0x1a0              ; =416
101416af0: 941ab221    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416af4: 14000069    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416af8: 914007e2    	add	x2, sp, #0x1, lsl #12   ; =0x1000
101416afc: 91094042    	add	x2, x2, #0x250
101416b00: aa1703e0    	mov	x0, x23
101416b04: aa1803e1    	mov	x1, x24
101416b08: 94010eae    	bl	0x10145a5c0 <__ZN4core5slice4sort6stable14driftsort_main17hd0839377c8e61f05E>
101416b0c: 17ffee57    	b	0x101412468 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2800>
101416b10: f9093bf6    	str	x22, [sp, #0x1270]
101416b14: f9092ff8    	str	x24, [sp, #0x1258]
101416b18: 52800020    	mov	w0, #0x1                ; =1
101416b1c: aa1b03e1    	mov	x1, x27
101416b20: 941ab215    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416b24: 1400005d    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416b28: d0007282    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101416b2c: 91222042    	add	x2, x2, #0x888
101416b30: aa0003e1    	mov	x1, x0
101416b34: 941ab482    	bl	0x101ac3d3c <__ZN4core9panicking18panic_bounds_check17hd6142ed38f8c399dE>
101416b38: 52800100    	mov	w0, #0x8                ; =8
101416b3c: 52803401    	mov	w1, #0x1a0              ; =416
101416b40: 941ab20d    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416b44: 14000055    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416b48: 52800100    	mov	w0, #0x8                ; =8
101416b4c: 52803401    	mov	w1, #0x1a0              ; =416
101416b50: 941ab209    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416b54: 14000051    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416b58: 52800020    	mov	w0, #0x1                ; =1
101416b5c: aa1a03e1    	mov	x1, x26
101416b60: 941ab205    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416b64: 1400004d    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416b68: d0007284    	adrp	x4, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101416b6c: 9121c084    	add	x4, x4, #0x870
101416b70: aa1303e0    	mov	x0, x19
101416b74: aa1503e1    	mov	x1, x21
101416b78: aa1403e2    	mov	x2, x20
101416b7c: aa1503e3    	mov	x3, x21
101416b80: 941ab2a2    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
101416b84: 52800100    	mov	w0, #0x8                ; =8
101416b88: 52800c01    	mov	w1, #0x60               ; =96
101416b8c: 941ab1fa    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416b90: 14000042    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416b94: 52800100    	mov	w0, #0x8                ; =8
101416b98: 52803401    	mov	w1, #0x1a0              ; =416
101416b9c: 941ab1f6    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416ba0: 1400003e    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416ba4: 914007e2    	add	x2, sp, #0x1, lsl #12   ; =0x1000
101416ba8: 91094042    	add	x2, x2, #0x250
101416bac: aa1403e0    	mov	x0, x20
101416bb0: aa1303e1    	mov	x1, x19
101416bb4: 94010ba1    	bl	0x101459a38 <__ZN4core5slice4sort6stable14driftsort_main17h09f3fb579065c468E>
101416bb8: 17fff79b    	b	0x101414a24 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4dbc>
101416bbc: 52800020    	mov	w0, #0x1                ; =1
101416bc0: aa1403e1    	mov	x1, x20
101416bc4: 941ab1ec    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416bc8: 14000034    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416bcc: 52800100    	mov	w0, #0x8                ; =8
101416bd0: 52803401    	mov	w1, #0x1a0              ; =416
101416bd4: 941ab1e8    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416bd8: 14000030    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416bdc: 52800100    	mov	w0, #0x8                ; =8
101416be0: 52800c01    	mov	w1, #0x60               ; =96
101416be4: 941ab1e4    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416be8: 1400002c    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416bec: 910403e2    	add	x2, sp, #0x100
101416bf0: aa1703e0    	mov	x0, x23
101416bf4: aa1803e1    	mov	x1, x24
101416bf8: 94010d90    	bl	0x10145a238 <__ZN4core5slice4sort6stable14driftsort_main17had64d1eda71ae686E>
101416bfc: 17fffd0f    	b	0x101416038 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x63d0>
101416c00: 912783e2    	add	x2, sp, #0x9e0
101416c04: f94047e0    	ldr	x0, [sp, #0x88]
101416c08: aa1903e1    	mov	x1, x25
101416c0c: 9407d052    	bl	0x10160ad54 <__ZN4core5slice4sort6stable14driftsort_main17h1e762a7023a11e2bE>
101416c10: 17fffbca    	b	0x101415b38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5ed0>
101416c14: 52800020    	mov	w0, #0x1                ; =1
101416c18: aa1b03e1    	mov	x1, x27
101416c1c: 941ab1d6    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416c20: 1400001e    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416c24: 52800020    	mov	w0, #0x1                ; =1
101416c28: aa1903e1    	mov	x1, x25
101416c2c: 941ab1d2    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416c30: 1400001a    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416c34: d0007284    	adrp	x4, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101416c38: 91228084    	add	x4, x4, #0x8a0
101416c3c: aa1303e0    	mov	x0, x19
101416c40: aa1403e1    	mov	x1, x20
101416c44: d2800002    	mov	x2, #0x0                ; =0
101416c48: 941ab270    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
101416c4c: 14000013    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416c50: d1000723    	sub	x3, x25, #0x1
101416c54: d0007284    	adrp	x4, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101416c58: 9122e084    	add	x4, x4, #0x8b8
101416c5c: aa1703e0    	mov	x0, x23
101416c60: aa1903e1    	mov	x1, x25
101416c64: 52800022    	mov	w2, #0x1                ; =1
101416c68: 941ab268    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
101416c6c: 1400000b    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416c70: 52800100    	mov	w0, #0x8                ; =8
101416c74: 52800c01    	mov	w1, #0x60               ; =96
101416c78: 941ab1bf    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416c7c: 14000007    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416c80: 900072a3    	adrp	x3, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
101416c84: 9113c063    	add	x3, x3, #0x4f0
101416c88: d2800000    	mov	x0, #0x0                ; =0
101416c8c: aa1503e1    	mov	x1, x21
101416c90: 52800082    	mov	w2, #0x4                ; =4
101416c94: 941ab2f5    	bl	0x101ac3868 <__ZN4core5slice5index16slice_index_fail17h88b945c1204cb3a0E>
101416c98: d4200020    	brk	#0x1
101416c9c: f9004be0    	str	x0, [sp, #0x90]
101416ca0: 912783e0    	add	x0, sp, #0x9e0
101416ca4: 14000132    	b	0x10141716c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7504>
101416ca8: f9004be0    	str	x0, [sp, #0x90]
101416cac: 912783e0    	add	x0, sp, #0x9e0
101416cb0: 14000372    	b	0x101417a78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e10>
101416cb4: f9004be0    	str	x0, [sp, #0x90]
101416cb8: 912783e0    	add	x0, sp, #0x9e0
101416cbc: 140002f5    	b	0x101417890 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c28>
101416cc0: f9004be0    	str	x0, [sp, #0x90]
101416cc4: d10303a0    	sub	x0, x29, #0xc0
101416cc8: 97d4af91    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101416ccc: 14000362    	b	0x101417a54 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7dec>
101416cd0: 1400005e    	b	0x101416e48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x71e0>
101416cd4: f9004be0    	str	x0, [sp, #0x90]
101416cd8: f240fa9f    	tst	x20, #0x7fffffffffffffff
101416cdc: 54001be0    	b.eq	0x101417058 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x73f0>
101416ce0: aa1303e0    	mov	x0, x19
101416ce4: aa1403e1    	mov	x1, x20
101416ce8: 140000b3    	b	0x101416fb4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x734c>
101416cec: f9004be0    	str	x0, [sp, #0x90]
101416cf0: aa1303e0    	mov	x0, x19
101416cf4: aa1903e1    	mov	x1, x25
101416cf8: 52800022    	mov	w2, #0x1                ; =1
101416cfc: 97da1e78    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416d00: 14000053    	b	0x101416e4c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x71e4>
101416d04: f9004be0    	str	x0, [sp, #0x90]
101416d08: b40029d3    	cbz	x19, 0x101417240 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d8>
101416d0c: aa1403e0    	mov	x0, x20
101416d10: aa1303e1    	mov	x1, x19
101416d14: 14000045    	b	0x101416e28 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x71c0>
101416d18: f9004be0    	str	x0, [sp, #0x90]
101416d1c: 1400022f    	b	0x1014175d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7970>
101416d20: f9004be0    	str	x0, [sp, #0x90]
101416d24: 910303e0    	add	x0, sp, #0xc0
101416d28: 97d468b8    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101416d2c: 1400029b    	b	0x101417798 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b30>
101416d30: f9004be0    	str	x0, [sp, #0x90]
101416d34: 910303e0    	add	x0, sp, #0xc0
101416d38: 97d468b4    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101416d3c: 1400029a    	b	0x1014177a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b3c>
101416d40: f9004be0    	str	x0, [sp, #0x90]
101416d44: f9400681    	ldr	x1, [x20, #0x8]
101416d48: b4000081    	cbz	x1, 0x101416d58 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x70f0>
101416d4c: f9400a82    	ldr	x2, [x20, #0x10]
101416d50: aa1303e0    	mov	x0, x19
101416d54: 97da1e62    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416d58: aa1603e0    	mov	x0, x22
101416d5c: 52800301    	mov	w1, #0x18               ; =24
101416d60: 52800102    	mov	w2, #0x8                ; =8
101416d64: 97da1e5e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416d68: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101416d6c: 910b2000    	add	x0, x0, #0x2c8
101416d70: 97d4af67    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101416d74: f9404be0    	ldr	x0, [sp, #0x90]
101416d78: 941aca17    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101416d7c: 14000033    	b	0x101416e48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x71e0>
101416d80: 14000001    	b	0x101416d84 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x711c>
101416d84: f9004be0    	str	x0, [sp, #0x90]
101416d88: f94083e1    	ldr	x1, [sp, #0x100]
101416d8c: b40025a1    	cbz	x1, 0x101417240 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d8>
101416d90: f94087e0    	ldr	x0, [sp, #0x108]
101416d94: 14000025    	b	0x101416e28 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x71c0>
101416d98: f9004be0    	str	x0, [sp, #0x90]
101416d9c: f94006e1    	ldr	x1, [x23, #0x8]
101416da0: b4000081    	cbz	x1, 0x101416db0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7148>
101416da4: f9400ae2    	ldr	x2, [x23, #0x10]
101416da8: aa1403e0    	mov	x0, x20
101416dac: 97da1e4c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416db0: aa1303e0    	mov	x0, x19
101416db4: 52800301    	mov	w1, #0x18               ; =24
101416db8: 52800102    	mov	w2, #0x8                ; =8
101416dbc: 1400013b    	b	0x1014172a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7640>
101416dc0: f9004be0    	str	x0, [sp, #0x90]
101416dc4: b40005b6    	cbz	x22, 0x101416e78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7210>
101416dc8: aa1903e0    	mov	x0, x25
101416dcc: aa1603e1    	mov	x1, x22
101416dd0: 52800022    	mov	w2, #0x1                ; =1
101416dd4: 97da1e42    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416dd8: 14000028    	b	0x101416e78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7210>
101416ddc: f9004be0    	str	x0, [sp, #0x90]
101416de0: 140000d9    	b	0x101417144 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x74dc>
101416de4: f9004be0    	str	x0, [sp, #0x90]
101416de8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101416dec: 910b2000    	add	x0, x0, #0x2c8
101416df0: 97d4af47    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101416df4: f9404be0    	ldr	x0, [sp, #0x90]
101416df8: 941ac9f7    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101416dfc: f9004be0    	str	x0, [sp, #0x90]
101416e00: 52800033    	mov	w19, #0x1               ; =1
101416e04: 140002c9    	b	0x101417928 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7cc0>
101416e08: f9004be0    	str	x0, [sp, #0x90]
101416e0c: 910403e0    	add	x0, sp, #0x100
101416e10: 97db9a32    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101416e14: 140000d7    	b	0x101417170 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7508>
101416e18: f9004be0    	str	x0, [sp, #0x90]
101416e1c: b4002134    	cbz	x20, 0x101417240 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d8>
101416e20: aa1303e0    	mov	x0, x19
101416e24: aa1403e1    	mov	x1, x20
101416e28: 52800022    	mov	w2, #0x1                ; =1
101416e2c: 97da1e2c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416e30: 14000104    	b	0x101417240 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d8>
101416e34: f9004be0    	str	x0, [sp, #0x90]
101416e38: f9092ff5    	str	x21, [sp, #0x1258]
101416e3c: 912783e0    	add	x0, sp, #0x9e0
101416e40: 97db9a26    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101416e44: 14000036    	b	0x101416f1c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x72b4>
101416e48: f9004be0    	str	x0, [sp, #0x90]
101416e4c: 910303e0    	add	x0, sp, #0xc0
101416e50: 97d4af2f    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101416e54: 140000fb    	b	0x101417240 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d8>
101416e58: f9004be0    	str	x0, [sp, #0x90]
101416e5c: 140002d5    	b	0x1014179b0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d48>
101416e60: f9004be0    	str	x0, [sp, #0x90]
101416e64: 140000a2    	b	0x1014170ec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7484>
101416e68: f9004be0    	str	x0, [sp, #0x90]
101416e6c: 52800033    	mov	w19, #0x1               ; =1
101416e70: 14000098    	b	0x1014170d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7468>
101416e74: f9004be0    	str	x0, [sp, #0x90]
101416e78: 910403e0    	add	x0, sp, #0x100
101416e7c: 9400fc46    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
101416e80: 140000b3    	b	0x10141714c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x74e4>
101416e84: 941ab3a8    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101416e88: f9004be0    	str	x0, [sp, #0x90]
101416e8c: f9400681    	ldr	x1, [x20, #0x8]
101416e90: b4002e81    	cbz	x1, 0x101417460 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77f8>
101416e94: f9400a82    	ldr	x2, [x20, #0x10]
101416e98: aa1303e0    	mov	x0, x19
101416e9c: 14000170    	b	0x10141745c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77f4>
101416ea0: 140000e7    	b	0x10141723c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d4>
101416ea4: f9004be0    	str	x0, [sp, #0x90]
101416ea8: f94006e1    	ldr	x1, [x23, #0x8]
101416eac: b4000081    	cbz	x1, 0x101416ebc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7254>
101416eb0: f9400ae2    	ldr	x2, [x23, #0x10]
101416eb4: aa1403e0    	mov	x0, x20
101416eb8: 97da1e09    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416ebc: aa1303e0    	mov	x0, x19
101416ec0: 52800301    	mov	w1, #0x18               ; =24
101416ec4: 52800102    	mov	w2, #0x8                ; =8
101416ec8: 97da1e05    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416ecc: 140000d5    	b	0x101417220 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75b8>
101416ed0: f9004be0    	str	x0, [sp, #0x90]
101416ed4: f9092ff5    	str	x21, [sp, #0x1258]
101416ed8: b40000b9    	cbz	x25, 0x101416eec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7284>
101416edc: aa1a03e0    	mov	x0, x26
101416ee0: aa1903e1    	mov	x1, x25
101416ee4: 52800022    	mov	w2, #0x1                ; =1
101416ee8: 97da1dfd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416eec: f240fb9f    	tst	x28, #0x7fffffffffffffff
101416ef0: 54000160    	b.eq	0x101416f1c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x72b4>
101416ef4: aa1803e0    	mov	x0, x24
101416ef8: aa1c03e1    	mov	x1, x28
101416efc: 14000006    	b	0x101416f14 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x72ac>
101416f00: f9004be0    	str	x0, [sp, #0x90]
101416f04: f9092ff5    	str	x21, [sp, #0x1258]
101416f08: b40000b9    	cbz	x25, 0x101416f1c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x72b4>
101416f0c: aa1a03e0    	mov	x0, x26
101416f10: aa1903e1    	mov	x1, x25
101416f14: 52800022    	mov	w2, #0x1                ; =1
101416f18: 97da1df1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416f1c: f94043e8    	ldr	x8, [sp, #0x80]
101416f20: f240f91f    	tst	x8, #0x7fffffffffffffff
101416f24: 54000340    	b.eq	0x101416f8c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7324>
101416f28: aa1703e0    	mov	x0, x23
101416f2c: f94043e1    	ldr	x1, [sp, #0x80]
101416f30: 14000006    	b	0x101416f48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x72e0>
101416f34: f9004be0    	str	x0, [sp, #0x90]
101416f38: f9092ff5    	str	x21, [sp, #0x1258]
101416f3c: b4000299    	cbz	x25, 0x101416f8c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7324>
101416f40: aa1a03e0    	mov	x0, x26
101416f44: aa1903e1    	mov	x1, x25
101416f48: 52800022    	mov	w2, #0x1                ; =1
101416f4c: 97da1de4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416f50: 1400000f    	b	0x101416f8c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7324>
101416f54: f9004be0    	str	x0, [sp, #0x90]
101416f58: f9092ff5    	str	x21, [sp, #0x1258]
101416f5c: f94063e1    	ldr	x1, [sp, #0xc0]
101416f60: b50001a1    	cbnz	x1, 0x101416f94 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x732c>
101416f64: 1400004a    	b	0x10141708c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7424>
101416f68: 140000b5    	b	0x10141723c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d4>
101416f6c: 1400003a    	b	0x101417054 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x73ec>
101416f70: 140002c0    	b	0x101417a70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e08>
101416f74: f9004be0    	str	x0, [sp, #0x90]
101416f78: 9125c3e0    	add	x0, sp, #0x970
101416f7c: 97db99d7    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101416f80: 1400002a    	b	0x101417028 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x73c0>
101416f84: f9004be0    	str	x0, [sp, #0x90]
101416f88: f9092ff5    	str	x21, [sp, #0x1258]
101416f8c: f85403a1    	ldur	x1, [x29, #-0xc0]
101416f90: b40007e1    	cbz	x1, 0x10141708c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7424>
101416f94: aa1303e0    	mov	x0, x19
101416f98: 52800022    	mov	w2, #0x1                ; =1
101416f9c: 97da1dd0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416fa0: 1400003b    	b	0x10141708c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7424>
101416fa4: f9004be0    	str	x0, [sp, #0x90]
101416fa8: b4000595    	cbz	x21, 0x101417058 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x73f0>
101416fac: aa1603e0    	mov	x0, x22
101416fb0: aa1503e1    	mov	x1, x21
101416fb4: 52800022    	mov	w2, #0x1                ; =1
101416fb8: 97da1dc9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416fbc: 14000027    	b	0x101417058 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x73f0>
101416fc0: f9004be0    	str	x0, [sp, #0x90]
101416fc4: 1400006b    	b	0x101417170 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7508>
101416fc8: f9004be0    	str	x0, [sp, #0x90]
101416fcc: b4002d93    	cbz	x19, 0x10141757c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7914>
101416fd0: aa1503e0    	mov	x0, x21
101416fd4: aa1303e1    	mov	x1, x19
101416fd8: 52800022    	mov	w2, #0x1                ; =1
101416fdc: 97da1dc0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416fe0: 910403e0    	add	x0, sp, #0x100
101416fe4: 9400f832    	bl	0x1014550ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7c24>
101416fe8: f9404be0    	ldr	x0, [sp, #0x90]
101416fec: 941ac97a    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101416ff0: 14000123    	b	0x10141747c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7814>
101416ff4: f9004be0    	str	x0, [sp, #0x90]
101416ff8: 912783e0    	add	x0, sp, #0x9e0
101416ffc: 9400ef57    	bl	0x101452d58 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x58d0>
101417000: 14000276    	b	0x1014179d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d70>
101417004: f9004be0    	str	x0, [sp, #0x90]
101417008: 14000120    	b	0x101417488 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7820>
10141700c: f9004be0    	str	x0, [sp, #0x90]
101417010: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101417014: 910b2000    	add	x0, x0, #0x2c8
101417018: 97d4aebd    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10141701c: f9404be0    	ldr	x0, [sp, #0x90]
101417020: 941ac96d    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417024: f9004be0    	str	x0, [sp, #0x90]
101417028: 910403e0    	add	x0, sp, #0x100
10141702c: 9400fbda    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
101417030: 14000293    	b	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417034: 941ab33c    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101417038: f9004be0    	str	x0, [sp, #0x90]
10141703c: b4000819    	cbz	x25, 0x10141713c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x74d4>
101417040: aa1a03e0    	mov	x0, x26
101417044: aa1903e1    	mov	x1, x25
101417048: 52800022    	mov	w2, #0x1                ; =1
10141704c: 97da1da4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417050: 1400003b    	b	0x10141713c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x74d4>
101417054: f9004be0    	str	x0, [sp, #0x90]
101417058: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10141705c: 91094000    	add	x0, x0, #0x250
101417060: 97d4aeab    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101417064: 910403e0    	add	x0, sp, #0x100
101417068: 9400f811    	bl	0x1014550ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7c24>
10141706c: f9404be0    	ldr	x0, [sp, #0x90]
101417070: 941ac959    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417074: f9004be0    	str	x0, [sp, #0x90]
101417078: 912783e0    	add	x0, sp, #0x9e0
10141707c: 97db9997    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101417080: 1400003a    	b	0x101417168 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7500>
101417084: f9004be0    	str	x0, [sp, #0x90]
101417088: f9092ff5    	str	x21, [sp, #0x1258]
10141708c: f85283a1    	ldur	x1, [x29, #-0xd8]
101417090: b4000081    	cbz	x1, 0x1014170a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7438>
101417094: f85303a0    	ldur	x0, [x29, #-0xd0]
101417098: 52800022    	mov	w2, #0x1                ; =1
10141709c: 97da1d90    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014170a0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014170a4: 91094000    	add	x0, x0, #0x250
1014170a8: 97d467d8    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
1014170ac: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014170b0: 910ca000    	add	x0, x0, #0x328
1014170b4: 9400fb6c    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
1014170b8: f9498be1    	ldr	x1, [sp, #0x1310]
1014170bc: b4000081    	cbz	x1, 0x1014170cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7464>
1014170c0: f9498fe0    	ldr	x0, [sp, #0x1318]
1014170c4: 52800022    	mov	w2, #0x1                ; =1
1014170c8: 97da1d85    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014170cc: 52800013    	mov	w19, #0x0               ; =0
1014170d0: f9497fe1    	ldr	x1, [sp, #0x12f8]
1014170d4: f240f83f    	tst	x1, #0x7fffffffffffffff
1014170d8: 54000080    	b.eq	0x1014170e8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7480>
1014170dc: f94983e0    	ldr	x0, [sp, #0x1300]
1014170e0: 52800022    	mov	w2, #0x1                ; =1
1014170e4: 97da1d7e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014170e8: 36000333    	tbz	w19, #0x0, 0x10141714c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x74e4>
1014170ec: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014170f0: 910b8000    	add	x0, x0, #0x2e0
1014170f4: 97d4ae86    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
1014170f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014170fc: 910b2000    	add	x0, x0, #0x2c8
101417100: 97d4ae83    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101417104: f9404be0    	ldr	x0, [sp, #0x90]
101417108: 941ac933    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10141710c: f9004be0    	str	x0, [sp, #0x90]
101417110: aa1703e0    	mov	x0, x23
101417114: aa1a03e1    	mov	x1, x26
101417118: 52800022    	mov	w2, #0x1                ; =1
10141711c: 97da1d70    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417120: 1400018e    	b	0x101417758 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7af0>
101417124: f9004be0    	str	x0, [sp, #0x90]
101417128: 14000061    	b	0x1014172ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7644>
10141712c: 140000fb    	b	0x101417518 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x78b0>
101417130: f9004be0    	str	x0, [sp, #0x90]
101417134: 14000011    	b	0x101417178 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7510>
101417138: f9004be0    	str	x0, [sp, #0x90]
10141713c: 912783e0    	add	x0, sp, #0x9e0
101417140: 9400fb95    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
101417144: 9125c3e0    	add	x0, sp, #0x970
101417148: 97d4ae71    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10141714c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101417150: 910b2000    	add	x0, x0, #0x2c8
101417154: 97d4ae6e    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101417158: f9404be0    	ldr	x0, [sp, #0x90]
10141715c: 941ac91e    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417160: 941ab2f1    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101417164: f9004be0    	str	x0, [sp, #0x90]
101417168: d10283a0    	sub	x0, x29, #0xa0
10141716c: 9400fb3e    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417170: 910303e0    	add	x0, sp, #0xc0
101417174: 9400f156    	bl	0x1014536cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6244>
101417178: b4000559    	cbz	x25, 0x101417220 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75b8>
10141717c: aa1403e0    	mov	x0, x20
101417180: aa1903e1    	mov	x1, x25
101417184: 52800022    	mov	w2, #0x1                ; =1
101417188: 97da1d55    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141718c: 14000025    	b	0x101417220 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75b8>
101417190: 941ab2e5    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101417194: f9004be0    	str	x0, [sp, #0x90]
101417198: f94006e1    	ldr	x1, [x23, #0x8]
10141719c: b4001621    	cbz	x1, 0x101417460 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77f8>
1014171a0: f9400ae2    	ldr	x2, [x23, #0x10]
1014171a4: aa1803e0    	mov	x0, x24
1014171a8: 140000ad    	b	0x10141745c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77f4>
1014171ac: 1400016a    	b	0x101417754 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7aec>
1014171b0: f9004be0    	str	x0, [sp, #0x90]
1014171b4: f9093bf6    	str	x22, [sp, #0x1270]
1014171b8: f9092ff8    	str	x24, [sp, #0x1258]
1014171bc: 912783e0    	add	x0, sp, #0x9e0
1014171c0: 97db9946    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014171c4: 140000f9    	b	0x1014175a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7940>
1014171c8: f9004be0    	str	x0, [sp, #0x90]
1014171cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014171d0: 91094000    	add	x0, x0, #0x250
1014171d4: 97db9941    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014171d8: 910303e0    	add	x0, sp, #0xc0
1014171dc: 97d4678b    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
1014171e0: 910403e0    	add	x0, sp, #0x100
1014171e4: 9400f7b2    	bl	0x1014550ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7c24>
1014171e8: f9404be0    	ldr	x0, [sp, #0x90]
1014171ec: 941ac8fa    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014171f0: f9004be0    	str	x0, [sp, #0x90]
1014171f4: f94006a1    	ldr	x1, [x21, #0x8]
1014171f8: b4000081    	cbz	x1, 0x101417208 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75a0>
1014171fc: f9400aa2    	ldr	x2, [x21, #0x10]
101417200: aa1403e0    	mov	x0, x20
101417204: 97da1d36    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417208: aa1303e0    	mov	x0, x19
10141720c: 52800301    	mov	w1, #0x18               ; =24
101417210: 52800102    	mov	w2, #0x8                ; =8
101417214: 97da1d32    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417218: 14000169    	b	0x1014177bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b54>
10141721c: f9004be0    	str	x0, [sp, #0x90]
101417220: b40042f6    	cbz	x22, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417224: aa1503e0    	mov	x0, x21
101417228: aa1603e1    	mov	x1, x22
10141722c: 52800022    	mov	w2, #0x1                ; =1
101417230: 97da1d2b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417234: f9404be0    	ldr	x0, [sp, #0x90]
101417238: 941ac8e7    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10141723c: f9004be0    	str	x0, [sp, #0x90]
101417240: f9404fe8    	ldr	x8, [sp, #0x98]
101417244: b40000a8    	cbz	x8, 0x101417258 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75f0>
101417248: aa1a03e0    	mov	x0, x26
10141724c: f9404fe1    	ldr	x1, [sp, #0x98]
101417250: 52800022    	mov	w2, #0x1                ; =1
101417254: 97da1d22    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417258: f94523e1    	ldr	x1, [sp, #0xa40]
10141725c: f240f83f    	tst	x1, #0x7fffffffffffffff
101417260: 54000080    	b.eq	0x101417270 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7608>
101417264: f94527e0    	ldr	x0, [sp, #0xa48]
101417268: 52800022    	mov	w2, #0x1                ; =1
10141726c: 97da1d1c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417270: 912783f3    	add	x19, sp, #0x9e0
101417274: 912783e0    	add	x0, sp, #0x9e0
101417278: 97d4ae25    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10141727c: 91006260    	add	x0, x19, #0x18
101417280: 97d4ae23    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101417284: 9100c260    	add	x0, x19, #0x30
101417288: 97d4ae21    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10141728c: 91012260    	add	x0, x19, #0x48
101417290: 97d4ae1f    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101417294: f9405fe8    	ldr	x8, [sp, #0xb8]
101417298: b40000a8    	cbz	x8, 0x1014172ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7644>
10141729c: f94047e0    	ldr	x0, [sp, #0x88]
1014172a0: f9405fe1    	ldr	x1, [sp, #0xb8]
1014172a4: 52800022    	mov	w2, #0x1                ; =1
1014172a8: 97da1d0d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014172ac: f94057e8    	ldr	x8, [sp, #0xa8]
1014172b0: b4003e68    	cbz	x8, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
1014172b4: a94a07e0    	ldp	x0, x1, [sp, #0xa0]
1014172b8: 52800022    	mov	w2, #0x1                ; =1
1014172bc: 97da1d08    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014172c0: f9404be0    	ldr	x0, [sp, #0x90]
1014172c4: 941ac8c4    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014172c8: f9004be0    	str	x0, [sp, #0x90]
1014172cc: 140000bf    	b	0x1014175c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7960>
1014172d0: f9004be0    	str	x0, [sp, #0x90]
1014172d4: 910403e0    	add	x0, sp, #0x100
1014172d8: 9400f775    	bl	0x1014550ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7c24>
1014172dc: f9404be0    	ldr	x0, [sp, #0x90]
1014172e0: 941ac8bd    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014172e4: f9004be0    	str	x0, [sp, #0x90]
1014172e8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014172ec: 91094000    	add	x0, x0, #0x250
1014172f0: 97db98fa    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014172f4: 14000025    	b	0x101417388 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7720>
1014172f8: f9004be0    	str	x0, [sp, #0x90]
1014172fc: f94006c1    	ldr	x1, [x22, #0x8]
101417300: b4000081    	cbz	x1, 0x101417310 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x76a8>
101417304: f9400ac2    	ldr	x2, [x22, #0x10]
101417308: aa1303e0    	mov	x0, x19
10141730c: 97da1cf4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417310: aa1403e0    	mov	x0, x20
101417314: 52800301    	mov	w1, #0x18               ; =24
101417318: 52800102    	mov	w2, #0x8                ; =8
10141731c: 97da1cf0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417320: 1400015d    	b	0x101417894 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c2c>
101417324: f9004be0    	str	x0, [sp, #0x90]
101417328: 910303e0    	add	x0, sp, #0xc0
10141732c: 97d46737    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417330: 910403e0    	add	x0, sp, #0x100
101417334: 9400f75e    	bl	0x1014550ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7c24>
101417338: f9404be0    	ldr	x0, [sp, #0x90]
10141733c: 941ac8a6    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417340: f9004be0    	str	x0, [sp, #0x90]
101417344: 910403e0    	add	x0, sp, #0x100
101417348: 97db98e4    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10141734c: 14000016    	b	0x1014173a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x773c>
101417350: f9004be0    	str	x0, [sp, #0x90]
101417354: 14000095    	b	0x1014175a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7940>
101417358: f9004be0    	str	x0, [sp, #0x90]
10141735c: f9400761    	ldr	x1, [x27, #0x8]
101417360: b4000081    	cbz	x1, 0x101417370 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7708>
101417364: f9400b62    	ldr	x2, [x27, #0x10]
101417368: aa1803e0    	mov	x0, x24
10141736c: 97da1cdc    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417370: aa1403e0    	mov	x0, x20
101417374: 52800301    	mov	w1, #0x18               ; =24
101417378: 52800102    	mov	w2, #0x8                ; =8
10141737c: 97da1cd8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417380: 14000077    	b	0x10141755c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x78f4>
101417384: f9004be0    	str	x0, [sp, #0x90]
101417388: 912783e0    	add	x0, sp, #0x9e0
10141738c: 9400fb02    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
101417390: 140001b9    	b	0x101417a74 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e0c>
101417394: 941ab264    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101417398: f9004be0    	str	x0, [sp, #0x90]
10141739c: 14000104    	b	0x1014177ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b44>
1014173a0: f9004be0    	str	x0, [sp, #0x90]
1014173a4: 9125c3e0    	add	x0, sp, #0x970
1014173a8: 97d46718    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
1014173ac: 140000f5    	b	0x101417780 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b18>
1014173b0: f9004be0    	str	x0, [sp, #0x90]
1014173b4: 14000136    	b	0x10141788c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c24>
1014173b8: f9004be0    	str	x0, [sp, #0x90]
1014173bc: 9125c3e0    	add	x0, sp, #0x970
1014173c0: 97db98c6    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014173c4: 14000036    	b	0x10141749c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7834>
1014173c8: 14000052    	b	0x101417510 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x78a8>
1014173cc: f9004be0    	str	x0, [sp, #0x90]
1014173d0: 140000f5    	b	0x1014177a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b3c>
1014173d4: f9004be0    	str	x0, [sp, #0x90]
1014173d8: f9492be1    	ldr	x1, [sp, #0x1250]
1014173dc: b40000c1    	cbz	x1, 0x1014173f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x778c>
1014173e0: aa1303e0    	mov	x0, x19
1014173e4: 52800022    	mov	w2, #0x1                ; =1
1014173e8: 97da1cbd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014173ec: 14000002    	b	0x1014173f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x778c>
1014173f0: f9004be0    	str	x0, [sp, #0x90]
1014173f4: f944f3e1    	ldr	x1, [sp, #0x9e0]
1014173f8: b40000c1    	cbz	x1, 0x101417410 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77a8>
1014173fc: aa1403e0    	mov	x0, x20
101417400: 52800022    	mov	w2, #0x1                ; =1
101417404: 97da1cb6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417408: 14000002    	b	0x101417410 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77a8>
10141740c: f9004be0    	str	x0, [sp, #0x90]
101417410: 910403e0    	add	x0, sp, #0x100
101417414: 97d466fd    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417418: 1400014d    	b	0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
10141741c: f9004be0    	str	x0, [sp, #0x90]
101417420: f9400761    	ldr	x1, [x27, #0x8]
101417424: b4000081    	cbz	x1, 0x101417434 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77cc>
101417428: f9400b62    	ldr	x2, [x27, #0x10]
10141742c: aa1903e0    	mov	x0, x25
101417430: 97da1cab    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417434: aa1803e0    	mov	x0, x24
101417438: 52800301    	mov	w1, #0x18               ; =24
10141743c: 52800102    	mov	w2, #0x8                ; =8
101417440: 97da1ca7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417444: 14000101    	b	0x101417848 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7be0>
101417448: f9004be0    	str	x0, [sp, #0x90]
10141744c: f94006e1    	ldr	x1, [x23, #0x8]
101417450: b4000081    	cbz	x1, 0x101417460 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77f8>
101417454: f9400ae2    	ldr	x2, [x23, #0x10]
101417458: aa1603e0    	mov	x0, x22
10141745c: 97da1ca0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417460: aa1503e0    	mov	x0, x21
101417464: 52800301    	mov	w1, #0x18               ; =24
101417468: 52800102    	mov	w2, #0x8                ; =8
10141746c: 97da1c9c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417470: f9404be0    	ldr	x0, [sp, #0x90]
101417474: 941ac858    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417478: 140000fd    	b	0x10141786c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c04>
10141747c: f9004be0    	str	x0, [sp, #0x90]
101417480: 912783e0    	add	x0, sp, #0x9e0
101417484: 97d4c576    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
101417488: 9125c3e0    	add	x0, sp, #0x970
10141748c: 9400fa76    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417490: 14000152    	b	0x1014179d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d70>
101417494: 14000019    	b	0x1014174f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7890>
101417498: f9004be0    	str	x0, [sp, #0x90]
10141749c: 910403e0    	add	x0, sp, #0x100
1014174a0: 9400fabd    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
1014174a4: 140000fc    	b	0x101417894 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c2c>
1014174a8: 941ab21f    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014174ac: f9004be0    	str	x0, [sp, #0x90]
1014174b0: f944f3e1    	ldr	x1, [sp, #0x9e0]
1014174b4: b40018e1    	cbz	x1, 0x1014177d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b68>
1014174b8: aa1303e0    	mov	x0, x19
1014174bc: 140000c3    	b	0x1014177c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b60>
1014174c0: f9004be0    	str	x0, [sp, #0x90]
1014174c4: 140000c3    	b	0x1014177d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b68>
1014174c8: f9004be0    	str	x0, [sp, #0x90]
1014174cc: 140000c3    	b	0x1014177d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b70>
1014174d0: f9004be0    	str	x0, [sp, #0x90]
1014174d4: f944f3e1    	ldr	x1, [sp, #0x9e0]
1014174d8: b5001841    	cbnz	x1, 0x1014177e0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b78>
1014174dc: 1400011c    	b	0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
1014174e0: f9004be0    	str	x0, [sp, #0x90]
1014174e4: 1400011a    	b	0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
1014174e8: f9004be0    	str	x0, [sp, #0x90]
1014174ec: 912783e0    	add	x0, sp, #0x9e0
1014174f0: 97db987a    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014174f4: 1400001e    	b	0x10141756c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7904>
1014174f8: f9004be0    	str	x0, [sp, #0x90]
1014174fc: aa1703e0    	mov	x0, x23
101417500: aa1403e1    	mov	x1, x20
101417504: 52800022    	mov	w2, #0x1                ; =1
101417508: 97da1c75    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141750c: 14000126    	b	0x1014179a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d3c>
101417510: f9004be0    	str	x0, [sp, #0x90]
101417514: 140000e0    	b	0x101417894 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c2c>
101417518: f9004be0    	str	x0, [sp, #0x90]
10141751c: f944f3e1    	ldr	x1, [sp, #0x9e0]
101417520: b4002ae1    	cbz	x1, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417524: aa1303e0    	mov	x0, x19
101417528: 52800022    	mov	w2, #0x1                ; =1
10141752c: 97da1c6c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417530: f9404be0    	ldr	x0, [sp, #0x90]
101417534: 941ac828    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417538: f9004be0    	str	x0, [sp, #0x90]
10141753c: 140000a0    	b	0x1014177bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b54>
101417540: f9004be0    	str	x0, [sp, #0x90]
101417544: 910403e0    	add	x0, sp, #0x100
101417548: 97db9864    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10141754c: 1400005a    	b	0x1014176b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7a4c>
101417550: f9004be0    	str	x0, [sp, #0x90]
101417554: 140000fb    	b	0x101417940 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7cd8>
101417558: f9004be0    	str	x0, [sp, #0x90]
10141755c: f94083e1    	ldr	x1, [sp, #0x100]
101417560: b50019e1    	cbnz	x1, 0x10141789c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c34>
101417564: 14000146    	b	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417568: f9004be0    	str	x0, [sp, #0x90]
10141756c: 9125c3e0    	add	x0, sp, #0x970
101417570: 97d466a6    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417574: d10283a0    	sub	x0, x29, #0xa0
101417578: 9400fa3b    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10141757c: 910403e0    	add	x0, sp, #0x100
101417580: 9400f6cb    	bl	0x1014550ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7c24>
101417584: f9404be0    	ldr	x0, [sp, #0x90]
101417588: 941ac813    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10141758c: f9004be0    	str	x0, [sp, #0x90]
101417590: 912783e0    	add	x0, sp, #0x9e0
101417594: 97db9851    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101417598: 14000075    	b	0x10141776c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b04>
10141759c: f9004be0    	str	x0, [sp, #0x90]
1014175a0: f9093bf6    	str	x22, [sp, #0x1270]
1014175a4: f9092ff8    	str	x24, [sp, #0x1258]
1014175a8: b40000b7    	cbz	x23, 0x1014175bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7954>
1014175ac: aa1903e0    	mov	x0, x25
1014175b0: aa1703e1    	mov	x1, x23
1014175b4: 52800022    	mov	w2, #0x1                ; =1
1014175b8: 97da1c49    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014175bc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014175c0: 91094000    	add	x0, x0, #0x250
1014175c4: 97d46691    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
1014175c8: 910303e0    	add	x0, sp, #0xc0
1014175cc: 9400fa26    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
1014175d0: 910403e0    	add	x0, sp, #0x100
1014175d4: 97d4c522    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
1014175d8: f85603a1    	ldur	x1, [x29, #-0xa0]
1014175dc: f240f83f    	tst	x1, #0x7fffffffffffffff
1014175e0: 540024e0    	b.eq	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
1014175e4: f85683a0    	ldur	x0, [x29, #-0x98]
1014175e8: 52800022    	mov	w2, #0x1                ; =1
1014175ec: 97da1c3c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014175f0: f9404be0    	ldr	x0, [sp, #0x90]
1014175f4: 941ac7f8    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014175f8: f9004be0    	str	x0, [sp, #0x90]
1014175fc: f904f7fb    	str	x27, [sp, #0x9e8]
101417600: f90503ff    	str	xzr, [sp, #0xa00]
101417604: b40000b5    	cbz	x21, 0x101417618 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x79b0>
101417608: aa1603e0    	mov	x0, x22
10141760c: aa1503e1    	mov	x1, x21
101417610: 52800022    	mov	w2, #0x1                ; =1
101417614: 97da1c32    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417618: aa1703e0    	mov	x0, x23
10141761c: 528000c1    	mov	w1, #0x6                ; =6
101417620: 14000005    	b	0x101417634 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x79cc>
101417624: f9004be0    	str	x0, [sp, #0x90]
101417628: b40000b5    	cbz	x21, 0x10141763c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x79d4>
10141762c: aa1603e0    	mov	x0, x22
101417630: aa1503e1    	mov	x1, x21
101417634: 52800022    	mov	w2, #0x1                ; =1
101417638: 97da1c29    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141763c: f904c3ff    	str	xzr, [sp, #0x980]
101417640: 912783e0    	add	x0, sp, #0x9e0
101417644: 97d46671    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417648: 9125c3e0    	add	x0, sp, #0x970
10141764c: 1400010b    	b	0x101417a78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e10>
101417650: f9004be0    	str	x0, [sp, #0x90]
101417654: 91002293    	add	x19, x20, #0x8
101417658: 14000004    	b	0x101417668 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7a00>
10141765c: 91006273    	add	x19, x19, #0x18
101417660: f10006b5    	subs	x21, x21, #0x1
101417664: 540000e0    	b.eq	0x101417680 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7a18>
101417668: f85f8261    	ldur	x1, [x19, #-0x8]
10141766c: b4ffff81    	cbz	x1, 0x10141765c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x79f4>
101417670: f9400260    	ldr	x0, [x19]
101417674: 52800022    	mov	w2, #0x1                ; =1
101417678: 97da1c19    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141767c: 17fffff8    	b	0x10141765c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x79f4>
101417680: b4001ff9    	cbz	x25, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417684: 8b190728    	add	x8, x25, x25, lsl #1
101417688: d37df101    	lsl	x1, x8, #3
10141768c: aa1403e0    	mov	x0, x20
101417690: 52800102    	mov	w2, #0x8                ; =8
101417694: 97da1c12    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417698: f9404be0    	ldr	x0, [sp, #0x90]
10141769c: 941ac7ce    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014176a0: f9004be0    	str	x0, [sp, #0x90]
1014176a4: 912783e0    	add	x0, sp, #0x9e0
1014176a8: 97db980c    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014176ac: 14000092    	b	0x1014178f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c8c>
1014176b0: f9004be0    	str	x0, [sp, #0x90]
1014176b4: 9125c3e0    	add	x0, sp, #0x970
1014176b8: 97d46654    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
1014176bc: b5001815    	cbnz	x21, 0x1014179bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d54>
1014176c0: 140000ef    	b	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
1014176c4: f9004be0    	str	x0, [sp, #0x90]
1014176c8: 912783e0    	add	x0, sp, #0x9e0
1014176cc: 97ec4f73    	bl	0x100f2b498 <__ZN200_$LT$otty_sync_dotfiles..catalog.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_sync_dotfiles..catalog..CatalogAppSpec$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hace6feb1294ba67fE+0x6bc0>
1014176d0: 1400009f    	b	0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
1014176d4: f9004be0    	str	x0, [sp, #0x90]
1014176d8: f9092ff8    	str	x24, [sp, #0x1258]
1014176dc: 912783e0    	add	x0, sp, #0x9e0
1014176e0: 97db97fe    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014176e4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014176e8: 91094000    	add	x0, x0, #0x250
1014176ec: 9400ed9b    	bl	0x101452d58 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x58d0>
1014176f0: 910403e0    	add	x0, sp, #0x100
1014176f4: 97d4c4da    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
1014176f8: 140000b8    	b	0x1014179d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d70>
1014176fc: f9004be0    	str	x0, [sp, #0x90]
101417700: b5000155    	cbnz	x21, 0x101417728 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ac0>
101417704: f9405fe8    	ldr	x8, [sp, #0xb8]
101417708: b4001a68    	cbz	x8, 0x101417a54 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7dec>
10141770c: f9405fe8    	ldr	x8, [sp, #0xb8]
101417710: 8b080508    	add	x8, x8, x8, lsl #1
101417714: d37df101    	lsl	x1, x8, #3
101417718: aa1403e0    	mov	x0, x20
10141771c: 52800102    	mov	w2, #0x8                ; =8
101417720: 97da1bef    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417724: 140000cc    	b	0x101417a54 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7dec>
101417728: 91002293    	add	x19, x20, #0x8
10141772c: 14000004    	b	0x10141773c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ad4>
101417730: 91006273    	add	x19, x19, #0x18
101417734: f10006b5    	subs	x21, x21, #0x1
101417738: 54fffe60    	b.eq	0x101417704 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7a9c>
10141773c: f85f8261    	ldur	x1, [x19, #-0x8]
101417740: b4ffff81    	cbz	x1, 0x101417730 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ac8>
101417744: f9400260    	ldr	x0, [x19]
101417748: 52800022    	mov	w2, #0x1                ; =1
10141774c: 97da1be4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417750: 17fffff8    	b	0x101417730 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ac8>
101417754: f9004be0    	str	x0, [sp, #0x90]
101417758: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10141775c: 91094000    	add	x0, x0, #0x250
101417760: 97d4aceb    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101417764: 14000007    	b	0x101417780 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b18>
101417768: f9004be0    	str	x0, [sp, #0x90]
10141776c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101417770: 91094000    	add	x0, x0, #0x250
101417774: 97d46625    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417778: 910303e0    	add	x0, sp, #0xc0
10141777c: 9400f9ba    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417780: b50011f5    	cbnz	x21, 0x1014179bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d54>
101417784: 140000be    	b	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417788: f9004be0    	str	x0, [sp, #0x90]
10141778c: f904bff3    	str	x19, [sp, #0x978]
101417790: 9125c3e0    	add	x0, sp, #0x970
101417794: 97d4661d    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417798: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10141779c: 91094000    	add	x0, x0, #0x250
1014177a0: 97d4c4af    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
1014177a4: 912783e0    	add	x0, sp, #0x9e0
1014177a8: 9400ee2d    	bl	0x10145305c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5bd4>
1014177ac: 71000f7f    	cmp	w27, #0x3
1014177b0: 54000061    	b.ne	0x1014177bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b54>
1014177b4: 910403e0    	add	x0, sp, #0x100
1014177b8: 9400fbf8    	bl	0x101456798 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x9310>
1014177bc: f85403a1    	ldur	x1, [x29, #-0xc0]
1014177c0: b4000081    	cbz	x1, 0x1014177d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b68>
1014177c4: aa1903e0    	mov	x0, x25
1014177c8: 52800022    	mov	w2, #0x1                ; =1
1014177cc: 97da1bc4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014177d0: d10363a0    	sub	x0, x29, #0xd8
1014177d4: 97d4acce    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
1014177d8: f94997e1    	ldr	x1, [sp, #0x1328]
1014177dc: b4000b81    	cbz	x1, 0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
1014177e0: aa1803e0    	mov	x0, x24
1014177e4: 52800022    	mov	w2, #0x1                ; =1
1014177e8: 97da1bbd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014177ec: 14000058    	b	0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
1014177f0: 941ab14d    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014177f4: f9004be0    	str	x0, [sp, #0x90]
1014177f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014177fc: 91094000    	add	x0, x0, #0x250
101417800: 97db97b6    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101417804: 14000020    	b	0x101417884 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c1c>
101417808: f9004be0    	str	x0, [sp, #0x90]
10141780c: b4000757    	cbz	x23, 0x1014178f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c8c>
101417810: aa1803e0    	mov	x0, x24
101417814: aa1703e1    	mov	x1, x23
101417818: 14000033    	b	0x1014178e4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c7c>
10141781c: f9004be0    	str	x0, [sp, #0x90]
101417820: b40000b7    	cbz	x23, 0x101417834 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7bcc>
101417824: aa1803e0    	mov	x0, x24
101417828: aa1703e1    	mov	x1, x23
10141782c: 52800022    	mov	w2, #0x1                ; =1
101417830: 97da1bab    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417834: aa1903e0    	mov	x0, x25
101417838: aa1503e1    	mov	x1, x21
10141783c: 1400002a    	b	0x1014178e4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c7c>
101417840: f9005bf5    	str	x21, [sp, #0xb0]
101417844: f9004be0    	str	x0, [sp, #0x90]
101417848: f94083e1    	ldr	x1, [sp, #0x100]
10141784c: b4001181    	cbz	x1, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417850: f9405be0    	ldr	x0, [sp, #0xb0]
101417854: 52800022    	mov	w2, #0x1                ; =1
101417858: 97da1ba1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141785c: f9404be0    	ldr	x0, [sp, #0x90]
101417860: 941ac75d    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417864: f9004be0    	str	x0, [sp, #0x90]
101417868: 1400007b    	b	0x101417a54 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7dec>
10141786c: f9004be0    	str	x0, [sp, #0x90]
101417870: f944f3e1    	ldr	x1, [sp, #0x9e0]
101417874: b5000141    	cbnz	x1, 0x10141789c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c34>
101417878: 14000081    	b	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
10141787c: 14000049    	b	0x1014179a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d38>
101417880: f9004be0    	str	x0, [sp, #0x90]
101417884: 912783e0    	add	x0, sp, #0x9e0
101417888: 9400f9c3    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
10141788c: 910303e0    	add	x0, sp, #0xc0
101417890: 9400f975    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417894: f85603a1    	ldur	x1, [x29, #-0xa0]
101417898: b4000f21    	cbz	x1, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
10141789c: aa1503e0    	mov	x0, x21
1014178a0: 52800022    	mov	w2, #0x1                ; =1
1014178a4: 97da1b8e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014178a8: f9404be0    	ldr	x0, [sp, #0x90]
1014178ac: 941ac74a    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014178b0: 941ab11d    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014178b4: 1400003b    	b	0x1014179a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d38>
1014178b8: f9004be0    	str	x0, [sp, #0x90]
1014178bc: b40008f3    	cbz	x19, 0x1014179d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d70>
1014178c0: aa1403e0    	mov	x0, x20
1014178c4: aa1303e1    	mov	x1, x19
1014178c8: 52800022    	mov	w2, #0x1                ; =1
1014178cc: 97da1b84    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014178d0: 14000042    	b	0x1014179d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d70>
1014178d4: f9004be0    	str	x0, [sp, #0x90]
1014178d8: f85403a1    	ldur	x1, [x29, #-0xc0]
1014178dc: b40000c1    	cbz	x1, 0x1014178f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c8c>
1014178e0: f85483a0    	ldur	x0, [x29, #-0xb8]
1014178e4: 52800022    	mov	w2, #0x1                ; =1
1014178e8: 97da1b7d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014178ec: 14000002    	b	0x1014178f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c8c>
1014178f0: f9004be0    	str	x0, [sp, #0x90]
1014178f4: f85283a1    	ldur	x1, [x29, #-0xd8]
1014178f8: b4000081    	cbz	x1, 0x101417908 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ca0>
1014178fc: f85303a0    	ldur	x0, [x29, #-0xd0]
101417900: 52800022    	mov	w2, #0x1                ; =1
101417904: 97da1b76    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417908: 910403e0    	add	x0, sp, #0x100
10141790c: 9400f550    	bl	0x101454e4c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x79c4>
101417910: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101417914: 910ca000    	add	x0, x0, #0x328
101417918: 9400f953    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10141791c: 9125c3e0    	add	x0, sp, #0x970
101417920: 97d4c44f    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
101417924: 52800013    	mov	w19, #0x0               ; =0
101417928: f9498be1    	ldr	x1, [sp, #0x1310]
10141792c: b4000081    	cbz	x1, 0x10141793c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7cd4>
101417930: f9498fe0    	ldr	x0, [sp, #0x1318]
101417934: 52800022    	mov	w2, #0x1                ; =1
101417938: 97da1b69    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141793c: 36000093    	tbz	w19, #0x0, 0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
101417940: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101417944: 91094000    	add	x0, x0, #0x250
101417948: 9400f541    	bl	0x101454e4c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x79c4>
10141794c: f9497fe1    	ldr	x1, [sp, #0x12f8]
101417950: f240f83f    	tst	x1, #0x7fffffffffffffff
101417954: 54000940    	b.eq	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417958: f94983e0    	ldr	x0, [sp, #0x1300]
10141795c: 52800022    	mov	w2, #0x1                ; =1
101417960: 97da1b5f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417964: f9404be0    	ldr	x0, [sp, #0x90]
101417968: 941ac71b    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10141796c: f9004be0    	str	x0, [sp, #0x90]
101417970: 912783e0    	add	x0, sp, #0x9e0
101417974: 97db9759    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101417978: 14000003    	b	0x101417984 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d1c>
10141797c: 14000009    	b	0x1014179a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d38>
101417980: f9004be0    	str	x0, [sp, #0x90]
101417984: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101417988: 91094000    	add	x0, x0, #0x250
10141798c: 97d4659f    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417990: 910303e0    	add	x0, sp, #0xc0
101417994: 9400f934    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417998: b5000135    	cbnz	x21, 0x1014179bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d54>
10141799c: 14000038    	b	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
1014179a0: f9004be0    	str	x0, [sp, #0x90]
1014179a4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014179a8: 91094000    	add	x0, x0, #0x250
1014179ac: 97d4c42c    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
1014179b0: 910303e0    	add	x0, sp, #0xc0
1014179b4: 97d4ac56    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
1014179b8: b4000635    	cbz	x21, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
1014179bc: f9405fe0    	ldr	x0, [sp, #0xb8]
1014179c0: aa1503e1    	mov	x1, x21
1014179c4: 52800022    	mov	w2, #0x1                ; =1
1014179c8: 97da1b45    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014179cc: f9404be0    	ldr	x0, [sp, #0x90]
1014179d0: 941ac701    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014179d4: f9004be0    	str	x0, [sp, #0x90]
1014179d8: f94007e8    	ldr	x8, [sp, #0x8]
1014179dc: b40004c8    	cbz	x8, 0x101417a74 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e0c>
1014179e0: a94007e0    	ldp	x0, x1, [sp]
1014179e4: 52800022    	mov	w2, #0x1                ; =1
1014179e8: 97da1b3d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014179ec: 14000022    	b	0x101417a74 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e0c>
1014179f0: f9004be0    	str	x0, [sp, #0x90]
1014179f4: f90087fc    	str	x28, [sp, #0x108]
1014179f8: f944bbe1    	ldr	x1, [sp, #0x970]
1014179fc: b4000081    	cbz	x1, 0x101417a0c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7da4>
101417a00: f944bfe0    	ldr	x0, [sp, #0x978]
101417a04: 52800022    	mov	w2, #0x1                ; =1
101417a08: 97da1b35    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417a0c: f81703b5    	stur	x21, [x29, #-0x90]
101417a10: 910403e0    	add	x0, sp, #0x100
101417a14: 97d4657d    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417a18: d10283a0    	sub	x0, x29, #0xa0
101417a1c: 9400f912    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417a20: 1400000d    	b	0x101417a54 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7dec>
101417a24: f9004be0    	str	x0, [sp, #0x90]
101417a28: f904f7fb    	str	x27, [sp, #0x9e8]
101417a2c: b40000b3    	cbz	x19, 0x101417a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7dd8>
101417a30: aa1603e0    	mov	x0, x22
101417a34: aa1303e1    	mov	x1, x19
101417a38: 52800022    	mov	w2, #0x1                ; =1
101417a3c: 97da1b28    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417a40: aa1403e0    	mov	x0, x20
101417a44: aa1503e1    	mov	x1, x21
101417a48: 97d4c688    	bl	0x100949468 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x36440>
101417a4c: 912783e0    	add	x0, sp, #0x9e0
101417a50: 97d4656e    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417a54: f85283a1    	ldur	x1, [x29, #-0xd8]
101417a58: b4000121    	cbz	x1, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417a5c: f85303a0    	ldur	x0, [x29, #-0xd0]
101417a60: 52800022    	mov	w2, #0x1                ; =1
101417a64: 97da1b1e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417a68: f9404be0    	ldr	x0, [sp, #0x90]
101417a6c: 941ac6da    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417a70: f9004be0    	str	x0, [sp, #0x90]
101417a74: 910303e0    	add	x0, sp, #0xc0
101417a78: 9400f8fb    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417a7c: f9404be0    	ldr	x0, [sp, #0x90]
101417a80: 941ac6d5    	bl	0x101ac95d4 <_writev+0x101ac95d4>
