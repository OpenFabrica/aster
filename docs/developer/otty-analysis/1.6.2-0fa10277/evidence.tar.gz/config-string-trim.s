
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100913028 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E>:
10094c964: 8b010009    	add	x9, x0, x1
10094c968: d280000b    	mov	x11, #0x0               ; =0
10094c96c: b4000921    	cbz	x1, 0x10094ca90 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a68>
10094c970: d000a28c    	adrp	x12, 0x101d9e000 <__ZN10serde_core2de5impls79_$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$std..time..SystemTime$GT$11deserialize14check_overflow13NANOS_PER_SEC17hdc7a2dcd898dff25E+0xffe0>
10094c974: 91239d8c    	add	x12, x12, #0x8e7
10094c978: 5282d00d    	mov	w13, #0x1680            ; =5760
10094c97c: aa0003ea    	mov	x10, x0
10094c980: 1400000b    	b	0x10094c9ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39984>
10094c984: 910009ea    	add	x10, x15, #0x2
10094c988: 331a11d0    	bfi	w16, w14, #6, #5
10094c98c: aa1003ee    	mov	x14, x16
10094c990: cb0f014b    	sub	x11, x10, x15
10094c994: 8b08016b    	add	x11, x11, x8
10094c998: 510025cf    	sub	w15, w14, #0x9
10094c99c: 710015ff    	cmp	w15, #0x5
10094c9a0: 54000302    	b.hs	0x10094ca00 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x399d8>
10094c9a4: eb09015f    	cmp	x10, x9
10094c9a8: 540006a0    	b.eq	0x10094ca7c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a54>
10094c9ac: aa0a03ef    	mov	x15, x10
10094c9b0: aa0b03e8    	mov	x8, x11
10094c9b4: 38c0154b    	ldrsb	w11, [x10], #0x1
10094c9b8: 12001d6e    	and	w14, w11, #0xff
10094c9bc: 36fffeab    	tbz	w11, #0x1f, 0x10094c990 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39968>
10094c9c0: 394005ea    	ldrb	w10, [x15, #0x1]
10094c9c4: 12001550    	and	w16, w10, #0x3f
10094c9c8: 710381df    	cmp	w14, #0xe0
10094c9cc: 54fffdc3    	b.lo	0x10094c984 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3995c>
10094c9d0: 120011cb    	and	w11, w14, #0x1f
10094c9d4: 394009ea    	ldrb	w10, [x15, #0x2]
10094c9d8: 1200154a    	and	w10, w10, #0x3f
10094c9dc: 2a101950    	orr	w16, w10, w16, lsl #6
10094c9e0: 7103c1df    	cmp	w14, #0xf0
10094c9e4: 54000283    	b.lo	0x10094ca34 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a0c>
10094c9e8: 910011ea    	add	x10, x15, #0x4
10094c9ec: 39400dee    	ldrb	w14, [x15, #0x3]
10094c9f0: 120015ce    	and	w14, w14, #0x3f
10094c9f4: 2a1019ce    	orr	w14, w14, w16, lsl #6
10094c9f8: 330e096e    	bfi	w14, w11, #18, #3
10094c9fc: 17ffffe5    	b	0x10094c990 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39968>
10094ca00: 710081df    	cmp	w14, #0x20
10094ca04: 54fffd00    	b.eq	0x10094c9a4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3997c>
10094ca08: 710201df    	cmp	w14, #0x80
10094ca0c: 54000463    	b.lo	0x10094ca98 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a70>
10094ca10: 53087dcf    	lsr	w15, w14, #8
10094ca14: 71007dff    	cmp	w15, #0x1f
10094ca18: 5400014c    	b.gt	0x10094ca40 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a18>
10094ca1c: 3400020f    	cbz	w15, 0x10094ca5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a34>
10094ca20: 710059ff    	cmp	w15, #0x16
10094ca24: 540003a1    	b.ne	0x10094ca98 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a70>
10094ca28: 6b0d01df    	cmp	w14, w13
10094ca2c: 54fffbc0    	b.eq	0x10094c9a4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3997c>
10094ca30: 1400001a    	b	0x10094ca98 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a70>
10094ca34: 91000dea    	add	x10, x15, #0x3
10094ca38: 2a0b320e    	orr	w14, w16, w11, lsl #12
10094ca3c: 17ffffd5    	b	0x10094c990 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39968>
10094ca40: 710081ff    	cmp	w15, #0x20
10094ca44: 54000140    	b.eq	0x10094ca6c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a44>
10094ca48: 7100c1ff    	cmp	w15, #0x30
10094ca4c: 54000261    	b.ne	0x10094ca98 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a70>
10094ca50: 71400ddf    	cmp	w14, #0x3, lsl #12      ; =0x3000
10094ca54: 54fffa80    	b.eq	0x10094c9a4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3997c>
10094ca58: 14000010    	b	0x10094ca98 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a70>
10094ca5c: 92401dce    	and	x14, x14, #0xff
10094ca60: 386e698e    	ldrb	w14, [x12, x14]
10094ca64: 3707fa0e    	tbnz	w14, #0x0, 0x10094c9a4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3997c>
10094ca68: 1400000c    	b	0x10094ca98 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a70>
10094ca6c: 92401dce    	and	x14, x14, #0xff
10094ca70: 386e698e    	ldrb	w14, [x12, x14]
10094ca74: 370ff98e    	tbnz	w14, #0x1, 0x10094c9a4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3997c>
10094ca78: 14000008    	b	0x10094ca98 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a70>
10094ca7c: d2800008    	mov	x8, #0x0                ; =0
10094ca80: d280000b    	mov	x11, #0x0               ; =0
10094ca84: cb080161    	sub	x1, x11, x8
10094ca88: 8b080000    	add	x0, x0, x8
10094ca8c: d65f03c0    	ret
10094ca90: d2800008    	mov	x8, #0x0                ; =0
10094ca94: aa0003ea    	mov	x10, x0
10094ca98: eb09015f    	cmp	x10, x9
10094ca9c: 54ffff40    	b.eq	0x10094ca84 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a5c>
10094caa0: d000a28c    	adrp	x12, 0x101d9e000 <__ZN10serde_core2de5impls79_$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$std..time..SystemTime$GT$11deserialize14check_overflow13NANOS_PER_SEC17hdc7a2dcd898dff25E+0xffe0>
10094caa4: 91239d8c    	add	x12, x12, #0x8e7
10094caa8: 5282d00d    	mov	w13, #0x1680            ; =5760
10094caac: 14000009    	b	0x10094cad0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39aa8>
10094cab0: 12001210    	and	w16, w16, #0x1f
10094cab4: 120015ef    	and	w15, w15, #0x3f
10094cab8: 2a1019ef    	orr	w15, w15, w16, lsl #6
10094cabc: 510025f0    	sub	w16, w15, #0x9
10094cac0: 7100161f    	cmp	w16, #0x5
10094cac4: 54000282    	b.hs	0x10094cb14 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39aec>
10094cac8: eb09015f    	cmp	x10, x9
10094cacc: 54fffdc0    	b.eq	0x10094ca84 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a5c>
10094cad0: aa0903ee    	mov	x14, x9
10094cad4: 38dffd2f    	ldrsb	w15, [x9, #-0x1]!
10094cad8: 36ffff2f    	tbz	w15, #0x1f, 0x10094cabc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a94>
10094cadc: aa0e03e9    	mov	x9, x14
10094cae0: 38dfed30    	ldrsb	w16, [x9, #-0x2]!
10094cae4: 3101021f    	cmn	w16, #0x40
10094cae8: 54fffe4a    	b.ge	0x10094cab0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a88>
10094caec: aa0e03e9    	mov	x9, x14
10094caf0: 38dfdd31    	ldrsb	w17, [x9, #-0x3]!
10094caf4: 3101023f    	cmn	w17, #0x40
10094caf8: 5400028a    	b.ge	0x10094cb48 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b20>
10094cafc: 12001e31    	and	w17, w17, #0xff
10094cb00: aa0e03e9    	mov	x9, x14
10094cb04: 385fcd21    	ldrb	w1, [x9, #-0x4]!
10094cb08: 12001631    	and	w17, w17, #0x3f
10094cb0c: 331a0831    	bfi	w17, w1, #6, #3
10094cb10: 1400000f    	b	0x10094cb4c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b24>
10094cb14: 710081ff    	cmp	w15, #0x20
10094cb18: 54fffd80    	b.eq	0x10094cac8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39aa0>
10094cb1c: 710201ff    	cmp	w15, #0x80
10094cb20: 540003a3    	b.lo	0x10094cb94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b6c>
10094cb24: 53087df0    	lsr	w16, w15, #8
10094cb28: 71007e1f    	cmp	w16, #0x1f
10094cb2c: 5400018c    	b.gt	0x10094cb5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b34>
10094cb30: 34000250    	cbz	w16, 0x10094cb78 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b50>
10094cb34: 71005a1f    	cmp	w16, #0x16
10094cb38: 540002e1    	b.ne	0x10094cb94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b6c>
10094cb3c: 6b0d01ff    	cmp	w15, w13
10094cb40: 54fffc40    	b.eq	0x10094cac8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39aa0>
10094cb44: 14000014    	b	0x10094cb94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b6c>
10094cb48: 12000e31    	and	w17, w17, #0xf
10094cb4c: 12001e10    	and	w16, w16, #0xff
10094cb50: 12001610    	and	w16, w16, #0x3f
10094cb54: 2a111a10    	orr	w16, w16, w17, lsl #6
10094cb58: 17ffffd7    	b	0x10094cab4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39a8c>
10094cb5c: 7100821f    	cmp	w16, #0x20
10094cb60: 54000140    	b.eq	0x10094cb88 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b60>
10094cb64: 7100c21f    	cmp	w16, #0x30
10094cb68: 54000161    	b.ne	0x10094cb94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b6c>
10094cb6c: 71400dff    	cmp	w15, #0x3, lsl #12      ; =0x3000
10094cb70: 54fffac0    	b.eq	0x10094cac8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39aa0>
10094cb74: 14000008    	b	0x10094cb94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b6c>
10094cb78: 92401def    	and	x15, x15, #0xff
10094cb7c: 386f698f    	ldrb	w15, [x12, x15]
10094cb80: 3707fa4f    	tbnz	w15, #0x0, 0x10094cac8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39aa0>
10094cb84: 14000004    	b	0x10094cb94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b6c>
10094cb88: 92401def    	and	x15, x15, #0xff
10094cb8c: 386f698f    	ldrb	w15, [x12, x15]
10094cb90: 370ff9cf    	tbnz	w15, #0x1, 0x10094cac8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39aa0>
10094cb94: cb0a0169    	sub	x9, x11, x10
10094cb98: 8b0e012b    	add	x11, x9, x14
10094cb9c: cb080161    	sub	x1, x11, x8
10094cba0: 8b080000    	add	x0, x0, x8
10094cba4: d65f03c0    	ret
