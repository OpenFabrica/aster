10065ad78:     	stp	x29, x30, [sp, #-0x10]!
10065ad7c:     	mov	x29, sp
10065ad80:     	ldr	x8, [x20]
10065ad84:     	ldr	x8, [x8, #0x540]
10065ad88:     	blr	x8
10065ad8c:     	and	w8, w0, #0xff
10065ad90:     	cmp	w8, #0xc
10065ad94:     	b.ne	0x10065ada8
10065ad98:     	mov	x0, #0x0                ; =0
10065ad9c:     	mov	x1, #0x0                ; =0
10065ada0:     	ldp	x29, x30, [sp], #0x10
10065ada4:     	ret
10065ada8:     	ldr	x8, [x20]
10065adac:     	ldr	x8, [x8, #0x528]
10065adb0:     	blr	x8
10065adb4:     	ldp	x29, x30, [sp], #0x10
10065adb8:     	ret
10065adbc:     	ldr	x8, [x20]
10065adc0:     	ldr	x2, [x8, #0x530]
10065adc4:     	br	x2
10065adc8:     	stp	x20, x19, [sp, #-0x20]!
10065adcc:     	stp	x29, x30, [sp, #0x10]
10065add0:     	add	x29, sp, #0x10
10065add4:     	mov	x19, x0
10065add8:     	str	x20, [x0, #0x10]
10065addc:     	ldr	x8, [x20]
