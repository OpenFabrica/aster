
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010146d390 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E>:
10146fab4: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10146fab8: a90167fa    	stp	x26, x25, [sp, #0x10]
10146fabc: a9025ff8    	stp	x24, x23, [sp, #0x20]
10146fac0: a90357f6    	stp	x22, x21, [sp, #0x30]
10146fac4: a9044ff4    	stp	x20, x19, [sp, #0x40]
10146fac8: a9057bfd    	stp	x29, x30, [sp, #0x50]
10146facc: 910143fd    	add	x29, sp, #0x50
10146fad0: d10f83ff    	sub	sp, sp, #0x3e0
10146fad4: aa0103f4    	mov	x20, x1
10146fad8: aa0003f3    	mov	x19, x0
10146fadc: a9422029    	ldp	x9, x8, [x1, #0x20]
10146fae0: eb09011f    	cmp	x8, x9
10146fae4: 540005e2    	b.hs	0x10146fba0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2810>
10146fae8: f9400e8a    	ldr	x10, [x20, #0x18]
10146faec: 5280002b    	mov	w11, #0x1               ; =1
10146faf0: d284c00c    	mov	x12, #0x2600            ; =9728
10146faf4: f2c0002c    	movk	x12, #0x1, lsl #32
10146faf8: 3868694d    	ldrb	w13, [x10, x8]
10146fafc: 710081bf    	cmp	w13, #0x20
10146fb00: 9acd216e    	lsl	x14, x11, x13
10146fb04: 8a0c01ce    	and	x14, x14, x12
10146fb08: fa4099c4    	ccmp	x14, #0x0, #0x4, ls
10146fb0c: 540000c0    	b.eq	0x10146fb24 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2794>
10146fb10: 91000508    	add	x8, x8, #0x1
10146fb14: f9001688    	str	x8, [x20, #0x28]
10146fb18: eb08013f    	cmp	x9, x8
10146fb1c: 54fffee1    	b.ne	0x10146faf8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2768>
10146fb20: 14000031    	b	0x10146fbe4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2854>
10146fb24: 7101b9bf    	cmp	w13, #0x6e
10146fb28: 540003c1    	b.ne	0x10146fba0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2810>
10146fb2c: 9100050b    	add	x11, x8, #0x1
10146fb30: f900168b    	str	x11, [x20, #0x28]
10146fb34: eb09017f    	cmp	x11, x9
10146fb38: 9a889529    	csinc	x9, x9, x8, ls
10146fb3c: 54007682    	b.hs	0x101470a0c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x367c>
10146fb40: 8b08014b    	add	x11, x10, x8
10146fb44: 3940056c    	ldrb	w12, [x11, #0x1]
10146fb48: 9100090b    	add	x11, x8, #0x2
10146fb4c: f900168b    	str	x11, [x20, #0x28]
10146fb50: 7101d59f    	cmp	w12, #0x75
10146fb54: 54007c01    	b.ne	0x101470ad4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3744>
10146fb58: eb09017f    	cmp	x11, x9
10146fb5c: 54007580    	b.eq	0x101470a0c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x367c>
10146fb60: 8b08014b    	add	x11, x10, x8
10146fb64: 3940096c    	ldrb	w12, [x11, #0x2]
10146fb68: 91000d0b    	add	x11, x8, #0x3
10146fb6c: f900168b    	str	x11, [x20, #0x28]
10146fb70: 7101b19f    	cmp	w12, #0x6c
10146fb74: 54007b01    	b.ne	0x101470ad4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3744>
10146fb78: eb09017f    	cmp	x11, x9
10146fb7c: 54007480    	b.eq	0x101470a0c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x367c>
10146fb80: 8b080149    	add	x9, x10, x8
10146fb84: 39400d29    	ldrb	w9, [x9, #0x3]
10146fb88: 91001108    	add	x8, x8, #0x4
10146fb8c: f9001688    	str	x8, [x20, #0x28]
10146fb90: 7101b13f    	cmp	w9, #0x6c
10146fb94: 54007a01    	b.ne	0x101470ad4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3744>
10146fb98: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10146fb9c: 140003bc    	b	0x101470a8c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x36fc>
10146fba0: eb09011f    	cmp	x8, x9
10146fba4: 54000202    	b.hs	0x10146fbe4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2854>
10146fba8: 9101a3f6    	add	x22, sp, #0x68
10146fbac: f9400e8a    	ldr	x10, [x20, #0x18]
10146fbb0: 5280002b    	mov	w11, #0x1               ; =1
10146fbb4: d284c00c    	mov	x12, #0x2600            ; =9728
10146fbb8: f2c0002c    	movk	x12, #0x1, lsl #32
10146fbbc: 3868694d    	ldrb	w13, [x10, x8]
10146fbc0: 710081bf    	cmp	w13, #0x20
10146fbc4: 9acd216e    	lsl	x14, x11, x13
10146fbc8: 8a0c01ce    	and	x14, x14, x12
10146fbcc: fa4099c4    	ccmp	x14, #0x0, #0x4, ls
10146fbd0: 54000160    	b.eq	0x10146fbfc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x286c>
10146fbd4: 91000508    	add	x8, x8, #0x1
10146fbd8: f9001688    	str	x8, [x20, #0x28]
10146fbdc: eb08013f    	cmp	x9, x8
10146fbe0: 54fffee1    	b.ne	0x10146fbbc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x282c>
10146fbe4: 528000a8    	mov	w8, #0x5                ; =5
10146fbe8: f900cbe8    	str	x8, [sp, #0x190]
10146fbec: 910643e1    	add	x1, sp, #0x190
10146fbf0: aa1403e0    	mov	x0, x20
10146fbf4: 94187d4d    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
10146fbf8: 140003a3    	b	0x101470a84 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x36f4>
10146fbfc: 71016dbf    	cmp	w13, #0x5b
10146fc00: 54007581    	b.ne	0x101470ab0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3720>
10146fc04: 3940c289    	ldrb	w9, [x20, #0x30]
10146fc08: 51000529    	sub	w9, w9, #0x1
10146fc0c: 3900c289    	strb	w9, [x20, #0x30]
10146fc10: 72001d3f    	tst	w9, #0xff
10146fc14: 540075c0    	b.eq	0x101470acc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x373c>
10146fc18: d280001b    	mov	x27, #0x0               ; =0
10146fc1c: 91000508    	add	x8, x8, #0x1
10146fc20: f9001688    	str	x8, [x20, #0x28]
10146fc24: 52800037    	mov	w23, #0x1               ; =1
10146fc28: 52800108    	mov	w8, #0x8                ; =8
10146fc2c: f90023f4    	str	x20, [sp, #0x40]
10146fc30: 390123f7    	strb	w23, [sp, #0x48]
10146fc34: d284c015    	mov	x21, #0x2600            ; =9728
10146fc38: f2c00035    	movk	x21, #0x1, lsl #32
10146fc3c: a90523ff    	stp	xzr, x8, [sp, #0x50]
10146fc40: f90033ff    	str	xzr, [sp, #0x60]
10146fc44: 52800119    	mov	w25, #0x8               ; =8
10146fc48: 910643e0    	add	x0, sp, #0x190
10146fc4c: 910103e1    	add	x1, sp, #0x40
10146fc50: 97fff450    	bl	0x10146cd90 <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x5a4>
10146fc54: 394643e8    	ldrb	w8, [sp, #0x190]
10146fc58: 7100051f    	cmp	w8, #0x1
10146fc5c: 54006e40    	b.eq	0x101470a24 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3694>
10146fc60: 394647e8    	ldrb	w8, [sp, #0x191]
10146fc64: 7100051f    	cmp	w8, #0x1
10146fc68: 54006e61    	b.ne	0x101470a34 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x36a4>
10146fc6c: f94023f8    	ldr	x24, [sp, #0x40]
10146fc70: a9422309    	ldp	x9, x8, [x24, #0x20]
10146fc74: eb09011f    	cmp	x8, x9
10146fc78: 54006542    	b.hs	0x101470920 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3590>
10146fc7c: f9400f0a    	ldr	x10, [x24, #0x18]
10146fc80: 3868694b    	ldrb	w11, [x10, x8]
10146fc84: 7100817f    	cmp	w11, #0x20
10146fc88: 9acb22ec    	lsl	x12, x23, x11
10146fc8c: 8a15018c    	and	x12, x12, x21
10146fc90: fa409984    	ccmp	x12, #0x0, #0x4, ls
10146fc94: 540000c0    	b.eq	0x10146fcac <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x291c>
10146fc98: 91000508    	add	x8, x8, #0x1
10146fc9c: f9001708    	str	x8, [x24, #0x28]
10146fca0: eb08013f    	cmp	x9, x8
10146fca4: 54fffee1    	b.ne	0x10146fc80 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x28f0>
10146fca8: 1400031e    	b	0x101470920 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3590>
10146fcac: 71016d7f    	cmp	w11, #0x5b
10146fcb0: 54001780    	b.eq	0x10146ffa0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2c10>
10146fcb4: 7101ed7f    	cmp	w11, #0x7b
10146fcb8: 54007121    	b.ne	0x101470adc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x374c>
10146fcbc: 3940c309    	ldrb	w9, [x24, #0x30]
10146fcc0: 51000529    	sub	w9, w9, #0x1
10146fcc4: 3900c309    	strb	w9, [x24, #0x30]
10146fcc8: 72001d3f    	tst	w9, #0xff
10146fccc: 540072e0    	b.eq	0x101470b28 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3798>
10146fcd0: 91000508    	add	x8, x8, #0x1
10146fcd4: f9001708    	str	x8, [x24, #0x28]
10146fcd8: f90197f8    	str	x24, [sp, #0x328]
10146fcdc: 390cc3f7    	strb	w23, [sp, #0x330]
10146fce0: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10146fce4: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10146fce8: a90327e8    	stp	x8, x9, [sp, #0x30]
10146fcec: 528000a8    	mov	w8, #0x5                ; =5
10146fcf0: f90013e8    	str	x8, [sp, #0x20]
10146fcf4: 528000a8    	mov	w8, #0x5                ; =5
10146fcf8: f90017e8    	str	x8, [sp, #0x28]
10146fcfc: 910643e0    	add	x0, sp, #0x190
10146fd00: 910ca3e1    	add	x1, sp, #0x328
10146fd04: 97fff370    	bl	0x10146cac4 <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x2d8>
10146fd08: 394643e8    	ldrb	w8, [sp, #0x190]
10146fd0c: 7100051f    	cmp	w8, #0x1
10146fd10: 54001920    	b.eq	0x101470034 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2ca4>
10146fd14: 394647e8    	ldrb	w8, [sp, #0x191]
10146fd18: 7100051f    	cmp	w8, #0x1
10146fd1c: 54001da1    	b.ne	0x1014700d0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2d40>
10146fd20: f94197f9    	ldr	x25, [sp, #0x328]
10146fd24: f9401728    	ldr	x8, [x25, #0x28]
10146fd28: 91000508    	add	x8, x8, #0x1
10146fd2c: f9001728    	str	x8, [x25, #0x28]
10146fd30: f9000b3f    	str	xzr, [x25, #0x10]
10146fd34: 910643e8    	add	x8, sp, #0x190
10146fd38: 91006320    	add	x0, x25, #0x18
10146fd3c: aa1903e1    	mov	x1, x25
10146fd40: 94088415    	bl	0x101690d94 <__ZN68_$LT$serde_json..read..StrRead$u20$as$u20$serde_json..read..Read$GT$9parse_str17h79c5c49f51148a19E>
10146fd44: a95973e9    	ldp	x9, x28, [sp, #0x190]
10146fd48: f100093f    	cmp	x9, #0x2
10146fd4c: 54001640    	b.eq	0x101470014 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2c84>
10146fd50: f940d3e8    	ldr	x8, [sp, #0x1a0]
10146fd54: f100111f    	cmp	x8, #0x4
10146fd58: 54000800    	b.eq	0x10146fe58 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2ac8>
10146fd5c: f1002d1f    	cmp	x8, #0xb
10146fd60: 540003c0    	b.eq	0x10146fdd8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2a48>
10146fd64: f100151f    	cmp	x8, #0x5
10146fd68: 54000821    	b.ne	0x10146fe6c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2adc>
10146fd6c: b9400388    	ldr	w8, [x28]
10146fd70: 39401389    	ldrb	w9, [x28, #0x4]
10146fd74: 528c2dca    	mov	w10, #0x616e            ; =24942
10146fd78: 72acadaa    	movk	w10, #0x656d, lsl #16
10146fd7c: 6b0a011f    	cmp	w8, w10
10146fd80: 52800e68    	mov	w8, #0x73               ; =115
10146fd84: 7a480120    	ccmp	w9, w8, #0x0, eq
10146fd88: 54000721    	b.ne	0x10146fe6c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2adc>
10146fd8c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10146fd90: f9401fe9    	ldr	x9, [sp, #0x38]
10146fd94: eb08013f    	cmp	x9, x8
10146fd98: 540050a1    	b.ne	0x1014707ac <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x341c>
10146fd9c: a9422329    	ldp	x9, x8, [x25, #0x20]
10146fda0: eb09011f    	cmp	x8, x9
10146fda4: 540045c2    	b.hs	0x10147065c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x32cc>
10146fda8: f841832a    	ldur	x10, [x25, #0x18]
10146fdac: 3868694b    	ldrb	w11, [x10, x8]
10146fdb0: 7100e97f    	cmp	w11, #0x3a
10146fdb4: 54005988    	b.hi	0x1014708e4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3554>
10146fdb8: 9acb22ec    	lsl	x12, x23, x11
10146fdbc: ea15019f    	tst	x12, x21
10146fdc0: 54000d20    	b.eq	0x10146ff64 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2bd4>
10146fdc4: 91000508    	add	x8, x8, #0x1
10146fdc8: f9001728    	str	x8, [x25, #0x28]
10146fdcc: eb08013f    	cmp	x9, x8
10146fdd0: 54fffee1    	b.ne	0x10146fdac <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2a1c>
10146fdd4: 14000222    	b	0x10147065c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x32cc>
10146fdd8: f9400388    	ldr	x8, [x28]
10146fddc: f8403389    	ldur	x9, [x28, #0x3]
10146fde0: d28cac8a    	mov	x10, #0x6564            ; =25956
10146fde4: f2ac6e6a    	movk	x10, #0x6373, lsl #16
10146fde8: f2cd2e4a    	movk	x10, #0x6972, lsl #32
10146fdec: f2ee8e0a    	movk	x10, #0x7470, lsl #48
10146fdf0: eb0a011f    	cmp	x8, x10
10146fdf4: d28e4c68    	mov	x8, #0x7263             ; =29283
10146fdf8: f2ae0d28    	movk	x8, #0x7069, lsl #16
10146fdfc: f2cd2e88    	movk	x8, #0x6974, lsl #32
10146fe00: f2edcde8    	movk	x8, #0x6e6f, lsl #48
10146fe04: fa480120    	ccmp	x9, x8, #0x0, eq
10146fe08: 54000321    	b.ne	0x10146fe6c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2adc>
10146fe0c: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10146fe10: f9401be9    	ldr	x9, [sp, #0x30]
10146fe14: eb08013f    	cmp	x9, x8
10146fe18: 54004a01    	b.ne	0x101470758 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x33c8>
10146fe1c: a9422329    	ldp	x9, x8, [x25, #0x20]
10146fe20: eb09011f    	cmp	x8, x9
10146fe24: 54004402    	b.hs	0x1014706a4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3314>
10146fe28: f841832a    	ldur	x10, [x25, #0x18]
10146fe2c: 3868694b    	ldrb	w11, [x10, x8]
10146fe30: 7100e97f    	cmp	w11, #0x3a
10146fe34: 540051c8    	b.hi	0x10147086c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x34dc>
10146fe38: 9acb22ec    	lsl	x12, x23, x11
10146fe3c: ea15019f    	tst	x12, x21
10146fe40: 54000440    	b.eq	0x10146fec8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2b38>
10146fe44: 91000508    	add	x8, x8, #0x1
10146fe48: f9001728    	str	x8, [x25, #0x28]
10146fe4c: eb08013f    	cmp	x9, x8
10146fe50: 54fffee1    	b.ne	0x10146fe2c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2a9c>
10146fe54: 14000214    	b	0x1014706a4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3314>
10146fe58: b9400388    	ldr	w8, [x28]
10146fe5c: 528e4c29    	mov	w9, #0x7261             ; =29281
10146fe60: 72ae6ce9    	movk	w9, #0x7367, lsl #16
10146fe64: 6b09011f    	cmp	w8, w9
10146fe68: 540000c0    	b.eq	0x10146fe80 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2af0>
10146fe6c: aa1903e0    	mov	x0, x25
10146fe70: 97fe4ca9    	bl	0x101403114 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x20c8>
10146fe74: aa0003fc    	mov	x28, x0
10146fe78: b4fff420    	cbz	x0, 0x10146fcfc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x296c>
10146fe7c: 14000066    	b	0x101470014 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2c84>
10146fe80: f94017e8    	ldr	x8, [sp, #0x28]
10146fe84: f100151f    	cmp	x8, #0x5
10146fe88: 54004be1    	b.ne	0x101470804 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3474>
10146fe8c: a9422329    	ldp	x9, x8, [x25, #0x20]
10146fe90: eb09011f    	cmp	x8, x9
10146fe94: 54003c42    	b.hs	0x10147061c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x328c>
10146fe98: f841832a    	ldur	x10, [x25, #0x18]
10146fe9c: 3868694b    	ldrb	w11, [x10, x8]
10146fea0: 7100e97f    	cmp	w11, #0x3a
10146fea4: 54005028    	b.hi	0x1014708a8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3518>
10146fea8: 9acb22ec    	lsl	x12, x23, x11
10146feac: ea15019f    	tst	x12, x21
10146feb0: 540002a0    	b.eq	0x10146ff04 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2b74>
10146feb4: 91000508    	add	x8, x8, #0x1
10146feb8: f9001728    	str	x8, [x25, #0x28]
10146febc: eb08013f    	cmp	x9, x8
10146fec0: 54fffee1    	b.ne	0x10146fe9c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2b0c>
10146fec4: 140001d6    	b	0x10147061c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x328c>
10146fec8: f100e97f    	cmp	x11, #0x3a
10146fecc: 54004d01    	b.ne	0x10147086c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x34dc>
10146fed0: 91000508    	add	x8, x8, #0x1
10146fed4: f9001728    	str	x8, [x25, #0x28]
10146fed8: d10203a0    	sub	x0, x29, #0x80
10146fedc: aa1903e1    	mov	x1, x25
10146fee0: 97fffe9d    	bl	0x10146f954 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x25c4>
10146fee4: f85803a9    	ldur	x9, [x29, #-0x80]
10146fee8: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10146feec: f9001be9    	str	x9, [sp, #0x30]
10146fef0: eb08013f    	cmp	x9, x8
10146fef4: 540040e0    	b.eq	0x101470710 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3380>
10146fef8: a978a3a9    	ldp	x9, x8, [x29, #-0x78]
10146fefc: a90027e8    	stp	x8, x9, [sp]
10146ff00: 17ffff7f    	b	0x10146fcfc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x296c>
10146ff04: f100e97f    	cmp	x11, #0x3a
10146ff08: 54004d01    	b.ne	0x1014708a8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3518>
10146ff0c: 91000508    	add	x8, x8, #0x1
10146ff10: f9001728    	str	x8, [x25, #0x28]
10146ff14: 910643e0    	add	x0, sp, #0x190
10146ff18: aa1903e1    	mov	x1, x25
10146ff1c: 97fff51e    	bl	0x10146d394 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x4>
10146ff20: f940cbeb    	ldr	x11, [sp, #0x190]
10146ff24: f100157f    	cmp	x11, #0x5
10146ff28: 54004060    	b.eq	0x101470734 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x33a4>
10146ff2c: f940cfe8    	ldr	x8, [sp, #0x198]
10146ff30: f9000be8    	str	x8, [sp, #0x10]
10146ff34: 910643e9    	add	x9, sp, #0x190
10146ff38: ad418520    	ldp	q0, q1, [x9, #0x30]
10146ff3c: 9108e3ea    	add	x10, sp, #0x238
10146ff40: ad018540    	stp	q0, q1, [x10, #0x30]
10146ff44: 3cc50120    	ldur	q0, [x9, #0x50]
10146ff48: 3c850140    	stur	q0, [x10, #0x50]
10146ff4c: f8460128    	ldur	x8, [x9, #0x60]
10146ff50: f8060148    	stur	x8, [x10, #0x60]
10146ff54: ad408520    	ldp	q0, q1, [x9, #0x10]
10146ff58: a9022feb    	stp	x11, x11, [sp, #0x20]
10146ff5c: ad008540    	stp	q0, q1, [x10, #0x10]
10146ff60: 17ffff67    	b	0x10146fcfc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x296c>
10146ff64: f100e97f    	cmp	x11, #0x3a
10146ff68: 54004be1    	b.ne	0x1014708e4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3554>
10146ff6c: 91000508    	add	x8, x8, #0x1
10146ff70: f9001728    	str	x8, [x25, #0x28]
10146ff74: d10203a0    	sub	x0, x29, #0x80
10146ff78: aa1903e1    	mov	x1, x25
10146ff7c: 97fe4a96    	bl	0x1014029d4 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x1988>
10146ff80: f85803a8    	ldur	x8, [x29, #-0x80]
10146ff84: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10146ff88: eb09011f    	cmp	x8, x9
10146ff8c: 54003b00    	b.eq	0x1014706ec <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x335c>
10146ff90: a978eba9    	ldp	x9, x26, [x29, #-0x78]
10146ff94: f9000fe9    	str	x9, [sp, #0x18]
10146ff98: f9001fe8    	str	x8, [sp, #0x38]
10146ff9c: 17ffff58    	b	0x10146fcfc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x296c>
10146ffa0: 3940c309    	ldrb	w9, [x24, #0x30]
10146ffa4: 51000529    	sub	w9, w9, #0x1
10146ffa8: 3900c309    	strb	w9, [x24, #0x30]
10146ffac: 72001d3f    	tst	w9, #0xff
10146ffb0: 54005b00    	b.eq	0x101470b10 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3780>
10146ffb4: 91000508    	add	x8, x8, #0x1
10146ffb8: f9001708    	str	x8, [x24, #0x28]
10146ffbc: f81083b8    	stur	x24, [x29, #-0xf8]
10146ffc0: 381103b7    	sturb	w23, [x29, #-0xf0]
10146ffc4: 910643e0    	add	x0, sp, #0x190
10146ffc8: d103e3a1    	sub	x1, x29, #0xf8
10146ffcc: 97fff371    	bl	0x10146cd90 <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x5a4>
10146ffd0: 394643e8    	ldrb	w8, [sp, #0x190]
10146ffd4: 7100051f    	cmp	w8, #0x1
10146ffd8: 54000061    	b.ne	0x10146ffe4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2c54>
10146ffdc: f940cffa    	ldr	x26, [sp, #0x198]
10146ffe0: 14000117    	b	0x10147043c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x30ac>
10146ffe4: 394647e8    	ldrb	w8, [sp, #0x191]
10146ffe8: 7100051f    	cmp	w8, #0x1
10146ffec: 54000681    	b.ne	0x1014700bc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2d2c>
10146fff0: f85083a1    	ldur	x1, [x29, #-0xf8]
10146fff4: 910643e0    	add	x0, sp, #0x190
10146fff8: 97fe4a77    	bl	0x1014029d4 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x1988>
10146fffc: b24107fc    	mov	x28, #-0x7fffffffffffffff ; =-9223372036854775807
101470000: a9596be9    	ldp	x9, x26, [sp, #0x190]
101470004: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101470008: eb08013f    	cmp	x9, x8
10147000c: 54000861    	b.ne	0x101470118 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2d88>
101470010: 1400010b    	b	0x10147043c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x30ac>
101470014: f94013e8    	ldr	x8, [sp, #0x20]
101470018: f9011fe8    	str	x8, [sp, #0x238]
10147001c: a94123ea    	ldp	x10, x8, [sp, #0x10]
101470020: f90123ea    	str	x10, [sp, #0x240]
101470024: f9401fe9    	ldr	x9, [sp, #0x38]
101470028: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
10147002c: f81183ba    	stur	x26, [x29, #-0xe8]
101470030: 14000009    	b	0x101470054 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2cc4>
101470034: f94013e8    	ldr	x8, [sp, #0x20]
101470038: f9011fe8    	str	x8, [sp, #0x238]
10147003c: a94123ea    	ldp	x10, x8, [sp, #0x10]
101470040: f90123ea    	str	x10, [sp, #0x240]
101470044: f9401fe9    	ldr	x9, [sp, #0x38]
101470048: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
10147004c: f81183ba    	stur	x26, [x29, #-0xe8]
101470050: f940cffc    	ldr	x28, [sp, #0x198]
101470054: f94017e8    	ldr	x8, [sp, #0x28]
101470058: f100151f    	cmp	x8, #0x5
10147005c: 54000f00    	b.eq	0x10147023c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2eac>
101470060: f100111f    	cmp	x8, #0x4
101470064: 54000ec0    	b.eq	0x10147023c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2eac>
101470068: f1000d1f    	cmp	x8, #0x3
10147006c: 54000e41    	b.ne	0x101470234 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2ea4>
101470070: f94127e8    	ldr	x8, [sp, #0x248]
101470074: f90017e8    	str	x8, [sp, #0x28]
101470078: f9412bf6    	ldr	x22, [sp, #0x250]
10147007c: b40000f6    	cbz	x22, 0x101470098 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2d08>
101470080: f94017f9    	ldr	x25, [sp, #0x28]
101470084: aa1903e0    	mov	x0, x25
101470088: 97ff8edc    	bl	0x101453bf8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6770>
10147008c: 9101a339    	add	x25, x25, #0x68
101470090: f10006d6    	subs	x22, x22, #0x1
101470094: 54ffff81    	b.ne	0x101470084 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2cf4>
101470098: 9101a3f6    	add	x22, sp, #0x68
10147009c: f9400be9    	ldr	x9, [sp, #0x10]
1014700a0: b4000ce9    	cbz	x9, 0x10147023c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2eac>
1014700a4: 52800d08    	mov	w8, #0x68               ; =104
1014700a8: 9b087d21    	mul	x1, x9, x8
1014700ac: f94017e0    	ldr	x0, [sp, #0x28]
1014700b0: 52800102    	mov	w2, #0x8                ; =8
1014700b4: 97d8b98a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014700b8: 14000061    	b	0x10147023c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2eac>
1014700bc: b24107fc    	mov	x28, #-0x7fffffffffffffff ; =-9223372036854775807
1014700c0: d2800009    	mov	x9, #0x0                ; =0
1014700c4: d2800019    	mov	x25, #0x0               ; =0
1014700c8: 5280011a    	mov	w26, #0x8               ; =8
1014700cc: 14000014    	b	0x10147011c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2d8c>
1014700d0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014700d4: a94327ed    	ldp	x13, x9, [sp, #0x30]
1014700d8: eb08013f    	cmp	x9, x8
1014700dc: 9a8903eb    	csel	x11, xzr, x9, eq
1014700e0: 52800108    	mov	w8, #0x8                ; =8
1014700e4: f9400fe9    	ldr	x9, [sp, #0x18]
1014700e8: 9a89010a    	csel	x10, x8, x9, eq
1014700ec: 9a9a03e9    	csel	x9, xzr, x26, eq
1014700f0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014700f4: b24107ec    	mov	x12, #-0x7fffffffffffffff ; =-9223372036854775807
1014700f8: eb0c01bf    	cmp	x13, x12
1014700fc: 9a8d0108    	csel	x8, x8, x13, eq
101470100: f94017ee    	ldr	x14, [sp, #0x28]
101470104: f10015df    	cmp	x14, #0x5
101470108: 54000581    	b.ne	0x1014701b8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2e28>
10147010c: 5280008e    	mov	w14, #0x4               ; =4
101470110: 9108e3f9    	add	x25, sp, #0x238
101470114: 14000032    	b	0x1014701dc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2e4c>
101470118: f940d3f9    	ldr	x25, [sp, #0x1a0]
10147011c: f9001be9    	str	x9, [sp, #0x30]
101470120: f9011fe9    	str	x9, [sp, #0x238]
101470124: f90123fa    	str	x26, [sp, #0x240]
101470128: f90127f9    	str	x25, [sp, #0x248]
10147012c: 910643e0    	add	x0, sp, #0x190
101470130: d103e3a1    	sub	x1, x29, #0xf8
101470134: 97fff317    	bl	0x10146cd90 <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x5a4>
101470138: 394643e8    	ldrb	w8, [sp, #0x190]
10147013c: 7100051f    	cmp	w8, #0x1
101470140: 540000a1    	b.ne	0x101470154 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2dc4>
101470144: f940cfe8    	ldr	x8, [sp, #0x198]
101470148: f9001fe8    	str	x8, [sp, #0x38]
10147014c: b50005f9    	cbnz	x25, 0x101470208 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2e78>
101470150: 140000b2    	b	0x101470418 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3088>
101470154: 394647e8    	ldrb	w8, [sp, #0x191]
101470158: 7100051f    	cmp	w8, #0x1
10147015c: 54000461    	b.ne	0x1014701e8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2e58>
101470160: f85083a1    	ldur	x1, [x29, #-0xf8]
101470164: 910643e0    	add	x0, sp, #0x190
101470168: 97fffdfb    	bl	0x10146f954 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x25c4>
10147016c: a95923e9    	ldp	x9, x8, [sp, #0x190]
101470170: f9001fe8    	str	x8, [sp, #0x38]
101470174: eb1c013f    	cmp	x9, x28
101470178: 54000460    	b.eq	0x101470204 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2e74>
10147017c: aa0903fc    	mov	x28, x9
101470180: f940d3e8    	ldr	x8, [sp, #0x1a0]
101470184: f90017e8    	str	x8, [sp, #0x28]
101470188: 910643e0    	add	x0, sp, #0x190
10147018c: d103e3a1    	sub	x1, x29, #0xf8
101470190: 97fff300    	bl	0x10146cd90 <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x5a4>
101470194: 394643e8    	ldrb	w8, [sp, #0x190]
101470198: 7100051f    	cmp	w8, #0x1
10147019c: 54000f81    	b.ne	0x10147038c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2ffc>
1014701a0: f940cfeb    	ldr	x11, [sp, #0x198]
1014701a4: f240fb9f    	tst	x28, #0x7fffffffffffffff
1014701a8: 540012a1    	b.ne	0x1014703fc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x306c>
1014701ac: f9001feb    	str	x11, [sp, #0x38]
1014701b0: b50002d9    	cbnz	x25, 0x101470208 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2e78>
1014701b4: 14000099    	b	0x101470418 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3088>
1014701b8: 9108e3f9    	add	x25, sp, #0x238
1014701bc: ad418720    	ldp	q0, q1, [x25, #0x30]
1014701c0: ad3a07a0    	stp	q0, q1, [x29, #-0xc0]
1014701c4: 3cc50320    	ldur	q0, [x25, #0x50]
1014701c8: 3c9603a0    	stur	q0, [x29, #-0xa0]
1014701cc: f846032c    	ldur	x12, [x25, #0x60]
1014701d0: f81703ac    	stur	x12, [x29, #-0x90]
1014701d4: ad408720    	ldp	q0, q1, [x25, #0x10]
1014701d8: ad3907a0    	stp	q0, q1, [x29, #-0xe0]
1014701dc: a94037ef    	ldp	x15, x13, [sp]
1014701e0: f9400bfc    	ldr	x28, [sp, #0x10]
1014701e4: 1400003c    	b	0x1014702d4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2f44>
1014701e8: 52800020    	mov	w0, #0x1                ; =1
1014701ec: b0006fc1    	adrp	x1, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
1014701f0: 91298021    	add	x1, x1, #0xa60
1014701f4: 90006fc2    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
1014701f8: 9113a042    	add	x2, x2, #0x4e8
1014701fc: 94187b6b    	bl	0x101a8efa8 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0xc8>
101470200: f9001fe0    	str	x0, [sp, #0x38]
101470204: b40010b9    	cbz	x25, 0x101470418 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3088>
101470208: 9100235c    	add	x28, x26, #0x8
10147020c: 14000004    	b	0x10147021c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2e8c>
101470210: 9100639c    	add	x28, x28, #0x18
101470214: f1000739    	subs	x25, x25, #0x1
101470218: 54001000    	b.eq	0x101470418 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3088>
10147021c: f85f8381    	ldur	x1, [x28, #-0x8]
101470220: b4ffff81    	cbz	x1, 0x101470210 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2e80>
101470224: f9400380    	ldr	x0, [x28]
101470228: 52800022    	mov	w2, #0x1                ; =1
10147022c: 97d8b92c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101470230: 17fffff8    	b	0x101470210 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2e80>
101470234: 9108e3e0    	add	x0, sp, #0x238
101470238: 97ff8e70    	bl	0x101453bf8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6770>
10147023c: d2800048    	mov	x8, #0x2                ; =2
101470240: f2f00008    	movk	x8, #0x8000, lsl #48
101470244: f9401be1    	ldr	x1, [sp, #0x30]
101470248: eb08003f    	cmp	x1, x8
10147024c: 540000ab    	b.lt	0x101470260 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2ed0>
101470250: b4000081    	cbz	x1, 0x101470260 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2ed0>
101470254: f94007e0    	ldr	x0, [sp, #0x8]
101470258: 52800022    	mov	w2, #0x1                ; =1
10147025c: 97d8b920    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101470260: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101470264: f9401fe9    	ldr	x9, [sp, #0x38]
101470268: eb08013f    	cmp	x9, x8
10147026c: 54000081    	b.ne	0x10147027c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2eec>
101470270: 528000ae    	mov	w14, #0x5               ; =5
101470274: 9108e3f9    	add	x25, sp, #0x238
101470278: 14000017    	b	0x1014702d4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2f44>
10147027c: b40001ba    	cbz	x26, 0x1014702b0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2f20>
101470280: f9400fe8    	ldr	x8, [sp, #0x18]
101470284: 91002119    	add	x25, x8, #0x8
101470288: 14000004    	b	0x101470298 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2f08>
10147028c: 91006339    	add	x25, x25, #0x18
101470290: f100075a    	subs	x26, x26, #0x1
101470294: 540000e0    	b.eq	0x1014702b0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2f20>
101470298: f85f8321    	ldur	x1, [x25, #-0x8]
10147029c: b4ffff81    	cbz	x1, 0x10147028c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2efc>
1014702a0: f9400320    	ldr	x0, [x25]
1014702a4: 52800022    	mov	w2, #0x1                ; =1
1014702a8: 97d8b90d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014702ac: 17fffff8    	b	0x10147028c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2efc>
1014702b0: 9108e3f9    	add	x25, sp, #0x238
1014702b4: f9401fe8    	ldr	x8, [sp, #0x38]
1014702b8: b40000c8    	cbz	x8, 0x1014702d0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2f40>
1014702bc: 8b080508    	add	x8, x8, x8, lsl #1
1014702c0: d37df101    	lsl	x1, x8, #3
1014702c4: f9400fe0    	ldr	x0, [sp, #0x18]
1014702c8: 52800102    	mov	w2, #0x8                ; =8
1014702cc: 97d8b904    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014702d0: 528000ae    	mov	w14, #0x5               ; =5
1014702d4: 3940c30c    	ldrb	w12, [x24, #0x30]
1014702d8: 1100058c    	add	w12, w12, #0x1
1014702dc: 3900c30c    	strb	w12, [x24, #0x30]
1014702e0: f9011fee    	str	x14, [sp, #0x238]
1014702e4: f90123fc    	str	x28, [sp, #0x240]
1014702e8: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
1014702ec: ad018720    	stp	q0, q1, [x25, #0x30]
1014702f0: 3cd603a0    	ldur	q0, [x29, #-0xa0]
1014702f4: 3c850320    	stur	q0, [x25, #0x50]
1014702f8: f85703ac    	ldur	x12, [x29, #-0x90]
1014702fc: f806032c    	stur	x12, [x25, #0x60]
101470300: ad7907a0    	ldp	q0, q1, [x29, #-0xe0]
101470304: ad008720    	stp	q0, q1, [x25, #0x10]
101470308: f90153eb    	str	x11, [sp, #0x2a0]
10147030c: f90157ea    	str	x10, [sp, #0x2a8]
101470310: f9015be9    	str	x9, [sp, #0x2b0]
101470314: f9015fe8    	str	x8, [sp, #0x2b8]
101470318: f90163ed    	str	x13, [sp, #0x2c0]
10147031c: f90167ef    	str	x15, [sp, #0x2c8]
101470320: aa1803e0    	mov	x0, x24
101470324: 97fe5174    	bl	0x1014048f4 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x38a8>
101470328: aa0003fa    	mov	x26, x0
10147032c: ad5186c0    	ldp	q0, q1, [x22, #0x230]
101470330: ad0f87e0    	stp	q0, q1, [sp, #0x1f0]
101470334: 3dc096c0    	ldr	q0, [x22, #0x250]
101470338: 3d8087e0    	str	q0, [sp, #0x210]
10147033c: f94167e8    	ldr	x8, [sp, #0x2c8]
101470340: ad4f86c0    	ldp	q0, q1, [x22, #0x1f0]
101470344: ad0d87e0    	stp	q0, q1, [sp, #0x1b0]
101470348: ad5086c0    	ldp	q0, q1, [x22, #0x210]
10147034c: ad0e87e0    	stp	q0, q1, [sp, #0x1d0]
101470350: ad4e86c0    	ldp	q0, q1, [x22, #0x1d0]
101470354: ad0c87e0    	stp	q0, q1, [sp, #0x190]
101470358: f90113e8    	str	x8, [sp, #0x220]
10147035c: f90117e0    	str	x0, [sp, #0x228]
101470360: f940cbe8    	ldr	x8, [sp, #0x190]
101470364: f100151f    	cmp	x8, #0x5
101470368: 54000d41    	b.ne	0x101470510 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3180>
10147036c: f940cff9    	ldr	x25, [sp, #0x198]
101470370: b400103a    	cbz	x26, 0x101470574 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x31e4>
101470374: f9400348    	ldr	x8, [x26]
101470378: f100051f    	cmp	x8, #0x1
10147037c: 54000bc1    	b.ne	0x1014704f4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3164>
101470380: 91002340    	add	x0, x26, #0x8
101470384: 97ff8bbe    	bl	0x10145327c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5df4>
101470388: 14000077    	b	0x101470564 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x31d4>
10147038c: 394647e8    	ldrb	w8, [sp, #0x191]
101470390: 7100051f    	cmp	w8, #0x1
101470394: 54000221    	b.ne	0x1014703d8 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3048>
101470398: f85083a1    	ldur	x1, [x29, #-0xf8]
10147039c: 910643e0    	add	x0, sp, #0x190
1014703a0: 97fff3fd    	bl	0x10146d394 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x4>
1014703a4: a9592fe8    	ldp	x8, x11, [sp, #0x190]
1014703a8: f100151f    	cmp	x8, #0x5
1014703ac: 54ffefc0    	b.eq	0x1014701a4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2e14>
1014703b0: 910643ea    	add	x10, sp, #0x190
1014703b4: ad418540    	ldp	q0, q1, [x10, #0x30]
1014703b8: ad1787e0    	stp	q0, q1, [sp, #0x2f0]
1014703bc: 3cc50140    	ldur	q0, [x10, #0x50]
1014703c0: 3d80c7e0    	str	q0, [sp, #0x310]
1014703c4: f8460149    	ldur	x9, [x10, #0x60]
1014703c8: f90193e9    	str	x9, [sp, #0x320]
1014703cc: ad408540    	ldp	q0, q1, [x10, #0x10]
1014703d0: ad1687e0    	stp	q0, q1, [sp, #0x2d0]
1014703d4: 14000002    	b	0x1014703dc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x304c>
1014703d8: 52800088    	mov	w8, #0x4                ; =4
1014703dc: 3dc076c0    	ldr	q0, [x22, #0x1d0]
1014703e0: 3c9803a0    	stur	q0, [x29, #-0x80]
1014703e4: f94127e9    	ldr	x9, [sp, #0x248]
1014703e8: f81903a9    	stur	x9, [x29, #-0x70]
1014703ec: aa0b03fa    	mov	x26, x11
1014703f0: f9401fea    	ldr	x10, [sp, #0x38]
1014703f4: f94017eb    	ldr	x11, [sp, #0x28]
1014703f8: 14000012    	b	0x101470440 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x30b0>
1014703fc: f9401fe0    	ldr	x0, [sp, #0x38]
101470400: aa1c03e1    	mov	x1, x28
101470404: 52800022    	mov	w2, #0x1                ; =1
101470408: aa0b03fc    	mov	x28, x11
10147040c: 97d8b8b4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101470410: f9001ffc    	str	x28, [sp, #0x38]
101470414: b5ffefb9    	cbnz	x25, 0x101470208 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2e78>
101470418: f9401be8    	ldr	x8, [sp, #0x30]
10147041c: b40000c8    	cbz	x8, 0x101470434 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x30a4>
101470420: 8b080508    	add	x8, x8, x8, lsl #1
101470424: d37df101    	lsl	x1, x8, #3
101470428: aa1a03e0    	mov	x0, x26
10147042c: 52800102    	mov	w2, #0x8                ; =8
101470430: 97d8b8ab    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101470434: f9401fea    	ldr	x10, [sp, #0x38]
101470438: aa0a03fa    	mov	x26, x10
10147043c: 528000a8    	mov	w8, #0x5                ; =5
101470440: 3940c309    	ldrb	w9, [x24, #0x30]
101470444: 11000529    	add	w9, w9, #0x1
101470448: 3900c309    	strb	w9, [x24, #0x30]
10147044c: f9011fe8    	str	x8, [sp, #0x238]
101470450: f90123fa    	str	x26, [sp, #0x240]
101470454: ad5787e0    	ldp	q0, q1, [sp, #0x2f0]
101470458: 9108e3e9    	add	x9, sp, #0x238
10147045c: ad018520    	stp	q0, q1, [x9, #0x30]
101470460: 3dc0c7e0    	ldr	q0, [sp, #0x310]
101470464: 3c850120    	stur	q0, [x9, #0x50]
101470468: f94193e8    	ldr	x8, [sp, #0x320]
10147046c: f8060128    	stur	x8, [x9, #0x60]
101470470: ad5687e0    	ldp	q0, q1, [sp, #0x2d0]
101470474: ad008520    	stp	q0, q1, [x9, #0x10]
101470478: 3cd803a0    	ldur	q0, [x29, #-0x80]
10147047c: 3c868120    	stur	q0, [x9, #0x68]
101470480: f85903a8    	ldur	x8, [x29, #-0x70]
101470484: f8078128    	stur	x8, [x9, #0x78]
101470488: f9015ffc    	str	x28, [sp, #0x2b8]
10147048c: f90163ea    	str	x10, [sp, #0x2c0]
101470490: f90167eb    	str	x11, [sp, #0x2c8]
101470494: aa1803e0    	mov	x0, x24
101470498: 97fe5140    	bl	0x101404998 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x394c>
10147049c: aa0003fa    	mov	x26, x0
1014704a0: ad5186c0    	ldp	q0, q1, [x22, #0x230]
1014704a4: ad0f87e0    	stp	q0, q1, [sp, #0x1f0]
1014704a8: 3dc096c0    	ldr	q0, [x22, #0x250]
1014704ac: 3d8087e0    	str	q0, [sp, #0x210]
1014704b0: f94167e8    	ldr	x8, [sp, #0x2c8]
1014704b4: ad4f86c0    	ldp	q0, q1, [x22, #0x1f0]
1014704b8: ad0d87e0    	stp	q0, q1, [sp, #0x1b0]
1014704bc: ad5086c0    	ldp	q0, q1, [x22, #0x210]
1014704c0: ad0e87e0    	stp	q0, q1, [sp, #0x1d0]
1014704c4: ad4e86c0    	ldp	q0, q1, [x22, #0x1d0]
1014704c8: ad0c87e0    	stp	q0, q1, [sp, #0x190]
1014704cc: f90113e8    	str	x8, [sp, #0x220]
1014704d0: f90117e0    	str	x0, [sp, #0x228]
1014704d4: f940cbe8    	ldr	x8, [sp, #0x190]
1014704d8: f100151f    	cmp	x8, #0x5
1014704dc: 540001a1    	b.ne	0x101470510 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3180>
1014704e0: f940cff9    	ldr	x25, [sp, #0x198]
1014704e4: b400049a    	cbz	x26, 0x101470574 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x31e4>
1014704e8: f9400348    	ldr	x8, [x26]
1014704ec: f100051f    	cmp	x8, #0x1
1014704f0: 54000360    	b.eq	0x10147055c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x31cc>
1014704f4: b5000388    	cbnz	x8, 0x101470564 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x31d4>
1014704f8: f9400b41    	ldr	x1, [x26, #0x10]
1014704fc: b4000341    	cbz	x1, 0x101470564 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x31d4>
101470500: f9400740    	ldr	x0, [x26, #0x8]
101470504: 52800022    	mov	w2, #0x1                ; =1
101470508: 97d8b875    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147050c: 14000016    	b	0x101470564 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x31d4>
101470510: b40000da    	cbz	x26, 0x101470528 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3198>
101470514: 910643e0    	add	x0, sp, #0x190
101470518: 97ff8ec3    	bl	0x101454024 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6b9c>
10147051c: 528000a8    	mov	w8, #0x5                ; =5
101470520: aa1a03f9    	mov	x25, x26
101470524: 14000015    	b	0x101470578 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x31e8>
101470528: f940cff9    	ldr	x25, [sp, #0x198]
10147052c: 910643ea    	add	x10, sp, #0x190
101470530: ad438540    	ldp	q0, q1, [x10, #0x70]
101470534: ad0b07e0    	stp	q0, q1, [sp, #0x160]
101470538: f8490149    	ldur	x9, [x10, #0x90]
10147053c: f900c3e9    	str	x9, [sp, #0x180]
101470540: ad418540    	ldp	q0, q1, [x10, #0x30]
101470544: ad0907e0    	stp	q0, q1, [sp, #0x120]
101470548: ad428141    	ldp	q1, q0, [x10, #0x50]
10147054c: ad0a03e1    	stp	q1, q0, [sp, #0x140]
101470550: ad408141    	ldp	q1, q0, [x10, #0x10]
101470554: ad0803e1    	stp	q1, q0, [sp, #0x100]
101470558: 14000008    	b	0x101470578 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x31e8>
10147055c: 91002340    	add	x0, x26, #0x8
101470560: 97ff8b47    	bl	0x10145327c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5df4>
101470564: aa1a03e0    	mov	x0, x26
101470568: 52800501    	mov	w1, #0x28               ; =40
10147056c: 52800102    	mov	w2, #0x8                ; =8
101470570: 97d8b85b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101470574: 528000a8    	mov	w8, #0x5                ; =5
101470578: 9101a3ea    	add	x10, sp, #0x68
10147057c: 5280131a    	mov	w26, #0x98              ; =152
101470580: f100151f    	cmp	x8, #0x5
101470584: 54002b80    	b.eq	0x101470af4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3764>
101470588: ad4b07e0    	ldp	q0, q1, [sp, #0x160]
10147058c: ad038540    	stp	q0, q1, [x10, #0x70]
101470590: f940c3e9    	ldr	x9, [sp, #0x180]
101470594: f8090149    	stur	x9, [x10, #0x90]
101470598: ad4907e0    	ldp	q0, q1, [sp, #0x120]
10147059c: ad018540    	stp	q0, q1, [x10, #0x30]
1014705a0: ad4a03e1    	ldp	q1, q0, [sp, #0x140]
1014705a4: ad028141    	stp	q1, q0, [x10, #0x50]
1014705a8: ad4803e1    	ldp	q1, q0, [sp, #0x100]
1014705ac: ad008141    	stp	q1, q0, [x10, #0x10]
1014705b0: a906e7e8    	stp	x8, x25, [sp, #0x68]
1014705b4: f94033f8    	ldr	x24, [sp, #0x60]
1014705b8: f9402be8    	ldr	x8, [sp, #0x50]
1014705bc: eb08031f    	cmp	x24, x8
1014705c0: 54000061    	b.ne	0x1014705cc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x323c>
1014705c4: 910143e0    	add	x0, sp, #0x50
1014705c8: 94187ec9    	bl	0x101a900ec <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hbcd96c4fe6d22110E>
1014705cc: f9402ff9    	ldr	x25, [sp, #0x58]
1014705d0: 9b1a6708    	madd	x8, x24, x26, x25
1014705d4: ad4306c0    	ldp	q0, q1, [x22, #0x60]
1014705d8: ad030500    	stp	q0, q1, [x8, #0x60]
1014705dc: 3dc022c0    	ldr	q0, [x22, #0x80]
1014705e0: 3d802100    	str	q0, [x8, #0x80]
1014705e4: f9407fe9    	ldr	x9, [sp, #0xf8]
1014705e8: f9004909    	str	x9, [x8, #0x90]
1014705ec: 3cc883e0    	ldur	q0, [sp, #0x88]
1014705f0: 3cc983e1    	ldur	q1, [sp, #0x98]
1014705f4: ad010500    	stp	q0, q1, [x8, #0x20]
1014705f8: 3cca83e0    	ldur	q0, [sp, #0xa8]
1014705fc: 3ccb83e1    	ldur	q1, [sp, #0xb8]
101470600: ad020500    	stp	q0, q1, [x8, #0x40]
101470604: 3cc683e0    	ldur	q0, [sp, #0x68]
101470608: 3cc783e1    	ldur	q1, [sp, #0x78]
10147060c: ad000500    	stp	q0, q1, [x8]
101470610: 9100071b    	add	x27, x24, #0x1
101470614: f90033fb    	str	x27, [sp, #0x60]
101470618: 17fffd8c    	b	0x10146fc48 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x28b8>
10147061c: f94013e8    	ldr	x8, [sp, #0x20]
101470620: f9011fe8    	str	x8, [sp, #0x238]
101470624: a94123ea    	ldp	x10, x8, [sp, #0x10]
101470628: f90123ea    	str	x10, [sp, #0x240]
10147062c: f9401fe9    	ldr	x9, [sp, #0x38]
101470630: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
101470634: f81183ba    	stur	x26, [x29, #-0xe8]
101470638: 52800068    	mov	w8, #0x3                ; =3
10147063c: f81803a8    	stur	x8, [x29, #-0x80]
101470640: d10203a1    	sub	x1, x29, #0x80
101470644: 528000a8    	mov	w8, #0x5                ; =5
101470648: f90017e8    	str	x8, [sp, #0x28]
10147064c: aa1903e0    	mov	x0, x25
101470650: 94187ab6    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
101470654: aa0003fc    	mov	x28, x0
101470658: 17fffef9    	b	0x10147023c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2eac>
10147065c: f94013e8    	ldr	x8, [sp, #0x20]
101470660: f9011fe8    	str	x8, [sp, #0x238]
101470664: a94123ea    	ldp	x10, x8, [sp, #0x10]
101470668: f90123ea    	str	x10, [sp, #0x240]
10147066c: f9401fe9    	ldr	x9, [sp, #0x38]
101470670: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
101470674: f81183ba    	stur	x26, [x29, #-0xe8]
101470678: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10147067c: f9001fe8    	str	x8, [sp, #0x38]
101470680: 52800068    	mov	w8, #0x3                ; =3
101470684: f900cbe8    	str	x8, [sp, #0x190]
101470688: 910643e1    	add	x1, sp, #0x190
10147068c: aa1903e0    	mov	x0, x25
101470690: 94187aa6    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
101470694: aa0003fc    	mov	x28, x0
101470698: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10147069c: f9001fe8    	str	x8, [sp, #0x38]
1014706a0: 17fffe6d    	b	0x101470054 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2cc4>
1014706a4: f94013e8    	ldr	x8, [sp, #0x20]
1014706a8: f9011fe8    	str	x8, [sp, #0x238]
1014706ac: a94123ea    	ldp	x10, x8, [sp, #0x10]
1014706b0: f90123ea    	str	x10, [sp, #0x240]
1014706b4: f9401fe9    	ldr	x9, [sp, #0x38]
1014706b8: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
1014706bc: f81183ba    	stur	x26, [x29, #-0xe8]
1014706c0: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
1014706c4: f9001be8    	str	x8, [sp, #0x30]
1014706c8: 52800068    	mov	w8, #0x3                ; =3
1014706cc: f900cbe8    	str	x8, [sp, #0x190]
1014706d0: 910643e1    	add	x1, sp, #0x190
1014706d4: aa1903e0    	mov	x0, x25
1014706d8: 94187a94    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
1014706dc: aa0003fc    	mov	x28, x0
1014706e0: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
1014706e4: f9001be8    	str	x8, [sp, #0x30]
1014706e8: 17fffe5b    	b	0x101470054 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2cc4>
1014706ec: f94013e8    	ldr	x8, [sp, #0x20]
1014706f0: f9011fe8    	str	x8, [sp, #0x238]
1014706f4: a94123ea    	ldp	x10, x8, [sp, #0x10]
1014706f8: f90123ea    	str	x10, [sp, #0x240]
1014706fc: f9401fe9    	ldr	x9, [sp, #0x38]
101470700: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
101470704: f81183ba    	stur	x26, [x29, #-0xe8]
101470708: f85883bc    	ldur	x28, [x29, #-0x78]
10147070c: 17ffffe3    	b	0x101470698 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3308>
101470710: f94013e8    	ldr	x8, [sp, #0x20]
101470714: f9011fe8    	str	x8, [sp, #0x238]
101470718: a94123ea    	ldp	x10, x8, [sp, #0x10]
10147071c: f90123ea    	str	x10, [sp, #0x240]
101470720: f9401fe9    	ldr	x9, [sp, #0x38]
101470724: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
101470728: f81183ba    	stur	x26, [x29, #-0xe8]
10147072c: f85883bc    	ldur	x28, [x29, #-0x78]
101470730: 17ffffec    	b	0x1014706e0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3350>
101470734: f94013e8    	ldr	x8, [sp, #0x20]
101470738: f9011fe8    	str	x8, [sp, #0x238]
10147073c: a94123ea    	ldp	x10, x8, [sp, #0x10]
101470740: f90123ea    	str	x10, [sp, #0x240]
101470744: f9401fe9    	ldr	x9, [sp, #0x38]
101470748: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
10147074c: f81183ba    	stur	x26, [x29, #-0xe8]
101470750: f940cffc    	ldr	x28, [sp, #0x198]
101470754: 17fffeba    	b	0x10147023c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2eac>
101470758: f94013e8    	ldr	x8, [sp, #0x20]
10147075c: f9011fe8    	str	x8, [sp, #0x238]
101470760: a94123ea    	ldp	x10, x8, [sp, #0x10]
101470764: f90123ea    	str	x10, [sp, #0x240]
101470768: f9401fe9    	ldr	x9, [sp, #0x38]
10147076c: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
101470770: f81183ba    	stur	x26, [x29, #-0xe8]
101470774: f0004368    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101470778: 9125f109    	add	x9, x8, #0x97c
10147077c: 52800168    	mov	w8, #0xb                ; =11
101470780: a93823a9    	stp	x9, x8, [x29, #-0x80]
101470784: d10203a8    	sub	x8, x29, #0x80
101470788: f900cbe8    	str	x8, [sp, #0x190]
10147078c: f0fffee8    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101470790: 91117108    	add	x8, x8, #0x45c
101470794: f900cfe8    	str	x8, [sp, #0x198]
101470798: 910643e1    	add	x1, sp, #0x190
10147079c: b0004be0    	adrp	x0, 0x101ded000 <_writev+0x101ded000>
1014707a0: 912fec00    	add	x0, x0, #0xbfb
1014707a4: 9416e065    	bl	0x101a28938 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x214>
1014707a8: 14000015    	b	0x1014707fc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x346c>
1014707ac: f94013e8    	ldr	x8, [sp, #0x20]
1014707b0: f9011fe8    	str	x8, [sp, #0x238]
1014707b4: a94123ea    	ldp	x10, x8, [sp, #0x10]
1014707b8: f90123ea    	str	x10, [sp, #0x240]
1014707bc: f9401fe9    	ldr	x9, [sp, #0x38]
1014707c0: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
1014707c4: f81183ba    	stur	x26, [x29, #-0xe8]
1014707c8: f0004368    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014707cc: 91261d09    	add	x9, x8, #0x987
1014707d0: 528000a8    	mov	w8, #0x5                ; =5
1014707d4: a93823a9    	stp	x9, x8, [x29, #-0x80]
1014707d8: d10203a8    	sub	x8, x29, #0x80
1014707dc: f900cbe8    	str	x8, [sp, #0x190]
1014707e0: f0fffee8    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
1014707e4: 91117108    	add	x8, x8, #0x45c
1014707e8: f900cfe8    	str	x8, [sp, #0x198]
1014707ec: 910643e1    	add	x1, sp, #0x190
1014707f0: b0004be0    	adrp	x0, 0x101ded000 <_writev+0x101ded000>
1014707f4: 912fec00    	add	x0, x0, #0xbfb
1014707f8: 9416e050    	bl	0x101a28938 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x214>
1014707fc: aa0003fc    	mov	x28, x0
101470800: 17fffe15    	b	0x101470054 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2cc4>
101470804: f94013e8    	ldr	x8, [sp, #0x20]
101470808: f9011fe8    	str	x8, [sp, #0x238]
10147080c: a94123ea    	ldp	x10, x8, [sp, #0x10]
101470810: f90123ea    	str	x10, [sp, #0x240]
101470814: f9401fe9    	ldr	x9, [sp, #0x38]
101470818: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
10147081c: f81183ba    	stur	x26, [x29, #-0xe8]
101470820: d0003568    	adrp	x8, 0x101b1e000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x17014>
101470824: 9112a109    	add	x9, x8, #0x4a8
101470828: 52800088    	mov	w8, #0x4                ; =4
10147082c: a93823a9    	stp	x9, x8, [x29, #-0x80]
101470830: d10203a8    	sub	x8, x29, #0x80
101470834: f900cbe8    	str	x8, [sp, #0x190]
101470838: f0fffee8    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
10147083c: 91117108    	add	x8, x8, #0x45c
101470840: f900cfe8    	str	x8, [sp, #0x198]
101470844: 910643e1    	add	x1, sp, #0x190
101470848: b0004be0    	adrp	x0, 0x101ded000 <_writev+0x101ded000>
10147084c: 912fec00    	add	x0, x0, #0xbfb
101470850: 9416e03a    	bl	0x101a28938 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x214>
101470854: aa0003fc    	mov	x28, x0
101470858: 9101a3f6    	add	x22, sp, #0x68
10147085c: f94017e8    	ldr	x8, [sp, #0x28]
101470860: f100111f    	cmp	x8, #0x4
101470864: 54ffc021    	b.ne	0x101470068 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2cd8>
101470868: 17fffe75    	b	0x10147023c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x2eac>
10147086c: f94013e8    	ldr	x8, [sp, #0x20]
101470870: f9011fe8    	str	x8, [sp, #0x238]
101470874: a94123ea    	ldp	x10, x8, [sp, #0x10]
101470878: f90123ea    	str	x10, [sp, #0x240]
10147087c: f9401fe9    	ldr	x9, [sp, #0x38]
101470880: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
101470884: f81183ba    	stur	x26, [x29, #-0xe8]
101470888: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10147088c: f9001be8    	str	x8, [sp, #0x30]
101470890: 528000c8    	mov	w8, #0x6                ; =6
101470894: f900cbe8    	str	x8, [sp, #0x190]
101470898: 910643e1    	add	x1, sp, #0x190
10147089c: aa1903e0    	mov	x0, x25
1014708a0: 94187a22    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
1014708a4: 17ffff8e    	b	0x1014706dc <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x334c>
1014708a8: f94013e8    	ldr	x8, [sp, #0x20]
1014708ac: f9011fe8    	str	x8, [sp, #0x238]
1014708b0: a94123ea    	ldp	x10, x8, [sp, #0x10]
1014708b4: f90123ea    	str	x10, [sp, #0x240]
1014708b8: f9401fe9    	ldr	x9, [sp, #0x38]
1014708bc: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
1014708c0: f81183ba    	stur	x26, [x29, #-0xe8]
1014708c4: 528000c8    	mov	w8, #0x6                ; =6
1014708c8: f81803a8    	stur	x8, [x29, #-0x80]
1014708cc: d10203a1    	sub	x1, x29, #0x80
1014708d0: 528000a8    	mov	w8, #0x5                ; =5
1014708d4: f90017e8    	str	x8, [sp, #0x28]
1014708d8: aa1903e0    	mov	x0, x25
1014708dc: 94187a13    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
1014708e0: 17ffff5d    	b	0x101470654 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x32c4>
1014708e4: f94013e8    	ldr	x8, [sp, #0x20]
1014708e8: f9011fe8    	str	x8, [sp, #0x238]
1014708ec: a94123ea    	ldp	x10, x8, [sp, #0x10]
1014708f0: f90123ea    	str	x10, [sp, #0x240]
1014708f4: f9401fe9    	ldr	x9, [sp, #0x38]
1014708f8: a930a3a9    	stp	x9, x8, [x29, #-0xf8]
1014708fc: f81183ba    	stur	x26, [x29, #-0xe8]
101470900: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101470904: f9001fe8    	str	x8, [sp, #0x38]
101470908: 528000c8    	mov	w8, #0x6                ; =6
10147090c: f900cbe8    	str	x8, [sp, #0x190]
101470910: 910643e1    	add	x1, sp, #0x190
101470914: aa1903e0    	mov	x0, x25
101470918: 94187a04    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
10147091c: 17ffff5e    	b	0x101470694 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3304>
101470920: 528000a8    	mov	w8, #0x5                ; =5
101470924: f900cbe8    	str	x8, [sp, #0x190]
101470928: 910643e1    	add	x1, sp, #0x190
10147092c: aa1803e0    	mov	x0, x24
101470930: 941879fe    	bl	0x101a8f128 <__ZN76_$LT$miniz_oxide..inflate..DecompressError$u20$as$u20$core..fmt..Display$GT$3fmt17hd6b40434d801f64eE+0x248>
101470934: aa0003f5    	mov	x21, x0
101470938: aa1b03f7    	mov	x23, x27
10147093c: b40000fb    	cbz	x27, 0x101470958 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x35c8>
101470940: aa1903f6    	mov	x22, x25
101470944: aa1603e0    	mov	x0, x22
101470948: 97ff8db7    	bl	0x101454024 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6b9c>
10147094c: 910262d6    	add	x22, x22, #0x98
101470950: f10006f7    	subs	x23, x23, #0x1
101470954: 54ffff81    	b.ne	0x101470944 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x35b4>
101470958: f9402be8    	ldr	x8, [sp, #0x50]
10147095c: b40000c8    	cbz	x8, 0x101470974 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x35e4>
101470960: 52801309    	mov	w9, #0x98               ; =152
101470964: 9b097d01    	mul	x1, x8, x9
101470968: aa1903e0    	mov	x0, x25
10147096c: 52800102    	mov	w2, #0x8                ; =8
101470970: 97d8b75b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101470974: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
101470978: 3940c288    	ldrb	w8, [x20, #0x30]
10147097c: 11000508    	add	w8, w8, #0x1
101470980: 3900c288    	strb	w8, [x20, #0x30]
101470984: a91957f8    	stp	x24, x21, [sp, #0x190]
101470988: f900d3fb    	str	x27, [sp, #0x1a0]
10147098c: aa1403e0    	mov	x0, x20
101470990: 97fe5002    	bl	0x101404998 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x394c>
101470994: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101470998: eb08031f    	cmp	x24, x8
10147099c: 540000a0    	b.eq	0x1014709b0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3620>
1014709a0: b5000200    	cbnz	x0, 0x1014709e0 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3650>
1014709a4: a9005678    	stp	x24, x21, [x19]
1014709a8: f9000a7b    	str	x27, [x19, #0x10]
1014709ac: 14000039    	b	0x101470a90 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3700>
1014709b0: b4000640    	cbz	x0, 0x101470a78 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x36e8>
1014709b4: f9400008    	ldr	x8, [x0]
1014709b8: f100051f    	cmp	x8, #0x1
1014709bc: 54000500    	b.eq	0x101470a5c <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x36cc>
1014709c0: aa0003f6    	mov	x22, x0
1014709c4: b5000528    	cbnz	x8, 0x101470a68 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x36d8>
1014709c8: f9400ac1    	ldr	x1, [x22, #0x10]
1014709cc: b40004e1    	cbz	x1, 0x101470a68 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x36d8>
1014709d0: f94006c0    	ldr	x0, [x22, #0x8]
1014709d4: 52800022    	mov	w2, #0x1                ; =1
1014709d8: 97d8b741    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014709dc: 14000023    	b	0x101470a68 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x36d8>
1014709e0: aa0003f6    	mov	x22, x0
1014709e4: b40000fb    	cbz	x27, 0x101470a00 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x3670>
1014709e8: aa1503f7    	mov	x23, x21
1014709ec: aa1703e0    	mov	x0, x23
1014709f0: 97ff8d8d    	bl	0x101454024 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6b9c>
1014709f4: 910262f7    	add	x23, x23, #0x98
1014709f8: f100077b    	subs	x27, x27, #0x1
1014709fc: 54ffff81    	b.ne	0x1014709ec <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x365c>
