
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001013fdd28 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE>:
1013ff688: d10243ff    	sub	sp, sp, #0x90
1013ff68c: a9036ffc    	stp	x28, x27, [sp, #0x30]
1013ff690: a90467fa    	stp	x26, x25, [sp, #0x40]
1013ff694: a9055ff8    	stp	x24, x23, [sp, #0x50]
1013ff698: a90657f6    	stp	x22, x21, [sp, #0x60]
1013ff69c: a9074ff4    	stp	x20, x19, [sp, #0x70]
1013ff6a0: a9087bfd    	stp	x29, x30, [sp, #0x80]
1013ff6a4: 910203fd    	add	x29, sp, #0x80
1013ff6a8: aa0003f4    	mov	x20, x0
1013ff6ac: f9400c39    	ldr	x25, [x1, #0x18]
1013ff6b0: f940043a    	ldr	x26, [x1, #0x8]
1013ff6b4: eb19035f    	cmp	x26, x25
1013ff6b8: 54000300    	b.eq	0x1013ff718 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19f0>
1013ff6bc: aa0103f7    	mov	x23, x1
1013ff6c0: f9401038    	ldr	x24, [x1, #0x20]
1013ff6c4: d2f0001b    	mov	x27, #-0x8000000000000000 ; =-9223372036854775808
1013ff6c8: 14000005    	b	0x1013ff6dc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19b4>
1013ff6cc: eb1b027f    	cmp	x19, x27
1013ff6d0: 540002a1    	b.ne	0x1013ff724 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19fc>
1013ff6d4: eb19035f    	cmp	x26, x25
1013ff6d8: 54000200    	b.eq	0x1013ff718 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19f0>
1013ff6dc: a9405753    	ldp	x19, x21, [x26]
1013ff6e0: f9400b56    	ldr	x22, [x26, #0x10]
1013ff6e4: 9100635a    	add	x26, x26, #0x18
1013ff6e8: f90006fa    	str	x26, [x23, #0x8]
1013ff6ec: aa1803e0    	mov	x0, x24
1013ff6f0: aa1503e1    	mov	x1, x21
1013ff6f4: aa1603e2    	mov	x2, x22
1013ff6f8: 94003d55    	bl	0x10140ec4c <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E>
1013ff6fc: 3707fe80    	tbnz	w0, #0x0, 0x1013ff6cc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19a4>
1013ff700: b4fffeb3    	cbz	x19, 0x1013ff6d4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19ac>
1013ff704: aa1503e0    	mov	x0, x21
1013ff708: aa1303e1    	mov	x1, x19
1013ff70c: 52800022    	mov	w2, #0x1                ; =1
1013ff710: 97da7bf3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff714: 17fffff0    	b	0x1013ff6d4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19ac>
1013ff718: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013ff71c: f9000288    	str	x8, [x20]
1013ff720: 1400001d    	b	0x1013ff794 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1a6c>
1013ff724: 97da7bf3    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1013ff728: 528000c0    	mov	w0, #0x6                ; =6
1013ff72c: 52800021    	mov	w1, #0x1                ; =1
1013ff730: 97da7bea    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1013ff734: b4000400    	cbz	x0, 0x1013ff7b4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1a8c>
1013ff738: aa0003f7    	mov	x23, x0
1013ff73c: 528e8ca8    	mov	w8, #0x7465             ; =29797
1013ff740: 79000808    	strh	w8, [x0, #0x4]
1013ff744: 528c2e88    	mov	w8, #0x6174             ; =24948
1013ff748: 72acee48    	movk	w8, #0x6772, lsl #16
1013ff74c: b9000008    	str	w8, [x0]
1013ff750: a90057f3    	stp	x19, x21, [sp]
1013ff754: f9000bf6    	str	x22, [sp, #0x10]
1013ff758: 910063e8    	add	x8, sp, #0x18
1013ff75c: 910003e0    	mov	x0, sp
1013ff760: 94103e9b    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1013ff764: 3cc183e0    	ldur	q0, [sp, #0x18]
1013ff768: f94017e8    	ldr	x8, [sp, #0x28]
1013ff76c: 3d800280    	str	q0, [x20]
1013ff770: a9014e88    	stp	x8, x19, [x20, #0x10]
1013ff774: a9025a95    	stp	x21, x22, [x20, #0x20]
1013ff778: 528000c8    	mov	w8, #0x6                ; =6
1013ff77c: a9035e88    	stp	x8, x23, [x20, #0x30]
1013ff780: f00043e8    	adrp	x8, 0x101c7e000 <__ZN16curve25519_dalek9constants23X25519_LOW_ORDER_POINTS17h489881f202cbb08bE+0x48>
1013ff784: 3dc23100    	ldr	q0, [x8, #0x8c0]
1013ff788: 3d801280    	str	q0, [x20, #0x40]
1013ff78c: 52804008    	mov	w8, #0x200              ; =512
1013ff790: 7900c288    	strh	w8, [x20, #0x60]
1013ff794: a9487bfd    	ldp	x29, x30, [sp, #0x80]
1013ff798: a9474ff4    	ldp	x20, x19, [sp, #0x70]
1013ff79c: a94657f6    	ldp	x22, x21, [sp, #0x60]
1013ff7a0: a9455ff8    	ldp	x24, x23, [sp, #0x50]
1013ff7a4: a94467fa    	ldp	x26, x25, [sp, #0x40]
1013ff7a8: a9436ffc    	ldp	x28, x27, [sp, #0x30]
1013ff7ac: 910243ff    	add	sp, sp, #0x90
1013ff7b0: d65f03c0    	ret
1013ff7b4: 52800020    	mov	w0, #0x1                ; =1
1013ff7b8: 528000c1    	mov	w1, #0x6                ; =6
1013ff7bc: 941b0eee    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1013ff7c0: d4200020    	brk	#0x1
1013ff7c4: aa0003f4    	mov	x20, x0
1013ff7c8: b40000b3    	cbz	x19, 0x1013ff7dc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1ab4>
1013ff7cc: aa1503e0    	mov	x0, x21
1013ff7d0: aa1303e1    	mov	x1, x19
1013ff7d4: 52800022    	mov	w2, #0x1                ; =1
1013ff7d8: 97da7bc1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff7dc: aa1703e0    	mov	x0, x23
1013ff7e0: 528000c1    	mov	w1, #0x6                ; =6
1013ff7e4: 14000006    	b	0x1013ff7fc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1ad4>
1013ff7e8: 14000001    	b	0x1013ff7ec <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1ac4>
1013ff7ec: aa0003f4    	mov	x20, x0
1013ff7f0: b40000b3    	cbz	x19, 0x1013ff804 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1adc>
1013ff7f4: aa1503e0    	mov	x0, x21
1013ff7f8: aa1303e1    	mov	x1, x19
1013ff7fc: 52800022    	mov	w2, #0x1                ; =1
1013ff800: 97da7bb7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff804: aa1403e0    	mov	x0, x20
1013ff808: 941b2773    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013ff80c: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
1013ff810: a90167fa    	stp	x26, x25, [sp, #0x10]
1013ff814: a9025ff8    	stp	x24, x23, [sp, #0x20]
1013ff818: a90357f6    	stp	x22, x21, [sp, #0x30]
1013ff81c: a9044ff4    	stp	x20, x19, [sp, #0x40]
1013ff820: a9057bfd    	stp	x29, x30, [sp, #0x50]
1013ff824: 910143fd    	add	x29, sp, #0x50
1013ff828: aa0103f4    	mov	x20, x1
1013ff82c: aa0003f3    	mov	x19, x0
