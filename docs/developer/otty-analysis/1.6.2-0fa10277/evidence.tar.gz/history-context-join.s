
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101432360 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E>:
101432b04: d10203ff    	sub	sp, sp, #0x80
101432b08: a90557f6    	stp	x22, x21, [sp, #0x50]
101432b0c: a9064ff4    	stp	x20, x19, [sp, #0x60]
101432b10: a9077bfd    	stp	x29, x30, [sp, #0x70]
101432b14: 9101c3fd    	add	x29, sp, #0x70
101432b18: aa0003f3    	mov	x19, x0
101432b1c: a9008be1    	stp	x1, x2, [sp, #0x8]
101432b20: b4000384    	cbz	x4, 0x101432b90 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x830>
101432b24: b0004568    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101432b28: 9112ad08    	add	x8, x8, #0x4ab
101432b2c: 910063f4    	add	x20, sp, #0x18
101432b30: 910063e0    	add	x0, sp, #0x18
101432b34: aa0303e1    	mov	x1, x3
101432b38: aa0403e2    	mov	x2, x4
101432b3c: aa0803e3    	mov	x3, x8
101432b40: 52800024    	mov	w4, #0x1                ; =1
101432b44: 9400e04f    	bl	0x10146ac80 <__ZN4core5slice4sort8unstable8heapsort8heapsort17h14b311923aeea277E+0x383c>
101432b48: 910023e8    	add	x8, sp, #0x8
101432b4c: b00000e9    	adrp	x9, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101432b50: 91117129    	add	x9, x9, #0x45c
101432b54: a90327e8    	stp	x8, x9, [sp, #0x30]
101432b58: b00001c8    	adrp	x8, 0x10146b000 <__ZN4core5slice4sort8unstable8heapsort8heapsort17h14b311923aeea277E+0x3bbc>
101432b5c: 913b4108    	add	x8, x8, #0xed0
101432b60: a90423f4    	stp	x20, x8, [sp, #0x40]
101432b64: f0004de0    	adrp	x0, 0x101df1000 <_writev+0x101df1000>
101432b68: 911bc800    	add	x0, x0, #0x6f2
101432b6c: 9100c3e1    	add	x1, sp, #0x30
101432b70: aa1303e8    	mov	x8, x19
101432b74: 940f6283    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
101432b78: f9400fe1    	ldr	x1, [sp, #0x18]
101432b7c: b4000301    	cbz	x1, 0x101432bdc <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x87c>
101432b80: f94013e0    	ldr	x0, [sp, #0x20]
101432b84: 52800022    	mov	w2, #0x1                ; =1
101432b88: 97d9aed5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101432b8c: 14000014    	b	0x101432bdc <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x87c>
101432b90: aa0203f4    	mov	x20, x2
101432b94: b4000182    	cbz	x2, 0x101432bc4 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x864>
101432b98: aa0103f5    	mov	x21, x1
101432b9c: 97d9aed5    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101432ba0: aa1403e0    	mov	x0, x20
101432ba4: 52800021    	mov	w1, #0x1                ; =1
101432ba8: 97d9aecc    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101432bac: aa1503e1    	mov	x1, x21
101432bb0: aa0003f5    	mov	x21, x0
101432bb4: b50000a0    	cbnz	x0, 0x101432bc8 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x868>
101432bb8: 52800020    	mov	w0, #0x1                ; =1
101432bbc: aa1403e1    	mov	x1, x20
101432bc0: 941a41ed    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101432bc4: 52800035    	mov	w21, #0x1               ; =1
101432bc8: aa1503e0    	mov	x0, x21
101432bcc: aa1403e2    	mov	x2, x20
101432bd0: 941a5c16    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101432bd4: a9005674    	stp	x20, x21, [x19]
101432bd8: f9000a74    	str	x20, [x19, #0x10]
101432bdc: a9477bfd    	ldp	x29, x30, [sp, #0x70]
101432be0: a9464ff4    	ldp	x20, x19, [sp, #0x60]
101432be4: a94557f6    	ldp	x22, x21, [sp, #0x50]
101432be8: 910203ff    	add	sp, sp, #0x80
101432bec: d65f03c0    	ret
101432bf0: aa0003f3    	mov	x19, x0
101432bf4: f9400fe1    	ldr	x1, [sp, #0x18]
101432bf8: b4000081    	cbz	x1, 0x101432c08 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x8a8>
101432bfc: f94013e0    	ldr	x0, [sp, #0x20]
101432c00: 52800022    	mov	w2, #0x1                ; =1
101432c04: 97d9aeb6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101432c08: aa1303e0    	mov	x0, x19
101432c0c: 941a5a72    	bl	0x101ac95d4 <_writev+0x101ac95d4>

0000000101432c10 <__ZN17otty_autocomplete6engine28resolve_description_language17h91de86ba33594fbcE>:
101432c10: d10143ff    	sub	sp, sp, #0x50
101432c14: a90257f6    	stp	x22, x21, [sp, #0x20]
101432c18: a9034ff4    	stp	x20, x19, [sp, #0x30]
101432c1c: a9047bfd    	stp	x29, x30, [sp, #0x40]
101432c20: 910103fd    	add	x29, sp, #0x40
101432c24: aa0803f3    	mov	x19, x8
101432c28: 72001c08    	ands	w8, w0, #0xff
101432c2c: 540000e0    	b.eq	0x101432c48 <__ZN17otty_autocomplete6engine28resolve_description_language17h91de86ba33594fbcE+0x38>
101432c30: 7100051f    	cmp	w8, #0x1
101432c34: 54000341    	b.ne	0x101432c9c <__ZN17otty_autocomplete6engine28resolve_description_language17h91de86ba33594fbcE+0x8c>
101432c38: 52800028    	mov	w8, #0x1                ; =1
101432c3c: a900227f    	stp	xzr, x8, [x19]
101432c40: f9000a7f    	str	xzr, [x19, #0x10]
101432c44: 14000020    	b	0x101432cc4 <__ZN17otty_autocomplete6engine28resolve_description_language17h91de86ba33594fbcE+0xb4>
101432c48: f100003f    	cmp	x1, #0x0
101432c4c: 9a8203e9    	csel	x9, xzr, x2, eq
101432c50: 9a9f1420    	csinc	x0, x1, xzr, ne
101432c54: 910023e8    	add	x8, sp, #0x8
101432c58: aa0903e1    	mov	x1, x9
101432c5c: 940f62b6    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
101432c60: a94123e0    	ldp	x0, x8, [sp, #0x10]
101432c64: f100091f    	cmp	x8, #0x2
101432c68: 540000a3    	b.lo	0x101432c7c <__ZN17otty_autocomplete6engine28resolve_description_language17h91de86ba33594fbcE+0x6c>
101432c6c: 79400008    	ldrh	w8, [x0]
101432c70: 528d0f49    	mov	w9, #0x687a             ; =26746
101432c74: 6b09011f    	cmp	w8, w9
101432c78: 54000300    	b.eq	0x101432cd8 <__ZN17otty_autocomplete6engine28resolve_description_language17h91de86ba33594fbcE+0xc8>
101432c7c: 52800028    	mov	w8, #0x1                ; =1
101432c80: a900227f    	stp	xzr, x8, [x19]
101432c84: f9000a7f    	str	xzr, [x19, #0x10]
101432c88: f94007e1    	ldr	x1, [sp, #0x8]
101432c8c: b40001c1    	cbz	x1, 0x101432cc4 <__ZN17otty_autocomplete6engine28resolve_description_language17h91de86ba33594fbcE+0xb4>
101432c90: 52800022    	mov	w2, #0x1                ; =1
101432c94: 97d9ae92    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101432c98: 1400000b    	b	0x101432cc4 <__ZN17otty_autocomplete6engine28resolve_description_language17h91de86ba33594fbcE+0xb4>
101432c9c: 97d9ae95    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101432ca0: 52800040    	mov	w0, #0x2                ; =2
101432ca4: 52800021    	mov	w1, #0x1                ; =1
101432ca8: 97d9ae8c    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101432cac: b4000360    	cbz	x0, 0x101432d18 <__ZN17otty_autocomplete6engine28resolve_description_language17h91de86ba33594fbcE+0x108>
101432cb0: 528d0f48    	mov	w8, #0x687a             ; =26746
101432cb4: 79000008    	strh	w8, [x0]
101432cb8: 52800048    	mov	w8, #0x2                ; =2
101432cbc: a9000268    	stp	x8, x0, [x19]
101432cc0: f9000a68    	str	x8, [x19, #0x10]
101432cc4: a9447bfd    	ldp	x29, x30, [sp, #0x40]
101432cc8: a9434ff4    	ldp	x20, x19, [sp, #0x30]
101432ccc: a94257f6    	ldp	x22, x21, [sp, #0x20]
101432cd0: 910143ff    	add	sp, sp, #0x50
101432cd4: d65f03c0    	ret
101432cd8: aa0003f5    	mov	x21, x0
101432cdc: f94007f4    	ldr	x20, [sp, #0x8]
101432ce0: 97d9ae84    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101432ce4: 52800040    	mov	w0, #0x2                ; =2
101432ce8: 52800021    	mov	w1, #0x1                ; =1
101432cec: 97d9ae7b    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101432cf0: b40001a0    	cbz	x0, 0x101432d24 <__ZN17otty_autocomplete6engine28resolve_description_language17h91de86ba33594fbcE+0x114>
101432cf4: 528d0f48    	mov	w8, #0x687a             ; =26746
101432cf8: 79000008    	strh	w8, [x0]
101432cfc: 52800048    	mov	w8, #0x2                ; =2
101432d00: a9000268    	stp	x8, x0, [x19]
101432d04: f9000a68    	str	x8, [x19, #0x10]
101432d08: aa1503e0    	mov	x0, x21
101432d0c: aa1403e1    	mov	x1, x20
101432d10: b5fffc14    	cbnz	x20, 0x101432c90 <__ZN17otty_autocomplete6engine28resolve_description_language17h91de86ba33594fbcE+0x80>
101432d14: 17ffffec    	b	0x101432cc4 <__ZN17otty_autocomplete6engine28resolve_description_language17h91de86ba33594fbcE+0xb4>
101432d18: 52800020    	mov	w0, #0x1                ; =1
101432d1c: 52800041    	mov	w1, #0x2                ; =2
101432d20: 941a4195    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101432d24: 52800020    	mov	w0, #0x1                ; =1
101432d28: 52800041    	mov	w1, #0x2                ; =2
101432d2c: 941a4192    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101432d30: d4200020    	brk	#0x1
101432d34: aa0003f3    	mov	x19, x0
101432d38: b40000b4    	cbz	x20, 0x101432d4c <__ZN17otty_autocomplete6engine28resolve_description_language17h91de86ba33594fbcE+0x13c>
101432d3c: aa1503e0    	mov	x0, x21
101432d40: aa1403e1    	mov	x1, x20
101432d44: 52800022    	mov	w2, #0x1                ; =1
101432d48: 97d9ae65    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101432d4c: aa1303e0    	mov	x0, x19
101432d50: 941a5a21    	bl	0x101ac95d4 <_writev+0x101ac95d4>
