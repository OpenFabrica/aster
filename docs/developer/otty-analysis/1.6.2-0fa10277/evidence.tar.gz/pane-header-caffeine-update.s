10066b010:     	stp	x28, x27, [sp, #-0x60]!
10066b014:     	stp	x26, x25, [sp, #0x10]
10066b018:     	stp	x24, x23, [sp, #0x20]
10066b01c:     	stp	x22, x21, [sp, #0x30]
10066b020:     	stp	x20, x19, [sp, #0x40]
10066b024:     	stp	x29, x30, [sp, #0x50]
10066b028:     	add	x29, sp, #0x50
10066b02c:     	sub	sp, sp, #0x30
10066b030:     	adrp	x0, 0x102340000
10066b034:     	add	x0, x0, #0xcc0
10066b038:     	adrp	x1, 0x101ae1000
10066b03c:     	add	x1, x1, #0x2d0 ; possible literal '�24'
10066b040:     	bl	0x100003c4c
10066b044:     	stur	x0, [x29, #-0x68]
10066b048:     	ldur	x8, [x0, #-0x8]
10066b04c:     	ldr	x8, [x8, #0x40]
10066b050:     	mov	x9, x8
10066b054:     	adrp	x16, 0x1022cb000
10066b058:     	ldr	x16, [x16, #0x398]
10066b05c:     	blr	x16
10066b060:     	mov	x9, sp
10066b064:     	add	x10, x8, #0xf
10066b068:     	and	x12, x10, #0xfffffffffffffff0
10066b06c:     	sub	x9, x9, x12
10066b070:     	stur	x9, [x29, #-0x70]
10066b074:     	mov	sp, x9
10066b078:     	mov	x9, x8
10066b07c:     	adrp	x16, 0x1022cb000
10066b080:     	ldr	x16, [x16, #0x398]
10066b084:     	blr	x16
10066b088:     	mov	x8, sp
10066b08c:     	sub	x26, x8, x12
10066b090:     	mov	sp, x26
10066b094:     	ldr	x20, [x20, #0x18]
10066b098:     	ldr	x8, [x20]
10066b09c:     	ldr	x8, [x8, #0x90]
10066b0a0:     	blr	x8
10066b0a4:     	mov	x28, #0x0               ; =0
10066b0a8:     	mov	x25, x0
10066b0ac:     	ldr	x8, [x25, #0x40]!
10066b0b0:     	stur	x0, [x29, #-0x60]
10066b0b4:     	ldrb	w9, [x0, #0x20]
10066b0b8:     	and	x10, x9, #0x3f
10066b0bc:     	mov	w11, #0x1               ; =1
10066b0c0:     	lsl	x9, x11, x9
10066b0c4:     	mov	x11, #-0x1              ; =-1
10066b0c8:     	cmp	w10, #0x6
10066b0cc:     	lsl	x10, x11, x9
10066b0d0:     	csinv	x10, x11, x10, hs
10066b0d4:     	and	x21, x10, x8
10066b0d8:     	add	x8, x9, #0x3f
10066b0dc:     	lsr	x19, x8, #6
10066b0e0:     	stur	x26, [x29, #-0x78]
10066b0e4:     	b	0x10066b12c
10066b0e8:     	ldr	x27, [x26, x22]
10066b0ec:     	ldr	x8, [x27]
10066b0f0:     	ldr	x22, [x8, #0x9c8]
10066b0f4:     	ldur	x0, [x29, #-0x58]
10066b0f8:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066b0fc:     	mov	x0, x27
10066b100:     	bl	0x101aca978 ; symbol _swift_retain
10066b104:     	mov	x20, x27
10066b108:     	blr	x22
10066b10c:     	mov	x0, x27
10066b110:     	bl	0x101aca960 ; symbol _swift_release
10066b114:     	sub	x8, x21, #0x1
10066b118:     	and	x21, x8, x21
10066b11c:     	mov	x0, x26
10066b120:     	mov	x1, x24
10066b124:     	mov	x2, x23
10066b128:     	bl	0x10002d870
10066b12c:     	cbnz	x21, 0x10066b148
10066b130:     	adds	x28, x28, #0x1
10066b134:     	b.vs	0x10066b20c
10066b138:     	cmp	x28, x19
10066b13c:     	b.ge	0x10066b1e4
10066b140:     	ldr	x21, [x25, x28, lsl #3]
10066b144:     	cbz	x21, 0x10066b130
10066b148:     	rbit	x8, x21
10066b14c:     	clz	x8, x8
10066b150:     	orr	x22, x8, x28, lsl #6
10066b154:     	ldp	x20, x9, [x29, #-0x68]
10066b158:     	ldp	x8, x26, [x9, #0x30]
10066b15c:     	add	x8, x8, x22, lsl #4
10066b160:     	ldp	x9, x8, [x8]
10066b164:     	ldur	x23, [x29, #-0x70]
10066b168:     	stp	x9, x8, [x23]
10066b16c:     	stur	x8, [x29, #-0x58]
10066b170:     	ldrsw	x24, [x20, #0x30]
10066b174:     	mov	x0, #0x0                ; =0
10066b178:     	bl	0x10068c794
10066b17c:     	mov	x27, x0
10066b180:     	ldur	x8, [x0, #-0x8]
10066b184:     	ldr	x8, [x8, #0x48]
10066b188:     	madd	x0, x8, x22, x26
10066b18c:     	add	x1, x23, x24
10066b190:     	adrp	x2, 0x10068c000
10066b194:     	add	x2, x2, #0x794 ; possible literal '��'
10066b198:     	bl	0x1000e73b0
10066b19c:     	mov	x0, x23
10066b1a0:     	ldur	x26, [x29, #-0x78]
10066b1a4:     	mov	x1, x26
10066b1a8:     	adrp	x24, 0x102340000
10066b1ac:     	add	x24, x24, #0xcc0
10066b1b0:     	mov	x2, x24
10066b1b4:     	adrp	x23, 0x101ae1000
10066b1b8:     	add	x23, x23, #0x2d0 ; possible literal '�24'
10066b1bc:     	mov	x3, x23
10066b1c0:     	bl	0x1000a1424
10066b1c4:     	ldrsw	x22, [x20, #0x30]
10066b1c8:     	add	x0, x26, x22
10066b1cc:     	mov	x1, x27
10066b1d0:     	bl	0x101aca78c ; symbol _swift_getEnumCaseMultiPayload
10066b1d4:     	cbz	w0, 0x10066b0e8
10066b1d8:     	ldur	x0, [x29, #-0x58]
10066b1dc:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066b1e0:     	b	0x10066b114
10066b1e4:     	ldur	x0, [x29, #-0x60]
10066b1e8:     	bl	0x101aca960 ; symbol _swift_release
10066b1ec:     	sub	sp, x29, #0x50
10066b1f0:     	ldp	x29, x30, [sp, #0x50]
10066b1f4:     	ldp	x20, x19, [sp, #0x40]
10066b1f8:     	ldp	x22, x21, [sp, #0x30]
10066b1fc:     	ldp	x24, x23, [sp, #0x20]
10066b200:     	ldp	x26, x25, [sp, #0x10]
10066b204:     	ldp	x28, x27, [sp], #0x60
10066b208:     	ret
10066b20c:     	brk	#0x1
10066b210:     	sub	sp, sp, #0x70
10066b214:     	stp	x24, x23, [sp, #0x30]
10066b218:     	stp	x22, x21, [sp, #0x40]
10066b21c:     	stp	x20, x19, [sp, #0x50]
10066b220:     	stp	x29, x30, [sp, #0x60]
10066b224:     	add	x29, sp, #0x60
10066b228:     	adrp	x8, 0x1023da000
10066b22c:     	ldr	x21, [x8, #0x330]
10066b230:     	add	x0, x20, x21
10066b234:     	add	x1, sp, #0x18
10066b238:     	mov	x2, #0x0                ; =0
10066b23c:     	mov	x3, #0x0                ; =0
10066b240:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066b244:     	ldr	x0, [x20, x21]
10066b248:     	cbz	x0, 0x10066b250
10066b24c:     	bl	0x101aceba0 ; selector invalidate
10066b250:     	ldr	x8, [x20]
10066b254:     	ldr	x8, [x8, #0x4c0]
10066b258:     	blr	x8
10066b25c:     	ldr	x8, [x20]
10066b260:     	ldr	x8, [x8, #0x5c8]
10066b264:     	blr	x8
10066b268:     	ldr	x0, [x20, #0x18]
10066b26c:     	bl	0x101aca960 ; symbol _swift_release
10066b270:     	adrp	x8, 0x1023da000
10066b274:     	ldr	x22, [x8, #0x2e0]
10066b278:     	mov	x0, #0x0                ; =0
10066b27c:     	bl	0x101ac4fd8 ; symbol _$s10Foundation4DateVMa
10066b280:     	mov	x19, x0
10066b284:     	ldur	x8, [x0, #-0x8]
10066b288:     	ldr	x23, [x8, #0x8]
10066b28c:     	add	x0, x20, x22
10066b290:     	mov	x1, x19
10066b294:     	blr	x23
10066b298:     	adrp	x8, 0x1023a8000
10066b29c:     	ldr	x8, [x8, #0x2c8]
10066b2a0:     	adrp	x1, 0x102341000
10066b2a4:     	add	x1, x1, #0x790
10066b2a8:     	adrp	x2, 0x101ae1000
10066b2ac:     	add	x2, x2, #0xd90 ; possible literal '�/4'
10066b2b0:     	add	x0, x20, x8
10066b2b4:     	bl	0x10002d870
10066b2b8:     	adrp	x8, 0x1023da000
10066b2bc:     	ldr	x8, [x8, #0x2e8]
10066b2c0:     	add	x0, x20, x8
10066b2c4:     	mov	x1, x19
10066b2c8:     	blr	x23
10066b2cc:     	adrp	x8, 0x1023da000
10066b2d0:     	ldr	x8, [x8, #0x2f8]
10066b2d4:     	add	x8, x20, x8
10066b2d8:     	ldr	x0, [x8, #0x8]
10066b2dc:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b2e0:     	adrp	x8, 0x1023da000
10066b2e4:     	ldr	x8, [x8, #0x308]
10066b2e8:     	add	x8, x20, x8
10066b2ec:     	ldr	x0, [x8, #0x8]
10066b2f0:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b2f4:     	adrp	x8, 0x1023da000
10066b2f8:     	ldr	x8, [x8, #0x318]
10066b2fc:     	adrp	x1, 0x10235e000
10066b300:     	add	x1, x1, #0xe58
10066b304:     	adrp	x2, 0x101afc000
10066b308:     	add	x2, x2, #0x940 ; possible literal '@q3'
10066b30c:     	add	x0, x20, x8
10066b310:     	bl	0x10002d870
10066b314:     	adrp	x8, 0x1023da000
10066b318:     	ldr	x8, [x8, #0x320]
10066b31c:     	ldr	x0, [x20, x8]
10066b320:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b324:     	ldr	x0, [x20, x21]
10066b328:     	bl	0x101ac9d30 ; symbol _objc_release
10066b32c:     	adrp	x8, 0x1023da000
10066b330:     	ldr	x8, [x8, #0x360]
10066b334:     	ldr	x0, [x20, x8]
10066b338:     	bl	0x101aca960 ; symbol _swift_release
10066b33c:     	adrp	x8, 0x1023da000
10066b340:     	ldr	x8, [x8, #0x368]
10066b344:     	add	x8, x20, x8
10066b348:     	ldr	x0, [x8, #0x8]
10066b34c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b350:     	adrp	x8, 0x1023da000
10066b354:     	ldr	x8, [x8, #0x378]
10066b358:     	add	x8, x20, x8
10066b35c:     	ldr	x19, [x8, #0x8]
10066b360:     	ldr	x21, [x8, #0x18]
10066b364:     	ldr	x22, [x8, #0x28]
10066b368:     	ldr	x0, [x8, #0x38]
10066b36c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b370:     	mov	x0, x22
10066b374:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b378:     	mov	x0, x21
10066b37c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b380:     	mov	x0, x19
10066b384:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b388:     	adrp	x8, 0x1023da000
10066b38c:     	ldr	x8, [x8, #0x380]
10066b390:     	adrp	x1, 0x10235e000
10066b394:     	add	x1, x1, #0xdd8
10066b398:     	adrp	x2, 0x101afc000
10066b39c:     	add	x2, x2, #0x918 ; possible literal '<q3'
10066b3a0:     	add	x0, x20, x8
10066b3a4:     	bl	0x10002d870
10066b3a8:     	adrp	x8, 0x1023a8000
10066b3ac:     	ldr	x8, [x8, #0x2d8]
10066b3b0:     	ldr	x0, [x20, x8]
10066b3b4:     	bl	0x101ac9d30 ; symbol _objc_release
10066b3b8:     	adrp	x8, 0x1023a8000
10066b3bc:     	ldr	x8, [x8, #0x2e0]
10066b3c0:     	ldr	x0, [x20, x8]
10066b3c4:     	bl	0x101ac9d30 ; symbol _objc_release
10066b3c8:     	adrp	x8, 0x1023a8000
10066b3cc:     	ldr	x8, [x8, #0x2e8]
10066b3d0:     	ldr	x0, [x20, x8]
10066b3d4:     	bl	0x101ac9d30 ; symbol _objc_release
10066b3d8:     	adrp	x8, 0x1023a8000
10066b3dc:     	ldr	x8, [x8, #0x2f0]
10066b3e0:     	ldr	x0, [x20, x8]
10066b3e4:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b3e8:     	adrp	x8, 0x1023a8000
10066b3ec:     	ldr	x8, [x8, #0x2d0]
10066b3f0:     	ldr	x0, [x20, x8]
10066b3f4:     	bl	0x101ac9d30 ; symbol _objc_release
10066b3f8:     	adrp	x8, 0x1023da000
10066b3fc:     	ldr	x8, [x8, #0x390]
10066b400:     	add	x8, x20, x8
10066b404:     	ldp	x0, x1, [x8]
10066b408:     	ldp	x2, x3, [x8, #0x10]
10066b40c:     	ldp	x4, x5, [x8, #0x20]
10066b410:     	ldp	x6, x7, [x8, #0x30]
10066b414:     	ldp	x9, x10, [x8, #0x40]
10066b418:     	ldrb	w8, [x8, #0x50]
10066b41c:     	strb	w8, [sp, #0x10]
10066b420:     	stp	x9, x10, [sp]
10066b424:     	bl	0x10068d274
10066b428:     	adrp	x8, 0x1023da000
10066b42c:     	ldr	x8, [x8, #0x3c8]
10066b430:     	add	x8, x20, x8
10066b434:     	ldr	x0, [x8, #0x8]
10066b438:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b43c:     	adrp	x8, 0x1023da000
10066b440:     	ldr	x8, [x8, #0x3d0]
10066b444:     	add	x8, x20, x8
10066b448:     	ldr	x0, [x8, #0x8]
10066b44c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b450:     	adrp	x8, 0x1023da000
10066b454:     	ldr	x8, [x8, #0x3d8]
10066b458:     	add	x8, x20, x8
10066b45c:     	ldr	x0, [x8, #0x8]
10066b460:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b464:     	mov	x0, x20
10066b468:     	ldp	x29, x30, [sp, #0x60]
10066b46c:     	ldp	x20, x19, [sp, #0x50]
10066b470:     	ldp	x22, x21, [sp, #0x40]
10066b474:     	ldp	x24, x23, [sp, #0x30]
10066b478:     	add	sp, sp, #0x70
10066b47c:     	ret
10066b480:     	adrp	x0, 0x10066b000
10066b484:     	add	x0, x0, #0x210
10066b488:     	b	0x10066f718
10066b48c:     	sub	sp, sp, #0xa0
10066b490:     	stp	x28, x27, [sp, #0x40]
10066b494:     	stp	x26, x25, [sp, #0x50]
10066b498:     	stp	x24, x23, [sp, #0x60]
10066b49c:     	stp	x22, x21, [sp, #0x70]
10066b4a0:     	stp	x20, x19, [sp, #0x80]
10066b4a4:     	stp	x29, x30, [sp, #0x90]
10066b4a8:     	add	x29, sp, #0x90
10066b4ac:     	mov	x22, x20
10066b4b0:     	adrp	x8, 0x1022cb000
10066b4b4:     	ldr	x8, [x8, #0x3c8]
10066b4b8:     	ldr	x8, [x8]
10066b4bc:     	str	x8, [sp, #0x38]
10066b4c0:     	ldr	x8, [x20]
10066b4c4:     	ldr	x8, [x8, #0x578]
10066b4c8:     	blr	x8
10066b4cc:     	tbz	w0, #0x0, 0x10066b4d8
10066b4d0:     	mov	w21, #0x0               ; =0
10066b4d4:     	b	0x10066b9e0
10066b4d8:     	mov	x25, #0x12              ; =18
10066b4dc:     	movk	x25, #0xd000, lsl #48
10066b4e0:     	mov	x19, #0x6143            ; =24899
10066b4e4:     	movk	x19, #0x6666, lsl #16
10066b4e8:     	movk	x19, #0x6965, lsl #32
10066b4ec:     	movk	x19, #0x616e, lsl #48
10066b4f0:     	str	wzr, [sp, #0x1c]
10066b4f4:     	adrp	x8, 0x101de2000
10066b4f8:     	add	x8, x8, #0xcf0 ; possible literal 'PreventUserIdleSystemSleep'
10066b4fc:     	sub	x8, x8, #0x20
10066b500:     	orr	x0, x25, #0x8
10066b504:     	orr	x1, x8, #0x8000000000000000
10066b508:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
10066b50c:     	mov	x20, x0
10066b510:     	adrp	x8, 0x101de2000
10066b514:     	add	x8, x8, #0xd10 ; possible literal 'Otty: task running with caffeinate'
10066b518:     	sub	x8, x8, #0x20
10066b51c:     	add	x0, x25, #0x10
10066b520:     	orr	x1, x8, #0x8000000000000000
10066b524:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
10066b528:     	mov	x21, x0
10066b52c:     	add	x3, sp, #0x1c
10066b530:     	mov	x0, x20
10066b534:     	mov	w1, #0xff               ; =255
10066b538:     	mov	x2, x21
10066b53c:     	bl	0x101ac9370
10066b540:     	mov	x23, x0
10066b544:     	mov	x0, x20
10066b548:     	bl	0x101ac9d30 ; symbol _objc_release
10066b54c:     	mov	x0, x21
10066b550:     	bl	0x101ac9d30 ; symbol _objc_release
10066b554:     	cmp	w23, #0x0
10066b558:     	cset	w21, eq
10066b55c:     	cbz	w23, 0x10066b610
10066b560:     	mov	x8, #-0x2000000000000000 ; =-2305843009213693952
10066b564:     	stp	xzr, x8, [sp, #0x20]
10066b568:     	add	x20, sp, #0x20
10066b56c:     	mov	w0, #0x1f               ; =31
10066b570:     	bl	0x101ac757c ; symbol _$ss11_StringGutsV4growyySiF
10066b574:     	ldr	x0, [sp, #0x28]
10066b578:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b57c:     	adrp	x8, 0x101de2000
10066b580:     	add	x8, x8, #0xd40 ; possible literal 'acquire FAILED tab='
10066b584:     	sub	x8, x8, #0x20
10066b588:     	orr	x8, x8, #0x8000000000000000
10066b58c:     	add	x9, x25, #0x1
10066b590:     	stp	x9, x8, [sp, #0x20]
10066b594:     	ldr	x8, [x22]
10066b598:     	ldr	x8, [x8, #0x698]
10066b59c:     	mov	x20, x22
10066b5a0:     	blr	x8
10066b5a4:     	mov	x22, x1
10066b5a8:     	add	x20, sp, #0x20
10066b5ac:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b5b0:     	mov	x0, x22
10066b5b4:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b5b8:     	mov	x0, #0x7220             ; =29216
10066b5bc:     	movk	x0, #0x7365, lsl #16
10066b5c0:     	movk	x0, #0x6c75, lsl #32
10066b5c4:     	movk	x0, #0x3d74, lsl #48
10066b5c8:     	add	x20, sp, #0x20
10066b5cc:     	mov	x1, #-0x1800000000000000 ; =-1729382256910270464
10066b5d0:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b5d4:     	str	w23, [sp, #0x8]
10066b5d8:     	adrp	x0, 0x1022cf000
10066b5dc:     	ldr	x0, [x0, #0xb8]
10066b5e0:     	adrp	x1, 0x1022cf000
10066b5e4:     	ldr	x1, [x1, #0xc8]
10066b5e8:     	add	x20, sp, #0x8
10066b5ec:     	bl	0x101ac7bb8 ; symbol _$ss23CustomStringConvertibleP11descriptionSSvgTj
10066b5f0:     	mov	x22, x1
10066b5f4:     	add	x20, sp, #0x20
10066b5f8:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b5fc:     	mov	x0, x22
10066b600:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b604:     	ldp	x2, x20, [sp, #0x20]
10066b608:     	mov	x0, x19
10066b60c:     	b	0x10066b9c8
10066b610:     	ldr	w8, [sp, #0x1c]
10066b614:     	adrp	x9, 0x1023a8000
10066b618:     	ldr	x9, [x9, #0x2f8]
10066b61c:     	str	w8, [x22, x9]
10066b620:     	str	wzr, [sp, #0x18]
10066b624:     	adrp	x8, 0x101de2000
10066b628:     	add	x8, x8, #0xd60 ; possible literal 'PreventSystemSleep'
10066b62c:     	sub	x8, x8, #0x20
10066b630:     	orr	x1, x8, #0x8000000000000000
10066b634:     	mov	x0, #0x12               ; =18
10066b638:     	movk	x0, #0xd000, lsl #48
10066b63c:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
10066b640:     	mov	x20, x0
10066b644:     	adrp	x8, 0x101de2000
10066b648:     	add	x8, x8, #0xd80 ; possible literal 'Otty: task running with caffeinate (lid closed)'
10066b64c:     	sub	x8, x8, #0x20
10066b650:     	add	x0, x25, #0x1d
10066b654:     	orr	x1, x8, #0x8000000000000000
10066b658:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
10066b65c:     	mov	x24, x0
10066b660:     	add	x3, sp, #0x18
10066b664:     	mov	x0, x20
10066b668:     	mov	w1, #0xff               ; =255
10066b66c:     	mov	x2, x24
10066b670:     	bl	0x101ac9370
10066b674:     	mov	x23, x0
10066b678:     	mov	x0, x20
10066b67c:     	bl	0x101ac9d30 ; symbol _objc_release
10066b680:     	mov	x0, x24
10066b684:     	bl	0x101ac9d30 ; symbol _objc_release
10066b688:     	adrp	x9, 0x1023a8000
10066b68c:     	cbz	w23, 0x10066b758
10066b690:     	mov	x8, #-0x2000000000000000 ; =-2305843009213693952
10066b694:     	stp	xzr, x8, [sp, #0x20]
10066b698:     	add	x20, sp, #0x20
10066b69c:     	mov	w0, #0x28               ; =40
10066b6a0:     	bl	0x101ac757c ; symbol _$ss11_StringGutsV4growyySiF
10066b6a4:     	ldr	x0, [sp, #0x28]
10066b6a8:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b6ac:     	adrp	x8, 0x101de2000
10066b6b0:     	add	x8, x8, #0xdb0 ; possible literal 'system assertion FAILED tab='
10066b6b4:     	sub	x8, x8, #0x20
10066b6b8:     	orr	x8, x8, #0x8000000000000000
10066b6bc:     	add	x9, x25, #0xa
10066b6c0:     	stp	x9, x8, [sp, #0x20]
10066b6c4:     	ldr	x8, [x22]
10066b6c8:     	ldr	x8, [x8, #0x698]
10066b6cc:     	mov	x20, x22
10066b6d0:     	blr	x8
10066b6d4:     	mov	x24, x1
10066b6d8:     	add	x20, sp, #0x20
10066b6dc:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b6e0:     	mov	x0, x24
10066b6e4:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b6e8:     	mov	x0, #0x7220             ; =29216
10066b6ec:     	movk	x0, #0x7365, lsl #16
10066b6f0:     	movk	x0, #0x6c75, lsl #32
10066b6f4:     	movk	x0, #0x3d74, lsl #48
10066b6f8:     	add	x20, sp, #0x20
10066b6fc:     	mov	x1, #-0x1800000000000000 ; =-1729382256910270464
10066b700:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b704:     	str	w23, [sp, #0x8]
10066b708:     	adrp	x0, 0x1022cf000
10066b70c:     	ldr	x0, [x0, #0xb8]
10066b710:     	adrp	x1, 0x1022cf000
10066b714:     	ldr	x1, [x1, #0xc8]
10066b718:     	add	x20, sp, #0x8
10066b71c:     	bl	0x101ac7bb8 ; symbol _$ss23CustomStringConvertibleP11descriptionSSvgTj
10066b720:     	mov	x23, x1
10066b724:     	add	x20, sp, #0x20
10066b728:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b72c:     	mov	x0, x23
10066b730:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b734:     	ldp	x2, x20, [sp, #0x20]
10066b738:     	mov	x0, x19
10066b73c:     	mov	x1, #0x6574             ; =25972
10066b740:     	movk	x1, #0xea00, lsl #48
10066b744:     	mov	x3, x20
10066b748:     	bl	0x100152e08
10066b74c:     	mov	x0, x20
10066b750:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b754:     	b	0x10066b764
10066b758:     	ldr	w8, [sp, #0x18]
10066b75c:     	ldr	x9, [x9, #0x300]
10066b760:     	str	w8, [x22, x9]
10066b764:     	adrp	x8, 0x1023da000
10066b768:     	ldr	x19, [x8, #0x3b0]
10066b76c:     	mov	w20, #0x1               ; =1
10066b770:     	add	x0, x22, x19
10066b774:     	add	x1, sp, #0x20
10066b778:     	mov	w2, #0x1                ; =1
10066b77c:     	mov	x3, #0x0                ; =0
10066b780:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066b784:     	strb	w20, [x22, x19]
10066b788:     	ldr	x8, [x22]
10066b78c:     	ldr	x27, [x8, #0x370]
10066b790:     	mov	x20, x22
10066b794:     	blr	x27
10066b798:     	mov	x20, x0
10066b79c:     	ldr	x8, [x0]
10066b7a0:     	ldr	x8, [x8, #0x238]
10066b7a4:     	blr	x8
10066b7a8:     	mov	x23, x0
10066b7ac:     	mov	x0, x20
10066b7b0:     	bl	0x101aca960 ; symbol _swift_release
10066b7b4:     	tbz	w23, #0x0, 0x10066b7d8
10066b7b8:     	bl	0x10013a308
10066b7bc:     	ldr	x20, [x0]
10066b7c0:     	mov	x0, x20
10066b7c4:     	bl	0x101aca978 ; symbol _swift_retain
10066b7c8:     	mov	x0, x22
10066b7cc:     	bl	0x10013ad60
10066b7d0:     	mov	x0, x20
10066b7d4:     	bl	0x101aca960 ; symbol _swift_release
10066b7d8:     	mov	x8, #-0x2000000000000000 ; =-2305843009213693952
10066b7dc:     	stp	xzr, x8, [sp, #0x8]
10066b7e0:     	add	x20, sp, #0x8
10066b7e4:     	mov	w0, #0x35               ; =53
10066b7e8:     	bl	0x101ac757c ; symbol _$ss11_StringGutsV4growyySiF
10066b7ec:     	ldp	x8, x9, [sp, #0x8]
10066b7f0:     	stp	x8, x9, [sp, #0x8]
10066b7f4:     	mov	x0, #0x6361             ; =25441
10066b7f8:     	movk	x0, #0x7571, lsl #16
10066b7fc:     	movk	x0, #0x7269, lsl #32
10066b800:     	movk	x0, #0x2065, lsl #48
10066b804:     	mov	x1, #0x6174             ; =24948
10066b808:     	movk	x1, #0x3d62, lsl #16
10066b80c:     	movk	x1, #0xec00, lsl #48
10066b810:     	add	x20, sp, #0x8
10066b814:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b818:     	ldr	x8, [x22]
10066b81c:     	ldr	x8, [x8, #0x698]
10066b820:     	mov	x20, x22
10066b824:     	blr	x8
10066b828:     	mov	x23, x1
10066b82c:     	add	x20, sp, #0x8
10066b830:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b834:     	mov	x0, x23
10066b838:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b83c:     	mov	x0, #0x7020             ; =28704
10066b840:     	movk	x0, #0x7265, lsl #16
10066b844:     	movk	x0, #0x6973, lsl #32
10066b848:     	movk	x0, #0x7473, lsl #48
10066b84c:     	mov	x1, #0x6e65             ; =28261
10066b850:     	movk	x1, #0x3d74, lsl #16
10066b854:     	movk	x1, #0xec00, lsl #48
10066b858:     	add	x20, sp, #0x8
10066b85c:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b860:     	ldr	x8, [x22]
10066b864:     	ldr	x8, [x8, #0x518]
10066b868:     	mov	x20, x22
10066b86c:     	blr	x8
10066b870:     	tst	w0, #0x1
10066b874:     	mov	w8, #0x7274             ; =29300
10066b878:     	movk	w8, #0x6575, lsl #16
10066b87c:     	mov	x26, #0x6166            ; =24934
10066b880:     	movk	x26, #0x736c, lsl #16
10066b884:     	movk	x26, #0x65, lsl #32
10066b888:     	csel	x0, x8, x26, ne
10066b88c:     	mov	x19, #-0x1b00000000000000 ; =-1945555039024054272
10066b890:     	mov	x28, #-0x1c00000000000000 ; =-2017612633061982208
10066b894:     	csel	x23, x28, x19, ne
10066b898:     	add	x20, sp, #0x8
10066b89c:     	mov	x1, x23
10066b8a0:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b8a4:     	mov	x0, x23
10066b8a8:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b8ac:     	mov	x0, #0x6920             ; =26912
10066b8b0:     	movk	x0, #0x6c64, lsl #16
10066b8b4:     	movk	x0, #0x3d65, lsl #32
10066b8b8:     	add	x20, sp, #0x8
10066b8bc:     	mov	x1, #-0x1a00000000000000 ; =-1873497444986126336
10066b8c0:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b8c4:     	ldr	w8, [sp, #0x1c]
10066b8c8:     	str	w8, [sp, #0x4]
10066b8cc:     	adrp	x23, 0x1022cf000
10066b8d0:     	ldr	x23, [x23, #0x2b8]
10066b8d4:     	adrp	x24, 0x1022cf000
10066b8d8:     	ldr	x24, [x24, #0x2c8]
10066b8dc:     	add	x20, sp, #0x4
10066b8e0:     	mov	x0, x23
10066b8e4:     	mov	x1, x24
10066b8e8:     	bl	0x101ac7bb8 ; symbol _$ss23CustomStringConvertibleP11descriptionSSvgTj
10066b8ec:     	mov	x25, x1
10066b8f0:     	add	x20, sp, #0x8
10066b8f4:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b8f8:     	mov	x0, x25
10066b8fc:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b900:     	mov	x0, #0x7320             ; =29472
10066b904:     	movk	x0, #0x7379, lsl #16
10066b908:     	movk	x0, #0x6574, lsl #32
10066b90c:     	movk	x0, #0x3d6d, lsl #48
10066b910:     	add	x20, sp, #0x8
10066b914:     	mov	x1, #-0x1800000000000000 ; =-1729382256910270464
10066b918:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b91c:     	adrp	x8, 0x1023a8000
10066b920:     	ldr	x8, [x8, #0x300]
10066b924:     	ldr	w8, [x22, x8]
10066b928:     	str	w8, [sp, #0x4]
10066b92c:     	add	x20, sp, #0x4
10066b930:     	mov	x0, x23
10066b934:     	mov	x1, x24
10066b938:     	bl	0x101ac7bb8 ; symbol _$ss23CustomStringConvertibleP11descriptionSSvgTj
10066b93c:     	mov	x23, x1
10066b940:     	add	x20, sp, #0x8
10066b944:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b948:     	mov	x0, x23
10066b94c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b950:     	mov	x0, #0x6c20             ; =27680
10066b954:     	movk	x0, #0x6469, lsl #16
10066b958:     	movk	x0, #0x3d, lsl #32
10066b95c:     	add	x20, sp, #0x8
10066b960:     	mov	x1, #-0x1b00000000000000 ; =-1945555039024054272
10066b964:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b968:     	mov	x20, x22
10066b96c:     	blr	x27
10066b970:     	mov	x20, x0
10066b974:     	ldr	x8, [x0]
10066b978:     	ldr	x8, [x8, #0x238]
10066b97c:     	blr	x8
10066b980:     	mov	x22, x0
10066b984:     	mov	x0, x20
10066b988:     	bl	0x101aca960 ; symbol _swift_release
10066b98c:     	tst	w22, #0x1
10066b990:     	mov	w8, #0x7274             ; =29300
10066b994:     	movk	w8, #0x6575, lsl #16
10066b998:     	csel	x0, x8, x26, ne
10066b99c:     	csel	x22, x28, x19, ne
10066b9a0:     	add	x20, sp, #0x8
10066b9a4:     	mov	x1, x22
10066b9a8:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066b9ac:     	mov	x0, x22
10066b9b0:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b9b4:     	ldp	x2, x20, [sp, #0x8]
10066b9b8:     	mov	x0, #0x6143             ; =24899
10066b9bc:     	movk	x0, #0x6666, lsl #16
10066b9c0:     	movk	x0, #0x6965, lsl #32
10066b9c4:     	movk	x0, #0x616e, lsl #48
10066b9c8:     	mov	x1, #0x6574             ; =25972
10066b9cc:     	movk	x1, #0xea00, lsl #48
10066b9d0:     	mov	x3, x20
10066b9d4:     	bl	0x100152e08
10066b9d8:     	mov	x0, x20
10066b9dc:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066b9e0:     	ldr	x8, [sp, #0x38]
10066b9e4:     	adrp	x9, 0x1022cb000
10066b9e8:     	ldr	x9, [x9, #0x3c8]
10066b9ec:     	ldr	x9, [x9]
10066b9f0:     	cmp	x9, x8
10066b9f4:     	b.ne	0x10066ba1c
10066b9f8:     	mov	x0, x21
10066b9fc:     	ldp	x29, x30, [sp, #0x90]
10066ba00:     	ldp	x20, x19, [sp, #0x80]
10066ba04:     	ldp	x22, x21, [sp, #0x70]
10066ba08:     	ldp	x24, x23, [sp, #0x60]
10066ba0c:     	ldp	x26, x25, [sp, #0x50]
10066ba10:     	ldp	x28, x27, [sp, #0x40]
10066ba14:     	add	sp, sp, #0xa0
10066ba18:     	ret
10066ba1c:     	bl	0x101ac964c
10066ba20:     	sub	sp, sp, #0x70
10066ba24:     	stp	x26, x25, [sp, #0x20]
10066ba28:     	stp	x24, x23, [sp, #0x30]
10066ba2c:     	stp	x22, x21, [sp, #0x40]
10066ba30:     	stp	x20, x19, [sp, #0x50]
10066ba34:     	stp	x29, x30, [sp, #0x60]
10066ba38:     	add	x29, sp, #0x60
10066ba3c:     	mov	x19, x20
10066ba40:     	ldr	x8, [x20]
10066ba44:     	ldr	x8, [x8, #0x578]
10066ba48:     	blr	x8
10066ba4c:     	mov	x21, x0
10066ba50:     	tbz	w0, #0x0, 0x10066bbe8
10066ba54:     	mov	x8, #-0x2000000000000000 ; =-2305843009213693952
10066ba58:     	stp	xzr, x8, [sp]
10066ba5c:     	mov	x20, sp
10066ba60:     	mov	w0, #0x20               ; =32
10066ba64:     	bl	0x101ac757c ; symbol _$ss11_StringGutsV4growyySiF
10066ba68:     	ldr	x0, [sp, #0x8]
10066ba6c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066ba70:     	mov	x8, #0x6572             ; =25970
10066ba74:     	movk	x8, #0x656c, lsl #16
10066ba78:     	movk	x8, #0x7361, lsl #32
10066ba7c:     	movk	x8, #0x2065, lsl #48
10066ba80:     	mov	x9, #0x6174             ; =24948
10066ba84:     	movk	x9, #0x3d62, lsl #16
10066ba88:     	movk	x9, #0xec00, lsl #48
10066ba8c:     	stp	x8, x9, [sp]
10066ba90:     	ldr	x8, [x19]
10066ba94:     	ldr	x8, [x8, #0x698]
10066ba98:     	mov	x20, x19
10066ba9c:     	blr	x8
10066baa0:     	mov	x22, x1
10066baa4:     	mov	x20, sp
10066baa8:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066baac:     	mov	x0, x22
10066bab0:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066bab4:     	mov	x0, #0x6920             ; =26912
10066bab8:     	movk	x0, #0x6c64, lsl #16
10066babc:     	movk	x0, #0x3d65, lsl #32
10066bac0:     	mov	x20, sp
10066bac4:     	mov	x1, #-0x1a00000000000000 ; =-1873497444986126336
10066bac8:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066bacc:     	adrp	x8, 0x1023a8000
10066bad0:     	ldr	x25, [x8, #0x2f8]
10066bad4:     	ldr	w8, [x19, x25]
10066bad8:     	str	w8, [sp, #0x1c]
10066badc:     	adrp	x22, 0x1022cf000
10066bae0:     	ldr	x22, [x22, #0x2b8]
10066bae4:     	adrp	x23, 0x1022cf000
10066bae8:     	ldr	x23, [x23, #0x2c8]
10066baec:     	add	x20, sp, #0x1c
10066baf0:     	mov	x0, x22
10066baf4:     	mov	x1, x23
10066baf8:     	bl	0x101ac7bb8 ; symbol _$ss23CustomStringConvertibleP11descriptionSSvgTj
10066bafc:     	mov	x24, x1
10066bb00:     	mov	x20, sp
10066bb04:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066bb08:     	mov	x0, x24
10066bb0c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066bb10:     	mov	x0, #0x7320             ; =29472
10066bb14:     	movk	x0, #0x7379, lsl #16
10066bb18:     	movk	x0, #0x6574, lsl #32
10066bb1c:     	movk	x0, #0x3d6d, lsl #48
10066bb20:     	mov	x20, sp
10066bb24:     	mov	x1, #-0x1800000000000000 ; =-1729382256910270464
10066bb28:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066bb2c:     	adrp	x8, 0x1023a8000
10066bb30:     	ldr	x24, [x8, #0x300]
10066bb34:     	ldr	w8, [x19, x24]
10066bb38:     	str	w8, [sp, #0x1c]
10066bb3c:     	add	x20, sp, #0x1c
10066bb40:     	mov	x0, x22
10066bb44:     	mov	x1, x23
10066bb48:     	bl	0x101ac7bb8 ; symbol _$ss23CustomStringConvertibleP11descriptionSSvgTj
10066bb4c:     	mov	x22, x1
10066bb50:     	mov	x20, sp
10066bb54:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10066bb58:     	mov	x0, x22
10066bb5c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066bb60:     	ldp	x2, x20, [sp]
10066bb64:     	mov	x0, #0x6143             ; =24899
10066bb68:     	movk	x0, #0x6666, lsl #16
10066bb6c:     	movk	x0, #0x6965, lsl #32
10066bb70:     	movk	x0, #0x616e, lsl #48
10066bb74:     	mov	x1, #0x6574             ; =25972
10066bb78:     	movk	x1, #0xea00, lsl #48
10066bb7c:     	mov	x3, x20
10066bb80:     	bl	0x100152e08
10066bb84:     	mov	x0, x20
10066bb88:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066bb8c:     	ldr	w0, [x19, x25]
10066bb90:     	bl	0x101ac937c
10066bb94:     	str	wzr, [x19, x25]
10066bb98:     	ldr	w0, [x19, x24]
10066bb9c:     	cbz	w0, 0x10066bba8
10066bba0:     	bl	0x101ac937c
10066bba4:     	str	wzr, [x19, x24]
10066bba8:     	bl	0x10013a308
10066bbac:     	ldr	x20, [x0]
10066bbb0:     	mov	x0, x20
10066bbb4:     	bl	0x101aca978 ; symbol _swift_retain
10066bbb8:     	mov	x0, x19
10066bbbc:     	bl	0x10013b358
10066bbc0:     	mov	x0, x20
10066bbc4:     	bl	0x101aca960 ; symbol _swift_release
10066bbc8:     	adrp	x8, 0x1023da000
10066bbcc:     	ldr	x20, [x8, #0x3b0]
10066bbd0:     	add	x0, x19, x20
10066bbd4:     	mov	x1, sp
10066bbd8:     	mov	w2, #0x1                ; =1
10066bbdc:     	mov	x3, #0x0                ; =0
10066bbe0:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066bbe4:     	strb	wzr, [x19, x20]
10066bbe8:     	and	w0, w21, #0x1
10066bbec:     	ldp	x29, x30, [sp, #0x60]
10066bbf0:     	ldp	x20, x19, [sp, #0x50]
10066bbf4:     	ldp	x22, x21, [sp, #0x40]
10066bbf8:     	ldp	x24, x23, [sp, #0x30]
10066bbfc:     	ldp	x26, x25, [sp, #0x20]
10066bc00:     	add	sp, sp, #0x70
10066bc04:     	ret
10066bc08:     	stp	x28, x27, [sp, #-0x60]!
10066bc0c:     	stp	x26, x25, [sp, #0x10]
10066bc10:     	stp	x24, x23, [sp, #0x20]
10066bc14:     	stp	x22, x21, [sp, #0x30]
10066bc18:     	stp	x20, x19, [sp, #0x40]
10066bc1c:     	stp	x29, x30, [sp, #0x50]
10066bc20:     	add	x29, sp, #0x50
10066bc24:     	sub	sp, sp, #0x70
10066bc28:     	mov	x24, x1
10066bc2c:     	stur	x0, [x29, #-0xa0]
10066bc30:     	adrp	x0, 0x102340000
10066bc34:     	add	x0, x0, #0xcc0
10066bc38:     	adrp	x1, 0x101ae1000
10066bc3c:     	add	x1, x1, #0x2d0 ; possible literal '�24'
10066bc40:     	bl	0x100003c4c
10066bc44:     	stur	x0, [x29, #-0x80]
10066bc48:     	ldur	x8, [x0, #-0x8]
10066bc4c:     	ldr	x8, [x8, #0x40]
10066bc50:     	mov	x9, x8
10066bc54:     	adrp	x16, 0x1022cb000
10066bc58:     	ldr	x16, [x16, #0x398]
10066bc5c:     	blr	x16
10066bc60:     	mov	x9, sp
10066bc64:     	add	x10, x8, #0xf
10066bc68:     	and	x12, x10, #0xfffffffffffffff0
10066bc6c:     	sub	x9, x9, x12
10066bc70:     	stur	x9, [x29, #-0x88]
10066bc74:     	mov	sp, x9
10066bc78:     	mov	x9, x8
10066bc7c:     	adrp	x16, 0x1022cb000
10066bc80:     	ldr	x16, [x16, #0x398]
10066bc84:     	blr	x16
10066bc88:     	mov	x8, sp
10066bc8c:     	sub	x19, x8, x12
10066bc90:     	mov	sp, x19
10066bc94:     	ldr	x20, [x20, #0x18]
10066bc98:     	ldr	x8, [x20]
10066bc9c:     	ldr	x8, [x8, #0x90]
10066bca0:     	blr	x8
10066bca4:     	mov	x20, x19
10066bca8:     	mov	x23, #0x0               ; =0
10066bcac:     	mov	x9, x0
10066bcb0:     	ldr	x8, [x9, #0x40]!
10066bcb4:     	stp	x9, x20, [x29, #-0x98]
10066bcb8:     	stur	x0, [x29, #-0x78]
10066bcbc:     	ldrb	w9, [x0, #0x20]
10066bcc0:     	and	x10, x9, #0x3f
10066bcc4:     	mov	w11, #0x1               ; =1
10066bcc8:     	lsl	x9, x11, x9
10066bccc:     	mov	x11, #-0x1              ; =-1
10066bcd0:     	lsl	x12, x11, x9
10066bcd4:     	cmp	w10, #0x6
10066bcd8:     	csinv	x10, x11, x12, hs
10066bcdc:     	and	x25, x10, x8
10066bce0:     	add	x8, x9, #0x3f
10066bce4:     	lsr	x19, x8, #6
10066bce8:     	and	x8, x24, #0xffffffffffffff
10066bcec:     	stp	x8, x24, [x29, #-0xb0]
10066bcf0:     	and	x8, x24, #0xfffffffffffffff
10066bcf4:     	stp	xzr, x8, [x29, #-0xc0]
10066bcf8:     	b	0x10066bd1c
10066bcfc:     	mov	x0, x22
10066bd00:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066bd04:     	sub	x8, x25, #0x1
10066bd08:     	and	x25, x8, x25
10066bd0c:     	mov	x0, x20
10066bd10:     	mov	x1, x26
10066bd14:     	mov	x2, x27
10066bd18:     	bl	0x10002d870
10066bd1c:     	cbz	x25, 0x10066bddc
10066bd20:     	rbit	x8, x25
10066bd24:     	clz	x8, x8
10066bd28:     	orr	x24, x8, x23, lsl #6
10066bd2c:     	ldp	x21, x9, [x29, #-0x80]
10066bd30:     	ldp	x8, x27, [x9, #0x30]
10066bd34:     	add	x8, x8, x24, lsl #4
10066bd38:     	ldp	x9, x22, [x8]
10066bd3c:     	ldur	x20, [x29, #-0x88]
10066bd40:     	stp	x9, x22, [x20]
10066bd44:     	ldrsw	x26, [x21, #0x30]
10066bd48:     	mov	x0, #0x0                ; =0
10066bd4c:     	bl	0x10068c794
10066bd50:     	mov	x28, x0
10066bd54:     	ldur	x8, [x0, #-0x8]
10066bd58:     	ldr	x8, [x8, #0x48]
10066bd5c:     	madd	x0, x8, x24, x27
10066bd60:     	add	x1, x20, x26
10066bd64:     	adrp	x2, 0x10068c000
10066bd68:     	add	x2, x2, #0x794 ; possible literal '��'
10066bd6c:     	bl	0x1000e73b0
10066bd70:     	mov	x0, x20
10066bd74:     	ldur	x20, [x29, #-0x90]
10066bd78:     	mov	x1, x20
10066bd7c:     	adrp	x26, 0x102340000
10066bd80:     	add	x26, x26, #0xcc0
10066bd84:     	mov	x2, x26
10066bd88:     	adrp	x27, 0x101ae1000
10066bd8c:     	add	x27, x27, #0x2d0 ; possible literal '�24'
10066bd90:     	mov	x3, x27
10066bd94:     	bl	0x1000a1424
10066bd98:     	ldrsw	x24, [x21, #0x30]
10066bd9c:     	add	x0, x20, x24
10066bda0:     	mov	x1, x28
10066bda4:     	bl	0x101aca78c ; symbol _swift_getEnumCaseMultiPayload
10066bda8:     	cbnz	w0, 0x10066bcfc
10066bdac:     	ldr	x28, [x20, x24]
10066bdb0:     	ldur	x24, [x29, #-0xa8]
10066bdb4:     	tbnz	x24, #0x3c, 0x10066be2c
10066bdb8:     	tbnz	x24, #0x3d, 0x10066be04
10066bdbc:     	ldur	x8, [x29, #-0xa0]
10066bdc0:     	tbz	x8, #0x3c, 0x10066be2c
10066bdc4:     	ldr	x28, [x28, #0x10]
10066bdc8:     	mov	x0, x22
10066bdcc:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066bdd0:     	ldur	x8, [x29, #-0xb8]
10066bdd4:     	add	x1, x8, #0x20
10066bdd8:     	b	0x10066be20
10066bddc:     	adds	x23, x23, #0x1
10066bde0:     	ldur	x8, [x29, #-0x98]
10066bde4:     	b.vs	0x10066be8c
10066bde8:     	cmp	x23, x19
10066bdec:     	b.ge	0x10066be64
10066bdf0:     	ldr	x25, [x8, x23, lsl #3]
10066bdf4:     	cbnz	x25, 0x10066bd20
10066bdf8:     	adds	x23, x23, #0x1
10066bdfc:     	b.vc	0x10066bde8
10066be00:     	b	0x10066be8c
10066be04:     	ldur	x9, [x29, #-0xa0]
10066be08:     	ldur	x8, [x29, #-0xb0]
10066be0c:     	stp	x9, x8, [x29, #-0x70]
10066be10:     	ldr	x28, [x28, #0x10]
10066be14:     	mov	x0, x22
10066be18:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066be1c:     	sub	x1, x29, #0x70
10066be20:     	mov	x0, x28
10066be24:     	bl	0x100a7d1fc
10066be28:     	b	0x10066bd04
10066be2c:     	mov	x0, x22
10066be30:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066be34:     	mov	x0, x28
10066be38:     	bl	0x101aca978 ; symbol _swift_retain
10066be3c:     	sub	x3, x29, #0x60
10066be40:     	ldur	x0, [x29, #-0xa0]
10066be44:     	mov	x1, x24
10066be48:     	mov	x2, x28
10066be4c:     	ldur	x21, [x29, #-0xc0]
10066be50:     	bl	0x1005346c0
10066be54:     	stur	x21, [x29, #-0xc0]
10066be58:     	mov	x0, x28
10066be5c:     	bl	0x101aca960 ; symbol _swift_release
10066be60:     	b	0x10066bd04
10066be64:     	ldur	x0, [x29, #-0x78]
10066be68:     	bl	0x101aca960 ; symbol _swift_release
10066be6c:     	sub	sp, x29, #0x50
10066be70:     	ldp	x29, x30, [sp, #0x50]
10066be74:     	ldp	x20, x19, [sp, #0x40]
10066be78:     	ldp	x22, x21, [sp, #0x30]
10066be7c:     	ldp	x24, x23, [sp, #0x20]
10066be80:     	ldp	x26, x25, [sp, #0x10]
10066be84:     	ldp	x28, x27, [sp], #0x60
10066be88:     	ret
10066be8c:     	brk	#0x1
