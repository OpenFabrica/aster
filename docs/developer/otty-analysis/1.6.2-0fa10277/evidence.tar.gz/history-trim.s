
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100913028 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E>:
10094cba8: b4000801    	cbz	x1, 0x10094cca8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c80>
10094cbac: 8b01000a    	add	x10, x0, x1
10094cbb0: d000a288    	adrp	x8, 0x101d9e000 <__ZN10serde_core2de5impls79_$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$std..time..SystemTime$GT$11deserialize14check_overflow13NANOS_PER_SEC17hdc7a2dcd898dff25E+0xffe0>
10094cbb4: 91239d08    	add	x8, x8, #0x8e7
10094cbb8: 5282d009    	mov	w9, #0x1680             ; =5760
10094cbbc: 14000009    	b	0x10094cbe0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39bb8>
10094cbc0: 120011ad    	and	w13, w13, #0x1f
10094cbc4: 1200158c    	and	w12, w12, #0x3f
10094cbc8: 2a0d198c    	orr	w12, w12, w13, lsl #6
10094cbcc: 5100258d    	sub	w13, w12, #0x9
10094cbd0: 710015bf    	cmp	w13, #0x5
10094cbd4: 54000282    	b.hs	0x10094cc24 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39bfc>
10094cbd8: eb0a001f    	cmp	x0, x10
10094cbdc: 54000680    	b.eq	0x10094ccac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c84>
10094cbe0: aa0a03eb    	mov	x11, x10
10094cbe4: 38dffd4c    	ldrsb	w12, [x10, #-0x1]!
10094cbe8: 36ffff2c    	tbz	w12, #0x1f, 0x10094cbcc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39ba4>
10094cbec: aa0b03ea    	mov	x10, x11
10094cbf0: 38dfed4d    	ldrsb	w13, [x10, #-0x2]!
10094cbf4: 310101bf    	cmn	w13, #0x40
10094cbf8: 54fffe4a    	b.ge	0x10094cbc0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b98>
10094cbfc: aa0b03ea    	mov	x10, x11
10094cc00: 38dfdd4e    	ldrsb	w14, [x10, #-0x3]!
10094cc04: 310101df    	cmn	w14, #0x40
10094cc08: 5400028a    	b.ge	0x10094cc58 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c30>
10094cc0c: 12001dce    	and	w14, w14, #0xff
10094cc10: aa0b03ea    	mov	x10, x11
10094cc14: 385fcd4f    	ldrb	w15, [x10, #-0x4]!
10094cc18: 120015ce    	and	w14, w14, #0x3f
10094cc1c: 331a09ee    	bfi	w14, w15, #6, #3
10094cc20: 1400000f    	b	0x10094cc5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c34>
10094cc24: 7100819f    	cmp	w12, #0x20
10094cc28: 54fffd80    	b.eq	0x10094cbd8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39bb0>
10094cc2c: 7102019f    	cmp	w12, #0x80
10094cc30: 540003a3    	b.lo	0x10094cca4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c7c>
10094cc34: 53087d8d    	lsr	w13, w12, #8
10094cc38: 71007dbf    	cmp	w13, #0x1f
10094cc3c: 5400018c    	b.gt	0x10094cc6c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c44>
10094cc40: 3400024d    	cbz	w13, 0x10094cc88 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c60>
10094cc44: 710059bf    	cmp	w13, #0x16
10094cc48: 540002e1    	b.ne	0x10094cca4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c7c>
10094cc4c: 6b09019f    	cmp	w12, w9
10094cc50: 54fffc40    	b.eq	0x10094cbd8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39bb0>
10094cc54: 14000014    	b	0x10094cca4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c7c>
10094cc58: 12000dce    	and	w14, w14, #0xf
10094cc5c: 12001dad    	and	w13, w13, #0xff
10094cc60: 120015ad    	and	w13, w13, #0x3f
10094cc64: 2a0e19ad    	orr	w13, w13, w14, lsl #6
10094cc68: 17ffffd7    	b	0x10094cbc4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b9c>
10094cc6c: 710081bf    	cmp	w13, #0x20
10094cc70: 54000140    	b.eq	0x10094cc98 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c70>
10094cc74: 7100c1bf    	cmp	w13, #0x30
10094cc78: 54000161    	b.ne	0x10094cca4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c7c>
10094cc7c: 71400d9f    	cmp	w12, #0x3, lsl #12      ; =0x3000
10094cc80: 54fffac0    	b.eq	0x10094cbd8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39bb0>
10094cc84: 14000008    	b	0x10094cca4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c7c>
10094cc88: 92401d8c    	and	x12, x12, #0xff
10094cc8c: 386c690c    	ldrb	w12, [x8, x12]
10094cc90: 3707fa4c    	tbnz	w12, #0x0, 0x10094cbd8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39bb0>
10094cc94: 14000004    	b	0x10094cca4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39c7c>
10094cc98: 92401d8c    	and	x12, x12, #0xff
10094cc9c: 386c690c    	ldrb	w12, [x8, x12]
10094cca0: 370ff9cc    	tbnz	w12, #0x1, 0x10094cbd8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39bb0>
10094cca4: cb000161    	sub	x1, x11, x0
10094cca8: d65f03c0    	ret
10094ccac: d2800001    	mov	x1, #0x0                ; =0
10094ccb0: d65f03c0    	ret
10094ccb4: d2800008    	mov	x8, #0x0                ; =0
10094ccb8: b40008a1    	cbz	x1, 0x10094cdcc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39da4>
10094ccbc: 8b010009    	add	x9, x0, x1
10094ccc0: d000a28a    	adrp	x10, 0x101d9e000 <__ZN10serde_core2de5impls79_$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$std..time..SystemTime$GT$11deserialize14check_overflow13NANOS_PER_SEC17hdc7a2dcd898dff25E+0xffe0>
10094ccc4: 91239d4a    	add	x10, x10, #0x8e7
10094ccc8: 5282d00b    	mov	w11, #0x1680            ; =5760
10094cccc: aa0003ed    	mov	x13, x0
10094ccd0: 1400000b    	b	0x10094ccfc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39cd4>
10094ccd4: 9100098d    	add	x13, x12, #0x2
10094ccd8: 331a11d0    	bfi	w16, w14, #6, #5
10094ccdc: aa1003ee    	mov	x14, x16
10094cce0: 510025cf    	sub	w15, w14, #0x9
10094cce4: 710015ff    	cmp	w15, #0x5
10094cce8: 54000322    	b.hs	0x10094cd4c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39d24>
10094ccec: cb0c0108    	sub	x8, x8, x12
10094ccf0: 8b0d0108    	add	x8, x8, x13
10094ccf4: eb0901bf    	cmp	x13, x9
10094ccf8: 54000680    	b.eq	0x10094cdc8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39da0>
10094ccfc: aa0d03ec    	mov	x12, x13
10094cd00: 38c015af    	ldrsb	w15, [x13], #0x1
10094cd04: 12001dee    	and	w14, w15, #0xff
10094cd08: 36fffecf    	tbz	w15, #0x1f, 0x10094cce0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39cb8>
10094cd0c: 3940058d    	ldrb	w13, [x12, #0x1]
10094cd10: 120015b0    	and	w16, w13, #0x3f
10094cd14: 710381df    	cmp	w14, #0xe0
10094cd18: 54fffde3    	b.lo	0x10094ccd4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39cac>
10094cd1c: 120011cf    	and	w15, w14, #0x1f
10094cd20: 3940098d    	ldrb	w13, [x12, #0x2]
10094cd24: 120015ad    	and	w13, w13, #0x3f
10094cd28: 2a1019b0    	orr	w16, w13, w16, lsl #6
10094cd2c: 7103c1df    	cmp	w14, #0xf0
10094cd30: 54000283    	b.lo	0x10094cd80 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39d58>
10094cd34: 9100118d    	add	x13, x12, #0x4
10094cd38: 39400d8e    	ldrb	w14, [x12, #0x3]
10094cd3c: 120015ce    	and	w14, w14, #0x3f
10094cd40: 2a1019ce    	orr	w14, w14, w16, lsl #6
10094cd44: 330e09ee    	bfi	w14, w15, #18, #3
10094cd48: 17ffffe6    	b	0x10094cce0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39cb8>
10094cd4c: 710081df    	cmp	w14, #0x20
10094cd50: 54fffce0    	b.eq	0x10094ccec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39cc4>
10094cd54: 710201df    	cmp	w14, #0x80
10094cd58: 540003a3    	b.lo	0x10094cdcc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39da4>
10094cd5c: 53087dcf    	lsr	w15, w14, #8
10094cd60: 71007dff    	cmp	w15, #0x1f
10094cd64: 5400014c    	b.gt	0x10094cd8c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39d64>
10094cd68: 3400020f    	cbz	w15, 0x10094cda8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39d80>
10094cd6c: 710059ff    	cmp	w15, #0x16
10094cd70: 540002e1    	b.ne	0x10094cdcc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39da4>
10094cd74: 6b0b01df    	cmp	w14, w11
10094cd78: 54fffba0    	b.eq	0x10094ccec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39cc4>
10094cd7c: 14000014    	b	0x10094cdcc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39da4>
10094cd80: 91000d8d    	add	x13, x12, #0x3
10094cd84: 2a0f320e    	orr	w14, w16, w15, lsl #12
10094cd88: 17ffffd6    	b	0x10094cce0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39cb8>
10094cd8c: 710081ff    	cmp	w15, #0x20
10094cd90: 54000140    	b.eq	0x10094cdb8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39d90>
10094cd94: 7100c1ff    	cmp	w15, #0x30
10094cd98: 540001a1    	b.ne	0x10094cdcc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39da4>
10094cd9c: 71400ddf    	cmp	w14, #0x3, lsl #12      ; =0x3000
10094cda0: 54fffa60    	b.eq	0x10094ccec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39cc4>
10094cda4: 1400000a    	b	0x10094cdcc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39da4>
10094cda8: 92401dce    	and	x14, x14, #0xff
10094cdac: 386e694e    	ldrb	w14, [x10, x14]
10094cdb0: 3707f9ee    	tbnz	w14, #0x0, 0x10094ccec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39cc4>
10094cdb4: 14000006    	b	0x10094cdcc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39da4>
10094cdb8: 92401dce    	and	x14, x14, #0xff
10094cdbc: 386e694e    	ldrb	w14, [x10, x14]
10094cdc0: 370ff96e    	tbnz	w14, #0x1, 0x10094ccec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39cc4>
10094cdc4: 14000002    	b	0x10094cdcc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39da4>
10094cdc8: aa0103e8    	mov	x8, x1
10094cdcc: cb080021    	sub	x1, x1, x8
10094cdd0: 8b080000    	add	x0, x0, x8
10094cdd4: d65f03c0    	ret
10094cdd8: 3940e408    	ldrb	w8, [x0, #0x39]
10094cddc: 36000068    	tbz	w8, #0x0, 0x10094cde8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39dc0>
10094cde0: d2800000    	mov	x0, #0x0                ; =0
10094cde4: d65f03c0    	ret
10094cde8: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
10094cdec: a9017bfd    	stp	x29, x30, [sp, #0x10]
10094cdf0: 910043fd    	add	x29, sp, #0x10
10094cdf4: 3940e008    	ldrb	w8, [x0, #0x38]
10094cdf8: 360005c8    	tbz	w8, #0x0, 0x10094ceb0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39e88>
10094cdfc: f9400808    	ldr	x8, [x0, #0x10]
