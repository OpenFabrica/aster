
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010140b34c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E>:
10140dcc0: d10383ff    	sub	sp, sp, #0xe0
10140dcc4: a9086ffc    	stp	x28, x27, [sp, #0x80]
10140dcc8: a90967fa    	stp	x26, x25, [sp, #0x90]
10140dccc: a90a5ff8    	stp	x24, x23, [sp, #0xa0]
10140dcd0: a90b57f6    	stp	x22, x21, [sp, #0xb0]
10140dcd4: a90c4ff4    	stp	x20, x19, [sp, #0xc0]
10140dcd8: a90d7bfd    	stp	x29, x30, [sp, #0xd0]
10140dcdc: 910343fd    	add	x29, sp, #0xd0
10140dce0: aa0003f3    	mov	x19, x0
10140dce4: 39412428    	ldrb	w8, [x1, #0x49]
10140dce8: 36000168    	tbz	w8, #0x0, 0x10140dd14 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29c8>
10140dcec: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140dcf0: f9000268    	str	x8, [x19]
10140dcf4: a94d7bfd    	ldp	x29, x30, [sp, #0xd0]
10140dcf8: a94c4ff4    	ldp	x20, x19, [sp, #0xc0]
10140dcfc: a94b57f6    	ldp	x22, x21, [sp, #0xb0]
10140dd00: a94a5ff8    	ldp	x24, x23, [sp, #0xa0]
10140dd04: a94967fa    	ldp	x26, x25, [sp, #0x90]
10140dd08: a9486ffc    	ldp	x28, x27, [sp, #0x80]
10140dd0c: 910383ff    	add	sp, sp, #0xe0
10140dd10: d65f03c0    	ret
10140dd14: aa0103f4    	mov	x20, x1
10140dd18: 528000d8    	mov	w24, #0x6               ; =6
10140dd1c: 52800039    	mov	w25, #0x1               ; =1
10140dd20: f9400035    	ldr	x21, [x1]
10140dd24: 528e4c5b    	mov	w27, #0x7262            ; =29282
10140dd28: 72adcc3b    	movk	w27, #0x6e61, lsl #16
10140dd2c: d2f0001c    	mov	x28, #-0x8000000000000000 ; =-9223372036854775808
10140dd30: 5285441a    	mov	w26, #0x2a20            ; =10784
10140dd34: 14000003    	b	0x10140dd40 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29f4>
10140dd38: 39412688    	ldrb	w8, [x20, #0x49]
10140dd3c: 3707fd88    	tbnz	w8, #0x0, 0x10140dcec <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29a0>
10140dd40: f8418296    	ldur	x22, [x20, #0x18]
10140dd44: 910003e0    	mov	x0, sp
10140dd48: 91006281    	add	x1, x20, #0x18
10140dd4c: 94017c64    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
10140dd50: b94003e8    	ldr	w8, [sp]
10140dd54: 7100051f    	cmp	w8, #0x1
10140dd58: 54000101    	b.ne	0x10140dd78 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a2c>
10140dd5c: f9400be8    	ldr	x8, [sp, #0x10]
10140dd60: f9400689    	ldr	x9, [x20, #0x8]
10140dd64: cb090101    	sub	x1, x8, x9
10140dd68: 8b0902c0    	add	x0, x22, x9
10140dd6c: f9000688    	str	x8, [x20, #0x8]
10140dd70: b50001c1    	cbnz	x1, 0x10140dda8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a5c>
10140dd74: 1400001c    	b	0x10140dde4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a98>
10140dd78: 39412688    	ldrb	w8, [x20, #0x49]
10140dd7c: 3707fb88    	tbnz	w8, #0x0, 0x10140dcec <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29a0>
10140dd80: 39012699    	strb	w25, [x20, #0x49]
10140dd84: 3941228a    	ldrb	w10, [x20, #0x48]
10140dd88: a940a688    	ldp	x8, x9, [x20, #0x8]
10140dd8c: 3700006a    	tbnz	w10, #0x0, 0x10140dd98 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a4c>
10140dd90: eb08013f    	cmp	x9, x8
10140dd94: 54fffac0    	b.eq	0x10140dcec <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29a0>
10140dd98: f841828a    	ldur	x10, [x20, #0x18]
10140dd9c: cb080121    	sub	x1, x9, x8
10140dda0: 8b080140    	add	x0, x10, x8
10140dda4: b4000201    	cbz	x1, 0x10140dde4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a98>
10140dda8: d1000428    	sub	x8, x1, #0x1
10140ddac: 38686809    	ldrb	w9, [x0, x8]
10140ddb0: 7100293f    	cmp	w9, #0xa
10140ddb4: 54000181    	b.ne	0x10140dde4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a98>
10140ddb8: d1000829    	sub	x9, x1, #0x2
10140ddbc: b40000c8    	cbz	x8, 0x10140ddd4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a88>
10140ddc0: 3869680a    	ldrb	w10, [x0, x9]
10140ddc4: 12001d4a    	and	w10, w10, #0xff
10140ddc8: 7100355f    	cmp	w10, #0xd
10140ddcc: 9a9f000a    	csel	x10, x0, xzr, eq
10140ddd0: 14000002    	b	0x10140ddd8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a8c>
10140ddd4: d280000a    	mov	x10, #0x0               ; =0
10140ddd8: f100015f    	cmp	x10, #0x0
10140dddc: 9a890101    	csel	x1, x8, x9, eq
10140dde0: 9a8a0000    	csel	x0, x0, x10, eq
10140dde4: b4fff840    	cbz	x0, 0x10140dcec <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29a0>
10140dde8: 97d4fadf    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
10140ddec: f1000828    	subs	x8, x1, #0x2
10140ddf0: 540000e2    	b.hs	0x10140de0c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2ac0>
10140ddf4: d2800009    	mov	x9, #0x0                ; =0
10140ddf8: f100013f    	cmp	x9, #0x0
10140ddfc: 9a880036    	csel	x22, x1, x8, eq
10140de00: 9a890017    	csel	x23, x0, x9, eq
10140de04: b5000176    	cbnz	x22, 0x10140de30 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2ae4>
10140de08: 17ffffcc    	b	0x10140dd38 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29ec>
10140de0c: aa0003e9    	mov	x9, x0
10140de10: 7840252a    	ldrh	w10, [x9], #0x2
10140de14: 5ac0094a    	rev	w10, w10
10140de18: 6b4a435f    	cmp	w26, w10, lsr #16
10140de1c: 9a9f0129    	csel	x9, x9, xzr, eq
10140de20: f100013f    	cmp	x9, #0x0
10140de24: 9a880036    	csel	x22, x1, x8, eq
10140de28: 9a890017    	csel	x23, x0, x9, eq
10140de2c: b4fff876    	cbz	x22, 0x10140dd38 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29ec>
10140de30: 394002e8    	ldrb	w8, [x23]
10140de34: 7100a11f    	cmp	w8, #0x28
10140de38: 54fff800    	b.eq	0x10140dd38 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29ec>
10140de3c: aa1503e0    	mov	x0, x21
10140de40: aa1703e1    	mov	x1, x23
10140de44: aa1603e2    	mov	x2, x22
10140de48: 94000381    	bl	0x10140ec4c <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E>
10140de4c: 34fff760    	cbz	w0, 0x10140dd38 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29ec>
10140de50: 97da4228    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140de54: 528000c0    	mov	w0, #0x6                ; =6
10140de58: 52800021    	mov	w1, #0x1                ; =1
10140de5c: 97da421f    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140de60: b4000400    	cbz	x0, 0x10140dee0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2b94>
10140de64: 528d0c68    	mov	w8, #0x6863             ; =26723
10140de68: 79000808    	strh	w8, [x0, #0x4]
10140de6c: b900001b    	str	w27, [x0]
10140de70: a90683f8    	stp	x24, x0, [sp, #0x68]
10140de74: f9003ff8    	str	x24, [sp, #0x78]
10140de78: 910003e0    	mov	x0, sp
10140de7c: 9101a3e3    	add	x3, sp, #0x68
10140de80: aa1703e1    	mov	x1, x23
10140de84: aa1603e2    	mov	x2, x22
10140de88: 52800044    	mov	w4, #0x2                ; =2
10140de8c: 94008253    	bl	0x10142e7d8 <__ZN17otty_autocomplete3fix8distance19damerau_levenshtein17hab3f29809ff4c368E+0x7a4>
10140de90: f94003e8    	ldr	x8, [sp]
10140de94: eb1c011f    	cmp	x8, x28
10140de98: 54fff500    	b.eq	0x10140dd38 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29ec>
10140de9c: f94007e9    	ldr	x9, [sp, #0x8]
10140dea0: f94013ea    	ldr	x10, [sp, #0x20]
10140dea4: f9401feb    	ldr	x11, [sp, #0x38]
10140dea8: f9402bec    	ldr	x12, [sp, #0x50]
10140deac: 3cc583e0    	ldur	q0, [sp, #0x58]
10140deb0: 3c858260    	stur	q0, [x19, #0x58]
10140deb4: 3dc007e0    	ldr	q0, [sp, #0x10]
10140deb8: 3cc283e1    	ldur	q1, [sp, #0x28]
10140debc: 3dc013e2    	ldr	q2, [sp, #0x40]
10140dec0: a9002668    	stp	x8, x9, [x19]
10140dec4: 3d800660    	str	q0, [x19, #0x10]
10140dec8: f900126a    	str	x10, [x19, #0x20]
10140decc: 3c828261    	stur	q1, [x19, #0x28]
10140ded0: f9001e6b    	str	x11, [x19, #0x38]
10140ded4: 3d801262    	str	q2, [x19, #0x40]
10140ded8: f9002a6c    	str	x12, [x19, #0x50]
10140dedc: 17ffff86    	b	0x10140dcf4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29a8>
10140dee0: 52800020    	mov	w0, #0x1                ; =1
10140dee4: 528000c1    	mov	w1, #0x6                ; =6
10140dee8: 941ad523    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140deec: d10303ff    	sub	sp, sp, #0xc0
10140def0: a9066ffc    	stp	x28, x27, [sp, #0x60]
10140def4: a90767fa    	stp	x26, x25, [sp, #0x70]
10140def8: a9085ff8    	stp	x24, x23, [sp, #0x80]
10140defc: a90957f6    	stp	x22, x21, [sp, #0x90]
10140df00: a90a4ff4    	stp	x20, x19, [sp, #0xa0]
10140df04: a90b7bfd    	stp	x29, x30, [sp, #0xb0]
10140df08: 9102c3fd    	add	x29, sp, #0xb0
10140df0c: f90007e0    	str	x0, [sp, #0x8]
10140df10: a9406035    	ldp	x21, x24, [x1]
10140df14: eb1802bf    	cmp	x21, x24
10140df18: 54000ca0    	b.eq	0x10140e0ac <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2d60>
10140df1c: aa0103f4    	mov	x20, x1
10140df20: f9400828    	ldr	x8, [x1, #0x10]
10140df24: f9000be8    	str	x8, [sp, #0x10]
10140df28: d2f0001a    	mov	x26, #-0x8000000000000000 ; =-9223372036854775808
10140df2c: 528d2d1b    	mov	w27, #0x6968            ; =26984
10140df30: 72ac8c9b    	movk	w27, #0x6464, lsl #16
10140df34: 528dccbc    	mov	w28, #0x6e65            ; =28261
10140df38: 14000004    	b	0x10140df48 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2bfc>
10140df3c: aa1303f5    	mov	x21, x19
10140df40: eb18027f    	cmp	x19, x24
10140df44: 54000b40    	b.eq	0x10140e0ac <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2d60>
10140df48: 910382b3    	add	x19, x21, #0xe0
10140df4c: f9000293    	str	x19, [x20]
10140df50: f94066a8    	ldr	x8, [x21, #0xc8]
10140df54: eb1a011f    	cmp	x8, x26
10140df58: 540002a0    	b.eq	0x10140dfac <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2c60>
10140df5c: f9406ea8    	ldr	x8, [x21, #0xd8]
10140df60: b4000268    	cbz	x8, 0x10140dfac <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2c60>
10140df64: f9406aa9    	ldr	x9, [x21, #0xd0]
10140df68: 8b080508    	add	x8, x8, x8, lsl #1
10140df6c: d37df108    	lsl	x8, x8, #3
10140df70: 91004129    	add	x9, x9, #0x10
10140df74: 14000004    	b	0x10140df84 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2c38>
10140df78: 91006129    	add	x9, x9, #0x18
10140df7c: f1006108    	subs	x8, x8, #0x18
10140df80: 54000160    	b.eq	0x10140dfac <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2c60>
10140df84: f940012a    	ldr	x10, [x9]
10140df88: f100195f    	cmp	x10, #0x6
10140df8c: 54ffff61    	b.ne	0x10140df78 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2c2c>
10140df90: f85f812a    	ldur	x10, [x9, #-0x8]
10140df94: b940014b    	ldr	w11, [x10]
10140df98: 7940094a    	ldrh	w10, [x10, #0x4]
10140df9c: 6b1b017f    	cmp	w11, w27
10140dfa0: 7a5c0140    	ccmp	w10, w28, #0x0, eq
10140dfa4: 54fffea1    	b.ne	0x10140df78 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2c2c>
10140dfa8: 17ffffe5    	b	0x10140df3c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2bf0>
10140dfac: aa1503f6    	mov	x22, x21
10140dfb0: f8468ec8    	ldr	x8, [x22, #0x68]!
10140dfb4: eb1a011f    	cmp	x8, x26
10140dfb8: 54fffc20    	b.eq	0x10140df3c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2bf0>
10140dfbc: f9400be8    	ldr	x8, [sp, #0x10]
10140dfc0: f9400908    	ldr	x8, [x8, #0x10]
10140dfc4: b4000308    	cbz	x8, 0x10140e024 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2cd8>
10140dfc8: a94706a0    	ldp	x0, x1, [x21, #0x70]
10140dfcc: 910123e8    	add	x8, sp, #0x48
10140dfd0: 940ff5d9    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
10140dfd4: a94523f7    	ldp	x23, x8, [sp, #0x50]
10140dfd8: f9400be9    	ldr	x9, [sp, #0x10]
10140dfdc: f9400922    	ldr	x2, [x9, #0x10]
10140dfe0: eb02011f    	cmp	x8, x2
10140dfe4: 540000a2    	b.hs	0x10140dff8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2cac>
10140dfe8: 52800019    	mov	w25, #0x0               ; =0
10140dfec: f94027e1    	ldr	x1, [sp, #0x48]
10140dff0: b5000121    	cbnz	x1, 0x10140e014 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2cc8>
10140dff4: 1400000b    	b	0x10140e020 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2cd4>
10140dff8: f9400520    	ldr	x0, [x9, #0x8]
10140dffc: aa1703e1    	mov	x1, x23
10140e000: 941aef07    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10140e004: 7100001f    	cmp	w0, #0x0
10140e008: 1a9f17f9    	cset	w25, eq
10140e00c: f94027e1    	ldr	x1, [sp, #0x48]
10140e010: b4000081    	cbz	x1, 0x10140e020 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2cd4>
10140e014: aa1703e0    	mov	x0, x23
10140e018: 52800022    	mov	w2, #0x1                ; =1
10140e01c: 97da41b0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e020: 34fff8f9    	cbz	w25, 0x10140df3c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2bf0>
10140e024: 910063e8    	add	x8, sp, #0x18
10140e028: aa1603e0    	mov	x0, x22
10140e02c: 94100468    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10140e030: f8480ea8    	ldr	x8, [x21, #0x80]!
10140e034: d2f00016    	mov	x22, #-0x8000000000000000 ; =-9223372036854775808
10140e038: eb16011f    	cmp	x8, x22
10140e03c: 540000c0    	b.eq	0x10140e054 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2d08>
10140e040: 910123e8    	add	x8, sp, #0x48
10140e044: aa1503e0    	mov	x0, x21
10140e048: 94100461    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10140e04c: a944e7f6    	ldp	x22, x25, [sp, #0x48]
10140e050: f9402ff7    	ldr	x23, [sp, #0x58]
10140e054: 3cc183e0    	ldur	q0, [sp, #0x18]
10140e058: 3d800fe0    	str	q0, [sp, #0x30]
10140e05c: f94017e8    	ldr	x8, [sp, #0x28]
10140e060: f90023e8    	str	x8, [sp, #0x40]
10140e064: 910123e8    	add	x8, sp, #0x48
10140e068: 9100c3e0    	add	x0, sp, #0x30
10140e06c: 94100458    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10140e070: f94027e8    	ldr	x8, [sp, #0x48]
10140e074: eb1a011f    	cmp	x8, x26
10140e078: 54fff620    	b.eq	0x10140df3c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2bf0>
10140e07c: a941abe9    	ldp	x9, x10, [sp, #0x18]
10140e080: f94017eb    	ldr	x11, [sp, #0x28]
10140e084: a94537ec    	ldp	x12, x13, [sp, #0x50]
10140e088: f94007ee    	ldr	x14, [sp, #0x8]
10140e08c: a90031c8    	stp	x8, x12, [x14]
10140e090: a90125cd    	stp	x13, x9, [x14, #0x10]
10140e094: a9022dca    	stp	x10, x11, [x14, #0x20]
10140e098: a90365d6    	stp	x22, x25, [x14, #0x30]
10140e09c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140e0a0: a90421d7    	stp	x23, x8, [x14, #0x40]
10140e0a4: 7900c1df    	strh	wzr, [x14, #0x60]
10140e0a8: 14000004    	b	0x10140e0b8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2d6c>
10140e0ac: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140e0b0: f94007e9    	ldr	x9, [sp, #0x8]
10140e0b4: f9000128    	str	x8, [x9]
10140e0b8: a94b7bfd    	ldp	x29, x30, [sp, #0xb0]
10140e0bc: a94a4ff4    	ldp	x20, x19, [sp, #0xa0]
10140e0c0: a94957f6    	ldp	x22, x21, [sp, #0x90]
10140e0c4: a9485ff8    	ldp	x24, x23, [sp, #0x80]
10140e0c8: a94767fa    	ldp	x26, x25, [sp, #0x70]
10140e0cc: a9466ffc    	ldp	x28, x27, [sp, #0x60]
10140e0d0: 910303ff    	add	sp, sp, #0xc0
10140e0d4: d65f03c0    	ret
10140e0d8: aa0003f3    	mov	x19, x0
10140e0dc: f9400fe1    	ldr	x1, [sp, #0x18]
10140e0e0: b40001e1    	cbz	x1, 0x10140e11c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2dd0>
10140e0e4: f94013e0    	ldr	x0, [sp, #0x20]
10140e0e8: 1400000b    	b	0x10140e114 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2dc8>
10140e0ec: aa0003f3    	mov	x19, x0
10140e0f0: f9401be1    	ldr	x1, [sp, #0x30]
10140e0f4: b4000081    	cbz	x1, 0x10140e104 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2db8>
10140e0f8: f9401fe0    	ldr	x0, [sp, #0x38]
10140e0fc: 52800022    	mov	w2, #0x1                ; =1
10140e100: 97da4177    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e104: f240fadf    	tst	x22, #0x7fffffffffffffff
10140e108: 540000a0    	b.eq	0x10140e11c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2dd0>
10140e10c: aa1903e0    	mov	x0, x25
10140e110: aa1603e1    	mov	x1, x22
10140e114: 52800022    	mov	w2, #0x1                ; =1
10140e118: 97da4171    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e11c: aa1303e0    	mov	x0, x19
10140e120: 941aed2d    	bl	0x101ac95d4 <_writev+0x101ac95d4>
