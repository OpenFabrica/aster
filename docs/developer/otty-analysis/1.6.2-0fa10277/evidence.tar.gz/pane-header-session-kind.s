10065aa70:     	sub	x0, x29, #0x98
10065aa74:     	bl	0x101ac9514 ; symbol __Block_copy
10065aa78:     	stur	x0, [x29, #-0xa8]
10065aa7c:     	ldur	x0, [x29, #-0x70]
10065aa80:     	bl	0x101aca960 ; symbol _swift_release
10065aa84:     	mov	x8, x23
10065aa88:     	bl	0x101ac5da0 ; symbol _$s8Dispatch0A3QoSV11unspecifiedACvgZ
10065aa8c:     	adrp	x8, 0x1022cf000
10065aa90:     	ldr	x8, [x8, #0x4a8]
10065aa94:     	stur	x8, [x29, #-0x98]
10065aa98:     	adrp	x0, 0x102342000
10065aa9c:     	add	x0, x0, #0x2e0
10065aaa0:     	adrp	x1, 0x1022cf000
10065aaa4:     	ldr	x1, [x1, #0x930]
10065aaa8:     	adrp	x2, 0x1022cf000
10065aaac:     	ldr	x2, [x2, #0x940]
10065aab0:     	bl	0x10002c7c4
10065aab4:     	mov	x26, x0
10065aab8:     	adrp	x20, 0x102340000
10065aabc:     	add	x20, x20, #0xc50
10065aac0:     	stur	x28, [x29, #-0xb0]
10065aac4:     	adrp	x28, 0x101ae1000
10065aac8:     	add	x28, x28, #0x280 ; possible literal '�14'
10065aacc:     	mov	x0, x20
10065aad0:     	mov	x1, x28
10065aad4:     	bl	0x100003c4c
10065aad8:     	mov	x25, x0
10065aadc:     	adrp	x0, 0x102342000
10065aae0:     	add	x0, x0, #0x2f0
10065aae4:     	adrp	x3, 0x1022ce000
10065aae8:     	ldr	x3, [x3, #0x238]
10065aaec:     	mov	x1, x20
10065aaf0:     	mov	x2, x28
10065aaf4:     	bl	0x10002b714
10065aaf8:     	mov	x2, x0
10065aafc:     	sub	x0, x29, #0x98
10065ab00:     	mov	x8, x21
10065ab04:     	mov	x1, x25
10065ab08:     	mov	x20, x19
10065ab0c:     	mov	x3, x19
10065ab10:     	mov	x4, x26
10065ab14:     	bl	0x101ac7450 ; symbol _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
10065ab18:     	mov	x0, #0x0                ; =0
10065ab1c:     	mov	x1, x23
10065ab20:     	mov	x2, x21
10065ab24:     	ldp	x25, x20, [x29, #-0xa8]
10065ab28:     	mov	x3, x25
10065ab2c:     	bl	0x101ac6e5c ; symbol _$sSo17OS_dispatch_queueC8DispatchE5async5group3qos5flags7executeySo0a1_b1_F0CSg_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
10065ab30:     	mov	x0, x25
10065ab34:     	bl	0x101ac9520 ; symbol __Block_release
10065ab38:     	mov	x0, x20
10065ab3c:     	bl	0x101ac9d30 ; symbol _objc_release
10065ab40:     	mov	x0, x24
10065ab44:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10065ab48:     	ldur	x8, [x29, #-0xb0]
10065ab4c:     	ldr	x8, [x8, #0x8]
10065ab50:     	mov	x0, x21
10065ab54:     	mov	x1, x19
10065ab58:     	blr	x8
10065ab5c:     	ldr	x8, [x27, #0x8]
10065ab60:     	mov	x0, x23
10065ab64:     	mov	x1, x22
10065ab68:     	blr	x8
10065ab6c:     	sub	sp, x29, #0x50
10065ab70:     	ldp	x29, x30, [sp, #0x50]
10065ab74:     	ldp	x20, x19, [sp, #0x40]
10065ab78:     	ldp	x22, x21, [sp, #0x30]
10065ab7c:     	ldp	x24, x23, [sp, #0x20]
10065ab80:     	ldp	x26, x25, [sp, #0x10]
10065ab84:     	ldp	x28, x27, [sp], #0x60
10065ab88:     	ret
10065ab8c:     	stp	x22, x21, [sp, #-0x30]!
10065ab90:     	stp	x20, x19, [sp, #0x10]
10065ab94:     	stp	x29, x30, [sp, #0x20]
10065ab98:     	add	x29, sp, #0x20
10065ab9c:     	mov	x21, x0
10065aba0:     	mov	w0, #0x30               ; =48
10065aba4:     	adrp	x8, 0x1022cf000
10065aba8:     	ldr	x8, [x8, #0x560]
10065abac:     	cbz	x8, 0x10065abbc
10065abb0:     	mov	w1, #0xa108             ; =41224
10065abb4:     	bl	0x101aca684 ; symbol _swift_coroFrameAlloc
10065abb8:     	b	0x10065abc0
10065abbc:     	bl	0x101ac9bf8 ; symbol _malloc
10065abc0:     	mov	x19, x0
10065abc4:     	str	x0, [x21]
10065abc8:     	str	x20, [x0, #0x28]
10065abcc:     	adrp	x8, 0x1023da000
10065abd0:     	ldr	x8, [x8, #0x188]
10065abd4:     	add	x20, x20, x8
10065abd8:     	mov	x0, x20
10065abdc:     	mov	x1, x19
10065abe0:     	mov	x2, #0x0                ; =0
10065abe4:     	mov	x3, #0x0                ; =0
10065abe8:     	bl	0x101aca600 ; symbol _swift_beginAccess
10065abec:     	ldr	x0, [x20, #0x8]
10065abf0:     	ldr	q0, [x20]
10065abf4:     	str	q0, [x19, #0x18]!
10065abf8:     	adrp	x20, 0x10065a000
10065abfc:     	add	x20, x20, #0xc1c
10065ac00:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10065ac04:     	mov	x0, x20
10065ac08:     	mov	x1, x19
10065ac0c:     	ldp	x29, x30, [sp, #0x20]
10065ac10:     	ldp	x20, x19, [sp, #0x10]
10065ac14:     	ldp	x22, x21, [sp], #0x30
10065ac18:     	ret
10065ac1c:     	stp	x22, x21, [sp, #-0x30]!
10065ac20:     	stp	x20, x19, [sp, #0x10]
10065ac24:     	stp	x29, x30, [sp, #0x20]
10065ac28:     	add	x29, sp, #0x20
10065ac2c:     	ldr	x19, [x0]
10065ac30:     	mov	x8, x19
10065ac34:     	ldr	x21, [x8, #0x18]!
10065ac38:     	ldp	x22, x20, [x19, #0x20]
10065ac3c:     	tbz	w1, #0x0, 0x10065ac60
10065ac40:     	mov	x0, x22
10065ac44:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10065ac48:     	mov	x0, x21
10065ac4c:     	mov	x1, x22
10065ac50:     	bl	0x10065a8fc
10065ac54:     	ldr	x0, [x19, #0x20]
10065ac58:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10065ac5c:     	b	0x10065ac6c
10065ac60:     	mov	x0, x21
10065ac64:     	mov	x1, x22
10065ac68:     	bl	0x10065a8fc
10065ac6c:     	mov	x0, x19
10065ac70:     	ldp	x29, x30, [sp, #0x20]
10065ac74:     	ldp	x20, x19, [sp, #0x10]
10065ac78:     	ldp	x22, x21, [sp], #0x30
10065ac7c:     	b	0x101ac99dc ; symbol _free
10065ac80:     	stp	x29, x30, [sp, #-0x10]!
10065ac84:     	mov	x29, sp
10065ac88:     	ldr	x8, [x20]
10065ac8c:     	ldr	x8, [x8, #0x4f8]
10065ac90:     	blr	x8
10065ac94:     	cbz	x1, 0x10065aca0
10065ac98:     	ldp	x29, x30, [sp], #0x10
10065ac9c:     	b	0x1004f394c
10065aca0:     	mov	w0, #0xc                ; =12
10065aca4:     	ldp	x29, x30, [sp], #0x10
10065aca8:     	ret
10065acac:     	stp	x29, x30, [sp, #-0x10]!
10065acb0:     	mov	x29, sp
10065acb4:     	and	w8, w0, #0xff
10065acb8:     	cmp	w8, #0xc
10065acbc:     	b.ne	0x10065accc
10065acc0:     	mov	x0, #0x0                ; =0
10065acc4:     	mov	x1, #0x0                ; =0
10065acc8:     	b	0x10065acd0
10065accc:     	bl	0x1004f2b8c
10065acd0:     	ldr	x8, [x20]
10065acd4:     	ldr	x2, [x8, #0x500]
10065acd8:     	ldp	x29, x30, [sp], #0x10
10065acdc:     	br	x2
10065ace0:     	stp	x20, x19, [sp, #-0x20]!
10065ace4:     	stp	x29, x30, [sp, #0x10]
10065ace8:     	add	x29, sp, #0x10
10065acec:     	mov	x19, x0
10065acf0:     	str	x20, [x19], #0x8
10065acf4:     	ldr	x8, [x20]
10065acf8:     	ldr	x8, [x8, #0x4f8]
10065acfc:     	blr	x8
10065ad00:     	cbz	x1, 0x10065ad0c
10065ad04:     	bl	0x1004f394c
10065ad08:     	b	0x10065ad10
10065ad0c:     	mov	w0, #0xc                ; =12
10065ad10:     	strb	w0, [x19]
10065ad14:     	adrp	x0, 0x10065a000
10065ad18:     	add	x0, x0, #0xd2c
10065ad1c:     	mov	x1, x19
10065ad20:     	ldp	x29, x30, [sp, #0x10]
10065ad24:     	ldp	x20, x19, [sp], #0x20
10065ad28:     	ret
10065ad2c:     	stp	x20, x19, [sp, #-0x20]!
10065ad30:     	stp	x29, x30, [sp, #0x10]
10065ad34:     	add	x29, sp, #0x10
10065ad38:     	mov	x19, x0
10065ad3c:     	mov	x8, x0
10065ad40:     	ldrb	w0, [x8, #0x8]!
10065ad44:     	cmp	w0, #0xc
10065ad48:     	b.ne	0x10065ad58
10065ad4c:     	mov	x1, #0x0                ; =0
10065ad50:     	mov	x0, #0x0                ; =0
10065ad54:     	b	0x10065ad5c
10065ad58:     	bl	0x1004f2b8c
10065ad5c:     	ldr	x20, [x19]
10065ad60:     	ldr	x8, [x20]
10065ad64:     	ldr	x8, [x8, #0x500]
10065ad68:     	blr	x8
10065ad6c:     	ldp	x29, x30, [sp, #0x10]
10065ad70:     	ldp	x20, x19, [sp], #0x20
10065ad74:     	ret
