10065748c:     	sub	sp, sp, #0x80
100657490:     	stp	x26, x25, [sp, #0x30]
100657494:     	stp	x24, x23, [sp, #0x40]
100657498:     	stp	x22, x21, [sp, #0x50]
10065749c:     	stp	x20, x19, [sp, #0x60]
1006574a0:     	stp	x29, x30, [sp, #0x70]
1006574a4:     	add	x29, sp, #0x70
1006574a8:     	mov	x19, x20
1006574ac:     	mov	x21, x0
1006574b0:     	ldr	x24, [x0, #0x10]
1006574b4:     	cbz	x24, 0x10065750c
1006574b8:     	add	x25, x21, #0x28
1006574bc:     	ldp	x22, x23, [x25, #-0x8]
1006574c0:     	add	x0, x19, #0x28
1006574c4:     	add	x1, sp, #0x8
1006574c8:     	mov	w2, #0x21               ; =33
1006574cc:     	mov	x3, #0x0                ; =0
1006574d0:     	bl	0x101aca600 ; symbol _swift_beginAccess
1006574d4:     	mov	x0, x23
1006574d8:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
1006574dc:     	add	x0, sp, #0x20
1006574e0:     	add	x20, x19, #0x28
1006574e4:     	mov	x1, x22
1006574e8:     	mov	x2, x23
1006574ec:     	bl	0x10004b670
1006574f0:     	add	x0, sp, #0x8
1006574f4:     	bl	0x101aca738 ; symbol _swift_endAccess
1006574f8:     	ldr	x0, [sp, #0x28]
1006574fc:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100657500:     	add	x25, x25, #0x10
100657504:     	subs	x24, x24, #0x1
100657508:     	b.ne	0x1006574bc
10065750c:     	mov	x8, #0x766f             ; =30319
100657510:     	movk	x8, #0x7265, lsl #16
100657514:     	movk	x8, #0x6972, lsl #32
100657518:     	movk	x8, #0x6564, lsl #48
10065751c:     	mov	x24, #0x20              ; =32
100657520:     	movk	x24, #0xe900, lsl #48
100657524:     	stp	x8, x24, [sp, #0x8]
100657528:     	str	x21, [sp, #0x20]
10065752c:     	adrp	x20, 0x102342000
100657530:     	add	x20, x20, #0xa20
100657534:     	adrp	x22, 0x101ae2000
100657538:     	add	x22, x22, #0x2f0 ; possible literal '�&4'
10065753c:     	mov	x0, x20
100657540:     	mov	x1, x22
100657544:     	bl	0x100003c4c
100657548:     	mov	x23, x0
10065754c:     	adrp	x0, 0x102341000
100657550:     	add	x0, x0, #0x7a0
100657554:     	adrp	x3, 0x1022ce000
100657558:     	ldr	x3, [x3, #0x220]
10065755c:     	mov	x1, x20
100657560:     	mov	x2, x22
100657564:     	bl	0x10002b714
100657568:     	mov	x3, x0
10065756c:     	add	x20, sp, #0x20
100657570:     	mov	w0, #0x2c               ; =44
100657574:     	mov	x1, #-0x1f00000000000000 ; =-2233785415175766016
100657578:     	mov	x2, x23
10065757c:     	bl	0x101ac60b8 ; symbol _$sSKsSS7ElementRtzrlE6joined9separatorS2S_tF
100657580:     	mov	x22, x1
100657584:     	add	x20, sp, #0x8
100657588:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10065758c:     	mov	x0, x22
100657590:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100657594:     	add	x20, sp, #0x8
100657598:     	mov	w0, #0x3d               ; =61
10065759c:     	mov	x1, #-0x1f00000000000000 ; =-2233785415175766016
1006575a0:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
1006575a4:     	mov	x0, x21
1006575a8:     	mov	x20, x19
1006575ac:     	bl	0x100657638
1006575b0:     	mov	x19, x0
1006575b4:     	adrp	x8, 0x1022cf000
1006575b8:     	ldr	x8, [x8, #0x490]
1006575bc:     	adrp	x1, 0x1022ce000
1006575c0:     	ldr	x1, [x1, #0x38]
1006575c4:     	adrp	x3, 0x1022ce000
1006575c8:     	ldr	x3, [x3, #0x48]
1006575cc:     	add	x2, x8, #0x8 ; possible literal 's\n'
1006575d0:     	bl	0x101ac5efc
1006575d4:     	mov	x21, x1
1006575d8:     	add	x20, sp, #0x8
1006575dc:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
1006575e0:     	mov	x0, x19
1006575e4:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1006575e8:     	mov	x0, x21
1006575ec:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1006575f0:     	ldp	x2, x19, [sp, #0x8]
1006575f4:     	mov	w8, #0x45               ; =69
1006575f8:     	mov	x0, #0x7250             ; =29264
1006575fc:     	movk	x0, #0x7669, lsl #16
100657600:     	movk	x0, #0x6c69, lsl #32
100657604:     	movk	x0, #0x6765, lsl #48
100657608:     	orr	x1, x24, x8
10065760c:     	mov	x3, x19
100657610:     	bl	0x100152e08
100657614:     	mov	x0, x19
100657618:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10065761c:     	ldp	x29, x30, [sp, #0x70]
100657620:     	ldp	x20, x19, [sp, #0x60]
100657624:     	ldp	x22, x21, [sp, #0x50]
100657628:     	ldp	x24, x23, [sp, #0x40]
10065762c:     	ldp	x26, x25, [sp, #0x30]
100657630:     	add	sp, sp, #0x80
100657634:     	ret
