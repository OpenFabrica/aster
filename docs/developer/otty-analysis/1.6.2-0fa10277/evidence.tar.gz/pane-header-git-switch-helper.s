10057b214:     	b	0x10057edcc
10057b218:     	ldp	x8, x1, [x0, #0x10]
10057b21c:     	mov	x0, x8
10057b220:     	b	0x10057f0c8
10057b224:     	b	0x10057f0c8
10057b228:     	stp	x22, x21, [sp, #-0x30]!
10057b22c:     	stp	x20, x19, [sp, #0x10]
10057b230:     	stp	x29, x30, [sp, #0x20]
10057b234:     	add	x29, sp, #0x20
10057b238:     	mov	x19, x1
10057b23c:     	mov	x20, x0
10057b240:     	adrp	x8, 0x102326000
10057b244:     	ldr	x0, [x8, #0xa10]
10057b248:     	bl	0x101ac9d24 ; symbol _objc_opt_self
10057b24c:     	bl	0x101ad4ec0 ; selector sharedWorkspace
10057b250:     	mov	x29, x29
10057b254:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
10057b258:     	mov	x21, x0
10057b25c:     	mov	x0, x20
10057b260:     	mov	x1, x19
10057b264:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
10057b268:     	mov	x19, x0
10057b26c:     	mov	x0, x21
10057b270:     	mov	x2, #0x0                ; =0
10057b274:     	mov	x3, x19
10057b278:     	bl	0x101ad13a0 ; selector selectFile:inFileViewerRootedAtPath:
10057b27c:     	mov	x0, x21
10057b280:     	bl	0x101ac9d30 ; symbol _objc_release
10057b284:     	mov	x0, x19
10057b288:     	ldp	x29, x30, [sp, #0x20]
10057b28c:     	ldp	x20, x19, [sp, #0x10]
10057b290:     	ldp	x22, x21, [sp], #0x30
10057b294:     	b	0x101ac9d30 ; symbol _objc_release
10057b298:     	stp	x28, x27, [sp, #-0x60]!
10057b29c:     	stp	x26, x25, [sp, #0x10]
10057b2a0:     	stp	x24, x23, [sp, #0x20]
10057b2a4:     	stp	x22, x21, [sp, #0x30]
10057b2a8:     	stp	x20, x19, [sp, #0x40]
10057b2ac:     	stp	x29, x30, [sp, #0x50]
10057b2b0:     	add	x29, sp, #0x50
10057b2b4:     	mov	x21, x1
10057b2b8:     	mov	x22, x0
10057b2bc:     	mov	x0, #0x0                ; =0
10057b2c0:     	bl	0x101ac4e28 ; symbol _$s10Foundation3URLVMa
10057b2c4:     	mov	x19, x0
10057b2c8:     	ldur	x28, [x0, #-0x8]
10057b2cc:     	ldr	x8, [x28, #0x40]
10057b2d0:     	mov	x9, x8
10057b2d4:     	adrp	x16, 0x1022cb000
10057b2d8:     	ldr	x16, [x16, #0x398]
10057b2dc:     	blr	x16
10057b2e0:     	mov	x9, sp
10057b2e4:     	add	x10, x8, #0xf
10057b2e8:     	and	x12, x10, #0xfffffffffffffff0
10057b2ec:     	sub	x24, x9, x12
10057b2f0:     	mov	sp, x24
10057b2f4:     	mov	x9, x8
10057b2f8:     	adrp	x16, 0x1022cb000
10057b2fc:     	ldr	x16, [x16, #0x398]
10057b300:     	blr	x16
10057b304:     	mov	x8, sp
10057b308:     	sub	x20, x8, x12
10057b30c:     	mov	sp, x20
10057b310:     	adrp	x8, 0x102326000
10057b314:     	ldr	x0, [x8, #0xa10]
10057b318:     	bl	0x101ac9d24 ; symbol _objc_opt_self
10057b31c:     	mov	x23, x0
10057b320:     	bl	0x101ad4ec0 ; selector sharedWorkspace
10057b324:     	mov	x29, x29
10057b328:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
10057b32c:     	mov	x26, x0
10057b330:     	adrp	x8, 0x101dd9000
10057b334:     	add	x8, x8, #0x3c0 ; possible literal 'com.apple.Terminal'
10057b338:     	sub	x8, x8, #0x20
10057b33c:     	orr	x1, x8, #0x8000000000000000
10057b340:     	mov	x0, #0x12               ; =18
10057b344:     	movk	x0, #0xd000, lsl #48
10057b348:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
10057b34c:     	mov	x27, x0
10057b350:     	mov	x0, x26
10057b354:     	mov	x2, x27
10057b358:     	bl	0x101acae60 ; selector URLForApplicationWithBundleIdentifier:
10057b35c:     	mov	x29, x29
10057b360:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
10057b364:     	mov	x25, x0
10057b368:     	mov	x0, x26
10057b36c:     	bl	0x101ac9d30 ; symbol _objc_release
10057b370:     	mov	x0, x27
10057b374:     	bl	0x101ac9d30 ; symbol _objc_release
10057b378:     	cbz	x25, 0x10057b484
10057b37c:     	mov	x8, x24
10057b380:     	mov	x0, x25
10057b384:     	bl	0x101ac4de0
10057b388:     	mov	x0, x25
10057b38c:     	bl	0x101ac9d30 ; symbol _objc_release
10057b390:     	ldr	x8, [x28, #0x20]
10057b394:     	mov	x0, x20
10057b398:     	mov	x1, x24
10057b39c:     	mov	x2, x19
10057b3a0:     	blr	x8
10057b3a4:     	adrp	x8, 0x102326000
10057b3a8:     	ldr	x0, [x8, #0xa98]
10057b3ac:     	bl	0x101ac9cb8 ; symbol _objc_allocWithZone
10057b3b0:     	bl	0x101ace2c0 ; selector init
10057b3b4:     	mov	x24, x0
10057b3b8:     	mov	x0, x23
10057b3bc:     	bl	0x101ad4ec0 ; selector sharedWorkspace
10057b3c0:     	mov	x29, x29
10057b3c4:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
10057b3c8:     	mov	x23, x0
10057b3cc:     	adrp	x0, 0x102363000
10057b3d0:     	add	x0, x0, #0xa00
10057b3d4:     	adrp	x1, 0x101aed000
10057b3d8:     	add	x1, x1, #0x9e0 ; possible literal '�v3'
10057b3dc:     	bl	0x100003c4c
10057b3e0:     	ldr	x8, [x28, #0x48]
10057b3e4:     	ldrb	w9, [x28, #0x50]
10057b3e8:     	add	x10, x9, #0x20
10057b3ec:     	bic	x26, x10, x9
10057b3f0:     	add	x1, x26, x8
10057b3f4:     	orr	x2, x9, #0x7
10057b3f8:     	bl	0x101aca588 ; symbol _swift_allocObject
10057b3fc:     	mov	x25, x0
10057b400:     	adrp	x8, 0x101ae1000
10057b404:     	ldr	q0, [x8, #0x130]
10057b408:     	str	q0, [x0, #0x10]
10057b40c:     	add	x8, x0, x26
10057b410:     	mov	x0, x22
10057b414:     	mov	x1, x21
10057b418:     	bl	0x101ac4d68 ; symbol _$s10Foundation3URLV15fileURLWithPathACSSh_tcfC
10057b41c:     	mov	x0, x25
10057b420:     	mov	x1, x19
10057b424:     	bl	0x101ac6754 ; symbol _$sSa10FoundationE19_bridgeToObjectiveCSo7NSArrayCyF
10057b428:     	mov	x21, x0
10057b42c:     	mov	x0, x25
10057b430:     	bl	0x101aca960 ; symbol _swift_release
10057b434:     	bl	0x101ac4d8c ; symbol _$s10Foundation3URLV19_bridgeToObjectiveCSo5NSURLCyF
10057b438:     	mov	x22, x0
10057b43c:     	mov	x0, x23
10057b440:     	mov	x2, x21
10057b444:     	mov	x3, x22
10057b448:     	mov	x4, x24
10057b44c:     	mov	x5, #0x0                ; =0
10057b450:     	bl	0x101acfde0 ; selector openURLs:withApplicationAtURL:configuration:completionHandler:
10057b454:     	mov	x0, x23
10057b458:     	bl	0x101ac9d30 ; symbol _objc_release
10057b45c:     	mov	x0, x21
10057b460:     	bl	0x101ac9d30 ; symbol _objc_release
10057b464:     	mov	x0, x22
10057b468:     	bl	0x101ac9d30 ; symbol _objc_release
10057b46c:     	mov	x0, x24
10057b470:     	bl	0x101ac9d30 ; symbol _objc_release
10057b474:     	ldr	x8, [x28, #0x8]
10057b478:     	mov	x0, x20
10057b47c:     	mov	x1, x19
10057b480:     	blr	x8
10057b484:     	sub	sp, x29, #0x50
10057b488:     	ldp	x29, x30, [sp, #0x50]
10057b48c:     	ldp	x20, x19, [sp, #0x40]
10057b490:     	ldp	x22, x21, [sp, #0x30]
10057b494:     	ldp	x24, x23, [sp, #0x20]
10057b498:     	ldp	x26, x25, [sp, #0x10]
10057b49c:     	ldp	x28, x27, [sp], #0x60
10057b4a0:     	ret
10057b4a4:     	ldp	x8, x6, [x5, #0x10]
10057b4a8:     	mov	x5, x8
10057b4ac:     	b	0x10057f380
10057b4b0:     	b	0x10057f380
10057b4b4:     	stp	x24, x23, [sp, #-0x40]!
10057b4b8:     	stp	x22, x21, [sp, #0x10]
10057b4bc:     	stp	x20, x19, [sp, #0x20]
10057b4c0:     	stp	x29, x30, [sp, #0x30]
10057b4c4:     	add	x29, sp, #0x30
10057b4c8:     	mov	x21, #0x14              ; =20
10057b4cc:     	movk	x21, #0xd000, lsl #48
10057b4d0:     	adrp	x8, 0x101ddd000
10057b4d4:     	add	x8, x8, #0x590 ; possible literal 'com.microsoft.VSCode'
10057b4d8:     	sub	x8, x8, #0x20
10057b4dc:     	orr	x19, x8, #0x8000000000000000
10057b4e0:     	adrp	x0, 0x10234f000
10057b4e4:     	add	x0, x0, #0x7f0
10057b4e8:     	adrp	x1, 0x101ae1000
10057b4ec:     	add	x1, x1, #0xd10 ; possible literal 'J/4'
10057b4f0:     	bl	0x100003c4c
10057b4f4:     	mov	x20, x0
10057b4f8:     	mov	w0, #0x3                ; =3
10057b4fc:     	bl	0x101ac793c
10057b500:     	mov	x20, x0
10057b504:     	bl	0x101aca978 ; symbol _swift_retain
10057b508:     	mov	x0, #0x14               ; =20
10057b50c:     	movk	x0, #0xd000, lsl #48
10057b510:     	mov	x1, x19
10057b514:     	bl	0x1000240a8
