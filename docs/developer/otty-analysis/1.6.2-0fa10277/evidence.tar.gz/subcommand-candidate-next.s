
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010140b34c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E>:
10140deec: d10303ff    	sub	sp, sp, #0xc0
10140def0: a9066ffc    	stp	x28, x27, [sp, #0x60]
10140def4: a90767fa    	stp	x26, x25, [sp, #0x70]
10140def8: a9085ff8    	stp	x24, x23, [sp, #0x80]
10140defc: a90957f6    	stp	x22, x21, [sp, #0x90]
10140df00: a90a4ff4    	stp	x20, x19, [sp, #0xa0]
10140df04: a90b7bfd    	stp	x29, x30, [sp, #0xb0]
10140df08: 9102c3fd    	add	x29, sp, #0xb0
10140df0c: f90007e0    	str	x0, [sp, #0x8]
10140df10: a9406035    	ldp	x21, x24, [x1]
10140df14: eb1802bf    	cmp	x21, x24
10140df18: 54000ca0    	b.eq	0x10140e0ac <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2d60>
10140df1c: aa0103f4    	mov	x20, x1
10140df20: f9400828    	ldr	x8, [x1, #0x10]
10140df24: f9000be8    	str	x8, [sp, #0x10]
10140df28: d2f0001a    	mov	x26, #-0x8000000000000000 ; =-9223372036854775808
10140df2c: 528d2d1b    	mov	w27, #0x6968            ; =26984
10140df30: 72ac8c9b    	movk	w27, #0x6464, lsl #16
10140df34: 528dccbc    	mov	w28, #0x6e65            ; =28261
10140df38: 14000004    	b	0x10140df48 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2bfc>
10140df3c: aa1303f5    	mov	x21, x19
10140df40: eb18027f    	cmp	x19, x24
10140df44: 54000b40    	b.eq	0x10140e0ac <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2d60>
10140df48: 910382b3    	add	x19, x21, #0xe0
10140df4c: f9000293    	str	x19, [x20]
10140df50: f94066a8    	ldr	x8, [x21, #0xc8]
10140df54: eb1a011f    	cmp	x8, x26
10140df58: 540002a0    	b.eq	0x10140dfac <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2c60>
10140df5c: f9406ea8    	ldr	x8, [x21, #0xd8]
10140df60: b4000268    	cbz	x8, 0x10140dfac <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2c60>
10140df64: f9406aa9    	ldr	x9, [x21, #0xd0]
10140df68: 8b080508    	add	x8, x8, x8, lsl #1
10140df6c: d37df108    	lsl	x8, x8, #3
10140df70: 91004129    	add	x9, x9, #0x10
10140df74: 14000004    	b	0x10140df84 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2c38>
10140df78: 91006129    	add	x9, x9, #0x18
10140df7c: f1006108    	subs	x8, x8, #0x18
10140df80: 54000160    	b.eq	0x10140dfac <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2c60>
10140df84: f940012a    	ldr	x10, [x9]
10140df88: f100195f    	cmp	x10, #0x6
10140df8c: 54ffff61    	b.ne	0x10140df78 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2c2c>
10140df90: f85f812a    	ldur	x10, [x9, #-0x8]
10140df94: b940014b    	ldr	w11, [x10]
10140df98: 7940094a    	ldrh	w10, [x10, #0x4]
10140df9c: 6b1b017f    	cmp	w11, w27
10140dfa0: 7a5c0140    	ccmp	w10, w28, #0x0, eq
10140dfa4: 54fffea1    	b.ne	0x10140df78 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2c2c>
10140dfa8: 17ffffe5    	b	0x10140df3c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2bf0>
10140dfac: aa1503f6    	mov	x22, x21
10140dfb0: f8468ec8    	ldr	x8, [x22, #0x68]!
10140dfb4: eb1a011f    	cmp	x8, x26
10140dfb8: 54fffc20    	b.eq	0x10140df3c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2bf0>
10140dfbc: f9400be8    	ldr	x8, [sp, #0x10]
10140dfc0: f9400908    	ldr	x8, [x8, #0x10]
10140dfc4: b4000308    	cbz	x8, 0x10140e024 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2cd8>
10140dfc8: a94706a0    	ldp	x0, x1, [x21, #0x70]
10140dfcc: 910123e8    	add	x8, sp, #0x48
10140dfd0: 940ff5d9    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
10140dfd4: a94523f7    	ldp	x23, x8, [sp, #0x50]
10140dfd8: f9400be9    	ldr	x9, [sp, #0x10]
10140dfdc: f9400922    	ldr	x2, [x9, #0x10]
10140dfe0: eb02011f    	cmp	x8, x2
10140dfe4: 540000a2    	b.hs	0x10140dff8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2cac>
10140dfe8: 52800019    	mov	w25, #0x0               ; =0
10140dfec: f94027e1    	ldr	x1, [sp, #0x48]
10140dff0: b5000121    	cbnz	x1, 0x10140e014 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2cc8>
10140dff4: 1400000b    	b	0x10140e020 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2cd4>
10140dff8: f9400520    	ldr	x0, [x9, #0x8]
10140dffc: aa1703e1    	mov	x1, x23
10140e000: 941aef07    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10140e004: 7100001f    	cmp	w0, #0x0
10140e008: 1a9f17f9    	cset	w25, eq
10140e00c: f94027e1    	ldr	x1, [sp, #0x48]
10140e010: b4000081    	cbz	x1, 0x10140e020 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2cd4>
10140e014: aa1703e0    	mov	x0, x23
10140e018: 52800022    	mov	w2, #0x1                ; =1
10140e01c: 97da41b0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e020: 34fff8f9    	cbz	w25, 0x10140df3c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2bf0>
10140e024: 910063e8    	add	x8, sp, #0x18
10140e028: aa1603e0    	mov	x0, x22
10140e02c: 94100468    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10140e030: f8480ea8    	ldr	x8, [x21, #0x80]!
10140e034: d2f00016    	mov	x22, #-0x8000000000000000 ; =-9223372036854775808
10140e038: eb16011f    	cmp	x8, x22
10140e03c: 540000c0    	b.eq	0x10140e054 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2d08>
10140e040: 910123e8    	add	x8, sp, #0x48
10140e044: aa1503e0    	mov	x0, x21
10140e048: 94100461    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10140e04c: a944e7f6    	ldp	x22, x25, [sp, #0x48]
10140e050: f9402ff7    	ldr	x23, [sp, #0x58]
10140e054: 3cc183e0    	ldur	q0, [sp, #0x18]
10140e058: 3d800fe0    	str	q0, [sp, #0x30]
10140e05c: f94017e8    	ldr	x8, [sp, #0x28]
10140e060: f90023e8    	str	x8, [sp, #0x40]
10140e064: 910123e8    	add	x8, sp, #0x48
10140e068: 9100c3e0    	add	x0, sp, #0x30
10140e06c: 94100458    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10140e070: f94027e8    	ldr	x8, [sp, #0x48]
10140e074: eb1a011f    	cmp	x8, x26
10140e078: 54fff620    	b.eq	0x10140df3c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2bf0>
10140e07c: a941abe9    	ldp	x9, x10, [sp, #0x18]
10140e080: f94017eb    	ldr	x11, [sp, #0x28]
10140e084: a94537ec    	ldp	x12, x13, [sp, #0x50]
10140e088: f94007ee    	ldr	x14, [sp, #0x8]
10140e08c: a90031c8    	stp	x8, x12, [x14]
10140e090: a90125cd    	stp	x13, x9, [x14, #0x10]
10140e094: a9022dca    	stp	x10, x11, [x14, #0x20]
10140e098: a90365d6    	stp	x22, x25, [x14, #0x30]
10140e09c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140e0a0: a90421d7    	stp	x23, x8, [x14, #0x40]
10140e0a4: 7900c1df    	strh	wzr, [x14, #0x60]
10140e0a8: 14000004    	b	0x10140e0b8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2d6c>
10140e0ac: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140e0b0: f94007e9    	ldr	x9, [sp, #0x8]
10140e0b4: f9000128    	str	x8, [x9]
10140e0b8: a94b7bfd    	ldp	x29, x30, [sp, #0xb0]
10140e0bc: a94a4ff4    	ldp	x20, x19, [sp, #0xa0]
10140e0c0: a94957f6    	ldp	x22, x21, [sp, #0x90]
10140e0c4: a9485ff8    	ldp	x24, x23, [sp, #0x80]
10140e0c8: a94767fa    	ldp	x26, x25, [sp, #0x70]
10140e0cc: a9466ffc    	ldp	x28, x27, [sp, #0x60]
10140e0d0: 910303ff    	add	sp, sp, #0xc0
10140e0d4: d65f03c0    	ret
10140e0d8: aa0003f3    	mov	x19, x0
10140e0dc: f9400fe1    	ldr	x1, [sp, #0x18]
10140e0e0: b40001e1    	cbz	x1, 0x10140e11c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2dd0>
10140e0e4: f94013e0    	ldr	x0, [sp, #0x20]
10140e0e8: 1400000b    	b	0x10140e114 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2dc8>
10140e0ec: aa0003f3    	mov	x19, x0
10140e0f0: f9401be1    	ldr	x1, [sp, #0x30]
10140e0f4: b4000081    	cbz	x1, 0x10140e104 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2db8>
10140e0f8: f9401fe0    	ldr	x0, [sp, #0x38]
10140e0fc: 52800022    	mov	w2, #0x1                ; =1
10140e100: 97da4177    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e104: f240fadf    	tst	x22, #0x7fffffffffffffff
10140e108: 540000a0    	b.eq	0x10140e11c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2dd0>
10140e10c: aa1903e0    	mov	x0, x25
10140e110: aa1603e1    	mov	x1, x22
10140e114: 52800022    	mov	w2, #0x1                ; =1
10140e118: 97da4171    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140e11c: aa1303e0    	mov	x0, x19
10140e120: 941aed2d    	bl	0x101ac95d4 <_writev+0x101ac95d4>
