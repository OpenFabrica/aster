1004a65dc:     	sub	sp, sp, #0x130
1004a65e0:     	stp	d15, d14, [sp, #0x90]
1004a65e4:     	stp	d13, d12, [sp, #0xa0]
1004a65e8:     	stp	d11, d10, [sp, #0xb0]
1004a65ec:     	stp	d9, d8, [sp, #0xc0]
1004a65f0:     	stp	x28, x27, [sp, #0xd0]
1004a65f4:     	stp	x26, x25, [sp, #0xe0]
1004a65f8:     	stp	x24, x23, [sp, #0xf0]
1004a65fc:     	stp	x22, x21, [sp, #0x100]
1004a6600:     	stp	x20, x19, [sp, #0x110]
1004a6604:     	stp	x29, x30, [sp, #0x120]
1004a6608:     	add	x29, sp, #0x120
1004a660c:     	adrp	x8, 0x102354000
1004a6610:     	ldr	x8, [x8, #0xdd0]
1004a6614:     	add	x8, x20, x8
1004a6618:     	ldr	x21, [x8]
1004a661c:     	cbz	x21, 0x1004a72bc
1004a6620:     	mov	x22, x20
1004a6624:     	ldr	x20, [x8, #0x8]
1004a6628:     	mov	x0, x21
1004a662c:     	mov	x1, x20
1004a6630:     	bl	0x100003f5c
1004a6634:     	blr	x21
1004a6638:     	mov	x23, x0
1004a663c:     	mov	x0, x21
1004a6640:     	mov	x1, x20
1004a6644:     	bl	0x100003840
1004a6648:     	mov	x0, #0x0                ; =0
1004a664c:     	bl	0x1004ad03c
1004a6650:     	mov	x20, x0
1004a6654:     	bl	0x1004a9cc4
1004a6658:     	mov	x20, x22
1004a665c:     	bl	0x1004a72f8
1004a6660:     	adrp	x8, 0x102354000
1004a6664:     	ldr	x21, [x8, #0xe10]
1004a6668:     	add	x0, x22, x21
1004a666c:     	add	x1, sp, #0x70
1004a6670:     	mov	w2, #0x1                ; =1
1004a6674:     	mov	x3, #0x0                ; =0
1004a6678:     	bl	0x101aca600 ; symbol _swift_beginAccess
1004a667c:     	ldr	x0, [x22, x21]
1004a6680:     	adrp	x8, 0x1022cf000
1004a6684:     	ldr	x8, [x8, #0x4a8]
1004a6688:     	str	x8, [x22, x21]
1004a668c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1004a6690:     	adrp	x8, 0x102354000
1004a6694:     	ldr	x8, [x8, #0xe20]
1004a6698:     	mov	x9, #-0x1               ; =-1
1004a669c:     	str	x9, [x22, x8]
1004a66a0:     	adrp	x8, 0x102354000
1004a66a4:     	ldr	x19, [x8, #0xdc8]
1004a66a8:     	add	x0, x22, x19
1004a66ac:     	add	x1, sp, #0x58
1004a66b0:     	mov	w2, #0x1                ; =1
1004a66b4:     	mov	x3, #0x0                ; =0
1004a66b8:     	bl	0x101aca600 ; symbol _swift_beginAccess
1004a66bc:     	strb	wzr, [x22, x19]
1004a66c0:     	mov	x0, #0x0                ; =0
1004a66c4:     	bl	0x10006d00c
1004a66c8:     	mov	x8, #0x400000000000     ; =70368744177664
1004a66cc:     	movk	x8, #0x4070, lsl #48
1004a66d0:     	fmov	d2, x8
1004a66d4:     	movi.2d	v0, #0000000000000000
1004a66d8:     	movi.2d	v1, #0000000000000000
1004a66dc:     	movi.2d	v3, #0000000000000000
1004a66e0:     	mov	x20, x0
1004a66e4:     	bl	0x100013340
1004a66e8:     	str	x0, [sp, #0x30]
1004a66ec:     	ldr	x10, [x23, #0x10]
1004a66f0:     	str	x22, [sp, #0x20]
1004a66f4:     	cbz	x10, 0x1004a6f30
1004a66f8:     	str	x21, [sp, #0x8]
1004a66fc:     	mov	x26, #0x0               ; =0
1004a6700:     	adrp	x8, 0x1022ca000
1004a6704:     	ldr	x8, [x8, #0x610]
1004a6708:     	adrp	x9, 0x1022ca000
1004a670c:     	ldr	x9, [x9, #0x620]
1004a6710:     	ldr	d8, [x8]
1004a6714:     	ldr	d9, [x9]
1004a6718:     	mov	x8, #0x800000000000     ; =140737488355328
1004a671c:     	movk	x8, #0x406c, lsl #48
1004a6720:     	fmov	d10, x8
1004a6724:     	mov	x8, #0x400000000000     ; =70368744177664
1004a6728:     	movk	x8, #0x4070, lsl #48
1004a672c:     	fmov	d11, x8
1004a6730:     	fmov	d15, #2.00000000
1004a6734:     	mov	x8, #0x800000000000     ; =140737488355328
1004a6738:     	movk	x8, #0x406d, lsl #48
1004a673c:     	fmov	d13, x8
1004a6740:     	fmov	d12, #4.00000000
1004a6744:     	mov	x22, x23
1004a6748:     	str	x23, [sp, #0x10]
1004a674c:     	b	0x1004a679c
1004a6750:     	ldr	x0, [sp, #0x30]
1004a6754:     	mov	x2, x25
1004a6758:     	bl	0x101acb460 ; selector addSubview:
1004a675c:     	mov	x0, x19
1004a6760:     	bl	0x101aca960 ; symbol _swift_release
1004a6764:     	mov	x0, x20
1004a6768:     	bl	0x101ac9d30 ; symbol _objc_release
1004a676c:     	mov	x0, x27
1004a6770:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1004a6774:     	mov	x0, x24
1004a6778:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
1004a677c:     	fmov	d14, #5.00000000
1004a6780:     	mov	x0, x25
1004a6784:     	bl	0x101ac9d30 ; symbol _objc_release
1004a6788:     	fadd	d12, d12, d14
1004a678c:     	add	x26, x26, #0x38
1004a6790:     	ldr	x10, [sp, #0x38]
1004a6794:     	subs	x10, x10, #0x1
1004a6798:     	b.eq	0x1004a6f1c
1004a679c:     	str	x10, [sp, #0x38]
1004a67a0:     	add	x19, x22, x26
1004a67a4:     	ldp	x28, x24, [x19, #0x20]
1004a67a8:     	ldp	x20, x27, [x19, #0x30]
1004a67ac:     	ldr	x25, [x19, #0x40]
1004a67b0:     	adrp	x0, 0x1021da000
1004a67b4:     	add	x0, x0, #0x610
1004a67b8:     	mov	w1, #0x20               ; =32
1004a67bc:     	mov	w2, #0x7                ; =7
1004a67c0:     	bl	0x101aca588 ; symbol _swift_allocObject
1004a67c4:     	ldr	x21, [x19, #0x50]
1004a67c8:     	ldur	q0, [x19, #0x48]
1004a67cc:     	mov	x19, x0
1004a67d0:     	str	q0, [x0, #0x10]
1004a67d4:     	mov	w8, #0x2d2d             ; =11565
1004a67d8:     	movk	w8, #0x2d, lsl #16
1004a67dc:     	cmp	x28, x8
1004a67e0:     	mov	x8, #-0x1d00000000000000 ; =-2089670227099910144
1004a67e4:     	ccmp	x24, x8, #0x0, eq
1004a67e8:     	b.eq	0x1004a680c
1004a67ec:     	mov	x0, x28
1004a67f0:     	mov	x1, x24
1004a67f4:     	mov	w2, #0x2d2d             ; =11565
1004a67f8:     	movk	w2, #0x2d, lsl #16
1004a67fc:     	mov	x3, #-0x1d00000000000000 ; =-2089670227099910144
1004a6800:     	mov	w4, #0x0                ; =0
1004a6804:     	bl	0x101ac7c90 ; symbol _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004a6808:     	tbz	w0, #0x0, 0x1004a68d0
1004a680c:     	fadd	d14, d12, d15
1004a6810:     	adrp	x8, 0x102326000
1004a6814:     	ldr	x23, [x8, #0xa40]
1004a6818:     	mov	x0, x24
1004a681c:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
1004a6820:     	mov	x0, x27
1004a6824:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
1004a6828:     	mov	x0, x25
1004a682c:     	bl	0x101ac9d3c ; symbol _objc_retain
1004a6830:     	mov	x20, x0
1004a6834:     	mov	x0, x21
1004a6838:     	bl	0x101aca978 ; symbol _swift_retain
1004a683c:     	mov	x0, x23
1004a6840:     	bl	0x101ac9cb8 ; symbol _objc_allocWithZone
1004a6844:     	fmov	d0, #12.00000000
1004a6848:     	fmov	d3, #1.00000000
1004a684c:     	mov.16b	v1, v14
1004a6850:     	mov.16b	v2, v13
1004a6854:     	bl	0x101ace5a0 ; selector initWithFrame:
1004a6858:     	mov	x25, x0
1004a685c:     	mov	w2, #0x1                ; =1
1004a6860:     	bl	0x101ad4ca0 ; selector setWantsLayer:
1004a6864:     	mov	x0, x25
1004a6868:     	bl	0x101acf2c0 ; selector layer
1004a686c:     	mov	x29, x29
