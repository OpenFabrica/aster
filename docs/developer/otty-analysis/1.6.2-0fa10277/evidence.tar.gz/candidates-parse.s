
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101588c48 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE>:
101588c48: d101c3ff    	sub	sp, sp, #0x70
101588c4c: a9054ff4    	stp	x20, x19, [sp, #0x50]
101588c50: a9067bfd    	stp	x29, x30, [sp, #0x60]
101588c54: 910183fd    	add	x29, sp, #0x60
101588c58: aa0803f4    	mov	x20, x8
101588c5c: a90007e0    	stp	x0, x1, [sp]
101588c60: 97cf0f41    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
101588c64: 910043e8    	add	x8, sp, #0x10
101588c68: 940a0ab3    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
101588c6c: a941a3f3    	ldp	x19, x8, [sp, #0x18]
101588c70: f100151f    	cmp	x8, #0x5
101588c74: 540002cc    	b.gt	0x101588ccc <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x84>
101588c78: f1000d1f    	cmp	x8, #0x3
101588c7c: 5400048c    	b.gt	0x101588d0c <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0xc4>
101588c80: f100091f    	cmp	x8, #0x2
101588c84: 54000960    	b.eq	0x101588db0 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x168>
101588c88: f1000d1f    	cmp	x8, #0x3
101588c8c: 54000e81    	b.ne	0x101588e5c <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x214>
101588c90: 79400268    	ldrh	w8, [x19]
101588c94: 39400a69    	ldrb	w9, [x19, #0x2]
101588c98: 528ccdea    	mov	w10, #0x666f            ; =26223
101588c9c: 6b0a011f    	cmp	w8, w10
101588ca0: 52800cc8    	mov	w8, #0x66               ; =102
101588ca4: 7a480120    	ccmp	w9, w8, #0x0, eq
101588ca8: 54001060    	b.eq	0x101588eb4 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x26c>
101588cac: 79400268    	ldrh	w8, [x19]
101588cb0: 39400a69    	ldrb	w9, [x19, #0x2]
101588cb4: 528e6caa    	mov	w10, #0x7365            ; =29541
101588cb8: 6b0a011f    	cmp	w8, w10
101588cbc: 52800c68    	mov	w8, #0x63               ; =99
101588cc0: 7a480120    	ccmp	w9, w8, #0x0, eq
101588cc4: 54000cc1    	b.ne	0x101588e5c <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x214>
101588cc8: 14000049    	b	0x101588dec <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x1a4>
101588ccc: f1001d1f    	cmp	x8, #0x7
101588cd0: 5400038c    	b.gt	0x101588d40 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0xf8>
101588cd4: f100191f    	cmp	x8, #0x6
101588cd8: 540007a0    	b.eq	0x101588dcc <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x184>
101588cdc: f1001d1f    	cmp	x8, #0x7
101588ce0: 54000be1    	b.ne	0x101588e5c <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x214>
101588ce4: b9400268    	ldr	w8, [x19]
101588ce8: b8403269    	ldur	w9, [x19, #0x3]
101588cec: 528d2c8a    	mov	w10, #0x6964            ; =26980
101588cf0: 72ac2e6a    	movk	w10, #0x6173, lsl #16
101588cf4: 6b0a011f    	cmp	w8, w10
101588cf8: 528c4c28    	mov	w8, #0x6261             ; =25185
101588cfc: 72acad88    	movk	w8, #0x656c, lsl #16
101588d00: 7a480120    	ccmp	w9, w8, #0x0, eq
101588d04: 54000ac1    	b.ne	0x101588e5c <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x214>
101588d08: 1400006b    	b	0x101588eb4 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x26c>
101588d0c: f100111f    	cmp	x8, #0x4
101588d10: 54000740    	b.eq	0x101588df8 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x1b0>
101588d14: f100151f    	cmp	x8, #0x5
101588d18: 54000a21    	b.ne	0x101588e5c <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x214>
101588d1c: b9400268    	ldr	w8, [x19]
101588d20: 39401269    	ldrb	w9, [x19, #0x4]
101588d24: 528c2cca    	mov	w10, #0x6166            ; =24934
101588d28: 72ae6d8a    	movk	w10, #0x736c, lsl #16
101588d2c: 6b0a011f    	cmp	w8, w10
101588d30: 52800ca8    	mov	w8, #0x65               ; =101
101588d34: 7a480120    	ccmp	w9, w8, #0x0, eq
101588d38: 54000921    	b.ne	0x101588e5c <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x214>
101588d3c: 1400005e    	b	0x101588eb4 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x26c>
101588d40: f100211f    	cmp	x8, #0x8
101588d44: 540007e0    	b.eq	0x101588e40 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x1f8>
101588d48: f100351f    	cmp	x8, #0xd
101588d4c: 54000881    	b.ne	0x101588e5c <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x214>
101588d50: d2856dc8    	mov	x8, #0x2b6e             ; =11118
101588d54: f2ae6ca8    	movk	x8, #0x7365, lsl #16
101588d58: f2cc2c68    	movk	x8, #0x6163, lsl #32
101588d5c: f2ecae08    	movk	x8, #0x6570, lsl #48
101588d60: f9400269    	ldr	x9, [x19]
101588d64: f840526a    	ldur	x10, [x19, #0x5]
101588d68: 9108010b    	add	x11, x8, #0x200
101588d6c: d28e0dec    	mov	x12, #0x706f            ; =28783
101588d70: f2ad2e8c    	movk	x12, #0x6974, lsl #16
101588d74: f2cdcdec    	movk	x12, #0x6e6f, lsl #32
101588d78: f2eca5ac    	movk	x12, #0x652d, lsl #48
101588d7c: eb0c013f    	cmp	x9, x12
101588d80: fa4b0140    	ccmp	x10, x11, #0x0, eq
101588d84: 540001e0    	b.eq	0x101588dc0 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x178>
101588d88: f9400269    	ldr	x9, [x19]
101588d8c: f840526a    	ldur	x10, [x19, #0x5]
101588d90: d28e0deb    	mov	x11, #0x706f            ; =28783
101588d94: f2ad2e8b    	movk	x11, #0x6974, lsl #16
101588d98: f2cdcdeb    	movk	x11, #0x6e6f, lsl #32
101588d9c: f2eca56b    	movk	x11, #0x652b, lsl #48
101588da0: eb0b013f    	cmp	x9, x11
101588da4: fa480140    	ccmp	x10, x8, #0x0, eq
101588da8: 540005a1    	b.ne	0x101588e5c <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x214>
101588dac: 14000005    	b	0x101588dc0 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x178>
101588db0: 79400268    	ldrh	w8, [x19]
101588db4: 5286acc9    	mov	w9, #0x3566             ; =13670
101588db8: 6b09011f    	cmp	w8, w9
101588dbc: 54000501    	b.ne	0x101588e5c <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x214>
101588dc0: 52800068    	mov	w8, #0x3                ; =3
101588dc4: 39002288    	strb	w8, [x20, #0x8]
101588dc8: 1400003c    	b	0x101588eb8 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x270>
101588dcc: b9400268    	ldr	w8, [x19]
101588dd0: 79400a69    	ldrh	w9, [x19, #0x4]
101588dd4: 528e6caa    	mov	w10, #0x7365            ; =29541
101588dd8: 72ac2c6a    	movk	w10, #0x6163, lsl #16
101588ddc: 6b0a011f    	cmp	w8, w10
101588de0: 528cae08    	mov	w8, #0x6570             ; =25968
101588de4: 7a480120    	ccmp	w9, w8, #0x0, eq
101588de8: 540003a1    	b.ne	0x101588e5c <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x214>
101588dec: 52800048    	mov	w8, #0x2                ; =2
101588df0: 39002288    	strb	w8, [x20, #0x8]
101588df4: 14000031    	b	0x101588eb8 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x270>
101588df8: b9400268    	ldr	w8, [x19]
101588dfc: 528dedc9    	mov	w9, #0x6f6e             ; =28526
101588e00: 72acadc9    	movk	w9, #0x656e, lsl #16
101588e04: 6b09011f    	cmp	w8, w9
101588e08: 54000560    	b.eq	0x101588eb4 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x26c>
101588e0c: b9400268    	ldr	w8, [x19]
101588e10: 528eac29    	mov	w9, #0x7561             ; =30049
101588e14: 72adee89    	movk	w9, #0x6f74, lsl #16
101588e18: 6b09011f    	cmp	w8, w9
101588e1c: 540000c0    	b.eq	0x101588e34 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x1ec>
101588e20: b9400268    	ldr	w8, [x19]
101588e24: 528e4e89    	mov	w9, #0x7274             ; =29300
101588e28: 72acaea9    	movk	w9, #0x6575, lsl #16
101588e2c: 6b09011f    	cmp	w8, w9
101588e30: 54000161    	b.ne	0x101588e5c <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x214>
101588e34: 52800028    	mov	w8, #0x1                ; =1
101588e38: 39002288    	strb	w8, [x20, #0x8]
101588e3c: 1400001f    	b	0x101588eb8 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x270>
101588e40: f9400268    	ldr	x8, [x19]
101588e44: d28d2c89    	mov	x9, #0x6964             ; =26980
101588e48: f2ac2e69    	movk	x9, #0x6173, lsl #16
101588e4c: f2cd8c49    	movk	x9, #0x6c62, lsl #32
101588e50: f2ec8ca9    	movk	x9, #0x6465, lsl #48
101588e54: eb09011f    	cmp	x8, x9
101588e58: 540002e0    	b.eq	0x101588eb4 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x26c>
101588e5c: 910003e8    	mov	x8, sp
101588e60: f00003c9    	adrp	x9, 0x101603000 <__ZN3std2io5error5Error3new17h3fc09d96e530f798E+0x13fc>
101588e64: 910c9129    	add	x9, x9, #0x324
101588e68: a93e27a8    	stp	x8, x9, [x29, #-0x20]
101588e6c: d0004440    	adrp	x0, 0x101e12000 <_writev+0x101e12000>
101588e70: 911b6000    	add	x0, x0, #0x6d8
101588e74: 9100a3e8    	add	x8, sp, #0x28
101588e78: d10083a1    	sub	x1, x29, #0x20
101588e7c: 940a09c1    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
101588e80: 3cc283e0    	ldur	q0, [sp, #0x28]
101588e84: 3d800280    	str	q0, [x20]
101588e88: f9401fe8    	ldr	x8, [sp, #0x38]
101588e8c: f9000a88    	str	x8, [x20, #0x10]
101588e90: f9400be1    	ldr	x1, [sp, #0x10]
101588e94: b4000081    	cbz	x1, 0x101588ea4 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x25c>
101588e98: aa1303e0    	mov	x0, x19
101588e9c: 52800022    	mov	w2, #0x1                ; =1
101588ea0: 97d4560f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101588ea4: a9467bfd    	ldp	x29, x30, [sp, #0x60]
101588ea8: a9454ff4    	ldp	x20, x19, [sp, #0x50]
101588eac: 9101c3ff    	add	sp, sp, #0x70
101588eb0: d65f03c0    	ret
101588eb4: 3900229f    	strb	wzr, [x20, #0x8]
101588eb8: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101588ebc: f9000288    	str	x8, [x20]
101588ec0: f9400be1    	ldr	x1, [sp, #0x10]
101588ec4: b5fffea1    	cbnz	x1, 0x101588e98 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x250>
101588ec8: 17fffff7    	b	0x101588ea4 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x25c>
101588ecc: aa0003f4    	mov	x20, x0
101588ed0: f9400be1    	ldr	x1, [sp, #0x10]
101588ed4: b4000081    	cbz	x1, 0x101588ee4 <__ZN11otty_config22AutocompleteCandidates5parse17ha74f16f58fd9f05fE+0x29c>
101588ed8: aa1303e0    	mov	x0, x19
101588edc: 52800022    	mov	w2, #0x1                ; =1
101588ee0: 97d455ff    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101588ee4: aa1403e0    	mov	x0, x20
101588ee8: 941501bb    	bl	0x101ac95d4 <_writev+0x101ac95d4>
