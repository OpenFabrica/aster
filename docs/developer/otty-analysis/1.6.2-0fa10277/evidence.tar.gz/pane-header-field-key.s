1004bf64c:	stp	x24, x23, [sp, #-0x40]!
1004bf650:	stp	x22, x21, [sp, #0x10]
1004bf654:	stp	x20, x19, [sp, #0x20]
1004bf658:	stp	x29, x30, [sp, #0x30]
1004bf65c:	add	x29, sp, #0x30
1004bf660:	mov	x22, x4
1004bf664:	mov	x20, x3
1004bf668:	mov	x23, x0
1004bf66c:	adrp	x8, 7778 ; 0x102321000
1004bf670:	ldr	x24, [x8, #0x590] ; Objc selector ref: insertNewline:
1004bf674:	mov	x0, x2
1004bf678:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bf67c:	mov	x19, x0
1004bf680:	mov	x0, x20
1004bf684:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bf688:	mov	x21, x0
1004bf68c:	mov	x0, x23
1004bf690:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004bf694:	mov	x20, x0
1004bf698:	mov	x0, x22
1004bf69c:	mov	x1, x24
1004bf6a0:	bl	0x101ac51d0 ; symbol stub for: _$s10ObjectiveC8SelectorV2eeoiySbAC_ACtFZ
1004bf6a4:	tbz	w0, #0x0, 0x1004bf6d8
1004bf6a8:	adrp	x8, 7783 ; 0x102326000
1004bf6ac:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004bf6b0:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004bf6b4:	mov	x1, x0
1004bf6b8:	mov	x0, x19
1004bf6bc:	mov	x2, #0x0
1004bf6c0:	mov	w3, #0x0
1004bf6c4:	mov	w4, #0x0
1004bf6c8:	bl	0x101aca720 ; symbol stub for: _swift_dynamicCastObjCClassUnconditional
1004bf6cc:	bl	0x1004b5d84
1004bf6d0:	mov	w22, #0x1
1004bf6d4:	b	0x1004bf714
1004bf6d8:	adrp	x8, 7778 ; 0x102321000
1004bf6dc:	ldr	x1, [x8, #0x828] ; Objc selector ref: cancelOperation:
1004bf6e0:	mov	x0, x22
1004bf6e4:	bl	0x101ac51d0 ; symbol stub for: _$s10ObjectiveC8SelectorV2eeoiySbAC_ACtFZ
1004bf6e8:	tbz	w0, #0x0, 0x1004bf710
1004bf6ec:	ldr	x8, [x20]
1004bf6f0:	adrp	x9, 7696 ; 0x1022cf000
1004bf6f4:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004bf6f8:	ldr	x9, [x9]
1004bf6fc:	and	x8, x9, x8
1004bf700:	ldr	x8, [x8, #0x248]
1004bf704:	blr	x8
1004bf708:	mov	w22, #0x1
1004bf70c:	b	0x1004bf714
1004bf710:	mov	w22, #0x0
1004bf714:	mov	x0, x20
1004bf718:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf71c:	mov	x0, x19
1004bf720:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf724:	mov	x0, x21
1004bf728:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004bf72c:	mov	x0, x22
1004bf730:	ldp	x29, x30, [sp, #0x30]
1004bf734:	ldp	x20, x19, [sp, #0x20]
1004bf738:	ldp	x22, x21, [sp, #0x10]
1004bf73c:	ldp	x24, x23, [sp], #0x40
1004bf740:	ret
