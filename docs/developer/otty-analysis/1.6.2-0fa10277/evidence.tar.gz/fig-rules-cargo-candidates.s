
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001013fdd28 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE>:
1013fe020: d10243ff    	sub	sp, sp, #0x90
1013fe024: a9036ffc    	stp	x28, x27, [sp, #0x30]
1013fe028: a90467fa    	stp	x26, x25, [sp, #0x40]
1013fe02c: a9055ff8    	stp	x24, x23, [sp, #0x50]
1013fe030: a90657f6    	stp	x22, x21, [sp, #0x60]
1013fe034: a9074ff4    	stp	x20, x19, [sp, #0x70]
1013fe038: a9087bfd    	stp	x29, x30, [sp, #0x80]
1013fe03c: 910203fd    	add	x29, sp, #0x80
1013fe040: aa0003f4    	mov	x20, x0
1013fe044: f9400c39    	ldr	x25, [x1, #0x18]
1013fe048: f940043a    	ldr	x26, [x1, #0x8]
1013fe04c: eb19035f    	cmp	x26, x25
1013fe050: 54000300    	b.eq	0x1013fe0b0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x388>
1013fe054: aa0103f6    	mov	x22, x1
1013fe058: f9401038    	ldr	x24, [x1, #0x20]
1013fe05c: d2f0001b    	mov	x27, #-0x8000000000000000 ; =-9223372036854775808
1013fe060: 14000005    	b	0x1013fe074 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x34c>
1013fe064: eb1b027f    	cmp	x19, x27
1013fe068: 540002a1    	b.ne	0x1013fe0bc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x394>
1013fe06c: eb19035f    	cmp	x26, x25
1013fe070: 54000200    	b.eq	0x1013fe0b0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x388>
1013fe074: a9405753    	ldp	x19, x21, [x26]
1013fe078: f9400b57    	ldr	x23, [x26, #0x10]
1013fe07c: 9100635a    	add	x26, x26, #0x18
1013fe080: f90006da    	str	x26, [x22, #0x8]
1013fe084: aa1803e0    	mov	x0, x24
1013fe088: aa1503e1    	mov	x1, x21
1013fe08c: aa1703e2    	mov	x2, x23
1013fe090: 940042ef    	bl	0x10140ec4c <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E>
1013fe094: 3707fe80    	tbnz	w0, #0x0, 0x1013fe064 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x33c>
1013fe098: b4fffeb3    	cbz	x19, 0x1013fe06c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x344>
1013fe09c: aa1503e0    	mov	x0, x21
1013fe0a0: aa1303e1    	mov	x1, x19
1013fe0a4: 52800022    	mov	w2, #0x1                ; =1
1013fe0a8: 97da818d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe0ac: 17fffff0    	b	0x1013fe06c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x344>
1013fe0b0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013fe0b4: f9000288    	str	x8, [x20]
1013fe0b8: 14000021    	b	0x1013fe13c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x414>
1013fe0bc: a942dad9    	ldp	x25, x22, [x22, #0x28]
1013fe0c0: b4000176    	cbz	x22, 0x1013fe0ec <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x3c4>
1013fe0c4: 97da818b    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1013fe0c8: aa1603e0    	mov	x0, x22
1013fe0cc: 52800021    	mov	w1, #0x1                ; =1
1013fe0d0: 97da8182    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1013fe0d4: aa0003f8    	mov	x24, x0
1013fe0d8: b50000c0    	cbnz	x0, 0x1013fe0f0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x3c8>
1013fe0dc: 52800020    	mov	w0, #0x1                ; =1
1013fe0e0: aa1603e1    	mov	x1, x22
1013fe0e4: 941b14a4    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1013fe0e8: d4200020    	brk	#0x1
1013fe0ec: 52800038    	mov	w24, #0x1               ; =1
1013fe0f0: aa1803e0    	mov	x0, x24
1013fe0f4: aa1903e1    	mov	x1, x25
1013fe0f8: aa1603e2    	mov	x2, x22
1013fe0fc: 941b2ecb    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1013fe100: a90057f3    	stp	x19, x21, [sp]
1013fe104: f9000bf7    	str	x23, [sp, #0x10]
1013fe108: 910063e8    	add	x8, sp, #0x18
1013fe10c: 910003e0    	mov	x0, sp
1013fe110: 9410442f    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1013fe114: 3cc183e0    	ldur	q0, [sp, #0x18]
1013fe118: f94017e8    	ldr	x8, [sp, #0x28]
1013fe11c: 3d800280    	str	q0, [x20]
1013fe120: a9014e88    	stp	x8, x19, [x20, #0x10]
1013fe124: a9025e95    	stp	x21, x23, [x20, #0x20]
1013fe128: a9036296    	stp	x22, x24, [x20, #0x30]
1013fe12c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013fe130: a9042296    	stp	x22, x8, [x20, #0x40]
1013fe134: 52804008    	mov	w8, #0x200              ; =512
1013fe138: 7900c288    	strh	w8, [x20, #0x60]
1013fe13c: a9487bfd    	ldp	x29, x30, [sp, #0x80]
1013fe140: a9474ff4    	ldp	x20, x19, [sp, #0x70]
1013fe144: a94657f6    	ldp	x22, x21, [sp, #0x60]
1013fe148: a9455ff8    	ldp	x24, x23, [sp, #0x50]
1013fe14c: a94467fa    	ldp	x26, x25, [sp, #0x40]
1013fe150: a9436ffc    	ldp	x28, x27, [sp, #0x30]
1013fe154: 910243ff    	add	sp, sp, #0x90
1013fe158: d65f03c0    	ret
1013fe15c: 1400000c    	b	0x1013fe18c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x464>
1013fe160: aa0003f4    	mov	x20, x0
1013fe164: b40000b3    	cbz	x19, 0x1013fe178 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x450>
1013fe168: aa1503e0    	mov	x0, x21
1013fe16c: aa1303e1    	mov	x1, x19
1013fe170: 52800022    	mov	w2, #0x1                ; =1
1013fe174: 97da815a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe178: f240fadf    	tst	x22, #0x7fffffffffffffff
1013fe17c: 54000140    	b.eq	0x1013fe1a4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x47c>
1013fe180: aa1803e0    	mov	x0, x24
1013fe184: aa1603e1    	mov	x1, x22
1013fe188: 14000005    	b	0x1013fe19c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x474>
1013fe18c: aa0003f4    	mov	x20, x0
1013fe190: b40000b3    	cbz	x19, 0x1013fe1a4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x47c>
1013fe194: aa1503e0    	mov	x0, x21
1013fe198: aa1303e1    	mov	x1, x19
1013fe19c: 52800022    	mov	w2, #0x1                ; =1
1013fe1a0: 97da814f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe1a4: aa1403e0    	mov	x0, x20
1013fe1a8: 941b2d0b    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013fe1ac: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
1013fe1b0: a90167fa    	stp	x26, x25, [sp, #0x10]
1013fe1b4: a9025ff8    	stp	x24, x23, [sp, #0x20]
1013fe1b8: a90357f6    	stp	x22, x21, [sp, #0x30]
1013fe1bc: a9044ff4    	stp	x20, x19, [sp, #0x40]
1013fe1c0: a9057bfd    	stp	x29, x30, [sp, #0x50]
1013fe1c4: 910143fd    	add	x29, sp, #0x50
1013fe1c8: d132c3ff    	sub	sp, sp, #0xcb0
1013fe1cc: f90003ff    	str	xzr, [sp]
1013fe1d0: f9443028    	ldr	x8, [x1, #0x860]
1013fe1d4: b4001328    	cbz	x8, 0x1013fe438 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x710>
1013fe1d8: aa0103f5    	mov	x21, x1
1013fe1dc: 39616028    	ldrb	w8, [x1, #0x858]
1013fe1e0: 7100091f    	cmp	w8, #0x2
1013fe1e4: 540012a0    	b.eq	0x1013fe438 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x710>
1013fe1e8: f94436a8    	ldr	x8, [x21, #0x868]
1013fe1ec: a90023e0    	stp	x0, x8, [sp]
1013fe1f0: 912142b6    	add	x22, x21, #0x850
1013fe1f4: 910043f7    	add	x23, sp, #0x10
1013fe1f8: 910043e8    	add	x8, sp, #0x10
1013fe1fc: aa1603e0    	mov	x0, x22
1013fe200: 940fae64    	bl	0x1017e9b90 <__ZN75_$LT$std..fs..ReadDir$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h8142713fd293396eE>
1013fe204: b94013e8    	ldr	w8, [sp, #0x10]
1013fe208: 7100051f    	cmp	w8, #0x1
1013fe20c: 54000fa1    	b.ne	0x1013fe400 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x6d8>
1013fe210: b24107f3    	mov	x19, #-0x7fffffffffffffff ; =-9223372036854775807
1013fe214: 14000008    	b	0x1013fe234 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x50c>
1013fe218: eb13031f    	cmp	x24, x19
1013fe21c: 54001221    	b.ne	0x1013fe460 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x738>
1013fe220: 910043e8    	add	x8, sp, #0x10
1013fe224: aa1603e0    	mov	x0, x22
1013fe228: 940fae5a    	bl	0x1017e9b90 <__ZN75_$LT$std..fs..ReadDir$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h8142713fd293396eE>
1013fe22c: b94013e8    	ldr	w8, [sp, #0x10]
1013fe230: 36000e88    	tbz	w8, #0x0, 0x1013fe400 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x6d8>
1013fe234: a941e3f9    	ldp	x25, x24, [sp, #0x18]
1013fe238: b40005b9    	cbz	x25, 0x1013fe2ec <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x5c4>
1013fe23c: f90223f8    	str	x24, [sp, #0x440]
1013fe240: 9110e3e8    	add	x8, sp, #0x438
1013fe244: 91004100    	add	x0, x8, #0x10
1013fe248: 910062e1    	add	x1, x23, #0x18
1013fe24c: 52808202    	mov	w2, #0x410              ; =1040
1013fe250: 941b2e76    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1013fe254: f9021fff    	str	xzr, [sp, #0x438]
1013fe258: f90433f8    	str	x24, [sp, #0x860]
1013fe25c: 912163e8    	add	x8, sp, #0x858
1013fe260: 91004100    	add	x0, x8, #0x10
1013fe264: 910062e1    	add	x1, x23, #0x18
1013fe268: 52808202    	mov	w2, #0x410              ; =1040
1013fe26c: 941b2e6f    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1013fe270: f94432a8    	ldr	x8, [x21, #0x860]
1013fe274: d1000508    	sub	x8, x8, #0x1
1013fe278: f90432a8    	str	x8, [x21, #0x860]
1013fe27c: f9042ff9    	str	x25, [sp, #0x858]
1013fe280: d10223a8    	sub	x8, x29, #0x88
1013fe284: 912163e0    	add	x0, sp, #0x858
1013fe288: 940ecccb    	bl	0x1017b15b4 <__ZN3std2fs8DirEntry9file_name17h6382942abec15980E>
1013fe28c: a977e3b9    	ldp	x25, x24, [x29, #-0x88]
1013fe290: f85883bb    	ldur	x27, [x29, #-0x78]
1013fe294: d101c3a8    	sub	x8, x29, #0x70
1013fe298: aa1803e0    	mov	x0, x24
1013fe29c: aa1b03e1    	mov	x1, x27
1013fe2a0: 94109a86    	bl	0x101824cb8 <__ZN4core3str8converts9from_utf817ha54c467cc832e2ffE>
1013fe2a4: b85903a8    	ldur	w8, [x29, #-0x70]
1013fe2a8: 36000108    	tbz	w8, #0x0, 0x1013fe2c8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x5a0>
1013fe2ac: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013fe2b0: eb08033f    	cmp	x25, x8
1013fe2b4: 54000421    	b.ne	0x1013fe338 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x610>
1013fe2b8: aa1803f9    	mov	x25, x24
1013fe2bc: f85983a8    	ldur	x8, [x29, #-0x68]
1013fe2c0: aa1b03f8    	mov	x24, x27
1013fe2c4: aa0803fb    	mov	x27, x8
1013fe2c8: f9442fe8    	ldr	x8, [sp, #0x858]
1013fe2cc: 92800009    	mov	x9, #-0x1               ; =-1
1013fe2d0: f8690108    	ldaddl	x9, x8, [x8]
1013fe2d4: f100051f    	cmp	x8, #0x1
1013fe2d8: 54000461    	b.ne	0x1013fe364 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x63c>
1013fe2dc: d50339bf    	dmb	ishld
1013fe2e0: 912163e0    	add	x0, sp, #0x858
1013fe2e4: 940f792a    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013fe2e8: 1400001f    	b	0x1013fe364 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x63c>
1013fe2ec: 92400708    	and	x8, x24, #0x3
1013fe2f0: f100051f    	cmp	x8, #0x1
1013fe2f4: 54fff961    	b.ne	0x1013fe220 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x4f8>
1013fe2f8: f85fff19    	ldr	x25, [x24, #-0x1]!
1013fe2fc: f940071a    	ldr	x26, [x24, #0x8]
1013fe300: f9400348    	ldr	x8, [x26]
1013fe304: b4000068    	cbz	x8, 0x1013fe310 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x5e8>
1013fe308: aa1903e0    	mov	x0, x25
1013fe30c: d63f0100    	blr	x8
1013fe310: f9400741    	ldr	x1, [x26, #0x8]
1013fe314: b4000081    	cbz	x1, 0x1013fe324 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x5fc>
1013fe318: f9400b42    	ldr	x2, [x26, #0x10]
1013fe31c: aa1903e0    	mov	x0, x25
1013fe320: 97da80ef    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe324: aa1803e0    	mov	x0, x24
1013fe328: 52800301    	mov	w1, #0x18               ; =24
1013fe32c: 52800102    	mov	w2, #0x8                ; =8
1013fe330: 97da80eb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe334: 17ffffbb    	b	0x1013fe220 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x4f8>
1013fe338: b40000b9    	cbz	x25, 0x1013fe34c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x624>
1013fe33c: aa1803e0    	mov	x0, x24
1013fe340: aa1903e1    	mov	x1, x25
1013fe344: 52800022    	mov	w2, #0x1                ; =1
1013fe348: 97da80e5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe34c: d2f00019    	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
1013fe350: f9442fe8    	ldr	x8, [sp, #0x858]
1013fe354: 92800009    	mov	x9, #-0x1               ; =-1
1013fe358: f8690108    	ldaddl	x9, x8, [x8]
1013fe35c: f100051f    	cmp	x8, #0x1
1013fe360: 54fffbe0    	b.eq	0x1013fe2dc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x5b4>
1013fe364: d2f0001a    	mov	x26, #-0x8000000000000000 ; =-9223372036854775808
1013fe368: eb1a033f    	cmp	x25, x26
1013fe36c: 54000220    	b.eq	0x1013fe3b0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x688>
1013fe370: b400009b    	cbz	x27, 0x1013fe380 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x658>
1013fe374: 39400308    	ldrb	w8, [x24]
1013fe378: 7100b91f    	cmp	w8, #0x2e
1013fe37c: 54000100    	b.eq	0x1013fe39c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x674>
1013fe380: f94007e0    	ldr	x0, [sp, #0x8]
1013fe384: aa1803e1    	mov	x1, x24
1013fe388: aa1b03e2    	mov	x2, x27
1013fe38c: 94004230    	bl	0x10140ec4c <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E>
1013fe390: 36000060    	tbz	w0, #0x0, 0x1013fe39c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x674>
1013fe394: aa1903fa    	mov	x26, x25
1013fe398: 14000006    	b	0x1013fe3b0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x688>
1013fe39c: b40000b9    	cbz	x25, 0x1013fe3b0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x688>
1013fe3a0: aa1803e0    	mov	x0, x24
1013fe3a4: aa1903e1    	mov	x1, x25
1013fe3a8: 52800022    	mov	w2, #0x1                ; =1
1013fe3ac: 97da80cc    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe3b0: f94432a8    	ldr	x8, [x21, #0x860]
1013fe3b4: f100011f    	cmp	x8, #0x0
1013fe3b8: 1a9f07e8    	cset	w8, ne
1013fe3bc: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1013fe3c0: eb09035f    	cmp	x26, x9
1013fe3c4: 1a9f17e9    	cset	w9, eq
1013fe3c8: 6a09011f    	tst	w8, w9
1013fe3cc: 9a9b139c    	csel	x28, x28, x27, ne
1013fe3d0: 9a981294    	csel	x20, x20, x24, ne
1013fe3d4: 9a9a1278    	csel	x24, x19, x26, ne
1013fe3d8: f9421fe8    	ldr	x8, [sp, #0x438]
1013fe3dc: b4fff1e8    	cbz	x8, 0x1013fe218 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x4f0>
1013fe3e0: 92800009    	mov	x9, #-0x1               ; =-1
1013fe3e4: f8690108    	ldaddl	x9, x8, [x8]
1013fe3e8: f100051f    	cmp	x8, #0x1
1013fe3ec: 54fff161    	b.ne	0x1013fe218 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x4f0>
1013fe3f0: d50339bf    	dmb	ishld
1013fe3f4: 9110e3e0    	add	x0, sp, #0x438
1013fe3f8: 940f78e5    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013fe3fc: 17ffff87    	b	0x1013fe218 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x4f0>
1013fe400: 396162a8    	ldrb	w8, [x21, #0x858]
1013fe404: 7100091f    	cmp	w8, #0x2
1013fe408: 54000120    	b.eq	0x1013fe42c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x704>
1013fe40c: f94002c8    	ldr	x8, [x22]
1013fe410: 92800009    	mov	x9, #-0x1               ; =-1
1013fe414: f8690108    	ldaddl	x9, x8, [x8]
1013fe418: f100051f    	cmp	x8, #0x1
1013fe41c: 54000081    	b.ne	0x1013fe42c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x704>
1013fe420: d50339bf    	dmb	ishld
1013fe424: aa1603e0    	mov	x0, x22
1013fe428: 940f78d9    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013fe42c: 52800048    	mov	w8, #0x2                ; =2
1013fe430: 392162a8    	strb	w8, [x21, #0x858]
1013fe434: f94003e0    	ldr	x0, [sp]
1013fe438: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013fe43c: f9000008    	str	x8, [x0]
1013fe440: 9132c3ff    	add	sp, sp, #0xcb0
1013fe444: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1013fe448: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1013fe44c: a94357f6    	ldp	x22, x21, [sp, #0x30]
1013fe450: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1013fe454: a94167fa    	ldp	x26, x25, [sp, #0x10]
1013fe458: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1013fe45c: d65f03c0    	ret
1013fe460: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013fe464: eb08031f    	cmp	x24, x8
1013fe468: f94003e0    	ldr	x0, [sp]
1013fe46c: 54fffe60    	b.eq	0x1013fe438 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x710>
1013fe470: aa0003f3    	mov	x19, x0
1013fe474: 97da809f    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1013fe478: 52800060    	mov	w0, #0x3                ; =3
1013fe47c: 52800021    	mov	w1, #0x1                ; =1
1013fe480: 97da8096    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1013fe484: b4000320    	cbz	x0, 0x1013fe4e8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x7c0>
1013fe488: aa0003f5    	mov	x21, x0
1013fe48c: 52800dc8    	mov	w8, #0x6e               ; =110
1013fe490: 39000808    	strb	w8, [x0, #0x2]
1013fe494: 528d2c48    	mov	w8, #0x6962             ; =26978
1013fe498: 79000008    	strh	w8, [x0]
1013fe49c: f9042ffa    	str	x26, [sp, #0x858]
1013fe4a0: f90433f4    	str	x20, [sp, #0x860]
1013fe4a4: f90437fc    	str	x28, [sp, #0x868]
1013fe4a8: 910043e8    	add	x8, sp, #0x10
1013fe4ac: 912163e0    	add	x0, sp, #0x858
1013fe4b0: 94104347    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1013fe4b4: 3dc007e0    	ldr	q0, [sp, #0x10]
1013fe4b8: f94013e8    	ldr	x8, [sp, #0x20]
1013fe4bc: 3d800260    	str	q0, [x19]
1013fe4c0: a9016a68    	stp	x8, x26, [x19, #0x10]
1013fe4c4: a9027274    	stp	x20, x28, [x19, #0x20]
1013fe4c8: 52800068    	mov	w8, #0x3                ; =3
1013fe4cc: a9035668    	stp	x8, x21, [x19, #0x30]
1013fe4d0: d0004208    	adrp	x8, 0x101c40000 <__ZN6rustls8versions5TLS1317h044579f6764766a2E+0x1b4a>
1013fe4d4: 3dc2a500    	ldr	q0, [x8, #0xa90]
1013fe4d8: 3d801260    	str	q0, [x19, #0x40]
1013fe4dc: 52804008    	mov	w8, #0x200              ; =512
1013fe4e0: 7900c268    	strh	w8, [x19, #0x60]
1013fe4e4: 17ffffd7    	b	0x1013fe440 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x718>
1013fe4e8: 52800020    	mov	w0, #0x1                ; =1
1013fe4ec: 52800061    	mov	w1, #0x3                ; =3
1013fe4f0: 941b13a1    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1013fe4f4: d4200020    	brk	#0x1
1013fe4f8: aa0003f3    	mov	x19, x0
1013fe4fc: b40000ba    	cbz	x26, 0x1013fe510 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x7e8>
1013fe500: aa1403e0    	mov	x0, x20
1013fe504: aa1a03e1    	mov	x1, x26
1013fe508: 52800022    	mov	w2, #0x1                ; =1
1013fe50c: 97da8074    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe510: aa1503e0    	mov	x0, x21
1013fe514: 52800061    	mov	w1, #0x3                ; =3
1013fe518: 52800022    	mov	w2, #0x1                ; =1
1013fe51c: 97da8070    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe520: aa1303e0    	mov	x0, x19
1013fe524: 941b2c2c    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013fe528: aa0003f3    	mov	x19, x0
1013fe52c: b400071a    	cbz	x26, 0x1013fe60c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8e4>
1013fe530: aa1403e0    	mov	x0, x20
1013fe534: aa1a03e1    	mov	x1, x26
1013fe538: 52800022    	mov	w2, #0x1                ; =1
1013fe53c: 97da8068    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe540: aa1303e0    	mov	x0, x19
1013fe544: 941b2c24    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013fe548: 52800048    	mov	w8, #0x2                ; =2
1013fe54c: 392162a8    	strb	w8, [x21, #0x858]
1013fe550: 941b2c21    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013fe554: aa0003f3    	mov	x19, x0
1013fe558: f9400741    	ldr	x1, [x26, #0x8]
1013fe55c: b4000081    	cbz	x1, 0x1013fe56c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x844>
1013fe560: f9400b42    	ldr	x2, [x26, #0x10]
1013fe564: aa1903e0    	mov	x0, x25
1013fe568: 97da805d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe56c: aa1803e0    	mov	x0, x24
1013fe570: 52800301    	mov	w1, #0x18               ; =24
1013fe574: 52800102    	mov	w2, #0x8                ; =8
1013fe578: 97da8059    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe57c: aa1303e0    	mov	x0, x19
1013fe580: 941b2c15    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013fe584: aa0003f3    	mov	x19, x0
1013fe588: b4000319    	cbz	x25, 0x1013fe5e8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8c0>
1013fe58c: aa1803e0    	mov	x0, x24
1013fe590: aa1903e1    	mov	x1, x25
1013fe594: 52800022    	mov	w2, #0x1                ; =1
1013fe598: 97da8051    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe59c: 14000013    	b	0x1013fe5e8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8c0>
1013fe5a0: aa0003f3    	mov	x19, x0
1013fe5a4: 14000011    	b	0x1013fe5e8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8c0>
1013fe5a8: aa0003f3    	mov	x19, x0
1013fe5ac: b40000f9    	cbz	x25, 0x1013fe5c8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8a0>
1013fe5b0: aa1803e0    	mov	x0, x24
1013fe5b4: aa1903e1    	mov	x1, x25
1013fe5b8: 52800022    	mov	w2, #0x1                ; =1
1013fe5bc: 97da8048    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe5c0: 14000002    	b	0x1013fe5c8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8a0>
1013fe5c4: aa0003f3    	mov	x19, x0
1013fe5c8: f9442fe8    	ldr	x8, [sp, #0x858]
1013fe5cc: 92800009    	mov	x9, #-0x1               ; =-1
1013fe5d0: f8690108    	ldaddl	x9, x8, [x8]
1013fe5d4: f100051f    	cmp	x8, #0x1
1013fe5d8: 54000081    	b.ne	0x1013fe5e8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8c0>
1013fe5dc: d50339bf    	dmb	ishld
1013fe5e0: 912163e0    	add	x0, sp, #0x858
1013fe5e4: 940f786a    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013fe5e8: f9421fe8    	ldr	x8, [sp, #0x438]
1013fe5ec: b4000108    	cbz	x8, 0x1013fe60c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8e4>
1013fe5f0: 92800009    	mov	x9, #-0x1               ; =-1
1013fe5f4: f8690108    	ldaddl	x9, x8, [x8]
1013fe5f8: f100051f    	cmp	x8, #0x1
1013fe5fc: 54000081    	b.ne	0x1013fe60c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8e4>
1013fe600: d50339bf    	dmb	ishld
1013fe604: 9110e3e0    	add	x0, sp, #0x438
1013fe608: 940f7861    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013fe60c: aa1303e0    	mov	x0, x19
1013fe610: 941b2bf1    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013fe614: 941b15c4    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1013fe618: 941b15c3    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1013fe61c: d10183ff    	sub	sp, sp, #0x60
1013fe620: a9025ff8    	stp	x24, x23, [sp, #0x20]
1013fe624: a90357f6    	stp	x22, x21, [sp, #0x30]
1013fe628: a9044ff4    	stp	x20, x19, [sp, #0x40]
1013fe62c: a9057bfd    	stp	x29, x30, [sp, #0x50]
1013fe630: 910143fd    	add	x29, sp, #0x50
1013fe634: aa0003f3    	mov	x19, x0
1013fe638: 39416428    	ldrb	w8, [x1, #0x59]
1013fe63c: 36000128    	tbz	w8, #0x0, 0x1013fe660 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x938>
1013fe640: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013fe644: f9000268    	str	x8, [x19]
1013fe648: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1013fe64c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1013fe650: a94357f6    	ldp	x22, x21, [sp, #0x30]
1013fe654: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1013fe658: 910183ff    	add	sp, sp, #0x60
1013fe65c: d65f03c0    	ret
1013fe660: aa0103f4    	mov	x20, x1
1013fe664: f9400836    	ldr	x22, [x1, #0x10]
1013fe668: 52800038    	mov	w24, #0x1               ; =1
1013fe66c: 14000003    	b	0x1013fe678 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x950>
1013fe670: 39416688    	ldrb	w8, [x20, #0x59]
1013fe674: 3707fe68    	tbnz	w8, #0x0, 0x1013fe640 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x918>
1013fe678: f8428295    	ldur	x21, [x20, #0x28]
1013fe67c: 910023e0    	add	x0, sp, #0x8
1013fe680: 9100a281    	add	x1, x20, #0x28
1013fe684: 9401ba16    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
1013fe688: b9400be8    	ldr	w8, [sp, #0x8]
1013fe68c: 7100051f    	cmp	w8, #0x1
1013fe690: 54000101    	b.ne	0x1013fe6b0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x988>
1013fe694: f9400fe8    	ldr	x8, [sp, #0x18]
1013fe698: f9400e89    	ldr	x9, [x20, #0x18]
1013fe69c: cb090117    	sub	x23, x8, x9
1013fe6a0: 8b0902b5    	add	x21, x21, x9
1013fe6a4: f9000e88    	str	x8, [x20, #0x18]
1013fe6a8: b50001d7    	cbnz	x23, 0x1013fe6e0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x9b8>
1013fe6ac: 1400001c    	b	0x1013fe71c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x9f4>
1013fe6b0: 39416688    	ldrb	w8, [x20, #0x59]
1013fe6b4: 3707fc68    	tbnz	w8, #0x0, 0x1013fe640 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x918>
1013fe6b8: 39016698    	strb	w24, [x20, #0x59]
1013fe6bc: 3941628a    	ldrb	w10, [x20, #0x58]
1013fe6c0: a941a688    	ldp	x8, x9, [x20, #0x18]
1013fe6c4: 3700006a    	tbnz	w10, #0x0, 0x1013fe6d0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x9a8>
1013fe6c8: eb08013f    	cmp	x9, x8
1013fe6cc: 54fffba0    	b.eq	0x1013fe640 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x918>
1013fe6d0: f842828a    	ldur	x10, [x20, #0x28]
1013fe6d4: cb080137    	sub	x23, x9, x8
1013fe6d8: 8b080155    	add	x21, x10, x8
1013fe6dc: b4000217    	cbz	x23, 0x1013fe71c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x9f4>
1013fe6e0: d10006e8    	sub	x8, x23, #0x1
1013fe6e4: 38686aa9    	ldrb	w9, [x21, x8]
1013fe6e8: 7100293f    	cmp	w9, #0xa
1013fe6ec: 54000181    	b.ne	0x1013fe71c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x9f4>
1013fe6f0: d1000ae9    	sub	x9, x23, #0x2
1013fe6f4: b40000c8    	cbz	x8, 0x1013fe70c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x9e4>
1013fe6f8: 38696aaa    	ldrb	w10, [x21, x9]
1013fe6fc: 12001d4a    	and	w10, w10, #0xff
1013fe700: 7100355f    	cmp	w10, #0xd
1013fe704: 9a9f02aa    	csel	x10, x21, xzr, eq
1013fe708: 14000002    	b	0x1013fe710 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x9e8>
1013fe70c: d280000a    	mov	x10, #0x0               ; =0
1013fe710: f100015f    	cmp	x10, #0x0
1013fe714: 9a890117    	csel	x23, x8, x9, eq
1013fe718: 9a8a02b5    	csel	x21, x21, x10, eq
1013fe71c: b4fff935    	cbz	x21, 0x1013fe640 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x918>
1013fe720: b4fffa97    	cbz	x23, 0x1013fe670 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x948>
1013fe724: aa1603e0    	mov	x0, x22
1013fe728: aa1503e1    	mov	x1, x21
1013fe72c: aa1703e2    	mov	x2, x23
1013fe730: 94004147    	bl	0x10140ec4c <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E>
1013fe734: 3607f9e0    	tbz	w0, #0x0, 0x1013fe670 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x948>
1013fe738: a9405296    	ldp	x22, x20, [x20]
1013fe73c: b4000154    	cbz	x20, 0x1013fe764 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xa3c>
1013fe740: 97da7fec    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1013fe744: aa1403e0    	mov	x0, x20
1013fe748: 52800021    	mov	w1, #0x1                ; =1
1013fe74c: 97da7fe3    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1013fe750: aa0003f8    	mov	x24, x0
1013fe754: b50000a0    	cbnz	x0, 0x1013fe768 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xa40>
1013fe758: 52800020    	mov	w0, #0x1                ; =1
1013fe75c: aa1403e1    	mov	x1, x20
1013fe760: 941b1305    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1013fe764: 52800038    	mov	w24, #0x1               ; =1
1013fe768: aa1803e0    	mov	x0, x24
1013fe76c: aa1603e1    	mov	x1, x22
1013fe770: aa1403e2    	mov	x2, x20
1013fe774: 941b2d2d    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1013fe778: a900e3f4    	stp	x20, x24, [sp, #0x8]
1013fe77c: f9000ff4    	str	x20, [sp, #0x18]
1013fe780: 910023e3    	add	x3, sp, #0x8
1013fe784: aa1303e0    	mov	x0, x19
1013fe788: aa1503e1    	mov	x1, x21
1013fe78c: aa1703e2    	mov	x2, x23
1013fe790: 52800064    	mov	w4, #0x3                ; =3
1013fe794: 9400c011    	bl	0x10142e7d8 <__ZN17otty_autocomplete3fix8distance19damerau_levenshtein17hab3f29809ff4c368E+0x7a4>
1013fe798: 17ffffac    	b	0x1013fe648 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x920>
1013fe79c: d10243ff    	sub	sp, sp, #0x90
1013fe7a0: a9036ffc    	stp	x28, x27, [sp, #0x30]
1013fe7a4: a90467fa    	stp	x26, x25, [sp, #0x40]
1013fe7a8: a9055ff8    	stp	x24, x23, [sp, #0x50]
1013fe7ac: a90657f6    	stp	x22, x21, [sp, #0x60]
1013fe7b0: a9074ff4    	stp	x20, x19, [sp, #0x70]
1013fe7b4: a9087bfd    	stp	x29, x30, [sp, #0x80]
1013fe7b8: 910203fd    	add	x29, sp, #0x80
1013fe7bc: aa0003f4    	mov	x20, x0
1013fe7c0: f9400c39    	ldr	x25, [x1, #0x18]
1013fe7c4: f940043a    	ldr	x26, [x1, #0x8]
1013fe7c8: eb19035f    	cmp	x26, x25
1013fe7cc: 54000300    	b.eq	0x1013fe82c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xb04>
1013fe7d0: aa0103f7    	mov	x23, x1
1013fe7d4: f9401038    	ldr	x24, [x1, #0x20]
1013fe7d8: d2f0001b    	mov	x27, #-0x8000000000000000 ; =-9223372036854775808
1013fe7dc: 14000005    	b	0x1013fe7f0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xac8>
1013fe7e0: eb1b027f    	cmp	x19, x27
1013fe7e4: 540002a1    	b.ne	0x1013fe838 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xb10>
1013fe7e8: eb19035f    	cmp	x26, x25
1013fe7ec: 54000200    	b.eq	0x1013fe82c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xb04>
1013fe7f0: a9405753    	ldp	x19, x21, [x26]
1013fe7f4: f9400b56    	ldr	x22, [x26, #0x10]
1013fe7f8: 9100635a    	add	x26, x26, #0x18
1013fe7fc: f90006fa    	str	x26, [x23, #0x8]
1013fe800: aa1803e0    	mov	x0, x24
1013fe804: aa1503e1    	mov	x1, x21
1013fe808: aa1603e2    	mov	x2, x22
1013fe80c: 94004110    	bl	0x10140ec4c <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E>
1013fe810: 3707fe80    	tbnz	w0, #0x0, 0x1013fe7e0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xab8>
1013fe814: b4fffeb3    	cbz	x19, 0x1013fe7e8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xac0>
1013fe818: aa1503e0    	mov	x0, x21
1013fe81c: aa1303e1    	mov	x1, x19
1013fe820: 52800022    	mov	w2, #0x1                ; =1
1013fe824: 97da7fae    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe828: 17fffff0    	b	0x1013fe7e8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xac0>
1013fe82c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013fe830: f9000288    	str	x8, [x20]
1013fe834: 1400001e    	b	0x1013fe8ac <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xb84>
1013fe838: 97da7fae    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1013fe83c: 528000e0    	mov	w0, #0x7                ; =7
1013fe840: 52800021    	mov	w1, #0x1                ; =1
1013fe844: 97da7fa5    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1013fe848: b4000420    	cbz	x0, 0x1013fe8cc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xba4>
1013fe84c: aa0003f7    	mov	x23, x0
1013fe850: 528d2ec8    	mov	w8, #0x6976             ; =26998
1013fe854: 72acac68    	movk	w8, #0x6563, lsl #16
1013fe858: b8003008    	stur	w8, [x0, #0x3]
1013fe85c: 528cae68    	mov	w8, #0x6573             ; =25971
1013fe860: 72aece48    	movk	w8, #0x7672, lsl #16
1013fe864: b9000008    	str	w8, [x0]
1013fe868: a90057f3    	stp	x19, x21, [sp]
1013fe86c: f9000bf6    	str	x22, [sp, #0x10]
1013fe870: 910063e8    	add	x8, sp, #0x18
1013fe874: 910003e0    	mov	x0, sp
1013fe878: 94104255    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1013fe87c: 3cc183e0    	ldur	q0, [sp, #0x18]
1013fe880: f94017e8    	ldr	x8, [sp, #0x28]
1013fe884: 3d800280    	str	q0, [x20]
1013fe888: a9014e88    	stp	x8, x19, [x20, #0x10]
1013fe88c: a9025a95    	stp	x21, x22, [x20, #0x20]
1013fe890: 528000e8    	mov	w8, #0x7                ; =7
1013fe894: a9035e88    	stp	x8, x23, [x20, #0x30]
1013fe898: b0004708    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1013fe89c: 3dc0d900    	ldr	q0, [x8, #0x360]
1013fe8a0: 3d801280    	str	q0, [x20, #0x40]
1013fe8a4: 52804008    	mov	w8, #0x200              ; =512
1013fe8a8: 7900c288    	strh	w8, [x20, #0x60]
1013fe8ac: a9487bfd    	ldp	x29, x30, [sp, #0x80]
1013fe8b0: a9474ff4    	ldp	x20, x19, [sp, #0x70]
1013fe8b4: a94657f6    	ldp	x22, x21, [sp, #0x60]
1013fe8b8: a9455ff8    	ldp	x24, x23, [sp, #0x50]
1013fe8bc: a94467fa    	ldp	x26, x25, [sp, #0x40]
1013fe8c0: a9436ffc    	ldp	x28, x27, [sp, #0x30]
1013fe8c4: 910243ff    	add	sp, sp, #0x90
1013fe8c8: d65f03c0    	ret
1013fe8cc: 52800020    	mov	w0, #0x1                ; =1
1013fe8d0: 528000e1    	mov	w1, #0x7                ; =7
1013fe8d4: 941b12a8    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1013fe8d8: d4200020    	brk	#0x1
1013fe8dc: aa0003f4    	mov	x20, x0
1013fe8e0: b40000b3    	cbz	x19, 0x1013fe8f4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xbcc>
1013fe8e4: aa1503e0    	mov	x0, x21
1013fe8e8: aa1303e1    	mov	x1, x19
1013fe8ec: 52800022    	mov	w2, #0x1                ; =1
1013fe8f0: 97da7f7b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe8f4: aa1703e0    	mov	x0, x23
1013fe8f8: 528000e1    	mov	w1, #0x7                ; =7
1013fe8fc: 14000006    	b	0x1013fe914 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xbec>
1013fe900: 14000001    	b	0x1013fe904 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xbdc>
1013fe904: aa0003f4    	mov	x20, x0
1013fe908: b40000b3    	cbz	x19, 0x1013fe91c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xbf4>
1013fe90c: aa1503e0    	mov	x0, x21
1013fe910: aa1303e1    	mov	x1, x19
1013fe914: 52800022    	mov	w2, #0x1                ; =1
1013fe918: 97da7f71    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fe91c: aa1403e0    	mov	x0, x20
1013fe920: 941b2b2d    	bl	0x101ac95d4 <_writev+0x101ac95d4>
