
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001014414ac <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E>:
1014414ac: 6db923e9    	stp	d9, d8, [sp, #-0x70]!
1014414b0: a9016ffc    	stp	x28, x27, [sp, #0x10]
1014414b4: a90267fa    	stp	x26, x25, [sp, #0x20]
1014414b8: a9035ff8    	stp	x24, x23, [sp, #0x30]
1014414bc: a90457f6    	stp	x22, x21, [sp, #0x40]
1014414c0: a9054ff4    	stp	x20, x19, [sp, #0x50]
1014414c4: a9067bfd    	stp	x29, x30, [sp, #0x60]
1014414c8: 910183fd    	add	x29, sp, #0x60
1014414cc: d10983ff    	sub	sp, sp, #0x260
1014414d0: a9071be1    	stp	x1, x6, [sp, #0x70]
1014414d4: f90033e3    	str	x3, [sp, #0x60]
1014414d8: 34001965    	cbz	w5, 0x101441804 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x358>
1014414dc: aa0703f3    	mov	x19, x7
1014414e0: aa0403fc    	mov	x28, x4
1014414e4: aa0203fb    	mov	x27, x2
1014414e8: aa0003f8    	mov	x24, x0
1014414ec: aa0003f5    	mov	x21, x0
1014414f0: f8468ea1    	ldr	x1, [x21, #0x68]!
1014414f4: f240f83f    	tst	x1, #0x7fffffffffffffff
1014414f8: 540001e1    	b.ne	0x101441534 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x88>
1014414fc: aa1803fa    	mov	x26, x24
101441500: f8480f41    	ldr	x1, [x26, #0x80]!
101441504: f240f83f    	tst	x1, #0x7fffffffffffffff
101441508: 54000241    	b.ne	0x101441550 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xa4>
10144150c: aa1803f4    	mov	x20, x24
101441510: f8498e81    	ldr	x1, [x20, #0x98]!
101441514: f240f83f    	tst	x1, #0x7fffffffffffffff
101441518: 540002a1    	b.ne	0x10144156c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xc0>
10144151c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101441520: f9003708    	str	x8, [x24, #0x68]
101441524: f9004308    	str	x8, [x24, #0x80]
101441528: f9004f08    	str	x8, [x24, #0x98]
10144152c: b500031b    	cbnz	x27, 0x10144158c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xe0>
101441530: 1400001b    	b	0x10144159c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xf0>
101441534: f9403b00    	ldr	x0, [x24, #0x70]
101441538: 52800022    	mov	w2, #0x1                ; =1
10144153c: 97d97468    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101441540: aa1803fa    	mov	x26, x24
101441544: f8480f41    	ldr	x1, [x26, #0x80]!
101441548: f240f83f    	tst	x1, #0x7fffffffffffffff
10144154c: 54fffe00    	b.eq	0x10144150c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x60>
101441550: f9404700    	ldr	x0, [x24, #0x88]
101441554: 52800022    	mov	w2, #0x1                ; =1
101441558: 97d97461    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10144155c: aa1803f4    	mov	x20, x24
101441560: f8498e81    	ldr	x1, [x20, #0x98]!
101441564: f240f83f    	tst	x1, #0x7fffffffffffffff
101441568: 54fffda0    	b.eq	0x10144151c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x70>
10144156c: f9405300    	ldr	x0, [x24, #0xa0]
101441570: 52800022    	mov	w2, #0x1                ; =1
101441574: 97d9745a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101441578: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10144157c: f9003708    	str	x8, [x24, #0x68]
101441580: f9004308    	str	x8, [x24, #0x80]
101441584: f9004f08    	str	x8, [x24, #0x98]
101441588: b40000bb    	cbz	x27, 0x10144159c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xf0>
10144158c: f9403be8    	ldr	x8, [sp, #0x70]
101441590: 39400108    	ldrb	w8, [x8]
101441594: 7100811f    	cmp	w8, #0x20
101441598: 54001360    	b.eq	0x101441804 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x358>
10144159c: a904d3f5    	stp	x21, x20, [sp, #0x48]
1014415a0: f90037f3    	str	x19, [sp, #0x68]
1014415a4: f9400b08    	ldr	x8, [x24, #0x10]
1014415a8: f90043fc    	str	x28, [sp, #0x80]
1014415ac: b4000ec8    	cbz	x8, 0x101441784 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2d8>
1014415b0: 910443e8    	add	x8, sp, #0x110
1014415b4: f9403be0    	ldr	x0, [sp, #0x70]
1014415b8: aa1b03f6    	mov	x22, x27
1014415bc: aa1b03e1    	mov	x1, x27
1014415c0: 940f285d    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
1014415c4: a940a708    	ldp	x8, x9, [x24, #0x8]
1014415c8: 5280030a    	mov	w10, #0x18              ; =24
1014415cc: 9b0a2134    	madd	x20, x9, x10, x8
1014415d0: a951dff3    	ldp	x19, x23, [sp, #0x118]
1014415d4: 14000003    	b	0x1014415e0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x134>
1014415d8: 910062a8    	add	x8, x21, #0x18
1014415dc: 37000c5b    	tbnz	w27, #0x0, 0x101441764 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b8>
1014415e0: aa0803f5    	mov	x21, x8
1014415e4: eb14011f    	cmp	x8, x20
1014415e8: 54000be0    	b.eq	0x101441764 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b8>
1014415ec: a94086a0    	ldp	x0, x1, [x21, #0x8]
1014415f0: 9106c3e8    	add	x8, sp, #0x1b0
1014415f4: 940f2850    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
1014415f8: a95beff9    	ldp	x25, x27, [sp, #0x1b8]
1014415fc: 910583e0    	add	x0, sp, #0x160
101441600: 8b170262    	add	x2, x19, x23
101441604: aa1303e1    	mov	x1, x19
101441608: 97ff262e    	bl	0x10140aec0 <__ZN110_$LT$otty_autocomplete..fix..rules..GitBranchExistsRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5db5b1300645ca85E+0xe10>
10144160c: d10363a0    	sub	x0, x29, #0xd8
101441610: 8b1b0322    	add	x2, x25, x27
101441614: aa1903e1    	mov	x1, x25
101441618: 97ff262a    	bl	0x10140aec0 <__ZN110_$LT$otty_autocomplete..fix..rules..GitBranchExistsRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5db5b1300645ca85E+0xe10>
10144161c: f940bbe9    	ldr	x9, [sp, #0x170]
101441620: f85383bb    	ldur	x27, [x29, #-0xc8]
101441624: d280001c    	mov	x28, #0x0               ; =0
101441628: b4000429    	cbz	x9, 0x1014416ac <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x200>
10144162c: d280000a    	mov	x10, #0x0               ; =0
101441630: f85303a8    	ldur	x8, [x29, #-0xd0]
101441634: 9280000b    	mov	x11, #-0x1              ; =-1
101441638: f940b7e0    	ldr	x0, [sp, #0x168]
10144163c: 9280000c    	mov	x12, #-0x1              ; =-1
101441640: 14000009    	b	0x101441664 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b8>
101441644: 9100054a    	add	x10, x10, #0x1
101441648: aa0c03e1    	mov	x1, x12
10144164c: aa0b03e2    	mov	x2, x11
101441650: 9100079c    	add	x28, x28, #0x1
101441654: aa0203eb    	mov	x11, x2
101441658: aa0103ec    	mov	x12, x1
10144165c: eb09015f    	cmp	x10, x9
101441660: 54000262    	b.hs	0x1014416ac <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x200>
101441664: eb1b039f    	cmp	x28, x27
101441668: 54000142    	b.hs	0x101441690 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1e4>
10144166c: b87c790d    	ldr	w13, [x8, x28, lsl #2]
101441670: b86a780e    	ldr	w14, [x0, x10, lsl #2]
101441674: 7100fdbf    	cmp	w13, #0x3f
101441678: 7a4e11a4    	ccmp	w13, w14, #0x4, ne
10144167c: 54fffe40    	b.eq	0x101441644 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x198>
101441680: aa0a03e1    	mov	x1, x10
101441684: aa1c03e2    	mov	x2, x28
101441688: 7100a9bf    	cmp	w13, #0x2a
10144168c: 54fffe20    	b.eq	0x101441650 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1a4>
101441690: b100057f    	cmn	x11, #0x1
101441694: 540003e0    	b.eq	0x101441710 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x264>
101441698: 9100058a    	add	x10, x12, #0x1
10144169c: aa0a03e1    	mov	x1, x10
1014416a0: aa0b03e2    	mov	x2, x11
1014416a4: aa0b03fc    	mov	x28, x11
1014416a8: 17ffffea    	b	0x101441650 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1a4>
1014416ac: eb1b039f    	cmp	x28, x27
1014416b0: 54000122    	b.hs	0x1014416d4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x228>
1014416b4: f85303a8    	ldur	x8, [x29, #-0xd0]
1014416b8: b87c7909    	ldr	w9, [x8, x28, lsl #2]
1014416bc: 7100a93f    	cmp	w9, #0x2a
1014416c0: 540000a1    	b.ne	0x1014416d4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x228>
1014416c4: 9100079c    	add	x28, x28, #0x1
1014416c8: eb1c037f    	cmp	x27, x28
1014416cc: 54ffff61    	b.ne	0x1014416b8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x20c>
1014416d0: aa1b03fc    	mov	x28, x27
1014416d4: f85283a8    	ldur	x8, [x29, #-0xd8]
1014416d8: b40000a8    	cbz	x8, 0x1014416ec <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x240>
1014416dc: f85303a0    	ldur	x0, [x29, #-0xd0]
1014416e0: d37ef501    	lsl	x1, x8, #2
1014416e4: 52800082    	mov	w2, #0x4                ; =4
1014416e8: 97d973fd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014416ec: eb1b039f    	cmp	x28, x27
1014416f0: 1a9f17fb    	cset	w27, eq
1014416f4: f940b3e8    	ldr	x8, [sp, #0x160]
1014416f8: b4000088    	cbz	x8, 0x101441708 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x25c>
1014416fc: f940b7e0    	ldr	x0, [sp, #0x168]
101441700: f94043fc    	ldr	x28, [sp, #0x80]
101441704: 1400000f    	b	0x101441740 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x294>
101441708: f94043fc    	ldr	x28, [sp, #0x80]
10144170c: 14000010    	b	0x10144174c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2a0>
101441710: f85283a9    	ldur	x9, [x29, #-0xd8]
101441714: b40000e9    	cbz	x9, 0x101441730 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x284>
101441718: d37ef521    	lsl	x1, x9, #2
10144171c: aa0003fb    	mov	x27, x0
101441720: aa0803e0    	mov	x0, x8
101441724: 52800082    	mov	w2, #0x4                ; =4
101441728: 97d973ed    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10144172c: aa1b03e0    	mov	x0, x27
101441730: 5280001b    	mov	w27, #0x0               ; =0
101441734: f940b3e8    	ldr	x8, [sp, #0x160]
101441738: f94043fc    	ldr	x28, [sp, #0x80]
10144173c: b4000088    	cbz	x8, 0x10144174c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2a0>
101441740: d37ef501    	lsl	x1, x8, #2
101441744: 52800082    	mov	w2, #0x4                ; =4
101441748: 97d973e5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10144174c: f940dbe1    	ldr	x1, [sp, #0x1b0]
101441750: b4fff441    	cbz	x1, 0x1014415d8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x12c>
101441754: aa1903e0    	mov	x0, x25
101441758: 52800022    	mov	w2, #0x1                ; =1
10144175c: 97d973e0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101441760: 17ffff9e    	b	0x1014415d8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x12c>
101441764: f9408be1    	ldr	x1, [sp, #0x110]
101441768: b4000081    	cbz	x1, 0x101441778 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2cc>
10144176c: aa1303e0    	mov	x0, x19
101441770: 52800022    	mov	w2, #0x1                ; =1
101441774: 97d973da    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101441778: eb1402bf    	cmp	x21, x20
10144177c: aa1603fb    	mov	x27, x22
101441780: 54000421    	b.ne	0x101441804 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x358>
101441784: 910223e8    	add	x8, sp, #0x88
101441788: f9403be0    	ldr	x0, [sp, #0x70]
10144178c: aa1b03e1    	mov	x1, x27
101441790: 9400238a    	bl	0x10144a5b8 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E>
101441794: a9494ff5    	ldp	x21, x19, [sp, #0x90]
101441798: b4000293    	cbz	x19, 0x1014417e8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x33c>
10144179c: d10363a8    	sub	x8, x29, #0xd8
1014417a0: aa1503e0    	mov	x0, x21
1014417a4: 940f368a    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1014417a8: f85283a9    	ldur	x9, [x29, #-0xd8]
1014417ac: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014417b0: f9001fe9    	str	x9, [sp, #0x38]
1014417b4: eb08013f    	cmp	x9, x8
1014417b8: 540003c1    	b.ne	0x101441830 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x384>
1014417bc: 910022b4    	add	x20, x21, #0x8
1014417c0: 14000004    	b	0x1014417d0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x324>
1014417c4: 91006294    	add	x20, x20, #0x18
1014417c8: f1000673    	subs	x19, x19, #0x1
1014417cc: 540000e0    	b.eq	0x1014417e8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x33c>
1014417d0: f85f8281    	ldur	x1, [x20, #-0x8]
1014417d4: b4ffff81    	cbz	x1, 0x1014417c4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x318>
1014417d8: f9400280    	ldr	x0, [x20]
1014417dc: 52800022    	mov	w2, #0x1                ; =1
1014417e0: 97d973bf    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014417e4: 17fffff8    	b	0x1014417c4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x318>
1014417e8: f94047e8    	ldr	x8, [sp, #0x88]
1014417ec: b40000c8    	cbz	x8, 0x101441804 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x358>
1014417f0: 8b080508    	add	x8, x8, x8, lsl #1
1014417f4: d37df101    	lsl	x1, x8, #3
1014417f8: aa1503e0    	mov	x0, x21
1014417fc: 52800102    	mov	w2, #0x8                ; =8
101441800: 97d973b7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101441804: d2800000    	mov	x0, #0x0                ; =0
101441808: aa1303e1    	mov	x1, x19
10144180c: 910983ff    	add	sp, sp, #0x260
101441810: a9467bfd    	ldp	x29, x30, [sp, #0x60]
101441814: a9454ff4    	ldp	x20, x19, [sp, #0x50]
101441818: a94457f6    	ldp	x22, x21, [sp, #0x40]
10144181c: a9435ff8    	ldp	x24, x23, [sp, #0x30]
101441820: a94267fa    	ldp	x26, x25, [sp, #0x20]
101441824: a9416ffc    	ldp	x28, x27, [sp, #0x10]
101441828: 6cc723e9    	ldp	d9, d8, [sp], #0x70
10144182c: d65f03c0    	ret
101441830: a97367a8    	ldp	x8, x25, [x29, #-0xd0]
101441834: f90023e8    	str	x8, [sp, #0x40]
101441838: 940e12da    	bl	0x1017c63a0 <__ZN3std4time10SystemTime3now17h1f829e3f63b2f4c0E>
10144183c: f900b3e0    	str	x0, [sp, #0x160]
101441840: b9016be1    	str	w1, [sp, #0x168]
101441844: d10363a8    	sub	x8, x29, #0xd8
101441848: 910583e0    	add	x0, sp, #0x160
10144184c: d2800001    	mov	x1, #0x0                ; =0
101441850: 52800002    	mov	w2, #0x0                ; =0
101441854: 940e12bf    	bl	0x1017c6350 <__ZN3std4time10SystemTime14duration_since17hb8d41322e5a737d4E>
101441858: b85283a8    	ldur	w8, [x29, #-0xd8]
10144185c: f85303a9    	ldur	x9, [x29, #-0xd0]
101441860: 7100011f    	cmp	w8, #0x0
101441864: 9a8913e8    	csel	x8, xzr, x9, ne
101441868: f9002fe8    	str	x8, [sp, #0x58]
10144186c: f94033e8    	ldr	x8, [sp, #0x60]
101441870: a91673e8    	stp	x8, x28, [sp, #0x160]
101441874: f1000b3f    	cmp	x25, #0x2
101441878: 54000443    	b.lo	0x101441900 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x454>
10144187c: f94023e8    	ldr	x8, [sp, #0x40]
101441880: 79400108    	ldrh	w8, [x8]
101441884: 5285e5c9    	mov	w9, #0x2f2e             ; =12078
101441888: 6b09011f    	cmp	w8, w9
10144188c: 54000180    	b.eq	0x1014418bc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x410>
101441890: f1000b3f    	cmp	x25, #0x2
101441894: 54000360    	b.eq	0x101441900 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x454>
101441898: f94023e9    	ldr	x9, [sp, #0x40]
10144189c: 79400128    	ldrh	w8, [x9]
1014418a0: 39400929    	ldrb	w9, [x9, #0x2]
1014418a4: 5285c5ca    	mov	w10, #0x2e2e            ; =11822
1014418a8: 6b0a011f    	cmp	w8, w10
1014418ac: 528005e8    	mov	w8, #0x2f               ; =47
1014418b0: 7a480120    	ccmp	w9, w8, #0x0, eq
1014418b4: 1a9f07e8    	cset	w8, ne
1014418b8: 14000002    	b	0x1014418c0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x414>
1014418bc: 52800008    	mov	w8, #0x0                ; =0
1014418c0: b400021c    	cbz	x28, 0x101441900 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x454>
1014418c4: 350001e8    	cbnz	w8, 0x101441900 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x454>
1014418c8: 90007148    	adrp	x8, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
1014418cc: 91182108    	add	x8, x8, #0x608
1014418d0: d0000069    	adrp	x9, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
1014418d4: 91117129    	add	x9, x9, #0x45c
1014418d8: a932a7a8    	stp	x8, x9, [x29, #-0xd8]
1014418dc: 910583e8    	add	x8, sp, #0x160
1014418e0: a933a7a8    	stp	x8, x9, [x29, #-0xc8]
1014418e4: d0004ec0    	adrp	x0, 0x101e1b000 <_writev+0x101e1b000>
1014418e8: 9102d000    	add	x0, x0, #0xb4
1014418ec: 910283e8    	add	x8, sp, #0xa0
1014418f0: d10363a1    	sub	x1, x29, #0xd8
1014418f4: 940f2723    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
1014418f8: a94a8be1    	ldp	x1, x2, [sp, #0xa8]
1014418fc: 14000005    	b	0x101441910 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x464>
101441900: d2800002    	mov	x2, #0x0                ; =0
101441904: 52800021    	mov	w1, #0x1                ; =1
101441908: a90a07ff    	stp	xzr, x1, [sp, #0xa0]
10144190c: f9005bff    	str	xzr, [sp, #0xb0]
101441910: aa1803e0    	mov	x0, x24
101441914: f94023e3    	ldr	x3, [sp, #0x40]
101441918: aa1903e4    	mov	x4, x25
10144191c: f9402fe5    	ldr	x5, [sp, #0x58]
101441920: 940009c9    	bl	0x101444044 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b98>
101441924: f1000e7f    	cmp	x19, #0x3
101441928: 54003c63    	b.lo	0x1014420b4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xc08>
10144192c: a940aebc    	ldp	x28, x11, [x21, #0x8]
101441930: f100117f    	cmp	x11, #0x4
101441934: 540003c1    	b.ne	0x1014419ac <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x500>
101441938: b9400388    	ldr	w8, [x28]
10144193c: 528e4c49    	mov	w9, #0x7262             ; =29282
101441940: 72aeeca9    	movk	w9, #0x7765, lsl #16
101441944: 6b09011f    	cmp	w8, w9
101441948: 54000560    	b.eq	0x1014419f4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x548>
10144194c: b9400388    	ldr	w8, [x28]
101441950: 528dce09    	mov	w9, #0x6e70             ; =28272
101441954: 72adae09    	movk	w9, #0x6d70, lsl #16
101441958: 6b09011f    	cmp	w8, w9
10144195c: 54000960    	b.eq	0x101441a88 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x5dc>
101441960: b9400388    	ldr	w8, [x28]
101441964: 528c2f29    	mov	w9, #0x6179             ; =24953
101441968: 72adce49    	movk	w9, #0x6e72, lsl #16
10144196c: 6b09011f    	cmp	w8, w9
101441970: 54000940    	b.eq	0x101441a98 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x5ec>
101441974: b9400388    	ldr	w8, [x28]
101441978: 528d2e09    	mov	w9, #0x6970             ; =26992
10144197c: 72a66e09    	movk	w9, #0x3370, lsl #16
101441980: 6b09011f    	cmp	w8, w9
101441984: 540009a0    	b.eq	0x101441ab8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x60c>
101441988: b9400388    	ldr	w8, [x28]
10144198c: 528d2e09    	mov	w9, #0x6970             ; =26992
101441990: 72af0e09    	movk	w9, #0x7870, lsl #16
101441994: 6b09011f    	cmp	w8, w9
101441998: 540038e1    	b.ne	0x1014420b4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xc08>
10144199c: aa1b03f6    	mov	x22, x27
1014419a0: 90007149    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
1014419a4: 9120a129    	add	x9, x9, #0x828
1014419a8: 1400004b    	b	0x101441ad4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x628>
1014419ac: f100097f    	cmp	x11, #0x2
1014419b0: 540005c0    	b.eq	0x101441a68 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x5bc>
1014419b4: f1000d7f    	cmp	x11, #0x3
1014419b8: 54000260    	b.eq	0x101441a04 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x558>
1014419bc: f100157f    	cmp	x11, #0x5
1014419c0: 540037a1    	b.ne	0x1014420b4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xc08>
1014419c4: b9400388    	ldr	w8, [x28]
1014419c8: 39401389    	ldrb	w9, [x28, #0x4]
1014419cc: 528c2c6a    	mov	w10, #0x6163            ; =24931
1014419d0: 72acee4a    	movk	w10, #0x6772, lsl #16
1014419d4: 6b0a011f    	cmp	w8, w10
1014419d8: 52800de8    	mov	w8, #0x6f               ; =111
1014419dc: 7a480120    	ccmp	w9, w8, #0x0, eq
1014419e0: 540036a1    	b.ne	0x1014420b4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xc08>
1014419e4: aa1b03f6    	mov	x22, x27
1014419e8: 90007149    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
1014419ec: 911c2129    	add	x9, x9, #0x708
1014419f0: 14000039    	b	0x101441ad4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x628>
1014419f4: aa1b03f6    	mov	x22, x27
1014419f8: 90007149    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
1014419fc: 911b6129    	add	x9, x9, #0x6d8
101441a00: 14000035    	b	0x101441ad4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x628>
101441a04: 79400388    	ldrh	w8, [x28]
101441a08: 39400b89    	ldrb	w9, [x28, #0x2]
101441a0c: 528e0dca    	mov	w10, #0x706e            ; =28782
101441a10: 6b0a011f    	cmp	w8, w10
101441a14: 52800da8    	mov	w8, #0x6d               ; =109
101441a18: 7a480120    	ccmp	w9, w8, #0x0, eq
101441a1c: 54000460    	b.eq	0x101441aa8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x5fc>
101441a20: 79400388    	ldrh	w8, [x28]
101441a24: 39400b89    	ldrb	w9, [x28, #0x2]
101441a28: 528d2e0a    	mov	w10, #0x6970            ; =26992
101441a2c: 6b0a011f    	cmp	w8, w10
101441a30: 52800e08    	mov	w8, #0x70               ; =112
101441a34: 7a480120    	ccmp	w9, w8, #0x0, eq
101441a38: 54000480    	b.eq	0x101441ac8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x61c>
101441a3c: 79400388    	ldrh	w8, [x28]
101441a40: 39400b89    	ldrb	w9, [x28, #0x2]
101441a44: 528cacea    	mov	w10, #0x6567            ; =25959
101441a48: 6b0a011f    	cmp	w8, w10
101441a4c: 52800da8    	mov	w8, #0x6d               ; =109
101441a50: 7a480120    	ccmp	w9, w8, #0x0, eq
101441a54: 54003301    	b.ne	0x1014420b4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xc08>
101441a58: aa1b03f6    	mov	x22, x27
101441a5c: 90007149    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101441a60: 91216129    	add	x9, x9, #0x858
101441a64: 1400001c    	b	0x101441ad4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x628>
101441a68: 79400388    	ldrh	w8, [x28]
101441a6c: 528dece9    	mov	w9, #0x6f67             ; =28519
101441a70: 6b09011f    	cmp	w8, w9
101441a74: 54003201    	b.ne	0x1014420b4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xc08>
101441a78: aa1b03f6    	mov	x22, x27
101441a7c: 90007149    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101441a80: 91222129    	add	x9, x9, #0x888
101441a84: 14000014    	b	0x101441ad4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x628>
101441a88: aa1b03f6    	mov	x22, x27
101441a8c: 90007149    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101441a90: 911da129    	add	x9, x9, #0x768
101441a94: 14000010    	b	0x101441ad4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x628>
101441a98: aa1b03f6    	mov	x22, x27
101441a9c: 90007149    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101441aa0: 911e6129    	add	x9, x9, #0x798
101441aa4: 1400000c    	b	0x101441ad4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x628>
101441aa8: aa1b03f6    	mov	x22, x27
101441aac: 90007149    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101441ab0: 911ce129    	add	x9, x9, #0x738
101441ab4: 14000008    	b	0x101441ad4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x628>
101441ab8: aa1b03f6    	mov	x22, x27
101441abc: 90007149    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101441ac0: 911fe129    	add	x9, x9, #0x7f8
101441ac4: 14000004    	b	0x101441ad4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x628>
101441ac8: aa1b03f6    	mov	x22, x27
101441acc: 90007149    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101441ad0: 911f2129    	add	x9, x9, #0x7c8
101441ad4: f9400d28    	ldr	x8, [x9, #0x18]
101441ad8: b4002ec8    	cbz	x8, 0x1014420b0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xc04>
101441adc: a9022fe9    	stp	x9, x11, [sp, #0x20]
101441ae0: f9400929    	ldr	x9, [x9, #0x10]
101441ae4: a94266b7    	ldp	x23, x25, [x21, #0x20]
101441ae8: d37ced14    	lsl	x20, x8, #4
101441aec: 9100213b    	add	x27, x9, #0x8
101441af0: 14000004    	b	0x101441b00 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x654>
101441af4: 9100437b    	add	x27, x27, #0x10
101441af8: f1004294    	subs	x20, x20, #0x10
101441afc: 54002da0    	b.eq	0x1014420b0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xc04>
101441b00: f9400368    	ldr	x8, [x27]
101441b04: eb19011f    	cmp	x8, x25
101441b08: 54ffff61    	b.ne	0x101441af4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x648>
101441b0c: f85f8360    	ldur	x0, [x27, #-0x8]
101441b10: aa1703e1    	mov	x1, x23
101441b14: aa1903e2    	mov	x2, x25
101441b18: 941a2041    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101441b1c: 35fffec0    	cbnz	w0, 0x101441af4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x648>
101441b20: 5280000a    	mov	w10, #0x0               ; =0
101441b24: 52800009    	mov	w9, #0x0                ; =0
101441b28: 52800108    	mov	w8, #0x8                ; =8
101441b2c: f94013eb    	ldr	x11, [sp, #0x20]
101441b30: f940156b    	ldr	x11, [x11, #0x28]
101441b34: f100017f    	cmp	x11, #0x0
101441b38: 1a9f17eb    	cset	w11, eq
101441b3c: b9001feb    	str	w11, [sp, #0x1c]
101441b40: a91b23ff    	stp	xzr, x8, [sp, #0x1b0]
101441b44: 52800308    	mov	w8, #0x18               ; =24
101441b48: 9b085668    	madd	x8, x19, x8, x21
101441b4c: f9001be8    	str	x8, [sp, #0x30]
101441b50: f900e3ff    	str	xzr, [sp, #0x1c0]
101441b54: 52800048    	mov	w8, #0x2                ; =2
101441b58: 0f020768    	movi.2s	v8, #0x5b
101441b5c: 9000714b    	adrp	x11, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101441b60: 9124016b    	add	x11, x11, #0x900
101441b64: f9000beb    	str	x11, [sp, #0x10]
101441b68: 0f020409    	movi.2s	v9, #0x40
101441b6c: aa1503f4    	mov	x20, x21
101441b70: aa1603fb    	mov	x27, x22
101441b74: aa1c03f6    	mov	x22, x28
101441b78: 1400000b    	b	0x101441ba4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6f8>
101441b7c: d2800008    	mov	x8, #0x0                ; =0
101441b80: 52800009    	mov	w9, #0x0                ; =0
101441b84: f940dfea    	ldr	x10, [sp, #0x1b8]
101441b88: 5280030b    	mov	w11, #0x18              ; =24
101441b8c: 9b0b2b2a    	madd	x10, x25, x11, x10
101441b90: a9005d5c    	stp	x28, x23, [x10]
101441b94: f900095c    	str	x28, [x10, #0x10]
101441b98: 9100072a    	add	x10, x25, #0x1
101441b9c: f900e3ea    	str	x10, [sp, #0x1c0]
101441ba0: 5280002a    	mov	w10, #0x1               ; =1
101441ba4: f94017f7    	ldr	x23, [sp, #0x28]
101441ba8: 360024aa    	tbz	w10, #0x0, 0x10144203c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb90>
101441bac: aa1403e8    	mov	x8, x20
101441bb0: f9401bea    	ldr	x10, [sp, #0x30]
101441bb4: eb0a029f    	cmp	x20, x10
101441bb8: 5400d3e0    	b.eq	0x101443634 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2188>
101441bbc: 91006114    	add	x20, x8, #0x18
101441bc0: 37002369    	tbnz	w9, #0x0, 0x10144202c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb80>
101441bc4: a940f119    	ldp	x25, x28, [x8, #0x8]
101441bc8: b400009c    	cbz	x28, 0x101441bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x72c>
101441bcc: 39400328    	ldrb	w8, [x25]
101441bd0: 7100b51f    	cmp	w8, #0x2d
101441bd4: 54001120    	b.eq	0x101441df8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x94c>
101441bd8: f10012ff    	cmp	x23, #0x4
101441bdc: 54000101    	b.ne	0x101441bfc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x750>
101441be0: b94002c8    	ldr	w8, [x22]
101441be4: 528c2f29    	mov	w9, #0x6179             ; =24953
101441be8: 72adce49    	movk	w9, #0x6e72, lsl #16
101441bec: 6b09011f    	cmp	w8, w9
101441bf0: 54000061    	b.ne	0x101441bfc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x750>
101441bf4: f940e3e8    	ldr	x8, [sp, #0x1c0]
101441bf8: b4000148    	cbz	x8, 0x101441c20 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x774>
101441bfc: f100079f    	cmp	x28, #0x1
101441c00: 540002c0    	b.eq	0x101441c58 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x7ac>
101441c04: f1000b9f    	cmp	x28, #0x2
101441c08: 540002e1    	b.ne	0x101441c64 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x7b8>
101441c0c: 79400328    	ldrh	w8, [x25]
101441c10: 5285c5c9    	mov	w9, #0x2e2e             ; =11822
101441c14: 6b09011f    	cmp	w8, w9
101441c18: 54000261    	b.ne	0x101441c64 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x7b8>
101441c1c: 14000104    	b	0x10144202c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb80>
101441c20: f100079f    	cmp	x28, #0x1
101441c24: 540001a0    	b.eq	0x101441c58 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x7ac>
101441c28: f1000b9f    	cmp	x28, #0x2
101441c2c: 54ffff00    	b.eq	0x101441c0c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x760>
101441c30: f1000f9f    	cmp	x28, #0x3
101441c34: 54000181    	b.ne	0x101441c64 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x7b8>
101441c38: 79400328    	ldrh	w8, [x25]
101441c3c: 39400b29    	ldrb	w9, [x25, #0x2]
101441c40: 528c8c2a    	mov	w10, #0x6461            ; =25697
101441c44: 6b0a011f    	cmp	w8, w10
101441c48: 52800c88    	mov	w8, #0x64               ; =100
101441c4c: 7a480120    	ccmp	w9, w8, #0x0, eq
101441c50: 540000a1    	b.ne	0x101441c64 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x7b8>
101441c54: 140000f6    	b	0x10144202c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb80>
101441c58: 39400328    	ldrb	w8, [x25]
101441c5c: 7100b91f    	cmp	w8, #0x2e
101441c60: 54001e60    	b.eq	0x10144202c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb80>
101441c64: a932f3b9    	stp	x25, x28, [x29, #-0xd8]
101441c68: a933f3bf    	stp	xzr, x28, [x29, #-0xc8]
101441c6c: 52800028    	mov	w8, #0x1                ; =1
101441c70: 381503a8    	sturb	w8, [x29, #-0xb0]
101441c74: fc1483a8    	stur	d8, [x29, #-0xb8]
101441c78: 910583e0    	add	x0, sp, #0x160
101441c7c: d10363a1    	sub	x1, x29, #0xd8
101441c80: 9400ac97    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101441c84: b94163e8    	ldr	w8, [sp, #0x160]
101441c88: 7100051f    	cmp	w8, #0x1
101441c8c: 540001c1    	b.ne	0x101441cc4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x818>
101441c90: f940b7e3    	ldr	x3, [sp, #0x168]
101441c94: b4000103    	cbz	x3, 0x101441cb4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x808>
101441c98: eb1c007f    	cmp	x3, x28
101441c9c: 54000102    	b.hs	0x101441cbc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x810>
101441ca0: 38e36b28    	ldrsb	w8, [x25, x3]
101441ca4: 3101051f    	cmn	w8, #0x41
101441ca8: 540109ed    	b.le	0x101443de4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2938>
101441cac: aa0303fc    	mov	x28, x3
101441cb0: 14000005    	b	0x101441cc4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x818>
101441cb4: d280001c    	mov	x28, #0x0               ; =0
101441cb8: 14000003    	b	0x101441cc4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x818>
101441cbc: eb1c007f    	cmp	x3, x28
101441cc0: 54010921    	b.ne	0x101443de4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2938>
101441cc4: d10363a8    	sub	x8, x29, #0xd8
101441cc8: aa1903e0    	mov	x0, x25
101441ccc: aa1c03e1    	mov	x1, x28
101441cd0: b0004502    	adrp	x2, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
101441cd4: 911ba842    	add	x2, x2, #0x6ea
101441cd8: 52800043    	mov	w3, #0x2                ; =2
101441cdc: 940f8934    	bl	0x1018241ac <__ZN4core3str7pattern11StrSearcher3new17hb0ec4e7243414bb1E>
101441ce0: 910583e0    	add	x0, sp, #0x160
101441ce4: d10363a1    	sub	x1, x29, #0xd8
101441ce8: 9400aa54    	bl	0x10146c638 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xf08>
101441cec: b94163e8    	ldr	w8, [sp, #0x160]
101441cf0: 7100051f    	cmp	w8, #0x1
101441cf4: 540001c1    	b.ne	0x101441d2c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x880>
101441cf8: f940b7e3    	ldr	x3, [sp, #0x168]
101441cfc: b4000103    	cbz	x3, 0x101441d1c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x870>
101441d00: eb1c007f    	cmp	x3, x28
101441d04: 54000102    	b.hs	0x101441d24 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x878>
101441d08: 38e36b28    	ldrsb	w8, [x25, x3]
101441d0c: 3101011f    	cmn	w8, #0x40
101441d10: 540106eb    	b.lt	0x101443dec <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2940>
101441d14: aa0303fc    	mov	x28, x3
101441d18: 14000005    	b	0x101441d2c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x880>
101441d1c: d280001c    	mov	x28, #0x0               ; =0
101441d20: 14000003    	b	0x101441d2c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x880>
101441d24: eb1c007f    	cmp	x3, x28
101441d28: 54010621    	b.ne	0x101443dec <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2940>
101441d2c: a932f3b9    	stp	x25, x28, [x29, #-0xd8]
101441d30: a933f3bf    	stp	xzr, x28, [x29, #-0xc8]
101441d34: 52800028    	mov	w8, #0x1                ; =1
101441d38: 381503a8    	sturb	w8, [x29, #-0xb0]
101441d3c: fc1483a9    	stur	d9, [x29, #-0xb8]
101441d40: 910583e0    	add	x0, sp, #0x160
101441d44: d10363a1    	sub	x1, x29, #0xd8
101441d48: 9400ac65    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101441d4c: b94163e8    	ldr	w8, [sp, #0x160]
101441d50: 7100051f    	cmp	w8, #0x1
101441d54: 540001c1    	b.ne	0x101441d8c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x8e0>
101441d58: f940b7e3    	ldr	x3, [sp, #0x168]
101441d5c: b4000103    	cbz	x3, 0x101441d7c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x8d0>
101441d60: eb1c007f    	cmp	x3, x28
101441d64: 54000102    	b.hs	0x101441d84 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x8d8>
101441d68: 38e36b28    	ldrsb	w8, [x25, x3]
101441d6c: 3101011f    	cmn	w8, #0x40
101441d70: 5401032b    	b.lt	0x101443dd4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2928>
101441d74: aa0303fc    	mov	x28, x3
101441d78: 14000005    	b	0x101441d8c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x8e0>
101441d7c: d280001c    	mov	x28, #0x0               ; =0
101441d80: 14000003    	b	0x101441d8c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x8e0>
101441d84: eb1c007f    	cmp	x3, x28
101441d88: 54010261    	b.ne	0x101443dd4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2928>
101441d8c: aa1c03e2    	mov	x2, x28
101441d90: 14000003    	b	0x101441d9c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x8f0>
101441d94: eb1c005f    	cmp	x2, x28
101441d98: 54000268    	b.hi	0x101441de4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x938>
101441d9c: 528005e0    	mov	w0, #0x2f               ; =47
101441da0: aa1903e1    	mov	x1, x25
101441da4: 940f8d9e    	bl	0x10182541c <__ZN4core5slice6memchr7memrchr17h46fa36c0891baeaeE>
101441da8: 360001e0    	tbz	w0, #0x0, 0x101441de4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x938>
101441dac: aa0103e2    	mov	x2, x1
101441db0: eb1c003f    	cmp	x1, x28
101441db4: 54ffff02    	b.hs	0x101441d94 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x8e8>
101441db8: 38626b28    	ldrb	w8, [x25, x2]
101441dbc: 7100bd1f    	cmp	w8, #0x2f
101441dc0: 54fffea1    	b.ne	0x101441d94 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x8e8>
101441dc4: 91000442    	add	x2, x2, #0x1
101441dc8: eb020388    	subs	x8, x28, x2
101441dcc: 54000089    	b.ls	0x101441ddc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x930>
101441dd0: 38e26b29    	ldrsb	w9, [x25, x2]
101441dd4: 3101013f    	cmn	w9, #0x40
101441dd8: 5401012b    	b.lt	0x101443dfc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2950>
101441ddc: 8b020339    	add	x25, x25, x2
101441de0: aa0803fc    	mov	x28, x8
101441de4: d2800008    	mov	x8, #0x0                ; =0
101441de8: 52800009    	mov	w9, #0x0                ; =0
101441dec: 5280002a    	mov	w10, #0x1               ; =1
101441df0: b500141c    	cbnz	x28, 0x101442070 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xbc4>
101441df4: 17ffff6d    	b	0x101441ba8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6fc>
101441df8: f94013e9    	ldr	x9, [sp, #0x20]
101441dfc: f9401528    	ldr	x8, [x9, #0x28]
101441e00: b40002e8    	cbz	x8, 0x101441e5c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x9b0>
101441e04: f90007f6    	str	x22, [sp, #0x8]
101441e08: aa1b03f6    	mov	x22, x27
101441e0c: f9401129    	ldr	x9, [x9, #0x20]
101441e10: d37ced17    	lsl	x23, x8, #4
101441e14: 9100213b    	add	x27, x9, #0x8
101441e18: 14000004    	b	0x101441e28 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x97c>
101441e1c: 9100437b    	add	x27, x27, #0x10
101441e20: f10042f7    	subs	x23, x23, #0x10
101441e24: 54000160    	b.eq	0x101441e50 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x9a4>
101441e28: f9400368    	ldr	x8, [x27]
101441e2c: eb1c011f    	cmp	x8, x28
101441e30: 54ffff61    	b.ne	0x101441e1c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x970>
101441e34: f85f8360    	ldur	x0, [x27, #-0x8]
101441e38: aa1903e1    	mov	x1, x25
101441e3c: aa1c03e2    	mov	x2, x28
101441e40: 941a1f77    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101441e44: 35fffec0    	cbnz	w0, 0x101441e1c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x970>
101441e48: 52800028    	mov	w8, #0x1                ; =1
101441e4c: b9001fe8    	str	w8, [sp, #0x1c]
101441e50: aa1603fb    	mov	x27, x22
101441e54: f94007f6    	ldr	x22, [sp, #0x8]
101441e58: f94017f7    	ldr	x23, [sp, #0x28]
101441e5c: f100179f    	cmp	x28, #0x5
101441e60: 5400044d    	b.le	0x101441ee8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xa3c>
101441e64: f1001b9f    	cmp	x28, #0x6
101441e68: 54000860    	b.eq	0x101441f74 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xac8>
101441e6c: f100279f    	cmp	x28, #0x9
101441e70: 54000aa0    	b.eq	0x101441fc4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb18>
101441e74: f100239f    	cmp	x28, #0x8
101441e78: 54000da1    	b.ne	0x10144202c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb80>
101441e7c: d2800008    	mov	x8, #0x0                ; =0
101441e80: f940032b    	ldr	x11, [x25]
101441e84: 5280002a    	mov	w10, #0x1               ; =1
101441e88: 52800029    	mov	w9, #0x1                ; =1
101441e8c: d285a5ac    	mov	x12, #0x2d2d            ; =11565
101441e90: f2ae4e0c    	movk	x12, #0x7270, lsl #16
101441e94: f2ccccac    	movk	x12, #0x6665, lsl #32
101441e98: f2ef0d2c    	movk	x12, #0x7869, lsl #48
101441e9c: eb0c017f    	cmp	x11, x12
101441ea0: 54ffe840    	b.eq	0x101441ba8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6fc>
101441ea4: d2800008    	mov	x8, #0x0                ; =0
101441ea8: f940032b    	ldr	x11, [x25]
101441eac: d285a5ac    	mov	x12, #0x2d2d            ; =11565
101441eb0: f2ac2e8c    	movk	x12, #0x6174, lsl #16
101441eb4: f2ccee4c    	movk	x12, #0x6772, lsl #32
101441eb8: f2ee8cac    	movk	x12, #0x7465, lsl #48
101441ebc: eb0c017f    	cmp	x11, x12
101441ec0: 54ffe740    	b.eq	0x101441ba8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6fc>
101441ec4: d2800008    	mov	x8, #0x0                ; =0
101441ec8: f940032b    	ldr	x11, [x25]
101441ecc: d285a5ac    	mov	x12, #0x2d2d            ; =11565
101441ed0: f2ae4c4c    	movk	x12, #0x7262, lsl #16
101441ed4: f2cdcc2c    	movk	x12, #0x6e61, lsl #32
101441ed8: f2ed0c6c    	movk	x12, #0x6863, lsl #48
101441edc: eb0c017f    	cmp	x11, x12
101441ee0: 54000a61    	b.ne	0x10144202c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb80>
101441ee4: 17ffff31    	b	0x101441ba8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6fc>
101441ee8: f1000b9f    	cmp	x28, #0x2
101441eec: 54000880    	b.eq	0x101441ffc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb50>
101441ef0: f100179f    	cmp	x28, #0x5
101441ef4: 540009c1    	b.ne	0x10144202c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb80>
101441ef8: d2800008    	mov	x8, #0x0                ; =0
101441efc: b9400329    	ldr	w9, [x25]
101441f00: 3940132a    	ldrb	w10, [x25, #0x4]
101441f04: 5285a5ab    	mov	w11, #0x2d2d            ; =11565
101441f08: 72ac2e8b    	movk	w11, #0x6174, lsl #16
101441f0c: 6b0b013f    	cmp	w9, w11
101441f10: 52800ce9    	mov	w9, #0x67               ; =103
101441f14: 7a490140    	ccmp	w10, w9, #0x0, eq
101441f18: 5280002a    	mov	w10, #0x1               ; =1
101441f1c: 52800029    	mov	w9, #0x1                ; =1
101441f20: 54ffe440    	b.eq	0x101441ba8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6fc>
101441f24: d2800008    	mov	x8, #0x0                ; =0
101441f28: b9400329    	ldr	w9, [x25]
101441f2c: 5285a5aa    	mov	w10, #0x2d2d            ; =11565
101441f30: 72acad6a    	movk	w10, #0x656b, lsl #16
101441f34: 1141c14a    	add	w10, w10, #0x70, lsl #12 ; =0x70000
101441f38: 3940132b    	ldrb	w11, [x25, #0x4]
101441f3c: 6b09015f    	cmp	w10, w9
101441f40: 52800ec9    	mov	w9, #0x76               ; =118
101441f44: 7a490160    	ccmp	w11, w9, #0x0, eq
101441f48: 5280002a    	mov	w10, #0x1               ; =1
101441f4c: 52800029    	mov	w9, #0x1                ; =1
101441f50: 54ffe2c0    	b.eq	0x101441ba8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6fc>
101441f54: d2800008    	mov	x8, #0x0                ; =0
101441f58: b9400329    	ldr	w9, [x25]
101441f5c: 3940132a    	ldrb	w10, [x25, #0x4]
101441f60: 5285a5ab    	mov	w11, #0x2d2d            ; =11565
101441f64: 72ad2ceb    	movk	w11, #0x6967, lsl #16
101441f68: 6b0b013f    	cmp	w9, w11
101441f6c: 52800e89    	mov	w9, #0x74               ; =116
101441f70: 1400001e    	b	0x101441fe8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb3c>
101441f74: d2800008    	mov	x8, #0x0                ; =0
101441f78: b9400329    	ldr	w9, [x25]
101441f7c: 5285a5aa    	mov	w10, #0x2d2d            ; =11565
101441f80: 72adee8a    	movk	w10, #0x6f74, lsl #16
101441f84: 5140814a    	sub	w10, w10, #0x20, lsl #12 ; =0x20000
101441f88: 79400b2b    	ldrh	w11, [x25, #0x4]
101441f8c: 6b09015f    	cmp	w10, w9
101441f90: 528e8de9    	mov	w9, #0x746f             ; =29807
101441f94: 7a490160    	ccmp	w11, w9, #0x0, eq
101441f98: 5280002a    	mov	w10, #0x1               ; =1
101441f9c: 52800029    	mov	w9, #0x1                ; =1
101441fa0: 54ffe040    	b.eq	0x101441ba8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6fc>
101441fa4: d2800008    	mov	x8, #0x0                ; =0
101441fa8: b9400329    	ldr	w9, [x25]
101441fac: 79400b2a    	ldrh	w10, [x25, #0x4]
101441fb0: 5285a5ab    	mov	w11, #0x2d2d            ; =11565
101441fb4: 72ac2e0b    	movk	w11, #0x6170, lsl #16
101441fb8: 6b09017f    	cmp	w11, w9
101441fbc: 528d0e89    	mov	w9, #0x6874             ; =26740
101441fc0: 1400000a    	b	0x101441fe8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb3c>
101441fc4: d2800008    	mov	x8, #0x0                ; =0
101441fc8: f9400329    	ldr	x9, [x25]
101441fcc: 3940232a    	ldrb	w10, [x25, #0x8]
101441fd0: d285a5ab    	mov	x11, #0x2d2d            ; =11565
101441fd4: f2acaecb    	movk	x11, #0x6576, lsl #16
101441fd8: f2ce6e4b    	movk	x11, #0x7372, lsl #32
101441fdc: f2eded2b    	movk	x11, #0x6f69, lsl #48
101441fe0: eb0b013f    	cmp	x9, x11
101441fe4: 52800dc9    	mov	w9, #0x6e               ; =110
101441fe8: 7a490140    	ccmp	w10, w9, #0x0, eq
101441fec: 5280002a    	mov	w10, #0x1               ; =1
101441ff0: 52800029    	mov	w9, #0x1                ; =1
101441ff4: 540001c1    	b.ne	0x10144202c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb80>
101441ff8: 17fffeec    	b	0x101441ba8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6fc>
101441ffc: d2800008    	mov	x8, #0x0                ; =0
101442000: 7940032b    	ldrh	w11, [x25]
101442004: 5280002a    	mov	w10, #0x1               ; =1
101442008: 52800029    	mov	w9, #0x1                ; =1
10144200c: 528e85ac    	mov	w12, #0x742d            ; =29741
101442010: 6b0c017f    	cmp	w11, w12
101442014: 54ffdca0    	b.eq	0x101441ba8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6fc>
101442018: d2800008    	mov	x8, #0x0                ; =0
10144201c: 7940032b    	ldrh	w11, [x25]
101442020: 528e45ac    	mov	w12, #0x722d            ; =29229
101442024: 6b0c017f    	cmp	w11, w12
101442028: 54ffdc00    	b.eq	0x101441ba8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6fc>
10144202c: d2800008    	mov	x8, #0x0                ; =0
101442030: 52800009    	mov	w9, #0x0                ; =0
101442034: 5280002a    	mov	w10, #0x1               ; =1
101442038: 17fffedc    	b	0x101441ba8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6fc>
10144203c: f9401bea    	ldr	x10, [sp, #0x30]
101442040: cb14014a    	sub	x10, x10, x20
101442044: d343fd4a    	lsr	x10, x10, #3
101442048: b201f3eb    	mov	x11, #-0x5555555555555556 ; =-6148914691236517206
10144204c: f295556b    	movk	x11, #0xaaab
101442050: 9b0b7d4a    	mul	x10, x10, x11
101442054: eb0a011f    	cmp	x8, x10
101442058: 5400aee2    	b.hs	0x101443634 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2188>
10144205c: 5280030a    	mov	w10, #0x18              ; =24
101442060: 9b0a5108    	madd	x8, x8, x10, x20
101442064: 91006114    	add	x20, x8, #0x18
101442068: 3607dae9    	tbz	w9, #0x0, 0x101441bc4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x718>
10144206c: 17fffff0    	b	0x10144202c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xb80>
101442070: 97d971a0    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101442074: aa1c03e0    	mov	x0, x28
101442078: 52800021    	mov	w1, #0x1                ; =1
10144207c: 97d97197    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101442080: b400e920    	cbz	x0, 0x101443da4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x28f8>
101442084: aa0003f7    	mov	x23, x0
101442088: aa1903e1    	mov	x1, x25
10144208c: aa1c03e2    	mov	x2, x28
101442090: 941a1ee6    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101442094: f940e3f9    	ldr	x25, [sp, #0x1c0]
101442098: f940dbe8    	ldr	x8, [sp, #0x1b0]
10144209c: eb08033f    	cmp	x25, x8
1014420a0: 54ffd6e1    	b.ne	0x101441b7c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6d0>
1014420a4: 9106c3e0    	add	x0, sp, #0x1b0
1014420a8: 941a02b2    	bl	0x101ac2b70 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hb575521872840d8cE>
1014420ac: 17fffeb4    	b	0x101441b7c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x6d0>
1014420b0: aa1603fb    	mov	x27, x22
1014420b4: d10363a0    	sub	x0, x29, #0xd8
1014420b8: aa1503e1    	mov	x1, x21
1014420bc: aa1303e2    	mov	x2, x19
1014420c0: 97ffefbf    	bl	0x10143dfbc <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x16a4>
1014420c4: f9400341    	ldr	x1, [x26]
1014420c8: f240f83f    	tst	x1, #0x7fffffffffffffff
1014420cc: 54000080    	b.eq	0x1014420dc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xc30>
1014420d0: f9404700    	ldr	x0, [x24, #0x88]
1014420d4: 52800022    	mov	w2, #0x1                ; =1
1014420d8: 97d97181    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014420dc: 3cd283a0    	ldur	q0, [x29, #-0xd8]
1014420e0: 3d800340    	str	q0, [x26]
1014420e4: f85383a8    	ldur	x8, [x29, #-0xc8]
1014420e8: f9000b48    	str	x8, [x26, #0x10]
1014420ec: d10363a0    	sub	x0, x29, #0xd8
1014420f0: aa1503e1    	mov	x1, x21
1014420f4: aa1303e2    	mov	x2, x19
1014420f8: 94000a8a    	bl	0x101444b20 <__ZN17otty_autocomplete7history14CommandHistory9clear_all17ha96dfef39a2aea48E+0x4a4>
1014420fc: f90027fb    	str	x27, [sp, #0x48]
101442100: f9400bb4    	ldr	x20, [x29, #0x10]
101442104: f9402bf7    	ldr	x23, [sp, #0x50]
101442108: f94002e1    	ldr	x1, [x23]
10144210c: f240f83f    	tst	x1, #0x7fffffffffffffff
101442110: 54000080    	b.eq	0x101442120 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xc74>
101442114: f9405300    	ldr	x0, [x24, #0xa0]
101442118: 52800022    	mov	w2, #0x1                ; =1
10144211c: 97d97170    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101442120: 52800016    	mov	w22, #0x0               ; =0
101442124: 3cd283a0    	ldur	q0, [x29, #-0xd8]
101442128: 3d8002e0    	str	q0, [x23]
10144212c: f85383a8    	ldur	x8, [x29, #-0xc8]
101442130: f9000ae8    	str	x8, [x23, #0x10]
101442134: 52800308    	mov	w8, #0x18               ; =24
101442138: 9b08567a    	madd	x26, x19, x8, x21
10144213c: 5280003c    	mov	w28, #0x1               ; =1
101442140: 528d0e9b    	mov	w27, #0x6874            ; =26740
101442144: 0f0107a8    	movi.2s	v8, #0x3d
101442148: 52800f37    	mov	w23, #0x79              ; =121
10144214c: 1400000a    	b	0x101442174 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xcc8>
101442150: 52800036    	mov	w22, #0x1               ; =1
101442154: aa1803e0    	mov	x0, x24
101442158: f9403fe1    	ldr	x1, [sp, #0x78]
10144215c: f94037e2    	ldr	x2, [sp, #0x68]
101442160: aa1903e3    	mov	x3, x25
101442164: aa1303e4    	mov	x4, x19
101442168: f9402fe5    	ldr	x5, [sp, #0x58]
10144216c: 940007b6    	bl	0x101444044 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b98>
101442170: d2800014    	mov	x20, #0x0               ; =0
101442174: aa1603e8    	mov	x8, x22
101442178: b5005474    	cbnz	x20, 0x101442c04 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1758>
10144217c: aa1503e9    	mov	x9, x21
101442180: eb1a02bf    	cmp	x21, x26
101442184: 540055c0    	b.eq	0x101442c3c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1790>
101442188: d2800014    	mov	x20, #0x0               ; =0
10144218c: 52800016    	mov	w22, #0x0               ; =0
101442190: 91006135    	add	x21, x9, #0x18
101442194: 3707ff08    	tbnz	w8, #0x0, 0x101442174 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xcc8>
101442198: a940cd39    	ldp	x25, x19, [x9, #0x8]
10144219c: d10363a8    	sub	x8, x29, #0xd8
1014421a0: aa1903e0    	mov	x0, x25
1014421a4: aa1303e1    	mov	x1, x19
1014421a8: 940f2563    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
1014421ac: 52800009    	mov	w9, #0x0                ; =0
1014421b0: a97323a0    	ldp	x0, x8, [x29, #-0xd0]
1014421b4: f1001d1f    	cmp	x8, #0x7
1014421b8: 5400022d    	b.le	0x1014421fc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xd50>
1014421bc: f100251f    	cmp	x8, #0x9
1014421c0: 540003ec    	b.gt	0x10144223c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xd90>
1014421c4: f100211f    	cmp	x8, #0x8
1014421c8: 540009e0    	b.eq	0x101442304 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xe58>
1014421cc: f100251f    	cmp	x8, #0x9
1014421d0: 54000c61    	b.ne	0x10144235c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xeb0>
1014421d4: f9400009    	ldr	x9, [x0]
1014421d8: 3940200a    	ldrb	w10, [x0, #0x8]
1014421dc: d285a5ab    	mov	x11, #0x2d2d            ; =11565
1014421e0: f2ae0c2b    	movk	x11, #0x7061, lsl #16
1014421e4: f2c5ad2b    	movk	x11, #0x2d69, lsl #32
1014421e8: f2ecad6b    	movk	x11, #0x656b, lsl #48
1014421ec: eb09017f    	cmp	x11, x9
1014421f0: 7a570140    	ccmp	w10, w23, #0x0, eq
1014421f4: 54000b21    	b.ne	0x101442358 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xeac>
1014421f8: 140000dc    	b	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
1014421fc: f100091f    	cmp	x8, #0x2
101442200: 54000500    	b.eq	0x1014422a0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xdf4>
101442204: f100191f    	cmp	x8, #0x6
101442208: 54000380    	b.eq	0x101442278 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xdcc>
10144220c: f1001d1f    	cmp	x8, #0x7
101442210: 54000a61    	b.ne	0x10144235c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xeb0>
101442214: b9400009    	ldr	w9, [x0]
101442218: b840300a    	ldur	w10, [x0, #0x3]
10144221c: 5285a5ab    	mov	w11, #0x2d2d            ; =11565
101442220: 72adee8b    	movk	w11, #0x6f74, lsl #16
101442224: 6b09017f    	cmp	w11, w9
101442228: 528d6de9    	mov	w9, #0x6b6f             ; =27503
10144222c: 72adcca9    	movk	w9, #0x6e65, lsl #16
101442230: 7a4a0120    	ccmp	w9, w10, #0x0, eq
101442234: 54000921    	b.ne	0x101442358 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xeac>
101442238: 140000cc    	b	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
10144223c: f100391f    	cmp	x8, #0xe
101442240: 54000460    	b.eq	0x1014422cc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xe20>
101442244: f100291f    	cmp	x8, #0xa
101442248: 540008a1    	b.ne	0x10144235c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xeb0>
10144224c: f9400009    	ldr	x9, [x0]
101442250: 7940100a    	ldrh	w10, [x0, #0x8]
101442254: d285a5ab    	mov	x11, #0x2d2d            ; =11565
101442258: f2ac2e0b    	movk	x11, #0x6170, lsl #16
10144225c: f2ce6e6b    	movk	x11, #0x7373, lsl #32
101442260: f2edeeeb    	movk	x11, #0x6f77, lsl #48
101442264: eb09017f    	cmp	x11, x9
101442268: 528c8e49    	mov	w9, #0x6472             ; =25714
10144226c: 7a490140    	ccmp	w10, w9, #0x0, eq
101442270: 54000201    	b.ne	0x1014422b0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xe04>
101442274: 140000bd    	b	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
101442278: b9400009    	ldr	w9, [x0]
10144227c: 7940080a    	ldrh	w10, [x0, #0x4]
101442280: 5285a5ab    	mov	w11, #0x2d2d            ; =11565
101442284: 72ac2e0b    	movk	w11, #0x6170, lsl #16
101442288: 6b09017f    	cmp	w11, w9
10144228c: 528e6e69    	mov	w9, #0x7373             ; =29555
101442290: 7a490140    	ccmp	w10, w9, #0x0, eq
101442294: 540016a0    	b.eq	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
101442298: 52800029    	mov	w9, #0x1                ; =1
10144229c: 14000030    	b	0x10144235c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xeb0>
1014422a0: 79400009    	ldrh	w9, [x0]
1014422a4: 528e05aa    	mov	w10, #0x702d            ; =28717
1014422a8: 6b0a013f    	cmp	w9, w10
1014422ac: 540015e0    	b.eq	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
1014422b0: 52800009    	mov	w9, #0x0                ; =0
1014422b4: f100211f    	cmp	x8, #0x8
1014422b8: 54fffa6d    	b.le	0x101442204 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xd58>
1014422bc: f100251f    	cmp	x8, #0x9
1014422c0: 54fff8a0    	b.eq	0x1014421d4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xd28>
1014422c4: f100391f    	cmp	x8, #0xe
1014422c8: 540004a1    	b.ne	0x10144235c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xeb0>
1014422cc: f9400009    	ldr	x9, [x0]
1014422d0: f840600a    	ldur	x10, [x0, #0x6]
1014422d4: d285a5ab    	mov	x11, #0x2d2d            ; =11565
1014422d8: f2ac6c2b    	movk	x11, #0x6361, lsl #16
1014422dc: f2ccac6b    	movk	x11, #0x6563, lsl #32
1014422e0: f2ee6e6b    	movk	x11, #0x7373, lsl #48
1014422e4: eb09017f    	cmp	x11, x9
1014422e8: d28e6e69    	mov	x9, #0x7373             ; =29555
1014422ec: f2ae85a9    	movk	x9, #0x742d, lsl #16
1014422f0: f2cd6de9    	movk	x9, #0x6b6f, lsl #32
1014422f4: f2edcca9    	movk	x9, #0x6e65, lsl #48
1014422f8: fa4a0120    	ccmp	x9, x10, #0x0, eq
1014422fc: 540002e1    	b.ne	0x101442358 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xeac>
101442300: 1400009a    	b	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
101442304: f9400009    	ldr	x9, [x0]
101442308: d285a5aa    	mov	x10, #0x2d2d            ; =11565
10144230c: f2ac2e0a    	movk	x10, #0x6170, lsl #16
101442310: f2ce6e6a    	movk	x10, #0x7373, lsl #32
101442314: f2ec8eea    	movk	x10, #0x6477, lsl #48
101442318: eb09015f    	cmp	x10, x9
10144231c: 54001260    	b.eq	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
101442320: f9400009    	ldr	x9, [x0]
101442324: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101442328: f2ae0c2a    	movk	x10, #0x7061, lsl #16
10144232c: f2cd6d2a    	movk	x10, #0x6b69, lsl #32
101442330: f2ef2caa    	movk	x10, #0x7965, lsl #48
101442334: eb09015f    	cmp	x10, x9
101442338: 54001180    	b.eq	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
10144233c: f9400009    	ldr	x9, [x0]
101442340: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101442344: f2acae6a    	movk	x10, #0x6573, lsl #16
101442348: f2ce4c6a    	movk	x10, #0x7263, lsl #32
10144234c: f2ee8caa    	movk	x10, #0x7465, lsl #48
101442350: eb09015f    	cmp	x10, x9
101442354: 540010a0    	b.eq	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
101442358: 52800009    	mov	w9, #0x0                ; =0
10144235c: f100311f    	cmp	x8, #0xc
101442360: 540001a1    	b.ne	0x101442394 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xee8>
101442364: f940000a    	ldr	x10, [x0]
101442368: b940080b    	ldr	w11, [x0, #0x8]
10144236c: d285a5ac    	mov	x12, #0x2d2d            ; =11565
101442370: f2acae6c    	movk	x12, #0x6573, lsl #16
101442374: f2ce4c6c    	movk	x12, #0x7263, lsl #32
101442378: f2ee8cac    	movk	x12, #0x7465, lsl #48
10144237c: eb0a019f    	cmp	x12, x10
101442380: 528d65aa    	mov	w10, #0x6b2d            ; =27437
101442384: 72af2caa    	movk	w10, #0x7965, lsl #16
101442388: fa4b0140    	ccmp	x10, x11, #0x0, eq
10144238c: 540001a1    	b.ne	0x1014423c0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xf14>
101442390: 14000076    	b	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
101442394: f100351f    	cmp	x8, #0xd
101442398: 54000c80    	b.eq	0x101442528 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x107c>
10144239c: f100151f    	cmp	x8, #0x5
1014423a0: 54000101    	b.ne	0x1014423c0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xf14>
1014423a4: b940000a    	ldr	w10, [x0]
1014423a8: 3940100b    	ldrb	w11, [x0, #0x4]
1014423ac: 5285a5ac    	mov	w12, #0x2d2d            ; =11565
1014423b0: 72acad6c    	movk	w12, #0x656b, lsl #16
1014423b4: 6b0a019f    	cmp	w12, w10
1014423b8: 7a570160    	ccmp	w11, w23, #0x0, eq
1014423bc: 54000d60    	b.eq	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
1014423c0: 5280000a    	mov	w10, #0x0               ; =0
1014423c4: 34000109    	cbz	w9, 0x1014423e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xf38>
1014423c8: b9400009    	ldr	w9, [x0]
1014423cc: 7940080b    	ldrh	w11, [x0, #0x4]
1014423d0: 5285a5ac    	mov	w12, #0x2d2d            ; =11565
1014423d4: 72aeac2c    	movk	w12, #0x7561, lsl #16
1014423d8: 6b09019f    	cmp	w12, w9
1014423dc: 7a5b0160    	ccmp	w11, w27, #0x0, eq
1014423e0: 54000c40    	b.eq	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
1014423e4: f1003d1f    	cmp	x8, #0xf
1014423e8: 540001e1    	b.ne	0x101442424 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xf78>
1014423ec: f9400008    	ldr	x8, [x0]
1014423f0: f8407009    	ldur	x9, [x0, #0x7]
1014423f4: d285a5ab    	mov	x11, #0x2d2d            ; =11565
1014423f8: f2aeac2b    	movk	x11, #0x7561, lsl #16
1014423fc: f2cd0e8b    	movk	x11, #0x6874, lsl #32
101442400: f2ee4deb    	movk	x11, #0x726f, lsl #48
101442404: eb08017f    	cmp	x11, x8
101442408: d28d2e48    	mov	x8, #0x6972             ; =26994
10144240c: f2ac2f48    	movk	x8, #0x617a, lsl #16
101442410: f2cd2e88    	movk	x8, #0x6974, lsl #32
101442414: f2edcde8    	movk	x8, #0x6e6f, lsl #48
101442418: fa490100    	ccmp	x8, x9, #0x0, eq
10144241c: 540001e1    	b.ne	0x101442458 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xfac>
101442420: 14000052    	b	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
101442424: f100311f    	cmp	x8, #0xc
101442428: 54000181    	b.ne	0x101442458 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xfac>
10144242c: f9400008    	ldr	x8, [x0]
101442430: b9400809    	ldr	w9, [x0, #0x8]
101442434: d285a5ab    	mov	x11, #0x2d2d            ; =11565
101442438: f2ae4c6b    	movk	x11, #0x7263, lsl #16
10144243c: f2cc8cab    	movk	x11, #0x6465, lsl #32
101442440: f2edccab    	movk	x11, #0x6e65, lsl #48
101442444: eb08017f    	cmp	x11, x8
101442448: 528d2e88    	mov	w8, #0x6974             ; =26996
10144244c: 72ad8c28    	movk	w8, #0x6c61, lsl #16
101442450: fa490100    	ccmp	x8, x9, #0x0, eq
101442454: 540008a0    	b.eq	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
101442458: 340001ca    	cbz	w10, 0x101442490 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xfe4>
10144245c: f9400008    	ldr	x8, [x0]
101442460: f8405009    	ldur	x9, [x0, #0x5]
101442464: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101442468: f2ae4c6a    	movk	x10, #0x7263, lsl #16
10144246c: f2cc8caa    	movk	x10, #0x6465, lsl #32
101442470: f2edccaa    	movk	x10, #0x6e65, lsl #48
101442474: eb08015f    	cmp	x10, x8
101442478: d28cac88    	mov	x8, #0x6564             ; =25956
10144247c: f2ae8dc8    	movk	x8, #0x746e, lsl #16
101442480: f2cc2d28    	movk	x8, #0x6169, lsl #32
101442484: f2ee6d88    	movk	x8, #0x736c, lsl #48
101442488: fa490100    	ccmp	x8, x9, #0x0, eq
10144248c: 540006e0    	b.eq	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
101442490: f85283a1    	ldur	x1, [x29, #-0xd8]
101442494: b4000061    	cbz	x1, 0x1014424a0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xff4>
101442498: 52800022    	mov	w2, #0x1                ; =1
10144249c: 97d97090    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014424a0: a932cfb9    	stp	x25, x19, [x29, #-0xd8]
1014424a4: a933cfbf    	stp	xzr, x19, [x29, #-0xc8]
1014424a8: 381503bc    	sturb	w28, [x29, #-0xb0]
1014424ac: fc1483a8    	stur	d8, [x29, #-0xb8]
1014424b0: 910583e0    	add	x0, sp, #0x160
1014424b4: d10363a1    	sub	x1, x29, #0xd8
1014424b8: 9400aa89    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
1014424bc: b94163e8    	ldr	w8, [sp, #0x160]
1014424c0: 7100051f    	cmp	w8, #0x1
1014424c4: 54003561    	b.ne	0x101442b70 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x16c4>
1014424c8: f940b7e1    	ldr	x1, [sp, #0x168]
1014424cc: 910583e8    	add	x8, sp, #0x160
1014424d0: aa1903e0    	mov	x0, x25
1014424d4: 940f2498    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
1014424d8: 5280000a    	mov	w10, #0x0               ; =0
1014424dc: a956a7e8    	ldp	x8, x9, [sp, #0x168]
1014424e0: f1001d3f    	cmp	x9, #0x7
1014424e4: 540004cd    	b.le	0x10144257c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10d0>
1014424e8: f100253f    	cmp	x9, #0x9
1014424ec: 5400068c    	b.gt	0x1014425bc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1110>
1014424f0: f100213f    	cmp	x9, #0x8
1014424f4: 54000c80    	b.eq	0x101442684 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x11d8>
1014424f8: f100253f    	cmp	x9, #0x9
1014424fc: 54000f01    	b.ne	0x1014426dc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1230>
101442500: f940010a    	ldr	x10, [x8]
101442504: 3940210b    	ldrb	w11, [x8, #0x8]
101442508: d285a5ac    	mov	x12, #0x2d2d            ; =11565
10144250c: f2ae0c2c    	movk	x12, #0x7061, lsl #16
101442510: f2c5ad2c    	movk	x12, #0x2d69, lsl #32
101442514: f2ecad6c    	movk	x12, #0x656b, lsl #48
101442518: eb0a019f    	cmp	x12, x10
10144251c: 7a570160    	ccmp	w11, w23, #0x0, eq
101442520: 54000dc1    	b.ne	0x1014426d8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x122c>
101442524: 140001b0    	b	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
101442528: f940000a    	ldr	x10, [x0]
10144252c: f840500b    	ldur	x11, [x0, #0x5]
101442530: d285a5ac    	mov	x12, #0x2d2d            ; =11565
101442534: f2ae4e0c    	movk	x12, #0x7270, lsl #16
101442538: f2cecd2c    	movk	x12, #0x7669, lsl #32
10144253c: f2ee8c2c    	movk	x12, #0x7461, lsl #48
101442540: eb0a019f    	cmp	x12, x10
101442544: d28c2eca    	mov	x10, #0x6176            ; =24950
101442548: f2acae8a    	movk	x10, #0x6574, lsl #16
10144254c: f2cd65aa    	movk	x10, #0x6b2d, lsl #32
101442550: f2ef2caa    	movk	x10, #0x7965, lsl #48
101442554: fa4b0140    	ccmp	x10, x11, #0x0, eq
101442558: 54000080    	b.eq	0x101442568 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10bc>
10144255c: 5280002a    	mov	w10, #0x1               ; =1
101442560: 34fff429    	cbz	w9, 0x1014423e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xf38>
101442564: 17ffff99    	b	0x1014423c8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xf1c>
101442568: f85283a1    	ldur	x1, [x29, #-0xd8]
10144256c: b4ffdf21    	cbz	x1, 0x101442150 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xca4>
101442570: 52800022    	mov	w2, #0x1                ; =1
101442574: 97d9705a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101442578: 17fffef6    	b	0x101442150 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xca4>
10144257c: f100093f    	cmp	x9, #0x2
101442580: 54000500    	b.eq	0x101442620 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1174>
101442584: f100193f    	cmp	x9, #0x6
101442588: 54000380    	b.eq	0x1014425f8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x114c>
10144258c: f1001d3f    	cmp	x9, #0x7
101442590: 54000a61    	b.ne	0x1014426dc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1230>
101442594: b940010a    	ldr	w10, [x8]
101442598: b840310b    	ldur	w11, [x8, #0x3]
10144259c: 5285a5ac    	mov	w12, #0x2d2d            ; =11565
1014425a0: 72adee8c    	movk	w12, #0x6f74, lsl #16
1014425a4: 6b0a019f    	cmp	w12, w10
1014425a8: 528d6dea    	mov	w10, #0x6b6f            ; =27503
1014425ac: 72adccaa    	movk	w10, #0x6e65, lsl #16
1014425b0: 7a4b0140    	ccmp	w10, w11, #0x0, eq
1014425b4: 54000921    	b.ne	0x1014426d8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x122c>
1014425b8: 1400018b    	b	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
1014425bc: f100393f    	cmp	x9, #0xe
1014425c0: 54000460    	b.eq	0x10144264c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x11a0>
1014425c4: f100293f    	cmp	x9, #0xa
1014425c8: 540008a1    	b.ne	0x1014426dc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1230>
1014425cc: f940010a    	ldr	x10, [x8]
1014425d0: 7940110b    	ldrh	w11, [x8, #0x8]
1014425d4: d285a5ac    	mov	x12, #0x2d2d            ; =11565
1014425d8: f2ac2e0c    	movk	x12, #0x6170, lsl #16
1014425dc: f2ce6e6c    	movk	x12, #0x7373, lsl #32
1014425e0: f2edeeec    	movk	x12, #0x6f77, lsl #48
1014425e4: eb0a019f    	cmp	x12, x10
1014425e8: 528c8e4a    	mov	w10, #0x6472            ; =25714
1014425ec: 7a4a0160    	ccmp	w11, w10, #0x0, eq
1014425f0: 54000201    	b.ne	0x101442630 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1184>
1014425f4: 1400017c    	b	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
1014425f8: b940010a    	ldr	w10, [x8]
1014425fc: 7940090b    	ldrh	w11, [x8, #0x4]
101442600: 5285a5ac    	mov	w12, #0x2d2d            ; =11565
101442604: 72ac2e0c    	movk	w12, #0x6170, lsl #16
101442608: 6b0a019f    	cmp	w12, w10
10144260c: 528e6e6a    	mov	w10, #0x7373            ; =29555
101442610: 7a4a0160    	ccmp	w11, w10, #0x0, eq
101442614: 54002e80    	b.eq	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
101442618: 5280002a    	mov	w10, #0x1               ; =1
10144261c: 14000030    	b	0x1014426dc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1230>
101442620: 7940010a    	ldrh	w10, [x8]
101442624: 528e05ab    	mov	w11, #0x702d            ; =28717
101442628: 6b0b015f    	cmp	w10, w11
10144262c: 54002dc0    	b.eq	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
101442630: 5280000a    	mov	w10, #0x0               ; =0
101442634: f100213f    	cmp	x9, #0x8
101442638: 54fffa6d    	b.le	0x101442584 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x10d8>
10144263c: f100253f    	cmp	x9, #0x9
101442640: 54fff600    	b.eq	0x101442500 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1054>
101442644: f100393f    	cmp	x9, #0xe
101442648: 540004a1    	b.ne	0x1014426dc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1230>
10144264c: f940010a    	ldr	x10, [x8]
101442650: f840610b    	ldur	x11, [x8, #0x6]
101442654: d285a5ac    	mov	x12, #0x2d2d            ; =11565
101442658: f2ac6c2c    	movk	x12, #0x6361, lsl #16
10144265c: f2ccac6c    	movk	x12, #0x6563, lsl #32
101442660: f2ee6e6c    	movk	x12, #0x7373, lsl #48
101442664: eb0a019f    	cmp	x12, x10
101442668: d28e6e6a    	mov	x10, #0x7373            ; =29555
10144266c: f2ae85aa    	movk	x10, #0x742d, lsl #16
101442670: f2cd6dea    	movk	x10, #0x6b6f, lsl #32
101442674: f2edccaa    	movk	x10, #0x6e65, lsl #48
101442678: fa4b0140    	ccmp	x10, x11, #0x0, eq
10144267c: 540002e1    	b.ne	0x1014426d8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x122c>
101442680: 14000159    	b	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
101442684: f940010a    	ldr	x10, [x8]
101442688: d285a5ab    	mov	x11, #0x2d2d            ; =11565
10144268c: f2ac2e0b    	movk	x11, #0x6170, lsl #16
101442690: f2ce6e6b    	movk	x11, #0x7373, lsl #32
101442694: f2ec8eeb    	movk	x11, #0x6477, lsl #48
101442698: eb0a017f    	cmp	x11, x10
10144269c: 54002a40    	b.eq	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
1014426a0: f940010a    	ldr	x10, [x8]
1014426a4: d285a5ab    	mov	x11, #0x2d2d            ; =11565
1014426a8: f2ae0c2b    	movk	x11, #0x7061, lsl #16
1014426ac: f2cd6d2b    	movk	x11, #0x6b69, lsl #32
1014426b0: f2ef2cab    	movk	x11, #0x7965, lsl #48
1014426b4: eb0a017f    	cmp	x11, x10
1014426b8: 54002960    	b.eq	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
1014426bc: f940010a    	ldr	x10, [x8]
1014426c0: d285a5ab    	mov	x11, #0x2d2d            ; =11565
1014426c4: f2acae6b    	movk	x11, #0x6573, lsl #16
1014426c8: f2ce4c6b    	movk	x11, #0x7263, lsl #32
1014426cc: f2ee8cab    	movk	x11, #0x7465, lsl #48
1014426d0: eb0a017f    	cmp	x11, x10
1014426d4: 54002880    	b.eq	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
1014426d8: 5280000a    	mov	w10, #0x0               ; =0
1014426dc: f100313f    	cmp	x9, #0xc
1014426e0: 540001a1    	b.ne	0x101442714 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1268>
1014426e4: f940010b    	ldr	x11, [x8]
1014426e8: b940090c    	ldr	w12, [x8, #0x8]
1014426ec: d285a5ad    	mov	x13, #0x2d2d            ; =11565
1014426f0: f2acae6d    	movk	x13, #0x6573, lsl #16
1014426f4: f2ce4c6d    	movk	x13, #0x7263, lsl #32
1014426f8: f2ee8cad    	movk	x13, #0x7465, lsl #48
1014426fc: eb0b01bf    	cmp	x13, x11
101442700: 528d65ab    	mov	w11, #0x6b2d            ; =27437
101442704: 72af2cab    	movk	w11, #0x7965, lsl #16
101442708: fa4c0160    	ccmp	x11, x12, #0x0, eq
10144270c: 540001a1    	b.ne	0x101442740 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1294>
101442710: 14000135    	b	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
101442714: f100353f    	cmp	x9, #0xd
101442718: 54000b60    	b.eq	0x101442884 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x13d8>
10144271c: f100153f    	cmp	x9, #0x5
101442720: 54000101    	b.ne	0x101442740 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1294>
101442724: b940010b    	ldr	w11, [x8]
101442728: 3940110c    	ldrb	w12, [x8, #0x4]
10144272c: 5285a5ad    	mov	w13, #0x2d2d            ; =11565
101442730: 72acad6d    	movk	w13, #0x656b, lsl #16
101442734: 6b0b01bf    	cmp	w13, w11
101442738: 7a570180    	ccmp	w12, w23, #0x0, eq
10144273c: 54002540    	b.eq	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
101442740: 5280000b    	mov	w11, #0x0               ; =0
101442744: 3400010a    	cbz	w10, 0x101442764 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x12b8>
101442748: b940010a    	ldr	w10, [x8]
10144274c: 7940090c    	ldrh	w12, [x8, #0x4]
101442750: 5285a5ad    	mov	w13, #0x2d2d            ; =11565
101442754: 72aeac2d    	movk	w13, #0x7561, lsl #16
101442758: 6b0a01bf    	cmp	w13, w10
10144275c: 7a5b0180    	ccmp	w12, w27, #0x0, eq
101442760: 54002420    	b.eq	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
101442764: f1003d3f    	cmp	x9, #0xf
101442768: 540001a1    	b.ne	0x10144279c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x12f0>
10144276c: f9400109    	ldr	x9, [x8]
101442770: f840710a    	ldur	x10, [x8, #0x7]
101442774: d285a5ac    	mov	x12, #0x2d2d            ; =11565
101442778: f2aeac2c    	movk	x12, #0x7561, lsl #16
10144277c: f2cd0e8c    	movk	x12, #0x6874, lsl #32
101442780: f2ee4dec    	movk	x12, #0x726f, lsl #48
101442784: eb09019f    	cmp	x12, x9
101442788: d28d2e49    	mov	x9, #0x6972             ; =26994
10144278c: f2ac2f49    	movk	x9, #0x617a, lsl #16
101442790: f2cd2e89    	movk	x9, #0x6974, lsl #32
101442794: f2edcde9    	movk	x9, #0x6e6f, lsl #48
101442798: 1400000c    	b	0x1014427c8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x131c>
10144279c: f100313f    	cmp	x9, #0xc
1014427a0: 54000181    	b.ne	0x1014427d0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1324>
1014427a4: f9400109    	ldr	x9, [x8]
1014427a8: b940090a    	ldr	w10, [x8, #0x8]
1014427ac: d285a5ac    	mov	x12, #0x2d2d            ; =11565
1014427b0: f2ae4c6c    	movk	x12, #0x7263, lsl #16
1014427b4: f2cc8cac    	movk	x12, #0x6465, lsl #32
1014427b8: f2edccac    	movk	x12, #0x6e65, lsl #48
1014427bc: eb09019f    	cmp	x12, x9
1014427c0: 528d2e89    	mov	w9, #0x6974             ; =26996
1014427c4: 72ad8c29    	movk	w9, #0x6c61, lsl #16
1014427c8: fa4a0120    	ccmp	x9, x10, #0x0, eq
1014427cc: 540020c0    	b.eq	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
1014427d0: 340001cb    	cbz	w11, 0x101442808 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x135c>
1014427d4: f9400109    	ldr	x9, [x8]
1014427d8: f8405108    	ldur	x8, [x8, #0x5]
1014427dc: d285a5aa    	mov	x10, #0x2d2d            ; =11565
1014427e0: f2ae4c6a    	movk	x10, #0x7263, lsl #16
1014427e4: f2cc8caa    	movk	x10, #0x6465, lsl #32
1014427e8: f2edccaa    	movk	x10, #0x6e65, lsl #48
1014427ec: eb09015f    	cmp	x10, x9
1014427f0: d28cac89    	mov	x9, #0x6564             ; =25956
1014427f4: f2ae8dc9    	movk	x9, #0x746e, lsl #16
1014427f8: f2cc2d29    	movk	x9, #0x6169, lsl #32
1014427fc: f2ee6d89    	movk	x9, #0x736c, lsl #48
101442800: fa480120    	ccmp	x9, x8, #0x0, eq
101442804: 54001f00    	b.eq	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
101442808: 910583e8    	add	x8, sp, #0x160
10144280c: f900dbe8    	str	x8, [sp, #0x1b0]
101442810: b0000148    	adrp	x8, 0x10146b000 <__ZN4core5slice4sort8unstable8heapsort8heapsort17h14b311923aeea277E+0x3bbc>
101442814: 913b4108    	add	x8, x8, #0xed0
101442818: f900dfe8    	str	x8, [sp, #0x1b8]
10144281c: d10363a8    	sub	x8, x29, #0xd8
101442820: 9106c3e1    	add	x1, sp, #0x1b0
101442824: 90004e60    	adrp	x0, 0x101e0e000 <_writev+0x101e0e000>
101442828: 91111c00    	add	x0, x0, #0x447
10144282c: 940f2355    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
101442830: 52800009    	mov	w9, #0x0                ; =0
101442834: a97283a1    	ldp	x1, x0, [x29, #-0xd8]
101442838: f85383a8    	ldur	x8, [x29, #-0xc8]
10144283c: f1001d1f    	cmp	x8, #0x7
101442840: 5400042d    	b.le	0x1014428c4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1418>
101442844: f100251f    	cmp	x8, #0x9
101442848: 540005ec    	b.gt	0x101442904 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1458>
10144284c: f100211f    	cmp	x8, #0x8
101442850: 54000be0    	b.eq	0x1014429cc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1520>
101442854: f100251f    	cmp	x8, #0x9
101442858: 54000e61    	b.ne	0x101442a24 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1578>
10144285c: f9400009    	ldr	x9, [x0]
101442860: 3940200a    	ldrb	w10, [x0, #0x8]
101442864: d285a5ab    	mov	x11, #0x2d2d            ; =11565
101442868: f2ae0c2b    	movk	x11, #0x7061, lsl #16
10144286c: f2c5ad2b    	movk	x11, #0x2d69, lsl #32
101442870: f2ecad6b    	movk	x11, #0x656b, lsl #48
101442874: eb09017f    	cmp	x11, x9
101442878: 7a570140    	ccmp	w10, w23, #0x0, eq
10144287c: 54000d21    	b.ne	0x101442a20 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1574>
101442880: 140000d6    	b	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
101442884: f940010b    	ldr	x11, [x8]
101442888: f840510c    	ldur	x12, [x8, #0x5]
10144288c: d285a5ad    	mov	x13, #0x2d2d            ; =11565
101442890: f2ae4e0d    	movk	x13, #0x7270, lsl #16
101442894: f2cecd2d    	movk	x13, #0x7669, lsl #32
101442898: f2ee8c2d    	movk	x13, #0x7461, lsl #48
10144289c: eb0b01bf    	cmp	x13, x11
1014428a0: d28c2ecb    	mov	x11, #0x6176            ; =24950
1014428a4: f2acae8b    	movk	x11, #0x6574, lsl #16
1014428a8: f2cd65ab    	movk	x11, #0x6b2d, lsl #32
1014428ac: f2ef2cab    	movk	x11, #0x7965, lsl #48
1014428b0: fa4c0160    	ccmp	x11, x12, #0x0, eq
1014428b4: 54001980    	b.eq	0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
1014428b8: 5280002b    	mov	w11, #0x1               ; =1
1014428bc: 34fff54a    	cbz	w10, 0x101442764 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x12b8>
1014428c0: 17ffffa2    	b	0x101442748 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x129c>
1014428c4: f100091f    	cmp	x8, #0x2
1014428c8: 54000500    	b.eq	0x101442968 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x14bc>
1014428cc: f100191f    	cmp	x8, #0x6
1014428d0: 54000380    	b.eq	0x101442940 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1494>
1014428d4: f1001d1f    	cmp	x8, #0x7
1014428d8: 54000a61    	b.ne	0x101442a24 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1578>
1014428dc: b9400009    	ldr	w9, [x0]
1014428e0: b840300a    	ldur	w10, [x0, #0x3]
1014428e4: 5285a5ab    	mov	w11, #0x2d2d            ; =11565
1014428e8: 72adee8b    	movk	w11, #0x6f74, lsl #16
1014428ec: 6b09017f    	cmp	w11, w9
1014428f0: 528d6de9    	mov	w9, #0x6b6f             ; =27503
1014428f4: 72adcca9    	movk	w9, #0x6e65, lsl #16
1014428f8: 7a4a0120    	ccmp	w9, w10, #0x0, eq
1014428fc: 54000921    	b.ne	0x101442a20 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1574>
101442900: 140000b6    	b	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
101442904: f100391f    	cmp	x8, #0xe
101442908: 54000460    	b.eq	0x101442994 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x14e8>
10144290c: f100291f    	cmp	x8, #0xa
101442910: 540008a1    	b.ne	0x101442a24 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1578>
101442914: f9400009    	ldr	x9, [x0]
101442918: 7940100a    	ldrh	w10, [x0, #0x8]
10144291c: d285a5ab    	mov	x11, #0x2d2d            ; =11565
101442920: f2ac2e0b    	movk	x11, #0x6170, lsl #16
101442924: f2ce6e6b    	movk	x11, #0x7373, lsl #32
101442928: f2edeeeb    	movk	x11, #0x6f77, lsl #48
10144292c: eb09017f    	cmp	x11, x9
101442930: 528c8e49    	mov	w9, #0x6472             ; =25714
101442934: 7a490140    	ccmp	w10, w9, #0x0, eq
101442938: 54000201    	b.ne	0x101442978 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x14cc>
10144293c: 140000a7    	b	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
101442940: b9400009    	ldr	w9, [x0]
101442944: 7940080a    	ldrh	w10, [x0, #0x4]
101442948: 5285a5ab    	mov	w11, #0x2d2d            ; =11565
10144294c: 72ac2e0b    	movk	w11, #0x6170, lsl #16
101442950: 6b09017f    	cmp	w11, w9
101442954: 528e6e69    	mov	w9, #0x7373             ; =29555
101442958: 7a490140    	ccmp	w10, w9, #0x0, eq
10144295c: 540013e0    	b.eq	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
101442960: 52800029    	mov	w9, #0x1                ; =1
101442964: 14000030    	b	0x101442a24 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1578>
101442968: 79400009    	ldrh	w9, [x0]
10144296c: 528e05aa    	mov	w10, #0x702d            ; =28717
101442970: 6b0a013f    	cmp	w9, w10
101442974: 54001320    	b.eq	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
101442978: 52800009    	mov	w9, #0x0                ; =0
10144297c: f100211f    	cmp	x8, #0x8
101442980: 54fffa6d    	b.le	0x1014428cc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1420>
101442984: f100251f    	cmp	x8, #0x9
101442988: 54fff6a0    	b.eq	0x10144285c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x13b0>
10144298c: f100391f    	cmp	x8, #0xe
101442990: 540004a1    	b.ne	0x101442a24 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1578>
101442994: f9400009    	ldr	x9, [x0]
101442998: f840600a    	ldur	x10, [x0, #0x6]
10144299c: d285a5ab    	mov	x11, #0x2d2d            ; =11565
1014429a0: f2ac6c2b    	movk	x11, #0x6361, lsl #16
1014429a4: f2ccac6b    	movk	x11, #0x6563, lsl #32
1014429a8: f2ee6e6b    	movk	x11, #0x7373, lsl #48
1014429ac: eb09017f    	cmp	x11, x9
1014429b0: d28e6e69    	mov	x9, #0x7373             ; =29555
1014429b4: f2ae85a9    	movk	x9, #0x742d, lsl #16
1014429b8: f2cd6de9    	movk	x9, #0x6b6f, lsl #32
1014429bc: f2edcca9    	movk	x9, #0x6e65, lsl #48
1014429c0: fa4a0120    	ccmp	x9, x10, #0x0, eq
1014429c4: 540002e1    	b.ne	0x101442a20 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1574>
1014429c8: 14000084    	b	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
1014429cc: f9400009    	ldr	x9, [x0]
1014429d0: d285a5aa    	mov	x10, #0x2d2d            ; =11565
1014429d4: f2ac2e0a    	movk	x10, #0x6170, lsl #16
1014429d8: f2ce6e6a    	movk	x10, #0x7373, lsl #32
1014429dc: f2ec8eea    	movk	x10, #0x6477, lsl #48
1014429e0: eb09015f    	cmp	x10, x9
1014429e4: 54000fa0    	b.eq	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
1014429e8: f9400009    	ldr	x9, [x0]
1014429ec: d285a5aa    	mov	x10, #0x2d2d            ; =11565
1014429f0: f2ae0c2a    	movk	x10, #0x7061, lsl #16
1014429f4: f2cd6d2a    	movk	x10, #0x6b69, lsl #32
1014429f8: f2ef2caa    	movk	x10, #0x7965, lsl #48
1014429fc: eb09015f    	cmp	x10, x9
101442a00: 54000ec0    	b.eq	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
101442a04: f9400009    	ldr	x9, [x0]
101442a08: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101442a0c: f2acae6a    	movk	x10, #0x6573, lsl #16
101442a10: f2ce4c6a    	movk	x10, #0x7263, lsl #32
101442a14: f2ee8caa    	movk	x10, #0x7465, lsl #48
101442a18: eb09015f    	cmp	x10, x9
101442a1c: 54000de0    	b.eq	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
101442a20: 52800009    	mov	w9, #0x0                ; =0
101442a24: f100311f    	cmp	x8, #0xc
101442a28: 540001a1    	b.ne	0x101442a5c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x15b0>
101442a2c: f940000a    	ldr	x10, [x0]
101442a30: b940080b    	ldr	w11, [x0, #0x8]
101442a34: d285a5ac    	mov	x12, #0x2d2d            ; =11565
101442a38: f2acae6c    	movk	x12, #0x6573, lsl #16
101442a3c: f2ce4c6c    	movk	x12, #0x7263, lsl #32
101442a40: f2ee8cac    	movk	x12, #0x7465, lsl #48
101442a44: eb0a019f    	cmp	x12, x10
101442a48: 528d65aa    	mov	w10, #0x6b2d            ; =27437
101442a4c: 72af2caa    	movk	w10, #0x7965, lsl #16
101442a50: fa4b0140    	ccmp	x10, x11, #0x0, eq
101442a54: 540001a1    	b.ne	0x101442a88 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x15dc>
101442a58: 14000060    	b	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
101442a5c: f100351f    	cmp	x8, #0xd
101442a60: 540009c0    	b.eq	0x101442b98 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x16ec>
101442a64: f100151f    	cmp	x8, #0x5
101442a68: 54000101    	b.ne	0x101442a88 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x15dc>
101442a6c: b940000a    	ldr	w10, [x0]
101442a70: 3940100b    	ldrb	w11, [x0, #0x4]
101442a74: 5285a5ac    	mov	w12, #0x2d2d            ; =11565
101442a78: 72acad6c    	movk	w12, #0x656b, lsl #16
101442a7c: 6b0a019f    	cmp	w12, w10
101442a80: 7a570160    	ccmp	w11, w23, #0x0, eq
101442a84: 54000aa0    	b.eq	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
101442a88: 5280000a    	mov	w10, #0x0               ; =0
101442a8c: 34000109    	cbz	w9, 0x101442aac <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1600>
101442a90: b9400009    	ldr	w9, [x0]
101442a94: 7940080b    	ldrh	w11, [x0, #0x4]
101442a98: 5285a5ac    	mov	w12, #0x2d2d            ; =11565
101442a9c: 72aeac2c    	movk	w12, #0x7561, lsl #16
101442aa0: 6b09019f    	cmp	w12, w9
101442aa4: 7a5b0160    	ccmp	w11, w27, #0x0, eq
101442aa8: 54000980    	b.eq	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
101442aac: f1003d1f    	cmp	x8, #0xf
101442ab0: 540001a1    	b.ne	0x101442ae4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1638>
101442ab4: f9400008    	ldr	x8, [x0]
101442ab8: f8407009    	ldur	x9, [x0, #0x7]
101442abc: d285a5ab    	mov	x11, #0x2d2d            ; =11565
101442ac0: f2aeac2b    	movk	x11, #0x7561, lsl #16
101442ac4: f2cd0e8b    	movk	x11, #0x6874, lsl #32
101442ac8: f2ee4deb    	movk	x11, #0x726f, lsl #48
101442acc: eb08017f    	cmp	x11, x8
101442ad0: d28d2e48    	mov	x8, #0x6972             ; =26994
101442ad4: f2ac2f48    	movk	x8, #0x617a, lsl #16
101442ad8: f2cd2e88    	movk	x8, #0x6974, lsl #32
101442adc: f2edcde8    	movk	x8, #0x6e6f, lsl #48
101442ae0: 1400000c    	b	0x101442b10 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1664>
101442ae4: f100311f    	cmp	x8, #0xc
101442ae8: 54000181    	b.ne	0x101442b18 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x166c>
101442aec: f9400008    	ldr	x8, [x0]
101442af0: b9400809    	ldr	w9, [x0, #0x8]
101442af4: d285a5ab    	mov	x11, #0x2d2d            ; =11565
101442af8: f2ae4c6b    	movk	x11, #0x7263, lsl #16
101442afc: f2cc8cab    	movk	x11, #0x6465, lsl #32
101442b00: f2edccab    	movk	x11, #0x6e65, lsl #48
101442b04: eb08017f    	cmp	x11, x8
101442b08: 528d2e88    	mov	w8, #0x6974             ; =26996
101442b0c: 72ad8c28    	movk	w8, #0x6c61, lsl #16
101442b10: fa490100    	ccmp	x8, x9, #0x0, eq
101442b14: 54000620    	b.eq	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
101442b18: 340001ca    	cbz	w10, 0x101442b50 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x16a4>
101442b1c: f9400008    	ldr	x8, [x0]
101442b20: f8405009    	ldur	x9, [x0, #0x5]
101442b24: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101442b28: f2ae4c6a    	movk	x10, #0x7263, lsl #16
101442b2c: f2cc8caa    	movk	x10, #0x6465, lsl #32
101442b30: f2edccaa    	movk	x10, #0x6e65, lsl #48
101442b34: eb08015f    	cmp	x10, x8
101442b38: d28cac88    	mov	x8, #0x6564             ; =25956
101442b3c: f2ae8dc8    	movk	x8, #0x746e, lsl #16
101442b40: f2cc2d28    	movk	x8, #0x6169, lsl #32
101442b44: f2ee6d88    	movk	x8, #0x736c, lsl #48
101442b48: fa490100    	ccmp	x8, x9, #0x0, eq
101442b4c: 54000460    	b.eq	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
101442b50: b4000061    	cbz	x1, 0x101442b5c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x16b0>
101442b54: 52800022    	mov	w2, #0x1                ; =1
101442b58: 97d96ee1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101442b5c: f940b3e1    	ldr	x1, [sp, #0x160]
101442b60: b4000081    	cbz	x1, 0x101442b70 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x16c4>
101442b64: f940b7e0    	ldr	x0, [sp, #0x168]
101442b68: 52800022    	mov	w2, #0x1                ; =1
101442b6c: 97d96edc    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101442b70: aa1803e0    	mov	x0, x24
101442b74: f9403fe1    	ldr	x1, [sp, #0x78]
101442b78: f94037e2    	ldr	x2, [sp, #0x68]
101442b7c: aa1903e3    	mov	x3, x25
101442b80: aa1303e4    	mov	x4, x19
101442b84: f9402fe5    	ldr	x5, [sp, #0x58]
101442b88: 9400052f    	bl	0x101444044 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b98>
101442b8c: d2800014    	mov	x20, #0x0               ; =0
101442b90: 52800016    	mov	w22, #0x0               ; =0
101442b94: 17fffd78    	b	0x101442174 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xcc8>
101442b98: f940000a    	ldr	x10, [x0]
101442b9c: f840500b    	ldur	x11, [x0, #0x5]
101442ba0: d285a5ac    	mov	x12, #0x2d2d            ; =11565
101442ba4: f2ae4e0c    	movk	x12, #0x7270, lsl #16
101442ba8: f2cecd2c    	movk	x12, #0x7669, lsl #32
101442bac: f2ee8c2c    	movk	x12, #0x7461, lsl #48
101442bb0: eb0a019f    	cmp	x12, x10
101442bb4: d28c2eca    	mov	x10, #0x6176            ; =24950
101442bb8: f2acae8a    	movk	x10, #0x6574, lsl #16
101442bbc: f2cd65aa    	movk	x10, #0x6b2d, lsl #32
101442bc0: f2ef2caa    	movk	x10, #0x7965, lsl #48
101442bc4: fa4b0140    	ccmp	x10, x11, #0x0, eq
101442bc8: 54000080    	b.eq	0x101442bd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x172c>
101442bcc: 5280002a    	mov	w10, #0x1               ; =1
101442bd0: 34fff6e9    	cbz	w9, 0x101442aac <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1600>
101442bd4: 17ffffaf    	b	0x101442a90 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x15e4>
101442bd8: b4000061    	cbz	x1, 0x101442be4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1738>
101442bdc: 52800022    	mov	w2, #0x1                ; =1
101442be0: 97d96ebf    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101442be4: f940b3e1    	ldr	x1, [sp, #0x160]
101442be8: b4000081    	cbz	x1, 0x101442bf8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x174c>
101442bec: f940b7e0    	ldr	x0, [sp, #0x168]
101442bf0: 52800022    	mov	w2, #0x1                ; =1
101442bf4: 97d96eba    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101442bf8: d2800014    	mov	x20, #0x0               ; =0
101442bfc: 52800016    	mov	w22, #0x0               ; =0
101442c00: 17fffd5d    	b	0x101442174 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xcc8>
101442c04: cb150349    	sub	x9, x26, x21
101442c08: d343fd29    	lsr	x9, x9, #3
101442c0c: b201f3ea    	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
101442c10: f295556a    	movk	x10, #0xaaab
101442c14: 9b0a7d29    	mul	x9, x9, x10
101442c18: eb09029f    	cmp	x20, x9
101442c1c: 54000102    	b.hs	0x101442c3c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1790>
101442c20: 52800309    	mov	w9, #0x18               ; =24
101442c24: 9b095689    	madd	x9, x20, x9, x21
101442c28: d2800014    	mov	x20, #0x0               ; =0
101442c2c: 52800016    	mov	w22, #0x0               ; =0
101442c30: 91006135    	add	x21, x9, #0x18
101442c34: 3707aa08    	tbnz	w8, #0x0, 0x101442174 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xcc8>
101442c38: 17fffd58    	b	0x101442198 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xcec>
101442c3c: a945a7e8    	ldp	x8, x9, [sp, #0x58]
101442c40: f94043fc    	ldr	x28, [sp, #0x80]
101442c44: a90bf3e9    	stp	x9, x28, [sp, #0xb8]
101442c48: f90067e8    	str	x8, [sp, #0xc8]
101442c4c: f94027fb    	ldr	x27, [sp, #0x48]
101442c50: b4007a9c    	cbz	x28, 0x101443ba0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x26f4>
101442c54: f9403be0    	ldr	x0, [sp, #0x70]
101442c58: aa1b03e1    	mov	x1, x27
101442c5c: 97d427d3    	bl	0x10094cba8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x39b80>
101442c60: aa0003f4    	mov	x20, x0
101442c64: aa0103f3    	mov	x19, x1
101442c68: a90d07e0    	stp	x0, x1, [sp, #0xd0]
101442c6c: f100803f    	cmp	x1, #0x20
101442c70: 540000a2    	b.hs	0x101442c84 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x17d8>
101442c74: aa1403e0    	mov	x0, x20
101442c78: aa1303e1    	mov	x1, x19
101442c7c: 940f84a2    	bl	0x101823f04 <__ZN4core3str5count23char_count_general_case17h2f8d6c508e57bc8aE>
101442c80: 14000004    	b	0x101442c90 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x17e4>
101442c84: aa1403e0    	mov	x0, x20
101442c88: aa1303e1    	mov	x1, x19
101442c8c: 940f82d3    	bl	0x1018237d8 <__ZN4core3str5count14do_count_chars17hd1916c92f730a8c1E>
101442c90: b4007893    	cbz	x19, 0x101443ba0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x26f4>
101442c94: f120001f    	cmp	x0, #0x800
101442c98: 54007848    	b.hi	0x101443ba0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x26f4>
101442c9c: 39454308    	ldrb	w8, [x24, #0x150]
101442ca0: 36005e68    	tbz	w8, #0x0, 0x10144386c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x23c0>
101442ca4: 910443e8    	add	x8, sp, #0x110
101442ca8: aa1403e0    	mov	x0, x20
101442cac: aa1303e1    	mov	x1, x19
101442cb0: 94001e42    	bl	0x10144a5b8 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E>
101442cb4: a951dbe8    	ldp	x8, x22, [sp, #0x118]
101442cb8: a902a3f4    	stp	x20, x8, [sp, #0x28]
101442cbc: b40046b6    	cbz	x22, 0x101443590 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x20e4>
101442cc0: 52800008    	mov	w8, #0x0                ; =0
101442cc4: 52800309    	mov	w9, #0x18               ; =24
101442cc8: f9401bf7    	ldr	x23, [sp, #0x30]
101442ccc: 9b095eda    	madd	x26, x22, x9, x23
101442cd0: 0f0107a8    	movi.2s	v8, #0x3d
101442cd4: 0f020409    	movi.2s	v9, #0x40
101442cd8: 14000005    	b	0x101442cec <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1840>
101442cdc: 52800008    	mov	w8, #0x0                ; =0
101442ce0: 910062f7    	add	x23, x23, #0x18
101442ce4: eb1a02ff    	cmp	x23, x26
101442ce8: 54004540    	b.eq	0x101443590 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x20e4>
101442cec: 370047c8    	tbnz	w8, #0x0, 0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
101442cf0: a940d6f9    	ldp	x25, x21, [x23, #0x8]
101442cf4: d10363a8    	sub	x8, x29, #0xd8
101442cf8: aa1903e0    	mov	x0, x25
101442cfc: aa1503e1    	mov	x1, x21
101442d00: 940f228d    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
101442d04: a97323a0    	ldp	x0, x8, [x29, #-0xd0]
101442d08: d1000908    	sub	x8, x8, #0x2
101442d0c: f100351f    	cmp	x8, #0xd
101442d10: 54001388    	b.hi	0x101442f80 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ad4>
101442d14: b00044eb    	adrp	x11, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101442d18: 9110816b    	add	x11, x11, #0x420
101442d1c: 10000089    	adr	x9, 0x101442d2c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1880>
101442d20: 3868696a    	ldrb	w10, [x11, x8]
101442d24: 8b0a0929    	add	x9, x9, x10, lsl #2
101442d28: d61f0120    	br	x9
101442d2c: 79400008    	ldrh	w8, [x0]
101442d30: 528e05a9    	mov	w9, #0x702d             ; =28717
101442d34: 6b09011f    	cmp	w8, w9
101442d38: 54001241    	b.ne	0x101442f80 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ad4>
101442d3c: 140000a7    	b	0x101442fd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b2c>
101442d40: f9400008    	ldr	x8, [x0]
101442d44: f8407009    	ldur	x9, [x0, #0x7]
101442d48: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101442d4c: f2aeac2a    	movk	x10, #0x7561, lsl #16
101442d50: f2cd0e8a    	movk	x10, #0x6874, lsl #32
101442d54: f2ee4dea    	movk	x10, #0x726f, lsl #48
101442d58: eb08015f    	cmp	x10, x8
101442d5c: d28d2e48    	mov	x8, #0x6972             ; =26994
101442d60: f2ac2f48    	movk	x8, #0x617a, lsl #16
101442d64: f2cd2e88    	movk	x8, #0x6974, lsl #32
101442d68: f2edcde8    	movk	x8, #0x6e6f, lsl #48
101442d6c: 14000083    	b	0x101442f78 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1acc>
101442d70: f9400008    	ldr	x8, [x0]
101442d74: d285a5a9    	mov	x9, #0x2d2d             ; =11565
101442d78: f2ac2e09    	movk	x9, #0x6170, lsl #16
101442d7c: f2ce6e69    	movk	x9, #0x7373, lsl #32
101442d80: f2ec8ee9    	movk	x9, #0x6477, lsl #48
101442d84: eb08013f    	cmp	x9, x8
101442d88: 54001280    	b.eq	0x101442fd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b2c>
101442d8c: f9400008    	ldr	x8, [x0]
101442d90: d285a5a9    	mov	x9, #0x2d2d             ; =11565
101442d94: f2ae0c29    	movk	x9, #0x7061, lsl #16
101442d98: f2cd6d29    	movk	x9, #0x6b69, lsl #32
101442d9c: f2ef2ca9    	movk	x9, #0x7965, lsl #48
101442da0: eb08013f    	cmp	x9, x8
101442da4: 540011a0    	b.eq	0x101442fd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b2c>
101442da8: f9400008    	ldr	x8, [x0]
101442dac: d285a5a9    	mov	x9, #0x2d2d             ; =11565
101442db0: f2acae69    	movk	x9, #0x6573, lsl #16
101442db4: f2ce4c69    	movk	x9, #0x7263, lsl #32
101442db8: f2ee8ca9    	movk	x9, #0x7465, lsl #48
101442dbc: eb08013f    	cmp	x9, x8
101442dc0: 54000e01    	b.ne	0x101442f80 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ad4>
101442dc4: 14000085    	b	0x101442fd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b2c>
101442dc8: f9400008    	ldr	x8, [x0]
101442dcc: 39402009    	ldrb	w9, [x0, #0x8]
101442dd0: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101442dd4: f2ae0c2a    	movk	x10, #0x7061, lsl #16
101442dd8: f2c5ad2a    	movk	x10, #0x2d69, lsl #32
101442ddc: f2ecad6a    	movk	x10, #0x656b, lsl #48
101442de0: eb08015f    	cmp	x10, x8
101442de4: 1400001f    	b	0x101442e60 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x19b4>
101442de8: b9400008    	ldr	w8, [x0]
101442dec: b8403009    	ldur	w9, [x0, #0x3]
101442df0: 5285a5aa    	mov	w10, #0x2d2d            ; =11565
101442df4: 72adee8a    	movk	w10, #0x6f74, lsl #16
101442df8: 6b08015f    	cmp	w10, w8
101442dfc: 528d6de8    	mov	w8, #0x6b6f             ; =27503
101442e00: 72adcca8    	movk	w8, #0x6e65, lsl #16
101442e04: 7a490100    	ccmp	w8, w9, #0x0, eq
101442e08: 54000bc1    	b.ne	0x101442f80 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ad4>
101442e0c: 14000073    	b	0x101442fd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b2c>
101442e10: b9400008    	ldr	w8, [x0]
101442e14: 79400809    	ldrh	w9, [x0, #0x4]
101442e18: 5285a5aa    	mov	w10, #0x2d2d            ; =11565
101442e1c: 72ac2e0a    	movk	w10, #0x6170, lsl #16
101442e20: 6b08015f    	cmp	w10, w8
101442e24: 528e6e68    	mov	w8, #0x7373             ; =29555
101442e28: 7a480120    	ccmp	w9, w8, #0x0, eq
101442e2c: 54000d60    	b.eq	0x101442fd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b2c>
101442e30: b9400008    	ldr	w8, [x0]
101442e34: 79400809    	ldrh	w9, [x0, #0x4]
101442e38: 5285a5aa    	mov	w10, #0x2d2d            ; =11565
101442e3c: 72aeac2a    	movk	w10, #0x7561, lsl #16
101442e40: 6b08015f    	cmp	w10, w8
101442e44: 528d0e88    	mov	w8, #0x6874             ; =26740
101442e48: 14000010    	b	0x101442e88 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x19dc>
101442e4c: b9400008    	ldr	w8, [x0]
101442e50: 39401009    	ldrb	w9, [x0, #0x4]
101442e54: 5285a5aa    	mov	w10, #0x2d2d            ; =11565
101442e58: 72acad6a    	movk	w10, #0x656b, lsl #16
101442e5c: 6b08015f    	cmp	w10, w8
101442e60: 52800f28    	mov	w8, #0x79               ; =121
101442e64: 14000009    	b	0x101442e88 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x19dc>
101442e68: f9400008    	ldr	x8, [x0]
101442e6c: 79401009    	ldrh	w9, [x0, #0x8]
101442e70: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101442e74: f2ac2e0a    	movk	x10, #0x6170, lsl #16
101442e78: f2ce6e6a    	movk	x10, #0x7373, lsl #32
101442e7c: f2edeeea    	movk	x10, #0x6f77, lsl #48
101442e80: eb08015f    	cmp	x10, x8
101442e84: 528c8e48    	mov	w8, #0x6472             ; =25714
101442e88: 7a480120    	ccmp	w9, w8, #0x0, eq
101442e8c: 540007a1    	b.ne	0x101442f80 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ad4>
101442e90: 14000052    	b	0x101442fd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b2c>
101442e94: f9400008    	ldr	x8, [x0]
101442e98: b9400809    	ldr	w9, [x0, #0x8]
101442e9c: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101442ea0: f2acae6a    	movk	x10, #0x6573, lsl #16
101442ea4: f2ce4c6a    	movk	x10, #0x7263, lsl #32
101442ea8: f2ee8caa    	movk	x10, #0x7465, lsl #48
101442eac: eb08015f    	cmp	x10, x8
101442eb0: 528d65a8    	mov	w8, #0x6b2d             ; =27437
101442eb4: 72af2ca8    	movk	w8, #0x7965, lsl #16
101442eb8: fa490100    	ccmp	x8, x9, #0x0, eq
101442ebc: 540008e0    	b.eq	0x101442fd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b2c>
101442ec0: f9400008    	ldr	x8, [x0]
101442ec4: b9400809    	ldr	w9, [x0, #0x8]
101442ec8: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101442ecc: f2ae4c6a    	movk	x10, #0x7263, lsl #16
101442ed0: f2cc8caa    	movk	x10, #0x6465, lsl #32
101442ed4: f2edccaa    	movk	x10, #0x6e65, lsl #48
101442ed8: eb08015f    	cmp	x10, x8
101442edc: 528d2e88    	mov	w8, #0x6974             ; =26996
101442ee0: 72ad8c28    	movk	w8, #0x6c61, lsl #16
101442ee4: 14000025    	b	0x101442f78 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1acc>
101442ee8: f9400008    	ldr	x8, [x0]
101442eec: f8406009    	ldur	x9, [x0, #0x6]
101442ef0: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101442ef4: f2ac6c2a    	movk	x10, #0x6361, lsl #16
101442ef8: f2ccac6a    	movk	x10, #0x6563, lsl #32
101442efc: f2ee6e6a    	movk	x10, #0x7373, lsl #48
101442f00: eb08015f    	cmp	x10, x8
101442f04: d28e6e68    	mov	x8, #0x7373             ; =29555
101442f08: f2ae85a8    	movk	x8, #0x742d, lsl #16
101442f0c: f2cd6de8    	movk	x8, #0x6b6f, lsl #32
101442f10: f2edcca8    	movk	x8, #0x6e65, lsl #48
101442f14: 14000019    	b	0x101442f78 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1acc>
101442f18: f9400008    	ldr	x8, [x0]
101442f1c: f8405009    	ldur	x9, [x0, #0x5]
101442f20: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101442f24: f2ae4e0a    	movk	x10, #0x7270, lsl #16
101442f28: f2cecd2a    	movk	x10, #0x7669, lsl #32
101442f2c: f2ee8c2a    	movk	x10, #0x7461, lsl #48
101442f30: eb08015f    	cmp	x10, x8
101442f34: d28c2ec8    	mov	x8, #0x6176             ; =24950
101442f38: f2acae88    	movk	x8, #0x6574, lsl #16
101442f3c: f2cd65a8    	movk	x8, #0x6b2d, lsl #32
101442f40: f2ef2ca8    	movk	x8, #0x7965, lsl #48
101442f44: fa490100    	ccmp	x8, x9, #0x0, eq
101442f48: 54000480    	b.eq	0x101442fd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b2c>
101442f4c: f9400008    	ldr	x8, [x0]
101442f50: f8405009    	ldur	x9, [x0, #0x5]
101442f54: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101442f58: f2ae4c6a    	movk	x10, #0x7263, lsl #16
101442f5c: f2cc8caa    	movk	x10, #0x6465, lsl #32
101442f60: f2edccaa    	movk	x10, #0x6e65, lsl #48
101442f64: eb08015f    	cmp	x10, x8
101442f68: d28cac88    	mov	x8, #0x6564             ; =25956
101442f6c: f2ae8dc8    	movk	x8, #0x746e, lsl #16
101442f70: f2cc2d28    	movk	x8, #0x6169, lsl #32
101442f74: f2ee6d88    	movk	x8, #0x736c, lsl #48
101442f78: fa490100    	ccmp	x8, x9, #0x0, eq
101442f7c: 540002e0    	b.eq	0x101442fd8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b2c>
101442f80: f85283a1    	ldur	x1, [x29, #-0xd8]
101442f84: b4000061    	cbz	x1, 0x101442f90 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ae4>
101442f88: 52800022    	mov	w2, #0x1                ; =1
101442f8c: 97d96dd4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101442f90: a932d7b9    	stp	x25, x21, [x29, #-0xd8]
101442f94: a933d7bf    	stp	xzr, x21, [x29, #-0xc8]
101442f98: 52800028    	mov	w8, #0x1                ; =1
101442f9c: 381503a8    	sturb	w8, [x29, #-0xb0]
101442fa0: fc1483a8    	stur	d8, [x29, #-0xb8]
101442fa4: 910583e0    	add	x0, sp, #0x160
101442fa8: d10363a1    	sub	x1, x29, #0xd8
101442fac: 9400a7cc    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101442fb0: b94163e8    	ldr	w8, [sp, #0x160]
101442fb4: 360012c8    	tbz	w8, #0x0, 0x10144320c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1d60>
101442fb8: f940bbe8    	ldr	x8, [sp, #0x170]
101442fbc: eb0802bf    	cmp	x21, x8
101442fc0: 54001260    	b.eq	0x10144320c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1d60>
101442fc4: d280000c    	mov	x12, #0x0               ; =0
101442fc8: f940b7e8    	ldr	x8, [sp, #0x168]
101442fcc: 8b080329    	add	x9, x25, x8
101442fd0: cb09010a    	sub	x10, x8, x9
101442fd4: 1400000d    	b	0x101443008 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b5c>
101442fd8: f85283a1    	ldur	x1, [x29, #-0xd8]
101442fdc: b4000061    	cbz	x1, 0x101442fe8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b3c>
101442fe0: 52800022    	mov	w2, #0x1                ; =1
101442fe4: 97d96dbe    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101442fe8: 52800028    	mov	w8, #0x1                ; =1
101442fec: 17ffff3d    	b	0x101442ce0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1834>
101442ff0: 910009ac    	add	x12, x13, #0x2
101442ff4: 331a116f    	bfi	w15, w11, #6, #5
101442ff8: aa0f03eb    	mov	x11, x15
101442ffc: 8b0c014c    	add	x12, x10, x12
101443000: 7100b57f    	cmp	w11, #0x2d
101443004: 540003a1    	b.ne	0x101443078 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1bcc>
101443008: eb08019f    	cmp	x12, x8
10144300c: 54000340    	b.eq	0x101443074 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1bc8>
101443010: aa0c03e9    	mov	x9, x12
101443014: 8b0c032d    	add	x13, x25, x12
101443018: aa0d03ec    	mov	x12, x13
10144301c: 38c0158e    	ldrsb	w14, [x12], #0x1
101443020: 12001dcb    	and	w11, w14, #0xff
101443024: 36fffece    	tbz	w14, #0x1f, 0x101442ffc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b50>
101443028: 394005ac    	ldrb	w12, [x13, #0x1]
10144302c: 1200158f    	and	w15, w12, #0x3f
101443030: 7103817f    	cmp	w11, #0xe0
101443034: 54fffde3    	b.lo	0x101442ff0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b44>
101443038: 1200116e    	and	w14, w11, #0x1f
10144303c: 394009ac    	ldrb	w12, [x13, #0x2]
101443040: 1200158c    	and	w12, w12, #0x3f
101443044: 2a0f198f    	orr	w15, w12, w15, lsl #6
101443048: 7103c17f    	cmp	w11, #0xf0
10144304c: 540000e3    	b.lo	0x101443068 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1bbc>
101443050: 910011ac    	add	x12, x13, #0x4
101443054: 39400dab    	ldrb	w11, [x13, #0x3]
101443058: 1200156b    	and	w11, w11, #0x3f
10144305c: 2a0f196b    	orr	w11, w11, w15, lsl #6
101443060: 330e09cb    	bfi	w11, w14, #18, #3
101443064: 17ffffe6    	b	0x101442ffc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b50>
101443068: 91000dac    	add	x12, x13, #0x3
10144306c: 2a0e31eb    	orr	w11, w15, w14, lsl #12
101443070: 17ffffe3    	b	0x101442ffc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1b50>
101443074: aa0803e9    	mov	x9, x8
101443078: cb090101    	sub	x1, x8, x9
10144307c: 9106c3e8    	add	x8, sp, #0x1b0
101443080: 8b090320    	add	x0, x25, x9
101443084: 940f21ac    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
101443088: a95bf3e8    	ldp	x8, x28, [sp, #0x1b8]
10144308c: f9002be8    	str	x8, [sp, #0x50]
101443090: f100439f    	cmp	x28, #0x10
101443094: 54000562    	b.hs	0x101443140 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1c94>
101443098: d2800014    	mov	x20, #0x0               ; =0
10144309c: 14000004    	b	0x1014430ac <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1c00>
1014430a0: 91004294    	add	x20, x20, #0x10
1014430a4: f103429f    	cmp	x20, #0xd0
1014430a8: 54000a20    	b.eq	0x1014431ec <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1d40>
1014430ac: d0007128    	adrp	x8, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
1014430b0: 91148108    	add	x8, x8, #0x520
1014430b4: 8b140108    	add	x8, x8, x20
1014430b8: f9400503    	ldr	x3, [x8, #0x8]
1014430bc: b40003e3    	cbz	x3, 0x101443138 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1c8c>
1014430c0: f9400102    	ldr	x2, [x8]
1014430c4: eb1c007f    	cmp	x3, x28
1014430c8: 54000182    	b.hs	0x1014430f8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1c4c>
1014430cc: f100047f    	cmp	x3, #0x1
1014430d0: 54000221    	b.ne	0x101443114 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1c68>
1014430d4: 39400048    	ldrb	w8, [x2]
1014430d8: f9402be9    	ldr	x9, [sp, #0x50]
1014430dc: aa1c03ea    	mov	x10, x28
1014430e0: 3840152b    	ldrb	w11, [x9], #0x1
1014430e4: 6b08017f    	cmp	w11, w8
1014430e8: 54000280    	b.eq	0x101443138 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1c8c>
1014430ec: f100054a    	subs	x10, x10, #0x1
1014430f0: 54ffff81    	b.ne	0x1014430e0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1c34>
1014430f4: 17ffffeb    	b	0x1014430a0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1bf4>
1014430f8: 54fffd41    	b.ne	0x1014430a0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1bf4>
1014430fc: aa0203e0    	mov	x0, x2
101443100: f9402be1    	ldr	x1, [sp, #0x50]
101443104: aa1c03e2    	mov	x2, x28
101443108: 941a1ac5    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10144310c: 35fffca0    	cbnz	w0, 0x1014430a0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1bf4>
101443110: 1400000a    	b	0x101443138 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1c8c>
101443114: d10363a8    	sub	x8, x29, #0xd8
101443118: f9402be0    	ldr	x0, [sp, #0x50]
10144311c: aa1c03e1    	mov	x1, x28
101443120: 940f8423    	bl	0x1018241ac <__ZN4core3str7pattern11StrSearcher3new17hb0ec4e7243414bb1E>
101443124: 910583e0    	add	x0, sp, #0x160
101443128: d10363a1    	sub	x1, x29, #0xd8
10144312c: 9400a543    	bl	0x10146c638 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xf08>
101443130: b94163e8    	ldr	w8, [sp, #0x160]
101443134: 3607fb68    	tbz	w8, #0x0, 0x1014430a0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1bf4>
101443138: 52800034    	mov	w20, #0x1               ; =1
10144313c: 1400002d    	b	0x1014431f0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1d44>
101443140: d0007134    	adrp	x20, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101443144: 9114a294    	add	x20, x20, #0x528
101443148: 52801a1b    	mov	w27, #0xd0              ; =208
10144314c: 14000004    	b	0x10144315c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1cb0>
101443150: 91004294    	add	x20, x20, #0x10
101443154: f100437b    	subs	x27, x27, #0x10
101443158: 54000440    	b.eq	0x1014431e0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1d34>
10144315c: f9400283    	ldr	x3, [x20]
101443160: b40003a3    	cbz	x3, 0x1014431d4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1d28>
101443164: f85f8282    	ldur	x2, [x20, #-0x8]
101443168: eb1c007f    	cmp	x3, x28
10144316c: 54000142    	b.hs	0x101443194 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ce8>
101443170: f100047f    	cmp	x3, #0x1
101443174: 540001e1    	b.ne	0x1014431b0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1d04>
101443178: 39400040    	ldrb	w0, [x2]
10144317c: f9402be1    	ldr	x1, [sp, #0x50]
101443180: aa1c03e2    	mov	x2, x28
101443184: 940f886f    	bl	0x101825340 <__ZN4core5slice6memchr14memchr_aligned17hb4aaf9792c60d219E>
101443188: f100041f    	cmp	x0, #0x1
10144318c: 54fffe21    	b.ne	0x101443150 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ca4>
101443190: 14000011    	b	0x1014431d4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1d28>
101443194: 54fffde1    	b.ne	0x101443150 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ca4>
101443198: aa0203e0    	mov	x0, x2
10144319c: f9402be1    	ldr	x1, [sp, #0x50]
1014431a0: aa1c03e2    	mov	x2, x28
1014431a4: 941a1a9e    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
1014431a8: 35fffd40    	cbnz	w0, 0x101443150 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ca4>
1014431ac: 1400000a    	b	0x1014431d4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1d28>
1014431b0: d10363a8    	sub	x8, x29, #0xd8
1014431b4: f9402be0    	ldr	x0, [sp, #0x50]
1014431b8: aa1c03e1    	mov	x1, x28
1014431bc: 940f83fc    	bl	0x1018241ac <__ZN4core3str7pattern11StrSearcher3new17hb0ec4e7243414bb1E>
1014431c0: 910583e0    	add	x0, sp, #0x160
1014431c4: d10363a1    	sub	x1, x29, #0xd8
1014431c8: 9400a51c    	bl	0x10146c638 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xf08>
1014431cc: b94163e8    	ldr	w8, [sp, #0x160]
1014431d0: 3607fc08    	tbz	w8, #0x0, 0x101443150 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ca4>
1014431d4: 52800034    	mov	w20, #0x1               ; =1
1014431d8: f94027fb    	ldr	x27, [sp, #0x48]
1014431dc: 14000005    	b	0x1014431f0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1d44>
1014431e0: 52800014    	mov	w20, #0x0               ; =0
1014431e4: f94027fb    	ldr	x27, [sp, #0x48]
1014431e8: 14000002    	b	0x1014431f0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1d44>
1014431ec: 52800014    	mov	w20, #0x0               ; =0
1014431f0: f940dbe1    	ldr	x1, [sp, #0x1b0]
1014431f4: f94043fc    	ldr	x28, [sp, #0x80]
1014431f8: b4000081    	cbz	x1, 0x101443208 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1d5c>
1014431fc: f9402be0    	ldr	x0, [sp, #0x50]
101443200: 52800022    	mov	w2, #0x1                ; =1
101443204: 97d96d36    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443208: 35001ef4    	cbnz	w20, 0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
10144320c: f1000ebf    	cmp	x21, #0x3
101443210: 54000fc3    	b.lo	0x101443408 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1f5c>
101443214: 79400328    	ldrh	w8, [x25]
101443218: 39400b29    	ldrb	w9, [x25, #0x2]
10144321c: 528d6e6a    	mov	w10, #0x6b73            ; =27507
101443220: 6b0a011f    	cmp	w8, w10
101443224: 528005a8    	mov	w8, #0x2d               ; =45
101443228: 7a480120    	ccmp	w9, w8, #0x0, eq
10144322c: 54001dc0    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
101443230: f1000ebf    	cmp	x21, #0x3
101443234: 54000ea0    	b.eq	0x101443408 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1f5c>
101443238: b9400328    	ldr	w8, [x25]
10144323c: 528d0ce9    	mov	w9, #0x6867             ; =26727
101443240: 72abede9    	movk	w9, #0x5f6f, lsl #16
101443244: 11404129    	add	w9, w9, #0x10, lsl #12  ; =0x10000
101443248: 6b08013f    	cmp	w9, w8
10144324c: 54001cc0    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
101443250: b9400328    	ldr	w8, [x25]
101443254: 528d0ce9    	mov	w9, #0x6867             ; =26727
101443258: 72abede9    	movk	w9, #0x5f6f, lsl #16
10144325c: 6b08013f    	cmp	w9, w8
101443260: 54001c20    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
101443264: b9400328    	ldr	w8, [x25]
101443268: 11418129    	add	w9, w9, #0x60, lsl #12  ; =0x60000
10144326c: 6b08013f    	cmp	w9, w8
101443270: 54001ba0    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
101443274: b9400328    	ldr	w8, [x25]
101443278: 528d0ce9    	mov	w9, #0x6867             ; =26727
10144327c: 72abede9    	movk	w9, #0x5f6f, lsl #16
101443280: 11410129    	add	w9, w9, #0x40, lsl #12  ; =0x40000
101443284: 6b08013f    	cmp	w9, w8
101443288: 54001ae0    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
10144328c: f1002ebf    	cmp	x21, #0xb
101443290: 540000e2    	b.hs	0x1014432ac <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1e00>
101443294: f1001abf    	cmp	x21, #0x6
101443298: 54000242    	b.hs	0x1014432e0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1e34>
10144329c: f10016bf    	cmp	x21, #0x5
1014432a0: 54000300    	b.eq	0x101443300 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1e54>
1014432a4: 52800028    	mov	w8, #0x1                ; =1
1014432a8: 14000037    	b	0x101443384 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ed8>
1014432ac: f9400328    	ldr	x8, [x25]
1014432b0: f8403329    	ldur	x9, [x25, #0x3]
1014432b4: d28d2cea    	mov	x10, #0x6967            ; =26983
1014432b8: f2ad0e8a    	movk	x10, #0x6874, lsl #16
1014432bc: f2cc4eaa    	movk	x10, #0x6275, lsl #32
1014432c0: f2ee0bea    	movk	x10, #0x705f, lsl #48
1014432c4: eb0a011f    	cmp	x8, x10
1014432c8: d28ead08    	mov	x8, #0x7568             ; =30056
1014432cc: f2abec48    	movk	x8, #0x5f62, lsl #16
1014432d0: f2cc2e08    	movk	x8, #0x6170, lsl #32
1014432d4: f2ebee88    	movk	x8, #0x5f74, lsl #48
1014432d8: fa480120    	ccmp	x9, x8, #0x0, eq
1014432dc: 54001840    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
1014432e0: b9400328    	ldr	w8, [x25]
1014432e4: 79400b29    	ldrh	w9, [x25, #0x4]
1014432e8: 528d8cea    	mov	w10, #0x6c67            ; =27751
1014432ec: 72ac2e0a    	movk	w10, #0x6170, lsl #16
1014432f0: 6b0a011f    	cmp	w8, w10
1014432f4: 5285ae88    	mov	w8, #0x2d74             ; =11636
1014432f8: 7a480120    	ccmp	w9, w8, #0x0, eq
1014432fc: 54001740    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
101443300: b9400328    	ldr	w8, [x25]
101443304: 39401329    	ldrb	w9, [x25, #0x4]
101443308: 528def0a    	mov	w10, #0x6f78            ; =28536
10144330c: 72ac4f0a    	movk	w10, #0x6278, lsl #16
101443310: 6b0a011f    	cmp	w8, w10
101443314: 528005a8    	mov	w8, #0x2d               ; =45
101443318: 7a480120    	ccmp	w9, w8, #0x0, eq
10144331c: 54001640    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
101443320: b9400328    	ldr	w8, [x25]
101443324: 39401329    	ldrb	w9, [x25, #0x4]
101443328: 528def0a    	mov	w10, #0x6f78            ; =28536
10144332c: 72ae0f0a    	movk	w10, #0x7078, lsl #16
101443330: 6b0a011f    	cmp	w8, w10
101443334: 528005a8    	mov	w8, #0x2d               ; =45
101443338: 7a480120    	ccmp	w9, w8, #0x0, eq
10144333c: 54001540    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
101443340: b9400328    	ldr	w8, [x25]
101443344: 39401329    	ldrb	w9, [x25, #0x4]
101443348: 528def0a    	mov	w10, #0x6f78            ; =28536
10144334c: 72ac2f0a    	movk	w10, #0x6178, lsl #16
101443350: 6b0a011f    	cmp	w8, w10
101443354: 528005a8    	mov	w8, #0x2d               ; =45
101443358: 7a480120    	ccmp	w9, w8, #0x0, eq
10144335c: 54001440    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
101443360: b9400328    	ldr	w8, [x25]
101443364: 39401329    	ldrb	w9, [x25, #0x4]
101443368: 528def0a    	mov	w10, #0x6f78            ; =28536
10144336c: 72ae6f0a    	movk	w10, #0x7378, lsl #16
101443370: 6b0a011f    	cmp	w8, w10
101443374: 528005a8    	mov	w8, #0x2d               ; =45
101443378: 7a480120    	ccmp	w9, w8, #0x0, eq
10144337c: 54001340    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
101443380: 52800008    	mov	w8, #0x0                ; =0
101443384: b9400329    	ldr	w9, [x25]
101443388: 5289682a    	mov	w10, #0x4b41            ; =19265
10144338c: 72a8292a    	movk	w10, #0x4149, lsl #16
101443390: 6b0a013f    	cmp	w9, w10
101443394: 54001280    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
101443398: b9400329    	ldr	w9, [x25]
10144339c: 1120014a    	add	w10, w10, #0x800
1014433a0: 6b09015f    	cmp	w10, w9
1014433a4: 54001200    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
1014433a8: b9400329    	ldr	w9, [x25]
1014433ac: 5289282a    	mov	w10, #0x4941            ; =18753
1014433b0: 72ac2f4a    	movk	w10, #0x617a, lsl #16
1014433b4: 6b0a013f    	cmp	w9, w10
1014433b8: 54001160    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
1014433bc: 37000128    	tbnz	w8, #0x0, 0x1014433e0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1f34>
1014433c0: b9400328    	ldr	w8, [x25]
1014433c4: 39401329    	ldrb	w9, [x25, #0x4]
1014433c8: 528c2f2a    	mov	w10, #0x6179            ; =24953
1014433cc: 72a7264a    	movk	w10, #0x3932, lsl #16
1014433d0: 6b0a011f    	cmp	w8, w10
1014433d4: 528005c8    	mov	w8, #0x2e               ; =46
1014433d8: 7a480120    	ccmp	w9, w8, #0x0, eq
1014433dc: 54001040    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
1014433e0: f1001abf    	cmp	x21, #0x6
1014433e4: 54000129    	b.ls	0x101443408 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1f5c>
1014433e8: 79400328    	ldrh	w8, [x25]
1014433ec: 5285a5a9    	mov	w9, #0x2d2d             ; =11565
1014433f0: 6b09011f    	cmp	w8, w9
1014433f4: 540000a0    	b.eq	0x101443408 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1f5c>
1014433f8: 79400328    	ldrh	w8, [x25]
1014433fc: 528e05a9    	mov	w9, #0x702d             ; =28717
101443400: 6b09011f    	cmp	w8, w9
101443404: 54000740    	b.eq	0x1014434ec <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2040>
101443408: d10363a8    	sub	x8, x29, #0xd8
10144340c: aa1903e0    	mov	x0, x25
101443410: aa1503e1    	mov	x1, x21
101443414: d00044e2    	adrp	x2, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101443418: 9129a842    	add	x2, x2, #0xa6a
10144341c: 52800063    	mov	w3, #0x3                ; =3
101443420: 940f8363    	bl	0x1018241ac <__ZN4core3str7pattern11StrSearcher3new17hb0ec4e7243414bb1E>
101443424: 910583e0    	add	x0, sp, #0x160
101443428: d10363a1    	sub	x1, x29, #0xd8
10144342c: 9400a483    	bl	0x10146c638 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xf08>
101443430: b94163e8    	ldr	w8, [sp, #0x160]
101443434: 3607c548    	tbz	w8, #0x0, 0x101442cdc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1830>
101443438: f940bbe8    	ldr	x8, [sp, #0x170]
10144343c: cb0802a9    	sub	x9, x21, x8
101443440: 8b080335    	add	x21, x25, x8
101443444: a932a7b5    	stp	x21, x9, [x29, #-0xd8]
101443448: a933a7bf    	stp	xzr, x9, [x29, #-0xc8]
10144344c: 52800028    	mov	w8, #0x1                ; =1
101443450: 381503a8    	sturb	w8, [x29, #-0xb0]
101443454: fc1483a9    	stur	d9, [x29, #-0xb8]
101443458: 910583e0    	add	x0, sp, #0x160
10144345c: d10363a1    	sub	x1, x29, #0xd8
101443460: 9400a69f    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101443464: b94163e8    	ldr	w8, [sp, #0x160]
101443468: 3607c3a8    	tbz	w8, #0x0, 0x101442cdc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1830>
10144346c: f940b7f9    	ldr	x25, [sp, #0x168]
101443470: f1003f3f    	cmp	x25, #0xf
101443474: 54000228    	b.hi	0x1014434b8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x200c>
101443478: b4ffc339    	cbz	x25, 0x101442cdc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1830>
10144347c: d2800009    	mov	x9, #0x0                ; =0
101443480: 38696aa8    	ldrb	w8, [x21, x9]
101443484: 7100e91f    	cmp	w8, #0x3a
101443488: 54000100    	b.eq	0x1014434a8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ffc>
10144348c: 52800008    	mov	w8, #0x0                ; =0
101443490: 91000529    	add	x9, x9, #0x1
101443494: eb09033f    	cmp	x25, x9
101443498: 54ffff41    	b.ne	0x101443480 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1fd4>
10144349c: 17fffe11    	b	0x101442ce0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1834>
1014434a0: f1000739    	subs	x25, x25, #0x1
1014434a4: 54000a00    	b.eq	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
1014434a8: 384016a8    	ldrb	w8, [x21], #0x1
1014434ac: 7100bd1f    	cmp	w8, #0x2f
1014434b0: 54ffff81    	b.ne	0x1014434a0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1ff4>
1014434b4: 17fffe0a    	b	0x101442cdc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1830>
1014434b8: 52800740    	mov	w0, #0x3a               ; =58
1014434bc: aa1503e1    	mov	x1, x21
1014434c0: aa1903e2    	mov	x2, x25
1014434c4: 940f879f    	bl	0x101825340 <__ZN4core5slice6memchr14memchr_aligned17hb4aaf9792c60d219E>
1014434c8: f100041f    	cmp	x0, #0x1
1014434cc: 54ffc081    	b.ne	0x101442cdc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1830>
1014434d0: 528005e0    	mov	w0, #0x2f               ; =47
1014434d4: aa1503e1    	mov	x1, x21
1014434d8: aa1903e2    	mov	x2, x25
1014434dc: 940f8799    	bl	0x101825340 <__ZN4core5slice6memchr14memchr_aligned17hb4aaf9792c60d219E>
1014434e0: f100041f    	cmp	x0, #0x1
1014434e4: 54ffbfc0    	b.eq	0x101442cdc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1830>
1014434e8: 1400003f    	b	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
1014434ec: aa1903e8    	mov	x8, x25
1014434f0: 38c02d09    	ldrsb	w9, [x8, #0x2]!
1014434f4: 3101013f    	cmn	w9, #0x40
1014434f8: 54004a0b    	b.lt	0x101443e38 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x298c>
1014434fc: 8b150329    	add	x9, x25, x21
101443500: 14000005    	b	0x101443514 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2068>
101443504: aa0b03e8    	mov	x8, x11
101443508: 5100e94a    	sub	w10, w10, #0x3a
10144350c: 3100295f    	cmn	w10, #0xa
101443510: 540006a3    	b.lo	0x1014435e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2138>
101443514: eb09011f    	cmp	x8, x9
101443518: 54fff780    	b.eq	0x101443408 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1f5c>
10144351c: aa0803eb    	mov	x11, x8
101443520: 38c0156c    	ldrsb	w12, [x11], #0x1
101443524: 12001d8a    	and	w10, w12, #0xff
101443528: 36fffeec    	tbz	w12, #0x1f, 0x101443504 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2058>
10144352c: 3940050b    	ldrb	w11, [x8, #0x1]
101443530: 1200156c    	and	w12, w11, #0x3f
101443534: 7103815f    	cmp	w10, #0xe0
101443538: 540001e3    	b.lo	0x101443574 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x20c8>
10144353c: 1200114b    	and	w11, w10, #0x1f
101443540: 3940090d    	ldrb	w13, [x8, #0x2]
101443544: 120015ad    	and	w13, w13, #0x3f
101443548: 2a0c19ac    	orr	w12, w13, w12, lsl #6
10144354c: 7103c15f    	cmp	w10, #0xf0
101443550: 540001a3    	b.lo	0x101443584 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x20d8>
101443554: 39400d0a    	ldrb	w10, [x8, #0x3]
101443558: 1200154a    	and	w10, w10, #0x3f
10144355c: 2a0c194a    	orr	w10, w10, w12, lsl #6
101443560: 330e096a    	bfi	w10, w11, #18, #3
101443564: 7144415f    	cmp	w10, #0x110, lsl #12    ; =0x110000
101443568: 54fff500    	b.eq	0x101443408 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x1f5c>
10144356c: 91001108    	add	x8, x8, #0x4
101443570: 17ffffe6    	b	0x101443508 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x205c>
101443574: 91000908    	add	x8, x8, #0x2
101443578: 331a114c    	bfi	w12, w10, #6, #5
10144357c: aa0c03ea    	mov	x10, x12
101443580: 17ffffe2    	b	0x101443508 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x205c>
101443584: 91000d08    	add	x8, x8, #0x3
101443588: 2a0b318a    	orr	w10, w12, w11, lsl #12
10144358c: 17ffffdf    	b	0x101443508 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x205c>
101443590: 9106c3e8    	add	x8, sp, #0x1b0
101443594: f94017e0    	ldr	x0, [sp, #0x28]
101443598: aa1303e1    	mov	x1, x19
10144359c: 940f2066    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
1014435a0: a95bd7f3    	ldp	x19, x21, [sp, #0x1b8]
1014435a4: f10022bf    	cmp	x21, #0x8
1014435a8: 540006a3    	b.lo	0x10144367c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x21d0>
1014435ac: d00044e2    	adrp	x2, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
1014435b0: 912f8842    	add	x2, x2, #0xbe2
1014435b4: d10363a8    	sub	x8, x29, #0xd8
1014435b8: aa1303e0    	mov	x0, x19
1014435bc: aa1503e1    	mov	x1, x21
1014435c0: 528000e3    	mov	w3, #0x7                ; =7
1014435c4: 940f82fa    	bl	0x1018241ac <__ZN4core3str7pattern11StrSearcher3new17hb0ec4e7243414bb1E>
1014435c8: 910583e0    	add	x0, sp, #0x160
1014435cc: d10363a1    	sub	x1, x29, #0xd8
1014435d0: 9400a41a    	bl	0x10146c638 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xf08>
1014435d4: b94163e8    	ldr	w8, [sp, #0x160]
1014435d8: 36000da8    	tbz	w8, #0x0, 0x10144378c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x22e0>
1014435dc: 52800034    	mov	w20, #0x1               ; =1
1014435e0: 14000089    	b	0x101443804 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2358>
1014435e4: f9401be8    	ldr	x8, [sp, #0x30]
1014435e8: 91002113    	add	x19, x8, #0x8
1014435ec: 14000004    	b	0x1014435fc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2150>
1014435f0: 91006273    	add	x19, x19, #0x18
1014435f4: f10006d6    	subs	x22, x22, #0x1
1014435f8: 540000e0    	b.eq	0x101443614 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2168>
1014435fc: f85f8261    	ldur	x1, [x19, #-0x8]
101443600: b4ffff81    	cbz	x1, 0x1014435f0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2144>
101443604: f9400260    	ldr	x0, [x19]
101443608: 52800022    	mov	w2, #0x1                ; =1
10144360c: 97d96c34    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443610: 17fffff8    	b	0x1014435f0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2144>
101443614: f9408be8    	ldr	x8, [sp, #0x110]
101443618: b4002c48    	cbz	x8, 0x101443ba0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x26f4>
10144361c: 8b080508    	add	x8, x8, x8, lsl #1
101443620: d37df101    	lsl	x1, x8, #3
101443624: f9401be0    	ldr	x0, [sp, #0x30]
101443628: 52800102    	mov	w2, #0x8                ; =8
10144362c: 97d96c2c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443630: 1400015c    	b	0x101443ba0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x26f4>
101443634: f940e3f4    	ldr	x20, [sp, #0x1c0]
101443638: b9401fe8    	ldr	w8, [sp, #0x1c]
10144363c: 36000388    	tbz	w8, #0x0, 0x1014436ac <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2200>
101443640: f940dff9    	ldr	x25, [sp, #0x1b8]
101443644: b4000934    	cbz	x20, 0x101443768 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x22bc>
101443648: 8b140688    	add	x8, x20, x20, lsl #1
10144364c: d37df114    	lsl	x20, x8, #3
101443650: b4000494    	cbz	x20, 0x1014436e0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2234>
101443654: 91006337    	add	x23, x25, #0x18
101443658: a9409323    	ldp	x3, x4, [x25, #0x8]
10144365c: d1006294    	sub	x20, x20, #0x18
101443660: aa1803e0    	mov	x0, x24
101443664: 52800021    	mov	w1, #0x1                ; =1
101443668: d2800002    	mov	x2, #0x0                ; =0
10144366c: f9402fe5    	ldr	x5, [sp, #0x58]
101443670: 94000275    	bl	0x101444044 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b98>
101443674: aa1703f9    	mov	x25, x23
101443678: 17fffff6    	b	0x101443650 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x21a4>
10144367c: f1001ebf    	cmp	x21, #0x7
101443680: 54000c01    	b.ne	0x101443800 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2354>
101443684: b9400268    	ldr	w8, [x19]
101443688: b8403269    	ldur	w9, [x19, #0x3]
10144368c: 528cac4a    	mov	w10, #0x6562            ; =25954
101443690: 72ae4c2a    	movk	w10, #0x7261, lsl #16
101443694: 6b0a011f    	cmp	w8, w10
101443698: 528cae48    	mov	w8, #0x6572             ; =25970
10144369c: 72a40e48    	movk	w8, #0x2072, lsl #16
1014436a0: 7a480120    	ccmp	w9, w8, #0x0, eq
1014436a4: 1a9f17f4    	cset	w20, eq
1014436a8: 14000057    	b	0x101443804 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2358>
1014436ac: f940dff9    	ldr	x25, [sp, #0x1b8]
1014436b0: b40005d4    	cbz	x20, 0x101443768 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x22bc>
1014436b4: 91002336    	add	x22, x25, #0x8
1014436b8: 14000004    	b	0x1014436c8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x221c>
1014436bc: 910062d6    	add	x22, x22, #0x18
1014436c0: f1000694    	subs	x20, x20, #0x1
1014436c4: 54000520    	b.eq	0x101443768 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x22bc>
1014436c8: f85f82c1    	ldur	x1, [x22, #-0x8]
1014436cc: b4ffff81    	cbz	x1, 0x1014436bc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2210>
1014436d0: f94002c0    	ldr	x0, [x22]
1014436d4: 52800022    	mov	w2, #0x1                ; =1
1014436d8: 97d96c01    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014436dc: 17fffff8    	b	0x1014436bc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2210>
1014436e0: f940e3e8    	ldr	x8, [sp, #0x1c0]
1014436e4: b40039e8    	cbz	x8, 0x101443e20 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2974>
1014436e8: f940dfe0    	ldr	x0, [sp, #0x1b8]
1014436ec: d10363a8    	sub	x8, x29, #0xd8
1014436f0: 940f2eb7    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1014436f4: 910443f4    	add	x20, sp, #0x110
1014436f8: 3cd283a0    	ldur	q0, [x29, #-0xd8]
1014436fc: 3d801680    	str	q0, [x20, #0x50]
101443700: f85383a8    	ldur	x8, [x29, #-0xc8]
101443704: f900bbe8    	str	x8, [sp, #0x170]
101443708: f94027f6    	ldr	x22, [sp, #0x48]
10144370c: f94002c1    	ldr	x1, [x22]
101443710: f240f83f    	tst	x1, #0x7fffffffffffffff
101443714: 54000080    	b.eq	0x101443724 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2278>
101443718: f9403b00    	ldr	x0, [x24, #0x70]
10144371c: 52800022    	mov	w2, #0x1                ; =1
101443720: 97d96bef    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443724: 3dc01680    	ldr	q0, [x20, #0x50]
101443728: 3d8002c0    	str	q0, [x22]
10144372c: f940bbe8    	ldr	x8, [sp, #0x170]
101443730: f9000ac8    	str	x8, [x22, #0x10]
101443734: a95bd3f9    	ldp	x25, x20, [sp, #0x1b8]
101443738: b4000194    	cbz	x20, 0x101443768 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x22bc>
10144373c: 91002336    	add	x22, x25, #0x8
101443740: 14000004    	b	0x101443750 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x22a4>
101443744: 910062d6    	add	x22, x22, #0x18
101443748: f1000694    	subs	x20, x20, #0x1
10144374c: 540000e0    	b.eq	0x101443768 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x22bc>
101443750: f85f82c1    	ldur	x1, [x22, #-0x8]
101443754: b4ffff81    	cbz	x1, 0x101443744 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2298>
101443758: f94002c0    	ldr	x0, [x22]
10144375c: 52800022    	mov	w2, #0x1                ; =1
101443760: 97d96bdf    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443764: 17fffff8    	b	0x101443744 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2298>
101443768: f940dbe8    	ldr	x8, [sp, #0x1b0]
10144376c: b4ff4a48    	cbz	x8, 0x1014420b4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xc08>
101443770: 8b080508    	add	x8, x8, x8, lsl #1
101443774: d37df101    	lsl	x1, x8, #3
101443778: aa1903e0    	mov	x0, x25
10144377c: 52800102    	mov	w2, #0x8                ; =8
101443780: 97d96bd7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443784: a9494ff5    	ldp	x21, x19, [sp, #0x90]
101443788: 17fffa4b    	b	0x1014420b4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0xc08>
10144378c: f1003ebf    	cmp	x21, #0xf
101443790: 540001a3    	b.lo	0x1014437c4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2318>
101443794: d00044e2    	adrp	x2, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
101443798: 912fa442    	add	x2, x2, #0xbe9
10144379c: d10363a8    	sub	x8, x29, #0xd8
1014437a0: aa1303e0    	mov	x0, x19
1014437a4: aa1503e1    	mov	x1, x21
1014437a8: 528001c3    	mov	w3, #0xe                ; =14
1014437ac: 940f8280    	bl	0x1018241ac <__ZN4core3str7pattern11StrSearcher3new17hb0ec4e7243414bb1E>
1014437b0: 910583e0    	add	x0, sp, #0x160
1014437b4: d10363a1    	sub	x1, x29, #0xd8
1014437b8: 9400a3a0    	bl	0x10146c638 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xf08>
1014437bc: b94163f4    	ldr	w20, [sp, #0x160]
1014437c0: 14000011    	b	0x101443804 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2358>
1014437c4: f1003abf    	cmp	x21, #0xe
1014437c8: 540001c1    	b.ne	0x101443800 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2354>
1014437cc: f9400268    	ldr	x8, [x19]
1014437d0: f8406269    	ldur	x9, [x19, #0x6]
1014437d4: d28eac2a    	mov	x10, #0x7561            ; =30049
1014437d8: f2ad0e8a    	movk	x10, #0x6874, lsl #16
1014437dc: f2ce4dea    	movk	x10, #0x726f, lsl #32
1014437e0: f2ef4d2a    	movk	x10, #0x7a69, lsl #48
1014437e4: eb0a011f    	cmp	x8, x10
1014437e8: d28f4d28    	mov	x8, #0x7a69             ; =31337
1014437ec: f2ae8c28    	movk	x8, #0x7461, lsl #16
1014437f0: f2cded28    	movk	x8, #0x6f69, lsl #32
1014437f4: f2e74dc8    	movk	x8, #0x3a6e, lsl #48
1014437f8: fa480120    	ccmp	x9, x8, #0x0, eq
1014437fc: 17ffffaa    	b	0x1014436a4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x21f8>
101443800: 52800014    	mov	w20, #0x0               ; =0
101443804: f940dbe1    	ldr	x1, [sp, #0x1b0]
101443808: b4000081    	cbz	x1, 0x101443818 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x236c>
10144380c: aa1303e0    	mov	x0, x19
101443810: 52800022    	mov	w2, #0x1                ; =1
101443814: 97d96bb2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443818: b40001b6    	cbz	x22, 0x10144384c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x23a0>
10144381c: f9401be8    	ldr	x8, [sp, #0x30]
101443820: 91002113    	add	x19, x8, #0x8
101443824: 14000004    	b	0x101443834 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2388>
101443828: 91006273    	add	x19, x19, #0x18
10144382c: f10006d6    	subs	x22, x22, #0x1
101443830: 540000e0    	b.eq	0x10144384c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x23a0>
101443834: f85f8261    	ldur	x1, [x19, #-0x8]
101443838: b4ffff81    	cbz	x1, 0x101443828 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x237c>
10144383c: f9400260    	ldr	x0, [x19]
101443840: 52800022    	mov	w2, #0x1                ; =1
101443844: 97d96ba6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443848: 17fffff8    	b	0x101443828 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x237c>
10144384c: f9408be8    	ldr	x8, [sp, #0x110]
101443850: b40000c8    	cbz	x8, 0x101443868 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x23bc>
101443854: 8b080508    	add	x8, x8, x8, lsl #1
101443858: d37df101    	lsl	x1, x8, #3
10144385c: f9401be0    	ldr	x0, [sp, #0x30]
101443860: 52800102    	mov	w2, #0x8                ; =8
101443864: 97d96b9e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443868: 370019d4    	tbnz	w20, #0x0, 0x101443ba0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x26f4>
10144386c: 9102e3e8    	add	x8, sp, #0xb8
101443870: b0007136    	adrp	x22, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101443874: 9126c2d6    	add	x22, x22, #0x9b0
101443878: a9145be8    	stp	x8, x22, [sp, #0x140]
10144387c: 910343e8    	add	x8, sp, #0xd0
101443880: a9155be8    	stp	x8, x22, [sp, #0x150]
101443884: aa1803f3    	mov	x19, x24
101443888: f84b0e68    	ldr	x8, [x19, #0xb0]!
10144388c: b5002848    	cbnz	x8, 0x101443d94 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x28e8>
101443890: 92800008    	mov	x8, #-0x1               ; =-1
101443894: f9005b08    	str	x8, [x24, #0xb0]
101443898: f00044e2    	adrp	x2, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10144389c: 9103d842    	add	x2, x2, #0xf6
1014438a0: d10363a8    	sub	x8, x29, #0xd8
1014438a4: 9102e300    	add	x0, x24, #0xb8
1014438a8: aa1303e1    	mov	x1, x19
1014438ac: 528009e3    	mov	w3, #0x4f               ; =79
1014438b0: 52800004    	mov	w4, #0x0                ; =0
1014438b4: 94017254    	bl	0x1014a0204 <__ZN8rusqlite16inner_connection15InnerConnection7prepare17h05de24fc7a518314E>
1014438b8: 910443e9    	add	x9, sp, #0x110
1014438bc: d2800274    	mov	x20, #0x13              ; =19
1014438c0: f2f00014    	movk	x20, #0x8000, lsl #48
1014438c4: f9400268    	ldr	x8, [x19]
1014438c8: 91000508    	add	x8, x8, #0x1
1014438cc: f9000268    	str	x8, [x19]
1014438d0: ad470520    	ldp	q0, q1, [x9, #0xe0]
1014438d4: ad050520    	stp	q0, q1, [x9, #0xa0]
1014438d8: f85283a3    	ldur	x3, [x29, #-0xd8]
1014438dc: f85503a8    	ldur	x8, [x29, #-0xb0]
1014438e0: f900ebe8    	str	x8, [sp, #0x1d0]
1014438e4: b4000683    	cbz	x3, 0x1014439b4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2508>
1014438e8: 3cd583a0    	ldur	q0, [x29, #-0xa8]
1014438ec: 3d802120    	str	q0, [x9, #0x80]
1014438f0: f85683a8    	ldur	x8, [x29, #-0x98]
1014438f4: f900d3e8    	str	x8, [sp, #0x1a0]
1014438f8: ad450520    	ldp	q0, q1, [x9, #0xa0]
1014438fc: 3c858120    	stur	q0, [x9, #0x58]
101443900: 910443fa    	add	x26, sp, #0x110
101443904: 3c868121    	stur	q1, [x9, #0x68]
101443908: f940ebe8    	ldr	x8, [sp, #0x1d0]
10144390c: f900c7e8    	str	x8, [sp, #0x188]
101443910: f900b3e3    	str	x3, [sp, #0x160]
101443914: f940cfe4    	ldr	x4, [sp, #0x198]
101443918: d10363a0    	sub	x0, x29, #0xd8
10144391c: 910503e1    	add	x1, sp, #0x140
101443920: 52800042    	mov	w2, #0x2                ; =2
101443924: 97fee7fd    	bl	0x1013fd918 <__ZN7bincode6config3int17cast_u64_to_usize17hdd90f9a911882862E+0xa4>
101443928: f85283b7    	ldur	x23, [x29, #-0xd8]
10144392c: eb1402ff    	cmp	x23, x20
101443930: 540004e1    	b.ne	0x1014439cc <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2520>
101443934: 910583e8    	add	x8, sp, #0x160
101443938: d103a3b9    	sub	x25, x29, #0xe8
10144393c: a931ffa8    	stp	x8, xzr, [x29, #-0xe8]
101443940: d10363a0    	sub	x0, x29, #0xd8
101443944: d103a3a1    	sub	x1, x29, #0xe8
101443948: 9400c699    	bl	0x1014753ac <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x801c>
10144394c: f85283b7    	ldur	x23, [x29, #-0xd8]
101443950: eb1402ff    	cmp	x23, x20
101443954: 54000481    	b.ne	0x1014439e4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2538>
101443958: f85203b5    	ldur	x21, [x29, #-0xe0]
10144395c: b4000535    	cbz	x21, 0x101443a00 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2554>
101443960: d10363a0    	sub	x0, x29, #0xd8
101443964: aa1503e1    	mov	x1, x21
101443968: d2800002    	mov	x2, #0x0                ; =0
10144396c: 9400c49a    	bl	0x101474bd4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x7844>
101443970: f85283b7    	ldur	x23, [x29, #-0xd8]
101443974: fc5303a8    	ldur	d8, [x29, #-0xd0]
101443978: eb1402ff    	cmp	x23, x20
10144397c: 54001f21    	b.ne	0x101443d60 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x28b4>
101443980: d10363a0    	sub	x0, x29, #0xd8
101443984: aa1503e1    	mov	x1, x21
101443988: 52800022    	mov	w2, #0x1                ; =1
10144398c: 9400c326    	bl	0x101474624 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x7294>
101443990: a972a3b7    	ldp	x23, x8, [x29, #-0xd8]
101443994: eb1402ff    	cmp	x23, x20
101443998: 54001f21    	b.ne	0x101443d7c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x28d0>
10144399c: fd008fe8    	str	d8, [sp, #0x118]
1014439a0: f90093e8    	str	x8, [sp, #0x120]
1014439a4: d2800277    	mov	x23, #0x13              ; =19
1014439a8: f2f00017    	movk	x23, #0x8000, lsl #48
1014439ac: f9008bf4    	str	x20, [sp, #0x110]
1014439b0: 1400001c    	b	0x101443a20 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2574>
1014439b4: ad450520    	ldp	q0, q1, [x9, #0xa0]
1014439b8: ad000520    	stp	q0, q1, [x9]
1014439bc: f940ebe8    	ldr	x8, [sp, #0x1d0]
1014439c0: f9009be8    	str	x8, [sp, #0x130]
1014439c4: f9408bf7    	ldr	x23, [sp, #0x110]
1014439c8: 1400001a    	b	0x101443a30 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2584>
1014439cc: 910443e8    	add	x8, sp, #0x110
1014439d0: ad470101    	ldp	q1, q0, [x8, #0xe0]
1014439d4: 3c818100    	stur	q0, [x8, #0x18]
1014439d8: f9008bf7    	str	x23, [sp, #0x110]
1014439dc: 3c808101    	stur	q1, [x8, #0x8]
1014439e0: 14000012    	b	0x101443a28 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x257c>
1014439e4: f85303a8    	ldur	x8, [x29, #-0xd0]
1014439e8: 3cd383a0    	ldur	q0, [x29, #-0xc8]
1014439ec: 910443ea    	add	x10, sp, #0x110
1014439f0: 3d802940    	str	q0, [x10, #0xa0]
1014439f4: f85483a9    	ldur	x9, [x29, #-0xb8]
1014439f8: f900e3e9    	str	x9, [sp, #0x1c0]
1014439fc: 14000004    	b	0x101443a0c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2560>
101443a00: 91002328    	add	x8, x25, #0x8
101443a04: d1002a97    	sub	x23, x20, #0xa
101443a08: 910443ea    	add	x10, sp, #0x110
101443a0c: a91123f7    	stp	x23, x8, [sp, #0x110]
101443a10: 3dc02940    	ldr	q0, [x10, #0xa0]
101443a14: 3d800540    	str	q0, [x10, #0x10]
101443a18: f940e3e8    	ldr	x8, [sp, #0x1c0]
101443a1c: f9009be8    	str	x8, [sp, #0x130]
101443a20: d103a3a0    	sub	x0, x29, #0xe8
101443a24: 94003d56    	bl	0x101452f7c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5af4>
101443a28: 910583e0    	add	x0, sp, #0x160
101443a2c: 94003fab    	bl	0x1014538d8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6450>
101443a30: eb1402ff    	cmp	x23, x20
101443a34: 540000a1    	b.ne	0x101443a48 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x259c>
101443a38: fd408fe8    	ldr	d8, [sp, #0x118]
101443a3c: f94093e9    	ldr	x9, [sp, #0x120]
101443a40: 52800028    	mov	w8, #0x1                ; =1
101443a44: 14000015    	b	0x101443a98 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x25ec>
101443a48: d1002a88    	sub	x8, x20, #0xa
101443a4c: eb0802ff    	cmp	x23, x8
101443a50: 540000a1    	b.ne	0x101443a64 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x25b8>
101443a54: 910443e0    	add	x0, sp, #0x110
101443a58: 94003eb7    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
101443a5c: d2800008    	mov	x8, #0x0                ; =0
101443a60: 1400000e    	b	0x101443a98 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x25ec>
101443a64: 910443e8    	add	x8, sp, #0x110
101443a68: ad400500    	ldp	q0, q1, [x8]
101443a6c: ad0707e0    	stp	q0, q1, [sp, #0xe0]
101443a70: f9409be8    	ldr	x8, [sp, #0x130]
101443a74: f90083e8    	str	x8, [sp, #0x100]
101443a78: f94073e8    	ldr	x8, [sp, #0xe0]
101443a7c: eb14011f    	cmp	x8, x20
101443a80: 54000621    	b.ne	0x101443b44 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2698>
101443a84: f94077e8    	ldr	x8, [sp, #0xe8]
101443a88: f100091f    	cmp	x8, #0x2
101443a8c: 54000600    	b.eq	0x101443b4c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x26a0>
101443a90: fd407be8    	ldr	d8, [sp, #0xf0]
101443a94: f9407fe9    	ldr	x9, [sp, #0xf8]
101443a98: 360005a8    	tbz	w8, #0x0, 0x101443b4c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x26a0>
101443a9c: f9402fe8    	ldr	x8, [sp, #0x58]
101443aa0: cb090108    	sub	x8, x8, x9
101443aa4: 9e620100    	scvtf	d0, x8
101443aa8: d2c40008    	mov	x8, #0x200000000000     ; =35184372088832
101443aac: f2e81588    	movk	x8, #0x40ac, lsl #48
101443ab0: 9e670101    	fmov	d1, x8
101443ab4: 1e611800    	fdiv	d0, d0, d1
101443ab8: 2f00e401    	movi	d1, #0000000000000000
101443abc: 1e616800    	fmaxnm	d0, d0, d1
101443ac0: d2d00008    	mov	x8, #0x800000000000     ; =140737488355328
101443ac4: f2e810c8    	movk	x8, #0x4086, lsl #48
101443ac8: 9e670101    	fmov	d1, x8
101443acc: 1e617801    	fminnm	d1, d0, d1
101443ad0: b203e7e8    	mov	x8, #0x6666666666666666 ; =7378697629483820646
101443ad4: f2e7fdc8    	movk	x8, #0x3fee, lsl #48
101443ad8: 9e670100    	fmov	d0, x8
101443adc: 941a18f2    	bl	0x101ac9ea4 <_writev+0x101ac9ea4>
101443ae0: 1e600900    	fmul	d0, d8, d0
101443ae4: 1e6e1001    	fmov	d1, #1.00000000
101443ae8: 1e612800    	fadd	d0, d0, d1
101443aec: fd00dbe0    	str	d0, [sp, #0x1b0]
101443af0: 9106c3e8    	add	x8, sp, #0x1b0
101443af4: d0007129    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101443af8: 91186129    	add	x9, x9, #0x618
101443afc: a932a7a8    	stp	x8, x9, [x29, #-0xd8]
101443b00: 910323e8    	add	x8, sp, #0xc8
101443b04: b0007129    	adrp	x9, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101443b08: 9127c129    	add	x9, x9, #0x9f0
101443b0c: a933a7a8    	stp	x8, x9, [x29, #-0xc8]
101443b10: 9102e3e8    	add	x8, sp, #0xb8
101443b14: a934dba8    	stp	x8, x22, [x29, #-0xb8]
101443b18: 910343e8    	add	x8, sp, #0xd0
101443b1c: a935dba8    	stp	x8, x22, [x29, #-0xa8]
101443b20: f00044e2    	adrp	x2, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
101443b24: 91067042    	add	x2, x2, #0x19c
101443b28: 910583e0    	add	x0, sp, #0x160
101443b2c: d10363a4    	sub	x4, x29, #0xd8
101443b30: aa1303e1    	mov	x1, x19
101443b34: 52800ac3    	mov	w3, #0x56               ; =86
101443b38: 52800085    	mov	w5, #0x4                ; =4
101443b3c: 9400c00d    	bl	0x101473b70 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x67e0>
101443b40: 14000013    	b	0x101443b8c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x26e0>
101443b44: 910383e0    	add	x0, sp, #0xe0
101443b48: 94003e7b    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
101443b4c: 9102e3e8    	add	x8, sp, #0xb8
101443b50: a932dba8    	stp	x8, x22, [x29, #-0xd8]
101443b54: 910343e8    	add	x8, sp, #0xd0
101443b58: a933dba8    	stp	x8, x22, [x29, #-0xc8]
101443b5c: 910323e8    	add	x8, sp, #0xc8
101443b60: b0007129    	adrp	x9, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101443b64: 9127c129    	add	x9, x9, #0x9f0
101443b68: a934a7a8    	stp	x8, x9, [x29, #-0xb8]
101443b6c: f00044e2    	adrp	x2, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
101443b70: 91051442    	add	x2, x2, #0x145
101443b74: 910583e0    	add	x0, sp, #0x160
101443b78: d10363a4    	sub	x4, x29, #0xd8
101443b7c: aa1303e1    	mov	x1, x19
101443b80: 52800ae3    	mov	w3, #0x57               ; =87
101443b84: 52800065    	mov	w5, #0x3                ; =3
101443b88: 9400bffa    	bl	0x101473b70 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x67e0>
101443b8c: f940b3e8    	ldr	x8, [sp, #0x160]
101443b90: eb14011f    	cmp	x8, x20
101443b94: 54000060    	b.eq	0x101443ba0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x26f4>
101443b98: 910583e0    	add	x0, sp, #0x160
101443b9c: 94003e66    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
101443ba0: f940a713    	ldr	x19, [x24, #0x148]
101443ba4: 91000668    	add	x8, x19, #0x1
101443ba8: f900a708    	str	x8, [x24, #0x148]
101443bac: b400045b    	cbz	x27, 0x101443c34 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2788>
101443bb0: 97d96ad0    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101443bb4: aa1b03e0    	mov	x0, x27
101443bb8: 52800021    	mov	w1, #0x1                ; =1
101443bbc: 97d96ac7    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101443bc0: aa0003f9    	mov	x25, x0
101443bc4: b4000f80    	cbz	x0, 0x101443db4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2908>
101443bc8: aa1903e0    	mov	x0, x25
101443bcc: f9403be1    	ldr	x1, [sp, #0x70]
101443bd0: aa1b03e2    	mov	x2, x27
101443bd4: 941a1815    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101443bd8: f94037f4    	ldr	x20, [sp, #0x68]
101443bdc: b40003b4    	cbz	x20, 0x101443c50 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x27a4>
101443be0: 97d96ac4    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101443be4: aa1403e0    	mov	x0, x20
101443be8: 52800021    	mov	w1, #0x1                ; =1
101443bec: 97d96abb    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101443bf0: aa0003fb    	mov	x27, x0
101443bf4: b4000e80    	cbz	x0, 0x101443dc4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2918>
101443bf8: aa1b03e0    	mov	x0, x27
101443bfc: f9403fe1    	ldr	x1, [sp, #0x78]
101443c00: aa1403e2    	mov	x2, x20
101443c04: 941a1809    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101443c08: b400031c    	cbz	x28, 0x101443c68 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x27bc>
101443c0c: 97d96ab9    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101443c10: aa1c03e0    	mov	x0, x28
101443c14: 52800021    	mov	w1, #0x1                ; =1
101443c18: 97d96ab0    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101443c1c: aa0003f5    	mov	x21, x0
101443c20: b5000260    	cbnz	x0, 0x101443c6c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x27c0>
101443c24: 52800020    	mov	w0, #0x1                ; =1
101443c28: aa1c03e1    	mov	x1, x28
101443c2c: 9419fdd2    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101443c30: 14000089    	b	0x101443e54 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x29a8>
101443c34: 52800039    	mov	w25, #0x1               ; =1
101443c38: aa1903e0    	mov	x0, x25
101443c3c: f9403be1    	ldr	x1, [sp, #0x70]
101443c40: aa1b03e2    	mov	x2, x27
101443c44: 941a17f9    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101443c48: f94037f4    	ldr	x20, [sp, #0x68]
101443c4c: b5fffcb4    	cbnz	x20, 0x101443be0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2734>
101443c50: 5280003b    	mov	w27, #0x1               ; =1
101443c54: aa1b03e0    	mov	x0, x27
101443c58: f9403fe1    	ldr	x1, [sp, #0x78]
101443c5c: aa1403e2    	mov	x2, x20
101443c60: 941a17f2    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101443c64: b5fffd5c    	cbnz	x28, 0x101443c0c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2760>
101443c68: 52800035    	mov	w21, #0x1               ; =1
101443c6c: aa1503e0    	mov	x0, x21
101443c70: f94033e1    	ldr	x1, [sp, #0x60]
101443c74: aa1c03e2    	mov	x2, x28
101443c78: 941a17ec    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101443c7c: f9400f01    	ldr	x1, [x24, #0x18]
101443c80: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101443c84: eb08003f    	cmp	x1, x8
101443c88: 540001e0    	b.eq	0x101443cc4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2818>
101443c8c: b4000081    	cbz	x1, 0x101443c9c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x27f0>
101443c90: f9401300    	ldr	x0, [x24, #0x20]
101443c94: 52800022    	mov	w2, #0x1                ; =1
101443c98: 97d96a91    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443c9c: f9401b01    	ldr	x1, [x24, #0x30]
101443ca0: b4000081    	cbz	x1, 0x101443cb0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2804>
101443ca4: f9401f00    	ldr	x0, [x24, #0x38]
101443ca8: 52800022    	mov	w2, #0x1                ; =1
101443cac: 97d96a8c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443cb0: f9402701    	ldr	x1, [x24, #0x48]
101443cb4: b4000081    	cbz	x1, 0x101443cc4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2818>
101443cb8: f9402b00    	ldr	x0, [x24, #0x50]
101443cbc: 52800022    	mov	w2, #0x1                ; =1
101443cc0: 97d96a87    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443cc4: f94027e9    	ldr	x9, [sp, #0x48]
101443cc8: a901e709    	stp	x9, x25, [x24, #0x18]
101443ccc: f94037e8    	ldr	x8, [sp, #0x68]
101443cd0: a902a309    	stp	x9, x8, [x24, #0x28]
101443cd4: a903a31b    	stp	x27, x8, [x24, #0x38]
101443cd8: a904d71c    	stp	x28, x21, [x24, #0x48]
101443cdc: a905cf1c    	stp	x28, x19, [x24, #0x58]
101443ce0: f94053e1    	ldr	x1, [sp, #0xa0]
101443ce4: b4000081    	cbz	x1, 0x101443cf4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2848>
101443ce8: f94057e0    	ldr	x0, [sp, #0xa8]
101443cec: 52800022    	mov	w2, #0x1                ; =1
101443cf0: 97d96a7b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443cf4: f9401fe1    	ldr	x1, [sp, #0x38]
101443cf8: b4000081    	cbz	x1, 0x101443d08 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x285c>
101443cfc: f94023e0    	ldr	x0, [sp, #0x40]
101443d00: 52800022    	mov	w2, #0x1                ; =1
101443d04: 97d96a76    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443d08: a94957f4    	ldp	x20, x21, [sp, #0x90]
101443d0c: b4000195    	cbz	x21, 0x101443d3c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2890>
101443d10: 91002296    	add	x22, x20, #0x8
101443d14: 14000004    	b	0x101443d24 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2878>
101443d18: 910062d6    	add	x22, x22, #0x18
101443d1c: f10006b5    	subs	x21, x21, #0x1
101443d20: 540000e0    	b.eq	0x101443d3c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2890>
101443d24: f85f82c1    	ldur	x1, [x22, #-0x8]
101443d28: b4ffff81    	cbz	x1, 0x101443d18 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x286c>
101443d2c: f94002c0    	ldr	x0, [x22]
101443d30: 52800022    	mov	w2, #0x1                ; =1
101443d34: 97d96a6a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443d38: 17fffff8    	b	0x101443d18 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x286c>
101443d3c: f94047e8    	ldr	x8, [sp, #0x88]
101443d40: b40000c8    	cbz	x8, 0x101443d58 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x28ac>
101443d44: 8b080508    	add	x8, x8, x8, lsl #1
101443d48: d37df101    	lsl	x1, x8, #3
101443d4c: aa1403e0    	mov	x0, x20
101443d50: 52800102    	mov	w2, #0x8                ; =8
101443d54: 97d96a62    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443d58: 52800020    	mov	w0, #0x1                ; =1
101443d5c: 17fff6ab    	b	0x101441808 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x35c>
101443d60: 3cd383a0    	ldur	q0, [x29, #-0xc8]
101443d64: 3d800740    	str	q0, [x26, #0x10]
101443d68: f85483a8    	ldur	x8, [x29, #-0xb8]
101443d6c: f9009be8    	str	x8, [sp, #0x130]
101443d70: f9008bf7    	str	x23, [sp, #0x110]
101443d74: fd008fe8    	str	d8, [sp, #0x118]
101443d78: 17ffff2a    	b	0x101443a20 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2574>
101443d7c: 3cd383a0    	ldur	q0, [x29, #-0xc8]
101443d80: 3d800740    	str	q0, [x26, #0x10]
101443d84: f85483a9    	ldur	x9, [x29, #-0xb8]
101443d88: f9009be9    	str	x9, [sp, #0x130]
101443d8c: a91123f7    	stp	x23, x8, [sp, #0x110]
101443d90: 17ffff24    	b	0x101443a20 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2574>
101443d94: f0007120    	adrp	x0, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
101443d98: 91154000    	add	x0, x0, #0x550
101443d9c: 9419fe2c    	bl	0x101ac364c <__ZN4core4cell22panic_already_borrowed17h323724f51fff7f07E>
101443da0: 1400002d    	b	0x101443e54 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x29a8>
101443da4: 52800020    	mov	w0, #0x1                ; =1
101443da8: aa1c03e1    	mov	x1, x28
101443dac: 9419fd72    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101443db0: 14000029    	b	0x101443e54 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x29a8>
101443db4: 52800020    	mov	w0, #0x1                ; =1
101443db8: aa1b03e1    	mov	x1, x27
101443dbc: 9419fd6e    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101443dc0: 14000025    	b	0x101443e54 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x29a8>
101443dc4: 52800020    	mov	w0, #0x1                ; =1
101443dc8: aa1403e1    	mov	x1, x20
101443dcc: 9419fd6a    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101443dd0: 14000021    	b	0x101443e54 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x29a8>
101443dd4: d2800002    	mov	x2, #0x0                ; =0
101443dd8: d0007128    	adrp	x8, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101443ddc: 9124c108    	add	x8, x8, #0x930
101443de0: 1400000a    	b	0x101443e08 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x295c>
101443de4: d2800002    	mov	x2, #0x0                ; =0
101443de8: 14000009    	b	0x101443e0c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2960>
101443dec: d2800002    	mov	x2, #0x0                ; =0
101443df0: d0007128    	adrp	x8, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101443df4: 91246108    	add	x8, x8, #0x918
101443df8: 14000004    	b	0x101443e08 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x295c>
101443dfc: aa1c03e3    	mov	x3, x28
101443e00: d0007128    	adrp	x8, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101443e04: 91252108    	add	x8, x8, #0x948
101443e08: f9000be8    	str	x8, [sp, #0x10]
101443e0c: aa1903e0    	mov	x0, x25
101443e10: aa1c03e1    	mov	x1, x28
101443e14: f9400be4    	ldr	x4, [sp, #0x10]
101443e18: 9419fdfc    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
101443e1c: 1400000e    	b	0x101443e54 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x29a8>
101443e20: d0007122    	adrp	x2, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101443e24: 9122e042    	add	x2, x2, #0x8b8
101443e28: d2800000    	mov	x0, #0x0                ; =0
101443e2c: d2800001    	mov	x1, #0x0                ; =0
101443e30: 9419ffc3    	bl	0x101ac3d3c <__ZN4core9panicking18panic_bounds_check17hd6142ed38f8c399dE>
101443e34: 14000008    	b	0x101443e54 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x29a8>
101443e38: d0007124    	adrp	x4, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101443e3c: 9117c084    	add	x4, x4, #0x5f0
101443e40: aa1903e0    	mov	x0, x25
101443e44: aa1503e1    	mov	x1, x21
101443e48: 52800042    	mov	w2, #0x2                ; =2
101443e4c: aa1503e3    	mov	x3, x21
101443e50: 9419fdee    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
101443e54: d4200020    	brk	#0x1
101443e58: 14000040    	b	0x101443f58 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2aac>
101443e5c: aa0003f5    	mov	x21, x0
101443e60: d103a3a0    	sub	x0, x29, #0xe8
101443e64: 94003c46    	bl	0x101452f7c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5af4>
101443e68: 14000009    	b	0x101443e8c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x29e0>
101443e6c: 9419ffae    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101443e70: aa0003f5    	mov	x21, x0
101443e74: f940dbe1    	ldr	x1, [sp, #0x1b0]
101443e78: b4000721    	cbz	x1, 0x101443f5c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2ab0>
101443e7c: aa1303e0    	mov	x0, x19
101443e80: 14000015    	b	0x101443ed4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2a28>
101443e84: 14000010    	b	0x101443ec4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2a18>
101443e88: aa0003f5    	mov	x21, x0
101443e8c: 910583e0    	add	x0, sp, #0x160
101443e90: 94003e92    	bl	0x1014538d8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6450>
101443e94: 1400005e    	b	0x10144400c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b60>
101443e98: 9419ffa3    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101443e9c: aa0003f5    	mov	x21, x0
101443ea0: f9400268    	ldr	x8, [x19]
101443ea4: 91000508    	add	x8, x8, #0x1
101443ea8: f9000268    	str	x8, [x19]
101443eac: 14000058    	b	0x10144400c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b60>
101443eb0: aa0003f5    	mov	x21, x0
101443eb4: f940b3e1    	ldr	x1, [sp, #0x160]
101443eb8: b4000aa1    	cbz	x1, 0x10144400c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b60>
101443ebc: f940b7e0    	ldr	x0, [sp, #0x168]
101443ec0: 1400001b    	b	0x101443f2c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2a80>
101443ec4: aa0003f5    	mov	x21, x0
101443ec8: f940dbe1    	ldr	x1, [sp, #0x1b0]
101443ecc: b4000481    	cbz	x1, 0x101443f5c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2ab0>
101443ed0: f9402be0    	ldr	x0, [sp, #0x50]
101443ed4: 52800022    	mov	w2, #0x1                ; =1
101443ed8: 97d96a01    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443edc: 14000020    	b	0x101443f5c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2ab0>
101443ee0: aa0003f5    	mov	x21, x0
101443ee4: aa1703e0    	mov	x0, x23
101443ee8: aa1c03e1    	mov	x1, x28
101443eec: 52800022    	mov	w2, #0x1                ; =1
101443ef0: 97d969fb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443ef4: 14000020    	b	0x101443f74 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2ac8>
101443ef8: aa0003f5    	mov	x21, x0
101443efc: f94037e8    	ldr	x8, [sp, #0x68]
101443f00: b40000e8    	cbz	x8, 0x101443f1c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2a70>
101443f04: aa1b03e0    	mov	x0, x27
101443f08: f94037e1    	ldr	x1, [sp, #0x68]
101443f0c: 52800022    	mov	w2, #0x1                ; =1
101443f10: 97d969f3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443f14: 14000002    	b	0x101443f1c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2a70>
101443f18: aa0003f5    	mov	x21, x0
101443f1c: f94027e8    	ldr	x8, [sp, #0x48]
101443f20: b4000768    	cbz	x8, 0x10144400c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b60>
101443f24: aa1903e0    	mov	x0, x25
101443f28: f94027e1    	ldr	x1, [sp, #0x48]
101443f2c: 52800022    	mov	w2, #0x1                ; =1
101443f30: 97d969eb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443f34: 14000036    	b	0x10144400c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b60>
101443f38: 1400000e    	b	0x101443f70 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2ac4>
101443f3c: aa0003f5    	mov	x21, x0
101443f40: 910223e0    	add	x0, sp, #0x88
101443f44: 97d3faf2    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101443f48: aa1503e0    	mov	x0, x21
101443f4c: 941a15a2    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101443f50: aa0003f5    	mov	x21, x0
101443f54: 14000033    	b	0x101444020 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b74>
101443f58: aa0003f5    	mov	x21, x0
101443f5c: 910443e0    	add	x0, sp, #0x110
101443f60: 97d3faeb    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101443f64: 1400002a    	b	0x10144400c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b60>
101443f68: 14000002    	b	0x101443f70 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2ac4>
101443f6c: 14000001    	b	0x101443f70 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2ac4>
101443f70: aa0003f5    	mov	x21, x0
101443f74: 9106c3e0    	add	x0, sp, #0x1b0
101443f78: 97d3fae5    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101443f7c: 14000024    	b	0x10144400c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b60>
101443f80: 14000022    	b	0x101444008 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b5c>
101443f84: aa0003f5    	mov	x21, x0
101443f88: f9408be1    	ldr	x1, [sp, #0x110]
101443f8c: b4000121    	cbz	x1, 0x101443fb0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b04>
101443f90: 14000019    	b	0x101443ff4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b48>
101443f94: aa0003f5    	mov	x21, x0
101443f98: f940b3e8    	ldr	x8, [sp, #0x160]
101443f9c: b50000e8    	cbnz	x8, 0x101443fb8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b0c>
101443fa0: f940dbe1    	ldr	x1, [sp, #0x1b0]
101443fa4: b50001e1    	cbnz	x1, 0x101443fe0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b34>
101443fa8: f9408be1    	ldr	x1, [sp, #0x110]
101443fac: b5000241    	cbnz	x1, 0x101443ff4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b48>
101443fb0: aa1503e0    	mov	x0, x21
101443fb4: 941a1588    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101443fb8: f940b7e0    	ldr	x0, [sp, #0x168]
101443fbc: d37ef501    	lsl	x1, x8, #2
101443fc0: 52800082    	mov	w2, #0x4                ; =4
101443fc4: 97d969c6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443fc8: f940dbe1    	ldr	x1, [sp, #0x1b0]
101443fcc: b4fffee1    	cbz	x1, 0x101443fa8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2afc>
101443fd0: 14000004    	b	0x101443fe0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b34>
101443fd4: aa0003f5    	mov	x21, x0
101443fd8: f940dbe1    	ldr	x1, [sp, #0x1b0]
101443fdc: b4fffe61    	cbz	x1, 0x101443fa8 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2afc>
101443fe0: aa1903e0    	mov	x0, x25
101443fe4: 52800022    	mov	w2, #0x1                ; =1
101443fe8: 97d969bd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101443fec: f9408be1    	ldr	x1, [sp, #0x110]
101443ff0: b4fffe01    	cbz	x1, 0x101443fb0 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b04>
101443ff4: aa1303e0    	mov	x0, x19
101443ff8: 52800022    	mov	w2, #0x1                ; =1
101443ffc: 97d969b8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101444000: aa1503e0    	mov	x0, x21
101444004: 941a1574    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101444008: aa0003f5    	mov	x21, x0
10144400c: f94053e1    	ldr	x1, [sp, #0xa0]
101444010: b4000081    	cbz	x1, 0x101444020 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b74>
101444014: f94057e0    	ldr	x0, [sp, #0xa8]
101444018: 52800022    	mov	w2, #0x1                ; =1
10144401c: 97d969b0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101444020: f9401fe8    	ldr	x8, [sp, #0x38]
101444024: b4000088    	cbz	x8, 0x101444034 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2b88>
101444028: a94383e1    	ldp	x1, x0, [sp, #0x38]
10144402c: 52800022    	mov	w2, #0x1                ; =1
101444030: 97d969ab    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101444034: 910223e0    	add	x0, sp, #0x88
101444038: 97d3fab5    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10144403c: aa1503e0    	mov	x0, x21
101444040: 941a1565    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101444044: d10443ff    	sub	sp, sp, #0x110
101444048: 6d0d23e9    	stp	d9, d8, [sp, #0xd0]
10144404c: a90e6ffc    	stp	x28, x27, [sp, #0xe0]
101444050: a90f4ff4    	stp	x20, x19, [sp, #0xf0]
101444054: a9107bfd    	stp	x29, x30, [sp, #0x100]
101444058: 910403fd    	add	x29, sp, #0x100
10144405c: aa0503f4    	mov	x20, x5
101444060: aa0403e5    	mov	x5, x4
101444064: aa0303e4    	mov	x4, x3
101444068: aa0203e3    	mov	x3, x2
10144406c: aa0103e2    	mov	x2, x1
101444070: aa0003f3    	mov	x19, x0
101444074: a9008fe1    	stp	x1, x3, [sp, #0x8]
101444078: a90197e4    	stp	x4, x5, [sp, #0x18]
10144407c: f90017f4    	str	x20, [sp, #0x28]
101444080: d101a3a0    	sub	x0, x29, #0x68
101444084: aa1303e1    	mov	x1, x19
101444088: 940001e3    	bl	0x101444814 <__ZN17otty_autocomplete7history14CommandHistory9clear_all17ha96dfef39a2aea48E+0x198>
10144408c: b85983a8    	ldur	w8, [x29, #-0x68]
101444090: 7100051f    	cmp	w8, #0x1
101444094: 540006a1    	b.ne	0x101444168 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2cbc>
101444098: fc5a03a8    	ldur	d8, [x29, #-0x60]
10144409c: f85a83a8    	ldur	x8, [x29, #-0x58]
1014440a0: cb080288    	sub	x8, x20, x8
1014440a4: 9e620100    	scvtf	d0, x8
1014440a8: d2c40008    	mov	x8, #0x200000000000     ; =35184372088832
1014440ac: f2e81588    	movk	x8, #0x40ac, lsl #48
1014440b0: 9e670101    	fmov	d1, x8
1014440b4: 1e611800    	fdiv	d0, d0, d1
1014440b8: 2f00e401    	movi	d1, #0000000000000000
1014440bc: 1e616800    	fmaxnm	d0, d0, d1
1014440c0: d2d00008    	mov	x8, #0x800000000000     ; =140737488355328
1014440c4: f2e810c8    	movk	x8, #0x4086, lsl #48
1014440c8: 9e670101    	fmov	d1, x8
1014440cc: 1e617801    	fminnm	d1, d0, d1
1014440d0: b203e7e8    	mov	x8, #0x6666666666666666 ; =7378697629483820646
1014440d4: f2e7fdc8    	movk	x8, #0x3fee, lsl #48
1014440d8: 9e670100    	fmov	d0, x8
1014440dc: 941a1772    	bl	0x101ac9ea4 <_writev+0x101ac9ea4>
1014440e0: 1e600900    	fmul	d0, d8, d0
1014440e4: 1e6e1001    	fmov	d1, #1.00000000
1014440e8: 1e612800    	fadd	d0, d0, d1
1014440ec: fc1c03a0    	stur	d0, [x29, #-0x40]
1014440f0: d10103a8    	sub	x8, x29, #0x40
1014440f4: b0007129    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
1014440f8: 91186129    	add	x9, x9, #0x618
1014440fc: a905a7e8    	stp	x8, x9, [sp, #0x58]
101444100: 9100a3e8    	add	x8, sp, #0x28
101444104: 90007129    	adrp	x9, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101444108: 9127c129    	add	x9, x9, #0x9f0
10144410c: a906a7e8    	stp	x8, x9, [sp, #0x68]
101444110: 90007128    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101444114: 9126c108    	add	x8, x8, #0x9b0
101444118: 910023e9    	add	x9, sp, #0x8
10144411c: a907a3e9    	stp	x9, x8, [sp, #0x78]
101444120: 910063e9    	add	x9, sp, #0x18
101444124: a908a3e9    	stp	x9, x8, [sp, #0x88]
101444128: d00044e2    	adrp	x2, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10144412c: 91168842    	add	x2, x2, #0x5a2
101444130: 9100c3e0    	add	x0, sp, #0x30
101444134: 9102c261    	add	x1, x19, #0xb0
101444138: 910163e4    	add	x4, sp, #0x58
10144413c: 52800ac3    	mov	w3, #0x56               ; =86
101444140: 52800085    	mov	w5, #0x4                ; =4
101444144: 9400be8b    	bl	0x101473b70 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x67e0>
101444148: f9401be8    	ldr	x8, [sp, #0x30]
10144414c: d2800269    	mov	x9, #0x13               ; =19
101444150: f2f00009    	movk	x9, #0x8000, lsl #48
101444154: eb09011f    	cmp	x8, x9
101444158: 54000360    	b.eq	0x1014441c4 <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2d18>
10144415c: 9100c3e0    	add	x0, sp, #0x30
101444160: 94003cf5    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
101444164: 1400002a    	b	0x10144420c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2d60>
101444168: 910023e8    	add	x8, sp, #0x8
10144416c: 90007129    	adrp	x9, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101444170: 9126c129    	add	x9, x9, #0x9b0
101444174: a905a7e8    	stp	x8, x9, [sp, #0x58]
101444178: 910063e8    	add	x8, sp, #0x18
10144417c: a906a7e8    	stp	x8, x9, [sp, #0x68]
101444180: 9100a3e8    	add	x8, sp, #0x28
101444184: 90007129    	adrp	x9, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101444188: 9127c129    	add	x9, x9, #0x9f0
10144418c: a907a7e8    	stp	x8, x9, [sp, #0x78]
101444190: d00044e2    	adrp	x2, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
101444194: 91152c42    	add	x2, x2, #0x54b
101444198: 9100c3e0    	add	x0, sp, #0x30
10144419c: 9102c261    	add	x1, x19, #0xb0
1014441a0: 910163e4    	add	x4, sp, #0x58
1014441a4: 52800ae3    	mov	w3, #0x57               ; =87
1014441a8: 52800065    	mov	w5, #0x3                ; =3
1014441ac: 9400be71    	bl	0x101473b70 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x67e0>
1014441b0: f9401be8    	ldr	x8, [sp, #0x30]
1014441b4: d2800269    	mov	x9, #0x13               ; =19
1014441b8: f2f00009    	movk	x9, #0x8000, lsl #48
1014441bc: eb09011f    	cmp	x8, x9
1014441c0: 54fffce1    	b.ne	0x10144415c <__ZN17otty_autocomplete7history14CommandHistory6record17h3222fa5866e61579E+0x2cb0>
1014441c4: a940a7e8    	ldp	x8, x9, [sp, #0x8]
1014441c8: a941afea    	ldp	x10, x11, [sp, #0x18]
1014441cc: a93b27a8    	stp	x8, x9, [x29, #-0x50]
1014441d0: a93c2faa    	stp	x10, x11, [x29, #-0x40]
1014441d4: f0000048    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
1014441d8: 91117108    	add	x8, x8, #0x45c
1014441dc: d10143a9    	sub	x9, x29, #0x50
1014441e0: a905a3e9    	stp	x9, x8, [sp, #0x58]
1014441e4: d10103a9    	sub	x9, x29, #0x40
1014441e8: a906a3e9    	stp	x9, x8, [sp, #0x68]
1014441ec: d0004e40    	adrp	x0, 0x101e0e000 <_writev+0x101e0e000>
1014441f0: 9110f000    	add	x0, x0, #0x43c
1014441f4: d101a3a8    	sub	x8, x29, #0x68
1014441f8: 910163e1    	add	x1, sp, #0x58
1014441fc: 940f1ce1    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
101444200: 91046260    	add	x0, x19, #0x118
101444204: d101a3a1    	sub	x1, x29, #0x68
101444208: 9400ca51    	bl	0x101476b4c <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xee0>
10144420c: a9507bfd    	ldp	x29, x30, [sp, #0x100]
101444210: a94f4ff4    	ldp	x20, x19, [sp, #0xf0]
101444214: a94e6ffc    	ldp	x28, x27, [sp, #0xe0]
101444218: 6d4d23e9    	ldp	d9, d8, [sp, #0xd0]
10144421c: 910443ff    	add	sp, sp, #0x110
101444220: d65f03c0    	ret
