
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101459a38 <__ZN4core5slice4sort6stable14driftsort_main17h09f3fb579065c468E>:
101459a38: d101c3ff    	sub	sp, sp, #0x70
101459a3c: a90267fa    	stp	x26, x25, [sp, #0x20]
101459a40: a9035ff8    	stp	x24, x23, [sp, #0x30]
101459a44: a90457f6    	stp	x22, x21, [sp, #0x40]
101459a48: a9054ff4    	stp	x20, x19, [sp, #0x50]
101459a4c: a9067bfd    	stp	x29, x30, [sp, #0x60]
101459a50: 910183fd    	add	x29, sp, #0x60
101459a54: cb410428    	sub	x8, x1, x1, lsr #1
101459a58: 52858f69    	mov	w9, #0x2c7b             ; =11387
101459a5c: 72a00029    	movk	w9, #0x1, lsl #16
101459a60: eb09003f    	cmp	x1, x9
101459a64: 9a893029    	csel	x9, x1, x9, lo
101459a68: eb08013f    	cmp	x9, x8
101459a6c: 9a888129    	csel	x9, x9, x8, hi
101459a70: 5280060a    	mov	w10, #0x30              ; =48
101459a74: f100c13f    	cmp	x9, #0x30
101459a78: 9a8a8134    	csel	x20, x9, x10, hi
101459a7c: 52800d09    	mov	w9, #0x68               ; =104
101459a80: 9b097e96    	mul	x22, x20, x9
101459a84: d2962769    	mov	x9, #0xb13b             ; =45371
101459a88: f2a76269    	movk	x9, #0x3b13, lsl #16
101459a8c: f2c27629    	movk	x9, #0x13b1, lsl #32
101459a90: f2e02769    	movk	x9, #0x13b, lsl #48
101459a94: eb09011f    	cmp	x8, x9
101459a98: 540000a9    	b.ls	0x101459aac <__ZN4core5slice4sort6stable14driftsort_main17h09f3fb579065c468E+0x74>
101459a9c: d2800017    	mov	x23, #0x0               ; =0
101459aa0: aa1703e0    	mov	x0, x23
101459aa4: aa1603e1    	mov	x1, x22
101459aa8: 9419a633    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101459aac: aa0203f3    	mov	x19, x2
101459ab0: b40001b6    	cbz	x22, 0x101459ae4 <__ZN4core5slice4sort6stable14driftsort_main17h09f3fb579065c468E+0xac>
101459ab4: aa0003f8    	mov	x24, x0
101459ab8: aa0103f9    	mov	x25, x1
101459abc: 97d9130d    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101459ac0: 52800117    	mov	w23, #0x8               ; =8
101459ac4: aa1603e0    	mov	x0, x22
101459ac8: 52800101    	mov	w1, #0x8                ; =8
101459acc: 97d91303    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101459ad0: b4fffe80    	cbz	x0, 0x101459aa0 <__ZN4core5slice4sort6stable14driftsort_main17h09f3fb579065c468E+0x68>
101459ad4: aa0003f5    	mov	x21, x0
101459ad8: aa1903e1    	mov	x1, x25
101459adc: aa1803e0    	mov	x0, x24
101459ae0: 14000003    	b	0x101459aec <__ZN4core5slice4sort6stable14driftsort_main17h09f3fb579065c468E+0xb4>
101459ae4: d2800014    	mov	x20, #0x0               ; =0
101459ae8: 52800115    	mov	w21, #0x8               ; =8
101459aec: a900d7f4    	stp	x20, x21, [sp, #0x8]
101459af0: f9000fff    	str	xzr, [sp, #0x18]
101459af4: f101043f    	cmp	x1, #0x41
101459af8: 1a9f27e4    	cset	w4, lo
101459afc: aa1503e2    	mov	x2, x21
101459b00: aa1403e3    	mov	x3, x20
101459b04: aa1303e5    	mov	x5, x19
101459b08: 94000dea    	bl	0x10145d2b0 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2bdc>
101459b0c: 52800d08    	mov	w8, #0x68               ; =104
101459b10: 9b087e81    	mul	x1, x20, x8
101459b14: aa1503e0    	mov	x0, x21
101459b18: 52800102    	mov	w2, #0x8                ; =8
101459b1c: a9467bfd    	ldp	x29, x30, [sp, #0x60]
101459b20: a9454ff4    	ldp	x20, x19, [sp, #0x50]
101459b24: a94457f6    	ldp	x22, x21, [sp, #0x40]
101459b28: a9435ff8    	ldp	x24, x23, [sp, #0x30]
101459b2c: a94267fa    	ldp	x26, x25, [sp, #0x20]
101459b30: 9101c3ff    	add	sp, sp, #0x70
101459b34: 17d912ea    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101459b38: aa0003f3    	mov	x19, x0
101459b3c: 910023e0    	add	x0, sp, #0x8
101459b40: 97fff0c9    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101459b44: aa1303e0    	mov	x0, x19
101459b48: 9419bea3    	bl	0x101ac95d4 <_writev+0x101ac95d4>
