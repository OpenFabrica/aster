
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101439004 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E>:
101439004: d10303ff    	sub	sp, sp, #0xc0
101439008: a90767fa    	stp	x26, x25, [sp, #0x70]
10143900c: a9085ff8    	stp	x24, x23, [sp, #0x80]
101439010: a90957f6    	stp	x22, x21, [sp, #0x90]
101439014: a90a4ff4    	stp	x20, x19, [sp, #0xa0]
101439018: a90b7bfd    	stp	x29, x30, [sp, #0xb0]
10143901c: 9102c3fd    	add	x29, sp, #0xb0
101439020: aa0803f6    	mov	x22, x8
101439024: b4000782    	cbz	x2, 0x101439114 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0x110>
101439028: aa0203f7    	mov	x23, x2
10143902c: aa0103f8    	mov	x24, x1
101439030: aa0003f5    	mov	x21, x0
101439034: 910043e8    	add	x8, sp, #0x10
101439038: aa0103e0    	mov	x0, x1
10143903c: 940f5864    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101439040: a94153f3    	ldp	x19, x20, [sp, #0x10]
101439044: f94013f9    	ldr	x25, [sp, #0x20]
101439048: f84d8ea8    	ldr	x8, [x21, #0xd8]!
10143904c: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101439050: eb09011f    	cmp	x8, x9
101439054: 54000580    	b.eq	0x101439104 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0x100>
101439058: aa1503e0    	mov	x0, x21
10143905c: aa1403e1    	mov	x1, x20
101439060: aa1903e2    	mov	x2, x25
101439064: 97ff9bf2    	bl	0x10142002c <__ZN17otty_autocomplete2db13CompletionsDb11lookup_spec17h895ef0a520e673c6E>
101439068: aa0003f5    	mov	x21, x0
10143906c: b40004c0    	cbz	x0, 0x101439104 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0x100>
101439070: f90007f5    	str	x21, [sp, #0x8]
101439074: 910043e0    	add	x0, sp, #0x10
101439078: 910042a1    	add	x1, x21, #0x10
10143907c: aa1803e2    	mov	x2, x24
101439080: aa1703e3    	mov	x3, x23
101439084: 52800024    	mov	w4, #0x1                ; =1
101439088: 940006fe    	bl	0x10143ac80 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x1c>
10143908c: a94363f7    	ldp	x23, x24, [sp, #0x30]
101439090: 910163e0    	add	x0, sp, #0x58
101439094: aa1403e1    	mov	x1, x20
101439098: aa1903e2    	mov	x2, x25
10143909c: aa1703e3    	mov	x3, x23
1014390a0: aa1803e4    	mov	x4, x24
1014390a4: 97ffe698    	bl	0x101432b04 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x7a4>
1014390a8: 3cc583e0    	ldur	q0, [sp, #0x58]
1014390ac: 3d8002c0    	str	q0, [x22]
1014390b0: f94037e9    	ldr	x9, [sp, #0x68]
1014390b4: f9402bea    	ldr	x10, [sp, #0x50]
1014390b8: f9400be8    	ldr	x8, [sp, #0x10]
1014390bc: a9012ac9    	stp	x9, x10, [x22, #0x10]
1014390c0: b40000a8    	cbz	x8, 0x1014390d4 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0xd0>
1014390c4: f9400fe0    	ldr	x0, [sp, #0x18]
1014390c8: d37df101    	lsl	x1, x8, #3
1014390cc: 52800102    	mov	w2, #0x8                ; =8
1014390d0: 97d99583    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014390d4: b4000398    	cbz	x24, 0x101439144 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0x140>
1014390d8: 910022f6    	add	x22, x23, #0x8
1014390dc: 14000004    	b	0x1014390ec <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0xe8>
1014390e0: 910062d6    	add	x22, x22, #0x18
1014390e4: f1000718    	subs	x24, x24, #0x1
1014390e8: 540002e0    	b.eq	0x101439144 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0x140>
1014390ec: f85f82c1    	ldur	x1, [x22, #-0x8]
1014390f0: b4ffff81    	cbz	x1, 0x1014390e0 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0xdc>
1014390f4: f94002c0    	ldr	x0, [x22]
1014390f8: 52800022    	mov	w2, #0x1                ; =1
1014390fc: 97d99578    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101439100: 17fffff8    	b	0x1014390e0 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0xdc>
101439104: a90052d3    	stp	x19, x20, [x22]
101439108: 52800028    	mov	w8, #0x1                ; =1
10143910c: a90122d9    	stp	x25, x8, [x22, #0x10]
101439110: 14000006    	b	0x101439128 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0x124>
101439114: 52800028    	mov	w8, #0x1                ; =1
101439118: a90022df    	stp	xzr, x8, [x22]
10143911c: 90003548    	adrp	x8, 0x101ae1000 <_writev+0x101ae1000>
101439120: 3dc30100    	ldr	q0, [x8, #0xc00]
101439124: 3d8006c0    	str	q0, [x22, #0x10]
101439128: a94b7bfd    	ldp	x29, x30, [sp, #0xb0]
10143912c: a94a4ff4    	ldp	x20, x19, [sp, #0xa0]
101439130: a94957f6    	ldp	x22, x21, [sp, #0x90]
101439134: a9485ff8    	ldp	x24, x23, [sp, #0x80]
101439138: a94767fa    	ldp	x26, x25, [sp, #0x70]
10143913c: 910303ff    	add	sp, sp, #0xc0
101439140: d65f03c0    	ret
101439144: f94017e8    	ldr	x8, [sp, #0x28]
101439148: b40000c8    	cbz	x8, 0x101439160 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0x15c>
10143914c: 8b080508    	add	x8, x8, x8, lsl #1
101439150: d37df101    	lsl	x1, x8, #3
101439154: aa1703e0    	mov	x0, x23
101439158: 52800102    	mov	w2, #0x8                ; =8
10143915c: 97d99560    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101439160: 92800008    	mov	x8, #-0x1               ; =-1
101439164: f86802a8    	ldaddl	x8, x8, [x21]
101439168: f100051f    	cmp	x8, #0x1
10143916c: 54000081    	b.ne	0x10143917c <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0x178>
101439170: d50339bf    	dmb	ishld
101439174: 910023e0    	add	x0, sp, #0x8
101439178: 9400c96e    	bl	0x10146b730 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E>
10143917c: b4fffd73    	cbz	x19, 0x101439128 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0x124>
101439180: aa1403e0    	mov	x0, x20
101439184: aa1303e1    	mov	x1, x19
101439188: 52800022    	mov	w2, #0x1                ; =1
10143918c: a94b7bfd    	ldp	x29, x30, [sp, #0xb0]
101439190: a94a4ff4    	ldp	x20, x19, [sp, #0xa0]
101439194: a94957f6    	ldp	x22, x21, [sp, #0x90]
101439198: a9485ff8    	ldp	x24, x23, [sp, #0x80]
10143919c: a94767fa    	ldp	x26, x25, [sp, #0x70]
1014391a0: 910303ff    	add	sp, sp, #0xc0
1014391a4: 17d9954e    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014391a8: aa0003f6    	mov	x22, x0
1014391ac: 910043e0    	add	x0, sp, #0x10
1014391b0: 94006b77    	bl	0x101453f8c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6b04>
1014391b4: 14000002    	b	0x1014391bc <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0x1b8>
1014391b8: aa0003f6    	mov	x22, x0
1014391bc: 92800008    	mov	x8, #-0x1               ; =-1
1014391c0: f86802a8    	ldaddl	x8, x8, [x21]
1014391c4: f100051f    	cmp	x8, #0x1
1014391c8: 540000e1    	b.ne	0x1014391e4 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0x1e0>
1014391cc: d50339bf    	dmb	ishld
1014391d0: 910023e0    	add	x0, sp, #0x8
1014391d4: 9400c957    	bl	0x10146b730 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E>
1014391d8: 14000003    	b	0x1014391e4 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0x1e0>
1014391dc: 941a2ad2    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014391e0: aa0003f6    	mov	x22, x0
1014391e4: b40000b3    	cbz	x19, 0x1014391f8 <__ZN17otty_autocomplete6engine6Engine15history_context17h352b2e8f99379525E+0x1f4>
1014391e8: aa1403e0    	mov	x0, x20
1014391ec: aa1303e1    	mov	x1, x19
1014391f0: 52800022    	mov	w2, #0x1                ; =1
1014391f4: 97d9953a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014391f8: aa1603e0    	mov	x0, x22
1014391fc: 941a40f6    	bl	0x101ac95d4 <_writev+0x101ac95d4>

0000000101439200 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE>:
101439200: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
101439204: a90157f6    	stp	x22, x21, [sp, #0x10]
101439208: a9024ff4    	stp	x20, x19, [sp, #0x20]
10143920c: a9037bfd    	stp	x29, x30, [sp, #0x30]
101439210: 9100c3fd    	add	x29, sp, #0x30
101439214: aa0203f3    	mov	x19, x2
101439218: aa0103f5    	mov	x21, x1
10143921c: aa0003f4    	mov	x20, x0
101439220: f941c416    	ldr	x22, [x0, #0x388]
101439224: f941c817    	ldr	x23, [x0, #0x390]
101439228: f94002e8    	ldr	x8, [x23]
10143922c: b4000068    	cbz	x8, 0x101439238 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x38>
101439230: aa1603e0    	mov	x0, x22
101439234: d63f0100    	blr	x8
101439238: f94006e1    	ldr	x1, [x23, #0x8]
10143923c: b4000081    	cbz	x1, 0x10143924c <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x4c>
101439240: f9400ae2    	ldr	x2, [x23, #0x10]
101439244: aa1603e0    	mov	x0, x22
101439248: 97d99525    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143924c: f901c695    	str	x21, [x20, #0x388]
101439250: f901ca93    	str	x19, [x20, #0x390]
101439254: a9437bfd    	ldp	x29, x30, [sp, #0x30]
101439258: a9424ff4    	ldp	x20, x19, [sp, #0x20]
10143925c: a94157f6    	ldp	x22, x21, [sp, #0x10]
101439260: a8c45ff8    	ldp	x24, x23, [sp], #0x40
101439264: d65f03c0    	ret
101439268: aa1703e9    	mov	x9, x23
10143926c: aa0003f7    	mov	x23, x0
101439270: f9400521    	ldr	x1, [x9, #0x8]
101439274: b4000081    	cbz	x1, 0x101439284 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x84>
101439278: f9400922    	ldr	x2, [x9, #0x10]
10143927c: aa1603e0    	mov	x0, x22
101439280: 97d99517    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101439284: f901c695    	str	x21, [x20, #0x388]
101439288: f901ca93    	str	x19, [x20, #0x390]
10143928c: aa1703e0    	mov	x0, x23
101439290: 941a40d1    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101439294: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
101439298: a90157f6    	stp	x22, x21, [sp, #0x10]
10143929c: a9024ff4    	stp	x20, x19, [sp, #0x20]
1014392a0: a9037bfd    	stp	x29, x30, [sp, #0x30]
1014392a4: 9100c3fd    	add	x29, sp, #0x30
1014392a8: b4000a86    	cbz	x6, 0x1014393f8 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x1f8>
1014392ac: b4000a65    	cbz	x5, 0x1014393f8 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x1f8>
1014392b0: 8b050088    	add	x8, x4, x5
1014392b4: aa0403e9    	mov	x9, x4
1014392b8: 14000004    	b	0x1014392c8 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0xc8>
1014392bc: aa0b03e9    	mov	x9, x11
1014392c0: 7100bd5f    	cmp	w10, #0x2f
1014392c4: 54000540    	b.eq	0x10143936c <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x16c>
1014392c8: eb08013f    	cmp	x9, x8
1014392cc: 540003c0    	b.eq	0x101439344 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x144>
1014392d0: aa0903eb    	mov	x11, x9
1014392d4: 38c0156c    	ldrsb	w12, [x11], #0x1
1014392d8: 12001d8a    	and	w10, w12, #0xff
1014392dc: 36ffff0c    	tbz	w12, #0x1f, 0x1014392bc <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0xbc>
1014392e0: 3940052b    	ldrb	w11, [x9, #0x1]
1014392e4: 1200156c    	and	w12, w11, #0x3f
1014392e8: 7103815f    	cmp	w10, #0xe0
1014392ec: 540001e3    	b.lo	0x101439328 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x128>
1014392f0: 1200114b    	and	w11, w10, #0x1f
1014392f4: 3940092d    	ldrb	w13, [x9, #0x2]
1014392f8: 120015ad    	and	w13, w13, #0x3f
1014392fc: 2a0c19ac    	orr	w12, w13, w12, lsl #6
101439300: 7103c15f    	cmp	w10, #0xf0
101439304: 540001a3    	b.lo	0x101439338 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x138>
101439308: 39400d2a    	ldrb	w10, [x9, #0x3]
10143930c: 1200154a    	and	w10, w10, #0x3f
101439310: 2a0c194a    	orr	w10, w10, w12, lsl #6
101439314: 330e096a    	bfi	w10, w11, #18, #3
101439318: 7144415f    	cmp	w10, #0x110, lsl #12    ; =0x110000
10143931c: 54000140    	b.eq	0x101439344 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x144>
101439320: 91001129    	add	x9, x9, #0x4
101439324: 17ffffe7    	b	0x1014392c0 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0xc0>
101439328: 91000929    	add	x9, x9, #0x2
10143932c: 331a114c    	bfi	w12, w10, #6, #5
101439330: aa0c03ea    	mov	x10, x12
101439334: 17ffffe3    	b	0x1014392c0 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0xc0>
101439338: 91000d29    	add	x9, x9, #0x3
10143933c: 2a0b318a    	orr	w10, w12, w11, lsl #12
101439340: 17ffffe0    	b	0x1014392c0 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0xc0>
101439344: 39400088    	ldrb	w8, [x4]
101439348: 7101f91f    	cmp	w8, #0x7e
10143934c: 528005c9    	mov	w9, #0x2e               ; =46
101439350: 7a491104    	ccmp	w8, w9, #0x4, ne
101439354: 1a9f17f3    	cset	w19, eq
101439358: f940d028    	ldr	x8, [x1, #0x1a0]
10143935c: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101439360: eb09011f    	cmp	x8, x9
101439364: 540000e1    	b.ne	0x101439380 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x180>
101439368: 14000018    	b	0x1014393c8 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x1c8>
10143936c: 52800033    	mov	w19, #0x1               ; =1
101439370: f940d028    	ldr	x8, [x1, #0x1a0]
101439374: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101439378: eb09011f    	cmp	x8, x9
10143937c: 54000260    	b.eq	0x1014393c8 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x1c8>
101439380: aa0003f4    	mov	x20, x0
101439384: 91068020    	add	x0, x1, #0x1a0
101439388: aa0203e1    	mov	x1, x2
10143938c: aa0303e2    	mov	x2, x3
101439390: aa0703f5    	mov	x21, x7
101439394: aa0603f7    	mov	x23, x6
101439398: aa0503f6    	mov	x22, x5
10143939c: aa0403f8    	mov	x24, x4
1014393a0: 940014b6    	bl	0x10143e678 <__ZN17otty_autocomplete7history14CommandHistory12offers_paths17h5110b07a591b8209E>
1014393a4: aa1803e4    	mov	x4, x24
1014393a8: aa1603e5    	mov	x5, x22
1014393ac: aa1703e6    	mov	x6, x23
1014393b0: aa1503e7    	mov	x7, x21
1014393b4: aa0003e8    	mov	x8, x0
1014393b8: aa1403e0    	mov	x0, x20
1014393bc: 2a080268    	orr	w8, w19, w8
1014393c0: 7100051f    	cmp	w8, #0x1
1014393c4: 540001a1    	b.ne	0x1014393f8 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x1f8>
1014393c8: aa0003e8    	mov	x8, x0
1014393cc: aa0403e0    	mov	x0, x4
1014393d0: aa0503e1    	mov	x1, x5
1014393d4: aa0603e2    	mov	x2, x6
1014393d8: aa0703e3    	mov	x3, x7
1014393dc: 52800024    	mov	w4, #0x1                ; =1
1014393e0: 52800025    	mov	w5, #0x1                ; =1
1014393e4: a9437bfd    	ldp	x29, x30, [sp, #0x30]
1014393e8: a9424ff4    	ldp	x20, x19, [sp, #0x20]
1014393ec: a94157f6    	ldp	x22, x21, [sp, #0x10]
1014393f0: a8c45ff8    	ldp	x24, x23, [sp], #0x40
1014393f4: 14003f22    	b	0x10144907c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E>
1014393f8: 52800108    	mov	w8, #0x8                ; =8
1014393fc: a900201f    	stp	xzr, x8, [x0]
101439400: f900081f    	str	xzr, [x0, #0x10]
101439404: a9437bfd    	ldp	x29, x30, [sp, #0x30]
101439408: a9424ff4    	ldp	x20, x19, [sp, #0x20]
10143940c: a94157f6    	ldp	x22, x21, [sp, #0x10]
101439410: a8c45ff8    	ldp	x24, x23, [sp], #0x40
101439414: d65f03c0    	ret
