1004c64bc:     	b	0x1004c64c0
1004c64c0:     	ldp	x0, x1, [x20, #0x10]
1004c64c4:     	ldp	x2, x3, [x20, #0x30]
1004c64c8:     	b	0x100582f88
1004c64cc:     	stp	x22, x21, [sp, #-0x30]!
1004c64d0:     	stp	x20, x19, [sp, #0x10]
1004c64d4:     	stp	x29, x30, [sp, #0x20]
1004c64d8:     	add	x29, sp, #0x20
1004c64dc:     	mov	x0, #0x0                ; =0
1004c64e0:     	bl	0x101ac4e28 ; symbol _$s10Foundation3URLVMa
1004c64e4:     	mov	x1, x0
1004c64e8:     	ldur	x8, [x0, #-0x8]
1004c64ec:     	ldrb	w19, [x8, #0x50]
1004c64f0:     	add	x9, x19, #0x10
1004c64f4:     	bic	x21, x9, x19
1004c64f8:     	ldr	x22, [x8, #0x40]
1004c64fc:     	ldr	x8, [x8, #0x8]
1004c6500:     	add	x0, x20, x21
1004c6504:     	blr	x8
1004c6508:     	add	x1, x21, x22
1004c650c:     	orr	x2, x19, #0x7
1004c6510:     	mov	x0, x20
1004c6514:     	ldp	x29, x30, [sp, #0x20]
1004c6518:     	ldp	x20, x19, [sp, #0x10]
1004c651c:     	ldp	x22, x21, [sp], #0x30
1004c6520:     	b	0x101aca6a8 ; symbol _swift_deallocObject
1004c6524:     	b	0x1004c6528
1004c6528:     	stp	x22, x21, [sp, #-0x30]!
1004c652c:     	stp	x20, x19, [sp, #0x10]
1004c6530:     	stp	x29, x30, [sp, #0x20]
1004c6534:     	add	x29, sp, #0x20
1004c6538:     	mov	x0, #0x0                ; =0
1004c653c:     	bl	0x101ac4e28 ; symbol _$s10Foundation3URLVMa
1004c6540:     	ldur	x8, [x0, #-0x8]
1004c6544:     	ldrb	w8, [x8, #0x50]
1004c6548:     	add	x9, x8, #0x10
1004c654c:     	bic	x21, x9, x8
1004c6550:     	adrp	x8, 0x102326000
1004c6554:     	ldr	x0, [x8, #0xa10]
1004c6558:     	bl	0x101ac9d24 ; symbol _objc_opt_self
1004c655c:     	bl	0x101ad4ec0 ; selector sharedWorkspace
1004c6560:     	mov	x29, x29
1004c6564:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
1004c6568:     	mov	x19, x0
1004c656c:     	add	x20, x20, x21
1004c6570:     	bl	0x101ac4d8c ; symbol _$s10Foundation3URLV19_bridgeToObjectiveCSo5NSURLCyF
1004c6574:     	mov	x20, x0
1004c6578:     	mov	x0, x19
1004c657c:     	mov	x2, x20
1004c6580:     	bl	0x101acfdc0 ; selector openURL:
1004c6584:     	mov	x0, x20
1004c6588:     	bl	0x101ac9d30 ; symbol _objc_release
1004c658c:     	mov	x0, x19
1004c6590:     	ldp	x29, x30, [sp, #0x20]
1004c6594:     	ldp	x20, x19, [sp, #0x10]
1004c6598:     	ldp	x22, x21, [sp], #0x30
1004c659c:     	b	0x101ac9d30 ; symbol _objc_release
