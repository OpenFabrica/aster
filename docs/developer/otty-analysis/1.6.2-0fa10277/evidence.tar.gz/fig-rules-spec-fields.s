
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010144ae38 <__ZN197_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionKind$GT$..deserialize..__FieldVisitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h04becca310550952E>:
10144ae4c: f1002c5f    	cmp	x2, #0xb
10144ae50: 54000520    	b.eq	0x10144aef4 <__ZN197_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionKind$GT$..deserialize..__FieldVisitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h04becca310550952E+0xbc>
10144ae54: f1001c5f    	cmp	x2, #0x7
10144ae58: 54000220    	b.eq	0x10144ae9c <__ZN197_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionKind$GT$..deserialize..__FieldVisitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h04becca310550952E+0x64>
10144ae5c: f100105f    	cmp	x2, #0x4
10144ae60: 540007e1    	b.ne	0x10144af5c <__ZN197_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionKind$GT$..deserialize..__FieldVisitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h04becca310550952E+0x124>
10144ae64: b9400028    	ldr	w8, [x1]
10144ae68: 528c2dc9    	mov	w9, #0x616e             ; =24942
10144ae6c: 72acada9    	movk	w9, #0x656d, lsl #16
10144ae70: 6b09011f    	cmp	w8, w9
10144ae74: 540008c0    	b.eq	0x10144af8c <__ZN197_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionKind$GT$..deserialize..__FieldVisitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h04becca310550952E+0x154>
10144ae78: b9400028    	ldr	w8, [x1]
10144ae7c: 528e4c29    	mov	w9, #0x7261             ; =29281
10144ae80: 72ae6ce9    	movk	w9, #0x7367, lsl #16
10144ae84: 6b09011f    	cmp	w8, w9
10144ae88: 540006a1    	b.ne	0x10144af5c <__ZN197_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionKind$GT$..deserialize..__FieldVisitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h04becca310550952E+0x124>
10144ae8c: 52800088    	mov	w8, #0x4                ; =4
10144ae90: 39000408    	strb	w8, [x0, #0x1]
10144ae94: 3900001f    	strb	wzr, [x0]
10144ae98: d65f03c0    	ret
10144ae9c: b9400028    	ldr	w8, [x1]
10144aea0: b8403029    	ldur	w9, [x1, #0x3]
10144aea4: 528e0dea    	mov	w10, #0x706f            ; =28783
10144aea8: 72ad2e8a    	movk	w10, #0x6974, lsl #16
10144aeac: 6b0a011f    	cmp	w8, w10
10144aeb0: 528ded28    	mov	w8, #0x6f69             ; =28521
10144aeb4: 72ae6dc8    	movk	w8, #0x736e, lsl #16
10144aeb8: 7a480120    	ccmp	w9, w8, #0x0, eq
10144aebc: 54000580    	b.eq	0x10144af6c <__ZN197_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionKind$GT$..deserialize..__FieldVisitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h04becca310550952E+0x134>
10144aec0: b9400028    	ldr	w8, [x1]
10144aec4: b8403029    	ldur	w9, [x1, #0x3]
10144aec8: 528d8c2a    	mov	w10, #0x6c61            ; =27745
10144aecc: 72ac2d2a    	movk	w10, #0x6169, lsl #16
10144aed0: 6b0a011f    	cmp	w8, w10
10144aed4: 528e6c28    	mov	w8, #0x7361             ; =29537
10144aed8: 72ae6ca8    	movk	w8, #0x7365, lsl #16
10144aedc: 7a480120    	ccmp	w9, w8, #0x0, eq
10144aee0: 540003e1    	b.ne	0x10144af5c <__ZN197_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionKind$GT$..deserialize..__FieldVisitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h04becca310550952E+0x124>
10144aee4: 528000a8    	mov	w8, #0x5                ; =5
10144aee8: 39000408    	strb	w8, [x0, #0x1]
10144aeec: 3900001f    	strb	wzr, [x0]
10144aef0: d65f03c0    	ret
10144aef4: f9400028    	ldr	x8, [x1]
10144aef8: f8403029    	ldur	x9, [x1, #0x3]
10144aefc: d28cac8a    	mov	x10, #0x6564            ; =25956
10144af00: f2ac6e6a    	movk	x10, #0x6373, lsl #16
10144af04: f2cd2e4a    	movk	x10, #0x6972, lsl #32
10144af08: f2ee8e0a    	movk	x10, #0x7470, lsl #48
10144af0c: eb0a011f    	cmp	x8, x10
10144af10: d28e4c68    	mov	x8, #0x7263             ; =29283
10144af14: f2ae0d28    	movk	x8, #0x7069, lsl #16
10144af18: f2cd2e88    	movk	x8, #0x6974, lsl #32
10144af1c: f2edcde8    	movk	x8, #0x6e6f, lsl #48
10144af20: fa480120    	ccmp	x9, x8, #0x0, eq
10144af24: 540002c0    	b.eq	0x10144af7c <__ZN197_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionKind$GT$..deserialize..__FieldVisitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h04becca310550952E+0x144>
10144af28: f9400028    	ldr	x8, [x1]
10144af2c: f8403029    	ldur	x9, [x1, #0x3]
10144af30: d28eae6a    	mov	x10, #0x7573            ; =30067
10144af34: f2ac6c4a    	movk	x10, #0x6362, lsl #16
10144af38: f2cdadea    	movk	x10, #0x6d6f, lsl #32
10144af3c: f2ec2daa    	movk	x10, #0x616d, lsl #48
10144af40: eb0a011f    	cmp	x8, x10
10144af44: d28dec68    	mov	x8, #0x6f63             ; =28515
10144af48: f2adada8    	movk	x8, #0x6d6d, lsl #16
10144af4c: f2cdcc28    	movk	x8, #0x6e61, lsl #32
10144af50: f2ee6c88    	movk	x8, #0x7364, lsl #48
10144af54: fa480120    	ccmp	x9, x8, #0x0, eq
10144af58: 54000220    	b.eq	0x10144af9c <__ZN197_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionKind$GT$..deserialize..__FieldVisitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h04becca310550952E+0x164>
10144af5c: 528000c8    	mov	w8, #0x6                ; =6
10144af60: 39000408    	strb	w8, [x0, #0x1]
10144af64: 3900001f    	strb	wzr, [x0]
10144af68: d65f03c0    	ret
10144af6c: 52800068    	mov	w8, #0x3                ; =3
10144af70: 39000408    	strb	w8, [x0, #0x1]
10144af74: 3900001f    	strb	wzr, [x0]
10144af78: d65f03c0    	ret
10144af7c: 52800028    	mov	w8, #0x1                ; =1
10144af80: 39000408    	strb	w8, [x0, #0x1]
10144af84: 3900001f    	strb	wzr, [x0]
10144af88: d65f03c0    	ret
10144af8c: 52800008    	mov	w8, #0x0                ; =0
10144af90: 39000408    	strb	w8, [x0, #0x1]
10144af94: 3900001f    	strb	wzr, [x0]
10144af98: d65f03c0    	ret
10144af9c: 52800048    	mov	w8, #0x2                ; =2
10144afa0: 39000408    	strb	w8, [x0, #0x1]
10144afa4: 3900001f    	strb	wzr, [x0]
10144afa8: d65f03c0    	ret
