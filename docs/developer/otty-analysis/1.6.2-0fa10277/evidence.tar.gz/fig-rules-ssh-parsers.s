
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101477fc0 <__ZN15otty_ssh_config11known_hosts11known_hosts17hf71f534e749e4cf0E>:
101477fc0: d10143ff    	sub	sp, sp, #0x50
101477fc4: a90257f6    	stp	x22, x21, [sp, #0x20]
101477fc8: a9034ff4    	stp	x20, x19, [sp, #0x30]
101477fcc: a9047bfd    	stp	x29, x30, [sp, #0x40]
101477fd0: 910103fd    	add	x29, sp, #0x40
101477fd4: aa0803f5    	mov	x21, x8
101477fd8: 910023e8    	add	x8, sp, #0x8
101477fdc: 940ce1c4    	bl	0x1017b06ec <__ZN3std2fs14read_to_string5inner17h33327e834bd59c04E>
101477fe0: f94007f3    	ldr	x19, [sp, #0x8]
101477fe4: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101477fe8: eb08027f    	cmp	x19, x8
101477fec: 54000161    	b.ne	0x101478018 <__ZN15otty_ssh_config11known_hosts11known_hosts17hf71f534e749e4cf0E+0x58>
101477ff0: 52800108    	mov	w8, #0x8                ; =8
101477ff4: a90022bf    	stp	xzr, x8, [x21]
101477ff8: f9000abf    	str	xzr, [x21, #0x10]
101477ffc: f9400be1    	ldr	x1, [sp, #0x10]
101478000: d2f00000    	mov	x0, #-0x8000000000000000 ; =-9223372036854775808
101478004: a9447bfd    	ldp	x29, x30, [sp, #0x40]
101478008: a9434ff4    	ldp	x20, x19, [sp, #0x30]
10147800c: a94257f6    	ldp	x22, x21, [sp, #0x20]
101478010: 910143ff    	add	sp, sp, #0x50
101478014: 140049ef    	b	0x10148a7d0 <__ZN3std2io5error5Error3new17h519eec155b6ed967E+0x820>
101478018: a94107f4    	ldp	x20, x1, [sp, #0x10]
10147801c: aa1503e8    	mov	x8, x21
101478020: aa1403e0    	mov	x0, x20
101478024: 94000017    	bl	0x101478080 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E>
101478028: b4000133    	cbz	x19, 0x10147804c <__ZN15otty_ssh_config11known_hosts11known_hosts17hf71f534e749e4cf0E+0x8c>
10147802c: aa1403e0    	mov	x0, x20
101478030: aa1303e1    	mov	x1, x19
101478034: 52800022    	mov	w2, #0x1                ; =1
101478038: a9447bfd    	ldp	x29, x30, [sp, #0x40]
10147803c: a9434ff4    	ldp	x20, x19, [sp, #0x30]
101478040: a94257f6    	ldp	x22, x21, [sp, #0x20]
101478044: 910143ff    	add	sp, sp, #0x50
101478048: 17d899a5    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147804c: a9447bfd    	ldp	x29, x30, [sp, #0x40]
101478050: a9434ff4    	ldp	x20, x19, [sp, #0x30]
101478054: a94257f6    	ldp	x22, x21, [sp, #0x20]
101478058: 910143ff    	add	sp, sp, #0x50
10147805c: d65f03c0    	ret
101478060: aa0003f5    	mov	x21, x0
101478064: b40000b3    	cbz	x19, 0x101478078 <__ZN15otty_ssh_config11known_hosts11known_hosts17hf71f534e749e4cf0E+0xb8>
101478068: aa1403e0    	mov	x0, x20
10147806c: aa1303e1    	mov	x1, x19
101478070: 52800022    	mov	w2, #0x1                ; =1
101478074: 97d8999a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478078: aa1503e0    	mov	x0, x21
10147807c: 94194556    	bl	0x101ac95d4 <_writev+0x101ac95d4>

0000000101478080 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E>:
101478080: 6db923e9    	stp	d9, d8, [sp, #-0x70]!
101478084: a9016ffc    	stp	x28, x27, [sp, #0x10]
101478088: a90267fa    	stp	x26, x25, [sp, #0x20]
10147808c: a9035ff8    	stp	x24, x23, [sp, #0x30]
101478090: a90457f6    	stp	x22, x21, [sp, #0x40]
101478094: a9054ff4    	stp	x20, x19, [sp, #0x50]
101478098: a9067bfd    	stp	x29, x30, [sp, #0x60]
10147809c: 910183fd    	add	x29, sp, #0x60
1014780a0: d10643ff    	sub	sp, sp, #0x190
1014780a4: aa0103f4    	mov	x20, x1
1014780a8: aa0003f5    	mov	x21, x0
1014780ac: aa0803f3    	mov	x19, x8
1014780b0: 52800108    	mov	w8, #0x8                ; =8
1014780b4: a900a3ff    	stp	xzr, x8, [sp, #0x8]
1014780b8: f9000fff    	str	xzr, [sp, #0x18]
1014780bc: 90007820    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
1014780c0: 9131a000    	add	x0, x0, #0xc68
1014780c4: f9400008    	ldr	x8, [x0]
1014780c8: d63f0100    	blr	x8
1014780cc: aa0003f6    	mov	x22, x0
1014780d0: 39404008    	ldrb	w8, [x0, #0x10]
1014780d4: 7100051f    	cmp	w8, #0x1
1014780d8: 540026a1    	b.ne	0x1014785ac <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x52c>
1014780dc: a94006c0    	ldp	x0, x1, [x22]
1014780e0: 91000408    	add	x8, x0, #0x1
1014780e4: f90002c8    	str	x8, [x22]
1014780e8: d0006f88    	adrp	x8, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
1014780ec: 91250108    	add	x8, x8, #0x940
1014780f0: ad400500    	ldp	q0, q1, [x8]
1014780f4: ad0107e0    	stp	q0, q1, [sp, #0x20]
1014780f8: a90407e0    	stp	x0, x1, [sp, #0x40]
1014780fc: a905d3ff    	stp	xzr, x20, [sp, #0x58]
101478100: 910163f7    	add	x23, sp, #0x58
101478104: a906d3f5    	stp	x21, x20, [sp, #0x68]
101478108: a907d3ff    	stp	xzr, x20, [sp, #0x78]
10147810c: 0f000540    	movi.2s	v0, #0xa
101478110: fd0047e0    	str	d0, [sp, #0x88]
101478114: 52800038    	mov	w24, #0x1               ; =1
101478118: 910383f9    	add	x25, sp, #0xe0
10147811c: d10323ba    	sub	x26, x29, #0xc8
101478120: 390243f8    	strb	w24, [sp, #0x90]
101478124: 0f010588    	movi.2s	v8, #0x2c
101478128: 0f0207a9    	movi.2s	v9, #0x5d
10147812c: 5280031b    	mov	w27, #0x18              ; =24
101478130: d2c0805c    	mov	x28, #0x40200000000     ; =4406636445696
101478134: f2f0001c    	movk	x28, #0x8000, lsl #48
101478138: 790133ff    	strh	wzr, [sp, #0x98]
10147813c: 14000003    	b	0x101478148 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0xc8>
101478140: 394267e8    	ldrb	w8, [sp, #0x99]
101478144: 37001c48    	tbnz	w8, #0x0, 0x1014784cc <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x44c>
101478148: f94037f4    	ldr	x20, [sp, #0x68]
10147814c: d10323a0    	sub	x0, x29, #0xc8
101478150: 910042e1    	add	x1, x23, #0x10
101478154: 940055ee    	bl	0x10148d90c <__ZN4core5slice4sort6stable9quicksort9quicksort17h1ad04638c7ce3510E+0x1974>
101478158: b85383a8    	ldur	w8, [x29, #-0xc8]
10147815c: 7100051f    	cmp	w8, #0x1
101478160: 54000101    	b.ne	0x101478180 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x100>
101478164: f85483a8    	ldur	x8, [x29, #-0xb8]
101478168: f9402fe9    	ldr	x9, [sp, #0x58]
10147816c: cb090101    	sub	x1, x8, x9
101478170: 8b090280    	add	x0, x20, x9
101478174: f9002fe8    	str	x8, [sp, #0x58]
101478178: b50001c1    	cbnz	x1, 0x1014781b0 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x130>
10147817c: 1400001c    	b	0x1014781ec <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x16c>
101478180: 394267e8    	ldrb	w8, [sp, #0x99]
101478184: 37001a48    	tbnz	w8, #0x0, 0x1014784cc <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x44c>
101478188: 390267f8    	strb	w24, [sp, #0x99]
10147818c: 394263ea    	ldrb	w10, [sp, #0x98]
101478190: a945a7e8    	ldp	x8, x9, [sp, #0x58]
101478194: 3700006a    	tbnz	w10, #0x0, 0x1014781a0 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x120>
101478198: eb08013f    	cmp	x9, x8
10147819c: 54001980    	b.eq	0x1014784cc <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x44c>
1014781a0: f94037ea    	ldr	x10, [sp, #0x68]
1014781a4: cb080121    	sub	x1, x9, x8
1014781a8: 8b080140    	add	x0, x10, x8
1014781ac: b4000201    	cbz	x1, 0x1014781ec <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x16c>
1014781b0: d1000428    	sub	x8, x1, #0x1
1014781b4: 38686809    	ldrb	w9, [x0, x8]
1014781b8: 7100293f    	cmp	w9, #0xa
1014781bc: 54000181    	b.ne	0x1014781ec <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x16c>
1014781c0: d1000829    	sub	x9, x1, #0x2
1014781c4: b40000c8    	cbz	x8, 0x1014781dc <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x15c>
1014781c8: 3869680a    	ldrb	w10, [x0, x9]
1014781cc: 12001d4a    	and	w10, w10, #0xff
1014781d0: 7100355f    	cmp	w10, #0xd
1014781d4: 9a9f000a    	csel	x10, x0, xzr, eq
1014781d8: 14000002    	b	0x1014781e0 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x160>
1014781dc: d280000a    	mov	x10, #0x0               ; =0
1014781e0: f100015f    	cmp	x10, #0x0
1014781e4: 9a890101    	csel	x1, x8, x9, eq
1014781e8: 9a8a0000    	csel	x0, x0, x10, eq
1014781ec: 97d351de    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
1014781f0: b4fffa81    	cbz	x1, 0x101478140 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0xc0>
1014781f4: 39400008    	ldrb	w8, [x0]
1014781f8: 71008d1f    	cmp	w8, #0x23
1014781fc: 54fffa20    	b.eq	0x101478140 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0xc0>
101478200: 7101f11f    	cmp	w8, #0x7c
101478204: 54fff9e0    	b.eq	0x101478140 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0xc0>
101478208: 8b010008    	add	x8, x0, x1
10147820c: a90a07ff    	stp	xzr, x1, [sp, #0xa0]
101478210: a90b07e0    	stp	x0, x1, [sp, #0xb0]
101478214: a90c23e0    	stp	x0, x8, [sp, #0xc0]
101478218: f9006bff    	str	xzr, [sp, #0xd0]
10147821c: 7901b3f8    	strh	w24, [sp, #0xd8]
101478220: 910283e0    	add	x0, sp, #0xa0
101478224: 97d35a46    	bl	0x10094eb3c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3bb14>
101478228: b4fff8c0    	cbz	x0, 0x101478140 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0xc0>
10147822c: b4000161    	cbz	x1, 0x101478258 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x1d8>
101478230: 39400008    	ldrb	w8, [x0]
101478234: 7101011f    	cmp	w8, #0x40
101478238: 540000c1    	b.ne	0x101478250 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x1d0>
10147823c: 910283e0    	add	x0, sp, #0xa0
101478240: 97d35a3f    	bl	0x10094eb3c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3bb14>
101478244: b4fff7e0    	cbz	x0, 0x101478140 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0xc0>
101478248: b4000081    	cbz	x1, 0x101478258 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x1d8>
10147824c: 39400008    	ldrb	w8, [x0]
101478250: 7101f11f    	cmp	w8, #0x7c
101478254: 54fff760    	b.eq	0x101478140 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0xc0>
101478258: a90e07ff    	stp	xzr, x1, [sp, #0xe0]
10147825c: a90f07e0    	stp	x0, x1, [sp, #0xf0]
101478260: a91007ff    	stp	xzr, x1, [sp, #0x100]
101478264: fd008be8    	str	d8, [sp, #0x110]
101478268: 390463f8    	strb	w24, [sp, #0x118]
10147826c: 790243f8    	strh	w24, [sp, #0x120]
101478270: 14000009    	b	0x101478294 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x214>
101478274: f9400be8    	ldr	x8, [sp, #0x10]
101478278: 9b1b22a8    	madd	x8, x21, x27, x8
10147827c: a9005914    	stp	x20, x22, [x8]
101478280: f9000914    	str	x20, [x8, #0x10]
101478284: 910006a8    	add	x8, x21, #0x1
101478288: f9000fe8    	str	x8, [sp, #0x18]
10147828c: 394487e8    	ldrb	w8, [sp, #0x121]
101478290: 3707f588    	tbnz	w8, #0x0, 0x101478140 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0xc0>
101478294: f9407bf5    	ldr	x21, [sp, #0xf0]
101478298: d10323a0    	sub	x0, x29, #0xc8
10147829c: 91004321    	add	x1, x25, #0x10
1014782a0: 9400559b    	bl	0x10148d90c <__ZN4core5slice4sort6stable9quicksort9quicksort17h1ad04638c7ce3510E+0x1974>
1014782a4: b85383a8    	ldur	w8, [x29, #-0xc8]
1014782a8: 7100051f    	cmp	w8, #0x1
1014782ac: 54000101    	b.ne	0x1014782cc <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x24c>
1014782b0: a97427a8    	ldp	x8, x9, [x29, #-0xc0]
1014782b4: f94073ea    	ldr	x10, [sp, #0xe0]
1014782b8: cb0a0114    	sub	x20, x8, x10
1014782bc: 8b0a02b5    	add	x21, x21, x10
1014782c0: f90073e9    	str	x9, [sp, #0xe0]
1014782c4: b50001d4    	cbnz	x20, 0x1014782fc <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x27c>
1014782c8: 17fffff1    	b	0x10147828c <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x20c>
1014782cc: 394487e8    	ldrb	w8, [sp, #0x121]
1014782d0: 3707f388    	tbnz	w8, #0x0, 0x101478140 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0xc0>
1014782d4: 390487f8    	strb	w24, [sp, #0x121]
1014782d8: 394483ea    	ldrb	w10, [sp, #0x120]
1014782dc: a94e27e8    	ldp	x8, x9, [sp, #0xe0]
1014782e0: 3700006a    	tbnz	w10, #0x0, 0x1014782ec <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x26c>
1014782e4: eb08013f    	cmp	x9, x8
1014782e8: 54fff2c0    	b.eq	0x101478140 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0xc0>
1014782ec: f9407bea    	ldr	x10, [sp, #0xf0]
1014782f0: cb080134    	sub	x20, x9, x8
1014782f4: 8b080155    	add	x21, x10, x8
1014782f8: b4fffcb4    	cbz	x20, 0x10147828c <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x20c>
1014782fc: aa1503f6    	mov	x22, x21
101478300: 384016c8    	ldrb	w8, [x22], #0x1
101478304: 71016d1f    	cmp	w8, #0x5b
101478308: 54000561    	b.ne	0x1014783b4 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x334>
10147830c: d1000694    	sub	x20, x20, #0x1
101478310: a933d3bf    	stp	xzr, x20, [x29, #-0xc8]
101478314: a934d3b6    	stp	x22, x20, [x29, #-0xb8]
101478318: a935d3bf    	stp	xzr, x20, [x29, #-0xa8]
10147831c: fc1683a9    	stur	d9, [x29, #-0x98]
101478320: 381703b8    	sturb	w24, [x29, #-0x90]
101478324: 781783b8    	sturh	w24, [x29, #-0x88]
101478328: d10203a0    	sub	x0, x29, #0x80
10147832c: 91004341    	add	x1, x26, #0x10
101478330: 94005577    	bl	0x10148d90c <__ZN4core5slice4sort6stable9quicksort9quicksort17h1ad04638c7ce3510E+0x1974>
101478334: b85803a8    	ldur	w8, [x29, #-0x80]
101478338: 7100051f    	cmp	w8, #0x1
10147833c: 54000141    	b.ne	0x101478364 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x2e4>
101478340: f85883a8    	ldur	x8, [x29, #-0x78]
101478344: f85383aa    	ldur	x10, [x29, #-0xc8]
101478348: cb0a0109    	sub	x9, x8, x10
10147834c: 8b0a02c8    	add	x8, x22, x10
101478350: f100011f    	cmp	x8, #0x0
101478354: 9a8802d5    	csel	x21, x22, x8, eq
101478358: 9a890294    	csel	x20, x20, x9, eq
10147835c: b50002d4    	cbnz	x20, 0x1014783b4 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x334>
101478360: 17ffffcb    	b	0x10147828c <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x20c>
101478364: 385793a8    	ldurb	w8, [x29, #-0x87]
101478368: 370000c8    	tbnz	w8, #0x0, 0x101478380 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x300>
10147836c: 385783aa    	ldurb	w10, [x29, #-0x88]
101478370: a973a7a8    	ldp	x8, x9, [x29, #-0xc8]
101478374: 3700012a    	tbnz	w10, #0x0, 0x101478398 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x318>
101478378: eb08013f    	cmp	x9, x8
10147837c: 540000e1    	b.ne	0x101478398 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x318>
101478380: d2800008    	mov	x8, #0x0                ; =0
101478384: f100011f    	cmp	x8, #0x0
101478388: 9a8802d5    	csel	x21, x22, x8, eq
10147838c: 9a890294    	csel	x20, x20, x9, eq
101478390: b5000134    	cbnz	x20, 0x1014783b4 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x334>
101478394: 17ffffbe    	b	0x10147828c <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x20c>
101478398: f85483aa    	ldur	x10, [x29, #-0xb8]
10147839c: cb080129    	sub	x9, x9, x8
1014783a0: 8b080148    	add	x8, x10, x8
1014783a4: f100011f    	cmp	x8, #0x0
1014783a8: 9a8802d5    	csel	x21, x22, x8, eq
1014783ac: 9a890294    	csel	x20, x20, x9, eq
1014783b0: b4fff6f4    	cbz	x20, 0x10147828c <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x20c>
1014783b4: 8b1402a8    	add	x8, x21, x20
1014783b8: aa1503e9    	mov	x9, x21
1014783bc: 14000008    	b	0x1014783dc <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x35c>
1014783c0: aa0b03e9    	mov	x9, x11
1014783c4: 2a0a03eb    	mov	w11, w10
1014783c8: 7100fd5f    	cmp	w10, #0x3f
1014783cc: 9acb230a    	lsl	x10, x24, x11
1014783d0: 8a1c014a    	and	x10, x10, x28
1014783d4: fa409944    	ccmp	x10, #0x0, #0x4, ls
1014783d8: 54fff5a1    	b.ne	0x10147828c <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x20c>
1014783dc: eb08013f    	cmp	x9, x8
1014783e0: 54000380    	b.eq	0x101478450 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x3d0>
1014783e4: aa0903eb    	mov	x11, x9
1014783e8: 38c0156c    	ldrsb	w12, [x11], #0x1
1014783ec: 12001d8a    	and	w10, w12, #0xff
1014783f0: 36fffe8c    	tbz	w12, #0x1f, 0x1014783c0 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x340>
1014783f4: 3940052b    	ldrb	w11, [x9, #0x1]
1014783f8: 1200156c    	and	w12, w11, #0x3f
1014783fc: 7103815f    	cmp	w10, #0xe0
101478400: 540001a3    	b.lo	0x101478434 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x3b4>
101478404: 1200114b    	and	w11, w10, #0x1f
101478408: 3940092d    	ldrb	w13, [x9, #0x2]
10147840c: 120015ad    	and	w13, w13, #0x3f
101478410: 2a0c19ac    	orr	w12, w13, w12, lsl #6
101478414: 7103c15f    	cmp	w10, #0xf0
101478418: 54000163    	b.lo	0x101478444 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x3c4>
10147841c: 39400d2a    	ldrb	w10, [x9, #0x3]
101478420: 91001129    	add	x9, x9, #0x4
101478424: 1200154a    	and	w10, w10, #0x3f
101478428: 2a0c194a    	orr	w10, w10, w12, lsl #6
10147842c: 330e096a    	bfi	w10, w11, #18, #3
101478430: 17ffffe5    	b	0x1014783c4 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x344>
101478434: 91000929    	add	x9, x9, #0x2
101478438: 331a114c    	bfi	w12, w10, #6, #5
10147843c: aa0c03ea    	mov	x10, x12
101478440: 17ffffe1    	b	0x1014783c4 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x344>
101478444: 91000d29    	add	x9, x9, #0x3
101478448: 2a0b318a    	orr	w10, w12, w11, lsl #12
10147844c: 17ffffde    	b	0x1014783c4 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x344>
101478450: 97d898a8    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101478454: aa1403e0    	mov	x0, x20
101478458: 52800021    	mov	w1, #0x1                ; =1
10147845c: 97d8989f    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101478460: b4000b00    	cbz	x0, 0x1014785c0 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x540>
101478464: aa0003f6    	mov	x22, x0
101478468: aa1503e1    	mov	x1, x21
10147846c: aa1403e2    	mov	x2, x20
101478470: 941945ee    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101478474: a933dbb4    	stp	x20, x22, [x29, #-0xc8]
101478478: f81483b4    	stur	x20, [x29, #-0xb8]
10147847c: 910083e0    	add	x0, sp, #0x20
101478480: d10323a1    	sub	x1, x29, #0xc8
101478484: 94005594    	bl	0x10148dad4 <__ZN4core5slice4sort6stable9quicksort9quicksort17h1ad04638c7ce3510E+0x1b3c>
101478488: 3707f020    	tbnz	w0, #0x0, 0x10147828c <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x20c>
10147848c: 97d89899    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101478490: aa1403e0    	mov	x0, x20
101478494: 52800021    	mov	w1, #0x1                ; =1
101478498: 97d89890    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147849c: b4000920    	cbz	x0, 0x1014785c0 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x540>
1014784a0: aa0003f6    	mov	x22, x0
1014784a4: aa1503e1    	mov	x1, x21
1014784a8: aa1403e2    	mov	x2, x20
1014784ac: 941945df    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014784b0: f9400ff5    	ldr	x21, [sp, #0x18]
1014784b4: f94007e8    	ldr	x8, [sp, #0x8]
1014784b8: eb0802bf    	cmp	x21, x8
1014784bc: 54ffedc1    	b.ne	0x101478274 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x1f4>
1014784c0: 910023e0    	add	x0, sp, #0x8
1014784c4: 941929ab    	bl	0x101ac2b70 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hb575521872840d8cE>
1014784c8: 17ffff6b    	b	0x101478274 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x1f4>
1014784cc: 3cc083e0    	ldur	q0, [sp, #0x8]
1014784d0: 3d800260    	str	q0, [x19]
1014784d4: f9400fe8    	ldr	x8, [sp, #0x18]
1014784d8: f9000a68    	str	x8, [x19, #0x10]
1014784dc: f94017f3    	ldr	x19, [sp, #0x28]
1014784e0: b4000553    	cbz	x19, 0x101478588 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x508>
1014784e4: f9401ff4    	ldr	x20, [sp, #0x38]
1014784e8: b40003d4    	cbz	x20, 0x101478560 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x4e0>
1014784ec: f94013f5    	ldr	x21, [sp, #0x20]
1014784f0: aa1503f6    	mov	x22, x21
1014784f4: fc4086c0    	ldr	d0, [x22], #0x8
1014784f8: 2e208800    	cmge.8b	v0, v0, #0
1014784fc: 9e660008    	fmov	x8, d0
101478500: 9201c118    	and	x24, x8, #0x8080808080808080
101478504: 52800317    	mov	w23, #0x18              ; =24
101478508: 14000005    	b	0x10147851c <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x49c>
10147850c: d1000708    	sub	x8, x24, #0x1
101478510: 8a180118    	and	x24, x8, x24
101478514: d1000694    	sub	x20, x20, #0x1
101478518: b4000254    	cbz	x20, 0x101478560 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x4e0>
10147851c: b50000f8    	cbnz	x24, 0x101478538 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x4b8>
101478520: fc4086c0    	ldr	d0, [x22], #0x8
101478524: 2e208800    	cmge.8b	v0, v0, #0
101478528: 9e660008    	fmov	x8, d0
10147852c: d10302b5    	sub	x21, x21, #0xc0
101478530: 9201c118    	and	x24, x8, #0x8080808080808080
101478534: b4ffff78    	cbz	x24, 0x101478520 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x4a0>
101478538: dac00308    	rbit	x8, x24
10147853c: dac01108    	clz	x8, x8
101478540: cb480fe8    	neg	x8, x8, lsr #3
101478544: 9b375508    	smaddl	x8, w8, w23, x21
101478548: f85e8101    	ldur	x1, [x8, #-0x18]
10147854c: b4fffe01    	cbz	x1, 0x10147850c <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x48c>
101478550: f85f0100    	ldur	x0, [x8, #-0x10]
101478554: 52800022    	mov	w2, #0x1                ; =1
101478558: 97d89861    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147855c: 17ffffec    	b	0x10147850c <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x48c>
101478560: 8b130668    	add	x8, x19, x19, lsl #1
101478564: d37df108    	lsl	x8, x8, #3
101478568: 8b130109    	add	x9, x8, x19
10147856c: b1008521    	adds	x1, x9, #0x21
101478570: 540000c0    	b.eq	0x101478588 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x508>
101478574: f94013e9    	ldr	x9, [sp, #0x20]
101478578: cb080128    	sub	x8, x9, x8
10147857c: d1006100    	sub	x0, x8, #0x18
101478580: 52800102    	mov	w2, #0x8                ; =8
101478584: 97d89856    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478588: 910643ff    	add	sp, sp, #0x190
10147858c: a9467bfd    	ldp	x29, x30, [sp, #0x60]
101478590: a9454ff4    	ldp	x20, x19, [sp, #0x50]
101478594: a94457f6    	ldp	x22, x21, [sp, #0x40]
101478598: a9435ff8    	ldp	x24, x23, [sp, #0x30]
10147859c: a94267fa    	ldp	x26, x25, [sp, #0x20]
1014785a0: a9416ffc    	ldp	x28, x27, [sp, #0x10]
1014785a4: 6cc723e9    	ldp	d9, d8, [sp], #0x70
1014785a8: d65f03c0    	ret
1014785ac: 940d1cf7    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
1014785b0: f90006c1    	str	x1, [x22, #0x8]
1014785b4: 52800028    	mov	w8, #0x1                ; =1
1014785b8: 390042c8    	strb	w8, [x22, #0x10]
1014785bc: 17fffec9    	b	0x1014780e0 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x60>
1014785c0: 52800020    	mov	w0, #0x1                ; =1
1014785c4: aa1403e1    	mov	x1, x20
1014785c8: 94192b6b    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014785cc: d4200020    	brk	#0x1
1014785d0: aa0003f3    	mov	x19, x0
1014785d4: 910023e0    	add	x0, sp, #0x8
1014785d8: 97d3294d    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
1014785dc: aa1303e0    	mov	x0, x19
1014785e0: 941943fd    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014785e4: aa0003f3    	mov	x19, x0
1014785e8: aa1603e0    	mov	x0, x22
1014785ec: aa1403e1    	mov	x1, x20
1014785f0: 52800022    	mov	w2, #0x1                ; =1
1014785f4: 97d8983a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014785f8: 910083e0    	add	x0, sp, #0x20
1014785fc: 97d34118    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
101478600: 910023e0    	add	x0, sp, #0x8
101478604: 97d32942    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101478608: aa1303e0    	mov	x0, x19
10147860c: 941943f2    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101478610: 14000002    	b	0x101478618 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x598>
101478614: 14000001    	b	0x101478618 <__ZN15otty_ssh_config11known_hosts17parse_known_hosts17h6c99e380855a07a3E+0x598>
101478618: aa0003f3    	mov	x19, x0
10147861c: 910083e0    	add	x0, sp, #0x20
101478620: 97d3410f    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
101478624: 910023e0    	add	x0, sp, #0x8
101478628: 97d32939    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10147862c: aa1303e0    	mov	x0, x19
101478630: 941943e9    	bl	0x101ac95d4 <_writev+0x101ac95d4>

0000000101478634 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE>:
101478634: d10483ff    	sub	sp, sp, #0x120
101478638: a90c6ffc    	stp	x28, x27, [sp, #0xc0]
10147863c: a90d67fa    	stp	x26, x25, [sp, #0xd0]
101478640: a90e5ff8    	stp	x24, x23, [sp, #0xe0]
101478644: a90f57f6    	stp	x22, x21, [sp, #0xf0]
101478648: a9104ff4    	stp	x20, x19, [sp, #0x100]
10147864c: a9117bfd    	stp	x29, x30, [sp, #0x110]
101478650: 910443fd    	add	x29, sp, #0x110
101478654: aa0803f3    	mov	x19, x8
101478658: 9100e3e8    	add	x8, sp, #0x38
10147865c: 940006c0    	bl	0x10147a15c <__ZN15otty_ssh_config4load6Loader15ssh_config_only17h4c508a3576e2129aE>
101478660: 910023e8    	add	x8, sp, #0x8
101478664: 9100e3e0    	add	x0, sp, #0x38
101478668: 94000894    	bl	0x10147a8b8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E>
10147866c: a94157f4    	ldp	x20, x21, [sp, #0x10]
101478670: 52802508    	mov	w8, #0x128              ; =296
101478674: 9b087ea8    	mul	x8, x21, x8
101478678: 8b080298    	add	x24, x20, x8
10147867c: aa1403e9    	mov	x9, x20
101478680: b40001a8    	cbz	x8, 0x1014786b4 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x80>
101478684: 9104a139    	add	x25, x9, #0x128
101478688: 39447d2a    	ldrb	w10, [x9, #0x11f]
10147868c: d104a108    	sub	x8, x8, #0x128
101478690: aa1903e9    	mov	x9, x25
101478694: 3707ff6a    	tbnz	w10, #0x0, 0x101478680 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x4c>
101478698: d104a320    	sub	x0, x25, #0x128
10147869c: d101c3a8    	sub	x8, x29, #0x70
1014786a0: 940e5acb    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1014786a4: f85903b6    	ldur	x22, [x29, #-0x70]
1014786a8: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014786ac: eb0802df    	cmp	x22, x8
1014786b0: 540000c1    	b.ne	0x1014786c8 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x94>
1014786b4: 52800108    	mov	w8, #0x8                ; =8
1014786b8: a900227f    	stp	xzr, x8, [x19]
1014786bc: f9000a7f    	str	xzr, [x19, #0x10]
1014786c0: b5000695    	cbnz	x21, 0x101478790 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x15c>
1014786c4: 14000039    	b	0x1014787a8 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x174>
1014786c8: a979dfb4    	ldp	x20, x23, [x29, #-0x68]
1014786cc: 97d89809    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014786d0: 52800c00    	mov	w0, #0x60               ; =96
1014786d4: 52800101    	mov	w1, #0x8                ; =8
1014786d8: 97d89800    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014786dc: b4000f40    	cbz	x0, 0x1014788c4 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x290>
1014786e0: aa0003f5    	mov	x21, x0
1014786e4: a9005016    	stp	x22, x20, [x0]
1014786e8: f9000817    	str	x23, [x0, #0x10]
1014786ec: 52800088    	mov	w8, #0x4                ; =4
1014786f0: a90883e8    	stp	x8, x0, [sp, #0x88]
1014786f4: 52800034    	mov	w20, #0x1               ; =1
1014786f8: d2f0001a    	mov	x26, #-0x8000000000000000 ; =-9223372036854775808
1014786fc: 5280031b    	mov	w27, #0x18              ; =24
101478700: f9004ff4    	str	x20, [sp, #0x98]
101478704: aa1903e8    	mov	x8, x25
101478708: eb18011f    	cmp	x8, x24
10147870c: 54000360    	b.eq	0x101478778 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x144>
101478710: 9104a119    	add	x25, x8, #0x128
101478714: 39447d09    	ldrb	w9, [x8, #0x11f]
101478718: aa1903e8    	mov	x8, x25
10147871c: 3707ff69    	tbnz	w9, #0x0, 0x101478708 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0xd4>
101478720: d104a320    	sub	x0, x25, #0x128
101478724: d101c3a8    	sub	x8, x29, #0x70
101478728: 940e5aa9    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10147872c: f85903b6    	ldur	x22, [x29, #-0x70]
101478730: eb1a02df    	cmp	x22, x26
101478734: 54000220    	b.eq	0x101478778 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x144>
101478738: a979f3b7    	ldp	x23, x28, [x29, #-0x68]
10147873c: f94047e8    	ldr	x8, [sp, #0x88]
101478740: eb08029f    	cmp	x20, x8
101478744: 54000101    	b.ne	0x101478764 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x130>
101478748: 910223e0    	add	x0, sp, #0x88
10147874c: aa1403e1    	mov	x1, x20
101478750: 52800022    	mov	w2, #0x1                ; =1
101478754: 52800103    	mov	w3, #0x8                ; =8
101478758: 52800304    	mov	w4, #0x18               ; =24
10147875c: 9416c03d    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101478760: f9404bf5    	ldr	x21, [sp, #0x90]
101478764: 9b1b5688    	madd	x8, x20, x27, x21
101478768: a9005d16    	stp	x22, x23, [x8]
10147876c: f900091c    	str	x28, [x8, #0x10]
101478770: 91000694    	add	x20, x20, #0x1
101478774: 17ffffe3    	b	0x101478700 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0xcc>
101478778: 3cc883e0    	ldur	q0, [sp, #0x88]
10147877c: 3d800260    	str	q0, [x19]
101478780: f9404fe8    	ldr	x8, [sp, #0x98]
101478784: f9000a68    	str	x8, [x19, #0x10]
101478788: a94157f4    	ldp	x20, x21, [sp, #0x10]
10147878c: b40000f5    	cbz	x21, 0x1014787a8 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x174>
101478790: aa1403f3    	mov	x19, x20
101478794: aa1303e0    	mov	x0, x19
101478798: 9400466b    	bl	0x10148a144 <__ZN3std2io5error5Error3new17h519eec155b6ed967E+0x194>
10147879c: 9104a273    	add	x19, x19, #0x128
1014787a0: f10006b5    	subs	x21, x21, #0x1
1014787a4: 54ffff81    	b.ne	0x101478794 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x160>
1014787a8: f94007e8    	ldr	x8, [sp, #0x8]
1014787ac: b40000c8    	cbz	x8, 0x1014787c4 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x190>
1014787b0: 52802509    	mov	w9, #0x128              ; =296
1014787b4: 9b097d01    	mul	x1, x8, x9
1014787b8: aa1403e0    	mov	x0, x20
1014787bc: 52800102    	mov	w2, #0x8                ; =8
1014787c0: 97d897c7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014787c4: a942d3f3    	ldp	x19, x20, [sp, #0x28]
1014787c8: b4000194    	cbz	x20, 0x1014787f8 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x1c4>
1014787cc: 91002275    	add	x21, x19, #0x8
1014787d0: 14000004    	b	0x1014787e0 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x1ac>
1014787d4: 910062b5    	add	x21, x21, #0x18
1014787d8: f1000694    	subs	x20, x20, #0x1
1014787dc: 540000e0    	b.eq	0x1014787f8 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x1c4>
1014787e0: f85f82a1    	ldur	x1, [x21, #-0x8]
1014787e4: b4ffff81    	cbz	x1, 0x1014787d4 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x1a0>
1014787e8: f94002a0    	ldr	x0, [x21]
1014787ec: 52800022    	mov	w2, #0x1                ; =1
1014787f0: 97d897bb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014787f4: 17fffff8    	b	0x1014787d4 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x1a0>
1014787f8: f94013e8    	ldr	x8, [sp, #0x20]
1014787fc: b40000c8    	cbz	x8, 0x101478814 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x1e0>
101478800: 8b080508    	add	x8, x8, x8, lsl #1
101478804: d37df101    	lsl	x1, x8, #3
101478808: aa1303e0    	mov	x0, x19
10147880c: 52800102    	mov	w2, #0x8                ; =8
101478810: 97d897b3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478814: f9401fe1    	ldr	x1, [sp, #0x38]
101478818: b4000081    	cbz	x1, 0x101478828 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x1f4>
10147881c: f94023e0    	ldr	x0, [sp, #0x40]
101478820: 52800022    	mov	w2, #0x1                ; =1
101478824: 97d897ae    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478828: f9402be1    	ldr	x1, [sp, #0x50]
10147882c: b4000081    	cbz	x1, 0x10147883c <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x208>
101478830: f9402fe0    	ldr	x0, [sp, #0x58]
101478834: 52800022    	mov	w2, #0x1                ; =1
101478838: 97d897a9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147883c: a94753f3    	ldp	x19, x20, [sp, #0x70]
101478840: b4000194    	cbz	x20, 0x101478870 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x23c>
101478844: 91002275    	add	x21, x19, #0x8
101478848: 14000004    	b	0x101478858 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x224>
10147884c: 910082b5    	add	x21, x21, #0x20
101478850: f1000694    	subs	x20, x20, #0x1
101478854: 540000e0    	b.eq	0x101478870 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x23c>
101478858: f85f82a1    	ldur	x1, [x21, #-0x8]
10147885c: b4ffff81    	cbz	x1, 0x10147884c <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x218>
101478860: f94002a0    	ldr	x0, [x21]
101478864: 52800022    	mov	w2, #0x1                ; =1
101478868: 97d8979d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147886c: 17fffff8    	b	0x10147884c <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x218>
101478870: f94037e8    	ldr	x8, [sp, #0x68]
101478874: b4000188    	cbz	x8, 0x1014788a4 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x270>
101478878: d37be901    	lsl	x1, x8, #5
10147887c: aa1303e0    	mov	x0, x19
101478880: 52800102    	mov	w2, #0x8                ; =8
101478884: a9517bfd    	ldp	x29, x30, [sp, #0x110]
101478888: a9504ff4    	ldp	x20, x19, [sp, #0x100]
10147888c: a94f57f6    	ldp	x22, x21, [sp, #0xf0]
101478890: a94e5ff8    	ldp	x24, x23, [sp, #0xe0]
101478894: a94d67fa    	ldp	x26, x25, [sp, #0xd0]
101478898: a94c6ffc    	ldp	x28, x27, [sp, #0xc0]
10147889c: 910483ff    	add	sp, sp, #0x120
1014788a0: 17d8978f    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014788a4: a9517bfd    	ldp	x29, x30, [sp, #0x110]
1014788a8: a9504ff4    	ldp	x20, x19, [sp, #0x100]
1014788ac: a94f57f6    	ldp	x22, x21, [sp, #0xf0]
1014788b0: a94e5ff8    	ldp	x24, x23, [sp, #0xe0]
1014788b4: a94d67fa    	ldp	x26, x25, [sp, #0xd0]
1014788b8: a94c6ffc    	ldp	x28, x27, [sp, #0xc0]
1014788bc: 910483ff    	add	sp, sp, #0x120
1014788c0: d65f03c0    	ret
1014788c4: 52800100    	mov	w0, #0x8                ; =8
1014788c8: 52800c01    	mov	w1, #0x60               ; =96
1014788cc: 94192aaa    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014788d0: d4200020    	brk	#0x1
1014788d4: aa0003f3    	mov	x19, x0
1014788d8: b40000f6    	cbz	x22, 0x1014788f4 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x2c0>
1014788dc: aa1703e0    	mov	x0, x23
1014788e0: aa1603e1    	mov	x1, x22
1014788e4: 52800022    	mov	w2, #0x1                ; =1
1014788e8: 97d8977d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014788ec: 14000002    	b	0x1014788f4 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x2c0>
1014788f0: aa0003f3    	mov	x19, x0
1014788f4: 910223e0    	add	x0, sp, #0x88
1014788f8: 97d32885    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
1014788fc: 14000009    	b	0x101478920 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x2ec>
101478900: aa0003f3    	mov	x19, x0
101478904: b40000f6    	cbz	x22, 0x101478920 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x2ec>
101478908: aa1403e0    	mov	x0, x20
10147890c: aa1603e1    	mov	x1, x22
101478910: 52800022    	mov	w2, #0x1                ; =1
101478914: 97d89772    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478918: 14000002    	b	0x101478920 <__ZN15otty_ssh_config17config_host_names17h30cc506ac7bc98ebE+0x2ec>
10147891c: aa0003f3    	mov	x19, x0
101478920: 910023e0    	add	x0, sp, #0x8
101478924: 94004679    	bl	0x10148a308 <__ZN3std2io5error5Error3new17h519eec155b6ed967E+0x358>
101478928: 9100e3e0    	add	x0, sp, #0x38
10147892c: 97d30970    	bl	0x10093aeec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x27ec4>
101478930: aa1303e0    	mov	x0, x19
101478934: 94194328    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101478938: aa0003f3    	mov	x19, x0
10147893c: 9100e3e0    	add	x0, sp, #0x38
101478940: 97d3096b    	bl	0x10093aeec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x27ec4>
101478944: aa1303e0    	mov	x0, x19
101478948: 94194323    	bl	0x101ac95d4 <_writev+0x101ac95d4>

000000010147894c <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE>:
10147894c: d10603ff    	sub	sp, sp, #0x180
101478950: a9126ffc    	stp	x28, x27, [sp, #0x120]
101478954: a91367fa    	stp	x26, x25, [sp, #0x130]
101478958: a9145ff8    	stp	x24, x23, [sp, #0x140]
10147895c: a91557f6    	stp	x22, x21, [sp, #0x150]
101478960: a9164ff4    	stp	x20, x19, [sp, #0x160]
101478964: a9177bfd    	stp	x29, x30, [sp, #0x170]
101478968: 9105c3fd    	add	x29, sp, #0x170
10147896c: aa0303f4    	mov	x20, x3
101478970: aa0203f5    	mov	x21, x2
101478974: aa0003f6    	mov	x22, x0
101478978: aa0803f3    	mov	x19, x8
10147897c: 90007820    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101478980: 9131a000    	add	x0, x0, #0xc68
101478984: f9400008    	ldr	x8, [x0]
101478988: d63f0100    	blr	x8
10147898c: 39404008    	ldrb	w8, [x0, #0x10]
101478990: 7100051f    	cmp	w8, #0x1
101478994: 54001e01    	b.ne	0x101478d54 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x408>
101478998: a9402408    	ldp	x8, x9, [x0]
10147899c: 9100050a    	add	x10, x8, #0x1
1014789a0: f900000a    	str	x10, [x0]
1014789a4: d0006f8a    	adrp	x10, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
1014789a8: 9125014a    	add	x10, x10, #0x940
1014789ac: ad400540    	ldp	q0, q1, [x10]
1014789b0: ad0007e0    	stp	q0, q1, [sp]
1014789b4: a90227e8    	stp	x8, x9, [sp, #0x20]
1014789b8: 910203e8    	add	x8, sp, #0x80
1014789bc: aa1603e0    	mov	x0, x22
1014789c0: 94000711    	bl	0x10147a604 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E>
1014789c4: 9100c3e8    	add	x8, sp, #0x30
1014789c8: 910203e0    	add	x0, sp, #0x80
1014789cc: aa1503e1    	mov	x1, x21
1014789d0: aa1403e2    	mov	x2, x20
1014789d4: 9400069a    	bl	0x10147a43c <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E>
1014789d8: 910203e8    	add	x8, sp, #0x80
1014789dc: 9100c3e0    	add	x0, sp, #0x30
1014789e0: 940007b6    	bl	0x10147a8b8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E>
1014789e4: f9404be8    	ldr	x8, [sp, #0x90]
1014789e8: b4000408    	cbz	x8, 0x101478a68 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x11c>
1014789ec: f94047e9    	ldr	x9, [sp, #0x88]
1014789f0: 5280250a    	mov	w10, #0x128             ; =296
1014789f4: 9b0a7d17    	mul	x23, x8, x10
1014789f8: 8b170138    	add	x24, x9, x23
1014789fc: 9104a139    	add	x25, x9, #0x128
101478a00: d2f00014    	mov	x20, #-0x8000000000000000 ; =-9223372036854775808
101478a04: 14000006    	b	0x101478a1c <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0xd0>
101478a08: eb1402bf    	cmp	x21, x20
101478a0c: 540011a1    	b.ne	0x101478c40 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x2f4>
101478a10: 9104a339    	add	x25, x25, #0x128
101478a14: f104a2f7    	subs	x23, x23, #0x128
101478a18: 54000280    	b.eq	0x101478a68 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x11c>
101478a1c: 385f7328    	ldurb	w8, [x25, #-0x9]
101478a20: 3707ff88    	tbnz	w8, #0x0, 0x101478a10 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0xc4>
101478a24: d104a320    	sub	x0, x25, #0x128
101478a28: d10223a8    	sub	x8, x29, #0x88
101478a2c: 940e59e8    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101478a30: d101c3a8    	sub	x8, x29, #0x70
101478a34: d10223a0    	sub	x0, x29, #0x88
101478a38: 940e59e5    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101478a3c: 910003e0    	mov	x0, sp
101478a40: d101c3a1    	sub	x1, x29, #0x70
101478a44: 94005424    	bl	0x10148dad4 <__ZN4core5slice4sort6stable9quicksort9quicksort17h1ad04638c7ce3510E+0x1b3c>
101478a48: f85783b5    	ldur	x21, [x29, #-0x88]
101478a4c: 34fffde0    	cbz	w0, 0x101478a08 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0xbc>
101478a50: b4fffe15    	cbz	x21, 0x101478a10 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0xc4>
101478a54: f85803a0    	ldur	x0, [x29, #-0x80]
101478a58: aa1503e1    	mov	x1, x21
101478a5c: 52800022    	mov	w2, #0x1                ; =1
101478a60: 97d8971f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478a64: 17ffffeb    	b	0x101478a10 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0xc4>
101478a68: 52800108    	mov	w8, #0x8                ; =8
101478a6c: a900227f    	stp	xzr, x8, [x19]
101478a70: f9000a7f    	str	xzr, [x19, #0x10]
101478a74: f94007f3    	ldr	x19, [sp, #0x8]
101478a78: b4000553    	cbz	x19, 0x101478b20 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x1d4>
101478a7c: f9400ff4    	ldr	x20, [sp, #0x18]
101478a80: b40003d4    	cbz	x20, 0x101478af8 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x1ac>
101478a84: f94003f5    	ldr	x21, [sp]
101478a88: aa1503f6    	mov	x22, x21
101478a8c: fc4086c0    	ldr	d0, [x22], #0x8
101478a90: 2e208800    	cmge.8b	v0, v0, #0
101478a94: 9e660008    	fmov	x8, d0
101478a98: 9201c118    	and	x24, x8, #0x8080808080808080
101478a9c: 52800317    	mov	w23, #0x18              ; =24
101478aa0: 14000005    	b	0x101478ab4 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x168>
101478aa4: d1000708    	sub	x8, x24, #0x1
101478aa8: 8a180118    	and	x24, x8, x24
101478aac: d1000694    	sub	x20, x20, #0x1
101478ab0: b4000254    	cbz	x20, 0x101478af8 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x1ac>
101478ab4: b50000f8    	cbnz	x24, 0x101478ad0 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x184>
101478ab8: fc4086c0    	ldr	d0, [x22], #0x8
101478abc: 2e208800    	cmge.8b	v0, v0, #0
101478ac0: 9e660008    	fmov	x8, d0
101478ac4: d10302b5    	sub	x21, x21, #0xc0
101478ac8: 9201c118    	and	x24, x8, #0x8080808080808080
101478acc: b4ffff78    	cbz	x24, 0x101478ab8 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x16c>
101478ad0: dac00308    	rbit	x8, x24
101478ad4: dac01108    	clz	x8, x8
101478ad8: cb480fe8    	neg	x8, x8, lsr #3
101478adc: 9b375508    	smaddl	x8, w8, w23, x21
101478ae0: f85e8101    	ldur	x1, [x8, #-0x18]
101478ae4: b4fffe01    	cbz	x1, 0x101478aa4 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x158>
101478ae8: f85f0100    	ldur	x0, [x8, #-0x10]
101478aec: 52800022    	mov	w2, #0x1                ; =1
101478af0: 97d896fb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478af4: 17ffffec    	b	0x101478aa4 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x158>
101478af8: 8b130668    	add	x8, x19, x19, lsl #1
101478afc: d37df108    	lsl	x8, x8, #3
101478b00: 8b130109    	add	x9, x8, x19
101478b04: b1008521    	adds	x1, x9, #0x21
101478b08: 540000c0    	b.eq	0x101478b20 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x1d4>
101478b0c: f94003e9    	ldr	x9, [sp]
101478b10: cb080128    	sub	x8, x9, x8
101478b14: d1006100    	sub	x0, x8, #0x18
101478b18: 52800102    	mov	w2, #0x8                ; =8
101478b1c: 97d896f0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478b20: a948d7f3    	ldp	x19, x21, [sp, #0x88]
101478b24: b40000f5    	cbz	x21, 0x101478b40 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x1f4>
101478b28: aa1303f4    	mov	x20, x19
101478b2c: aa1403e0    	mov	x0, x20
101478b30: 94004585    	bl	0x10148a144 <__ZN3std2io5error5Error3new17h519eec155b6ed967E+0x194>
101478b34: 9104a294    	add	x20, x20, #0x128
101478b38: f10006b5    	subs	x21, x21, #0x1
101478b3c: 54ffff81    	b.ne	0x101478b2c <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x1e0>
101478b40: f94043e8    	ldr	x8, [sp, #0x80]
101478b44: b40000c8    	cbz	x8, 0x101478b5c <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x210>
101478b48: 52802509    	mov	w9, #0x128              ; =296
101478b4c: 9b097d01    	mul	x1, x8, x9
101478b50: aa1303e0    	mov	x0, x19
101478b54: 52800102    	mov	w2, #0x8                ; =8
101478b58: 97d896e1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478b5c: a94a53f3    	ldp	x19, x20, [sp, #0xa0]
101478b60: b4000194    	cbz	x20, 0x101478b90 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x244>
101478b64: 91002275    	add	x21, x19, #0x8
101478b68: 14000004    	b	0x101478b78 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x22c>
101478b6c: 910062b5    	add	x21, x21, #0x18
101478b70: f1000694    	subs	x20, x20, #0x1
101478b74: 540000e0    	b.eq	0x101478b90 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x244>
101478b78: f85f82a1    	ldur	x1, [x21, #-0x8]
101478b7c: b4ffff81    	cbz	x1, 0x101478b6c <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x220>
101478b80: f94002a0    	ldr	x0, [x21]
101478b84: 52800022    	mov	w2, #0x1                ; =1
101478b88: 97d896d5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478b8c: 17fffff8    	b	0x101478b6c <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x220>
101478b90: f9404fe8    	ldr	x8, [sp, #0x98]
101478b94: b40000c8    	cbz	x8, 0x101478bac <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x260>
101478b98: 8b080508    	add	x8, x8, x8, lsl #1
101478b9c: d37df101    	lsl	x1, x8, #3
101478ba0: aa1303e0    	mov	x0, x19
101478ba4: 52800102    	mov	w2, #0x8                ; =8
101478ba8: 97d896cd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478bac: f9401be1    	ldr	x1, [sp, #0x30]
101478bb0: b4000081    	cbz	x1, 0x101478bc0 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x274>
101478bb4: f9401fe0    	ldr	x0, [sp, #0x38]
101478bb8: 52800022    	mov	w2, #0x1                ; =1
101478bbc: 97d896c8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478bc0: f94027e1    	ldr	x1, [sp, #0x48]
101478bc4: b4000081    	cbz	x1, 0x101478bd4 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x288>
101478bc8: f9402be0    	ldr	x0, [sp, #0x50]
101478bcc: 52800022    	mov	w2, #0x1                ; =1
101478bd0: 97d896c3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478bd4: a946d3f3    	ldp	x19, x20, [sp, #0x68]
101478bd8: b4000194    	cbz	x20, 0x101478c08 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x2bc>
101478bdc: 91002275    	add	x21, x19, #0x8
101478be0: 14000004    	b	0x101478bf0 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x2a4>
101478be4: 910082b5    	add	x21, x21, #0x20
101478be8: f1000694    	subs	x20, x20, #0x1
101478bec: 540000e0    	b.eq	0x101478c08 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x2bc>
101478bf0: f85f82a1    	ldur	x1, [x21, #-0x8]
101478bf4: b4ffff81    	cbz	x1, 0x101478be4 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x298>
101478bf8: f94002a0    	ldr	x0, [x21]
101478bfc: 52800022    	mov	w2, #0x1                ; =1
101478c00: 97d896b7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478c04: 17fffff8    	b	0x101478be4 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x298>
101478c08: f94033e8    	ldr	x8, [sp, #0x60]
101478c0c: b40000a8    	cbz	x8, 0x101478c20 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x2d4>
101478c10: d37be901    	lsl	x1, x8, #5
101478c14: aa1303e0    	mov	x0, x19
101478c18: 52800102    	mov	w2, #0x8                ; =8
101478c1c: 97d896b0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478c20: a9577bfd    	ldp	x29, x30, [sp, #0x170]
101478c24: a9564ff4    	ldp	x20, x19, [sp, #0x160]
101478c28: a95557f6    	ldp	x22, x21, [sp, #0x150]
101478c2c: a9545ff8    	ldp	x24, x23, [sp, #0x140]
101478c30: a95367fa    	ldp	x26, x25, [sp, #0x130]
101478c34: a9526ffc    	ldp	x28, x27, [sp, #0x120]
101478c38: 910603ff    	add	sp, sp, #0x180
101478c3c: d65f03c0    	ret
101478c40: a9786bb6    	ldp	x22, x26, [x29, #-0x80]
101478c44: 97d896ab    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101478c48: 52800c00    	mov	w0, #0x60               ; =96
101478c4c: 52800101    	mov	w1, #0x8                ; =8
101478c50: 97d896a2    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101478c54: b4000960    	cbz	x0, 0x101478d80 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x434>
101478c58: aa0003f4    	mov	x20, x0
101478c5c: a9005815    	stp	x21, x22, [x0]
101478c60: f900081a    	str	x26, [x0, #0x10]
101478c64: 52800088    	mov	w8, #0x4                ; =4
101478c68: a93603a8    	stp	x8, x0, [x29, #-0xa0]
101478c6c: 52800028    	mov	w8, #0x1                ; =1
101478c70: f81703a8    	stur	x8, [x29, #-0x90]
101478c74: f104a2ff    	cmp	x23, #0x128
101478c78: 54000600    	b.eq	0x101478d38 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x3ec>
101478c7c: 52800035    	mov	w21, #0x1               ; =1
101478c80: d2f0001a    	mov	x26, #-0x8000000000000000 ; =-9223372036854775808
101478c84: 5280031b    	mov	w27, #0x18              ; =24
101478c88: 9104a339    	add	x25, x25, #0x128
101478c8c: 14000006    	b	0x101478ca4 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x358>
101478c90: eb1a02df    	cmp	x22, x26
101478c94: 540002e1    	b.ne	0x101478cf0 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x3a4>
101478c98: eb18033f    	cmp	x25, x24
101478c9c: 9104a339    	add	x25, x25, #0x128
101478ca0: 540004c0    	b.eq	0x101478d38 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x3ec>
101478ca4: 385f7328    	ldurb	w8, [x25, #-0x9]
101478ca8: 3707ff88    	tbnz	w8, #0x0, 0x101478c98 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x34c>
101478cac: d104a320    	sub	x0, x25, #0x128
101478cb0: d10223a8    	sub	x8, x29, #0x88
101478cb4: 940e5946    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101478cb8: d101c3a8    	sub	x8, x29, #0x70
101478cbc: d10223a0    	sub	x0, x29, #0x88
101478cc0: 940e5943    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101478cc4: 910003e0    	mov	x0, sp
101478cc8: d101c3a1    	sub	x1, x29, #0x70
101478ccc: 94005382    	bl	0x10148dad4 <__ZN4core5slice4sort6stable9quicksort9quicksort17h1ad04638c7ce3510E+0x1b3c>
101478cd0: f85783b6    	ldur	x22, [x29, #-0x88]
101478cd4: 34fffde0    	cbz	w0, 0x101478c90 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x344>
101478cd8: b4fffe16    	cbz	x22, 0x101478c98 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x34c>
101478cdc: f85803a0    	ldur	x0, [x29, #-0x80]
101478ce0: aa1603e1    	mov	x1, x22
101478ce4: 52800022    	mov	w2, #0x1                ; =1
101478ce8: 97d8967d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478cec: 17ffffeb    	b	0x101478c98 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x34c>
101478cf0: a97873b7    	ldp	x23, x28, [x29, #-0x80]
101478cf4: f85603a8    	ldur	x8, [x29, #-0xa0]
101478cf8: eb0802bf    	cmp	x21, x8
101478cfc: 54000101    	b.ne	0x101478d1c <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x3d0>
101478d00: d10283a0    	sub	x0, x29, #0xa0
101478d04: aa1503e1    	mov	x1, x21
101478d08: 52800022    	mov	w2, #0x1                ; =1
101478d0c: 52800103    	mov	w3, #0x8                ; =8
101478d10: 52800304    	mov	w4, #0x18               ; =24
101478d14: 9416becf    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101478d18: f85683b4    	ldur	x20, [x29, #-0x98]
101478d1c: 9b1b52a8    	madd	x8, x21, x27, x20
101478d20: a9005d16    	stp	x22, x23, [x8]
101478d24: f900091c    	str	x28, [x8, #0x10]
101478d28: 910006b5    	add	x21, x21, #0x1
101478d2c: f81703b5    	stur	x21, [x29, #-0x90]
101478d30: eb18033f    	cmp	x25, x24
101478d34: 54fffaa1    	b.ne	0x101478c88 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x33c>
101478d38: 3cd603a0    	ldur	q0, [x29, #-0xa0]
101478d3c: 3d800260    	str	q0, [x19]
101478d40: f85703a8    	ldur	x8, [x29, #-0x90]
101478d44: f9000a68    	str	x8, [x19, #0x10]
101478d48: f94007f3    	ldr	x19, [sp, #0x8]
101478d4c: b5ffe993    	cbnz	x19, 0x101478a7c <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x130>
101478d50: 17ffff74    	b	0x101478b20 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x1d4>
101478d54: aa0103f7    	mov	x23, x1
101478d58: aa0003f8    	mov	x24, x0
101478d5c: 940d1b0b    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101478d60: aa0003e8    	mov	x8, x0
101478d64: aa1803e0    	mov	x0, x24
101478d68: aa0103e9    	mov	x9, x1
101478d6c: aa1703e1    	mov	x1, x23
101478d70: f9000709    	str	x9, [x24, #0x8]
101478d74: 5280002a    	mov	w10, #0x1               ; =1
101478d78: 3900430a    	strb	w10, [x24, #0x10]
101478d7c: 17ffff08    	b	0x10147899c <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x50>
101478d80: 52800100    	mov	w0, #0x8                ; =8
101478d84: 52800c01    	mov	w1, #0x60               ; =96
101478d88: 9419297b    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101478d8c: d4200020    	brk	#0x1
101478d90: aa0003f3    	mov	x19, x0
101478d94: b40003b6    	cbz	x22, 0x101478e08 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x4bc>
101478d98: aa1703e0    	mov	x0, x23
101478d9c: aa1603e1    	mov	x1, x22
101478da0: 14000018    	b	0x101478e00 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x4b4>
101478da4: aa0003f3    	mov	x19, x0
101478da8: b4000475    	cbz	x21, 0x101478e34 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x4e8>
101478dac: aa1603e0    	mov	x0, x22
101478db0: aa1503e1    	mov	x1, x21
101478db4: 1400001e    	b	0x101478e2c <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x4e0>
101478db8: aa0003f3    	mov	x19, x0
101478dbc: 910003e0    	mov	x0, sp
101478dc0: 97d33f27    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
101478dc4: 9100c3e0    	add	x0, sp, #0x30
101478dc8: 97d30849    	bl	0x10093aeec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x27ec4>
101478dcc: aa1303e0    	mov	x0, x19
101478dd0: 94194201    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101478dd4: aa0003f3    	mov	x19, x0
101478dd8: 1400000c    	b	0x101478e08 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x4bc>
101478ddc: aa0003f3    	mov	x19, x0
101478de0: 910003e0    	mov	x0, sp
101478de4: 97d33f1e    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
101478de8: aa1303e0    	mov	x0, x19
101478dec: 941941fa    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101478df0: aa0003f3    	mov	x19, x0
101478df4: f85783a1    	ldur	x1, [x29, #-0x88]
101478df8: b4000081    	cbz	x1, 0x101478e08 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x4bc>
101478dfc: f85803a0    	ldur	x0, [x29, #-0x80]
101478e00: 52800022    	mov	w2, #0x1                ; =1
101478e04: 97d89636    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478e08: d10283a0    	sub	x0, x29, #0xa0
101478e0c: 97d32740    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101478e10: 14000009    	b	0x101478e34 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x4e8>
101478e14: aa0003f3    	mov	x19, x0
101478e18: 14000007    	b	0x101478e34 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x4e8>
101478e1c: aa0003f3    	mov	x19, x0
101478e20: f85783a1    	ldur	x1, [x29, #-0x88]
101478e24: b4000081    	cbz	x1, 0x101478e34 <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE+0x4e8>
101478e28: f85803a0    	ldur	x0, [x29, #-0x80]
101478e2c: 52800022    	mov	w2, #0x1                ; =1
101478e30: 97d8962b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101478e34: 910003e0    	mov	x0, sp
101478e38: 97d33f09    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
101478e3c: 910203e0    	add	x0, sp, #0x80
101478e40: 94004532    	bl	0x10148a308 <__ZN3std2io5error5Error3new17h519eec155b6ed967E+0x358>
101478e44: 9100c3e0    	add	x0, sp, #0x30
101478e48: 97d30829    	bl	0x10093aeec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x27ec4>
101478e4c: aa1303e0    	mov	x0, x19
101478e50: 941941e1    	bl	0x101ac95d4 <_writev+0x101ac95d4>
