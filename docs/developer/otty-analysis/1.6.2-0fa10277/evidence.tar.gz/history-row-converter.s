
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010140b34c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E>:
10140d7e4: d102c3ff    	sub	sp, sp, #0xb0
10140d7e8: 6d0423e9    	stp	d9, d8, [sp, #0x40]
10140d7ec: a9056ffc    	stp	x28, x27, [sp, #0x50]
10140d7f0: a90667fa    	stp	x26, x25, [sp, #0x60]
10140d7f4: a9075ff8    	stp	x24, x23, [sp, #0x70]
10140d7f8: a90857f6    	stp	x22, x21, [sp, #0x80]
10140d7fc: a9094ff4    	stp	x20, x19, [sp, #0x90]
10140d800: a90a7bfd    	stp	x29, x30, [sp, #0xa0]
10140d804: 910283fd    	add	x29, sp, #0xa0
10140d808: aa0103f4    	mov	x20, x1
10140d80c: f90007e0    	str	x0, [sp, #0x8]
10140d810: d2800279    	mov	x25, #0x13              ; =19
10140d814: f2f00019    	movk	x25, #0x8000, lsl #48
10140d818: 910043f8    	add	x24, sp, #0x10
10140d81c: 5280003a    	mov	w26, #0x1               ; =1
10140d820: 2f00e408    	movi	d8, #0000000000000000
10140d824: 14000008    	b	0x10140d844 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x24f8>
10140d828: a941dff5    	ldp	x21, x23, [sp, #0x18]
10140d82c: a942cffb    	ldp	x27, x19, [sp, #0x28]
10140d830: a90173fa    	stp	x26, x28, [sp, #0x10]
10140d834: a9025ff5    	stp	x21, x23, [sp, #0x20]
10140d838: a9034ffb    	stp	x27, x19, [sp, #0x30]
10140d83c: 91002300    	add	x0, x24, #0x8
10140d840: 9401173d    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
10140d844: 910043e0    	add	x0, sp, #0x10
10140d848: 91002281    	add	x1, x20, #0x8
10140d84c: 94019ed8    	bl	0x1014753ac <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x801c>
10140d850: f9400bfc    	ldr	x28, [sp, #0x10]
10140d854: eb19039f    	cmp	x28, x25
10140d858: 54fffe81    	b.ne	0x10140d828 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x24dc>
10140d85c: f9400a97    	ldr	x23, [x20, #0x10]
10140d860: b40008b7    	cbz	x23, 0x10140d974 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2628>
10140d864: f9400293    	ldr	x19, [x20]
10140d868: 910043e0    	add	x0, sp, #0x10
10140d86c: aa1703e1    	mov	x1, x23
10140d870: d2800002    	mov	x2, #0x0                ; =0
10140d874: 94019bc1    	bl	0x101474778 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x73e8>
10140d878: a94157fc    	ldp	x28, x21, [sp, #0x10]
10140d87c: a9426ff6    	ldp	x22, x27, [sp, #0x20]
10140d880: eb19039f    	cmp	x28, x25
10140d884: 54000541    	b.ne	0x10140d92c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x25e0>
10140d888: 910043e0    	add	x0, sp, #0x10
10140d88c: aa1703e1    	mov	x1, x23
10140d890: 52800022    	mov	w2, #0x1                ; =1
10140d894: 94019cd0    	bl	0x101474bd4 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x7844>
10140d898: f9400bfc    	ldr	x28, [sp, #0x10]
10140d89c: fd400fe9    	ldr	d9, [sp, #0x18]
10140d8a0: eb19039f    	cmp	x28, x25
10140d8a4: 540004a1    	b.ne	0x10140d938 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x25ec>
10140d8a8: 910043e0    	add	x0, sp, #0x10
10140d8ac: aa1703e1    	mov	x1, x23
10140d8b0: 52800042    	mov	w2, #0x2                ; =2
10140d8b4: 94019b5c    	bl	0x101474624 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x7294>
10140d8b8: a94163fc    	ldp	x28, x24, [sp, #0x10]
10140d8bc: eb19039f    	cmp	x28, x25
10140d8c0: 54000521    	b.ne	0x10140d964 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2618>
10140d8c4: f9400268    	ldr	x8, [x19]
10140d8c8: cb180108    	sub	x8, x8, x24
10140d8cc: 9e620100    	scvtf	d0, x8
10140d8d0: d2c40008    	mov	x8, #0x200000000000     ; =35184372088832
10140d8d4: f2e81588    	movk	x8, #0x40ac, lsl #48
10140d8d8: 9e670101    	fmov	d1, x8
10140d8dc: 1e611800    	fdiv	d0, d0, d1
10140d8e0: 1e686800    	fmaxnm	d0, d0, d8
10140d8e4: d2d00008    	mov	x8, #0x800000000000     ; =140737488355328
10140d8e8: f2e810c8    	movk	x8, #0x4086, lsl #48
10140d8ec: 9e670101    	fmov	d1, x8
10140d8f0: 1e617801    	fminnm	d1, d0, d1
10140d8f4: b203e7e8    	mov	x8, #0x6666666666666666 ; =7378697629483820646
10140d8f8: f2e7fdc8    	movk	x8, #0x3fee, lsl #48
10140d8fc: 9e670100    	fmov	d0, x8
10140d900: 941af169    	bl	0x101ac9ea4 <_writev+0x101ac9ea4>
10140d904: 1e600920    	fmul	d0, d9, d0
10140d908: a90157ff    	stp	xzr, x21, [sp, #0x10]
10140d90c: a9026ff6    	stp	x22, x27, [sp, #0x20]
10140d910: fd001be0    	str	d0, [sp, #0x30]
10140d914: f9001ff8    	str	x24, [sp, #0x38]
10140d918: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140d91c: eb0802bf    	cmp	x21, x8
10140d920: 910043f8    	add	x24, sp, #0x10
10140d924: 54fff900    	b.eq	0x10140d844 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x24f8>
10140d928: 1400001f    	b	0x10140d9a4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2658>
10140d92c: f9401bf3    	ldr	x19, [sp, #0x30]
10140d930: aa1603f7    	mov	x23, x22
10140d934: 17ffffbf    	b	0x10140d830 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x24e4>
10140d938: a9426ff7    	ldp	x23, x27, [sp, #0x20]
10140d93c: 9e660138    	fmov	x24, d9
10140d940: f9401bf3    	ldr	x19, [sp, #0x30]
10140d944: b40000b5    	cbz	x21, 0x10140d958 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x260c>
10140d948: aa1603e0    	mov	x0, x22
10140d94c: aa1503e1    	mov	x1, x21
10140d950: 52800022    	mov	w2, #0x1                ; =1
10140d954: 97da4362    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140d958: aa1803f5    	mov	x21, x24
10140d95c: 910043f8    	add	x24, sp, #0x10
10140d960: 17ffffb4    	b	0x10140d830 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x24e4>
10140d964: a9426ff7    	ldp	x23, x27, [sp, #0x20]
10140d968: f9401bf3    	ldr	x19, [sp, #0x30]
10140d96c: b5fffef5    	cbnz	x21, 0x10140d948 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x25fc>
10140d970: 17fffffa    	b	0x10140d958 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x260c>
10140d974: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140d978: f94007e9    	ldr	x9, [sp, #0x8]
10140d97c: f9000128    	str	x8, [x9]
10140d980: a94a7bfd    	ldp	x29, x30, [sp, #0xa0]
10140d984: a9494ff4    	ldp	x20, x19, [sp, #0x90]
10140d988: a94857f6    	ldp	x22, x21, [sp, #0x80]
10140d98c: a9475ff8    	ldp	x24, x23, [sp, #0x70]
10140d990: a94667fa    	ldp	x26, x25, [sp, #0x60]
10140d994: a9456ffc    	ldp	x28, x27, [sp, #0x50]
10140d998: 6d4423e9    	ldp	d9, d8, [sp, #0x40]
10140d99c: 9102c3ff    	add	sp, sp, #0xb0
10140d9a0: d65f03c0    	ret
10140d9a4: 3cc18300    	ldur	q0, [x24, #0x18]
10140d9a8: f94007e9    	ldr	x9, [sp, #0x8]
10140d9ac: 3d800520    	str	q0, [x9, #0x10]
10140d9b0: f8428308    	ldur	x8, [x24, #0x28]
10140d9b4: f9001128    	str	x8, [x9, #0x20]
10140d9b8: a9005935    	stp	x21, x22, [x9]
10140d9bc: 17fffff1    	b	0x10140d980 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2634>
10140d9c0: 14000001    	b	0x10140d9c4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2678>
10140d9c4: aa0003f3    	mov	x19, x0
10140d9c8: b40000b5    	cbz	x21, 0x10140d9dc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2690>
10140d9cc: aa1603e0    	mov	x0, x22
10140d9d0: aa1503e1    	mov	x1, x21
10140d9d4: 52800022    	mov	w2, #0x1                ; =1
10140d9d8: 97da4341    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140d9dc: aa1303e0    	mov	x0, x19
10140d9e0: 941aeefd    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140d9e4: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10140d9e8: a90167fa    	stp	x26, x25, [sp, #0x10]
10140d9ec: a9025ff8    	stp	x24, x23, [sp, #0x20]
10140d9f0: a90357f6    	stp	x22, x21, [sp, #0x30]
10140d9f4: a9044ff4    	stp	x20, x19, [sp, #0x40]
10140d9f8: a9057bfd    	stp	x29, x30, [sp, #0x50]
10140d9fc: 910143fd    	add	x29, sp, #0x50
10140da00: d13283ff    	sub	sp, sp, #0xca0
10140da04: f90003ff    	str	xzr, [sp]
10140da08: aa0003f3    	mov	x19, x0
10140da0c: 39616028    	ldrb	w8, [x1, #0x858]
10140da10: 7100091f    	cmp	w8, #0x2
10140da14: 54000e00    	b.eq	0x10140dbd4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2888>
10140da18: aa0103f4    	mov	x20, x1
10140da1c: 91214035    	add	x21, x1, #0x850
10140da20: 910003f9    	mov	x25, sp
10140da24: 910003e8    	mov	x8, sp
10140da28: aa1503e0    	mov	x0, x21
10140da2c: 940f7059    	bl	0x1017e9b90 <__ZN75_$LT$std..fs..ReadDir$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h8142713fd293396eE>
10140da30: b94003e8    	ldr	w8, [sp]
10140da34: 7100051f    	cmp	w8, #0x1
10140da38: 54000b41    	b.ne	0x10140dba0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2854>
10140da3c: 912123fb    	add	x27, sp, #0x848
10140da40: d2f0001c    	mov	x28, #-0x8000000000000000 ; =-9223372036854775808
10140da44: 9280001a    	mov	x26, #-0x1              ; =-1
10140da48: 14000008    	b	0x10140da68 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x271c>
10140da4c: eb1c02df    	cmp	x22, x28
10140da50: 54000d61    	b.ne	0x10140dbfc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x28b0>
10140da54: 910003e8    	mov	x8, sp
10140da58: aa1503e0    	mov	x0, x21
10140da5c: 940f704d    	bl	0x1017e9b90 <__ZN75_$LT$std..fs..ReadDir$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h8142713fd293396eE>
10140da60: b94003e8    	ldr	w8, [sp]
10140da64: 360009e8    	tbz	w8, #0x0, 0x10140dba0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2854>
10140da68: a940dbf7    	ldp	x23, x22, [sp, #0x8]
10140da6c: b40004f7    	cbz	x23, 0x10140db08 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x27bc>
10140da70: f9021bf6    	str	x22, [sp, #0x430]
10140da74: 9110a3e8    	add	x8, sp, #0x428
10140da78: 91004100    	add	x0, x8, #0x10
10140da7c: 91006321    	add	x1, x25, #0x18
10140da80: 52808202    	mov	w2, #0x410              ; =1040
10140da84: 941af069    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10140da88: f90217ff    	str	xzr, [sp, #0x428]
10140da8c: f9042bf6    	str	x22, [sp, #0x850]
10140da90: 91004360    	add	x0, x27, #0x10
10140da94: 91006321    	add	x1, x25, #0x18
10140da98: 52808202    	mov	w2, #0x410              ; =1040
10140da9c: 941af063    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10140daa0: f90427f7    	str	x23, [sp, #0x848]
10140daa4: d10223a8    	sub	x8, x29, #0x88
10140daa8: 912123e0    	add	x0, sp, #0x848
10140daac: 940e8ec2    	bl	0x1017b15b4 <__ZN3std2fs8DirEntry9file_name17h6382942abec15980E>
10140dab0: a977dfb6    	ldp	x22, x23, [x29, #-0x88]
10140dab4: f85883b8    	ldur	x24, [x29, #-0x78]
10140dab8: d101c3a8    	sub	x8, x29, #0x70
10140dabc: aa1703e0    	mov	x0, x23
10140dac0: aa1803e1    	mov	x1, x24
10140dac4: 94105c7d    	bl	0x101824cb8 <__ZN4core3str8converts9from_utf817ha54c467cc832e2ffE>
10140dac8: b85903a8    	ldur	w8, [x29, #-0x70]
10140dacc: 360000e8    	tbz	w8, #0x0, 0x10140dae8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x279c>
10140dad0: eb1c02df    	cmp	x22, x28
10140dad4: 54000401    	b.ne	0x10140db54 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2808>
10140dad8: aa1703f6    	mov	x22, x23
10140dadc: f85983a8    	ldur	x8, [x29, #-0x68]
10140dae0: aa1803f7    	mov	x23, x24
10140dae4: aa0803f8    	mov	x24, x8
10140dae8: f94427e8    	ldr	x8, [sp, #0x848]
10140daec: f87a0108    	ldaddl	x26, x8, [x8]
10140daf0: f100051f    	cmp	x8, #0x1
10140daf4: 54000441    	b.ne	0x10140db7c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2830>
10140daf8: d50339bf    	dmb	ishld
10140dafc: 912123e0    	add	x0, sp, #0x848
10140db00: 940f3b23    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
10140db04: 1400001e    	b	0x10140db7c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2830>
10140db08: 924006c8    	and	x8, x22, #0x3
10140db0c: f100051f    	cmp	x8, #0x1
10140db10: 54fffa21    	b.ne	0x10140da54 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2708>
10140db14: f85ffed7    	ldr	x23, [x22, #-0x1]!
10140db18: f94006d8    	ldr	x24, [x22, #0x8]
10140db1c: f9400308    	ldr	x8, [x24]
10140db20: b4000068    	cbz	x8, 0x10140db2c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x27e0>
10140db24: aa1703e0    	mov	x0, x23
10140db28: d63f0100    	blr	x8
10140db2c: f9400701    	ldr	x1, [x24, #0x8]
10140db30: b4000081    	cbz	x1, 0x10140db40 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x27f4>
10140db34: f9400b02    	ldr	x2, [x24, #0x10]
10140db38: aa1703e0    	mov	x0, x23
10140db3c: 97da42e8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140db40: aa1603e0    	mov	x0, x22
10140db44: 52800301    	mov	w1, #0x18               ; =24
10140db48: 52800102    	mov	w2, #0x8                ; =8
10140db4c: 97da42e4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140db50: 17ffffc1    	b	0x10140da54 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2708>
10140db54: b40000b6    	cbz	x22, 0x10140db68 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x281c>
10140db58: aa1703e0    	mov	x0, x23
10140db5c: aa1603e1    	mov	x1, x22
10140db60: 52800022    	mov	w2, #0x1                ; =1
10140db64: 97da42de    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140db68: d2f00016    	mov	x22, #-0x8000000000000000 ; =-9223372036854775808
10140db6c: f94427e8    	ldr	x8, [sp, #0x848]
10140db70: f87a0108    	ldaddl	x26, x8, [x8]
10140db74: f100051f    	cmp	x8, #0x1
10140db78: 54fffc00    	b.eq	0x10140daf8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x27ac>
10140db7c: f94217e8    	ldr	x8, [sp, #0x428]
10140db80: b4fff668    	cbz	x8, 0x10140da4c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2700>
10140db84: f87a0108    	ldaddl	x26, x8, [x8]
10140db88: f100051f    	cmp	x8, #0x1
10140db8c: 54fff601    	b.ne	0x10140da4c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2700>
10140db90: d50339bf    	dmb	ishld
10140db94: 9110a3e0    	add	x0, sp, #0x428
10140db98: 940f3afd    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
10140db9c: 17ffffac    	b	0x10140da4c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2700>
10140dba0: 39616288    	ldrb	w8, [x20, #0x858]
10140dba4: 7100091f    	cmp	w8, #0x2
10140dba8: 54000120    	b.eq	0x10140dbcc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2880>
10140dbac: f94002a8    	ldr	x8, [x21]
10140dbb0: 92800009    	mov	x9, #-0x1               ; =-1
10140dbb4: f8690108    	ldaddl	x9, x8, [x8]
10140dbb8: f100051f    	cmp	x8, #0x1
10140dbbc: 54000081    	b.ne	0x10140dbcc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2880>
10140dbc0: d50339bf    	dmb	ishld
10140dbc4: aa1503e0    	mov	x0, x21
10140dbc8: 940f3af1    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
10140dbcc: 52800048    	mov	w8, #0x2                ; =2
10140dbd0: 39216288    	strb	w8, [x20, #0x858]
10140dbd4: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140dbd8: f9000268    	str	x8, [x19]
10140dbdc: 913283ff    	add	sp, sp, #0xca0
10140dbe0: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10140dbe4: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10140dbe8: a94357f6    	ldp	x22, x21, [sp, #0x30]
10140dbec: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10140dbf0: a94167fa    	ldp	x26, x25, [sp, #0x10]
10140dbf4: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10140dbf8: d65f03c0    	ret
10140dbfc: a9005e76    	stp	x22, x23, [x19]
10140dc00: f9000a78    	str	x24, [x19, #0x10]
10140dc04: 17fffff6    	b	0x10140dbdc <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2890>
10140dc08: 52800048    	mov	w8, #0x2                ; =2
10140dc0c: 39216288    	strb	w8, [x20, #0x858]
10140dc10: 941aee71    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140dc14: aa0003f3    	mov	x19, x0
10140dc18: f9400701    	ldr	x1, [x24, #0x8]
10140dc1c: b4000081    	cbz	x1, 0x10140dc2c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x28e0>
10140dc20: f9400b02    	ldr	x2, [x24, #0x10]
10140dc24: aa1703e0    	mov	x0, x23
10140dc28: 97da42ad    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140dc2c: aa1603e0    	mov	x0, x22
10140dc30: 52800301    	mov	w1, #0x18               ; =24
10140dc34: 52800102    	mov	w2, #0x8                ; =8
10140dc38: 97da42a9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140dc3c: aa1303e0    	mov	x0, x19
10140dc40: 941aee65    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140dc44: aa0003f3    	mov	x19, x0
10140dc48: 14000011    	b	0x10140dc8c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2940>
10140dc4c: aa0003f3    	mov	x19, x0
10140dc50: b40000f6    	cbz	x22, 0x10140dc6c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2920>
10140dc54: aa1703e0    	mov	x0, x23
10140dc58: aa1603e1    	mov	x1, x22
10140dc5c: 52800022    	mov	w2, #0x1                ; =1
10140dc60: 97da429f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140dc64: 14000002    	b	0x10140dc6c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2920>
10140dc68: aa0003f3    	mov	x19, x0
10140dc6c: f94427e8    	ldr	x8, [sp, #0x848]
10140dc70: 92800009    	mov	x9, #-0x1               ; =-1
10140dc74: f8690108    	ldaddl	x9, x8, [x8]
10140dc78: f100051f    	cmp	x8, #0x1
10140dc7c: 54000081    	b.ne	0x10140dc8c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2940>
10140dc80: d50339bf    	dmb	ishld
10140dc84: 912123e0    	add	x0, sp, #0x848
10140dc88: 940f3ac1    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
10140dc8c: f94217e8    	ldr	x8, [sp, #0x428]
10140dc90: b4000108    	cbz	x8, 0x10140dcb0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2964>
10140dc94: 92800009    	mov	x9, #-0x1               ; =-1
10140dc98: f8690108    	ldaddl	x9, x8, [x8]
10140dc9c: f100051f    	cmp	x8, #0x1
10140dca0: 54000081    	b.ne	0x10140dcb0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2964>
10140dca4: d50339bf    	dmb	ishld
10140dca8: 9110a3e0    	add	x0, sp, #0x428
10140dcac: 940f3ab8    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
10140dcb0: aa1303e0    	mov	x0, x19
10140dcb4: 941aee48    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140dcb8: 941ad81b    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
10140dcbc: 941ad81a    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
10140dcc0: d10383ff    	sub	sp, sp, #0xe0
10140dcc4: a9086ffc    	stp	x28, x27, [sp, #0x80]
10140dcc8: a90967fa    	stp	x26, x25, [sp, #0x90]
10140dccc: a90a5ff8    	stp	x24, x23, [sp, #0xa0]
10140dcd0: a90b57f6    	stp	x22, x21, [sp, #0xb0]
10140dcd4: a90c4ff4    	stp	x20, x19, [sp, #0xc0]
10140dcd8: a90d7bfd    	stp	x29, x30, [sp, #0xd0]
10140dcdc: 910343fd    	add	x29, sp, #0xd0
10140dce0: aa0003f3    	mov	x19, x0
10140dce4: 39412428    	ldrb	w8, [x1, #0x49]
10140dce8: 36000168    	tbz	w8, #0x0, 0x10140dd14 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29c8>
10140dcec: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140dcf0: f9000268    	str	x8, [x19]
10140dcf4: a94d7bfd    	ldp	x29, x30, [sp, #0xd0]
10140dcf8: a94c4ff4    	ldp	x20, x19, [sp, #0xc0]
10140dcfc: a94b57f6    	ldp	x22, x21, [sp, #0xb0]
10140dd00: a94a5ff8    	ldp	x24, x23, [sp, #0xa0]
10140dd04: a94967fa    	ldp	x26, x25, [sp, #0x90]
10140dd08: a9486ffc    	ldp	x28, x27, [sp, #0x80]
10140dd0c: 910383ff    	add	sp, sp, #0xe0
10140dd10: d65f03c0    	ret
10140dd14: aa0103f4    	mov	x20, x1
10140dd18: 528000d8    	mov	w24, #0x6               ; =6
10140dd1c: 52800039    	mov	w25, #0x1               ; =1
10140dd20: f9400035    	ldr	x21, [x1]
10140dd24: 528e4c5b    	mov	w27, #0x7262            ; =29282
10140dd28: 72adcc3b    	movk	w27, #0x6e61, lsl #16
10140dd2c: d2f0001c    	mov	x28, #-0x8000000000000000 ; =-9223372036854775808
10140dd30: 5285441a    	mov	w26, #0x2a20            ; =10784
10140dd34: 14000003    	b	0x10140dd40 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29f4>
10140dd38: 39412688    	ldrb	w8, [x20, #0x49]
10140dd3c: 3707fd88    	tbnz	w8, #0x0, 0x10140dcec <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29a0>
10140dd40: f8418296    	ldur	x22, [x20, #0x18]
10140dd44: 910003e0    	mov	x0, sp
10140dd48: 91006281    	add	x1, x20, #0x18
10140dd4c: 94017c64    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
10140dd50: b94003e8    	ldr	w8, [sp]
10140dd54: 7100051f    	cmp	w8, #0x1
10140dd58: 54000101    	b.ne	0x10140dd78 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a2c>
10140dd5c: f9400be8    	ldr	x8, [sp, #0x10]
10140dd60: f9400689    	ldr	x9, [x20, #0x8]
10140dd64: cb090101    	sub	x1, x8, x9
10140dd68: 8b0902c0    	add	x0, x22, x9
10140dd6c: f9000688    	str	x8, [x20, #0x8]
10140dd70: b50001c1    	cbnz	x1, 0x10140dda8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a5c>
10140dd74: 1400001c    	b	0x10140dde4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a98>
10140dd78: 39412688    	ldrb	w8, [x20, #0x49]
10140dd7c: 3707fb88    	tbnz	w8, #0x0, 0x10140dcec <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29a0>
10140dd80: 39012699    	strb	w25, [x20, #0x49]
10140dd84: 3941228a    	ldrb	w10, [x20, #0x48]
10140dd88: a940a688    	ldp	x8, x9, [x20, #0x8]
10140dd8c: 3700006a    	tbnz	w10, #0x0, 0x10140dd98 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a4c>
10140dd90: eb08013f    	cmp	x9, x8
10140dd94: 54fffac0    	b.eq	0x10140dcec <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29a0>
10140dd98: f841828a    	ldur	x10, [x20, #0x18]
10140dd9c: cb080121    	sub	x1, x9, x8
10140dda0: 8b080140    	add	x0, x10, x8
10140dda4: b4000201    	cbz	x1, 0x10140dde4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a98>
10140dda8: d1000428    	sub	x8, x1, #0x1
10140ddac: 38686809    	ldrb	w9, [x0, x8]
10140ddb0: 7100293f    	cmp	w9, #0xa
10140ddb4: 54000181    	b.ne	0x10140dde4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a98>
10140ddb8: d1000829    	sub	x9, x1, #0x2
10140ddbc: b40000c8    	cbz	x8, 0x10140ddd4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a88>
10140ddc0: 3869680a    	ldrb	w10, [x0, x9]
10140ddc4: 12001d4a    	and	w10, w10, #0xff
10140ddc8: 7100355f    	cmp	w10, #0xd
10140ddcc: 9a9f000a    	csel	x10, x0, xzr, eq
10140ddd0: 14000002    	b	0x10140ddd8 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2a8c>
10140ddd4: d280000a    	mov	x10, #0x0               ; =0
10140ddd8: f100015f    	cmp	x10, #0x0
10140dddc: 9a890101    	csel	x1, x8, x9, eq
10140dde0: 9a8a0000    	csel	x0, x0, x10, eq
10140dde4: b4fff840    	cbz	x0, 0x10140dcec <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29a0>
10140dde8: 97d4fadf    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
10140ddec: f1000828    	subs	x8, x1, #0x2
10140ddf0: 540000e2    	b.hs	0x10140de0c <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2ac0>
10140ddf4: d2800009    	mov	x9, #0x0                ; =0
10140ddf8: f100013f    	cmp	x9, #0x0
10140ddfc: 9a880036    	csel	x22, x1, x8, eq
10140de00: 9a890017    	csel	x23, x0, x9, eq
10140de04: b5000176    	cbnz	x22, 0x10140de30 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2ae4>
10140de08: 17ffffcc    	b	0x10140dd38 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29ec>
10140de0c: aa0003e9    	mov	x9, x0
10140de10: 7840252a    	ldrh	w10, [x9], #0x2
10140de14: 5ac0094a    	rev	w10, w10
10140de18: 6b4a435f    	cmp	w26, w10, lsr #16
10140de1c: 9a9f0129    	csel	x9, x9, xzr, eq
10140de20: f100013f    	cmp	x9, #0x0
10140de24: 9a880036    	csel	x22, x1, x8, eq
10140de28: 9a890017    	csel	x23, x0, x9, eq
10140de2c: b4fff876    	cbz	x22, 0x10140dd38 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29ec>
10140de30: 394002e8    	ldrb	w8, [x23]
10140de34: 7100a11f    	cmp	w8, #0x28
10140de38: 54fff800    	b.eq	0x10140dd38 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29ec>
10140de3c: aa1503e0    	mov	x0, x21
10140de40: aa1703e1    	mov	x1, x23
10140de44: aa1603e2    	mov	x2, x22
10140de48: 94000381    	bl	0x10140ec4c <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E>
10140de4c: 34fff760    	cbz	w0, 0x10140dd38 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29ec>
10140de50: 97da4228    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140de54: 528000c0    	mov	w0, #0x6                ; =6
10140de58: 52800021    	mov	w1, #0x1                ; =1
10140de5c: 97da421f    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140de60: b4000400    	cbz	x0, 0x10140dee0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2b94>
10140de64: 528d0c68    	mov	w8, #0x6863             ; =26723
10140de68: 79000808    	strh	w8, [x0, #0x4]
10140de6c: b900001b    	str	w27, [x0]
10140de70: a90683f8    	stp	x24, x0, [sp, #0x68]
10140de74: f9003ff8    	str	x24, [sp, #0x78]
10140de78: 910003e0    	mov	x0, sp
10140de7c: 9101a3e3    	add	x3, sp, #0x68
10140de80: aa1703e1    	mov	x1, x23
10140de84: aa1603e2    	mov	x2, x22
10140de88: 52800044    	mov	w4, #0x2                ; =2
10140de8c: 94008253    	bl	0x10142e7d8 <__ZN17otty_autocomplete3fix8distance19damerau_levenshtein17hab3f29809ff4c368E+0x7a4>
10140de90: f94003e8    	ldr	x8, [sp]
10140de94: eb1c011f    	cmp	x8, x28
10140de98: 54fff500    	b.eq	0x10140dd38 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29ec>
10140de9c: f94007e9    	ldr	x9, [sp, #0x8]
10140dea0: f94013ea    	ldr	x10, [sp, #0x20]
10140dea4: f9401feb    	ldr	x11, [sp, #0x38]
10140dea8: f9402bec    	ldr	x12, [sp, #0x50]
10140deac: 3cc583e0    	ldur	q0, [sp, #0x58]
10140deb0: 3c858260    	stur	q0, [x19, #0x58]
10140deb4: 3dc007e0    	ldr	q0, [sp, #0x10]
10140deb8: 3cc283e1    	ldur	q1, [sp, #0x28]
10140debc: 3dc013e2    	ldr	q2, [sp, #0x40]
10140dec0: a9002668    	stp	x8, x9, [x19]
10140dec4: 3d800660    	str	q0, [x19, #0x10]
10140dec8: f900126a    	str	x10, [x19, #0x20]
10140decc: 3c828261    	stur	q1, [x19, #0x28]
10140ded0: f9001e6b    	str	x11, [x19, #0x38]
10140ded4: 3d801262    	str	q2, [x19, #0x40]
10140ded8: f9002a6c    	str	x12, [x19, #0x50]
10140dedc: 17ffff86    	b	0x10140dcf4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x29a8>
10140dee0: 52800020    	mov	w0, #0x1                ; =1
10140dee4: 528000c1    	mov	w1, #0x6                ; =6
10140dee8: 941ad523    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
