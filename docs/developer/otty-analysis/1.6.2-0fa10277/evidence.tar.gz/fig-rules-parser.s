
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010143ac64 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E>:
10143ac80: d10383ff    	sub	sp, sp, #0xe0
10143ac84: a9086ffc    	stp	x28, x27, [sp, #0x80]
10143ac88: a90967fa    	stp	x26, x25, [sp, #0x90]
10143ac8c: a90a5ff8    	stp	x24, x23, [sp, #0xa0]
10143ac90: a90b57f6    	stp	x22, x21, [sp, #0xb0]
10143ac94: a90c4ff4    	stp	x20, x19, [sp, #0xc0]
10143ac98: a90d7bfd    	stp	x29, x30, [sp, #0xd0]
10143ac9c: 910343fd    	add	x29, sp, #0xd0
10143aca0: aa0403f8    	mov	x24, x4
10143aca4: aa0303f7    	mov	x23, x3
10143aca8: aa0203f6    	mov	x22, x2
10143acac: aa0103fc    	mov	x28, x1
10143acb0: f90003e0    	str	x0, [sp]
10143acb4: 97d98e8f    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10143acb8: 52800100    	mov	w0, #0x8                ; =8
10143acbc: 52800101    	mov	w1, #0x8                ; =8
10143acc0: 97d98e86    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10143acc4: b4001f40    	cbz	x0, 0x10143b0ac <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x448>
10143acc8: f90007ff    	str	xzr, [sp, #0x8]
10143accc: f900001c    	str	x28, [x0]
10143acd0: 52800108    	mov	w8, #0x8                ; =8
10143acd4: a90523ff    	stp	xzr, x8, [sp, #0x50]
10143acd8: f10006e8    	subs	x8, x23, #0x1
10143acdc: 9a8833e8    	csel	x8, xzr, x8, lo
10143ace0: 7100031f    	cmp	w24, #0x0
10143ace4: 5280002a    	mov	w10, #0x1               ; =1
10143ace8: a9032be0    	stp	x0, x10, [sp, #0x30]
10143acec: a9042be0    	stp	x0, x10, [sp, #0x40]
10143acf0: 52800029    	mov	w9, #0x1                ; =1
10143acf4: f90033ff    	str	xzr, [sp, #0x60]
10143acf8: 9a8812e8    	csel	x8, x23, x8, ne
10143acfc: a90223e9    	stp	x9, x8, [sp, #0x20]
10143ad00: f100091f    	cmp	x8, #0x2
10143ad04: 54001a83    	b.lo	0x10143b054 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x3f0>
10143ad08: f90007ff    	str	xzr, [sp, #0x8]
10143ad0c: 52800028    	mov	w8, #0x1                ; =1
10143ad10: f90013e8    	str	x8, [sp, #0x20]
10143ad14: 52800038    	mov	w24, #0x1               ; =1
10143ad18: 14000008    	b	0x10143ad38 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd4>
10143ad1c: f94007e8    	ldr	x8, [sp, #0x8]
10143ad20: 91000508    	add	x8, x8, #0x1
10143ad24: f90007e8    	str	x8, [sp, #0x8]
10143ad28: 91000718    	add	x24, x24, #0x1
10143ad2c: f94017e8    	ldr	x8, [sp, #0x28]
10143ad30: eb08031f    	cmp	x24, x8
10143ad34: 54001922    	b.hs	0x10143b058 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x3f4>
10143ad38: f94013e8    	ldr	x8, [sp, #0x20]
10143ad3c: f9401be9    	ldr	x9, [sp, #0x30]
10143ad40: 8b080d28    	add	x8, x9, x8, lsl #3
10143ad44: a90173e8    	stp	x8, x28, [sp, #0x10]
10143ad48: 14000006    	b	0x10143ad60 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xfc>
10143ad4c: 52800028    	mov	w8, #0x1                ; =1
10143ad50: 8b180118    	add	x24, x8, x24
10143ad54: f94017e8    	ldr	x8, [sp, #0x28]
10143ad58: eb08031f    	cmp	x24, x8
10143ad5c: 540017e2    	b.hs	0x10143b058 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x3f4>
10143ad60: eb17031f    	cmp	x24, x23
10143ad64: 54001aa2    	b.hs	0x10143b0b8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x454>
10143ad68: 52800308    	mov	w8, #0x18               ; =24
10143ad6c: 9b085b1b    	madd	x27, x24, x8, x22
10143ad70: a940eb79    	ldp	x25, x26, [x27, #0x8]
10143ad74: b4000c1a    	cbz	x26, 0x10143aef4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x290>
10143ad78: 39400328    	ldrb	w8, [x25]
10143ad7c: 7100b51f    	cmp	w8, #0x2d
10143ad80: 54000ba1    	b.ne	0x10143aef4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x290>
10143ad84: f9405b88    	ldr	x8, [x28, #0xb0]
10143ad88: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10143ad8c: eb09011f    	cmp	x8, x9
10143ad90: 54000400    	b.eq	0x10143ae10 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x1ac>
10143ad94: f9406388    	ldr	x8, [x28, #0xc0]
10143ad98: b40003c8    	cbz	x8, 0x10143ae10 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x1ac>
10143ad9c: f9405f95    	ldr	x21, [x28, #0xb8]
10143ada0: 52801309    	mov	w9, #0x98               ; =152
10143ada4: 9b09551b    	madd	x27, x8, x9, x21
10143ada8: 14000004    	b	0x10143adb8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x154>
10143adac: 910262b5    	add	x21, x21, #0x98
10143adb0: eb1b02bf    	cmp	x21, x27
10143adb4: 540002e0    	b.eq	0x10143ae10 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x1ac>
10143adb8: f9403ea8    	ldr	x8, [x21, #0x78]
10143adbc: b4ffff88    	cbz	x8, 0x10143adac <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x148>
10143adc0: f9403aa9    	ldr	x9, [x21, #0x70]
10143adc4: 8b080508    	add	x8, x8, x8, lsl #1
10143adc8: d37df114    	lsl	x20, x8, #3
10143adcc: 91004133    	add	x19, x9, #0x10
10143add0: 14000004    	b	0x10143ade0 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x17c>
10143add4: 91006273    	add	x19, x19, #0x18
10143add8: f1006294    	subs	x20, x20, #0x18
10143addc: 54fffe80    	b.eq	0x10143adac <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x148>
10143ade0: f9400268    	ldr	x8, [x19]
10143ade4: eb1a011f    	cmp	x8, x26
10143ade8: 54ffff61    	b.ne	0x10143add4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x170>
10143adec: f85f8260    	ldur	x0, [x19, #-0x8]
10143adf0: aa1903e1    	mov	x1, x25
10143adf4: aa1a03e2    	mov	x2, x26
10143adf8: 941a3b89    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10143adfc: 35fffec0    	cbnz	w0, 0x10143add4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x170>
10143ae00: f94002a8    	ldr	x8, [x21]
10143ae04: f100111f    	cmp	x8, #0x4
10143ae08: 54000621    	b.ne	0x10143aecc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x268>
10143ae0c: 17ffffd0    	b	0x10143ad4c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xe8>
10143ae10: f94013e8    	ldr	x8, [sp, #0x20]
10143ae14: b4fff9c8    	cbz	x8, 0x10143ad4c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xe8>
10143ae18: aa1603fc    	mov	x28, x22
10143ae1c: aa1703f6    	mov	x22, x23
10143ae20: f9400bfb    	ldr	x27, [sp, #0x10]
10143ae24: 14000004    	b	0x10143ae34 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x1d0>
10143ae28: f9401be8    	ldr	x8, [sp, #0x30]
10143ae2c: eb1b011f    	cmp	x8, x27
10143ae30: 54000580    	b.eq	0x10143aee0 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x27c>
10143ae34: f85f8f68    	ldr	x8, [x27, #-0x8]!
10143ae38: f9405909    	ldr	x9, [x8, #0xb0]
10143ae3c: d2f0000a    	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
10143ae40: eb0a013f    	cmp	x9, x10
10143ae44: 54ffff20    	b.eq	0x10143ae28 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x1c4>
10143ae48: f9406109    	ldr	x9, [x8, #0xc0]
10143ae4c: b4fffee9    	cbz	x9, 0x10143ae28 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x1c4>
10143ae50: f9405d15    	ldr	x21, [x8, #0xb8]
10143ae54: 52801308    	mov	w8, #0x98               ; =152
10143ae58: 9b085534    	madd	x20, x9, x8, x21
10143ae5c: 14000004    	b	0x10143ae6c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x208>
10143ae60: 910262b5    	add	x21, x21, #0x98
10143ae64: eb1402bf    	cmp	x21, x20
10143ae68: 54fffe00    	b.eq	0x10143ae28 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x1c4>
10143ae6c: f9403ea8    	ldr	x8, [x21, #0x78]
10143ae70: b4ffff88    	cbz	x8, 0x10143ae60 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x1fc>
10143ae74: f9403aa9    	ldr	x9, [x21, #0x70]
10143ae78: 8b080508    	add	x8, x8, x8, lsl #1
10143ae7c: d37df113    	lsl	x19, x8, #3
10143ae80: 91004137    	add	x23, x9, #0x10
10143ae84: 14000004    	b	0x10143ae94 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x230>
10143ae88: 910062f7    	add	x23, x23, #0x18
10143ae8c: f1006273    	subs	x19, x19, #0x18
10143ae90: 54fffe80    	b.eq	0x10143ae60 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x1fc>
10143ae94: f94002e8    	ldr	x8, [x23]
10143ae98: eb1a011f    	cmp	x8, x26
10143ae9c: 54ffff61    	b.ne	0x10143ae88 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x224>
10143aea0: f85f82e0    	ldur	x0, [x23, #-0x8]
10143aea4: aa1903e1    	mov	x1, x25
10143aea8: aa1a03e2    	mov	x2, x26
10143aeac: 941a3b5c    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10143aeb0: 35fffec0    	cbnz	w0, 0x10143ae88 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x224>
10143aeb4: aa1603f7    	mov	x23, x22
10143aeb8: aa1c03f6    	mov	x22, x28
10143aebc: f9400ffc    	ldr	x28, [sp, #0x18]
10143aec0: f94002a8    	ldr	x8, [x21]
10143aec4: f100111f    	cmp	x8, #0x4
10143aec8: 54fff420    	b.eq	0x10143ad4c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xe8>
10143aecc: f9400ea9    	ldr	x9, [x21, #0x18]
10143aed0: f1000d1f    	cmp	x8, #0x3
10143aed4: 52800048    	mov	w8, #0x2                ; =2
10143aed8: 9a891508    	csinc	x8, x8, x9, ne
10143aedc: 17ffff9d    	b	0x10143ad50 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xec>
10143aee0: 52800028    	mov	w8, #0x1                ; =1
10143aee4: aa1603f7    	mov	x23, x22
10143aee8: aa1c03f6    	mov	x22, x28
10143aeec: f9400ffc    	ldr	x28, [sp, #0x18]
10143aef0: 17ffff98    	b	0x10143ad50 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xec>
10143aef4: f9404f88    	ldr	x8, [x28, #0x98]
10143aef8: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10143aefc: eb09011f    	cmp	x8, x9
10143af00: 54fff0e0    	b.eq	0x10143ad1c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xb8>
10143af04: f9405788    	ldr	x8, [x28, #0xa8]
10143af08: b4fff0a8    	cbz	x8, 0x10143ad1c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xb8>
10143af0c: f9405395    	ldr	x21, [x28, #0xa0]
10143af10: 52801c09    	mov	w9, #0xe0               ; =224
10143af14: 9b095508    	madd	x8, x8, x9, x21
10143af18: f9000be8    	str	x8, [sp, #0x10]
10143af1c: 14000005    	b	0x10143af30 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x2cc>
10143af20: 910382b5    	add	x21, x21, #0xe0
10143af24: f9400be8    	ldr	x8, [sp, #0x10]
10143af28: eb0802bf    	cmp	x21, x8
10143af2c: 54ffef80    	b.eq	0x10143ad1c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xb8>
10143af30: f94036a8    	ldr	x8, [x21, #0x68]
10143af34: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10143af38: eb09011f    	cmp	x8, x9
10143af3c: 54000120    	b.eq	0x10143af60 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x2fc>
10143af40: f9403ea8    	ldr	x8, [x21, #0x78]
10143af44: eb1a011f    	cmp	x8, x26
10143af48: 540000c1    	b.ne	0x10143af60 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x2fc>
10143af4c: f9403aa0    	ldr	x0, [x21, #0x70]
10143af50: aa1903e1    	mov	x1, x25
10143af54: aa1a03e2    	mov	x2, x26
10143af58: 941a3b31    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10143af5c: 340002e0    	cbz	w0, 0x10143afb8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x354>
10143af60: f94066a8    	ldr	x8, [x21, #0xc8]
10143af64: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10143af68: eb09011f    	cmp	x8, x9
10143af6c: 54fffda0    	b.eq	0x10143af20 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x2bc>
10143af70: f9406ea8    	ldr	x8, [x21, #0xd8]
10143af74: b4fffd68    	cbz	x8, 0x10143af20 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x2bc>
10143af78: f9406aa9    	ldr	x9, [x21, #0xd0]
10143af7c: 8b080508    	add	x8, x8, x8, lsl #1
10143af80: d37df114    	lsl	x20, x8, #3
10143af84: 91004133    	add	x19, x9, #0x10
10143af88: 14000004    	b	0x10143af98 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x334>
10143af8c: 91006273    	add	x19, x19, #0x18
10143af90: f1006294    	subs	x20, x20, #0x18
10143af94: 54fffc60    	b.eq	0x10143af20 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x2bc>
10143af98: f9400268    	ldr	x8, [x19]
10143af9c: eb1a011f    	cmp	x8, x26
10143afa0: 54ffff61    	b.ne	0x10143af8c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x328>
10143afa4: f85f8260    	ldur	x0, [x19, #-0x8]
10143afa8: aa1903e1    	mov	x1, x25
10143afac: aa1a03e2    	mov	x2, x26
10143afb0: 941a3b1b    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10143afb4: 35fffec0    	cbnz	w0, 0x10143af8c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x328>
10143afb8: 9101a3e8    	add	x8, sp, #0x68
10143afbc: aa1b03e0    	mov	x0, x27
10143afc0: 940f5083    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10143afc4: f94033f3    	ldr	x19, [sp, #0x60]
10143afc8: f9402be8    	ldr	x8, [sp, #0x50]
10143afcc: eb08027f    	cmp	x19, x8
10143afd0: 54000061    	b.ne	0x10143afdc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x378>
10143afd4: 910143e0    	add	x0, sp, #0x50
10143afd8: 941a1ee6    	bl	0x101ac2b70 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hb575521872840d8cE>
10143afdc: f9402fe8    	ldr	x8, [sp, #0x58]
10143afe0: 52800309    	mov	w9, #0x18               ; =24
10143afe4: 9b092268    	madd	x8, x19, x9, x8
10143afe8: 3cc683e0    	ldur	q0, [sp, #0x68]
10143afec: 3d800100    	str	q0, [x8]
10143aff0: f9403fe9    	ldr	x9, [sp, #0x78]
10143aff4: f9000909    	str	x9, [x8, #0x10]
10143aff8: 91000668    	add	x8, x19, #0x1
10143affc: f90033e8    	str	x8, [sp, #0x60]
10143b000: f9401fe8    	ldr	x8, [sp, #0x38]
10143b004: f94013e9    	ldr	x9, [sp, #0x20]
10143b008: eb08013f    	cmp	x9, x8
10143b00c: 540000a1    	b.ne	0x10143b020 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x3bc>
10143b010: 9100e3e0    	add	x0, sp, #0x38
10143b014: 9419541c    	bl	0x101a90084 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17ha41cb05e3e7aa5a5E>
10143b018: f94023e8    	ldr	x8, [sp, #0x40]
10143b01c: f9001be8    	str	x8, [sp, #0x30]
10143b020: f90007ff    	str	xzr, [sp, #0x8]
10143b024: f94013e8    	ldr	x8, [sp, #0x20]
10143b028: f9401be9    	ldr	x9, [sp, #0x30]
10143b02c: f828793c    	str	x28, [x9, x8, lsl #3]
10143b030: 91000508    	add	x8, x8, #0x1
10143b034: f90013e8    	str	x8, [sp, #0x20]
10143b038: f90027e8    	str	x8, [sp, #0x48]
10143b03c: aa1503fc    	mov	x28, x21
10143b040: 91000718    	add	x24, x24, #0x1
10143b044: f94017e8    	ldr	x8, [sp, #0x28]
10143b048: eb08031f    	cmp	x24, x8
10143b04c: 54ffe763    	b.lo	0x10143ad38 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd4>
10143b050: 14000002    	b	0x10143b058 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x3f4>
10143b054: 52800038    	mov	w24, #0x1               ; =1
10143b058: a943a7e8    	ldp	x8, x9, [sp, #0x38]
10143b05c: 3dc017e0    	ldr	q0, [sp, #0x50]
10143b060: f94003ec    	ldr	x12, [sp]
10143b064: 3c818180    	stur	q0, [x12, #0x18]
10143b068: f94033ea    	ldr	x10, [sp, #0x60]
10143b06c: eb1802ff    	cmp	x23, x24
10143b070: 9a9832eb    	csel	x11, x23, x24, lo
10143b074: a902f18a    	stp	x10, x28, [x12, #0x28]
10143b078: a9002588    	stp	x8, x9, [x12]
10143b07c: f94013e8    	ldr	x8, [sp, #0x20]
10143b080: f9000988    	str	x8, [x12, #0x10]
10143b084: f94007e8    	ldr	x8, [sp, #0x8]
10143b088: a903ad88    	stp	x8, x11, [x12, #0x38]
10143b08c: a94d7bfd    	ldp	x29, x30, [sp, #0xd0]
10143b090: a94c4ff4    	ldp	x20, x19, [sp, #0xc0]
10143b094: a94b57f6    	ldp	x22, x21, [sp, #0xb0]
10143b098: a94a5ff8    	ldp	x24, x23, [sp, #0xa0]
10143b09c: a94967fa    	ldp	x26, x25, [sp, #0x90]
10143b0a0: a9486ffc    	ldp	x28, x27, [sp, #0x80]
10143b0a4: 910383ff    	add	sp, sp, #0xe0
10143b0a8: d65f03c0    	ret
10143b0ac: 52800100    	mov	w0, #0x8                ; =8
10143b0b0: 52800101    	mov	w1, #0x8                ; =8
10143b0b4: 941a20a2    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
10143b0b8: d0007162    	adrp	x2, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
10143b0bc: 91124042    	add	x2, x2, #0x490
10143b0c0: aa1803e0    	mov	x0, x24
10143b0c4: aa1703e1    	mov	x1, x23
10143b0c8: 941a231d    	bl	0x101ac3d3c <__ZN4core9panicking18panic_bounds_check17hd6142ed38f8c399dE>
10143b0cc: d4200020    	brk	#0x1
10143b0d0: aa0003f3    	mov	x19, x0
10143b0d4: f94037e1    	ldr	x1, [sp, #0x68]
10143b0d8: b50000e1    	cbnz	x1, 0x10143b0f4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x490>
10143b0dc: 910143e0    	add	x0, sp, #0x50
10143b0e0: 97d41e8b    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10143b0e4: f9401fe8    	ldr	x8, [sp, #0x38]
10143b0e8: b5000228    	cbnz	x8, 0x10143b12c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x4c8>
10143b0ec: aa1303e0    	mov	x0, x19
10143b0f0: 941a3939    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10143b0f4: f9403be0    	ldr	x0, [sp, #0x70]
10143b0f8: 52800022    	mov	w2, #0x1                ; =1
10143b0fc: 97d98d78    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143b100: 910143e0    	add	x0, sp, #0x50
10143b104: 97d41e82    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10143b108: f9401fe8    	ldr	x8, [sp, #0x38]
10143b10c: b4ffff08    	cbz	x8, 0x10143b0ec <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x488>
10143b110: 14000007    	b	0x10143b12c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x4c8>
10143b114: 14000001    	b	0x10143b118 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x4b4>
10143b118: aa0003f3    	mov	x19, x0
10143b11c: 910143e0    	add	x0, sp, #0x50
10143b120: 97d41e7b    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10143b124: f9401fe8    	ldr	x8, [sp, #0x38]
10143b128: b4fffe28    	cbz	x8, 0x10143b0ec <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x488>
10143b12c: f94023e0    	ldr	x0, [sp, #0x40]
10143b130: d37df101    	lsl	x1, x8, #3
10143b134: 52800102    	mov	w2, #0x8                ; =8
10143b138: 97d98d69    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143b13c: aa1303e0    	mov	x0, x19
10143b140: 941a3925    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10143b144: d10643ff    	sub	sp, sp, #0x190
10143b148: a9136ffc    	stp	x28, x27, [sp, #0x130]
10143b14c: a91467fa    	stp	x26, x25, [sp, #0x140]
10143b150: a9155ff8    	stp	x24, x23, [sp, #0x150]
10143b154: a91657f6    	stp	x22, x21, [sp, #0x160]
10143b158: a9174ff4    	stp	x20, x19, [sp, #0x170]
10143b15c: a9187bfd    	stp	x29, x30, [sp, #0x180]
10143b160: 910603fd    	add	x29, sp, #0x180
10143b164: aa0103f7    	mov	x23, x1
10143b168: f100109f    	cmp	x4, #0x4
10143b16c: 5400016c    	b.gt	0x10143b198 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x534>
10143b170: f100089f    	cmp	x4, #0x2
10143b174: 5400032c    	b.gt	0x10143b1d8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x574>
10143b178: b4000b24    	cbz	x4, 0x10143b2dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x678>
10143b17c: f100089f    	cmp	x4, #0x2
10143b180: 54004221    	b.ne	0x10143b9c4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd60>
10143b184: 79400068    	ldrh	w8, [x3]
10143b188: 528d0e69    	mov	w9, #0x6873             ; =26739
10143b18c: 6b09011f    	cmp	w8, w9
10143b190: 540041a1    	b.ne	0x10143b9c4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd60>
10143b194: 14000052    	b	0x10143b2dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x678>
10143b198: f100249f    	cmp	x4, #0x9
10143b19c: 540003ac    	b.gt	0x10143b210 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x5ac>
10143b1a0: f100149f    	cmp	x4, #0x5
10143b1a4: 540005a0    	b.eq	0x10143b258 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x5f4>
10143b1a8: f1001c9f    	cmp	x4, #0x7
10143b1ac: 540040c1    	b.ne	0x10143b9c4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd60>
10143b1b0: b9400068    	ldr	w8, [x3]
10143b1b4: b8403069    	ldur	w9, [x3, #0x3]
10143b1b8: 528dec6a    	mov	w10, #0x6f63            ; =28515
10143b1bc: 72ae6dca    	movk	w10, #0x736e, lsl #16
10143b1c0: 6b0a011f    	cmp	w8, w10
10143b1c4: 528dee68    	mov	w8, #0x6f73             ; =28531
10143b1c8: 72acad88    	movk	w8, #0x656c, lsl #16
10143b1cc: 7a480120    	ccmp	w9, w8, #0x0, eq
10143b1d0: 54003fa1    	b.ne	0x10143b9c4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd60>
10143b1d4: 14000042    	b	0x10143b2dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x678>
10143b1d8: f1000c9f    	cmp	x4, #0x3
10143b1dc: 54000500    	b.eq	0x10143b27c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x618>
10143b1e0: f100109f    	cmp	x4, #0x4
10143b1e4: 54003f01    	b.ne	0x10143b9c4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd60>
10143b1e8: 528c2c48    	mov	w8, #0x6162             ; =24930
10143b1ec: 72ad0e68    	movk	w8, #0x6873, lsl #16
10143b1f0: b9400069    	ldr	w9, [x3]
10143b1f4: 6b08013f    	cmp	w9, w8
10143b1f8: 54000720    	b.eq	0x10143b2dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x678>
10143b1fc: b9400069    	ldr	w9, [x3]
10143b200: 11201108    	add	w8, w8, #0x804
10143b204: 6b09011f    	cmp	w8, w9
10143b208: 54003de1    	b.ne	0x10143b9c4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd60>
10143b20c: 14000034    	b	0x10143b2dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x678>
10143b210: f100289f    	cmp	x4, #0xa
10143b214: 54000500    	b.eq	0x10143b2b4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x650>
10143b218: f100349f    	cmp	x4, #0xd
10143b21c: 54003d41    	b.ne	0x10143b9c4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd60>
10143b220: f9400068    	ldr	x8, [x3]
10143b224: f8405069    	ldur	x9, [x3, #0x5]
10143b228: d28d0e6a    	mov	x10, #0x6873            ; =26739
10143b22c: f2ad8caa    	movk	x10, #0x6c65, lsl #16
10143b230: f2c5ad8a    	movk	x10, #0x2d6c, lsl #32
10143b234: f2ecae6a    	movk	x10, #0x6573, lsl #48
10143b238: eb0a011f    	cmp	x8, x10
10143b23c: d28e65a8    	mov	x8, #0x732d             ; =29485
10143b240: f2ae6ca8    	movk	x8, #0x7365, lsl #16
10143b244: f2cd2e68    	movk	x8, #0x6973, lsl #32
10143b248: f2edcde8    	movk	x8, #0x6e6f, lsl #48
10143b24c: fa480120    	ccmp	x9, x8, #0x0, eq
10143b250: 54003ba1    	b.ne	0x10143b9c4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd60>
10143b254: 14000022    	b	0x10143b2dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x678>
10143b258: b9400068    	ldr	w8, [x3]
10143b25c: 39401069    	ldrb	w9, [x3, #0x4]
10143b260: 528d0e6a    	mov	w10, #0x6873            ; =26739
10143b264: 72ad8caa    	movk	w10, #0x6c65, lsl #16
10143b268: 6b0a011f    	cmp	w8, w10
10143b26c: 52800d88    	mov	w8, #0x6c               ; =108
10143b270: 7a480120    	ccmp	w9, w8, #0x0, eq
10143b274: 54003a81    	b.ne	0x10143b9c4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd60>
10143b278: 14000019    	b	0x10143b2dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x678>
10143b27c: 79400068    	ldrh	w8, [x3]
10143b280: 39400869    	ldrb	w9, [x3, #0x2]
10143b284: 528e6f4a    	mov	w10, #0x737a            ; =29562
10143b288: 6b0a011f    	cmp	w8, w10
10143b28c: 52800d08    	mov	w8, #0x68               ; =104
10143b290: 7a480120    	ccmp	w9, w8, #0x0, eq
10143b294: 54000240    	b.eq	0x10143b2dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x678>
10143b298: 79400069    	ldrh	w9, [x3]
10143b29c: 3940086a    	ldrb	w10, [x3, #0x2]
10143b2a0: 528e6d6b    	mov	w11, #0x736b            ; =29547
10143b2a4: 6b0b013f    	cmp	w9, w11
10143b2a8: 7a480140    	ccmp	w10, w8, #0x0, eq
10143b2ac: 540038c1    	b.ne	0x10143b9c4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd60>
10143b2b0: 1400000b    	b	0x10143b2dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x678>
10143b2b4: f9400068    	ldr	x8, [x3]
10143b2b8: 79401069    	ldrh	w9, [x3, #0x8]
10143b2bc: d28d0e6a    	mov	x10, #0x6873            ; =26739
10143b2c0: f2ae65aa    	movk	x10, #0x732d, lsl #16
10143b2c4: f2ce6caa    	movk	x10, #0x7365, lsl #32
10143b2c8: f2ed2e6a    	movk	x10, #0x6973, lsl #48
10143b2cc: eb0a011f    	cmp	x8, x10
10143b2d0: 528dcde8    	mov	w8, #0x6e6f             ; =28271
10143b2d4: 7a480120    	ccmp	w9, w8, #0x0, eq
10143b2d8: 54003761    	b.ne	0x10143b9c4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd60>
10143b2dc: a9029fe6    	stp	x6, x7, [sp, #0x28]
10143b2e0: f9001fe5    	str	x5, [sp, #0x38]
10143b2e4: f90013e0    	str	x0, [sp, #0x20]
10143b2e8: b4000482    	cbz	x2, 0x10143b378 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x714>
10143b2ec: 8b020448    	add	x8, x2, x2, lsl #1
10143b2f0: d37df11a    	lsl	x26, x8, #3
10143b2f4: 910042f3    	add	x19, x23, #0x10
10143b2f8: 52840494    	mov	w20, #0x2024            ; =8228
10143b2fc: 528404b5    	mov	w21, #0x2025            ; =8229
10143b300: aa1a03f6    	mov	x22, x26
10143b304: 14000004    	b	0x10143b314 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x6b0>
10143b308: 91006273    	add	x19, x19, #0x18
10143b30c: f10062d6    	subs	x22, x22, #0x18
10143b310: 54000400    	b.eq	0x10143b390 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x72c>
10143b314: a97f8660    	ldp	x0, x1, [x19, #-0x8]
10143b318: 97d44593    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
10143b31c: f100083f    	cmp	x1, #0x2
10143b320: 54000102    	b.hs	0x10143b340 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x6dc>
10143b324: f100043f    	cmp	x1, #0x1
10143b328: 54ffff01    	b.ne	0x10143b308 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x6a4>
10143b32c: 39400008    	ldrb	w8, [x0]
10143b330: 121f1908    	and	w8, w8, #0xfe
10143b334: 7100911f    	cmp	w8, #0x24
10143b338: 54fffe81    	b.ne	0x10143b308 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x6a4>
10143b33c: 1400000d    	b	0x10143b370 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x70c>
10143b340: 79400008    	ldrh	w8, [x0]
10143b344: 6b14011f    	cmp	w8, w20
10143b348: 54000140    	b.eq	0x10143b370 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x70c>
10143b34c: 79400008    	ldrh	w8, [x0]
10143b350: 7124911f    	cmp	w8, #0x924
10143b354: 540000e0    	b.eq	0x10143b370 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x70c>
10143b358: 79400008    	ldrh	w8, [x0]
10143b35c: 6b15011f    	cmp	w8, w21
10143b360: 54000080    	b.eq	0x10143b370 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x70c>
10143b364: 79400008    	ldrh	w8, [x0]
10143b368: 7124951f    	cmp	w8, #0x925
10143b36c: 54fffce1    	b.ne	0x10143b308 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x6a4>
10143b370: 5280001b    	mov	w27, #0x0               ; =0
10143b374: 14000008    	b	0x10143b394 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x730>
10143b378: d2800014    	mov	x20, #0x0               ; =0
10143b37c: 52800108    	mov	w8, #0x8                ; =8
10143b380: a90423ff    	stp	xzr, x8, [sp, #0x40]
10143b384: a9057fff    	stp	xzr, xzr, [sp, #0x50]
10143b388: a9067fe8    	stp	x8, xzr, [sp, #0x60]
10143b38c: 140000e6    	b	0x10143b724 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xac0>
10143b390: 5280003b    	mov	w27, #0x1               ; =1
10143b394: 52800016    	mov	w22, #0x0               ; =0
10143b398: 5280011c    	mov	w28, #0x8               ; =8
10143b39c: a90473ff    	stp	xzr, x28, [sp, #0x40]
10143b3a0: 910042f4    	add	x20, x23, #0x10
10143b3a4: 52800313    	mov	w19, #0x18              ; =24
10143b3a8: a9057fff    	stp	xzr, xzr, [sp, #0x50]
10143b3ac: 52848415    	mov	w21, #0x2420            ; =9248
10143b3b0: a9067ffc    	stp	x28, xzr, [sp, #0x60]
10143b3b4: 1400000d    	b	0x10143b3e8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x784>
10143b3b8: 52800016    	mov	w22, #0x0               ; =0
10143b3bc: f94027e8    	ldr	x8, [sp, #0x48]
10143b3c0: 9b1322e8    	madd	x8, x23, x19, x8
10143b3c4: 3dc033e0    	ldr	q0, [sp, #0xc0]
10143b3c8: 3d800100    	str	q0, [x8]
10143b3cc: f9406be9    	ldr	x9, [sp, #0xd0]
10143b3d0: f9000909    	str	x9, [x8, #0x10]
10143b3d4: 910006e8    	add	x8, x23, #0x1
10143b3d8: f9002be8    	str	x8, [sp, #0x50]
10143b3dc: 91006294    	add	x20, x20, #0x18
10143b3e0: f100635a    	subs	x26, x26, #0x18
10143b3e4: 54001600    	b.eq	0x10143b6a4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xa40>
10143b3e8: a97f8680    	ldp	x0, x1, [x20, #-0x8]
10143b3ec: 97d4455e    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
10143b3f0: b4000441    	cbz	x1, 0x10143b478 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x814>
10143b3f4: 39400008    	ldrb	w8, [x0]
10143b3f8: 71008d1f    	cmp	w8, #0x23
10143b3fc: 54ffff00    	b.eq	0x10143b3dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x778>
10143b400: aa0103f7    	mov	x23, x1
10143b404: f1000421    	subs	x1, x1, #0x1
10143b408: 54000561    	b.ne	0x10143b4b4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x850>
10143b40c: aa0003f9    	mov	x25, x0
10143b410: 97d98cb8    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10143b414: aa1703e0    	mov	x0, x23
10143b418: 52800021    	mov	w1, #0x1                ; =1
10143b41c: 97d98caf    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10143b420: b4002e20    	cbz	x0, 0x10143b9e4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd80>
10143b424: aa0003f8    	mov	x24, x0
10143b428: aa1903e1    	mov	x1, x25
10143b42c: aa1703e2    	mov	x2, x23
10143b430: 941a39fe    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10143b434: 2a160368    	orr	w8, w27, w22
10143b438: 37000ce8    	tbnz	w8, #0x0, 0x10143b5d4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x970>
10143b43c: f94037e8    	ldr	x8, [sp, #0x68]
10143b440: b4001268    	cbz	x8, 0x10143b68c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xa28>
10143b444: 3cc583e0    	ldur	q0, [sp, #0x58]
10143b448: 3d8033e0    	str	q0, [sp, #0xc0]
10143b44c: f94037e8    	ldr	x8, [sp, #0x68]
10143b450: f9006be8    	str	x8, [sp, #0xd0]
10143b454: a905f3ff    	stp	xzr, x28, [sp, #0x58]
10143b458: f90037ff    	str	xzr, [sp, #0x68]
10143b45c: f9402bf6    	ldr	x22, [sp, #0x50]
10143b460: f94023e8    	ldr	x8, [sp, #0x40]
10143b464: eb0802df    	cmp	x22, x8
10143b468: 54001021    	b.ne	0x10143b66c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xa08>
10143b46c: 910103e0    	add	x0, sp, #0x40
10143b470: 94195269    	bl	0x101a8fe14 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hed155317132a177cE>
10143b474: 1400007e    	b	0x10143b66c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xa08>
10143b478: f94037e8    	ldr	x8, [sp, #0x68]
10143b47c: b4000d88    	cbz	x8, 0x10143b62c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x9c8>
10143b480: 3cc583e0    	ldur	q0, [sp, #0x58]
10143b484: 3d8033e0    	str	q0, [sp, #0xc0]
10143b488: f94037e8    	ldr	x8, [sp, #0x68]
10143b48c: f9006be8    	str	x8, [sp, #0xd0]
10143b490: a905f3ff    	stp	xzr, x28, [sp, #0x58]
10143b494: f90037ff    	str	xzr, [sp, #0x68]
10143b498: f9402bf7    	ldr	x23, [sp, #0x50]
10143b49c: f94023e8    	ldr	x8, [sp, #0x40]
10143b4a0: eb0802ff    	cmp	x23, x8
10143b4a4: 54fff8a1    	b.ne	0x10143b3b8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x754>
10143b4a8: 910103e0    	add	x0, sp, #0x40
10143b4ac: 9419525a    	bl	0x101a8fe14 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hed155317132a177cE>
10143b4b0: 17ffffc2    	b	0x10143b3b8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x754>
10143b4b4: 79400009    	ldrh	w9, [x0]
10143b4b8: 5ac00929    	rev	w9, w9
10143b4bc: 6b4942bf    	cmp	w21, w9, lsr #16
10143b4c0: 54000680    	b.eq	0x10143b590 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x92c>
10143b4c4: 79400009    	ldrh	w9, [x0]
10143b4c8: 5ac00929    	rev	w9, w9
10143b4cc: 5284a40a    	mov	w10, #0x2520            ; =9504
10143b4d0: 6b49415f    	cmp	w10, w9, lsr #16
10143b4d4: 540005e0    	b.eq	0x10143b590 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x92c>
10143b4d8: 79400009    	ldrh	w9, [x0]
10143b4dc: 5ac00929    	rev	w9, w9
10143b4e0: 5287c40a    	mov	w10, #0x3e20            ; =15904
10143b4e4: 6b49415f    	cmp	w10, w9, lsr #16
10143b4e8: 54000540    	b.eq	0x10143b590 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x92c>
10143b4ec: 79400009    	ldrh	w9, [x0]
10143b4f0: 5ac00929    	rev	w9, w9
10143b4f4: 5284812a    	mov	w10, #0x2409            ; =9225
10143b4f8: 6b49415f    	cmp	w10, w9, lsr #16
10143b4fc: 540004a0    	b.eq	0x10143b590 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x92c>
10143b500: 79400009    	ldrh	w9, [x0]
10143b504: 5ac00929    	rev	w9, w9
10143b508: 5284a12a    	mov	w10, #0x2509            ; =9481
10143b50c: 6b49415f    	cmp	w10, w9, lsr #16
10143b510: 54000400    	b.eq	0x10143b590 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x92c>
10143b514: 79400009    	ldrh	w9, [x0]
10143b518: 5ac00929    	rev	w9, w9
10143b51c: 5287c12a    	mov	w10, #0x3e09            ; =15881
10143b520: 6b49415f    	cmp	w10, w9, lsr #16
10143b524: 54000360    	b.eq	0x10143b590 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x92c>
10143b528: 7100911f    	cmp	w8, #0x24
10143b52c: 54fff701    	b.ne	0x10143b40c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x7a8>
10143b530: 79400008    	ldrh	w8, [x0]
10143b534: 52850489    	mov	w9, #0x2824             ; =10276
10143b538: 6b09011f    	cmp	w8, w9
10143b53c: 54fff680    	b.eq	0x10143b40c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x7a8>
10143b540: 79400008    	ldrh	w8, [x0]
10143b544: 528f6489    	mov	w9, #0x7b24             ; =31524
10143b548: 6b09011f    	cmp	w8, w9
10143b54c: 54fff600    	b.eq	0x10143b40c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x7a8>
10143b550: aa0003e8    	mov	x8, x0
10143b554: 38c01d09    	ldrsb	w9, [x8, #0x1]!
10143b558: 3101013f    	cmn	w9, #0x40
10143b55c: 5400254b    	b.lt	0x10143ba04 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xda0>
10143b560: aa0803e0    	mov	x0, x8
10143b564: 97d44500    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
10143b568: aa0003f9    	mov	x25, x0
10143b56c: aa0103f7    	mov	x23, x1
10143b570: b50001c1    	cbnz	x1, 0x10143b5a8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x944>
10143b574: 52800038    	mov	w24, #0x1               ; =1
10143b578: aa1803e0    	mov	x0, x24
10143b57c: aa1903e1    	mov	x1, x25
10143b580: aa1703e2    	mov	x2, x23
10143b584: 941a39a9    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10143b588: b5000277    	cbnz	x23, 0x10143b5d4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x970>
10143b58c: 17ffff94    	b	0x10143b3dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x778>
10143b590: d1000ae1    	sub	x1, x23, #0x2
10143b594: 91000800    	add	x0, x0, #0x2
10143b598: 97d444f3    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
10143b59c: aa0003f9    	mov	x25, x0
10143b5a0: aa0103f7    	mov	x23, x1
10143b5a4: b4fffe81    	cbz	x1, 0x10143b574 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x910>
10143b5a8: 97d98c52    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10143b5ac: aa1703e0    	mov	x0, x23
10143b5b0: 52800021    	mov	w1, #0x1                ; =1
10143b5b4: 97d98c49    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10143b5b8: aa0003f8    	mov	x24, x0
10143b5bc: b4002140    	cbz	x0, 0x10143b9e4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd80>
10143b5c0: aa1803e0    	mov	x0, x24
10143b5c4: aa1903e1    	mov	x1, x25
10143b5c8: aa1703e2    	mov	x2, x23
10143b5cc: 941a3997    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10143b5d0: b4fff077    	cbz	x23, 0x10143b3dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x778>
10143b5d4: aa1803e0    	mov	x0, x24
10143b5d8: aa1703e1    	mov	x1, x23
10143b5dc: 940009cc    	bl	0x10143dd0c <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x13f4>
10143b5e0: 2a160008    	orr	w8, w0, w22
10143b5e4: 36000288    	tbz	w8, #0x0, 0x10143b634 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x9d0>
10143b5e8: 8b170308    	add	x8, x24, x23
10143b5ec: 385ff108    	ldurb	w8, [x8, #-0x1]
10143b5f0: 7101711f    	cmp	w8, #0x5c
10143b5f4: 1a9f17f6    	cset	w22, eq
10143b5f8: f94037f9    	ldr	x25, [sp, #0x68]
10143b5fc: f9402fe8    	ldr	x8, [sp, #0x58]
10143b600: eb08033f    	cmp	x25, x8
10143b604: 54000061    	b.ne	0x10143b610 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x9ac>
10143b608: 910163e0    	add	x0, sp, #0x58
10143b60c: 941a1d59    	bl	0x101ac2b70 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hb575521872840d8cE>
10143b610: f94033e8    	ldr	x8, [sp, #0x60]
10143b614: 9b132328    	madd	x8, x25, x19, x8
10143b618: a9006117    	stp	x23, x24, [x8]
10143b61c: f9000917    	str	x23, [x8, #0x10]
10143b620: 91000728    	add	x8, x25, #0x1
10143b624: f90037e8    	str	x8, [sp, #0x68]
10143b628: 17ffff6d    	b	0x10143b3dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x778>
10143b62c: 52800016    	mov	w22, #0x0               ; =0
10143b630: 17ffff6b    	b	0x10143b3dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x778>
10143b634: f94037e8    	ldr	x8, [sp, #0x68]
10143b638: b40002a8    	cbz	x8, 0x10143b68c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xa28>
10143b63c: 3cc583e0    	ldur	q0, [sp, #0x58]
10143b640: 3d8033e0    	str	q0, [sp, #0xc0]
10143b644: f94037e8    	ldr	x8, [sp, #0x68]
10143b648: f9006be8    	str	x8, [sp, #0xd0]
10143b64c: a905f3ff    	stp	xzr, x28, [sp, #0x58]
10143b650: f90037ff    	str	xzr, [sp, #0x68]
10143b654: f9402bf6    	ldr	x22, [sp, #0x50]
10143b658: f94023e8    	ldr	x8, [sp, #0x40]
10143b65c: eb0802df    	cmp	x22, x8
10143b660: 54000061    	b.ne	0x10143b66c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xa08>
10143b664: 910103e0    	add	x0, sp, #0x40
10143b668: 941951eb    	bl	0x101a8fe14 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hed155317132a177cE>
10143b66c: f94027e8    	ldr	x8, [sp, #0x48]
10143b670: 9b1322c8    	madd	x8, x22, x19, x8
10143b674: 3dc033e0    	ldr	q0, [sp, #0xc0]
10143b678: 3d800100    	str	q0, [x8]
10143b67c: f9406be9    	ldr	x9, [sp, #0xd0]
10143b680: f9000909    	str	x9, [x8, #0x10]
10143b684: 910006c8    	add	x8, x22, #0x1
10143b688: f9002be8    	str	x8, [sp, #0x50]
10143b68c: aa1803e0    	mov	x0, x24
10143b690: aa1703e1    	mov	x1, x23
10143b694: 52800022    	mov	w2, #0x1                ; =1
10143b698: 97d98c11    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143b69c: 52800016    	mov	w22, #0x0               ; =0
10143b6a0: 17ffff4f    	b	0x10143b3dc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x778>
10143b6a4: f94037e8    	ldr	x8, [sp, #0x68]
10143b6a8: f94023f4    	ldr	x20, [sp, #0x40]
10143b6ac: b40003c8    	cbz	x8, 0x10143b724 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xac0>
10143b6b0: 3cc583e0    	ldur	q0, [sp, #0x58]
10143b6b4: 3d8033e0    	str	q0, [sp, #0xc0]
10143b6b8: f94037e8    	ldr	x8, [sp, #0x68]
10143b6bc: f9006be8    	str	x8, [sp, #0xd0]
10143b6c0: 52800108    	mov	w8, #0x8                ; =8
10143b6c4: a905a3ff    	stp	xzr, x8, [sp, #0x58]
10143b6c8: f90037ff    	str	xzr, [sp, #0x68]
10143b6cc: f9402bf3    	ldr	x19, [sp, #0x50]
10143b6d0: eb14027f    	cmp	x19, x20
10143b6d4: 54000081    	b.ne	0x10143b6e4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xa80>
10143b6d8: 910103e0    	add	x0, sp, #0x40
10143b6dc: 941951ce    	bl	0x101a8fe14 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hed155317132a177cE>
10143b6e0: f94023f4    	ldr	x20, [sp, #0x40]
10143b6e4: f94027f7    	ldr	x23, [sp, #0x48]
10143b6e8: 52800308    	mov	w8, #0x18               ; =24
10143b6ec: 9b085e68    	madd	x8, x19, x8, x23
10143b6f0: 3dc033e0    	ldr	q0, [sp, #0xc0]
10143b6f4: 3d800100    	str	q0, [x8]
10143b6f8: f9406be9    	ldr	x9, [sp, #0xd0]
10143b6fc: f9000909    	str	x9, [x8, #0x10]
10143b700: 91000668    	add	x8, x19, #0x1
10143b704: f9002be8    	str	x8, [sp, #0x50]
10143b708: 52800309    	mov	w9, #0x18               ; =24
10143b70c: a9075ff7    	stp	x23, x23, [sp, #0x70]
10143b710: 9b095d13    	madd	x19, x8, x9, x23
10143b714: a9084ff4    	stp	x20, x19, [sp, #0x80]
10143b718: aa1703f5    	mov	x21, x23
10143b71c: b5000128    	cbnz	x8, 0x10143b740 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xadc>
10143b720: 1400006c    	b	0x10143b8d0 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xc6c>
10143b724: a944a3f7    	ldp	x23, x8, [sp, #0x48]
10143b728: 52800309    	mov	w9, #0x18               ; =24
10143b72c: a9075ff7    	stp	x23, x23, [sp, #0x70]
10143b730: 9b095d13    	madd	x19, x8, x9, x23
10143b734: a9084ff4    	stp	x20, x19, [sp, #0x80]
10143b738: aa1703f5    	mov	x21, x23
10143b73c: b4000ca8    	cbz	x8, 0x10143b8d0 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xc6c>
10143b740: 9102a3f6    	add	x22, sp, #0xa8
10143b744: f9401fe8    	ldr	x8, [sp, #0x38]
10143b748: f9400108    	ldr	x8, [x8]
10143b74c: f9000fe8    	str	x8, [sp, #0x18]
10143b750: d2f0001c    	mov	x28, #-0x8000000000000000 ; =-9223372036854775808
10143b754: aa1703f5    	mov	x21, x23
10143b758: 1400000e    	b	0x10143b790 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xb2c>
10143b75c: f9400728    	ldr	x8, [x25, #0x8]
10143b760: 52800909    	mov	w9, #0x48               ; =72
10143b764: 9b092308    	madd	x8, x24, x9, x8
10143b768: ad4707e0    	ldp	q0, q1, [sp, #0xe0]
10143b76c: ad010500    	stp	q0, q1, [x8, #0x20]
10143b770: f94083e9    	ldr	x9, [sp, #0x100]
10143b774: f9002109    	str	x9, [x8, #0x40]
10143b778: ad4603e1    	ldp	q1, q0, [sp, #0xc0]
10143b77c: ad000101    	stp	q1, q0, [x8]
10143b780: 91000708    	add	x8, x24, #0x1
10143b784: f9000b28    	str	x8, [x25, #0x10]
10143b788: eb1302bf    	cmp	x21, x19
10143b78c: 54000a20    	b.eq	0x10143b8d0 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xc6c>
10143b790: f94002ba    	ldr	x26, [x21]
10143b794: 3cc082a0    	ldur	q0, [x21, #0x8]
10143b798: 910062b5    	add	x21, x21, #0x18
10143b79c: 3d8027e0    	str	q0, [sp, #0x90]
10143b7a0: eb1c035f    	cmp	x26, x28
10143b7a4: 54000960    	b.eq	0x10143b8d0 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xc6c>
10143b7a8: f90057fa    	str	x26, [sp, #0xa8]
10143b7ac: 3dc027e0    	ldr	q0, [sp, #0x90]
10143b7b0: 3c8082c0    	stur	q0, [x22, #0x8]
10143b7b4: a94b63f9    	ldp	x25, x24, [sp, #0xb0]
10143b7b8: d1001b08    	sub	x8, x24, #0x6
10143b7bc: b100151f    	cmn	x8, #0x5
10143b7c0: 54000122    	b.hs	0x10143b7e4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xb80>
10143b7c4: b5000178    	cbnz	x24, 0x10143b7f0 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xb8c>
10143b7c8: b4fffe1a    	cbz	x26, 0x10143b788 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xb24>
10143b7cc: 8b1a0748    	add	x8, x26, x26, lsl #1
10143b7d0: d37df101    	lsl	x1, x8, #3
10143b7d4: aa1903e0    	mov	x0, x25
10143b7d8: 52800102    	mov	w2, #0x8                ; =8
10143b7dc: 97d98bc0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143b7e0: 17ffffea    	b	0x10143b788 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xb24>
10143b7e4: a9408720    	ldp	x0, x1, [x25, #0x8]
10143b7e8: 94000949    	bl	0x10143dd0c <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x13f4>
10143b7ec: 35000180    	cbnz	w0, 0x10143b81c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xbb8>
10143b7f0: 9100233b    	add	x27, x25, #0x8
10143b7f4: 14000004    	b	0x10143b804 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xba0>
10143b7f8: 9100637b    	add	x27, x27, #0x18
10143b7fc: f1000718    	subs	x24, x24, #0x1
10143b800: 54fffe40    	b.eq	0x10143b7c8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xb64>
10143b804: f85f8361    	ldur	x1, [x27, #-0x8]
10143b808: b4ffff81    	cbz	x1, 0x10143b7f8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xb94>
10143b80c: f9400360    	ldr	x0, [x27]
10143b810: 52800022    	mov	w2, #0x1                ; =1
10143b814: 97d98bb2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143b818: 17fffff8    	b	0x10143b7f8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xb94>
10143b81c: f9003ff5    	str	x21, [sp, #0x78]
10143b820: 3cca83e0    	ldur	q0, [sp, #0xa8]
10143b824: 3c9903a0    	stur	q0, [x29, #-0x70]
10143b828: f9405fe8    	ldr	x8, [sp, #0xb8]
10143b82c: f81a03a8    	stur	x8, [x29, #-0x60]
10143b830: d2f00019    	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
10143b834: f9400fe8    	ldr	x8, [sp, #0x18]
10143b838: eb19011f    	cmp	x8, x25
10143b83c: f9401bf8    	ldr	x24, [sp, #0x30]
10143b840: 540000e0    	b.eq	0x10143b85c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xbf8>
10143b844: 910303e8    	add	x8, sp, #0xc0
10143b848: f9401fe0    	ldr	x0, [sp, #0x38]
10143b84c: 940f4e60    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10143b850: a94c27f9    	ldp	x25, x9, [sp, #0xc0]
10143b854: f9406be8    	ldr	x8, [sp, #0xd0]
10143b858: a900a7e8    	stp	x8, x9, [sp, #0x8]
10143b85c: b4000118    	cbz	x24, 0x10143b87c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xc18>
10143b860: 97d98ba4    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10143b864: aa1803e0    	mov	x0, x24
10143b868: 52800021    	mov	w1, #0x1                ; =1
10143b86c: 97d98b9b    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10143b870: aa0003fa    	mov	x26, x0
10143b874: b5000060    	cbnz	x0, 0x10143b880 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xc1c>
10143b878: 1400005f    	b	0x10143b9f4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd90>
10143b87c: 5280003a    	mov	w26, #0x1               ; =1
10143b880: aa1a03e0    	mov	x0, x26
10143b884: f94017e1    	ldr	x1, [sp, #0x28]
10143b888: aa1803e2    	mov	x2, x24
10143b88c: 941a38e7    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10143b890: 3cca83e0    	ldur	q0, [sp, #0xa8]
10143b894: 3d8033e0    	str	q0, [sp, #0xc0]
10143b898: f9405fe8    	ldr	x8, [sp, #0xb8]
10143b89c: a940abe9    	ldp	x9, x10, [sp, #0x8]
10143b8a0: a90f2bf9    	stp	x25, x10, [sp, #0xf0]
10143b8a4: f90083e9    	str	x9, [sp, #0x100]
10143b8a8: a90d63e8    	stp	x8, x24, [sp, #0xd0]
10143b8ac: a90e63fa    	stp	x26, x24, [sp, #0xe0]
10143b8b0: f94013f9    	ldr	x25, [sp, #0x20]
10143b8b4: f9400b38    	ldr	x24, [x25, #0x10]
10143b8b8: f9400328    	ldr	x8, [x25]
10143b8bc: eb08031f    	cmp	x24, x8
10143b8c0: 54fff4e1    	b.ne	0x10143b75c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xaf8>
10143b8c4: aa1903e0    	mov	x0, x25
10143b8c8: 941951d5    	bl	0x101a9001c <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h8241b837d23a106fE>
10143b8cc: 17ffffa4    	b	0x10143b75c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xaf8>
10143b8d0: f9003ff5    	str	x21, [sp, #0x78]
10143b8d4: eb150268    	subs	x8, x19, x21
10143b8d8: 54000420    	b.eq	0x10143b95c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xcf8>
10143b8dc: d2800016    	mov	x22, #0x0               ; =0
10143b8e0: d343fd08    	lsr	x8, x8, #3
10143b8e4: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
10143b8e8: f2955569    	movk	x9, #0xaaab
10143b8ec: 9b097d18    	mul	x24, x8, x9
10143b8f0: 52800319    	mov	w25, #0x18              ; =24
10143b8f4: 14000004    	b	0x10143b904 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xca0>
10143b8f8: 910006d6    	add	x22, x22, #0x1
10143b8fc: eb1802df    	cmp	x22, x24
10143b900: 540002e0    	b.eq	0x10143b95c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xcf8>
10143b904: 9b1956da    	madd	x26, x22, x25, x21
10143b908: a940ef53    	ldp	x19, x27, [x26, #0x8]
10143b90c: b400019b    	cbz	x27, 0x10143b93c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xcd8>
10143b910: 9100227c    	add	x28, x19, #0x8
10143b914: 14000004    	b	0x10143b924 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xcc0>
10143b918: 9100639c    	add	x28, x28, #0x18
10143b91c: f100077b    	subs	x27, x27, #0x1
10143b920: 540000e0    	b.eq	0x10143b93c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xcd8>
10143b924: f85f8381    	ldur	x1, [x28, #-0x8]
10143b928: b4ffff81    	cbz	x1, 0x10143b918 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xcb4>
10143b92c: f9400380    	ldr	x0, [x28]
10143b930: 52800022    	mov	w2, #0x1                ; =1
10143b934: 97d98b6a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143b938: 17fffff8    	b	0x10143b918 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xcb4>
10143b93c: f9400348    	ldr	x8, [x26]
10143b940: b4fffdc8    	cbz	x8, 0x10143b8f8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xc94>
10143b944: 8b080508    	add	x8, x8, x8, lsl #1
10143b948: d37df101    	lsl	x1, x8, #3
10143b94c: aa1303e0    	mov	x0, x19
10143b950: 52800102    	mov	w2, #0x8                ; =8
10143b954: 97d98b62    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143b958: 17ffffe8    	b	0x10143b8f8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xc94>
10143b95c: b40000d4    	cbz	x20, 0x10143b974 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd10>
10143b960: 8b140688    	add	x8, x20, x20, lsl #1
10143b964: d37df101    	lsl	x1, x8, #3
10143b968: aa1703e0    	mov	x0, x23
10143b96c: 52800102    	mov	w2, #0x8                ; =8
10143b970: 97d98b5b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143b974: a94653f3    	ldp	x19, x20, [sp, #0x60]
10143b978: b4000194    	cbz	x20, 0x10143b9a8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd44>
10143b97c: 91002275    	add	x21, x19, #0x8
10143b980: 14000004    	b	0x10143b990 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd2c>
10143b984: 910062b5    	add	x21, x21, #0x18
10143b988: f1000694    	subs	x20, x20, #0x1
10143b98c: 540000e0    	b.eq	0x10143b9a8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd44>
10143b990: f85f82a1    	ldur	x1, [x21, #-0x8]
10143b994: b4ffff81    	cbz	x1, 0x10143b984 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd20>
10143b998: f94002a0    	ldr	x0, [x21]
10143b99c: 52800022    	mov	w2, #0x1                ; =1
10143b9a0: 97d98b4f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143b9a4: 17fffff8    	b	0x10143b984 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd20>
10143b9a8: f9402fe8    	ldr	x8, [sp, #0x58]
10143b9ac: b40000c8    	cbz	x8, 0x10143b9c4 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xd60>
10143b9b0: 8b080508    	add	x8, x8, x8, lsl #1
10143b9b4: d37df101    	lsl	x1, x8, #3
10143b9b8: aa1303e0    	mov	x0, x19
10143b9bc: 52800102    	mov	w2, #0x8                ; =8
10143b9c0: 97d98b47    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143b9c4: a9587bfd    	ldp	x29, x30, [sp, #0x180]
10143b9c8: a9574ff4    	ldp	x20, x19, [sp, #0x170]
10143b9cc: a95657f6    	ldp	x22, x21, [sp, #0x160]
10143b9d0: a9555ff8    	ldp	x24, x23, [sp, #0x150]
10143b9d4: a95467fa    	ldp	x26, x25, [sp, #0x140]
10143b9d8: a9536ffc    	ldp	x28, x27, [sp, #0x130]
10143b9dc: 910643ff    	add	sp, sp, #0x190
10143b9e0: d65f03c0    	ret
10143b9e4: 52800020    	mov	w0, #0x1                ; =1
10143b9e8: aa1703e1    	mov	x1, x23
10143b9ec: 941a1e62    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10143b9f0: 1400000b    	b	0x10143ba1c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xdb8>
10143b9f4: 52800020    	mov	w0, #0x1                ; =1
10143b9f8: aa1803e1    	mov	x1, x24
10143b9fc: 941a1e5e    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10143ba00: 14000007    	b	0x10143ba1c <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xdb8>
10143ba04: d0007164    	adrp	x4, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
10143ba08: 9113c084    	add	x4, x4, #0x4f0
10143ba0c: aa1703e1    	mov	x1, x23
10143ba10: 52800022    	mov	w2, #0x1                ; =1
10143ba14: aa1703e3    	mov	x3, x23
10143ba18: 941a1efc    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
10143ba1c: d4200020    	brk	#0x1
10143ba20: aa0003f3    	mov	x19, x0
10143ba24: 910303e0    	add	x0, sp, #0xc0
10143ba28: 94006047    	bl	0x101453b44 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x66bc>
10143ba2c: 9101c3e0    	add	x0, sp, #0x70
10143ba30: 9400532a    	bl	0x1014506d8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x3250>
10143ba34: 910163e0    	add	x0, sp, #0x58
10143ba38: 97d41c35    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10143ba3c: aa1303e0    	mov	x0, x19
10143ba40: 941a36e5    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10143ba44: aa0003f3    	mov	x19, x0
10143ba48: 14000004    	b	0x10143ba58 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xdf4>
10143ba4c: aa0003f3    	mov	x19, x0
10143ba50: f240fb3f    	tst	x25, #0x7fffffffffffffff
10143ba54: 54000061    	b.ne	0x10143ba60 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xdfc>
10143ba58: d101c3a0    	sub	x0, x29, #0x70
10143ba5c: 14000025    	b	0x10143baf0 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xe8c>
10143ba60: f9400be0    	ldr	x0, [sp, #0x10]
10143ba64: aa1903e1    	mov	x1, x25
10143ba68: 52800022    	mov	w2, #0x1                ; =1
10143ba6c: 97d98b1c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143ba70: d101c3a0    	sub	x0, x29, #0x70
10143ba74: 1400001f    	b	0x10143baf0 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xe8c>
10143ba78: 14000007    	b	0x10143ba94 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xe30>
10143ba7c: 14000001    	b	0x10143ba80 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xe1c>
10143ba80: aa0003f3    	mov	x19, x0
10143ba84: 910303e0    	add	x0, sp, #0xc0
10143ba88: 97d41c21    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10143ba8c: 1400000c    	b	0x10143babc <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xe58>
10143ba90: 1400000a    	b	0x10143bab8 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0xe54>
10143ba94: aa0003f3    	mov	x19, x0
10143ba98: 910303e0    	add	x0, sp, #0xc0
10143ba9c: 97d41c1c    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10143baa0: 910163e0    	add	x0, sp, #0x58
10143baa4: 97d41c1a    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10143baa8: 910103e0    	add	x0, sp, #0x40
10143baac: 94006a88    	bl	0x1014564cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x9044>
10143bab0: aa1303e0    	mov	x0, x19
10143bab4: 941a36c8    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10143bab8: aa0003f3    	mov	x19, x0
10143babc: aa1803e0    	mov	x0, x24
10143bac0: aa1703e1    	mov	x1, x23
10143bac4: 52800022    	mov	w2, #0x1                ; =1
10143bac8: 97d98b05    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143bacc: 910163e0    	add	x0, sp, #0x58
10143bad0: 97d41c0f    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10143bad4: 910103e0    	add	x0, sp, #0x40
10143bad8: 94006a7d    	bl	0x1014564cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x9044>
10143badc: aa1303e0    	mov	x0, x19
10143bae0: 941a36bd    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10143bae4: aa0003f3    	mov	x19, x0
10143bae8: f9003ff5    	str	x21, [sp, #0x78]
10143baec: 9102a3e0    	add	x0, sp, #0xa8
10143baf0: 97d41c07    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10143baf4: 9101c3e0    	add	x0, sp, #0x70
10143baf8: 940052f8    	bl	0x1014506d8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x3250>
10143bafc: 910163e0    	add	x0, sp, #0x58
10143bb00: 97d41c03    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10143bb04: aa1303e0    	mov	x0, x19
10143bb08: 941a36b3    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10143bb0c: aa0003f3    	mov	x19, x0
10143bb10: 910163e0    	add	x0, sp, #0x58
10143bb14: 97d41bfe    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10143bb18: 910103e0    	add	x0, sp, #0x40
10143bb1c: 94006a6c    	bl	0x1014564cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x9044>
10143bb20: aa1303e0    	mov	x0, x19
10143bb24: 941a36ac    	bl	0x101ac95d4 <_writev+0x101ac95d4>
