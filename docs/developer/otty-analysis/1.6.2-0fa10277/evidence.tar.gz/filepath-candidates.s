
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010144907c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E>:
10144907c: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
101449080: a90167fa    	stp	x26, x25, [sp, #0x10]
101449084: a9025ff8    	stp	x24, x23, [sp, #0x20]
101449088: a90357f6    	stp	x22, x21, [sp, #0x30]
10144908c: a9044ff4    	stp	x20, x19, [sp, #0x40]
101449090: a9057bfd    	stp	x29, x30, [sp, #0x50]
101449094: 910143fd    	add	x29, sp, #0x50
101449098: d10803ff    	sub	sp, sp, #0x200
10144909c: aa0103f7    	mov	x23, x1
1014490a0: aa0003f8    	mov	x24, x0
1014490a4: aa0803f3    	mov	x19, x8
1014490a8: 39005fe4    	strb	w4, [sp, #0x17]
1014490ac: 370000c4    	tbnz	w4, #0x0, 0x1014490c4 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x48>
1014490b0: 350000a5    	cbnz	w5, 0x1014490c4 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x48>
1014490b4: 52800108    	mov	w8, #0x8                ; =8
1014490b8: a900227f    	stp	xzr, x8, [x19]
1014490bc: f9000a7f    	str	xzr, [x19, #0x10]
1014490c0: 14000203    	b	0x1014498cc <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x850>
1014490c4: 9101a3fc    	add	x28, sp, #0x68
1014490c8: a904dff8    	stp	x24, x23, [sp, #0x48]
1014490cc: a9048f82    	stp	x2, x3, [x28, #0x48]
1014490d0: b40004f7    	cbz	x23, 0x10144916c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xf0>
1014490d4: aa1803e8    	mov	x8, x24
1014490d8: 3840150a    	ldrb	w10, [x8], #0x1
1014490dc: d10006e9    	sub	x9, x23, #0x1
1014490e0: 7101f95f    	cmp	w10, #0x7e
1014490e4: fa400924    	ccmp	x9, #0x0, #0x4, eq
1014490e8: 54000780    	b.eq	0x1014491d8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x15c>
1014490ec: 39c0010b    	ldrsb	w11, [x8]
1014490f0: 12001d6a    	and	w10, w11, #0xff
1014490f4: 37f8048b    	tbnz	w11, #0x1f, 0x101449184 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x108>
1014490f8: 7100bd5f    	cmp	w10, #0x2f
1014490fc: 540006e1    	b.ne	0x1014491d8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x15c>
101449100: a90ca788    	stp	x8, x9, [x28, #0xc8]
101449104: 910323e8    	add	x8, sp, #0xc8
101449108: 94054725    	bl	0x10159ad9c <__ZN11otty_config6Config13user_home_dir17hfc53f12b1c41c57eE>
10144910c: f9403394    	ldr	x20, [x28, #0x60]
101449110: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101449114: eb08029f    	cmp	x20, x8
101449118: 54000c40    	b.eq	0x1014492a0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x224>
10144911c: a9468795    	ldp	x21, x1, [x28, #0x68]
101449120: d10343a8    	sub	x8, x29, #0xd0
101449124: aa1503e0    	mov	x0, x21
101449128: 940f159d    	bl	0x10180e79c <__ZN5alloc6string6String15from_utf8_lossy17hcb81682812c4da7aE>
10144912c: a951e79a    	ldp	x26, x25, [x28, #0x118]
101449130: f9409796    	ldr	x22, [x28, #0x128]
101449134: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101449138: eb08035f    	cmp	x26, x8
10144913c: 54000a21    	b.ne	0x101449280 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x204>
101449140: b4000936    	cbz	x22, 0x101449264 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x1e8>
101449144: 97d9556b    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101449148: aa1603e0    	mov	x0, x22
10144914c: 52800021    	mov	w1, #0x1                ; =1
101449150: 97d95562    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101449154: aa0003fa    	mov	x26, x0
101449158: b5000880    	cbnz	x0, 0x101449268 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x1ec>
10144915c: 52800020    	mov	w0, #0x1                ; =1
101449160: aa1603e1    	mov	x1, x22
101449164: 9419e884    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101449168: 1400022d    	b	0x101449a1c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x9a0>
10144916c: aa1803e0    	mov	x0, x24
101449170: d2800001    	mov	x1, #0x0                ; =0
101449174: 940de98d    	bl	0x1017c37a8 <__ZN3std4path4Path11is_absolute17hfb29e0a39a1869d7E>
101449178: 36000460    	tbz	w0, #0x0, 0x101449204 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x188>
10144917c: 52800034    	mov	w20, #0x1               ; =1
101449180: 1400004e    	b	0x1014492b8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x23c>
101449184: 39400b0b    	ldrb	w11, [x24, #0x2]
101449188: 1200156c    	and	w12, w11, #0x3f
10144918c: 7103815f    	cmp	w10, #0xe0
101449190: 540001c3    	b.lo	0x1014491c8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x14c>
101449194: 1200114b    	and	w11, w10, #0x1f
101449198: 39400f0d    	ldrb	w13, [x24, #0x3]
10144919c: 120015ad    	and	w13, w13, #0x3f
1014491a0: 2a0c19ac    	orr	w12, w13, w12, lsl #6
1014491a4: 7103c15f    	cmp	w10, #0xf0
1014491a8: 54000563    	b.lo	0x101449254 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x1d8>
1014491ac: 3940130a    	ldrb	w10, [x24, #0x4]
1014491b0: 1200154a    	and	w10, w10, #0x3f
1014491b4: 2a0c194a    	orr	w10, w10, w12, lsl #6
1014491b8: 330e096a    	bfi	w10, w11, #18, #3
1014491bc: 7100bd5f    	cmp	w10, #0x2f
1014491c0: 54fffa00    	b.eq	0x101449100 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x84>
1014491c4: 14000005    	b	0x1014491d8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x15c>
1014491c8: 331a114c    	bfi	w12, w10, #6, #5
1014491cc: aa0c03ea    	mov	x10, x12
1014491d0: 7100bd5f    	cmp	w10, #0x2f
1014491d4: 54fff960    	b.eq	0x101449100 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x84>
1014491d8: aa1803e0    	mov	x0, x24
1014491dc: aa1703e1    	mov	x1, x23
1014491e0: 940de972    	bl	0x1017c37a8 <__ZN3std4path4Path11is_absolute17hfb29e0a39a1869d7E>
1014491e4: 36000100    	tbz	w0, #0x0, 0x101449204 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x188>
1014491e8: 97d95542    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014491ec: aa1703e0    	mov	x0, x23
1014491f0: 52800021    	mov	w1, #0x1                ; =1
1014491f4: 97d95539    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014491f8: aa0003f4    	mov	x20, x0
1014491fc: b50005e0    	cbnz	x0, 0x1014492b8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x23c>
101449200: 140001ee    	b	0x1014499b8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x93c>
101449204: aa1803e0    	mov	x0, x24
101449208: aa1703e1    	mov	x1, x23
10144920c: 94000273    	bl	0x101449bd8 <__ZN17otty_autocomplete7sources6is_dir17h36378ede18c97a36E+0x4>
101449210: b9006380    	str	w0, [x28, #0x60]
101449214: 9102c3e8    	add	x8, sp, #0xb0
101449218: d0000029    	adrp	x9, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
10144921c: 91117129    	add	x9, x9, #0x45c
101449220: a911a788    	stp	x8, x9, [x28, #0x118]
101449224: f0001e28    	adrp	x8, 0x101810000 <__ZN92_$LT$alloc..borrow..Cow$LT$str$GT$$u20$as$u20$core..ops..arith..AddAssign$LT$$RF$str$GT$$GT$10add_assign17h2c4b02baf6f14f7dE+0x440>
101449228: 912ab108    	add	x8, x8, #0xaac
10144922c: 910323ea    	add	x10, sp, #0xc8
101449230: a912a38a    	stp	x10, x8, [x28, #0x128]
101449234: 910123e8    	add	x8, sp, #0x48
101449238: a913a788    	stp	x8, x9, [x28, #0x138]
10144923c: d0004da0    	adrp	x0, 0x101dff000 <_writev+0x101dff000>
101449240: 9117ec00    	add	x0, x0, #0x5fb
101449244: 910063e8    	add	x8, sp, #0x18
101449248: d10343a1    	sub	x1, x29, #0xd0
10144924c: 940f08cd    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
101449250: 14000020    	b	0x1014492d0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x254>
101449254: 2a0b318a    	orr	w10, w12, w11, lsl #12
101449258: 7100bd5f    	cmp	w10, #0x2f
10144925c: 54fff520    	b.eq	0x101449100 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x84>
101449260: 17ffffde    	b	0x1014491d8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x15c>
101449264: 5280003a    	mov	w26, #0x1               ; =1
101449268: aa1a03e0    	mov	x0, x26
10144926c: aa1903e1    	mov	x1, x25
101449270: aa1603e2    	mov	x2, x22
101449274: 941a026d    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101449278: aa1a03f9    	mov	x25, x26
10144927c: aa1603fa    	mov	x26, x22
101449280: b40000b4    	cbz	x20, 0x101449294 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x218>
101449284: aa1503e0    	mov	x0, x21
101449288: aa1403e1    	mov	x1, x20
10144928c: 52800022    	mov	w2, #0x1                ; =1
101449290: 97d95513    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101449294: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101449298: eb08035f    	cmp	x26, x8
10144929c: 54003521    	b.ne	0x101449940 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x8c4>
1014492a0: 97d95514    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014492a4: aa1703e0    	mov	x0, x23
1014492a8: 52800021    	mov	w1, #0x1                ; =1
1014492ac: 97d9550b    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014492b0: b4003840    	cbz	x0, 0x1014499b8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x93c>
1014492b4: aa0003f4    	mov	x20, x0
1014492b8: aa1403e0    	mov	x0, x20
1014492bc: aa1803e1    	mov	x1, x24
1014492c0: aa1703e2    	mov	x2, x23
1014492c4: 941a0259    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014492c8: a901d3f7    	stp	x23, x20, [sp, #0x18]
1014492cc: f90017f7    	str	x23, [sp, #0x28]
1014492d0: a94253fa    	ldp	x26, x20, [sp, #0x20]
1014492d4: 8b140348    	add	x8, x26, x20
1014492d8: b4000114    	cbz	x20, 0x1014492f8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x27c>
1014492dc: 38dff109    	ldursb	w9, [x8, #-0x1]
1014492e0: 37f80109    	tbnz	w9, #0x1f, 0x101449300 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x284>
1014492e4: 7100bd3f    	cmp	w9, #0x2f
1014492e8: 1a9f17e9    	cset	w9, eq
1014492ec: 3900dfe9    	strb	w9, [sp, #0x37]
1014492f0: 54000581    	b.ne	0x1014493a0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x324>
1014492f4: 14000020    	b	0x101449374 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x2f8>
1014492f8: 3900dfff    	strb	wzr, [sp, #0x37]
1014492fc: 14000029    	b	0x1014493a0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x324>
101449300: 38dfe10a    	ldursb	w10, [x8, #-0x2]
101449304: 3101015f    	cmn	w10, #0x40
101449308: 5400014a    	b.ge	0x101449330 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x2b4>
10144930c: 12001d4a    	and	w10, w10, #0xff
101449310: 38dfd10b    	ldursb	w11, [x8, #-0x3]
101449314: 3101017f    	cmn	w11, #0x40
101449318: 540001ca    	b.ge	0x101449350 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x2d4>
10144931c: 12001d6b    	and	w11, w11, #0xff
101449320: 385fc10c    	ldurb	w12, [x8, #-0x4]
101449324: 1200156b    	and	w11, w11, #0x3f
101449328: 331a098b    	bfi	w11, w12, #6, #3
10144932c: 1400000a    	b	0x101449354 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x2d8>
101449330: 1200114a    	and	w10, w10, #0x1f
101449334: 12001529    	and	w9, w9, #0x3f
101449338: 2a0a1929    	orr	w9, w9, w10, lsl #6
10144933c: 7100bd3f    	cmp	w9, #0x2f
101449340: 1a9f17e9    	cset	w9, eq
101449344: 3900dfe9    	strb	w9, [sp, #0x37]
101449348: 540002c1    	b.ne	0x1014493a0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x324>
10144934c: 1400000a    	b	0x101449374 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x2f8>
101449350: 12000d6b    	and	w11, w11, #0xf
101449354: 1200154a    	and	w10, w10, #0x3f
101449358: 2a0b194a    	orr	w10, w10, w11, lsl #6
10144935c: 12001529    	and	w9, w9, #0x3f
101449360: 2a0a1929    	orr	w9, w9, w10, lsl #6
101449364: 7100bd3f    	cmp	w9, #0x2f
101449368: 1a9f17e9    	cset	w9, eq
10144936c: 3900dfe9    	strb	w9, [sp, #0x37]
101449370: 54000181    	b.ne	0x1014493a0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x324>
101449374: d10343a8    	sub	x8, x29, #0xd0
101449378: 910063e0    	add	x0, sp, #0x18
10144937c: 940f1794    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101449380: d2800014    	mov	x20, #0x0               ; =0
101449384: a951d796    	ldp	x22, x21, [x28, #0x118]
101449388: 52800039    	mov	w25, #0x1               ; =1
10144938c: f9409781    	ldr	x1, [x28, #0x128]
101449390: 140000a4    	b	0x101449620 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x5a4>
101449394: aa0a03e8    	mov	x8, x10
101449398: 7100bd3f    	cmp	w9, #0x2f
10144939c: 54000460    	b.eq	0x101449428 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x3ac>
1014493a0: eb08035f    	cmp	x26, x8
1014493a4: 54000560    	b.eq	0x101449450 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x3d4>
1014493a8: aa0803ea    	mov	x10, x8
1014493ac: 38dffd49    	ldrsb	w9, [x10, #-0x1]!
1014493b0: 36ffff29    	tbz	w9, #0x1f, 0x101449394 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x318>
1014493b4: aa0803eb    	mov	x11, x8
1014493b8: 38dfed6a    	ldrsb	w10, [x11, #-0x2]!
1014493bc: 3101015f    	cmn	w10, #0x40
1014493c0: 5400014a    	b.ge	0x1014493e8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x36c>
1014493c4: aa0803ec    	mov	x12, x8
1014493c8: 38dfdd8b    	ldrsb	w11, [x12, #-0x3]!
1014493cc: 3101017f    	cmn	w11, #0x40
1014493d0: 540001aa    	b.ge	0x101449404 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x388>
1014493d4: 12001d6b    	and	w11, w11, #0xff
1014493d8: 385fcd0c    	ldrb	w12, [x8, #-0x4]!
1014493dc: 1200156b    	and	w11, w11, #0x3f
1014493e0: 331a098b    	bfi	w11, w12, #6, #3
1014493e4: 1400000a    	b	0x10144940c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x390>
1014493e8: 1200114a    	and	w10, w10, #0x1f
1014493ec: aa0b03e8    	mov	x8, x11
1014493f0: 12001529    	and	w9, w9, #0x3f
1014493f4: 2a0a1929    	orr	w9, w9, w10, lsl #6
1014493f8: 7100bd3f    	cmp	w9, #0x2f
1014493fc: 54fffd21    	b.ne	0x1014493a0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x324>
101449400: 1400000a    	b	0x101449428 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x3ac>
101449404: 12000d6b    	and	w11, w11, #0xf
101449408: aa0c03e8    	mov	x8, x12
10144940c: 12001d4a    	and	w10, w10, #0xff
101449410: 1200154a    	and	w10, w10, #0x3f
101449414: 2a0b194a    	orr	w10, w10, w11, lsl #6
101449418: 12001529    	and	w9, w9, #0x3f
10144941c: 2a0a1929    	orr	w9, w9, w10, lsl #6
101449420: 7100bd3f    	cmp	w9, #0x2f
101449424: 54fffbe1    	b.ne	0x1014493a0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x324>
101449428: eb1a0116    	subs	x22, x8, x26
10144942c: 540004a0    	b.eq	0x1014494c0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x444>
101449430: eb1402df    	cmp	x22, x20
101449434: 54000622    	b.hs	0x1014494f8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x47c>
101449438: 38f66b48    	ldrsb	w8, [x26, x22]
10144943c: 3101051f    	cmn	w8, #0x41
101449440: 540005ec    	b.gt	0x1014494fc <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x480>
101449444: 90007104    	adrp	x4, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101449448: 91276084    	add	x4, x4, #0x9d8
10144944c: 14000025    	b	0x1014494e0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x464>
101449450: 97d954a8    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101449454: 52800036    	mov	w22, #0x1               ; =1
101449458: 52800020    	mov	w0, #0x1                ; =1
10144945c: 52800021    	mov	w1, #0x1                ; =1
101449460: 97d9549e    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101449464: b4002a20    	cbz	x0, 0x1014499a8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x92c>
101449468: aa0003f5    	mov	x21, x0
10144946c: 528005c8    	mov	w8, #0x2e               ; =46
101449470: 39000008    	strb	w8, [x0]
101449474: b4000174    	cbz	x20, 0x1014494a0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x424>
101449478: 97d9549e    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10144947c: aa1403e0    	mov	x0, x20
101449480: 52800021    	mov	w1, #0x1                ; =1
101449484: 97d95495    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101449488: aa0003f9    	mov	x25, x0
10144948c: b50000c0    	cbnz	x0, 0x1014494a4 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x428>
101449490: 52800020    	mov	w0, #0x1                ; =1
101449494: aa1403e1    	mov	x1, x20
101449498: 9419e7b7    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10144949c: 14000160    	b	0x101449a1c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x9a0>
1014494a0: 52800039    	mov	w25, #0x1               ; =1
1014494a4: aa1903e0    	mov	x0, x25
1014494a8: aa1a03e1    	mov	x1, x26
1014494ac: aa1403e2    	mov	x2, x20
1014494b0: 941a01de    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014494b4: 52800036    	mov	w22, #0x1               ; =1
1014494b8: 52800021    	mov	w1, #0x1                ; =1
1014494bc: 14000059    	b	0x101449620 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x5a4>
1014494c0: f100069b    	subs	x27, x20, #0x1
1014494c4: 540004c9    	b.ls	0x10144955c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x4e0>
1014494c8: 39c00748    	ldrsb	w8, [x26, #0x1]
1014494cc: 3101051f    	cmn	w8, #0x41
1014494d0: 540004ac    	b.gt	0x101449564 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x4e8>
1014494d4: 90007104    	adrp	x4, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
1014494d8: 9126a084    	add	x4, x4, #0x9a8
1014494dc: 52800036    	mov	w22, #0x1               ; =1
1014494e0: aa1a03e0    	mov	x0, x26
1014494e4: aa1403e1    	mov	x1, x20
1014494e8: d2800002    	mov	x2, #0x0                ; =0
1014494ec: aa1603e3    	mov	x3, x22
1014494f0: 9419e846    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
1014494f4: 1400014a    	b	0x101449a1c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x9a0>
1014494f8: 54fffa61    	b.ne	0x101449444 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x3c8>
1014494fc: 97d9547d    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101449500: aa1603e0    	mov	x0, x22
101449504: 52800021    	mov	w1, #0x1                ; =1
101449508: 97d95474    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10144950c: b40024e0    	cbz	x0, 0x1014499a8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x92c>
101449510: aa0003f5    	mov	x21, x0
101449514: aa1a03e1    	mov	x1, x26
101449518: aa1603e2    	mov	x2, x22
10144951c: 941a01c3    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101449520: b10006db    	adds	x27, x22, #0x1
101449524: 54000602    	b.hs	0x1014495e4 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x568>
101449528: eb1b029f    	cmp	x20, x27
10144952c: 540005a9    	b.ls	0x1014495e0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x564>
101449530: 38fb6b48    	ldrsb	w8, [x26, x27]
101449534: 3101051f    	cmn	w8, #0x41
101449538: 5400056c    	b.gt	0x1014495e4 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x568>
10144953c: 90007104    	adrp	x4, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101449540: 9127c084    	add	x4, x4, #0x9f0
101449544: aa1a03e0    	mov	x0, x26
101449548: aa1403e1    	mov	x1, x20
10144954c: aa1b03e2    	mov	x2, x27
101449550: aa1403e3    	mov	x3, x20
101449554: 9419e82d    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
101449558: 14000131    	b	0x101449a1c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x9a0>
10144955c: f100069f    	cmp	x20, #0x1
101449560: 54fffba1    	b.ne	0x1014494d4 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x458>
101449564: 97d95463    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101449568: 52800036    	mov	w22, #0x1               ; =1
10144956c: 52800020    	mov	w0, #0x1                ; =1
101449570: 52800021    	mov	w1, #0x1                ; =1
101449574: 97d95459    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101449578: b4002180    	cbz	x0, 0x1014499a8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x92c>
10144957c: aa0003f5    	mov	x21, x0
101449580: 39400348    	ldrb	w8, [x26]
101449584: 39000008    	strb	w8, [x0]
101449588: f1000a9f    	cmp	x20, #0x2
10144958c: 54000163    	b.lo	0x1014495b8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x53c>
101449590: 39c00748    	ldrsb	w8, [x26, #0x1]
101449594: 3101051f    	cmn	w8, #0x41
101449598: 540022cd    	b.le	0x1014499f0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x974>
10144959c: 97d95455    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014495a0: aa1b03e0    	mov	x0, x27
1014495a4: 52800021    	mov	w1, #0x1                ; =1
1014495a8: 97d9544c    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014495ac: b4002320    	cbz	x0, 0x101449a10 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x994>
1014495b0: aa0003f9    	mov	x25, x0
1014495b4: 14000003    	b	0x1014495c0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x544>
1014495b8: d280001b    	mov	x27, #0x0               ; =0
1014495bc: 52800039    	mov	w25, #0x1               ; =1
1014495c0: 91000741    	add	x1, x26, #0x1
1014495c4: aa1903e0    	mov	x0, x25
1014495c8: aa1b03e2    	mov	x2, x27
1014495cc: 941a0197    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014495d0: 52800036    	mov	w22, #0x1               ; =1
1014495d4: 52800021    	mov	w1, #0x1                ; =1
1014495d8: aa1b03f4    	mov	x20, x27
1014495dc: 14000011    	b	0x101449620 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x5a4>
1014495e0: 54fffae1    	b.ne	0x10144953c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x4c0>
1014495e4: eb1b0294    	subs	x20, x20, x27
1014495e8: 54000061    	b.ne	0x1014495f4 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x578>
1014495ec: 52800039    	mov	w25, #0x1               ; =1
1014495f0: 14000007    	b	0x10144960c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x590>
1014495f4: 97d9543f    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014495f8: aa1403e0    	mov	x0, x20
1014495fc: 52800021    	mov	w1, #0x1                ; =1
101449600: 97d95436    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101449604: aa0003f9    	mov	x25, x0
101449608: b4001ec0    	cbz	x0, 0x1014499e0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x964>
10144960c: 8b1b0341    	add	x1, x26, x27
101449610: aa1903e0    	mov	x0, x25
101449614: aa1403e2    	mov	x2, x20
101449618: 941a0184    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10144961c: aa1603e1    	mov	x1, x22
101449620: d10343a8    	sub	x8, x29, #0xd0
101449624: f90007f5    	str	x21, [sp, #0x8]
101449628: aa1503e0    	mov	x0, x21
10144962c: 940dc77e    	bl	0x1017bb424 <__ZN3std3sys2fs8read_dir17h3de3d951fc53246fE>
101449630: 385383b5    	ldurb	w21, [x29, #-0xc8]
101449634: f9408f9a    	ldr	x26, [x28, #0x118]
101449638: 71000abf    	cmp	w21, #0x2
10144963c: 54000201    	b.ne	0x10144967c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x600>
101449640: 92400748    	and	x8, x26, #0x3
101449644: f100051f    	cmp	x8, #0x1
101449648: 54001520    	b.eq	0x1014498ec <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x870>
10144964c: 52800108    	mov	w8, #0x8                ; =8
101449650: a900227f    	stp	xzr, x8, [x19]
101449654: f9000a7f    	str	xzr, [x19, #0x10]
101449658: f94007f3    	ldr	x19, [sp, #0x8]
10144965c: b40000b4    	cbz	x20, 0x101449670 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x5f4>
101449660: aa1903e0    	mov	x0, x25
101449664: aa1403e1    	mov	x1, x20
101449668: 52800022    	mov	w2, #0x1                ; =1
10144966c: 97d9541c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101449670: b4001256    	cbz	x22, 0x1014498b8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x83c>
101449674: aa1303e0    	mov	x0, x19
101449678: 1400008d    	b	0x1014498ac <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x830>
10144967c: f9001ffa    	str	x26, [sp, #0x38]
101449680: 390103f5    	strb	w21, [sp, #0x40]
101449684: 910123e8    	add	x8, sp, #0x48
101449688: aa1903e0    	mov	x0, x25
10144968c: aa1403e1    	mov	x1, x20
101449690: 940f0829    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
101449694: b40000b4    	cbz	x20, 0x1014496a8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x62c>
101449698: 39400328    	ldrb	w8, [x25]
10144969c: 7100b91f    	cmp	w8, #0x2e
1014496a0: 1a9f17e8    	cset	w8, eq
1014496a4: 14000002    	b	0x1014496ac <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x630>
1014496a8: 52800008    	mov	w8, #0x0                ; =0
1014496ac: 39019fe8    	strb	w8, [sp, #0x67]
1014496b0: 52807d08    	mov	w8, #0x3e8              ; =1000
1014496b4: 9101a3fb    	add	x27, sp, #0x68
1014496b8: a9036b88    	stp	x8, x26, [x28, #0x30]
1014496bc: 3902a3f5    	strb	w21, [sp, #0xa8]
1014496c0: 91019fe8    	add	x8, sp, #0x67
1014496c4: 910123e9    	add	x9, sp, #0x48
1014496c8: a906a7e8    	stp	x8, x9, [sp, #0x68]
1014496cc: 91005fe8    	add	x8, sp, #0x17
1014496d0: a907e3e8    	stp	x8, x24, [sp, #0x78]
1014496d4: 9100dfe8    	add	x8, sp, #0x37
1014496d8: a908a3f7    	stp	x23, x8, [sp, #0x88]
1014496dc: 910323e0    	add	x0, sp, #0xc8
1014496e0: 9101a3e1    	add	x1, sp, #0x68
1014496e4: 97ff1290    	bl	0x10140e124 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2dd8>
1014496e8: d10343ba    	sub	x26, x29, #0xd0
1014496ec: f9403388    	ldr	x8, [x28, #0x60]
1014496f0: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1014496f4: eb09011f    	cmp	x8, x9
1014496f8: f94007f5    	ldr	x21, [sp, #0x8]
1014496fc: 540001a1    	b.ne	0x101449730 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x6b4>
101449700: 52800108    	mov	w8, #0x8                ; =8
101449704: a911a39f    	stp	xzr, x8, [x28, #0x118]
101449708: f900979f    	str	xzr, [x28, #0x128]
10144970c: f9401f88    	ldr	x8, [x28, #0x38]
101449710: 92800009    	mov	x9, #-0x1               ; =-1
101449714: f8690108    	ldaddl	x9, x8, [x8]
101449718: f100051f    	cmp	x8, #0x1
10144971c: 54000a21    	b.ne	0x101449860 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x7e4>
101449720: d50339bf    	dmb	ishld
101449724: 9100e360    	add	x0, x27, #0x38
101449728: 940e4c19    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
10144972c: 1400004d    	b	0x101449860 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x7e4>
101449730: 97d953f0    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101449734: 52803400    	mov	w0, #0x1a0              ; =416
101449738: 52800101    	mov	w1, #0x8                ; =8
10144973c: 97d953e7    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101449740: b4001420    	cbz	x0, 0x1014499c4 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x948>
101449744: aa0003f7    	mov	x23, x0
101449748: ad450780    	ldp	q0, q1, [x28, #0xa0]
10144974c: ad020400    	stp	q0, q1, [x0, #0x40]
101449750: ad430780    	ldp	q0, q1, [x28, #0x60]
101449754: ad000400    	stp	q0, q1, [x0]
101449758: ad440381    	ldp	q1, q0, [x28, #0x80]
10144975c: ad010001    	stp	q1, q0, [x0, #0x20]
101449760: 3cc783e0    	ldur	q0, [sp, #0x78]
101449764: 3cc683e1    	ldur	q1, [sp, #0x68]
101449768: 3c8d8380    	stur	q0, [x28, #0xd8]
10144976c: 3cc883e0    	ldur	q0, [sp, #0x88]
101449770: 3c8e8380    	stur	q0, [x28, #0xe8]
101449774: 3dc00f80    	ldr	q0, [x28, #0x30]
101449778: 3c8f8380    	stur	q0, [x28, #0xf8]
10144977c: f9406388    	ldr	x8, [x28, #0xc0]
101449780: f9003008    	str	x8, [x0, #0x60]
101449784: 52800088    	mov	w8, #0x4                ; =4
101449788: a9048388    	stp	x8, x0, [x28, #0x48]
10144978c: 52800038    	mov	w24, #0x1               ; =1
101449790: f9002f98    	str	x24, [x28, #0x58]
101449794: f9402388    	ldr	x8, [x28, #0x40]
101449798: f9008788    	str	x8, [x28, #0x108]
10144979c: 52800d1b    	mov	w27, #0x68              ; =104
1014497a0: d2f00015    	mov	x21, #-0x8000000000000000 ; =-9223372036854775808
1014497a4: 3c8c8381    	stur	q1, [x28, #0xc8]
1014497a8: 1400000f    	b	0x1014497e4 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x768>
1014497ac: 8b1b02e8    	add	x8, x23, x27
1014497b0: ad400740    	ldp	q0, q1, [x26]
1014497b4: 3dc00b42    	ldr	q2, [x26, #0x20]
1014497b8: ad008901    	stp	q1, q2, [x8, #0x10]
1014497bc: 3d800100    	str	q0, [x8]
1014497c0: ad418740    	ldp	q0, q1, [x26, #0x30]
1014497c4: 3dc01742    	ldr	q2, [x26, #0x50]
1014497c8: f9403349    	ldr	x9, [x26, #0x60]
1014497cc: f9003109    	str	x9, [x8, #0x60]
1014497d0: ad020901    	stp	q1, q2, [x8, #0x40]
1014497d4: 3d800d00    	str	q0, [x8, #0x30]
1014497d8: 91000718    	add	x24, x24, #0x1
1014497dc: f9002f98    	str	x24, [x28, #0x58]
1014497e0: 9101a37b    	add	x27, x27, #0x68
1014497e4: d10343a0    	sub	x0, x29, #0xd0
1014497e8: 9104c3e1    	add	x1, sp, #0x130
1014497ec: 97ff124e    	bl	0x10140e124 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2dd8>
1014497f0: f9408f88    	ldr	x8, [x28, #0x118]
1014497f4: eb15011f    	cmp	x8, x21
1014497f8: 54000180    	b.eq	0x101449828 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x7ac>
1014497fc: f9402788    	ldr	x8, [x28, #0x48]
101449800: eb08031f    	cmp	x24, x8
101449804: 54fffd41    	b.ne	0x1014497ac <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x730>
101449808: 9102c3e0    	add	x0, sp, #0xb0
10144980c: aa1803e1    	mov	x1, x24
101449810: 52800022    	mov	w2, #0x1                ; =1
101449814: 52800103    	mov	w3, #0x8                ; =8
101449818: 52800d04    	mov	w4, #0x68               ; =104
10144981c: 94177c0d    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101449820: f9402b97    	ldr	x23, [x28, #0x50]
101449824: 17ffffe2    	b	0x1014497ac <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x730>
101449828: f9408388    	ldr	x8, [x28, #0x100]
10144982c: 92800009    	mov	x9, #-0x1               ; =-1
101449830: f8690108    	ldaddl	x9, x8, [x8]
101449834: f100051f    	cmp	x8, #0x1
101449838: 540000a1    	b.ne	0x10144984c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x7d0>
10144983c: 9104c3e8    	add	x8, sp, #0x130
101449840: d50339bf    	dmb	ishld
101449844: 9100e100    	add	x0, x8, #0x38
101449848: 940e4bd1    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
10144984c: 3cc48380    	ldur	q0, [x28, #0x48]
101449850: 3d800340    	str	q0, [x26]
101449854: f9402f88    	ldr	x8, [x28, #0x58]
101449858: f9000b48    	str	x8, [x26, #0x10]
10144985c: f94007f5    	ldr	x21, [sp, #0x8]
101449860: f9400b41    	ldr	x1, [x26, #0x10]
101449864: f100083f    	cmp	x1, #0x2
101449868: 54000962    	b.hs	0x101449994 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x918>
10144986c: 3dc00340    	ldr	q0, [x26]
101449870: 3d800260    	str	q0, [x19]
101449874: f9400b48    	ldr	x8, [x26, #0x10]
101449878: f9000a68    	str	x8, [x19, #0x10]
10144987c: f94027e1    	ldr	x1, [sp, #0x48]
101449880: b4000081    	cbz	x1, 0x101449890 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x814>
101449884: f9402be0    	ldr	x0, [sp, #0x50]
101449888: 52800022    	mov	w2, #0x1                ; =1
10144988c: 97d95394    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101449890: b40000b4    	cbz	x20, 0x1014498a4 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x828>
101449894: aa1903e0    	mov	x0, x25
101449898: aa1403e1    	mov	x1, x20
10144989c: 52800022    	mov	w2, #0x1                ; =1
1014498a0: 97d9538f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014498a4: b40000b6    	cbz	x22, 0x1014498b8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x83c>
1014498a8: aa1503e0    	mov	x0, x21
1014498ac: aa1603e1    	mov	x1, x22
1014498b0: 52800022    	mov	w2, #0x1                ; =1
1014498b4: 97d9538a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014498b8: f9400fe1    	ldr	x1, [sp, #0x18]
1014498bc: b4000081    	cbz	x1, 0x1014498cc <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x850>
1014498c0: f94013e0    	ldr	x0, [sp, #0x20]
1014498c4: 52800022    	mov	w2, #0x1                ; =1
1014498c8: 97d95385    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014498cc: 910803ff    	add	sp, sp, #0x200
1014498d0: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1014498d4: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1014498d8: a94357f6    	ldp	x22, x21, [sp, #0x30]
1014498dc: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1014498e0: a94167fa    	ldp	x26, x25, [sp, #0x10]
1014498e4: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1014498e8: d65f03c0    	ret
1014498ec: f85fff57    	ldr	x23, [x26, #-0x1]!
1014498f0: f9400755    	ldr	x21, [x26, #0x8]
1014498f4: f94002a8    	ldr	x8, [x21]
1014498f8: b4000068    	cbz	x8, 0x101449904 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x888>
1014498fc: aa1703e0    	mov	x0, x23
101449900: d63f0100    	blr	x8
101449904: f94006a1    	ldr	x1, [x21, #0x8]
101449908: b4000081    	cbz	x1, 0x101449918 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x89c>
10144990c: f9400aa2    	ldr	x2, [x21, #0x10]
101449910: aa1703e0    	mov	x0, x23
101449914: 97d95372    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101449918: aa1a03e0    	mov	x0, x26
10144991c: 52800301    	mov	w1, #0x18               ; =24
101449920: 52800102    	mov	w2, #0x8                ; =8
101449924: 97d9536e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101449928: 52800108    	mov	w8, #0x8                ; =8
10144992c: a900227f    	stp	xzr, x8, [x19]
101449930: f9000a7f    	str	xzr, [x19, #0x10]
101449934: f94007f3    	ldr	x19, [sp, #0x8]
101449938: b5ffe954    	cbnz	x20, 0x101449660 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x5e4>
10144993c: 17ffff4d    	b	0x101449670 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x5f4>
101449940: a906679a    	stp	x26, x25, [x28, #0x60]
101449944: f9003b96    	str	x22, [x28, #0x70]
101449948: 910323e8    	add	x8, sp, #0xc8
10144994c: d0000109    	adrp	x9, 0x10146b000 <__ZN4core5slice4sort8unstable8heapsort8heapsort17h14b311923aeea277E+0x3bbc>
101449950: 913b4129    	add	x9, x9, #0xed0
101449954: a911a788    	stp	x8, x9, [x28, #0x118]
101449958: 9104c3e8    	add	x8, sp, #0x130
10144995c: d0000029    	adrp	x9, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101449960: 91117129    	add	x9, x9, #0x45c
101449964: a912a788    	stp	x8, x9, [x28, #0x128]
101449968: d0004e80    	adrp	x0, 0x101e1b000 <_writev+0x101e1b000>
10144996c: 9102d000    	add	x0, x0, #0xb4
101449970: 910063e8    	add	x8, sp, #0x18
101449974: d10343a1    	sub	x1, x29, #0xd0
101449978: 940f0702    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
10144997c: f9403381    	ldr	x1, [x28, #0x60]
101449980: b4ffca81    	cbz	x1, 0x1014492d0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x254>
101449984: f9403780    	ldr	x0, [x28, #0x68]
101449988: 52800022    	mov	w2, #0x1                ; =1
10144998c: 97d95354    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101449990: 17fffe50    	b	0x1014492d0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x254>
101449994: f9400740    	ldr	x0, [x26, #0x8]
101449998: f100543f    	cmp	x1, #0x15
10144999c: 540001c2    	b.hs	0x1014499d4 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x958>
1014499a0: 94003e0b    	bl	0x1014591cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbd44>
1014499a4: 17ffffb2    	b	0x10144986c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x7f0>
1014499a8: 52800020    	mov	w0, #0x1                ; =1
1014499ac: aa1603e1    	mov	x1, x22
1014499b0: 9419e671    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014499b4: 1400001a    	b	0x101449a1c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x9a0>
1014499b8: 52800020    	mov	w0, #0x1                ; =1
1014499bc: aa1703e1    	mov	x1, x23
1014499c0: 9419e66d    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014499c4: 52800100    	mov	w0, #0x8                ; =8
1014499c8: 52803401    	mov	w1, #0x1a0              ; =416
1014499cc: 9419e66a    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014499d0: 14000013    	b	0x101449a1c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x9a0>
1014499d4: 910323e2    	add	x2, sp, #0xc8
1014499d8: 940040e5    	bl	0x101459d6c <__ZN4core5slice4sort6stable14driftsort_main17h432afb774326fdecE>
1014499dc: 17ffffa4    	b	0x10144986c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x7f0>
1014499e0: 52800020    	mov	w0, #0x1                ; =1
1014499e4: aa1403e1    	mov	x1, x20
1014499e8: 9419e663    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014499ec: 1400000c    	b	0x101449a1c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x9a0>
1014499f0: 90007104    	adrp	x4, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
1014499f4: 91270084    	add	x4, x4, #0x9c0
1014499f8: aa1a03e0    	mov	x0, x26
1014499fc: aa1403e1    	mov	x1, x20
101449a00: 52800022    	mov	w2, #0x1                ; =1
101449a04: aa1403e3    	mov	x3, x20
101449a08: 9419e700    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
101449a0c: 14000004    	b	0x101449a1c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x9a0>
101449a10: 52800020    	mov	w0, #0x1                ; =1
101449a14: aa1b03e1    	mov	x1, x27
101449a18: 9419e657    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101449a1c: d4200020    	brk	#0x1
101449a20: aa0003f3    	mov	x19, x0
101449a24: d10343a0    	sub	x0, x29, #0xd0
101449a28: 1400004f    	b	0x101449b64 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xae8>
101449a2c: aa0003f3    	mov	x19, x0
101449a30: f9403381    	ldr	x1, [x28, #0x60]
101449a34: b4000ca1    	cbz	x1, 0x101449bc8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb4c>
101449a38: f9403780    	ldr	x0, [x28, #0x68]
101449a3c: 14000061    	b	0x101449bc0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb44>
101449a40: aa0003f3    	mov	x19, x0
101449a44: f94006a1    	ldr	x1, [x21, #0x8]
101449a48: b4000081    	cbz	x1, 0x101449a58 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0x9dc>
101449a4c: f9400aa2    	ldr	x2, [x21, #0x10]
101449a50: aa1703e0    	mov	x0, x23
101449a54: 97d95322    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101449a58: aa1a03e0    	mov	x0, x26
101449a5c: 52800301    	mov	w1, #0x18               ; =24
101449a60: 52800102    	mov	w2, #0x8                ; =8
101449a64: 14000045    	b	0x101449b78 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xafc>
101449a68: aa0003f3    	mov	x19, x0
101449a6c: b4000af4    	cbz	x20, 0x101449bc8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb4c>
101449a70: aa1503e0    	mov	x0, x21
101449a74: aa1403e1    	mov	x1, x20
101449a78: 14000052    	b	0x101449bc0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb44>
101449a7c: aa0003f3    	mov	x19, x0
101449a80: 14000038    	b	0x101449b60 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xae4>
101449a84: aa0003f3    	mov	x19, x0
101449a88: 14000038    	b	0x101449b68 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xaec>
101449a8c: 14000004    	b	0x101449a9c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xa20>
101449a90: aa0003f3    	mov	x19, x0
101449a94: aa1503e0    	mov	x0, x21
101449a98: 14000044    	b	0x101449ba8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb2c>
101449a9c: aa0003f3    	mov	x19, x0
101449aa0: aa1503e0    	mov	x0, x21
101449aa4: 52800021    	mov	w1, #0x1                ; =1
101449aa8: 14000041    	b	0x101449bac <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb30>
101449aac: aa0003f3    	mov	x19, x0
101449ab0: 910323e0    	add	x0, sp, #0xc8
101449ab4: 97dacf09    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101449ab8: 14000002    	b	0x101449ac0 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xa44>
101449abc: aa0003f3    	mov	x19, x0
101449ac0: f9401f88    	ldr	x8, [x28, #0x38]
101449ac4: 92800009    	mov	x9, #-0x1               ; =-1
101449ac8: f8690108    	ldaddl	x9, x8, [x8]
101449acc: f100051f    	cmp	x8, #0x1
101449ad0: 540004c1    	b.ne	0x101449b68 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xaec>
101449ad4: d50339bf    	dmb	ishld
101449ad8: 9100e360    	add	x0, x27, #0x38
101449adc: 940e4b2c    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
101449ae0: 14000022    	b	0x101449b68 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xaec>
101449ae4: 9419e890    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101449ae8: aa0003f3    	mov	x19, x0
101449aec: 92800008    	mov	x8, #-0x1               ; =-1
101449af0: f8680348    	ldaddl	x8, x8, [x26]
101449af4: f100051f    	cmp	x8, #0x1
101449af8: 54000421    	b.ne	0x101449b7c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb00>
101449afc: d50339bf    	dmb	ishld
101449b00: 9100e3e0    	add	x0, sp, #0x38
101449b04: 940e4b22    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
101449b08: 1400001d    	b	0x101449b7c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb00>
101449b0c: 9419e886    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101449b10: aa0003f3    	mov	x19, x0
101449b14: 1400001a    	b	0x101449b7c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb00>
101449b18: aa0003f3    	mov	x19, x0
101449b1c: f9400fe1    	ldr	x1, [sp, #0x18]
101449b20: b50004e1    	cbnz	x1, 0x101449bbc <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb40>
101449b24: 14000029    	b	0x101449bc8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb4c>
101449b28: aa0003f3    	mov	x19, x0
101449b2c: d10343a0    	sub	x0, x29, #0xd0
101449b30: 97daceea    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101449b34: 14000002    	b	0x101449b3c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xac0>
101449b38: aa0003f3    	mov	x19, x0
101449b3c: f9408388    	ldr	x8, [x28, #0x100]
101449b40: 92800009    	mov	x9, #-0x1               ; =-1
101449b44: f8690108    	ldaddl	x9, x8, [x8]
101449b48: f100051f    	cmp	x8, #0x1
101449b4c: 540000a1    	b.ne	0x101449b60 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xae4>
101449b50: 9104c3e8    	add	x8, sp, #0x130
101449b54: d50339bf    	dmb	ishld
101449b58: 9100e100    	add	x0, x8, #0x38
101449b5c: 940e4b0c    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
101449b60: 9102c3e0    	add	x0, sp, #0xb0
101449b64: 940030c0    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101449b68: f94027e1    	ldr	x1, [sp, #0x48]
101449b6c: b4000081    	cbz	x1, 0x101449b7c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb00>
101449b70: f9402be0    	ldr	x0, [sp, #0x50]
101449b74: 52800022    	mov	w2, #0x1                ; =1
101449b78: 97d952d9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101449b7c: b50000b4    	cbnz	x20, 0x101449b90 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb14>
101449b80: b5000136    	cbnz	x22, 0x101449ba4 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb28>
101449b84: f9400fe1    	ldr	x1, [sp, #0x18]
101449b88: b50001a1    	cbnz	x1, 0x101449bbc <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb40>
101449b8c: 1400000f    	b	0x101449bc8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb4c>
101449b90: aa1903e0    	mov	x0, x25
101449b94: aa1403e1    	mov	x1, x20
101449b98: 52800022    	mov	w2, #0x1                ; =1
101449b9c: 97d952d0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101449ba0: b4ffff36    	cbz	x22, 0x101449b84 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb08>
101449ba4: f94007e0    	ldr	x0, [sp, #0x8]
101449ba8: aa1603e1    	mov	x1, x22
101449bac: 52800022    	mov	w2, #0x1                ; =1
101449bb0: 97d952cb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101449bb4: f9400fe1    	ldr	x1, [sp, #0x18]
101449bb8: b4000081    	cbz	x1, 0x101449bc8 <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E+0xb4c>
101449bbc: f94013e0    	ldr	x0, [sp, #0x20]
101449bc0: 52800022    	mov	w2, #0x1                ; =1
101449bc4: 97d952c6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101449bc8: aa1303e0    	mov	x0, x19
101449bcc: 9419fe82    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101449bd0: 9419e855    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
