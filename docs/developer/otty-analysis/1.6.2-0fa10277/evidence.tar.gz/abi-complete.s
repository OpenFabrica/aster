
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100a405f8 <_otty_autocomplete_complete>:
100a405f8: d10283ff    	sub	sp, sp, #0xa0
100a405fc: a90567fa    	stp	x26, x25, [sp, #0x50]
100a40600: a9065ff8    	stp	x24, x23, [sp, #0x60]
100a40604: a90757f6    	stp	x22, x21, [sp, #0x70]
100a40608: a9084ff4    	stp	x20, x19, [sp, #0x80]
100a4060c: a9097bfd    	stp	x29, x30, [sp, #0x90]
100a40610: 910243fd    	add	x29, sp, #0x90
100a40614: b4000e20    	cbz	x0, 0x100a407d8 <_otty_autocomplete_complete+0x1e0>
100a40618: b40003e1    	cbz	x1, 0x100a40694 <_otty_autocomplete_complete+0x9c>
100a4061c: aa0203f6    	mov	x22, x2
100a40620: aa0003f3    	mov	x19, x0
100a40624: aa0103e0    	mov	x0, x1
100a40628: aa0103f4    	mov	x20, x1
100a4062c: 944227bc    	bl	0x101aca51c <_writev+0x101aca51c>
100a40630: 9100c3e8    	add	x8, sp, #0x30
100a40634: 91000401    	add	x1, x0, #0x1
100a40638: aa1403e0    	mov	x0, x20
100a4063c: 94374291    	bl	0x101811080 <__ZN4core3ffi5c_str4CStr6to_str17h25155b05b54fea5fE>
100a40640: b94033e8    	ldr	w8, [sp, #0x30]
100a40644: 37000288    	tbnz	w8, #0x0, 0x100a40694 <_otty_autocomplete_complete+0x9c>
100a40648: f94023f4    	ldr	x20, [sp, #0x40]
100a4064c: b4000254    	cbz	x20, 0x100a40694 <_otty_autocomplete_complete+0x9c>
100a40650: f9401ff5    	ldr	x21, [sp, #0x38]
100a40654: b40003b6    	cbz	x22, 0x100a406c8 <_otty_autocomplete_complete+0xd0>
100a40658: aa1603e0    	mov	x0, x22
100a4065c: 944227b0    	bl	0x101aca51c <_writev+0x101aca51c>
100a40660: 9100c3e8    	add	x8, sp, #0x30
100a40664: 91000401    	add	x1, x0, #0x1
100a40668: aa1603e0    	mov	x0, x22
100a4066c: 94374285    	bl	0x101811080 <__ZN4core3ffi5c_str4CStr6to_str17h25155b05b54fea5fE>
100a40670: b94033e8    	ldr	w8, [sp, #0x30]
100a40674: a943dbe9    	ldp	x9, x22, [sp, #0x38]
100a40678: f10002df    	cmp	x22, #0x0
100a4067c: 1a9f1508    	csinc	w8, w8, wzr, ne
100a40680: 7100011f    	cmp	w8, #0x0
100a40684: 9a8913f7    	csel	x23, xzr, x9, ne
100a40688: f8bfc260    	ldapr	x0, [x19]
100a4068c: b5000240    	cbnz	x0, 0x100a406d4 <_otty_autocomplete_complete+0xdc>
100a40690: 14000059    	b	0x100a407f4 <_otty_autocomplete_complete+0x1fc>
100a40694: 94017817    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
100a40698: 52800040    	mov	w0, #0x2                ; =2
100a4069c: 52800021    	mov	w1, #0x1                ; =1
100a406a0: 9401780e    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
100a406a4: b4000be0    	cbz	x0, 0x100a40820 <_otty_autocomplete_complete+0x228>
100a406a8: 528bab68    	mov	w8, #0x5d5b             ; =23899
100a406ac: 79000008    	strh	w8, [x0]
100a406b0: 52800048    	mov	w8, #0x2                ; =2
100a406b4: a90303e8    	stp	x8, x0, [sp, #0x30]
100a406b8: f90023e8    	str	x8, [sp, #0x40]
100a406bc: 9100c3e0    	add	x0, sp, #0x30
100a406c0: 97fe3039    	bl	0x1009cc7a4 <__ZN8otty_ffi15headless_engine17hd9cd11f7a154132bE+0x3960>
100a406c4: 14000045    	b	0x100a407d8 <_otty_autocomplete_complete+0x1e0>
100a406c8: d2800017    	mov	x23, #0x0               ; =0
100a406cc: f8bfc260    	ldapr	x0, [x19]
100a406d0: b4000920    	cbz	x0, 0x100a407f4 <_otty_autocomplete_complete+0x1fc>
100a406d4: 9435f99f    	bl	0x1017bed50 <__ZN3std3sys3pal4unix4sync5mutex5Mutex4lock17h3548d2db0de37829E>
100a406d8: 9000ccf9    	adrp	x25, 0x1023dc000 <__ZN15crossbeam_utils6atomic11atomic_cell4lock5LOCKS17he2ac33ecd5b81040E+0x1680>
100a406dc: 912da339    	add	x25, x25, #0xb68
100a406e0: f9400328    	ldr	x8, [x25]
100a406e4: f240f91f    	tst	x8, #0x7fffffffffffffff
100a406e8: 540008c1    	b.ne	0x100a40800 <_otty_autocomplete_complete+0x208>
100a406ec: 52800018    	mov	w24, #0x0               ; =0
100a406f0: 3940227f    	ldrb	wzr, [x19, #0x8]
100a406f4: 910063e8    	add	x8, sp, #0x18
100a406f8: 91004260    	add	x0, x19, #0x10
100a406fc: aa1503e1    	mov	x1, x21
100a40700: aa1403e2    	mov	x2, x20
100a40704: aa1703e3    	mov	x3, x23
100a40708: aa1603e4    	mov	x4, x22
100a4070c: 9427e7d6    	bl	0x10143a664 <__ZN17otty_autocomplete6engine6Engine8complete17h9e57a7d12b945fcaE>
100a40710: 37000098    	tbnz	w24, #0x0, 0x100a40720 <_otty_autocomplete_complete+0x128>
100a40714: f9400328    	ldr	x8, [x25]
100a40718: f240f91f    	tst	x8, #0x7fffffffffffffff
100a4071c: 54000781    	b.ne	0x100a4080c <_otty_autocomplete_complete+0x214>
100a40720: f9400260    	ldr	x0, [x19]
100a40724: 9435f992    	bl	0x1017bed6c <__ZN3std3sys3pal4unix4sync5mutex5Mutex6unlock17h5e6d0b50222d57d0E>
100a40728: a9420be1    	ldp	x1, x2, [sp, #0x20]
100a4072c: 9100c3e0    	add	x0, sp, #0x30
100a40730: 97fa94fa    	bl	0x1008e5b18 <__ZN108_$LT$otty_ffi..daemon_session..DaemonTransport$u20$as$u20$otty_core..session_transport..SessionTransport$GT$6resize17h21d8cbd68e09b5b3E+0xb628>
100a40734: a9434fe8    	ldp	x8, x19, [sp, #0x30]
100a40738: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
100a4073c: eb09011f    	cmp	x8, x9
100a40740: 540002c1    	b.ne	0x100a40798 <_otty_autocomplete_complete+0x1a0>
100a40744: f90027f3    	str	x19, [sp, #0x48]
100a40748: 940177ea    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
100a4074c: 52800040    	mov	w0, #0x2                ; =2
100a40750: 52800021    	mov	w1, #0x1                ; =1
100a40754: 940177e1    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
100a40758: b40006c0    	cbz	x0, 0x100a40830 <_otty_autocomplete_complete+0x238>
100a4075c: 528bab68    	mov	w8, #0x5d5b             ; =23899
100a40760: 79000008    	strh	w8, [x0]
100a40764: 52800048    	mov	w8, #0x2                ; =2
100a40768: a90303e8    	stp	x8, x0, [sp, #0x30]
100a4076c: f90023e8    	str	x8, [sp, #0x40]
100a40770: f9400268    	ldr	x8, [x19]
100a40774: f100051f    	cmp	x8, #0x1
100a40778: 54000180    	b.eq	0x100a407a8 <_otty_autocomplete_complete+0x1b0>
100a4077c: b50001a8    	cbnz	x8, 0x100a407b0 <_otty_autocomplete_complete+0x1b8>
100a40780: f9400a61    	ldr	x1, [x19, #0x10]
100a40784: b4000161    	cbz	x1, 0x100a407b0 <_otty_autocomplete_complete+0x1b8>
100a40788: f9400660    	ldr	x0, [x19, #0x8]
100a4078c: 52800022    	mov	w2, #0x1                ; =1
100a40790: 940177d3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
100a40794: 14000007    	b	0x100a407b0 <_otty_autocomplete_complete+0x1b8>
100a40798: f94023e9    	ldr	x9, [sp, #0x40]
100a4079c: a9034fe8    	stp	x8, x19, [sp, #0x30]
100a407a0: f90023e9    	str	x9, [sp, #0x40]
100a407a4: 14000007    	b	0x100a407c0 <_otty_autocomplete_complete+0x1c8>
100a407a8: 91002260    	add	x0, x19, #0x8
100a407ac: 97fbe011    	bl	0x1009387f0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x257c8>
100a407b0: aa1303e0    	mov	x0, x19
100a407b4: 52800501    	mov	w1, #0x28               ; =40
100a407b8: 52800102    	mov	w2, #0x8                ; =8
100a407bc: 940177c8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
100a407c0: 9100c3e0    	add	x0, sp, #0x30
100a407c4: 97fe2ff8    	bl	0x1009cc7a4 <__ZN8otty_ffi15headless_engine17hd9cd11f7a154132bE+0x3960>
100a407c8: aa0003f3    	mov	x19, x0
100a407cc: 910063e0    	add	x0, sp, #0x18
100a407d0: 97fc182f    	bl	0x10094688c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x33864>
100a407d4: aa1303e0    	mov	x0, x19
100a407d8: a9497bfd    	ldp	x29, x30, [sp, #0x90]
100a407dc: a9484ff4    	ldp	x20, x19, [sp, #0x80]
100a407e0: a94757f6    	ldp	x22, x21, [sp, #0x70]
100a407e4: a9465ff8    	ldp	x24, x23, [sp, #0x60]
100a407e8: a94567fa    	ldp	x26, x25, [sp, #0x50]
100a407ec: 910283ff    	add	sp, sp, #0xa0
100a407f0: d65f03c0    	ret
100a407f4: aa1303e0    	mov	x0, x19
100a407f8: 943f992d    	bl	0x101a26cac <_create_tasklist_extension+0x4854>
100a407fc: 17ffffb6    	b	0x100a406d4 <_otty_autocomplete_complete+0xdc>
100a40800: 9441fd09    	bl	0x101abfc24 <__ZN3std9panicking11panic_count17is_zero_slow_path17h055803fbeed74640E>
100a40804: 52000018    	eor	w24, w0, #0x1
100a40808: 17ffffba    	b	0x100a406f0 <_otty_autocomplete_complete+0xf8>
100a4080c: 9441fd06    	bl	0x101abfc24 <__ZN3std9panicking11panic_count17is_zero_slow_path17h055803fbeed74640E>
100a40810: 3707f880    	tbnz	w0, #0x0, 0x100a40720 <_otty_autocomplete_complete+0x128>
100a40814: 52800028    	mov	w8, #0x1                ; =1
100a40818: 39002268    	strb	w8, [x19, #0x8]
100a4081c: 17ffffc1    	b	0x100a40720 <_otty_autocomplete_complete+0x128>
100a40820: 52800020    	mov	w0, #0x1                ; =1
100a40824: 52800041    	mov	w1, #0x2                ; =2
100a40828: 94420ad3    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
100a4082c: 14000004    	b	0x100a4083c <_otty_autocomplete_complete+0x244>
100a40830: 52800020    	mov	w0, #0x1                ; =1
100a40834: 52800041    	mov	w1, #0x2                ; =2
100a40838: 94420acf    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
100a4083c: d4200020    	brk	#0x1
100a40840: aa0003f4    	mov	x20, x0
100a40844: aa1303e0    	mov	x0, x19
100a40848: 52800501    	mov	w1, #0x28               ; =40
100a4084c: 52800102    	mov	w2, #0x8                ; =8
100a40850: 940177a3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
100a40854: 1400000d    	b	0x100a40888 <_otty_autocomplete_complete+0x290>
100a40858: aa0003f4    	mov	x20, x0
100a4085c: 910123e0    	add	x0, sp, #0x48
100a40860: 97fbe232    	bl	0x100939128 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x26100>
100a40864: 14000009    	b	0x100a40888 <_otty_autocomplete_complete+0x290>
100a40868: 94420d2f    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
100a4086c: aa0003f4    	mov	x20, x0
100a40870: aa1303e0    	mov	x0, x19
100a40874: aa1803e1    	mov	x1, x24
100a40878: 97fbb3e0    	bl	0x10092d7f8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1a7d0>
100a4087c: 14000007    	b	0x100a40898 <_otty_autocomplete_complete+0x2a0>
100a40880: 94420d29    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
100a40884: aa0003f4    	mov	x20, x0
100a40888: 910063e0    	add	x0, sp, #0x18
100a4088c: 97fc1800    	bl	0x10094688c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x33864>
100a40890: 14000002    	b	0x100a40898 <_otty_autocomplete_complete+0x2a0>
100a40894: aa0003f4    	mov	x20, x0
100a40898: aa1403e0    	mov	x0, x20
100a4089c: 9441fced    	bl	0x101abfc50 <__ZN3std9panicking12catch_unwind7cleanup17h11de3f5386a52d13E>
100a408a0: aa0003f3    	mov	x19, x0
100a408a4: aa0103f4    	mov	x20, x1
100a408a8: a90087e0    	stp	x0, x1, [sp, #0x8]
100a408ac: f00086c0    	adrp	x0, 0x101b1b000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14014>
100a408b0: 9114dc00    	add	x0, x0, #0x537
100a408b4: 910023e2    	add	x2, sp, #0x8
100a408b8: 52800341    	mov	w1, #0x1a               ; =26
100a408bc: 97fde500    	bl	0x1009b9cbc <__ZN86_$LT$otty_ffi..sync_ffi..HostShim$u20$as$u20$otty_sync_transport..host..SealedKeys$GT$16note_needs_grant17h02324a1d3d3001f7E+0x1ab18>
100a408c0: f9400288    	ldr	x8, [x20]
100a408c4: b4000068    	cbz	x8, 0x100a408d0 <_otty_autocomplete_complete+0x2d8>
100a408c8: aa1303e0    	mov	x0, x19
100a408cc: d63f0100    	blr	x8
100a408d0: f9400681    	ldr	x1, [x20, #0x8]
100a408d4: b4000081    	cbz	x1, 0x100a408e4 <_otty_autocomplete_complete+0x2ec>
100a408d8: f9400a82    	ldr	x2, [x20, #0x10]
100a408dc: aa1303e0    	mov	x0, x19
100a408e0: 9401777f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
100a408e4: d2800000    	mov	x0, #0x0                ; =0
100a408e8: 17ffffbc    	b	0x100a407d8 <_otty_autocomplete_complete+0x1e0>
100a408ec: f9400681    	ldr	x1, [x20, #0x8]
100a408f0: b40000e1    	cbz	x1, 0x100a4090c <_otty_autocomplete_complete+0x314>
100a408f4: f9400a82    	ldr	x2, [x20, #0x10]
100a408f8: aa1303e0    	mov	x0, x19
100a408fc: 94017778    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
100a40900: 94420d58    	bl	0x101ac3e60 <__ZN4core9panicking19panic_cannot_unwind17hf1ae4d338f0b538fE>
100a40904: 910023e0    	add	x0, sp, #0x8
100a40908: 97fc2831    	bl	0x10094a9cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x379a4>
100a4090c: 94420d55    	bl	0x101ac3e60 <__ZN4core9panicking19panic_cannot_unwind17hf1ae4d338f0b538fE>
100a40910: 94420d05    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
100a40914: 94420d53    	bl	0x101ac3e60 <__ZN4core9panicking19panic_cannot_unwind17hf1ae4d338f0b538fE>

0000000100a40918 <_otty_autocomplete_db_apply_jsonl>:
100a40918: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
100a4091c: a90167fa    	stp	x26, x25, [sp, #0x10]
100a40920: a9025ff8    	stp	x24, x23, [sp, #0x20]
100a40924: a90357f6    	stp	x22, x21, [sp, #0x30]
100a40928: a9044ff4    	stp	x20, x19, [sp, #0x40]
100a4092c: a9057bfd    	stp	x29, x30, [sp, #0x50]
100a40930: 910143fd    	add	x29, sp, #0x50
100a40934: d10983ff    	sub	sp, sp, #0x260
100a40938: aa0303f9    	mov	x25, x3
100a4093c: aa0203f7    	mov	x23, x2
100a40940: aa0103f6    	mov	x22, x1
100a40944: b4000280    	cbz	x0, 0x100a40994 <_otty_autocomplete_db_apply_jsonl+0x7c>
100a40948: aa0003f3    	mov	x19, x0
100a4094c: 944226f4    	bl	0x101aca51c <_writev+0x101aca51c>
100a40950: 910543e8    	add	x8, sp, #0x150
100a40954: 91000401    	add	x1, x0, #0x1
100a40958: aa1303e0    	mov	x0, x19
100a4095c: 943741c9    	bl	0x101811080 <__ZN4core3ffi5c_str4CStr6to_str17h25155b05b54fea5fE>
100a40960: b94153e8    	ldr	w8, [sp, #0x150]
100a40964: a955d3e9    	ldp	x9, x20, [sp, #0x158]
100a40968: f100029f    	cmp	x20, #0x0
100a4096c: 1a9f1508    	csinc	w8, w8, wzr, ne
100a40970: 7100011f    	cmp	w8, #0x0
100a40974: 9a8913f5    	csel	x21, xzr, x9, ne
100a40978: 9401775e    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
100a4097c: 5280027a    	mov	w26, #0x13              ; =19
100a40980: 52800260    	mov	w0, #0x13               ; =19
100a40984: 52800021    	mov	w1, #0x1                ; =1
100a40988: 94017754    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
100a4098c: b5000120    	cbnz	x0, 0x100a409b0 <_otty_autocomplete_db_apply_jsonl+0x98>
100a40990: 14000077    	b	0x100a40b6c <_otty_autocomplete_db_apply_jsonl+0x254>
100a40994: d2800015    	mov	x21, #0x0               ; =0
100a40998: 94017756    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
100a4099c: 5280027a    	mov	w26, #0x13              ; =19
100a409a0: 52800260    	mov	w0, #0x13               ; =19
100a409a4: 52800021    	mov	w1, #0x1                ; =1
100a409a8: 9401774c    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
100a409ac: b4000e00    	cbz	x0, 0x100a40b6c <_otty_autocomplete_db_apply_jsonl+0x254>
100a409b0: aa0003f3    	mov	x19, x0
100a409b4: 910543fc    	add	x28, sp, #0x150
100a409b8: 52800418    	mov	w24, #0x20              ; =32
100a409bc: 72ac0018    	movk	w24, #0x6000, lsl #16
100a409c0: 528c2e08    	mov	w8, #0x6170             ; =24944
100a409c4: 72ad0e88    	movk	w8, #0x6874, lsl #16
100a409c8: b800f008    	stur	w8, [x0, #0xf]
100a409cc: f00086a8    	adrp	x8, 0x101b17000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x10014>
100a409d0: 91045108    	add	x8, x8, #0x114
100a409d4: 3dc00100    	ldr	q0, [x8]
100a409d8: 3d800000    	str	q0, [x0]
100a409dc: b4000335    	cbz	x21, 0x100a40a40 <_otty_autocomplete_db_apply_jsonl+0x128>
100a409e0: aa1303e0    	mov	x0, x19
100a409e4: 52800261    	mov	w1, #0x13               ; =19
100a409e8: 52800022    	mov	w2, #0x1                ; =1
100a409ec: 9401773c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
100a409f0: b40002d7    	cbz	x23, 0x100a40a48 <_otty_autocomplete_db_apply_jsonl+0x130>
100a409f4: aa1703e0    	mov	x0, x23
100a409f8: 944226c9    	bl	0x101aca51c <_writev+0x101aca51c>
100a409fc: 910543e8    	add	x8, sp, #0x150
100a40a00: 91000401    	add	x1, x0, #0x1
100a40a04: aa1703e0    	mov	x0, x23
100a40a08: 9437419e    	bl	0x101811080 <__ZN4core3ffi5c_str4CStr6to_str17h25155b05b54fea5fE>
100a40a0c: b94153e8    	ldr	w8, [sp, #0x150]
100a40a10: a955dfe9    	ldp	x9, x23, [sp, #0x158]
100a40a14: f10002ff    	cmp	x23, #0x0
100a40a18: 1a9f1508    	csinc	w8, w8, wzr, ne
100a40a1c: 7100011f    	cmp	w8, #0x0
100a40a20: 9a8913f8    	csel	x24, xzr, x9, ne
100a40a24: 94017733    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
100a40a28: 5280027a    	mov	w26, #0x13              ; =19
100a40a2c: 52800260    	mov	w0, #0x13               ; =19
100a40a30: 52800021    	mov	w1, #0x1                ; =1
100a40a34: 94017729    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
100a40a38: b5000160    	cbnz	x0, 0x100a40a64 <_otty_autocomplete_db_apply_jsonl+0x14c>
100a40a3c: 1400004c    	b	0x100a40b6c <_otty_autocomplete_db_apply_jsonl+0x254>
100a40a40: 52800275    	mov	w21, #0x13              ; =19
100a40a44: 14000051    	b	0x100a40b88 <_otty_autocomplete_db_apply_jsonl+0x270>
100a40a48: d2800018    	mov	x24, #0x0               ; =0
100a40a4c: 94017729    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
100a40a50: 5280027a    	mov	w26, #0x13              ; =19
100a40a54: 52800260    	mov	w0, #0x13               ; =19
100a40a58: 52800021    	mov	w1, #0x1                ; =1
100a40a5c: 9401771f    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
100a40a60: b4000860    	cbz	x0, 0x100a40b6c <_otty_autocomplete_db_apply_jsonl+0x254>
100a40a64: aa0003f3    	mov	x19, x0
100a40a68: 528c2c88    	mov	w8, #0x6164             ; =24932
100a40a6c: 72acae88    	movk	w8, #0x6574, lsl #16
100a40a70: b800f008    	stur	w8, [x0, #0xf]
100a40a74: f00086a8    	adrp	x8, 0x101b17000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x10014>
100a40a78: 91049d08    	add	x8, x8, #0x127
100a40a7c: 3dc00100    	ldr	q0, [x8]
