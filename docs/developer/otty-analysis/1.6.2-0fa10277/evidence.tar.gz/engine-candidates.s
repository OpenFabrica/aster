
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101433c6c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E>:
101434764: 6db82beb    	stp	d11, d10, [sp, #-0x80]!
101434768: 6d0123e9    	stp	d9, d8, [sp, #0x10]
10143476c: a9026ffc    	stp	x28, x27, [sp, #0x20]
101434770: a90367fa    	stp	x26, x25, [sp, #0x30]
101434774: a9045ff8    	stp	x24, x23, [sp, #0x40]
101434778: a90557f6    	stp	x22, x21, [sp, #0x50]
10143477c: a9064ff4    	stp	x20, x19, [sp, #0x60]
101434780: a9077bfd    	stp	x29, x30, [sp, #0x70]
101434784: 9101c3fd    	add	x29, sp, #0x70
101434788: d110c3ff    	sub	sp, sp, #0x430
10143478c: f90003ff    	str	xzr, [sp]
101434790: f90067e5    	str	x5, [sp, #0xc8]
101434794: f9006fe4    	str	x4, [sp, #0xd8]
101434798: aa0303f3    	mov	x19, x3
10143479c: aa0203f4    	mov	x20, x2
1014347a0: f90077e1    	str	x1, [sp, #0xe8]
1014347a4: aa0003fb    	mov	x27, x0
1014347a8: 940e4741    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
1014347ac: 52800062    	mov	w2, #0x3                ; =3
1014347b0: 52800003    	mov	w3, #0x0                ; =0
1014347b4: 940ee2d5    	bl	0x1017ed308 <__ZN88_$LT$std..time..Instant$u20$as$u20$core..ops..arith..Add$LT$core..time..Duration$GT$$GT$3add17h36fd49e2955fadbfE>
1014347b8: f90073e0    	str	x0, [sp, #0xe0]
1014347bc: aa0103f5    	mov	x21, x1
1014347c0: aa1403e0    	mov	x0, x20
1014347c4: aa1303e1    	mov	x1, x19
1014347c8: 94005633    	bl	0x10144a094 <__ZN17otty_autocomplete8tokenize23extract_current_command17h1b01b47006c1e301E>
1014347cc: aa0003f4    	mov	x20, x0
1014347d0: aa0103f3    	mov	x19, x1
1014347d4: 9103c3e8    	add	x8, sp, #0xf0
1014347d8: 94005778    	bl	0x10144a5b8 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E>
1014347dc: f94083fc    	ldr	x28, [sp, #0x100]
1014347e0: b40001dc    	cbz	x28, 0x101434818 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xbac>
1014347e4: b4000453    	cbz	x19, 0x10143486c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xc00>
1014347e8: 8b13028a    	add	x10, x20, x19
1014347ec: 38dff148    	ldursb	w8, [x10, #-0x1]
1014347f0: 37f80ce8    	tbnz	w8, #0x1f, 0x10143498c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xd20>
1014347f4: 7100891f    	cmp	w8, #0x22
1014347f8: 54000060    	b.eq	0x101434804 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xb98>
1014347fc: 71009d1f    	cmp	w8, #0x27
101434800: 54000361    	b.ne	0x10143486c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xc00>
101434804: 52800108    	mov	w8, #0x8                ; =8
101434808: a900237f    	stp	xzr, x8, [x27]
10143480c: f9000b7f    	str	xzr, [x27, #0x10]
101434810: f9407ff3    	ldr	x19, [sp, #0xf8]
101434814: 14000728    	b	0x1014364b4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2848>
101434818: 52800108    	mov	w8, #0x8                ; =8
10143481c: a900237f    	stp	xzr, x8, [x27]
101434820: f9000b7f    	str	xzr, [x27, #0x10]
101434824: f9407ff3    	ldr	x19, [sp, #0xf8]
101434828: f9407be8    	ldr	x8, [sp, #0xf0]
10143482c: b40000c8    	cbz	x8, 0x101434844 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xbd8>
101434830: 8b080508    	add	x8, x8, x8, lsl #1
101434834: d37df101    	lsl	x1, x8, #3
101434838: aa1303e0    	mov	x0, x19
10143483c: 52800102    	mov	w2, #0x8                ; =8
101434840: 97d9a7a7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101434844: 9110c3ff    	add	sp, sp, #0x430
101434848: a9477bfd    	ldp	x29, x30, [sp, #0x70]
10143484c: a9464ff4    	ldp	x20, x19, [sp, #0x60]
101434850: a94557f6    	ldp	x22, x21, [sp, #0x50]
101434854: a9445ff8    	ldp	x24, x23, [sp, #0x40]
101434858: a94367fa    	ldp	x26, x25, [sp, #0x30]
10143485c: a9426ffc    	ldp	x28, x27, [sp, #0x20]
101434860: 6d4123e9    	ldp	d9, d8, [sp, #0x10]
101434864: 6cc82beb    	ldp	d11, d10, [sp], #0x80
101434868: d65f03c0    	ret
10143486c: aa1403e0    	mov	x0, x20
101434870: aa1303e1    	mov	x1, x19
101434874: 940055a6    	bl	0x101449f0c <__ZN17otty_autocomplete8tokenize21ends_at_word_boundary17h605b070ee1f8f4feE>
101434878: aa0003f4    	mov	x20, x0
10143487c: f9407fe0    	ldr	x0, [sp, #0xf8]
101434880: 910423e8    	add	x8, sp, #0x108
101434884: f90063e0    	str	x0, [sp, #0xc0]
101434888: 940f6a51    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10143488c: f100079f    	cmp	x28, #0x1
101434890: 52000288    	eor	w8, w20, #0x1
101434894: 1a8813e8    	csel	w8, wzr, w8, ne
101434898: f9006bfb    	str	x27, [sp, #0xd0]
10143489c: 370004e8    	tbnz	w8, #0x0, 0x101434938 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xccc>
1014348a0: f94077e0    	ldr	x0, [sp, #0xe8]
1014348a4: f84d8c08    	ldr	x8, [x0, #0xd8]!
1014348a8: a95127ea    	ldp	x10, x9, [sp, #0x110]
1014348ac: a90b27ea    	stp	x10, x9, [sp, #0xb0]
1014348b0: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1014348b4: eb09011f    	cmp	x8, x9
1014348b8: 540008e0    	b.eq	0x1014349d4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xd68>
1014348bc: a94b0be1    	ldp	x1, x2, [sp, #0xb0]
1014348c0: 97ffaddb    	bl	0x10142002c <__ZN17otty_autocomplete2db13CompletionsDb11lookup_spec17h895ef0a520e673c6E>
1014348c4: aa0003f6    	mov	x22, x0
1014348c8: b4000860    	cbz	x0, 0x1014349d4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xd68>
1014348cc: f9013ff6    	str	x22, [sp, #0x278]
1014348d0: 940e46f7    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
1014348d4: f94073e8    	ldr	x8, [sp, #0xe0]
1014348d8: eb08001f    	cmp	x0, x8
1014348dc: 540062a1    	b.ne	0x101435530 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x18c4>
1014348e0: 6b15003f    	cmp	w1, w21
1014348e4: 540062a8    	b.hi	0x101435538 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x18cc>
1014348e8: 910a43e0    	add	x0, sp, #0x290
1014348ec: 910042c1    	add	x1, x22, #0x10
1014348f0: f94063e2    	ldr	x2, [sp, #0xc0]
1014348f4: aa1c03e3    	mov	x3, x28
1014348f8: aa1403e4    	mov	x4, x20
1014348fc: 940018e1    	bl	0x10143ac80 <__ZN17otty_autocomplete6engine6Engine8has_spec17h9c13a037468e2f54E+0x1c>
101434900: f9004ff6    	str	x22, [sp, #0x98]
101434904: b9007bf5    	str	w21, [sp, #0x78]
101434908: 3600ded4    	tbz	w20, #0x0, 0x1014364e0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2874>
10143490c: d2800017    	mov	x23, #0x0               ; =0
101434910: 5280003a    	mov	w26, #0x1               ; =1
101434914: f90173ff    	str	xzr, [sp, #0x2e0]
101434918: f90177fa    	str	x26, [sp, #0x2e8]
10143491c: f9017bff    	str	xzr, [sp, #0x2f0]
101434920: f94163f9    	ldr	x25, [sp, #0x2c0]
101434924: 52800108    	mov	w8, #0x8                ; =8
101434928: f90183ff    	str	xzr, [sp, #0x300]
10143492c: f90187e8    	str	x8, [sp, #0x308]
101434930: f9018bff    	str	xzr, [sp, #0x310]
101434934: 1400071f    	b	0x1014365b0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2944>
101434938: a95107f4    	ldp	x20, x1, [sp, #0x110]
10143493c: b4000661    	cbz	x1, 0x101434a08 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xd9c>
101434940: f94077e0    	ldr	x0, [sp, #0xe8]
101434944: 39434013    	ldrb	w19, [x0, #0xd0]
101434948: 910483e8    	add	x8, sp, #0x120
10143494c: aa0103e4    	mov	x4, x1
101434950: f9406fe1    	ldr	x1, [sp, #0xd8]
101434954: f94067e2    	ldr	x2, [sp, #0xc8]
101434958: aa1403e3    	mov	x3, x20
10143495c: f9002be4    	str	x4, [sp, #0x50]
101434960: 94004405    	bl	0x101445974 <__ZN17otty_autocomplete7learned15LearnedCommands11completions17h3fd4cb5f221f42c6E>
101434964: 36000b53    	tbz	w19, #0x0, 0x101434acc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xe60>
101434968: 9104e3e0    	add	x0, sp, #0x138
10143496c: f94077e8    	ldr	x8, [sp, #0xe8]
101434970: 910d0101    	add	x1, x8, #0x340
101434974: f9406fe2    	ldr	x2, [sp, #0xd8]
101434978: f94067e3    	ldr	x3, [sp, #0xc8]
10143497c: aa1403e4    	mov	x4, x20
101434980: f9402be5    	ldr	x5, [sp, #0x50]
101434984: 94002004    	bl	0x10143c994 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x7c>
101434988: 14000054    	b	0x101434ad8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xe6c>
10143498c: 38dfe149    	ldursb	w9, [x10, #-0x2]
101434990: 3101013f    	cmn	w9, #0x40
101434994: 540002ea    	b.ge	0x1014349f0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xd84>
101434998: 12001d29    	and	w9, w9, #0xff
10143499c: 38dfd14b    	ldursb	w11, [x10, #-0x3]
1014349a0: 3101017f    	cmn	w11, #0x40
1014349a4: 5400588a    	b.ge	0x1014354b4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1848>
1014349a8: 12001d6b    	and	w11, w11, #0xff
1014349ac: 385fc14c    	ldurb	w12, [x10, #-0x4]
1014349b0: 1200156a    	and	w10, w11, #0x3f
1014349b4: 331a098a    	bfi	w10, w12, #6, #3
1014349b8: 12001529    	and	w9, w9, #0x3f
1014349bc: 2a0a1929    	orr	w9, w9, w10, lsl #6
1014349c0: 12001508    	and	w8, w8, #0x3f
1014349c4: 2a091908    	orr	w8, w8, w9, lsl #6
1014349c8: 7100891f    	cmp	w8, #0x22
1014349cc: 54fff181    	b.ne	0x1014347fc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xb90>
1014349d0: 17ffff8d    	b	0x101434804 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xb98>
1014349d4: 34000294    	cbz	w20, 0x101434a24 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xdb8>
1014349d8: d2800008    	mov	x8, #0x0                ; =0
1014349dc: 52800029    	mov	w9, #0x1                ; =1
1014349e0: f90183ff    	str	xzr, [sp, #0x300]
1014349e4: f90187e9    	str	x9, [sp, #0x308]
1014349e8: f9018bff    	str	xzr, [sp, #0x310]
1014349ec: 14000015    	b	0x101434a40 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xdd4>
1014349f0: 12001129    	and	w9, w9, #0x1f
1014349f4: 12001508    	and	w8, w8, #0x3f
1014349f8: 2a091908    	orr	w8, w8, w9, lsl #6
1014349fc: 7100891f    	cmp	w8, #0x22
101434a00: 54ffefe1    	b.ne	0x1014347fc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xb90>
101434a04: 17ffff80    	b	0x101434804 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xb98>
101434a08: 52800108    	mov	w8, #0x8                ; =8
101434a0c: f90183ff    	str	xzr, [sp, #0x300]
101434a10: f90187e8    	str	x8, [sp, #0x308]
101434a14: f9018bff    	str	xzr, [sp, #0x310]
101434a18: f9406fe8    	ldr	x8, [sp, #0xd8]
101434a1c: b500c668    	cbnz	x8, 0x1014362e8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x267c>
101434a20: 1400067b    	b	0x10143640c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x27a0>
101434a24: 52800308    	mov	w8, #0x18               ; =24
101434a28: f94063e9    	ldr	x9, [sp, #0xc0]
101434a2c: 9b082788    	madd	x8, x28, x8, x9
101434a30: d1006100    	sub	x0, x8, #0x18
101434a34: 910c03e8    	add	x8, sp, #0x300
101434a38: 940f69e5    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101434a3c: f9418be8    	ldr	x8, [sp, #0x310]
101434a40: f100011f    	cmp	x8, #0x0
101434a44: 1a9f07e8    	cset	w8, ne
101434a48: cb080388    	sub	x8, x28, x8
101434a4c: f100051f    	cmp	x8, #0x1
101434a50: 9a9f8501    	csinc	x1, x8, xzr, hi
101434a54: eb1c003f    	cmp	x1, x28
101434a58: 5401b388    	b.hi	0x1014380c8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x445c>
101434a5c: 8b010428    	add	x8, x1, x1, lsl #1
101434a60: d37df108    	lsl	x8, x8, #3
101434a64: f94063e9    	ldr	x9, [sp, #0xc0]
101434a68: 8b080138    	add	x24, x9, x8
101434a6c: 9100c129    	add	x9, x9, #0x30
101434a70: d1006108    	sub	x8, x8, #0x18
101434a74: b9007bf5    	str	w21, [sp, #0x78]
101434a78: b4000228    	cbz	x8, 0x101434abc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xe50>
101434a7c: aa0903f9    	mov	x25, x9
101434a80: f85f8129    	ldur	x9, [x9, #-0x8]
101434a84: b40000e9    	cbz	x9, 0x101434aa0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xe34>
101434a88: f85f0329    	ldur	x9, [x25, #-0x10]
101434a8c: 3940012a    	ldrb	w10, [x9]
101434a90: 91006329    	add	x9, x25, #0x18
101434a94: d1006108    	sub	x8, x8, #0x18
101434a98: 7100b55f    	cmp	w10, #0x2d
101434a9c: 54fffee0    	b.eq	0x101434a78 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xe0c>
101434aa0: d1006320    	sub	x0, x25, #0x18
101434aa4: 910e43e8    	add	x8, sp, #0x390
101434aa8: 940f69c9    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101434aac: f941cbf6    	ldr	x22, [sp, #0x390]
101434ab0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101434ab4: eb0802df    	cmp	x22, x8
101434ab8: 54003e01    	b.ne	0x101435278 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x160c>
101434abc: 52800108    	mov	w8, #0x8                ; =8
101434ac0: a91a23ff    	stp	xzr, x8, [sp, #0x1a0]
101434ac4: f900dbff    	str	xzr, [sp, #0x1b0]
101434ac8: 14000225    	b	0x10143535c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x16f0>
101434acc: 52800108    	mov	w8, #0x8                ; =8
101434ad0: a913a3ff    	stp	xzr, x8, [sp, #0x138]
101434ad4: f900a7ff    	str	xzr, [sp, #0x148]
101434ad8: 3dc04be0    	ldr	q0, [sp, #0x120]
101434adc: 3d8057e0    	str	q0, [sp, #0x150]
101434ae0: f9409bf7    	ldr	x23, [sp, #0x130]
101434ae4: f900b3f7    	str	x23, [sp, #0x160]
101434ae8: f940afe8    	ldr	x8, [sp, #0x158]
101434aec: f9001fe8    	str	x8, [sp, #0x38]
101434af0: 90007a40    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101434af4: 9131a000    	add	x0, x0, #0xc68
101434af8: f9400008    	ldr	x8, [x0]
101434afc: d63f0100    	blr	x8
101434b00: aa0003f6    	mov	x22, x0
101434b04: 39404008    	ldrb	w8, [x0, #0x10]
101434b08: 7100051f    	cmp	w8, #0x1
101434b0c: f9002ff4    	str	x20, [sp, #0x58]
101434b10: 5401ae81    	b.ne	0x1014380e0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4474>
101434b14: a94006c0    	ldp	x0, x1, [x22]
101434b18: 91000408    	add	x8, x0, #0x1
101434b1c: f90002c8    	str	x8, [x22]
101434b20: 900071a8    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101434b24: 91166108    	add	x8, x8, #0x598
101434b28: ad400500    	ldp	q0, q1, [x8]
101434b2c: 3d801be0    	str	q0, [sp, #0x60]
101434b30: ad1c87e0    	stp	q0, q1, [sp, #0x390]
101434b34: 3d8013e1    	str	q1, [sp, #0x40]
101434b38: f901dbe0    	str	x0, [sp, #0x3b0]
101434b3c: f901dfe1    	str	x1, [sp, #0x3b8]
101434b40: b501add7    	cbnz	x23, 0x1014380f8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x448c>
101434b44: ad5c87e0    	ldp	q0, q1, [sp, #0x390]
101434b48: ad0b87e0    	stp	q0, q1, [sp, #0x170]
101434b4c: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
101434b50: 3d8067e0    	str	q0, [sp, #0x190]
101434b54: a953d3ea    	ldp	x10, x20, [sp, #0x138]
101434b58: f940a7e8    	ldr	x8, [sp, #0x148]
101434b5c: 52800d09    	mov	w9, #0x68               ; =104
101434b60: 9b095109    	madd	x9, x8, x9, x20
101434b64: a91a53f4    	stp	x20, x20, [sp, #0x1a0]
101434b68: a91b27ea    	stp	x10, x9, [sp, #0x1b0]
101434b6c: f90057e9    	str	x9, [sp, #0xa8]
101434b70: 9105c3e9    	add	x9, sp, #0x170
101434b74: f900e3e9    	str	x9, [sp, #0x1c0]
101434b78: b4002688    	cbz	x8, 0x101435048 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x13dc>
101434b7c: a901d3ea    	stp	x10, x20, [sp, #0x18]
101434b80: a902dff6    	stp	x22, x23, [sp, #0x28]
101434b84: b9007bf5    	str	w21, [sp, #0x78]
101434b88: f94057f6    	ldr	x22, [sp, #0xa8]
101434b8c: f940c7e8    	ldr	x8, [sp, #0x188]
101434b90: b5000b88    	cbnz	x8, 0x101434d00 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1094>
101434b94: 9101a294    	add	x20, x20, #0x68
101434b98: aa1403e8    	mov	x8, x20
101434b9c: a9f9e51b    	ldp	x27, x25, [x8, #-0x68]!
101434ba0: a9411115    	ldp	x21, x4, [x8, #0x10]
101434ba4: a9421d05    	ldp	x5, x7, [x8, #0x20]
101434ba8: a9430d02    	ldp	x2, x3, [x8, #0x30]
101434bac: a9440113    	ldp	x19, x0, [x8, #0x40]
101434bb0: f9402901    	ldr	x1, [x8, #0x50]
101434bb4: 3cc58100    	ldur	q0, [x8, #0x58]
101434bb8: 3d80cbe0    	str	q0, [sp, #0x320]
101434bbc: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101434bc0: eb09037f    	cmp	x27, x9
101434bc4: 54001e01    	b.ne	0x101434f84 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1318>
101434bc8: 9101a294    	add	x20, x20, #0x68
101434bcc: 9101a108    	add	x8, x8, #0x68
101434bd0: eb16011f    	cmp	x8, x22
101434bd4: 54fffe21    	b.ne	0x101434b98 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xf2c>
101434bd8: 14000117    	b	0x101435034 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x13c8>
101434bdc: 8a180117    	and	x23, x8, x24
101434be0: fc776b49    	ldr	d9, [x26, x23]
101434be4: 2e288d20    	cmeq.8b	v0, v9, v8
101434be8: 9e660008    	fmov	x8, d0
101434bec: f201c116    	ands	x22, x8, #0x8080808080808080
101434bf0: 540003e0    	b.eq	0x101434c6c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1000>
101434bf4: a90b87e0    	stp	x0, x1, [sp, #0xb8]
101434bf8: a90997e3    	stp	x3, x5, [sp, #0x98]
101434bfc: f9005be2    	str	x2, [sp, #0xb0]
101434c00: a9089ff3    	stp	x19, x7, [sp, #0x88]
101434c04: f90043ef    	str	x15, [sp, #0x80]
101434c08: dac002c8    	rbit	x8, x22
101434c0c: dac01108    	clz	x8, x8
101434c10: 8b480ee8    	add	x8, x23, x8, lsr #3
101434c14: 8a180108    	and	x8, x8, x24
101434c18: 52800309    	mov	w9, #0x18               ; =24
101434c1c: 9b09fd08    	mneg	x8, x8, x9
101434c20: 8b080348    	add	x8, x26, x8
101434c24: f85f8109    	ldur	x9, [x8, #-0x8]
101434c28: eb0902bf    	cmp	x21, x9
101434c2c: 54000101    	b.ne	0x101434c4c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xfe0>
101434c30: f85f0101    	ldur	x1, [x8, #-0x10]
101434c34: aa1903e0    	mov	x0, x25
101434c38: aa1503e2    	mov	x2, x21
101434c3c: aa0403f3    	mov	x19, x4
101434c40: 941a53f7    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101434c44: aa1303e4    	mov	x4, x19
101434c48: 34000240    	cbz	w0, 0x101434c90 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1024>
101434c4c: d10006c8    	sub	x8, x22, #0x1
101434c50: ea160116    	ands	x22, x8, x22
101434c54: a94b87e0    	ldp	x0, x1, [sp, #0xb8]
101434c58: f9405be2    	ldr	x2, [sp, #0xb0]
101434c5c: a94997e3    	ldp	x3, x5, [sp, #0x98]
101434c60: a9489ff3    	ldp	x19, x7, [sp, #0x88]
101434c64: f94043ef    	ldr	x15, [sp, #0x80]
101434c68: 54fffd01    	b.ne	0x101434c08 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xf9c>
101434c6c: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
101434c70: 2e208d20    	cmeq.8b	v0, v9, v0
101434c74: 2e30a800    	umaxv.8b	b0, v0
101434c78: 1e260008    	fmov	w8, s0
101434c7c: f94057f6    	ldr	x22, [sp, #0xa8]
101434c80: 37000bc8    	tbnz	w8, #0x0, 0x101434df8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x118c>
101434c84: 910021ef    	add	x15, x15, #0x8
101434c88: 8b0f02e8    	add	x8, x23, x15
101434c8c: 17ffffd4    	b	0x101434bdc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xf70>
101434c90: b40000db    	cbz	x27, 0x101434ca8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x103c>
101434c94: aa1903e0    	mov	x0, x25
101434c98: aa1b03e1    	mov	x1, x27
101434c9c: 52800022    	mov	w2, #0x1                ; =1
101434ca0: 97d9a68f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101434ca4: aa1303e4    	mov	x4, x19
101434ca8: f94057f6    	ldr	x22, [sp, #0xa8]
101434cac: b40000a4    	cbz	x4, 0x101434cc0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1054>
101434cb0: f94053e0    	ldr	x0, [sp, #0xa0]
101434cb4: aa0403e1    	mov	x1, x4
101434cb8: 52800022    	mov	w2, #0x1                ; =1
101434cbc: 97d9a688    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101434cc0: f9405be1    	ldr	x1, [sp, #0xb0]
101434cc4: f240f83f    	tst	x1, #0x7fffffffffffffff
101434cc8: 540000a1    	b.ne	0x101434cdc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1070>
101434ccc: a94b83e1    	ldp	x1, x0, [sp, #0xb8]
101434cd0: f240f83f    	tst	x1, #0x7fffffffffffffff
101434cd4: 540009c0    	b.eq	0x101434e0c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x11a0>
101434cd8: 14000007    	b	0x101434cf4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1088>
101434cdc: f9404fe0    	ldr	x0, [sp, #0x98]
101434ce0: 52800022    	mov	w2, #0x1                ; =1
101434ce4: 97d9a67e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101434ce8: a94b83e1    	ldp	x1, x0, [sp, #0xb8]
101434cec: f240f83f    	tst	x1, #0x7fffffffffffffff
101434cf0: 540008e0    	b.eq	0x101434e0c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x11a0>
101434cf4: 52800022    	mov	w2, #0x1                ; =1
101434cf8: 97d9a679    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101434cfc: 14000044    	b	0x101434e0c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x11a0>
101434d00: aa1403fc    	mov	x28, x20
101434d04: a940669b    	ldp	x27, x25, [x20]
101434d08: a9411295    	ldp	x21, x4, [x20, #0x10]
101434d0c: a9421e85    	ldp	x5, x7, [x20, #0x20]
101434d10: a9430e82    	ldp	x2, x3, [x20, #0x30]
101434d14: a9440293    	ldp	x19, x0, [x20, #0x40]
101434d18: f9402a81    	ldr	x1, [x20, #0x50]
101434d1c: 9101a294    	add	x20, x20, #0x68
101434d20: f940c7e8    	ldr	x8, [sp, #0x188]
101434d24: b40006a8    	cbz	x8, 0x101434df8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x118c>
101434d28: a9592fe9    	ldp	x9, x11, [sp, #0x190]
101434d2c: d28caea8    	mov	x8, #0x6575             ; =25973
101434d30: f2ae0e68    	movk	x8, #0x7073, lsl #16
101434d34: f2cdaca8    	movk	x8, #0x6d65, lsl #32
101434d38: f2ee6de8    	movk	x8, #0x736f, lsl #48
101434d3c: ca08012a    	eor	x10, x9, x8
101434d40: d28deda8    	mov	x8, #0x6f6d             ; =28525
101434d44: f2adcc88    	movk	x8, #0x6e64, lsl #16
101434d48: f2ce4c28    	movk	x8, #0x7261, lsl #32
101434d4c: f2ec8de8    	movk	x8, #0x646f, lsl #48
101434d50: ca080168    	eor	x8, x11, x8
101434d54: d28e4c2c    	mov	x12, #0x7261            ; =29281
101434d58: f2adccac    	movk	x12, #0x6e65, lsl #16
101434d5c: f2ccecac    	movk	x12, #0x6765, lsl #32
101434d60: f2ed8f2c    	movk	x12, #0x6c79, lsl #48
101434d64: ca0c0129    	eor	x9, x9, x12
101434d68: d28cae6c    	mov	x12, #0x6573            ; =25971
101434d6c: f2af2e8c    	movk	x12, #0x7974, lsl #16
101434d70: f2cc8c4c    	movk	x12, #0x6462, lsl #32
101434d74: f2ee8cac    	movk	x12, #0x7465, lsl #48
101434d78: ca0c016b    	eor	x11, x11, x12
101434d7c: f27df2ac    	ands	x12, x21, #0xfffffffffffffff8
101434d80: 540002a0    	b.eq	0x101434dd4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1168>
101434d84: d280000d    	mov	x13, #0x0               ; =0
101434d88: f86d6b2e    	ldr	x14, [x25, x13]
101434d8c: ca0b01cb    	eor	x11, x14, x11
101434d90: 8b08014a    	add	x10, x10, x8
101434d94: cac8cd48    	eor	x8, x10, x8, ror #51
101434d98: 8b090169    	add	x9, x11, x9
101434d9c: 8b08012f    	add	x15, x9, x8
101434da0: cacbc129    	eor	x9, x9, x11, ror #48
101434da4: 93ca814a    	ror	x10, x10, #0x20
101434da8: cac8bde8    	eor	x8, x15, x8, ror #47
101434dac: 8b0a012b    	add	x11, x9, x10
101434db0: ca0e016a    	eor	x10, x11, x14
101434db4: cac9ad6b    	eor	x11, x11, x9, ror #43
101434db8: 93cf81e9    	ror	x9, x15, #0x20
101434dbc: 910021ad    	add	x13, x13, #0x8
101434dc0: eb0c01bf    	cmp	x13, x12
101434dc4: 54fffe23    	b.lo	0x101434d88 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x111c>
101434dc8: d100058c    	sub	x12, x12, #0x1
101434dcc: 927df18c    	and	x12, x12, #0xfffffffffffffff8
101434dd0: 9100218c    	add	x12, x12, #0x8
101434dd4: 92400aad    	and	x13, x21, #0x7
101434dd8: f10011bf    	cmp	x13, #0x4
101434ddc: 540001e3    	b.lo	0x101434e18 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x11ac>
101434de0: b86c6b2e    	ldr	w14, [x25, x12]
101434de4: 5280008f    	mov	w15, #0x4               ; =4
101434de8: b24001f0    	orr	x16, x15, #0x1
101434dec: eb0d021f    	cmp	x16, x13
101434df0: 540001e3    	b.lo	0x101434e2c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x11c0>
101434df4: 14000014    	b	0x101434e44 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x11d8>
101434df8: 3cc58380    	ldur	q0, [x28, #0x58]
101434dfc: 3d80cbe0    	str	q0, [sp, #0x320]
101434e00: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101434e04: eb08037f    	cmp	x27, x8
101434e08: 54000be1    	b.ne	0x101434f84 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1318>
101434e0c: eb16029f    	cmp	x20, x22
101434e10: 54fff781    	b.ne	0x101434d00 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1094>
101434e14: 14000088    	b	0x101435034 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x13c8>
101434e18: d280000f    	mov	x15, #0x0               ; =0
101434e1c: d280000e    	mov	x14, #0x0               ; =0
101434e20: b24001f0    	orr	x16, x15, #0x1
101434e24: eb0d021f    	cmp	x16, x13
101434e28: 540000e2    	b.hs	0x101434e44 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x11d8>
101434e2c: 8b0c0330    	add	x16, x25, x12
101434e30: 786f6a10    	ldrh	w16, [x16, x15]
101434e34: d37df1f1    	lsl	x17, x15, #3
101434e38: 9ad12210    	lsl	x16, x16, x17
101434e3c: aa0e020e    	orr	x14, x16, x14
101434e40: b27f01ef    	orr	x15, x15, #0x2
101434e44: eb0d01ff    	cmp	x15, x13
101434e48: 54000102    	b.hs	0x101434e68 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x11fc>
101434e4c: 8b0c01ec    	add	x12, x15, x12
101434e50: 386c6b2c    	ldrb	w12, [x25, x12]
101434e54: d37df1ef    	lsl	x15, x15, #3
101434e58: 9acf218c    	lsl	x12, x12, x15
101434e5c: aa0e018e    	orr	x14, x12, x14
101434e60: 910006ac    	add	x12, x21, #0x1
101434e64: 14000003    	b	0x101434e70 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1204>
101434e68: 910006ac    	add	x12, x21, #0x1
101434e6c: b40002ad    	cbz	x13, 0x101434ec0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1254>
101434e70: d37df1af    	lsl	x15, x13, #3
101434e74: 52801ff0    	mov	w16, #0xff              ; =255
101434e78: 9acf220f    	lsl	x15, x16, x15
101434e7c: aa0f01ce    	orr	x14, x14, x15
101434e80: f1001dbf    	cmp	x13, #0x7
101434e84: 54000201    	b.ne	0x101434ec4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1258>
101434e88: ca0b01cb    	eor	x11, x14, x11
101434e8c: 8b0a010a    	add	x10, x8, x10
101434e90: cac8cd48    	eor	x8, x10, x8, ror #51
101434e94: 8b090169    	add	x9, x11, x9
101434e98: 8b08012d    	add	x13, x9, x8
101434e9c: cacbc129    	eor	x9, x9, x11, ror #48
101434ea0: 93ca814a    	ror	x10, x10, #0x20
101434ea4: cac8bda8    	eor	x8, x13, x8, ror #47
101434ea8: 8b0a012b    	add	x11, x9, x10
101434eac: ca0e016a    	eor	x10, x11, x14
101434eb0: cac9ad6b    	eor	x11, x11, x9, ror #43
101434eb4: 93cd81a9    	ror	x9, x13, #0x20
101434eb8: d280000e    	mov	x14, #0x0               ; =0
101434ebc: 14000002    	b	0x101434ec4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1258>
101434ec0: 52801fee    	mov	w14, #0xff              ; =255
101434ec4: d280000f    	mov	x15, #0x0               ; =0
101434ec8: aa0ce1cc    	orr	x12, x14, x12, lsl #56
101434ecc: ca0b018b    	eor	x11, x12, x11
101434ed0: 8b0a010a    	add	x10, x8, x10
101434ed4: cac8cd48    	eor	x8, x10, x8, ror #51
101434ed8: 8b090169    	add	x9, x11, x9
101434edc: 8b08012d    	add	x13, x9, x8
101434ee0: cacbc129    	eor	x9, x9, x11, ror #48
101434ee4: 93ca814a    	ror	x10, x10, #0x20
101434ee8: cac8bda8    	eor	x8, x13, x8, ror #47
101434eec: 8b0a012a    	add	x10, x9, x10
101434ef0: ca0c014b    	eor	x11, x10, x12
101434ef4: cac9ad49    	eor	x9, x10, x9, ror #43
101434ef8: 93cd81aa    	ror	x10, x13, #0x20
101434efc: d2401d4a    	eor	x10, x10, #0xff
101434f00: 8b08016b    	add	x11, x11, x8
101434f04: cac8cd68    	eor	x8, x11, x8, ror #51
101434f08: 8b0a012a    	add	x10, x9, x10
101434f0c: 8b0a010c    	add	x12, x8, x10
101434f10: cac9c149    	eor	x9, x10, x9, ror #48
101434f14: 93cb816a    	ror	x10, x11, #0x20
101434f18: cac8bd88    	eor	x8, x12, x8, ror #47
101434f1c: 8b0a012a    	add	x10, x9, x10
101434f20: 8b0a010b    	add	x11, x8, x10
101434f24: cac9ad49    	eor	x9, x10, x9, ror #43
101434f28: 93cc818a    	ror	x10, x12, #0x20
101434f2c: cac8cd68    	eor	x8, x11, x8, ror #51
101434f30: 8b0a012a    	add	x10, x9, x10
101434f34: 8b0a010c    	add	x12, x8, x10
101434f38: cac9c149    	eor	x9, x10, x9, ror #48
101434f3c: 93cb816a    	ror	x10, x11, #0x20
101434f40: cac8bd88    	eor	x8, x12, x8, ror #47
101434f44: 8b0a012a    	add	x10, x9, x10
101434f48: 8b0a010b    	add	x11, x8, x10
101434f4c: cac9ad49    	eor	x9, x10, x9, ror #43
101434f50: 93cc818a    	ror	x10, x12, #0x20
101434f54: cac8cd68    	eor	x8, x11, x8, ror #51
101434f58: 8b0a012a    	add	x10, x9, x10
101434f5c: 8b0a010b    	add	x11, x8, x10
101434f60: cac9c149    	eor	x9, x10, x9, ror #48
101434f64: 93c9ad29    	ror	x9, x9, #0x2b
101434f68: cac8bd28    	eor	x8, x9, x8, ror #47
101434f6c: cacb8108    	eor	x8, x8, x11, ror #32
101434f70: ca0b0108    	eor	x8, x8, x11
101434f74: d379fd09    	lsr	x9, x8, #57
101434f78: a95763fa    	ldp	x26, x24, [sp, #0x170]
101434f7c: 0e010d28    	dup.8b	v8, w9
101434f80: 17ffff17    	b	0x101434bdc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xf70>
101434f84: 3dc0cbe0    	ldr	q0, [sp, #0x320]
101434f88: 910e43e8    	add	x8, sp, #0x390
101434f8c: 3c858100    	stur	q0, [x8, #0x58]
101434f90: f901cbfb    	str	x27, [sp, #0x390]
101434f94: f901cff9    	str	x25, [sp, #0x398]
101434f98: f901d3f5    	str	x21, [sp, #0x3a0]
101434f9c: f901d7e4    	str	x4, [sp, #0x3a8]
101434fa0: f901dbe5    	str	x5, [sp, #0x3b0]
101434fa4: f901dfe7    	str	x7, [sp, #0x3b8]
101434fa8: f901e3e2    	str	x2, [sp, #0x3c0]
101434fac: f901e7e3    	str	x3, [sp, #0x3c8]
101434fb0: f901ebf3    	str	x19, [sp, #0x3d0]
101434fb4: f901efe0    	str	x0, [sp, #0x3d8]
101434fb8: f901f3e1    	str	x1, [sp, #0x3e0]
101434fbc: f940abe8    	ldr	x8, [sp, #0x150]
101434fc0: f9401bf3    	ldr	x19, [sp, #0x30]
101434fc4: eb08027f    	cmp	x19, x8
101434fc8: 54000121    	b.ne	0x101434fec <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1380>
101434fcc: 910543e0    	add	x0, sp, #0x150
101434fd0: aa1303e1    	mov	x1, x19
101434fd4: 52800022    	mov	w2, #0x1                ; =1
101434fd8: 52800103    	mov	w3, #0x8                ; =8
101434fdc: 52800d04    	mov	w4, #0x68               ; =104
101434fe0: 9417ce1c    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101434fe4: f940afe8    	ldr	x8, [sp, #0x158]
101434fe8: f9001fe8    	str	x8, [sp, #0x38]
101434fec: f9401fe8    	ldr	x8, [sp, #0x38]
101434ff0: 52800d09    	mov	w9, #0x68               ; =104
101434ff4: 9b092268    	madd	x8, x19, x9, x8
101434ff8: ad5c87e0    	ldp	q0, q1, [sp, #0x390]
101434ffc: 3dc0efe2    	ldr	q2, [sp, #0x3b0]
101435000: ad008901    	stp	q1, q2, [x8, #0x10]
101435004: 3d800100    	str	q0, [x8]
101435008: ad5e07e0    	ldp	q0, q1, [sp, #0x3c0]
10143500c: 3dc0fbe2    	ldr	q2, [sp, #0x3e0]
101435010: f941fbe9    	ldr	x9, [sp, #0x3f0]
101435014: f9003109    	str	x9, [x8, #0x60]
101435018: ad020901    	stp	q1, q2, [x8, #0x40]
10143501c: 3d800d00    	str	q0, [x8, #0x30]
101435020: 91000673    	add	x19, x19, #0x1
101435024: f9001bf3    	str	x19, [sp, #0x30]
101435028: f900b3f3    	str	x19, [sp, #0x160]
10143502c: eb16029f    	cmp	x20, x22
101435030: 54ffdae1    	b.ne	0x101434b8c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xf20>
101435034: f900d7f6    	str	x22, [sp, #0x1a8]
101435038: f9406bfb    	ldr	x27, [sp, #0xd0]
10143503c: b9407bf5    	ldr	w21, [sp, #0x78]
101435040: a9425bf4    	ldp	x20, x22, [sp, #0x20]
101435044: f9400fea    	ldr	x10, [sp, #0x18]
101435048: b40000ca    	cbz	x10, 0x101435060 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x13f4>
10143504c: 52800d08    	mov	w8, #0x68               ; =104
101435050: 9b087d41    	mul	x1, x10, x8
101435054: aa1403e0    	mov	x0, x20
101435058: 52800102    	mov	w2, #0x8                ; =8
10143505c: 97d9a5a0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101435060: 940e4513    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101435064: f94073f3    	ldr	x19, [sp, #0xe0]
101435068: f9402ff4    	ldr	x20, [sp, #0x58]
10143506c: eb13001f    	cmp	x0, x19
101435070: 54000b61    	b.ne	0x1014351dc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1570>
101435074: 6b15003f    	cmp	w1, w21
101435078: 54000b68    	b.hi	0x1014351e4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1578>
10143507c: 910743e8    	add	x8, sp, #0x1d0
101435080: aa1403e0    	mov	x0, x20
101435084: f9402be1    	ldr	x1, [sp, #0x50]
101435088: 940f59ab    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
10143508c: f94077e8    	ldr	x8, [sp, #0xe8]
101435090: 910be100    	add	x0, x8, #0x2f8
101435094: aa1303e1    	mov	x1, x19
101435098: aa1503e2    	mov	x2, x21
10143509c: 94004b84    	bl	0x101447eac <__ZN17otty_autocomplete7sources15PathExecutables3get17h2fb85cccc5c7b0a8E>
1014350a0: aa0003f3    	mov	x19, x0
1014350a4: 9107a3e8    	add	x8, sp, #0x1e8
1014350a8: 940049c3    	bl	0x1014477b4 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E>
1014350ac: a9402668    	ldp	x8, x9, [x19]
1014350b0: 8b090109    	add	x9, x8, x9
1014350b4: 91000529    	add	x9, x9, #0x1
1014350b8: aa0803ea    	mov	x10, x8
1014350bc: fc408540    	ldr	d0, [x10], #0x8
1014350c0: 2e208800    	cmge.8b	v0, v0, #0
1014350c4: 9e66000b    	fmov	x11, d0
1014350c8: 9201c16b    	and	x11, x11, #0x8080808080808080
1014350cc: f9400e6c    	ldr	x12, [x19, #0x18]
1014350d0: a95ebbed    	ldp	x13, x14, [sp, #0x1e8]
1014350d4: 8b0e01ae    	add	x14, x13, x14
1014350d8: 910005ce    	add	x14, x14, #0x1
1014350dc: aa0d03ef    	mov	x15, x13
1014350e0: fc4085e0    	ldr	d0, [x15], #0x8
1014350e4: 2e208800    	cmge.8b	v0, v0, #0
1014350e8: 9e660010    	fmov	x16, d0
1014350ec: 9201c210    	and	x16, x16, #0x8080808080808080
1014350f0: f94103f1    	ldr	x17, [sp, #0x200]
1014350f4: f9019beb    	str	x11, [sp, #0x330]
1014350f8: f9019fea    	str	x10, [sp, #0x338]
1014350fc: f901a3e9    	str	x9, [sp, #0x340]
101435100: f901a7ec    	str	x12, [sp, #0x348]
101435104: f901abed    	str	x13, [sp, #0x350]
101435108: f901aff0    	str	x16, [sp, #0x358]
10143510c: f901b3ef    	str	x15, [sp, #0x360]
101435110: f901b7ee    	str	x14, [sp, #0x368]
101435114: f901bbf1    	str	x17, [sp, #0x370]
101435118: 910743e9    	add	x9, sp, #0x1d0
10143511c: f90197e8    	str	x8, [sp, #0x328]
101435120: f90193e9    	str	x9, [sp, #0x320]
101435124: 910c83e0    	add	x0, sp, #0x320
101435128: 97ff2f55    	bl	0x101400e7c <__ZN107_$LT$otty_autocomplete..fix..rules..CdCorrectionRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h8900cf03849afe93E+0x121c>
10143512c: aa0003f4    	mov	x20, x0
101435130: b4005560    	cbz	x0, 0x101435bdc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1f70>
101435134: 97d9a56f    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101435138: 52800400    	mov	w0, #0x20               ; =32
10143513c: 52800101    	mov	w1, #0x8                ; =8
101435140: 97d9a566    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101435144: b401a900    	cbz	x0, 0x101438664 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x49f8>
101435148: aa0003f3    	mov	x19, x0
10143514c: d2800015    	mov	x21, #0x0               ; =0
101435150: f9000014    	str	x20, [x0]
101435154: 52800028    	mov	w8, #0x1                ; =1
101435158: f90153e8    	str	x8, [sp, #0x2a0]
10143515c: f941bbe8    	ldr	x8, [sp, #0x370]
101435160: f901f3e8    	str	x8, [sp, #0x3e0]
101435164: 52800088    	mov	w8, #0x4                ; =4
101435168: f9014be8    	str	x8, [sp, #0x290]
10143516c: f9014fe0    	str	x0, [sp, #0x298]
101435170: ad5a07e0    	ldp	q0, q1, [sp, #0x340]
101435174: ad1d87e0    	stp	q0, q1, [sp, #0x3b0]
101435178: 3dc0dbe0    	ldr	q0, [sp, #0x360]
10143517c: 3d80f7e0    	str	q0, [sp, #0x3d0]
101435180: ad5907e0    	ldp	q0, q1, [sp, #0x320]
101435184: ad1c87e0    	stp	q0, q1, [sp, #0x390]
101435188: 14000007    	b	0x1014351a4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1538>
10143518c: f9414ff3    	ldr	x19, [sp, #0x298]
101435190: 8b150e68    	add	x8, x19, x21, lsl #3
101435194: f9000514    	str	x20, [x8, #0x8]
101435198: 91000aa8    	add	x8, x21, #0x2
10143519c: f90153e8    	str	x8, [sp, #0x2a0]
1014351a0: 910006b5    	add	x21, x21, #0x1
1014351a4: 910e43e0    	add	x0, sp, #0x390
1014351a8: 97ff2f35    	bl	0x101400e7c <__ZN107_$LT$otty_autocomplete..fix..rules..CdCorrectionRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h8900cf03849afe93E+0x121c>
1014351ac: aa0003f4    	mov	x20, x0
1014351b0: b4001b00    	cbz	x0, 0x101435510 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x18a4>
1014351b4: 910006a1    	add	x1, x21, #0x1
1014351b8: f9414be8    	ldr	x8, [sp, #0x290]
1014351bc: eb08003f    	cmp	x1, x8
1014351c0: 54fffe81    	b.ne	0x101435190 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1524>
1014351c4: 910a43e0    	add	x0, sp, #0x290
1014351c8: 52800022    	mov	w2, #0x1                ; =1
1014351cc: 52800103    	mov	w3, #0x8                ; =8
1014351d0: 52800104    	mov	w4, #0x8                ; =8
1014351d4: 9417cd9f    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1014351d8: 17ffffed    	b	0x10143518c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1520>
1014351dc: eb13001f    	cmp	x0, x19
1014351e0: 54fff4ed    	b.le	0x10143507c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1410>
1014351e4: 3dc057e0    	ldr	q0, [sp, #0x150]
1014351e8: 3d80c3e0    	str	q0, [sp, #0x300]
1014351ec: f940b3e8    	ldr	x8, [sp, #0x160]
1014351f0: f9018be8    	str	x8, [sp, #0x310]
1014351f4: f940bff3    	ldr	x19, [sp, #0x178]
1014351f8: b4001853    	cbz	x19, 0x101435500 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1894>
1014351fc: f940c7f4    	ldr	x20, [sp, #0x188]
101435200: b40016b4    	cbz	x20, 0x1014354d4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1868>
101435204: f940bbf5    	ldr	x21, [sp, #0x170]
101435208: aa1503f6    	mov	x22, x21
10143520c: fc4086c0    	ldr	d0, [x22], #0x8
101435210: 2e208800    	cmge.8b	v0, v0, #0
101435214: 9e660008    	fmov	x8, d0
101435218: 9201c118    	and	x24, x8, #0x8080808080808080
10143521c: 52800317    	mov	w23, #0x18              ; =24
101435220: 14000005    	b	0x101435234 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x15c8>
101435224: d1000708    	sub	x8, x24, #0x1
101435228: 8a180118    	and	x24, x8, x24
10143522c: d1000694    	sub	x20, x20, #0x1
101435230: b4001534    	cbz	x20, 0x1014354d4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1868>
101435234: b50000f8    	cbnz	x24, 0x101435250 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x15e4>
101435238: fc4086c0    	ldr	d0, [x22], #0x8
10143523c: 2e208800    	cmge.8b	v0, v0, #0
101435240: 9e660008    	fmov	x8, d0
101435244: d10302b5    	sub	x21, x21, #0xc0
101435248: 9201c118    	and	x24, x8, #0x8080808080808080
10143524c: b4ffff78    	cbz	x24, 0x101435238 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x15cc>
101435250: dac00308    	rbit	x8, x24
101435254: dac01108    	clz	x8, x8
101435258: cb480fe8    	neg	x8, x8, lsr #3
10143525c: 9b375508    	smaddl	x8, w8, w23, x21
101435260: f85e8101    	ldur	x1, [x8, #-0x18]
101435264: b4fffe01    	cbz	x1, 0x101435224 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x15b8>
101435268: f85f0100    	ldur	x0, [x8, #-0x10]
10143526c: 52800022    	mov	w2, #0x1                ; =1
101435270: 97d9a51b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101435274: 17ffffec    	b	0x101435224 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x15b8>
101435278: f941cff7    	ldr	x23, [sp, #0x398]
10143527c: f941d3f3    	ldr	x19, [sp, #0x3a0]
101435280: 97d9a51c    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101435284: 52800c00    	mov	w0, #0x60               ; =96
101435288: 52800101    	mov	w1, #0x8                ; =8
10143528c: 97d9a513    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101435290: b4019e20    	cbz	x0, 0x101438654 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x49e8>
101435294: aa0003f5    	mov	x21, x0
101435298: a9005c16    	stp	x22, x23, [x0]
10143529c: f9000813    	str	x19, [x0, #0x10]
1014352a0: 52800088    	mov	w8, #0x4                ; =4
1014352a4: f90193e8    	str	x8, [sp, #0x320]
1014352a8: f90197e0    	str	x0, [sp, #0x328]
1014352ac: 52800033    	mov	w19, #0x1               ; =1
1014352b0: 5280031b    	mov	w27, #0x18              ; =24
1014352b4: 14000005    	b	0x1014352c8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x165c>
1014352b8: 9b1b5668    	madd	x8, x19, x27, x21
1014352bc: a9005d16    	stp	x22, x23, [x8]
1014352c0: f900091a    	str	x26, [x8, #0x10]
1014352c4: 91000673    	add	x19, x19, #0x1
1014352c8: f9019bf3    	str	x19, [sp, #0x330]
1014352cc: 91006328    	add	x8, x25, #0x18
1014352d0: d1006100    	sub	x0, x8, #0x18
1014352d4: eb18001f    	cmp	x0, x24
1014352d8: 54000380    	b.eq	0x101435348 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x16dc>
1014352dc: aa0803f9    	mov	x25, x8
1014352e0: f85f8108    	ldur	x8, [x8, #-0x8]
1014352e4: b40000c8    	cbz	x8, 0x1014352fc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1690>
1014352e8: f85f0328    	ldur	x8, [x25, #-0x10]
1014352ec: 39400109    	ldrb	w9, [x8]
1014352f0: 91006328    	add	x8, x25, #0x18
1014352f4: 7100b53f    	cmp	w9, #0x2d
1014352f8: 54fffec0    	b.eq	0x1014352d0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1664>
1014352fc: 910e43e8    	add	x8, sp, #0x390
101435300: 940f67b3    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101435304: f941cbf6    	ldr	x22, [sp, #0x390]
101435308: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10143530c: eb0802df    	cmp	x22, x8
101435310: 540001c0    	b.eq	0x101435348 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x16dc>
101435314: f941cff7    	ldr	x23, [sp, #0x398]
101435318: f941d3fa    	ldr	x26, [sp, #0x3a0]
10143531c: f94193e8    	ldr	x8, [sp, #0x320]
101435320: eb08027f    	cmp	x19, x8
101435324: 54fffca1    	b.ne	0x1014352b8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x164c>
101435328: 910c83e0    	add	x0, sp, #0x320
10143532c: aa1303e1    	mov	x1, x19
101435330: 52800022    	mov	w2, #0x1                ; =1
101435334: 52800103    	mov	w3, #0x8                ; =8
101435338: 52800304    	mov	w4, #0x18               ; =24
10143533c: 9417cd45    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101435340: f94197f5    	ldr	x21, [sp, #0x328]
101435344: 17ffffdd    	b	0x1014352b8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x164c>
101435348: 3dc0cbe0    	ldr	q0, [sp, #0x320]
10143534c: 3d806be0    	str	q0, [sp, #0x1a0]
101435350: f9419be8    	ldr	x8, [sp, #0x330]
101435354: f900dbe8    	str	x8, [sp, #0x1b0]
101435358: f9406bfb    	ldr	x27, [sp, #0xd0]
10143535c: 940e4454    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101435360: f94073e8    	ldr	x8, [sp, #0xe0]
101435364: eb08001f    	cmp	x0, x8
101435368: 540000a1    	b.ne	0x10143537c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1710>
10143536c: b9407be8    	ldr	w8, [sp, #0x78]
101435370: 6b08003f    	cmp	w1, w8
101435374: 54000083    	b.lo	0x101435384 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1718>
101435378: 1400007b    	b	0x101435564 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x18f8>
10143537c: eb08001f    	cmp	x0, x8
101435380: 54000f2a    	b.ge	0x101435564 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x18f8>
101435384: a95adbf5    	ldp	x21, x22, [sp, #0x1a8]
101435388: f94187f7    	ldr	x23, [sp, #0x308]
10143538c: f9418bf8    	ldr	x24, [sp, #0x310]
101435390: a94e23e1    	ldp	x1, x8, [sp, #0xe0]
101435394: 910be100    	add	x0, x8, #0x2f8
101435398: b9407be2    	ldr	w2, [sp, #0x78]
10143539c: 94004ac4    	bl	0x101447eac <__ZN17otty_autocomplete7sources15PathExecutables3get17h2fb85cccc5c7b0a8E>
1014353a0: f9011be0    	str	x0, [sp, #0x230]
1014353a4: f94077eb    	ldr	x11, [sp, #0xe8]
1014353a8: 91068173    	add	x19, x11, #0x1a0
1014353ac: f940d168    	ldr	x8, [x11, #0x1a0]
1014353b0: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1014353b4: eb09011f    	cmp	x8, x9
1014353b8: 9a9303e8    	csel	x8, xzr, x19, eq
1014353bc: f9014be8    	str	x8, [sp, #0x290]
1014353c0: 910e2168    	add	x8, x11, #0x388
1014353c4: f901d3f5    	str	x21, [sp, #0x3a0]
1014353c8: f901d7f6    	str	x22, [sp, #0x3a8]
1014353cc: f94063e9    	ldr	x9, [sp, #0xc0]
1014353d0: f901dbe9    	str	x9, [sp, #0x3b0]
1014353d4: f901dffc    	str	x28, [sp, #0x3b8]
1014353d8: f901e3f7    	str	x23, [sp, #0x3c0]
1014353dc: f901e7f8    	str	x24, [sp, #0x3c8]
1014353e0: f9406fe9    	ldr	x9, [sp, #0xd8]
1014353e4: f901cbe9    	str	x9, [sp, #0x390]
1014353e8: f94067e9    	ldr	x9, [sp, #0xc8]
1014353ec: f901cfe9    	str	x9, [sp, #0x398]
1014353f0: f94073e9    	ldr	x9, [sp, #0xe0]
1014353f4: f90203e9    	str	x9, [sp, #0x400]
1014353f8: b9407be9    	ldr	w9, [sp, #0x78]
1014353fc: b9040be9    	str	w9, [sp, #0x408]
101435400: 900071a9    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101435404: 910f4129    	add	x9, x9, #0x3d0
101435408: 9108c3ea    	add	x10, sp, #0x230
10143540c: f901ebea    	str	x10, [sp, #0x3d0]
101435410: f901efe9    	str	x9, [sp, #0x3d8]
101435414: 3dc00100    	ldr	q0, [x8]
101435418: 3d80fbe0    	str	q0, [sp, #0x3e0]
10143541c: 910a43e8    	add	x8, sp, #0x290
101435420: 900071a9    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101435424: 91100129    	add	x9, x9, #0x400
101435428: f901fbe8    	str	x8, [sp, #0x3f0]
10143542c: f901ffe9    	str	x9, [sp, #0x3f8]
101435430: f941bd63    	ldr	x3, [x11, #0x378]
101435434: f941c164    	ldr	x4, [x11, #0x380]
101435438: 910c83e8    	add	x8, sp, #0x320
10143543c: 910e43e2    	add	x2, sp, #0x390
101435440: a94b07e0    	ldp	x0, x1, [sp, #0xb0]
101435444: 97ff6563    	bl	0x10140e9d0 <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE>
101435448: f9419bf7    	ldr	x23, [sp, #0x330]
10143544c: b40007f7    	cbz	x23, 0x101435548 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x18dc>
101435450: f94197f4    	ldr	x20, [sp, #0x328]
101435454: 910e43e0    	add	x0, sp, #0x390
101435458: a94b0be1    	ldp	x1, x2, [sp, #0xb0]
10143545c: aa1503e3    	mov	x3, x21
101435460: aa1603e4    	mov	x4, x22
101435464: 97fff5a8    	bl	0x101432b04 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x7a4>
101435468: f9400268    	ldr	x8, [x19]
10143546c: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101435470: eb09011f    	cmp	x8, x9
101435474: 54000100    	b.eq	0x101435494 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1828>
101435478: f941cff5    	ldr	x21, [sp, #0x398]
10143547c: f941d3e4    	ldr	x4, [sp, #0x3a0]
101435480: aa1303e0    	mov	x0, x19
101435484: aa1403e1    	mov	x1, x20
101435488: aa1703e2    	mov	x2, x23
10143548c: aa1503e3    	mov	x3, x21
101435490: 94002f54    	bl	0x1014411e0 <__ZN17otty_autocomplete7history14CommandHistory5boost17h770725e82b32622eE>
101435494: 3dc0cbe0    	ldr	q0, [sp, #0x320]
101435498: 3d800360    	str	q0, [x27]
10143549c: f9419be8    	ldr	x8, [sp, #0x330]
1014354a0: f9000b68    	str	x8, [x27, #0x10]
1014354a4: f941cbe1    	ldr	x1, [sp, #0x390]
1014354a8: b4002041    	cbz	x1, 0x1014358b0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1c44>
1014354ac: f941cfe0    	ldr	x0, [sp, #0x398]
1014354b0: 140000fe    	b	0x1014358a8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1c3c>
1014354b4: 12000d6a    	and	w10, w11, #0xf
1014354b8: 12001529    	and	w9, w9, #0x3f
1014354bc: 2a0a1929    	orr	w9, w9, w10, lsl #6
1014354c0: 12001508    	and	w8, w8, #0x3f
1014354c4: 2a091908    	orr	w8, w8, w9, lsl #6
1014354c8: 7100891f    	cmp	w8, #0x22
1014354cc: 54ff9981    	b.ne	0x1014347fc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xb90>
1014354d0: 17fffccd    	b	0x101434804 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xb98>
1014354d4: 8b130668    	add	x8, x19, x19, lsl #1
1014354d8: d37df108    	lsl	x8, x8, #3
1014354dc: 8b130109    	add	x9, x8, x19
1014354e0: b1008521    	adds	x1, x9, #0x21
1014354e4: f9402ff4    	ldr	x20, [sp, #0x58]
1014354e8: 540000c0    	b.eq	0x101435500 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1894>
1014354ec: f940bbe9    	ldr	x9, [sp, #0x170]
1014354f0: cb080128    	sub	x8, x9, x8
1014354f4: d1006100    	sub	x0, x8, #0x18
1014354f8: 52800102    	mov	w2, #0x8                ; =8
1014354fc: 97d9a478    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101435500: f9402be1    	ldr	x1, [sp, #0x50]
101435504: f9406fe8    	ldr	x8, [sp, #0xd8]
101435508: b5006f08    	cbnz	x8, 0x1014362e8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x267c>
10143550c: 140003c0    	b	0x10143640c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x27a0>
101435510: f9414be8    	ldr	x8, [sp, #0x290]
101435514: f9414ff7    	ldr	x23, [sp, #0x298]
101435518: 910006b3    	add	x19, x21, #0x1
10143551c: f1000a7f    	cmp	x19, #0x2
101435520: f9000be8    	str	x8, [sp, #0x10]
101435524: 54016122    	b.hs	0x101438148 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x44dc>
101435528: 52800033    	mov	w19, #0x1               ; =1
10143552c: 140001af    	b	0x101435be8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1f7c>
101435530: eb08001f    	cmp	x0, x8
101435534: 54ff9dad    	b.le	0x1014348e8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xc7c>
101435538: 52800108    	mov	w8, #0x8                ; =8
10143553c: a900237f    	stp	xzr, x8, [x27]
101435540: f9000b7f    	str	xzr, [x27, #0x10]
101435544: 140009ee    	b	0x101437cfc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4090>
101435548: f94193e8    	ldr	x8, [sp, #0x320]
10143554c: b40000c8    	cbz	x8, 0x101435564 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x18f8>
101435550: f94197e0    	ldr	x0, [sp, #0x328]
101435554: 52800d09    	mov	w9, #0x68               ; =104
101435558: 9b097d01    	mul	x1, x8, x9
10143555c: 52800102    	mov	w2, #0x8                ; =8
101435560: 97d9a45f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101435564: f9405ff5    	ldr	x21, [sp, #0xb8]
101435568: b4000175    	cbz	x21, 0x101435594 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1928>
10143556c: 97d9a461    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101435570: aa1503e0    	mov	x0, x21
101435574: 52800021    	mov	w1, #0x1                ; =1
101435578: 97d9a458    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10143557c: aa0003f3    	mov	x19, x0
101435580: b50000c0    	cbnz	x0, 0x101435598 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x192c>
101435584: 52800020    	mov	w0, #0x1                ; =1
101435588: aa1503e1    	mov	x1, x21
10143558c: 941a377a    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101435590: 14000c6b    	b	0x10143873c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ad0>
101435594: 52800033    	mov	w19, #0x1               ; =1
101435598: aa1303e0    	mov	x0, x19
10143559c: f9405be1    	ldr	x1, [sp, #0xb0]
1014355a0: aa1503e2    	mov	x2, x21
1014355a4: 941a51a1    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014355a8: f9014bf5    	str	x21, [sp, #0x290]
1014355ac: f90073f3    	str	x19, [sp, #0xe0]
1014355b0: f9014ff3    	str	x19, [sp, #0x298]
1014355b4: f90153f5    	str	x21, [sp, #0x2a0]
1014355b8: 52000288    	eor	w8, w20, #0x1
1014355bc: cb080388    	sub	x8, x28, x8
1014355c0: 52800309    	mov	w9, #0x18               ; =24
1014355c4: f94063ea    	ldr	x10, [sp, #0xc0]
1014355c8: 9b092b89    	madd	x9, x28, x9, x10
1014355cc: f90193ea    	str	x10, [sp, #0x320]
1014355d0: f90197e9    	str	x9, [sp, #0x328]
1014355d4: 52800021    	mov	w1, #0x1                ; =1
1014355d8: f9019be8    	str	x8, [sp, #0x330]
1014355dc: f9019fe1    	str	x1, [sp, #0x338]
1014355e0: d2f00017    	mov	x23, #-0x8000000000000000 ; =-9223372036854775808
1014355e4: 52800418    	mov	w24, #0x20              ; =32
1014355e8: aa1503f3    	mov	x19, x21
1014355ec: aa1503fc    	mov	x28, x21
1014355f0: b40000e1    	cbz	x1, 0x10143560c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x19a0>
1014355f4: f9019fff    	str	xzr, [sp, #0x338]
1014355f8: 910c83e0    	add	x0, sp, #0x320
1014355fc: 97ff20a1    	bl	0x1013fd880 <__ZN7bincode6config3int17cast_u64_to_usize17hdd90f9a911882862E+0xc>
101435600: aa0003f4    	mov	x20, x0
101435604: b5000180    	cbnz	x0, 0x101435634 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x19c8>
101435608: 14000058    	b	0x101435768 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1afc>
10143560c: f9419be8    	ldr	x8, [sp, #0x330]
101435610: b4000ac8    	cbz	x8, 0x101435768 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1afc>
101435614: d1000508    	sub	x8, x8, #0x1
101435618: f9019be8    	str	x8, [sp, #0x330]
10143561c: f94193f4    	ldr	x20, [sp, #0x320]
101435620: f94197e8    	ldr	x8, [sp, #0x328]
101435624: eb08029f    	cmp	x20, x8
101435628: 54000a00    	b.eq	0x101435768 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1afc>
10143562c: 91006288    	add	x8, x20, #0x18
101435630: f90193e8    	str	x8, [sp, #0x320]
101435634: a940da95    	ldp	x21, x22, [x20, #0x8]
101435638: b4000096    	cbz	x22, 0x101435648 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x19dc>
10143563c: 394002a8    	ldrb	w8, [x21]
101435640: 7100b51f    	cmp	w8, #0x2d
101435644: 54000640    	b.eq	0x10143570c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1aa0>
101435648: 910e43e0    	add	x0, sp, #0x390
10143564c: a94e23e2    	ldp	x2, x8, [sp, #0xe0]
101435650: 910dc101    	add	x1, x8, #0x370
101435654: aa1303e3    	mov	x3, x19
101435658: 97ff94de    	bl	0x10141a9d0 <__ZN17otty_autocomplete10help_probe9HelpProbe10ingest_now17h00f145a8c7bfd4c4E+0x290>
10143565c: f941cbe8    	ldr	x8, [sp, #0x390]
101435660: eb17011f    	cmp	x8, x23
101435664: 54000820    	b.eq	0x101435768 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1afc>
101435668: f941dfe8    	ldr	x8, [sp, #0x3b8]
10143566c: b40007a8    	cbz	x8, 0x101435760 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1af4>
101435670: f941dbe9    	ldr	x9, [sp, #0x3b0]
101435674: 8b080508    	add	x8, x8, x8, lsl #1
101435678: d37ced19    	lsl	x25, x8, #4
10143567c: 9100413a    	add	x26, x9, #0x10
101435680: 14000004    	b	0x101435690 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1a24>
101435684: 9100c35a    	add	x26, x26, #0x30
101435688: f100c339    	subs	x25, x25, #0x30
10143568c: 540006a0    	b.eq	0x101435760 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1af4>
101435690: f9400348    	ldr	x8, [x26]
101435694: eb16011f    	cmp	x8, x22
101435698: 54ffff61    	b.ne	0x101435684 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1a18>
10143569c: f85f8340    	ldur	x0, [x26, #-0x8]
1014356a0: aa1503e1    	mov	x1, x21
1014356a4: aa1603e2    	mov	x2, x22
1014356a8: 941a515d    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
1014356ac: 35fffec0    	cbnz	w0, 0x101435684 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1a18>
1014356b0: 910e43e0    	add	x0, sp, #0x390
1014356b4: 94007d66    	bl	0x101454c4c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x77c4>
1014356b8: f9414be9    	ldr	x9, [sp, #0x290]
1014356bc: aa1303e8    	mov	x8, x19
1014356c0: eb13013f    	cmp	x9, x19
1014356c4: 540002a0    	b.eq	0x101435718 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1aac>
1014356c8: f94073e9    	ldr	x9, [sp, #0xe0]
1014356cc: 38286938    	strb	w24, [x9, x8]
1014356d0: 91000676    	add	x22, x19, #0x1
1014356d4: f90153f6    	str	x22, [sp, #0x2a0]
1014356d8: a940ce95    	ldp	x21, x19, [x20, #0x8]
1014356dc: f9414be8    	ldr	x8, [sp, #0x290]
1014356e0: cb160108    	sub	x8, x8, x22
1014356e4: eb08027f    	cmp	x19, x8
1014356e8: 540002c8    	b.hi	0x101435740 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1ad4>
1014356ec: f9414fe8    	ldr	x8, [sp, #0x298]
1014356f0: f90073e8    	str	x8, [sp, #0xe0]
1014356f4: 8b160100    	add	x0, x8, x22
1014356f8: aa1503e1    	mov	x1, x21
1014356fc: aa1303e2    	mov	x2, x19
101435700: 941a514a    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101435704: 8b1302d3    	add	x19, x22, x19
101435708: f90153f3    	str	x19, [sp, #0x2a0]
10143570c: f9419fe1    	ldr	x1, [sp, #0x338]
101435710: b4fff7e1    	cbz	x1, 0x10143560c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x19a0>
101435714: 17ffffb8    	b	0x1014355f4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1988>
101435718: 910a43e0    	add	x0, sp, #0x290
10143571c: aa1303e1    	mov	x1, x19
101435720: 52800022    	mov	w2, #0x1                ; =1
101435724: 52800023    	mov	w3, #0x1                ; =1
101435728: 52800024    	mov	w4, #0x1                ; =1
10143572c: 9417cc49    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101435730: f94153e8    	ldr	x8, [sp, #0x2a0]
101435734: f9414fe9    	ldr	x9, [sp, #0x298]
101435738: f90073e9    	str	x9, [sp, #0xe0]
10143573c: 17ffffe3    	b	0x1014356c8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1a5c>
101435740: 910a43e0    	add	x0, sp, #0x290
101435744: aa1603e1    	mov	x1, x22
101435748: aa1303e2    	mov	x2, x19
10143574c: 52800023    	mov	w3, #0x1                ; =1
101435750: 52800024    	mov	w4, #0x1                ; =1
101435754: 9417cc3f    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101435758: f94153f6    	ldr	x22, [sp, #0x2a0]
10143575c: 17ffffe4    	b	0x1014356ec <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1a80>
101435760: 910e43e0    	add	x0, sp, #0x390
101435764: 94007d3a    	bl	0x101454c4c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x77c4>
101435768: f9414be8    	ldr	x8, [sp, #0x290]
10143576c: f90053e8    	str	x8, [sp, #0xa0]
101435770: f94187f8    	ldr	x24, [sp, #0x308]
101435774: f9418bf5    	ldr	x21, [sp, #0x310]
101435778: 9105c3e8    	add	x8, sp, #0x170
10143577c: a94e53f6    	ldp	x22, x20, [sp, #0xe0]
101435780: 910dc280    	add	x0, x20, #0x370
101435784: aa1603e1    	mov	x1, x22
101435788: aa1303e2    	mov	x2, x19
10143578c: aa1803e3    	mov	x3, x24
101435790: aa1503e4    	mov	x4, x21
101435794: 97ff9b0e    	bl	0x10141c3cc <__ZN17otty_autocomplete10help_probe9HelpProbe16help_completions17h0cf18b1237b2f175E>
101435798: 910dc280    	add	x0, x20, #0x370
10143579c: aa1603e1    	mov	x1, x22
1014357a0: aa1303e2    	mov	x2, x19
1014357a4: 97ff98db    	bl	0x10141bb10 <__ZN17otty_autocomplete10help_probe9HelpProbe15probe_if_needed17h06b148b8526492f7E>
1014357a8: f940c3e8    	ldr	x8, [sp, #0x180]
1014357ac: b40009c8    	cbz	x8, 0x1014358e4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1c78>
1014357b0: 3dc05fe0    	ldr	q0, [sp, #0x170]
1014357b4: 3d80a7e0    	str	q0, [sp, #0x290]
1014357b8: f940c3e8    	ldr	x8, [sp, #0x180]
1014357bc: f90153e8    	str	x8, [sp, #0x2a0]
1014357c0: f94077f4    	ldr	x20, [sp, #0xe8]
1014357c4: f940d288    	ldr	x8, [x20, #0x1a0]
1014357c8: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1014357cc: eb09011f    	cmp	x8, x9
1014357d0: 540000e0    	b.eq	0x1014357ec <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1b80>
1014357d4: f9414fe1    	ldr	x1, [sp, #0x298]
1014357d8: f94153e2    	ldr	x2, [sp, #0x2a0]
1014357dc: 91068280    	add	x0, x20, #0x1a0
1014357e0: f94073e3    	ldr	x3, [sp, #0xe0]
1014357e4: aa1303e4    	mov	x4, x19
1014357e8: 94002e7e    	bl	0x1014411e0 <__ZN17otty_autocomplete7history14CommandHistory5boost17h770725e82b32622eE>
1014357ec: 910c83e0    	add	x0, sp, #0x320
1014357f0: aa1403e1    	mov	x1, x20
1014357f4: f9405be2    	ldr	x2, [sp, #0xb0]
1014357f8: aa1c03e3    	mov	x3, x28
1014357fc: aa1803e4    	mov	x4, x24
101435800: aa1503e5    	mov	x5, x21
101435804: f9406fe6    	ldr	x6, [sp, #0xd8]
101435808: f94067e7    	ldr	x7, [sp, #0xc8]
10143580c: 94000ea2    	bl	0x101439294 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x94>
101435810: f94193f7    	ldr	x23, [sp, #0x320]
101435814: f94197f3    	ldr	x19, [sp, #0x328]
101435818: f9419bf4    	ldr	x20, [sp, #0x330]
10143581c: 52800d08    	mov	w8, #0x68               ; =104
101435820: 9b087e95    	mul	x21, x20, x8
101435824: 8b150268    	add	x8, x19, x21
101435828: f901cbf3    	str	x19, [sp, #0x390]
10143582c: f901cff3    	str	x19, [sp, #0x398]
101435830: f901d3f7    	str	x23, [sp, #0x3a0]
101435834: f901d7e8    	str	x8, [sp, #0x3a8]
101435838: f94153f6    	ldr	x22, [sp, #0x2a0]
10143583c: f9414be8    	ldr	x8, [sp, #0x290]
101435840: cb160108    	sub	x8, x8, x22
101435844: eb08029f    	cmp	x20, x8
101435848: 540154c8    	b.hi	0x1014382e0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4674>
10143584c: f9414fe8    	ldr	x8, [sp, #0x298]
101435850: 52800d09    	mov	w9, #0x68               ; =104
101435854: 9b0922c0    	madd	x0, x22, x9, x8
101435858: aa1303e1    	mov	x1, x19
10143585c: aa1503e2    	mov	x2, x21
101435860: 941a50f2    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101435864: 8b1402c8    	add	x8, x22, x20
101435868: f90153e8    	str	x8, [sp, #0x2a0]
10143586c: b40000d7    	cbz	x23, 0x101435884 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1c18>
101435870: 52800d08    	mov	w8, #0x68               ; =104
101435874: 9b087ee1    	mul	x1, x23, x8
101435878: aa1303e0    	mov	x0, x19
10143587c: 52800102    	mov	w2, #0x8                ; =8
101435880: 97d9a397    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101435884: 910a43e0    	add	x0, sp, #0x290
101435888: 97ffe421    	bl	0x10142e90c <__ZN17otty_autocomplete4item14dedupe_by_text17hfec778e0c02dfb24E>
10143588c: 3dc0a7e0    	ldr	q0, [sp, #0x290]
101435890: 3d800360    	str	q0, [x27]
101435894: f94153e8    	ldr	x8, [sp, #0x2a0]
101435898: f9000b68    	str	x8, [x27, #0x10]
10143589c: f94053e1    	ldr	x1, [sp, #0xa0]
1014358a0: b4000081    	cbz	x1, 0x1014358b0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1c44>
1014358a4: f94073e0    	ldr	x0, [sp, #0xe0]
1014358a8: 52800022    	mov	w2, #0x1                ; =1
1014358ac: 97d9a38c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014358b0: a95ad3f3    	ldp	x19, x20, [sp, #0x1a8]
1014358b4: b4013a74    	cbz	x20, 0x101438000 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4394>
1014358b8: 91002275    	add	x21, x19, #0x8
1014358bc: 14000004    	b	0x1014358cc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1c60>
1014358c0: 910062b5    	add	x21, x21, #0x18
1014358c4: f1000694    	subs	x20, x20, #0x1
1014358c8: 540139c0    	b.eq	0x101438000 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4394>
1014358cc: f85f82a1    	ldur	x1, [x21, #-0x8]
1014358d0: b4ffff81    	cbz	x1, 0x1014358c0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1c54>
1014358d4: f94002a0    	ldr	x0, [x21]
1014358d8: 52800022    	mov	w2, #0x1                ; =1
1014358dc: 97d9a380    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014358e0: 17fffff8    	b	0x1014358c0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1c54>
1014358e4: 9107a3e0    	add	x0, sp, #0x1e8
1014358e8: f94077e1    	ldr	x1, [sp, #0xe8]
1014358ec: f9405be2    	ldr	x2, [sp, #0xb0]
1014358f0: aa1c03e3    	mov	x3, x28
1014358f4: aa1803e4    	mov	x4, x24
1014358f8: aa1503e5    	mov	x5, x21
1014358fc: f9406fe6    	ldr	x6, [sp, #0xd8]
101435900: f94067e7    	ldr	x7, [sp, #0xc8]
101435904: 94000e64    	bl	0x101439294 <__ZN17otty_autocomplete6engine6Engine15set_jump_lookup17hefe980fd1ac66b7dE+0x94>
101435908: a95f5bf3    	ldp	x19, x22, [sp, #0x1f0]
10143590c: f0007a20    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101435910: 9131a000    	add	x0, x0, #0xc68
101435914: f9400008    	ldr	x8, [x0]
101435918: d63f0100    	blr	x8
10143591c: aa0003f4    	mov	x20, x0
101435920: 39404008    	ldrb	w8, [x0, #0x10]
101435924: 7100051f    	cmp	w8, #0x1
101435928: 54015001    	b.ne	0x101438328 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x46bc>
10143592c: a9400680    	ldp	x0, x1, [x20]
101435930: 91000408    	add	x8, x0, #0x1
101435934: f9000288    	str	x8, [x20]
101435938: f0007188    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
10143593c: 91166108    	add	x8, x8, #0x598
101435940: ad400500    	ldp	q0, q1, [x8]
101435944: ad1c87e0    	stp	q0, q1, [sp, #0x390]
101435948: f9003fe0    	str	x0, [sp, #0x78]
10143594c: f901dbe0    	str	x0, [sp, #0x3b0]
101435950: f901dfe1    	str	x1, [sp, #0x3b8]
101435954: b5014f96    	cbnz	x22, 0x101438344 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x46d8>
101435958: f9006fe1    	str	x1, [sp, #0xd8]
10143595c: f90067ff    	str	xzr, [sp, #0xc8]
101435960: d0003688    	adrp	x8, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
101435964: 91242108    	add	x8, x8, #0x908
101435968: f90057e8    	str	x8, [sp, #0xa8]
10143596c: 52800028    	mov	w8, #0x1                ; =1
101435970: b900c3e8    	str	w8, [sp, #0xc0]
101435974: f94077ea    	ldr	x10, [sp, #0xe8]
101435978: f940d148    	ldr	x8, [x10, #0x1a0]
10143597c: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101435980: eb09011f    	cmp	x8, x9
101435984: 54000180    	b.eq	0x1014359b4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1d48>
101435988: 910e43e8    	add	x8, sp, #0x390
10143598c: 91068140    	add	x0, x10, #0x1a0
101435990: f9405be1    	ldr	x1, [sp, #0xb0]
101435994: aa1c03e2    	mov	x2, x28
101435998: aa1803e3    	mov	x3, x24
10143599c: aa1503e4    	mov	x4, x21
1014359a0: 9400293d    	bl	0x10143fe94 <__ZN17otty_autocomplete7history14CommandHistory19history_completions17h701f0bafb2f794c8E>
1014359a4: f941cbea    	ldr	x10, [sp, #0x390]
1014359a8: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014359ac: eb08015f    	cmp	x10, x8
1014359b0: 540063c1    	b.ne	0x101436628 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x29bc>
1014359b4: d280000a    	mov	x10, #0x0               ; =0
1014359b8: 52800113    	mov	w19, #0x8               ; =8
1014359bc: 5280010b    	mov	w11, #0x8               ; =8
1014359c0: cb0b0268    	sub	x8, x19, x11
1014359c4: d343fd08    	lsr	x8, x8, #3
1014359c8: d289d8a9    	mov	x9, #0x4ec5             ; =20165
1014359cc: f2b89d89    	movk	x9, #0xc4ec, lsl #16
1014359d0: f2dd89c9    	movk	x9, #0xec4e, lsl #32
1014359d4: f2e9d889    	movk	x9, #0x4ec4, lsl #48
1014359d8: 9b097d15    	mul	x21, x8, x9
1014359dc: f9011bea    	str	x10, [sp, #0x230]
1014359e0: f9011feb    	str	x11, [sp, #0x238]
1014359e4: f90123f5    	str	x21, [sp, #0x240]
1014359e8: a95ecff7    	ldp	x23, x19, [sp, #0x1e8]
1014359ec: f940fff4    	ldr	x20, [sp, #0x1f8]
1014359f0: 52800d08    	mov	w8, #0x68               ; =104
1014359f4: 9b087e96    	mul	x22, x20, x8
1014359f8: 8b160268    	add	x8, x19, x22
1014359fc: f901cbf3    	str	x19, [sp, #0x390]
101435a00: f901cff3    	str	x19, [sp, #0x398]
101435a04: f901d3f7    	str	x23, [sp, #0x3a0]
101435a08: f901d7e8    	str	x8, [sp, #0x3a8]
101435a0c: cb150148    	sub	x8, x10, x21
101435a10: eb08029f    	cmp	x20, x8
101435a14: 54015268    	b.hi	0x101438460 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x47f4>
101435a18: 52800d08    	mov	w8, #0x68               ; =104
101435a1c: 9b082ea0    	madd	x0, x21, x8, x11
101435a20: aa1303e1    	mov	x1, x19
101435a24: aa1603e2    	mov	x2, x22
101435a28: 941a5080    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101435a2c: 8b1402a8    	add	x8, x21, x20
101435a30: f90123e8    	str	x8, [sp, #0x240]
101435a34: b40000d7    	cbz	x23, 0x101435a4c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1de0>
101435a38: 52800d08    	mov	w8, #0x68               ; =104
101435a3c: 9b087ee1    	mul	x1, x23, x8
101435a40: aa1303e0    	mov	x0, x19
101435a44: 52800102    	mov	w2, #0x8                ; =8
101435a48: 97d9a325    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101435a4c: 9108c3e0    	add	x0, sp, #0x230
101435a50: 97ffe3af    	bl	0x10142e90c <__ZN17otty_autocomplete4item14dedupe_by_text17hfec778e0c02dfb24E>
101435a54: f94077e8    	ldr	x8, [sp, #0xe8]
101435a58: f940d108    	ldr	x8, [x8, #0x1a0]
101435a5c: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101435a60: eb09011f    	cmp	x8, x9
101435a64: 540126c0    	b.eq	0x101437f3c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x42d0>
101435a68: f9411ffa    	ldr	x26, [sp, #0x238]
101435a6c: f94123f9    	ldr	x25, [sp, #0x240]
101435a70: b40072f9    	cbz	x25, 0x1014368cc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2c60>
101435a74: d37ffb36    	lsl	x22, x25, #1
101435a78: 8b1902c8    	add	x8, x22, x25
101435a7c: d37ced13    	lsl	x19, x8, #4
101435a80: 97d9a31c    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101435a84: aa1303e0    	mov	x0, x19
101435a88: 52800101    	mov	w1, #0x8                ; =8
101435a8c: 97d9a313    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101435a90: f9006fe0    	str	x0, [sp, #0xd8]
101435a94: b4016100    	cbz	x0, 0x1014386b4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4a48>
101435a98: d280001b    	mov	x27, #0x0               ; =0
101435a9c: d2800017    	mov	x23, #0x0               ; =0
101435aa0: f9014bf6    	str	x22, [sp, #0x290]
101435aa4: 52800d18    	mov	w24, #0x68              ; =104
101435aa8: 5280031c    	mov	w28, #0x18              ; =24
101435aac: 14000013    	b	0x101435af8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1e8c>
101435ab0: 52800035    	mov	w21, #0x1               ; =1
101435ab4: aa1503e0    	mov	x0, x21
101435ab8: aa1403e1    	mov	x1, x20
101435abc: aa1303e2    	mov	x2, x19
101435ac0: 941a505a    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101435ac4: f941d3e8    	ldr	x8, [sp, #0x3a0]
101435ac8: f9019be8    	str	x8, [sp, #0x330]
101435acc: 3dc0e7e0    	ldr	q0, [sp, #0x390]
101435ad0: 3d80cbe0    	str	q0, [sp, #0x320]
101435ad4: f9406fe9    	ldr	x9, [sp, #0xd8]
101435ad8: 9b1c2769    	madd	x9, x27, x28, x9
101435adc: 3d800120    	str	q0, [x9]
101435ae0: a9014d28    	stp	x8, x19, [x9, #0x10]
101435ae4: a9024d35    	stp	x21, x19, [x9, #0x20]
101435ae8: 91000b7b    	add	x27, x27, #0x2
101435aec: 910006f7    	add	x23, x23, #0x1
101435af0: eb1902ff    	cmp	x23, x25
101435af4: 54005940    	b.eq	0x10143661c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x29b0>
101435af8: 9b186af3    	madd	x19, x23, x24, x26
101435afc: 910e43e8    	add	x8, sp, #0x390
101435b00: aa1303e0    	mov	x0, x19
101435b04: 940f65b2    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101435b08: a940ce74    	ldp	x20, x19, [x19, #0x8]
101435b0c: b4fffd33    	cbz	x19, 0x101435ab0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1e44>
101435b10: 8b130288    	add	x8, x20, x19
101435b14: aa0803e9    	mov	x9, x8
101435b18: 14000004    	b	0x101435b28 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1ebc>
101435b1c: aa0903e8    	mov	x8, x9
101435b20: eb09029f    	cmp	x20, x9
101435b24: 540004c0    	b.eq	0x101435bbc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1f50>
101435b28: 38dffd2a    	ldrsb	w10, [x9, #-0x1]!
101435b2c: 37f800ca    	tbnz	w10, #0x1f, 0x101435b44 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1ed8>
101435b30: 7101715f    	cmp	w10, #0x5c
101435b34: 54ffff40    	b.eq	0x101435b1c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1eb0>
101435b38: 7100bd5f    	cmp	w10, #0x2f
101435b3c: 54ffff00    	b.eq	0x101435b1c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1eb0>
101435b40: 1400001e    	b	0x101435bb8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1f4c>
101435b44: aa0803e9    	mov	x9, x8
101435b48: 38dfed2b    	ldrsb	w11, [x9, #-0x2]!
101435b4c: 3101017f    	cmn	w11, #0x40
101435b50: 5400016a    	b.ge	0x101435b7c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1f10>
101435b54: aa0803e9    	mov	x9, x8
101435b58: 38dfdd2c    	ldrsb	w12, [x9, #-0x3]!
101435b5c: 3101019f    	cmn	w12, #0x40
101435b60: 540001aa    	b.ge	0x101435b94 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1f28>
101435b64: 12001d8c    	and	w12, w12, #0xff
101435b68: aa0803e9    	mov	x9, x8
101435b6c: 385fcd2d    	ldrb	w13, [x9, #-0x4]!
101435b70: 1200158c    	and	w12, w12, #0x3f
101435b74: 331a09ac    	bfi	w12, w13, #6, #3
101435b78: 14000008    	b	0x101435b98 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1f2c>
101435b7c: 1200116b    	and	w11, w11, #0x1f
101435b80: 1200154a    	and	w10, w10, #0x3f
101435b84: 2a0b194a    	orr	w10, w10, w11, lsl #6
101435b88: 7101715f    	cmp	w10, #0x5c
101435b8c: 54fffd61    	b.ne	0x101435b38 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1ecc>
101435b90: 17ffffe3    	b	0x101435b1c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1eb0>
101435b94: 12000d8c    	and	w12, w12, #0xf
101435b98: 12001d6b    	and	w11, w11, #0xff
101435b9c: 1200156b    	and	w11, w11, #0x3f
101435ba0: 2a0c196b    	orr	w11, w11, w12, lsl #6
101435ba4: 1200154a    	and	w10, w10, #0x3f
101435ba8: 2a0b194a    	orr	w10, w10, w11, lsl #6
101435bac: 7101715f    	cmp	w10, #0x5c
101435bb0: 54fffc41    	b.ne	0x101435b38 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1ecc>
101435bb4: 17ffffda    	b	0x101435b1c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1eb0>
101435bb8: cb140113    	sub	x19, x8, x20
101435bbc: b4fff7b3    	cbz	x19, 0x101435ab0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1e44>
101435bc0: 97d9a2cc    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101435bc4: aa1303e0    	mov	x0, x19
101435bc8: 52800021    	mov	w1, #0x1                ; =1
101435bcc: 97d9a2c3    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101435bd0: b40153a0    	cbz	x0, 0x101438644 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x49d8>
101435bd4: aa0003f5    	mov	x21, x0
101435bd8: 17ffffb7    	b	0x101435ab4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1e48>
101435bdc: f9000bff    	str	xzr, [sp, #0x10]
101435be0: d2800013    	mov	x19, #0x0               ; =0
101435be4: 52800117    	mov	w23, #0x8               ; =8
101435be8: f9402fe1    	ldr	x1, [sp, #0x58]
101435bec: 910863f4    	add	x20, sp, #0x218
101435bf0: f94077e0    	ldr	x0, [sp, #0xe8]
101435bf4: f84d8c08    	ldr	x8, [x0, #0xd8]!
101435bf8: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101435bfc: eb09011f    	cmp	x8, x9
101435c00: 54000180    	b.eq	0x101435c30 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1fc4>
101435c04: 910e43e8    	add	x8, sp, #0x390
101435c08: f9402be2    	ldr	x2, [sp, #0x50]
101435c0c: 52800643    	mov	w3, #0x32               ; =50
101435c10: 97ffafae    	bl	0x101421ac8 <__ZN17otty_autocomplete2db13CompletionsDb16search_by_prefix17hb9e23076e498d470E>
101435c14: f941cbe9    	ldr	x9, [sp, #0x390]
101435c18: 910a67e8    	add	x8, sp, #0x299
101435c1c: 3ccff100    	ldur	q0, [x8, #0xff]
101435c20: 3d80a7e0    	str	q0, [sp, #0x290]
101435c24: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101435c28: eb08013f    	cmp	x9, x8
101435c2c: 54004d61    	b.ne	0x1014365d8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x296c>
101435c30: d280001c    	mov	x28, #0x0               ; =0
101435c34: a9007ff7    	stp	x23, xzr, [sp]
101435c38: 52800109    	mov	w9, #0x8                ; =8
101435c3c: f9010fff    	str	xzr, [sp, #0x218]
101435c40: 52800108    	mov	w8, #0x8                ; =8
101435c44: f90013e8    	str	x8, [sp, #0x20]
101435c48: f90113e9    	str	x9, [sp, #0x220]
101435c4c: f90117ff    	str	xzr, [sp, #0x228]
101435c50: 394042c8    	ldrb	w8, [x22, #0x10]
101435c54: 7100051f    	cmp	w8, #0x1
101435c58: 54004d41    	b.ne	0x101436600 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2994>
101435c5c: a94006c0    	ldp	x0, x1, [x22]
101435c60: 91000408    	add	x8, x0, #0x1
101435c64: f90002c8    	str	x8, [x22]
101435c68: 3dc01be1    	ldr	q1, [sp, #0x60]
101435c6c: 3dc013e0    	ldr	q0, [sp, #0x40]
101435c70: ad1c83e1    	stp	q1, q0, [sp, #0x390]
101435c74: f901dbe0    	str	x0, [sp, #0x3b0]
101435c78: f901dfe1    	str	x1, [sp, #0x3b8]
101435c7c: b5012cfc    	cbnz	x28, 0x101438218 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x45ac>
101435c80: ad5c87e0    	ldp	q0, q1, [sp, #0x390]
101435c84: ad1187e0    	stp	q0, q1, [sp, #0x230]
101435c88: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
101435c8c: 3d8097e0    	str	q0, [sp, #0x250]
101435c90: 9108c3e8    	add	x8, sp, #0x230
101435c94: f9014be8    	str	x8, [sp, #0x290]
101435c98: 910a43e8    	add	x8, sp, #0x290
101435c9c: f901cbe8    	str	x8, [sp, #0x390]
101435ca0: f1000a7f    	cmp	x19, #0x2
101435ca4: 54012de2    	b.hs	0x101438260 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x45f4>
101435ca8: a955d7e8    	ldp	x8, x21, [sp, #0x158]
101435cac: f9004fe8    	str	x8, [sp, #0x98]
101435cb0: 394042c8    	ldrb	w8, [x22, #0x10]
101435cb4: 7100051f    	cmp	w8, #0x1
101435cb8: 54012e41    	b.ne	0x101438280 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4614>
101435cbc: a94006c0    	ldp	x0, x1, [x22]
101435cc0: 91000408    	add	x8, x0, #0x1
101435cc4: f90002c8    	str	x8, [x22]
101435cc8: 3dc01be1    	ldr	q1, [sp, #0x60]
101435ccc: 3dc013e0    	ldr	q0, [sp, #0x40]
101435cd0: ad1c83e1    	stp	q1, q0, [sp, #0x390]
101435cd4: 910e43e8    	add	x8, sp, #0x390
101435cd8: f901dbe0    	str	x0, [sp, #0x3b0]
101435cdc: f901dfe1    	str	x1, [sp, #0x3b8]
101435ce0: b5012db5    	cbnz	x21, 0x101438294 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4628>
101435ce4: ad5d07e0    	ldp	q0, q1, [sp, #0x3a0]
101435ce8: ad1507e0    	stp	q0, q1, [sp, #0x2a0]
101435cec: 3dc0e7e1    	ldr	q1, [sp, #0x390]
101435cf0: 3d80a7e1    	str	q1, [sp, #0x290]
101435cf4: 8b130ee9    	add	x9, x23, x19, lsl #3
101435cf8: f94157f4    	ldr	x20, [sp, #0x2a8]
101435cfc: f9415be8    	ldr	x8, [sp, #0x2b0]
101435d00: a90aa7e8    	stp	x8, x9, [sp, #0xa8]
101435d04: f9415fe8    	ldr	x8, [sp, #0x2b8]
101435d08: f90053e8    	str	x8, [sp, #0xa0]
101435d0c: f9414fe9    	ldr	x9, [sp, #0x298]
101435d10: f9414be8    	ldr	x8, [sp, #0x290]
101435d14: a90ba7e8    	stp	x8, x9, [sp, #0xb8]
101435d18: 8b1c0788    	add	x8, x28, x28, lsl #1
101435d1c: d37ced09    	lsl	x9, x8, #4
101435d20: f94013e8    	ldr	x8, [sp, #0x20]
101435d24: 91006108    	add	x8, x8, #0x18
101435d28: a902a7e8    	stp	x8, x9, [sp, #0x28]
101435d2c: 52800653    	mov	w19, #0x32              ; =50
101435d30: f94103e8    	ldr	x8, [sp, #0x200]
101435d34: f90033e8    	str	x8, [sp, #0x60]
101435d38: f94107e9    	ldr	x9, [sp, #0x208]
101435d3c: f9410be8    	ldr	x8, [sp, #0x210]
101435d40: a903a7e8    	stp	x8, x9, [sp, #0x38]
101435d44: a95ea7e8    	ldp	x8, x9, [sp, #0x1e8]
101435d48: a907a7e8    	stp	x8, x9, [sp, #0x78]
101435d4c: 14000011    	b	0x101435d90 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2124>
101435d50: f9404fe8    	ldr	x8, [sp, #0x98]
101435d54: 52800d09    	mov	w9, #0x68               ; =104
101435d58: 9b0922a8    	madd	x8, x21, x9, x8
101435d5c: ad5c87e0    	ldp	q0, q1, [sp, #0x390]
101435d60: 3dc0efe2    	ldr	q2, [sp, #0x3b0]
101435d64: ad008901    	stp	q1, q2, [x8, #0x10]
101435d68: 3d800100    	str	q0, [x8]
101435d6c: ad5e07e0    	ldp	q0, q1, [sp, #0x3c0]
101435d70: 3dc0fbe2    	ldr	q2, [sp, #0x3e0]
101435d74: f941fbe9    	ldr	x9, [sp, #0x3f0]
101435d78: f9003109    	str	x9, [x8, #0x60]
101435d7c: ad020901    	stp	q1, q2, [x8, #0x40]
101435d80: 3d800d00    	str	q0, [x8, #0x30]
101435d84: 910006b5    	add	x21, x21, #0x1
101435d88: f900b3f5    	str	x21, [sp, #0x160]
101435d8c: b4001913    	cbz	x19, 0x1014360ac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2440>
101435d90: b5000b74    	cbnz	x20, 0x101435efc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2290>
101435d94: f9405be8    	ldr	x8, [sp, #0xb0]
101435d98: eb0802ff    	cmp	x23, x8
101435d9c: 54001880    	b.eq	0x1014360ac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2440>
101435da0: d1000673    	sub	x19, x19, #0x1
101435da4: f90073f3    	str	x19, [sp, #0xe0]
101435da8: f84086fa    	ldr	x26, [x23], #0x8
101435dac: f94033e8    	ldr	x8, [sp, #0x60]
101435db0: b4000c28    	cbz	x8, 0x101435f34 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x22c8>
101435db4: a94383e1    	ldp	x1, x0, [sp, #0x38]
101435db8: aa1a03e2    	mov	x2, x26
101435dbc: 97d45eb0    	bl	0x10094d87c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a854>
101435dc0: d2800009    	mov	x9, #0x0                ; =0
101435dc4: d379fc08    	lsr	x8, x0, #57
101435dc8: 0e010d08    	dup.8b	v8, w8
101435dcc: a940ef56    	ldp	x22, x27, [x26, #0x8]
101435dd0: a947abe8    	ldp	x8, x10, [sp, #0x78]
101435dd4: 8a0a0019    	and	x25, x0, x10
101435dd8: fc796909    	ldr	d9, [x8, x25]
101435ddc: 2e288d20    	cmeq.8b	v0, v9, v8
101435de0: 9e660008    	fmov	x8, d0
101435de4: f201c118    	ands	x24, x8, #0x8080808080808080
101435de8: 540002e0    	b.eq	0x101435e44 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x21d8>
101435dec: f9000fe9    	str	x9, [sp, #0x18]
101435df0: dac00308    	rbit	x8, x24
101435df4: dac01108    	clz	x8, x8
101435df8: 8b480f28    	add	x8, x25, x8, lsr #3
101435dfc: f94043e9    	ldr	x9, [sp, #0x80]
101435e00: 8a090108    	and	x8, x8, x9
101435e04: 52800609    	mov	w9, #0x30               ; =48
101435e08: 9b09fd08    	mneg	x8, x8, x9
101435e0c: f9403fe9    	ldr	x9, [sp, #0x78]
101435e10: 8b080133    	add	x19, x9, x8
101435e14: f85e0268    	ldur	x8, [x19, #-0x20]
101435e18: eb08037f    	cmp	x27, x8
101435e1c: 540000c1    	b.ne	0x101435e34 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x21c8>
101435e20: f85d8261    	ldur	x1, [x19, #-0x28]
101435e24: aa1603e0    	mov	x0, x22
101435e28: aa1b03e2    	mov	x2, x27
101435e2c: 941a4f7c    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101435e30: 34000ae0    	cbz	w0, 0x101435f8c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2320>
101435e34: d1000708    	sub	x8, x24, #0x1
101435e38: ea180118    	ands	x24, x8, x24
101435e3c: f9400fe9    	ldr	x9, [sp, #0x18]
101435e40: 54fffd81    	b.ne	0x101435df0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2184>
101435e44: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
101435e48: 2e208d20    	cmeq.8b	v0, v9, v0
101435e4c: 2e30a800    	umaxv.8b	b0, v0
101435e50: 1e260008    	fmov	w8, s0
101435e54: 37000708    	tbnz	w8, #0x0, 0x101435f34 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x22c8>
101435e58: 91002129    	add	x9, x9, #0x8
101435e5c: 8b090320    	add	x0, x25, x9
101435e60: 17ffffdc    	b	0x101435dd0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2164>
101435e64: a94ba7e8    	ldp	x8, x9, [sp, #0xb8]
101435e68: 8a090019    	and	x25, x0, x9
101435e6c: fc796909    	ldr	d9, [x8, x25]
101435e70: 2e288d20    	cmeq.8b	v0, v9, v8
101435e74: 9e660008    	fmov	x8, d0
101435e78: f201c118    	ands	x24, x8, #0x8080808080808080
101435e7c: 540002a0    	b.eq	0x101435ed0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2264>
101435e80: dac00308    	rbit	x8, x24
101435e84: dac01108    	clz	x8, x8
101435e88: 8b480f28    	add	x8, x25, x8, lsr #3
101435e8c: f94063e9    	ldr	x9, [sp, #0xc0]
101435e90: 8a090108    	and	x8, x8, x9
101435e94: 52800309    	mov	w9, #0x18               ; =24
101435e98: 9b09fd08    	mneg	x8, x8, x9
101435e9c: f9405fe9    	ldr	x9, [sp, #0xb8]
101435ea0: 8b080128    	add	x8, x9, x8
101435ea4: f85f8109    	ldur	x9, [x8, #-0x8]
101435ea8: eb09037f    	cmp	x27, x9
101435eac: 540000c1    	b.ne	0x101435ec4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2258>
101435eb0: f85f0101    	ldur	x1, [x8, #-0x10]
101435eb4: aa1603e0    	mov	x0, x22
101435eb8: aa1b03e2    	mov	x2, x27
101435ebc: 941a4f58    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101435ec0: 34000180    	cbz	w0, 0x101435ef0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2284>
101435ec4: d1000708    	sub	x8, x24, #0x1
101435ec8: ea180118    	ands	x24, x8, x24
101435ecc: 54fffda1    	b.ne	0x101435e80 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2214>
101435ed0: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
101435ed4: 2e208d20    	cmeq.8b	v0, v9, v0
101435ed8: 2e30a800    	umaxv.8b	b0, v0
101435edc: 1e260008    	fmov	w8, s0
101435ee0: 3707f668    	tbnz	w8, #0x0, 0x101435dac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2140>
101435ee4: 91002273    	add	x19, x19, #0x8
101435ee8: 8b130320    	add	x0, x25, x19
101435eec: 17ffffde    	b	0x101435e64 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x21f8>
101435ef0: f9406bfb    	ldr	x27, [sp, #0xd0]
101435ef4: f94073f3    	ldr	x19, [sp, #0xe0]
101435ef8: b4000db3    	cbz	x19, 0x1014360ac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2440>
101435efc: f9405be8    	ldr	x8, [sp, #0xb0]
101435f00: eb0802ff    	cmp	x23, x8
101435f04: 54000d40    	b.eq	0x1014360ac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2440>
101435f08: d1000673    	sub	x19, x19, #0x1
101435f0c: f90073f3    	str	x19, [sp, #0xe0]
101435f10: f84086fa    	ldr	x26, [x23], #0x8
101435f14: a94a03e1    	ldp	x1, x0, [sp, #0xa0]
101435f18: aa1a03e2    	mov	x2, x26
101435f1c: 97d45e58    	bl	0x10094d87c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a854>
101435f20: d2800013    	mov	x19, #0x0               ; =0
101435f24: d379fc08    	lsr	x8, x0, #57
101435f28: 0e010d08    	dup.8b	v8, w8
101435f2c: a940ef56    	ldp	x22, x27, [x26, #0x8]
101435f30: 17ffffcd    	b	0x101435e64 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x21f8>
101435f34: b40005bc    	cbz	x28, 0x101435fe8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x237c>
101435f38: f9400b5b    	ldr	x27, [x26, #0x10]
101435f3c: a942cff6    	ldp	x22, x19, [sp, #0x28]
101435f40: 910863f8    	add	x24, sp, #0x218
101435f44: 14000004    	b	0x101435f54 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x22e8>
101435f48: 9100c2d6    	add	x22, x22, #0x30
101435f4c: f100c273    	subs	x19, x19, #0x30
101435f50: 54000460    	b.eq	0x101435fdc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2370>
101435f54: f85f82c8    	ldur	x8, [x22, #-0x8]
101435f58: eb1b011f    	cmp	x8, x27
101435f5c: 54ffff61    	b.ne	0x101435f48 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x22dc>
101435f60: f9400741    	ldr	x1, [x26, #0x8]
101435f64: f85f02c0    	ldur	x0, [x22, #-0x10]
101435f68: aa1b03e2    	mov	x2, x27
101435f6c: 941a4f2c    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101435f70: 35fffec0    	cbnz	w0, 0x101435f48 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x22dc>
101435f74: f94002c8    	ldr	x8, [x22]
101435f78: d2f0001b    	mov	x27, #-0x8000000000000000 ; =-9223372036854775808
101435f7c: eb1b011f    	cmp	x8, x27
101435f80: 54000841    	b.ne	0x101436088 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x241c>
101435f84: 52800016    	mov	w22, #0x0               ; =0
101435f88: 1400001b    	b	0x101435ff4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2388>
101435f8c: d1006268    	sub	x8, x19, #0x18
101435f90: f90183e8    	str	x8, [sp, #0x300]
101435f94: 910c03e8    	add	x8, sp, #0x300
101435f98: f901cbe8    	str	x8, [sp, #0x390]
101435f9c: d00000c8    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101435fa0: 91113108    	add	x8, x8, #0x44c
101435fa4: f901cfe8    	str	x8, [sp, #0x398]
101435fa8: 910983e8    	add	x8, sp, #0x260
101435fac: 910e43e1    	add	x1, sp, #0x390
101435fb0: b0004ec0    	adrp	x0, 0x101e0e000 <_writev+0x101e0e000>
101435fb4: 910f8000    	add	x0, x0, #0x3e0
101435fb8: 940f5572    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
101435fbc: 910863f8    	add	x24, sp, #0x218
101435fc0: f94133fb    	ldr	x27, [sp, #0x260]
101435fc4: f94137e8    	ldr	x8, [sp, #0x268]
101435fc8: f9004be8    	str	x8, [sp, #0x90]
101435fcc: 528000b6    	mov	w22, #0x5               ; =5
101435fd0: f9413be8    	ldr	x8, [sp, #0x270]
101435fd4: f90047e8    	str	x8, [sp, #0x88]
101435fd8: 14000007    	b	0x101435ff4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2388>
101435fdc: 52800016    	mov	w22, #0x0               ; =0
101435fe0: d2f0001b    	mov	x27, #-0x8000000000000000 ; =-9223372036854775808
101435fe4: 14000004    	b	0x101435ff4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2388>
101435fe8: 52800016    	mov	w22, #0x0               ; =0
101435fec: d2f0001b    	mov	x27, #-0x8000000000000000 ; =-9223372036854775808
101435ff0: 910863f8    	add	x24, sp, #0x218
101435ff4: 9109e3e8    	add	x8, sp, #0x278
101435ff8: aa1a03e0    	mov	x0, x26
101435ffc: 940f6474    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101436000: 3dc01b00    	ldr	q0, [x24, #0x60]
101436004: 3d80bbe0    	str	q0, [sp, #0x2e0]
101436008: f94147e8    	ldr	x8, [sp, #0x288]
10143600c: f9017be8    	str	x8, [sp, #0x2f0]
101436010: 910c03e8    	add	x8, sp, #0x300
101436014: 910b83e0    	add	x0, sp, #0x2e0
101436018: 940f646d    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10143601c: 3dc01b00    	ldr	q0, [x24, #0x60]
101436020: 910e43e9    	add	x9, sp, #0x390
101436024: 3c818120    	stur	q0, [x9, #0x18]
101436028: f94147e8    	ldr	x8, [sp, #0x288]
10143602c: f8028128    	stur	x8, [x9, #0x28]
101436030: 3dc0c3e0    	ldr	q0, [sp, #0x300]
101436034: f9418be8    	ldr	x8, [sp, #0x310]
101436038: 3d80e7e0    	str	q0, [sp, #0x390]
10143603c: f901d3e8    	str	x8, [sp, #0x3a0]
101436040: f901e3fb    	str	x27, [sp, #0x3c0]
101436044: a948a7e8    	ldp	x8, x9, [sp, #0x88]
101436048: f901e7e9    	str	x9, [sp, #0x3c8]
10143604c: f901ebe8    	str	x8, [sp, #0x3d0]
101436050: 390fc7f6    	strb	w22, [sp, #0x3f1]
101436054: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101436058: f901efe8    	str	x8, [sp, #0x3d8]
10143605c: 390fc3ff    	strb	wzr, [sp, #0x3f0]
101436060: f940abe8    	ldr	x8, [sp, #0x150]
101436064: eb0802bf    	cmp	x21, x8
101436068: f9406bfb    	ldr	x27, [sp, #0xd0]
10143606c: f94073f3    	ldr	x19, [sp, #0xe0]
101436070: 54ffe701    	b.ne	0x101435d50 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x20e4>
101436074: 910543e0    	add	x0, sp, #0x150
101436078: 9419679b    	bl	0x101a8fee4 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h79ba5ff6649e4cf8E>
10143607c: f940afe8    	ldr	x8, [sp, #0x158]
101436080: f9004fe8    	str	x8, [sp, #0x98]
101436084: 17ffff33    	b	0x101435d50 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x20e4>
101436088: 910e43e8    	add	x8, sp, #0x390
10143608c: aa1603e0    	mov	x0, x22
101436090: 940f644f    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101436094: 52800016    	mov	w22, #0x0               ; =0
101436098: f941cbfb    	ldr	x27, [sp, #0x390]
10143609c: f941cfe8    	ldr	x8, [sp, #0x398]
1014360a0: f9004be8    	str	x8, [sp, #0x90]
1014360a4: f941d3e8    	ldr	x8, [sp, #0x3a0]
1014360a8: 17ffffcb    	b	0x101435fd4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2368>
1014360ac: f9400be8    	ldr	x8, [sp, #0x10]
1014360b0: b40000a8    	cbz	x8, 0x1014360c4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2458>
1014360b4: d37df101    	lsl	x1, x8, #3
1014360b8: f94003e0    	ldr	x0, [sp]
1014360bc: 52800102    	mov	w2, #0x8                ; =8
1014360c0: 97d9a187    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014360c4: 3dc057e0    	ldr	q0, [sp, #0x150]
1014360c8: 3d80c3e0    	str	q0, [sp, #0x300]
1014360cc: f940b3e8    	ldr	x8, [sp, #0x160]
1014360d0: f9018be8    	str	x8, [sp, #0x310]
1014360d4: f94063e8    	ldr	x8, [sp, #0xc0]
1014360d8: b4000548    	cbz	x8, 0x101436180 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2514>
1014360dc: b40003d4    	cbz	x20, 0x101436154 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x24e8>
1014360e0: f9405ff3    	ldr	x19, [sp, #0xb8]
1014360e4: aa1303f5    	mov	x21, x19
1014360e8: fc4086a0    	ldr	d0, [x21], #0x8
1014360ec: 2e208800    	cmge.8b	v0, v0, #0
1014360f0: 9e660008    	fmov	x8, d0
1014360f4: 9201c117    	and	x23, x8, #0x8080808080808080
1014360f8: 52800316    	mov	w22, #0x18              ; =24
1014360fc: 14000005    	b	0x101436110 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x24a4>
101436100: d10006e8    	sub	x8, x23, #0x1
101436104: 8a170117    	and	x23, x8, x23
101436108: d1000694    	sub	x20, x20, #0x1
10143610c: b4000254    	cbz	x20, 0x101436154 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x24e8>
101436110: b50000f7    	cbnz	x23, 0x10143612c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x24c0>
101436114: fc4086a0    	ldr	d0, [x21], #0x8
101436118: 2e208800    	cmge.8b	v0, v0, #0
10143611c: 9e660008    	fmov	x8, d0
101436120: d1030273    	sub	x19, x19, #0xc0
101436124: 9201c117    	and	x23, x8, #0x8080808080808080
101436128: b4ffff77    	cbz	x23, 0x101436114 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x24a8>
10143612c: dac002e8    	rbit	x8, x23
101436130: dac01108    	clz	x8, x8
101436134: cb480fe8    	neg	x8, x8, lsr #3
101436138: 9b364d08    	smaddl	x8, w8, w22, x19
10143613c: f85e8101    	ldur	x1, [x8, #-0x18]
101436140: b4fffe01    	cbz	x1, 0x101436100 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2494>
101436144: f85f0100    	ldur	x0, [x8, #-0x10]
101436148: 52800022    	mov	w2, #0x1                ; =1
10143614c: 97d9a164    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101436150: 17ffffec    	b	0x101436100 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2494>
101436154: f94063e9    	ldr	x9, [sp, #0xc0]
101436158: 8b090528    	add	x8, x9, x9, lsl #1
10143615c: d37df108    	lsl	x8, x8, #3
101436160: 8b090109    	add	x9, x8, x9
101436164: b1008521    	adds	x1, x9, #0x21
101436168: 540000c0    	b.eq	0x101436180 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2514>
10143616c: f9405fe9    	ldr	x9, [sp, #0xb8]
101436170: cb080128    	sub	x8, x9, x8
101436174: d1006100    	sub	x0, x8, #0x18
101436178: 52800102    	mov	w2, #0x8                ; =8
10143617c: 97d9a158    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101436180: f9411fe9    	ldr	x9, [sp, #0x238]
101436184: b4000149    	cbz	x9, 0x1014361ac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2540>
101436188: d37ced28    	lsl	x8, x9, #4
10143618c: 8b090109    	add	x9, x8, x9
101436190: b1006521    	adds	x1, x9, #0x19
101436194: 540000c0    	b.eq	0x1014361ac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2540>
101436198: f9411be9    	ldr	x9, [sp, #0x230]
10143619c: cb080128    	sub	x8, x9, x8
1014361a0: d1004100    	sub	x0, x8, #0x10
1014361a4: 52800102    	mov	w2, #0x8                ; =8
1014361a8: 97d9a14d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014361ac: b400027c    	cbz	x28, 0x1014361f8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x258c>
1014361b0: f94013e8    	ldr	x8, [sp, #0x20]
1014361b4: 91008113    	add	x19, x8, #0x20
1014361b8: 14000004    	b	0x1014361c8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x255c>
1014361bc: 9100c273    	add	x19, x19, #0x30
1014361c0: f100079c    	subs	x28, x28, #0x1
1014361c4: 540001a0    	b.eq	0x1014361f8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x258c>
1014361c8: f85e0261    	ldur	x1, [x19, #-0x20]
1014361cc: b4000081    	cbz	x1, 0x1014361dc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2570>
1014361d0: f85e8260    	ldur	x0, [x19, #-0x18]
1014361d4: 52800022    	mov	w2, #0x1                ; =1
1014361d8: 97d9a141    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014361dc: f85f8261    	ldur	x1, [x19, #-0x8]
1014361e0: f240f83f    	tst	x1, #0x7fffffffffffffff
1014361e4: 54fffec0    	b.eq	0x1014361bc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2550>
1014361e8: f9400260    	ldr	x0, [x19]
1014361ec: 52800022    	mov	w2, #0x1                ; =1
1014361f0: 97d9a13b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014361f4: 17fffff2    	b	0x1014361bc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2550>
1014361f8: f94007e8    	ldr	x8, [sp, #0x8]
1014361fc: b40000c8    	cbz	x8, 0x101436214 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x25a8>
101436200: 8b080508    	add	x8, x8, x8, lsl #1
101436204: d37ced01    	lsl	x1, x8, #4
101436208: f94013e0    	ldr	x0, [sp, #0x20]
10143620c: 52800102    	mov	w2, #0x8                ; =8
101436210: 97d9a133    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101436214: 9107a3e0    	add	x0, sp, #0x1e8
101436218: 97d3e1f2    	bl	0x10092e9e0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1b9b8>
10143621c: f940ebe1    	ldr	x1, [sp, #0x1d0]
101436220: b4000081    	cbz	x1, 0x101436230 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x25c4>
101436224: f940efe0    	ldr	x0, [sp, #0x1d8]
101436228: 52800022    	mov	w2, #0x1                ; =1
10143622c: 97d9a12c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101436230: f940bff3    	ldr	x19, [sp, #0x178]
101436234: b4000553    	cbz	x19, 0x1014362dc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2670>
101436238: f940c7f4    	ldr	x20, [sp, #0x188]
10143623c: b40003d4    	cbz	x20, 0x1014362b4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2648>
101436240: f940bbf5    	ldr	x21, [sp, #0x170]
101436244: aa1503f6    	mov	x22, x21
101436248: fc4086c0    	ldr	d0, [x22], #0x8
10143624c: 2e208800    	cmge.8b	v0, v0, #0
101436250: 9e660008    	fmov	x8, d0
101436254: 9201c118    	and	x24, x8, #0x8080808080808080
101436258: 52800317    	mov	w23, #0x18              ; =24
10143625c: 14000005    	b	0x101436270 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2604>
101436260: d1000708    	sub	x8, x24, #0x1
101436264: 8a180118    	and	x24, x8, x24
101436268: d1000694    	sub	x20, x20, #0x1
10143626c: b4000254    	cbz	x20, 0x1014362b4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2648>
101436270: b50000f8    	cbnz	x24, 0x10143628c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2620>
101436274: fc4086c0    	ldr	d0, [x22], #0x8
101436278: 2e208800    	cmge.8b	v0, v0, #0
10143627c: 9e660008    	fmov	x8, d0
101436280: d10302b5    	sub	x21, x21, #0xc0
101436284: 9201c118    	and	x24, x8, #0x8080808080808080
101436288: b4ffff78    	cbz	x24, 0x101436274 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2608>
10143628c: dac00308    	rbit	x8, x24
101436290: dac01108    	clz	x8, x8
101436294: cb480fe8    	neg	x8, x8, lsr #3
101436298: 9b375508    	smaddl	x8, w8, w23, x21
10143629c: f85e8101    	ldur	x1, [x8, #-0x18]
1014362a0: b4fffe01    	cbz	x1, 0x101436260 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x25f4>
1014362a4: f85f0100    	ldur	x0, [x8, #-0x10]
1014362a8: 52800022    	mov	w2, #0x1                ; =1
1014362ac: 97d9a10c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014362b0: 17ffffec    	b	0x101436260 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x25f4>
1014362b4: 8b130668    	add	x8, x19, x19, lsl #1
1014362b8: d37df108    	lsl	x8, x8, #3
1014362bc: 8b130109    	add	x9, x8, x19
1014362c0: b1008521    	adds	x1, x9, #0x21
1014362c4: 540000c0    	b.eq	0x1014362dc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2670>
1014362c8: f940bbe9    	ldr	x9, [sp, #0x170]
1014362cc: cb080128    	sub	x8, x9, x8
1014362d0: d1006100    	sub	x0, x8, #0x18
1014362d4: 52800102    	mov	w2, #0x8                ; =8
1014362d8: 97d9a101    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014362dc: a94553e1    	ldp	x1, x20, [sp, #0x50]
1014362e0: f9406fe8    	ldr	x8, [sp, #0xd8]
1014362e4: b4000948    	cbz	x8, 0x10143640c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x27a0>
1014362e8: 8b010288    	add	x8, x20, x1
1014362ec: aa1403e9    	mov	x9, x20
1014362f0: 14000004    	b	0x101436300 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2694>
1014362f4: aa0b03e9    	mov	x9, x11
1014362f8: 7100bd5f    	cmp	w10, #0x2f
1014362fc: 54000400    	b.eq	0x10143637c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2710>
101436300: eb08013f    	cmp	x9, x8
101436304: 54000840    	b.eq	0x10143640c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x27a0>
101436308: aa0903eb    	mov	x11, x9
10143630c: 38c0156c    	ldrsb	w12, [x11], #0x1
101436310: 12001d8a    	and	w10, w12, #0xff
101436314: 36ffff0c    	tbz	w12, #0x1f, 0x1014362f4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2688>
101436318: 3940052b    	ldrb	w11, [x9, #0x1]
10143631c: 1200156c    	and	w12, w11, #0x3f
101436320: 7103815f    	cmp	w10, #0xe0
101436324: 540001e3    	b.lo	0x101436360 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x26f4>
101436328: 1200114b    	and	w11, w10, #0x1f
10143632c: 3940092d    	ldrb	w13, [x9, #0x2]
101436330: 120015ad    	and	w13, w13, #0x3f
101436334: 2a0c19ac    	orr	w12, w13, w12, lsl #6
101436338: 7103c15f    	cmp	w10, #0xf0
10143633c: 540001a3    	b.lo	0x101436370 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2704>
101436340: 39400d2a    	ldrb	w10, [x9, #0x3]
101436344: 1200154a    	and	w10, w10, #0x3f
101436348: 2a0c194a    	orr	w10, w10, w12, lsl #6
10143634c: 330e096a    	bfi	w10, w11, #18, #3
101436350: 7144415f    	cmp	w10, #0x110, lsl #12    ; =0x110000
101436354: 540005c0    	b.eq	0x10143640c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x27a0>
101436358: 91001129    	add	x9, x9, #0x4
10143635c: 17ffffe7    	b	0x1014362f8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x268c>
101436360: 91000929    	add	x9, x9, #0x2
101436364: 331a114c    	bfi	w12, w10, #6, #5
101436368: aa0c03ea    	mov	x10, x12
10143636c: 17ffffe3    	b	0x1014362f8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x268c>
101436370: 91000d29    	add	x9, x9, #0x3
101436374: 2a0b318a    	orr	w10, w12, w11, lsl #12
101436378: 17ffffe0    	b	0x1014362f8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x268c>
10143637c: 910c83e8    	add	x8, sp, #0x320
101436380: aa1403e0    	mov	x0, x20
101436384: f9406fe2    	ldr	x2, [sp, #0xd8]
101436388: f94067e3    	ldr	x3, [sp, #0xc8]
10143638c: 52800024    	mov	w4, #0x1                ; =1
101436390: 52800025    	mov	w5, #0x1                ; =1
101436394: 94004b3a    	bl	0x10144907c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E>
101436398: f94193f7    	ldr	x23, [sp, #0x320]
10143639c: f94197f3    	ldr	x19, [sp, #0x328]
1014363a0: f9419bf4    	ldr	x20, [sp, #0x330]
1014363a4: 52800d08    	mov	w8, #0x68               ; =104
1014363a8: 9b087e95    	mul	x21, x20, x8
1014363ac: 8b150268    	add	x8, x19, x21
1014363b0: f901cbf3    	str	x19, [sp, #0x390]
1014363b4: f901cff3    	str	x19, [sp, #0x398]
1014363b8: f901d3f7    	str	x23, [sp, #0x3a0]
1014363bc: f901d7e8    	str	x8, [sp, #0x3a8]
1014363c0: f9418bf6    	ldr	x22, [sp, #0x310]
1014363c4: f94183e8    	ldr	x8, [sp, #0x300]
1014363c8: cb160108    	sub	x8, x8, x22
1014363cc: eb08029f    	cmp	x20, x8
1014363d0: 5400f9a8    	b.hi	0x101438304 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4698>
1014363d4: f94187e8    	ldr	x8, [sp, #0x308]
1014363d8: 52800d09    	mov	w9, #0x68               ; =104
1014363dc: 9b0922c0    	madd	x0, x22, x9, x8
1014363e0: aa1303e1    	mov	x1, x19
1014363e4: aa1503e2    	mov	x2, x21
1014363e8: 941a4e10    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014363ec: 8b1402c8    	add	x8, x22, x20
1014363f0: f9018be8    	str	x8, [sp, #0x310]
1014363f4: b40000d7    	cbz	x23, 0x10143640c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x27a0>
1014363f8: 52800d08    	mov	w8, #0x68               ; =104
1014363fc: 9b087ee1    	mul	x1, x23, x8
101436400: aa1303e0    	mov	x0, x19
101436404: 52800102    	mov	w2, #0x8                ; =8
101436408: 97d9a0b5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143640c: 910c03e0    	add	x0, sp, #0x300
101436410: 97ffe13f    	bl	0x10142e90c <__ZN17otty_autocomplete4item14dedupe_by_text17hfec778e0c02dfb24E>
101436414: f94077e8    	ldr	x8, [sp, #0xe8]
101436418: f940d108    	ldr	x8, [x8, #0x1a0]
10143641c: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101436420: eb09011f    	cmp	x8, x9
101436424: 54000320    	b.eq	0x101436488 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x281c>
101436428: f94187e8    	ldr	x8, [sp, #0x308]
10143642c: f9418be9    	ldr	x9, [sp, #0x310]
101436430: b40001a9    	cbz	x9, 0x101436464 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x27f8>
101436434: d280000a    	mov	x10, #0x0               ; =0
101436438: 52800d0b    	mov	w11, #0x68              ; =104
10143643c: 9b0b7d2b    	mul	x11, x9, x11
101436440: 9101850c    	add	x12, x8, #0x61
101436444: 3846858d    	ldrb	w13, [x12], #0x68
101436448: 71001dbf    	cmp	w13, #0x7
10143644c: 540000e3    	b.lo	0x101436468 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x27fc>
101436450: 9100054a    	add	x10, x10, #0x1
101436454: f101a16b    	subs	x11, x11, #0x68
101436458: 54ffff61    	b.ne	0x101436444 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x27d8>
10143645c: aa0903ea    	mov	x10, x9
101436460: 14000002    	b	0x101436468 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x27fc>
101436464: d280000a    	mov	x10, #0x0               ; =0
101436468: cb0a0122    	sub	x2, x9, x10
10143646c: 52800d09    	mov	w9, #0x68               ; =104
101436470: 9b092141    	madd	x1, x10, x9, x8
101436474: f94077e8    	ldr	x8, [sp, #0xe8]
101436478: 91068100    	add	x0, x8, #0x1a0
10143647c: 52800023    	mov	w3, #0x1                ; =1
101436480: d2800004    	mov	x4, #0x0                ; =0
101436484: 94002b57    	bl	0x1014411e0 <__ZN17otty_autocomplete7history14CommandHistory5boost17h770725e82b32622eE>
101436488: 3dc0c3e0    	ldr	q0, [sp, #0x300]
10143648c: 3d800360    	str	q0, [x27]
101436490: f9418be8    	ldr	x8, [sp, #0x310]
101436494: f9000b68    	str	x8, [x27, #0x10]
101436498: f94087e1    	ldr	x1, [sp, #0x108]
10143649c: b4000081    	cbz	x1, 0x1014364ac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2840>
1014364a0: f9408be0    	ldr	x0, [sp, #0x110]
1014364a4: 52800022    	mov	w2, #0x1                ; =1
1014364a8: 97d9a08d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014364ac: a94ff3f3    	ldp	x19, x28, [sp, #0xf8]
1014364b0: b4ff1bdc    	cbz	x28, 0x101434828 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xbbc>
1014364b4: 91002274    	add	x20, x19, #0x8
1014364b8: 14000004    	b	0x1014364c8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x285c>
1014364bc: 91006294    	add	x20, x20, #0x18
1014364c0: f100079c    	subs	x28, x28, #0x1
1014364c4: 54ff1b20    	b.eq	0x101434828 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xbbc>
1014364c8: f85f8281    	ldur	x1, [x20, #-0x8]
1014364cc: b4ffff81    	cbz	x1, 0x1014364bc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2850>
1014364d0: f9400280    	ldr	x0, [x20]
1014364d4: 52800022    	mov	w2, #0x1                ; =1
1014364d8: 97d9a081    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014364dc: 17fffff8    	b	0x1014364bc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2850>
1014364e0: 52800308    	mov	w8, #0x18               ; =24
1014364e4: f94063e9    	ldr	x9, [sp, #0xc0]
1014364e8: 9b082788    	madd	x8, x28, x8, x9
1014364ec: d1006100    	sub	x0, x8, #0x18
1014364f0: 910b83e8    	add	x8, sp, #0x2e0
1014364f4: 940f6336    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1014364f8: f94177fa    	ldr	x26, [sp, #0x2e8]
1014364fc: f9417bf7    	ldr	x23, [sp, #0x2f0]
101436500: f94163f9    	ldr	x25, [sp, #0x2c0]
101436504: 52800108    	mov	w8, #0x8                ; =8
101436508: f90183ff    	str	xzr, [sp, #0x300]
10143650c: f90187e8    	str	x8, [sp, #0x308]
101436510: f9018bff    	str	xzr, [sp, #0x310]
101436514: b40004f7    	cbz	x23, 0x1014365b0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2944>
101436518: 39400348    	ldrb	w8, [x26]
10143651c: 7100b51f    	cmp	w8, #0x2d
101436520: 54000481    	b.ne	0x1014365b0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2944>
101436524: f9414fe4    	ldr	x4, [sp, #0x298]
101436528: f94153e5    	ldr	x5, [sp, #0x2a0]
10143652c: 910c83e0    	add	x0, sp, #0x320
101436530: aa1a03e1    	mov	x1, x26
101436534: aa1703e2    	mov	x2, x23
101436538: aa1903e3    	mov	x3, x25
10143653c: f90057e4    	str	x4, [sp, #0xa8]
101436540: 97fff03e    	bl	0x101432638 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x2d8>
101436544: f94193f6    	ldr	x22, [sp, #0x320]
101436548: f94197f3    	ldr	x19, [sp, #0x328]
10143654c: f9419bf4    	ldr	x20, [sp, #0x330]
101436550: 52800d08    	mov	w8, #0x68               ; =104
101436554: 9b087e95    	mul	x21, x20, x8
101436558: 8b150268    	add	x8, x19, x21
10143655c: f901cbf3    	str	x19, [sp, #0x390]
101436560: f901cff3    	str	x19, [sp, #0x398]
101436564: f901d3f6    	str	x22, [sp, #0x3a0]
101436568: f901d7e8    	str	x8, [sp, #0x3a8]
10143656c: b5010594    	cbnz	x20, 0x10143861c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x49b0>
101436570: d2800017    	mov	x23, #0x0               ; =0
101436574: 52800108    	mov	w8, #0x8                ; =8
101436578: 52800d09    	mov	w9, #0x68               ; =104
10143657c: 9b0922e0    	madd	x0, x23, x9, x8
101436580: aa1303e1    	mov	x1, x19
101436584: aa1503e2    	mov	x2, x21
101436588: 941a4da8    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10143658c: 8b1402e8    	add	x8, x23, x20
101436590: f9018be8    	str	x8, [sp, #0x310]
101436594: b40078b6    	cbz	x22, 0x1014374a8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x383c>
101436598: 52800d08    	mov	w8, #0x68               ; =104
10143659c: 9b087ec1    	mul	x1, x22, x8
1014365a0: aa1303e0    	mov	x0, x19
1014365a4: 52800102    	mov	w2, #0x8                ; =8
1014365a8: 97d9a04d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014365ac: 140003bf    	b	0x1014374a8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x383c>
1014365b0: f94167e8    	ldr	x8, [sp, #0x2c8]
1014365b4: b5004f68    	cbnz	x8, 0x101436fa0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3334>
1014365b8: f9404f28    	ldr	x8, [x25, #0x98]
1014365bc: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1014365c0: eb09011f    	cmp	x8, x9
1014365c4: 540037a1    	b.ne	0x101436cb8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x304c>
1014365c8: d2800014    	mov	x20, #0x0               ; =0
1014365cc: d2800016    	mov	x22, #0x0               ; =0
1014365d0: 52800113    	mov	w19, #0x8               ; =8
1014365d4: 1400025a    	b	0x101436f3c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x32d0>
1014365d8: a90027f7    	stp	x23, x9, [sp]
1014365dc: f9010fe9    	str	x9, [sp, #0x218]
1014365e0: 3dc0a7e0    	ldr	q0, [sp, #0x290]
1014365e4: 3c808280    	stur	q0, [x20, #0x8]
1014365e8: f94113e8    	ldr	x8, [sp, #0x220]
1014365ec: f90013e8    	str	x8, [sp, #0x20]
1014365f0: f94117fc    	ldr	x28, [sp, #0x228]
1014365f4: 394042c8    	ldrb	w8, [x22, #0x10]
1014365f8: 7100051f    	cmp	w8, #0x1
1014365fc: 54ffb300    	b.eq	0x101435c5c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1ff0>
101436600: 940e24e2    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101436604: f90006c1    	str	x1, [x22, #0x8]
101436608: 52800028    	mov	w8, #0x1                ; =1
10143660c: 390042c8    	strb	w8, [x22, #0x10]
101436610: f9406bfb    	ldr	x27, [sp, #0xd0]
101436614: f94003f7    	ldr	x23, [sp]
101436618: 17fffd92    	b	0x101435c60 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1ff4>
10143661c: f9405ffc    	ldr	x28, [sp, #0xb8]
101436620: f9406fe1    	ldr	x1, [sp, #0xd8]
101436624: 140000ad    	b	0x1014368d8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2c6c>
101436628: f941cfeb    	ldr	x11, [sp, #0x398]
10143662c: f941d3e8    	ldr	x8, [sp, #0x3a0]
101436630: b40036e8    	cbz	x8, 0x101436d0c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x30a0>
101436634: a9032beb    	stp	x11, x10, [sp, #0x30]
101436638: 52800d09    	mov	w9, #0x68               ; =104
10143663c: 9b092d0e    	madd	x14, x8, x9, x11
101436640: aa0b03f6    	mov	x22, x11
101436644: aa0b03f3    	mov	x19, x11
101436648: f9406fe1    	ldr	x1, [sp, #0xd8]
10143664c: f9002bee    	str	x14, [sp, #0x50]
101436650: 14000045    	b	0x101436764 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2af8>
101436654: f94067e8    	ldr	x8, [sp, #0xc8]
101436658: 8a08001c    	and	x28, x0, x8
10143665c: f94057e8    	ldr	x8, [sp, #0xa8]
101436660: fc7c6909    	ldr	d9, [x8, x28]
101436664: 2e288d20    	cmeq.8b	v0, v9, v8
101436668: 9e660008    	fmov	x8, d0
10143666c: f201c115    	ands	x21, x8, #0x8080808080808080
101436670: 540002a0    	b.eq	0x1014366c4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2a58>
101436674: f90023e9    	str	x9, [sp, #0x40]
101436678: dac002a8    	rbit	x8, x21
10143667c: dac01108    	clz	x8, x8
101436680: 8b480f88    	add	x8, x28, x8, lsr #3
101436684: f94067e9    	ldr	x9, [sp, #0xc8]
101436688: 8a090108    	and	x8, x8, x9
10143668c: f94057e9    	ldr	x9, [sp, #0xa8]
101436690: cb081128    	sub	x8, x9, x8, lsl #4
101436694: f85f8109    	ldur	x9, [x8, #-0x8]
101436698: eb09029f    	cmp	x20, x9
10143669c: 540000c1    	b.ne	0x1014366b4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2a48>
1014366a0: f85f0101    	ldur	x1, [x8, #-0x10]
1014366a4: aa1703e0    	mov	x0, x23
1014366a8: aa1403e2    	mov	x2, x20
1014366ac: 941a4d5c    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
1014366b0: 34000240    	cbz	w0, 0x1014366f8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2a8c>
1014366b4: d10006a8    	sub	x8, x21, #0x1
1014366b8: ea150115    	ands	x21, x8, x21
1014366bc: f94023e9    	ldr	x9, [sp, #0x40]
1014366c0: 54fffdc1    	b.ne	0x101436678 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2a0c>
1014366c4: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
1014366c8: 2e208d20    	cmeq.8b	v0, v9, v0
1014366cc: 2e30a800    	umaxv.8b	b0, v0
1014366d0: 1e260008    	fmov	w8, s0
1014366d4: f9406fe1    	ldr	x1, [sp, #0xd8]
1014366d8: a9450fee    	ldp	x14, x3, [sp, #0x50]
1014366dc: a9493fe0    	ldp	x0, x15, [sp, #0x90]
1014366e0: a94843f1    	ldp	x17, x16, [sp, #0x80]
1014366e4: f94033e2    	ldr	x2, [sp, #0x60]
1014366e8: 37000ac8    	tbnz	w8, #0x0, 0x101436840 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2bd4>
1014366ec: 91002129    	add	x9, x9, #0x8
1014366f0: 8b090380    	add	x0, x28, x9
1014366f4: 17ffffd8    	b	0x101436654 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x29e8>
1014366f8: b40000b9    	cbz	x25, 0x10143670c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2aa0>
1014366fc: aa1703e0    	mov	x0, x23
101436700: aa1903e1    	mov	x1, x25
101436704: 52800022    	mov	w2, #0x1                ; =1
101436708: 97d99ff5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143670c: f9405ffc    	ldr	x28, [sp, #0xb8]
101436710: b40000bb    	cbz	x27, 0x101436724 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2ab8>
101436714: f9404be0    	ldr	x0, [sp, #0x90]
101436718: aa1b03e1    	mov	x1, x27
10143671c: 52800022    	mov	w2, #0x1                ; =1
101436720: 97d99fef    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101436724: f240fb1f    	tst	x24, #0x7fffffffffffffff
101436728: 540000a0    	b.eq	0x10143673c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2ad0>
10143672c: f94043e0    	ldr	x0, [sp, #0x80]
101436730: aa1803e1    	mov	x1, x24
101436734: 52800022    	mov	w2, #0x1                ; =1
101436738: 97d99fe9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143673c: f9404fe1    	ldr	x1, [sp, #0x98]
101436740: f240f83f    	tst	x1, #0x7fffffffffffffff
101436744: f9406bfb    	ldr	x27, [sp, #0xd0]
101436748: 54000080    	b.eq	0x101436758 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2aec>
10143674c: f94047e0    	ldr	x0, [sp, #0x88]
101436750: 52800022    	mov	w2, #0x1                ; =1
101436754: 97d99fe2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101436758: f9406fe1    	ldr	x1, [sp, #0xd8]
10143675c: f9402bee    	ldr	x14, [sp, #0x50]
101436760: 14000043    	b	0x10143686c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2c00>
101436764: a9405ed9    	ldp	x25, x23, [x22]
101436768: a9416eda    	ldp	x26, x27, [x22, #0x10]
10143676c: a9420ac0    	ldp	x0, x2, [x22, #0x20]
101436770: a94346d8    	ldp	x24, x17, [x22, #0x30]
101436774: a9443ec3    	ldp	x3, x15, [x22, #0x40]
101436778: f9402ad0    	ldr	x16, [x22, #0x50]
10143677c: 3cc582c0    	ldur	q0, [x22, #0x58]
101436780: 3d80e7e0    	str	q0, [sp, #0x390]
101436784: b40007da    	cbz	x26, 0x10143687c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2c10>
101436788: 8b1a02e8    	add	x8, x23, x26
10143678c: aa0803e9    	mov	x9, x8
101436790: 14000004    	b	0x1014367a0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2b34>
101436794: aa0903e8    	mov	x8, x9
101436798: eb0902ff    	cmp	x23, x9
10143679c: 540004a0    	b.eq	0x101436830 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2bc4>
1014367a0: 38dffd2a    	ldrsb	w10, [x9, #-0x1]!
1014367a4: 37f800ca    	tbnz	w10, #0x1f, 0x1014367bc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2b50>
1014367a8: 7101715f    	cmp	w10, #0x5c
1014367ac: 54ffff40    	b.eq	0x101436794 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2b28>
1014367b0: 7100bd5f    	cmp	w10, #0x2f
1014367b4: 54ffff00    	b.eq	0x101436794 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2b28>
1014367b8: 14000040    	b	0x1014368b8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2c4c>
1014367bc: aa0803e9    	mov	x9, x8
1014367c0: 38dfed2b    	ldrsb	w11, [x9, #-0x2]!
1014367c4: 3101017f    	cmn	w11, #0x40
1014367c8: 5400016a    	b.ge	0x1014367f4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2b88>
1014367cc: aa0803e9    	mov	x9, x8
1014367d0: 38dfdd2c    	ldrsb	w12, [x9, #-0x3]!
1014367d4: 3101019f    	cmn	w12, #0x40
1014367d8: 540001aa    	b.ge	0x10143680c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2ba0>
1014367dc: 12001d8c    	and	w12, w12, #0xff
1014367e0: aa0803e9    	mov	x9, x8
1014367e4: 385fcd2d    	ldrb	w13, [x9, #-0x4]!
1014367e8: 1200158c    	and	w12, w12, #0x3f
1014367ec: 331a09ac    	bfi	w12, w13, #6, #3
1014367f0: 14000008    	b	0x101436810 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2ba4>
1014367f4: 1200116b    	and	w11, w11, #0x1f
1014367f8: 1200154a    	and	w10, w10, #0x3f
1014367fc: 2a0b194a    	orr	w10, w10, w11, lsl #6
101436800: 7101715f    	cmp	w10, #0x5c
101436804: 54fffd61    	b.ne	0x1014367b0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2b44>
101436808: 17ffffe3    	b	0x101436794 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2b28>
10143680c: 12000d8c    	and	w12, w12, #0xf
101436810: 12001d6b    	and	w11, w11, #0xff
101436814: 1200156b    	and	w11, w11, #0x3f
101436818: 2a0c196b    	orr	w11, w11, w12, lsl #6
10143681c: 1200154a    	and	w10, w10, #0x3f
101436820: 2a0b194a    	orr	w10, w10, w11, lsl #6
101436824: 7101715f    	cmp	w10, #0x5c
101436828: 54fffc41    	b.ne	0x1014367b0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2b44>
10143682c: 17ffffda    	b	0x101436794 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2b28>
101436830: aa1a03f4    	mov	x20, x26
101436834: f9406fe1    	ldr	x1, [sp, #0xd8]
101436838: b940c3e8    	ldr	w8, [sp, #0xc0]
10143683c: 36000268    	tbz	w8, #0x0, 0x101436888 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2c1c>
101436840: a9005e79    	stp	x25, x23, [x19]
101436844: a9016e7a    	stp	x26, x27, [x19, #0x10]
101436848: a9020a60    	stp	x0, x2, [x19, #0x20]
10143684c: a9034678    	stp	x24, x17, [x19, #0x30]
101436850: a9043e63    	stp	x3, x15, [x19, #0x40]
101436854: f9002a70    	str	x16, [x19, #0x50]
101436858: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10143685c: 3c858260    	stur	q0, [x19, #0x58]
101436860: 9101a273    	add	x19, x19, #0x68
101436864: f9406bfb    	ldr	x27, [sp, #0xd0]
101436868: f9405ffc    	ldr	x28, [sp, #0xb8]
10143686c: 9101a2d6    	add	x22, x22, #0x68
101436870: eb0e02df    	cmp	x22, x14
101436874: 54fff781    	b.ne	0x101436764 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2af8>
101436878: 1400010e    	b	0x101436cb0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3044>
10143687c: d2800014    	mov	x20, #0x0               ; =0
101436880: b940c3e8    	ldr	w8, [sp, #0xc0]
101436884: 3707fde8    	tbnz	w8, #0x0, 0x101436840 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2bd4>
101436888: a9058be3    	stp	x3, x2, [sp, #0x58]
10143688c: a90883f0    	stp	x16, x0, [sp, #0x88]
101436890: f90043f1    	str	x17, [sp, #0x80]
101436894: f9004fef    	str	x15, [sp, #0x98]
101436898: f9403fe0    	ldr	x0, [sp, #0x78]
10143689c: aa1703e2    	mov	x2, x23
1014368a0: aa1403e3    	mov	x3, x20
1014368a4: 97d45b66    	bl	0x10094d63c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a614>
1014368a8: d2800009    	mov	x9, #0x0                ; =0
1014368ac: d379fc08    	lsr	x8, x0, #57
1014368b0: 0e010d08    	dup.8b	v8, w8
1014368b4: 17ffff68    	b	0x101436654 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x29e8>
1014368b8: cb170114    	sub	x20, x8, x23
1014368bc: f9406fe1    	ldr	x1, [sp, #0xd8]
1014368c0: b940c3e8    	ldr	w8, [sp, #0xc0]
1014368c4: 3707fbe8    	tbnz	w8, #0x0, 0x101436840 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2bd4>
1014368c8: 17fffff0    	b	0x101436888 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2c1c>
1014368cc: d2800016    	mov	x22, #0x0               ; =0
1014368d0: d280001b    	mov	x27, #0x0               ; =0
1014368d4: 52800101    	mov	w1, #0x8                ; =8
1014368d8: f9006fe1    	str	x1, [sp, #0xd8]
1014368dc: f90173f6    	str	x22, [sp, #0x2e0]
1014368e0: 910c83e8    	add	x8, sp, #0x320
1014368e4: f94077e9    	ldr	x9, [sp, #0xe8]
1014368e8: 91068120    	add	x0, x9, #0x1a0
1014368ec: aa1b03e2    	mov	x2, x27
1014368f0: f9405be3    	ldr	x3, [sp, #0xb0]
1014368f4: aa1c03e4    	mov	x4, x28
1014368f8: 9400202c    	bl	0x10143e9a8 <__ZN17otty_autocomplete7history14CommandHistory15frecency_scores17h97b33baba167a62bE>
1014368fc: f90123ff    	str	xzr, [sp, #0x240]
101436900: b200e3e8    	mov	x8, #0x1111111111111111 ; =1229782938247303441
101436904: f2822248    	movk	x8, #0x1112
101436908: f2e02228    	movk	x8, #0x111, lsl #48
10143690c: d1000508    	sub	x8, x8, #0x1
101436910: eb08033f    	cmp	x25, x8
101436914: 54000089    	b.ls	0x101436924 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2cb8>
101436918: d2800000    	mov	x0, #0x0                ; =0
10143691c: 941a3296    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101436920: 14000787    	b	0x10143873c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ad0>
101436924: d379e328    	lsl	x8, x25, #7
101436928: cb190d13    	sub	x19, x8, x25, lsl #3
10143692c: f9002ff3    	str	x19, [sp, #0x58]
101436930: b4001f39    	cbz	x25, 0x101436d14 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x30a8>
101436934: 97d99f6f    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101436938: aa1303e0    	mov	x0, x19
10143693c: 52800101    	mov	w1, #0x8                ; =8
101436940: 97d99f66    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101436944: b400ec40    	cbz	x0, 0x1014386cc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4a60>
101436948: aa0003fc    	mov	x28, x0
10143694c: f90077ff    	str	xzr, [sp, #0xe8]
101436950: 52800d08    	mov	w8, #0x68               ; =104
101436954: 9b087f28    	mul	x8, x25, x8
101436958: 8b080349    	add	x9, x26, x8
10143695c: a907a7e0    	stp	x0, x9, [sp, #0x78]
101436960: f9419fea    	ldr	x10, [sp, #0x338]
101436964: f941a3eb    	ldr	x11, [sp, #0x340]
101436968: f941a7e9    	ldr	x9, [sp, #0x348]
10143696c: a9092fe9    	stp	x9, x11, [sp, #0x90]
101436970: f94197e9    	ldr	x9, [sp, #0x328]
101436974: f90063e9    	str	x9, [sp, #0xc0]
101436978: f94193e9    	ldr	x9, [sp, #0x320]
10143697c: a90b27ea    	stp	x10, x9, [sp, #0xb0]
101436980: d101a114    	sub	x20, x8, #0x68
101436984: 9101a353    	add	x19, x26, #0x68
101436988: aa1a03f5    	mov	x21, x26
10143698c: 1400001a    	b	0x1014369f4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2d88>
101436990: aa0803e9    	mov	x9, x8
101436994: 1e606900    	fmaxnm	d0, d8, d0
101436998: 7100013f    	cmp	w9, #0x0
10143699c: 1e681c01    	fcsel	d1, d0, d8, ne
1014369a0: 5280002a    	mov	w10, #0x1               ; =1
1014369a4: 52800f08    	mov	w8, #0x78               ; =120
1014369a8: 9b087168    	madd	x8, x11, x8, x28
1014369ac: f900010a    	str	x10, [x8]
1014369b0: fd000501    	str	d1, [x8, #0x8]
1014369b4: ad5e87e0    	ldp	q0, q1, [sp, #0x3d0]
1014369b8: ad028500    	stp	q0, q1, [x8, #0x50]
1014369bc: f941fbe9    	ldr	x9, [sp, #0x3f0]
1014369c0: f9003909    	str	x9, [x8, #0x70]
1014369c4: ad5c87e0    	ldp	q0, q1, [sp, #0x390]
1014369c8: ad008500    	stp	q0, q1, [x8, #0x10]
1014369cc: ad5d83e1    	ldp	q1, q0, [sp, #0x3b0]
1014369d0: 9100056b    	add	x11, x11, #0x1
1014369d4: f90077eb    	str	x11, [sp, #0xe8]
1014369d8: d101a294    	sub	x20, x20, #0x68
1014369dc: 9101a273    	add	x19, x19, #0x68
1014369e0: aa1503fa    	mov	x26, x21
1014369e4: ad018101    	stp	q1, q0, [x8, #0x30]
1014369e8: f94043e8    	ldr	x8, [sp, #0x80]
1014369ec: eb0802bf    	cmp	x21, x8
1014369f0: 54001be0    	b.eq	0x101436d6c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3100>
1014369f4: f84686a8    	ldr	x8, [x21], #0x68
1014369f8: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1014369fc: eb09011f    	cmp	x8, x9
101436a00: 540019a0    	b.eq	0x101436d34 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x30c8>
101436a04: 3cc28340    	ldur	q0, [x26, #0x28]
101436a08: 910e43e9    	add	x9, sp, #0x390
101436a0c: 3c828120    	stur	q0, [x9, #0x28]
101436a10: 3cc38340    	ldur	q0, [x26, #0x38]
101436a14: 3c838120    	stur	q0, [x9, #0x38]
101436a18: 3cc48340    	ldur	q0, [x26, #0x48]
101436a1c: 3c848120    	stur	q0, [x9, #0x48]
101436a20: 3cc58340    	ldur	q0, [x26, #0x58]
101436a24: 3c858120    	stur	q0, [x9, #0x58]
101436a28: 3cc08340    	ldur	q0, [x26, #0x8]
101436a2c: 3c808120    	stur	q0, [x9, #0x8]
101436a30: 3cc18340    	ldur	q0, [x26, #0x18]
101436a34: 3c818120    	stur	q0, [x9, #0x18]
101436a38: f901cbe8    	str	x8, [sp, #0x390]
101436a3c: f9405be8    	ldr	x8, [sp, #0xb0]
101436a40: b4000608    	cbz	x8, 0x101436b00 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2e94>
101436a44: 910e43e2    	add	x2, sp, #0x390
101436a48: a94903e1    	ldp	x1, x0, [sp, #0x90]
101436a4c: 97d45b8c    	bl	0x10094d87c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a854>
101436a50: d2800009    	mov	x9, #0x0                ; =0
101436a54: d379fc08    	lsr	x8, x0, #57
101436a58: 0e010d08    	dup.8b	v8, w8
101436a5c: f941d3f6    	ldr	x22, [sp, #0x3a0]
101436a60: f941cffa    	ldr	x26, [sp, #0x398]
101436a64: a94babe8    	ldp	x8, x10, [sp, #0xb8]
101436a68: 8a0a0017    	and	x23, x0, x10
101436a6c: fc776909    	ldr	d9, [x8, x23]
101436a70: 2e288d20    	cmeq.8b	v0, v9, v8
101436a74: 9e660008    	fmov	x8, d0
101436a78: f201c118    	ands	x24, x8, #0x8080808080808080
101436a7c: 540002a0    	b.eq	0x101436ad0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2e64>
101436a80: f90047e9    	str	x9, [sp, #0x88]
101436a84: dac00308    	rbit	x8, x24
101436a88: dac01108    	clz	x8, x8
101436a8c: 8b480ee8    	add	x8, x23, x8, lsr #3
101436a90: a94babe9    	ldp	x9, x10, [sp, #0xb8]
101436a94: 8a0a0108    	and	x8, x8, x10
101436a98: cb08153c    	sub	x28, x9, x8, lsl #5
101436a9c: f85f0388    	ldur	x8, [x28, #-0x10]
101436aa0: eb0802df    	cmp	x22, x8
101436aa4: 540000c1    	b.ne	0x101436abc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2e50>
101436aa8: f85e8381    	ldur	x1, [x28, #-0x18]
101436aac: aa1a03e0    	mov	x0, x26
101436ab0: aa1603e2    	mov	x2, x22
101436ab4: 941a4c5a    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101436ab8: 340001c0    	cbz	w0, 0x101436af0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2e84>
101436abc: d1000708    	sub	x8, x24, #0x1
101436ac0: ea180118    	ands	x24, x8, x24
101436ac4: f9403ffc    	ldr	x28, [sp, #0x78]
101436ac8: f94047e9    	ldr	x9, [sp, #0x88]
101436acc: 54fffdc1    	b.ne	0x101436a84 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2e18>
101436ad0: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
101436ad4: 2e208d20    	cmeq.8b	v0, v9, v0
101436ad8: 2e30a800    	umaxv.8b	b0, v0
101436adc: 1e260008    	fmov	w8, s0
101436ae0: 37000188    	tbnz	w8, #0x0, 0x101436b10 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2ea4>
101436ae4: 91002129    	add	x9, x9, #0x8
101436ae8: 8b0902e0    	add	x0, x23, x9
101436aec: 17ffffde    	b	0x101436a64 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2df8>
101436af0: fc5f8388    	ldur	d8, [x28, #-0x8]
101436af4: 5280002e    	mov	w14, #0x1               ; =1
101436af8: f9403ffc    	ldr	x28, [sp, #0x78]
101436afc: 14000006    	b	0x101436b14 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2ea8>
101436b00: 5280000e    	mov	w14, #0x0               ; =0
101436b04: f941cffa    	ldr	x26, [sp, #0x398]
101436b08: f941d3f6    	ldr	x22, [sp, #0x3a0]
101436b0c: 14000002    	b	0x101436b14 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2ea8>
101436b10: 5280000e    	mov	w14, #0x0               ; =0
101436b14: b4000596    	cbz	x22, 0x101436bc4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2f58>
101436b18: 8b160348    	add	x8, x26, x22
101436b1c: aa0803e9    	mov	x9, x8
101436b20: 14000004    	b	0x101436b30 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2ec4>
101436b24: aa0903e8    	mov	x8, x9
101436b28: eb09035f    	cmp	x26, x9
101436b2c: 540004c0    	b.eq	0x101436bc4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2f58>
101436b30: 38dffd2a    	ldrsb	w10, [x9, #-0x1]!
101436b34: 37f800ca    	tbnz	w10, #0x1f, 0x101436b4c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2ee0>
101436b38: 7101715f    	cmp	w10, #0x5c
101436b3c: 54ffff40    	b.eq	0x101436b24 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2eb8>
101436b40: 7100bd5f    	cmp	w10, #0x2f
101436b44: 54ffff00    	b.eq	0x101436b24 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2eb8>
101436b48: 1400001e    	b	0x101436bc0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2f54>
101436b4c: aa0803e9    	mov	x9, x8
101436b50: 38dfed2b    	ldrsb	w11, [x9, #-0x2]!
101436b54: 3101017f    	cmn	w11, #0x40
101436b58: 5400016a    	b.ge	0x101436b84 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2f18>
101436b5c: aa0803e9    	mov	x9, x8
101436b60: 38dfdd2c    	ldrsb	w12, [x9, #-0x3]!
101436b64: 3101019f    	cmn	w12, #0x40
101436b68: 540001aa    	b.ge	0x101436b9c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2f30>
101436b6c: 12001d8c    	and	w12, w12, #0xff
101436b70: aa0803e9    	mov	x9, x8
101436b74: 385fcd2d    	ldrb	w13, [x9, #-0x4]!
101436b78: 1200158c    	and	w12, w12, #0x3f
101436b7c: 331a09ac    	bfi	w12, w13, #6, #3
101436b80: 14000008    	b	0x101436ba0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2f34>
101436b84: 1200116b    	and	w11, w11, #0x1f
101436b88: 1200154a    	and	w10, w10, #0x3f
101436b8c: 2a0b194a    	orr	w10, w10, w11, lsl #6
101436b90: 7101715f    	cmp	w10, #0x5c
101436b94: 54fffd61    	b.ne	0x101436b40 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2ed4>
101436b98: 17ffffe3    	b	0x101436b24 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2eb8>
101436b9c: 12000d8c    	and	w12, w12, #0xf
101436ba0: 12001d6b    	and	w11, w11, #0xff
101436ba4: 1200156b    	and	w11, w11, #0x3f
101436ba8: 2a0c196b    	orr	w11, w11, w12, lsl #6
101436bac: 1200154a    	and	w10, w10, #0x3f
101436bb0: 2a0b194a    	orr	w10, w10, w11, lsl #6
101436bb4: 7101715f    	cmp	w10, #0x5c
101436bb8: 54fffc41    	b.ne	0x101436b40 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2ed4>
101436bbc: 17ffffda    	b	0x101436b24 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2eb8>
101436bc0: cb1a0116    	sub	x22, x8, x26
101436bc4: f9405be8    	ldr	x8, [sp, #0xb0]
101436bc8: b4000608    	cbz	x8, 0x101436c88 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x301c>
101436bcc: b9008bee    	str	w14, [sp, #0x88]
101436bd0: a94903e1    	ldp	x1, x0, [sp, #0x90]
101436bd4: aa1a03e2    	mov	x2, x26
101436bd8: aa1603e3    	mov	x3, x22
101436bdc: 97d45a98    	bl	0x10094d63c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a614>
101436be0: d2800009    	mov	x9, #0x0                ; =0
101436be4: d379fc08    	lsr	x8, x0, #57
101436be8: 0e010d09    	dup.8b	v9, w8
101436bec: a94babe8    	ldp	x8, x10, [sp, #0xb8]
101436bf0: 8a0a0017    	and	x23, x0, x10
101436bf4: fc77690a    	ldr	d10, [x8, x23]
101436bf8: 2e298d40    	cmeq.8b	v0, v10, v9
101436bfc: 9e660008    	fmov	x8, d0
101436c00: f201c118    	ands	x24, x8, #0x8080808080808080
101436c04: 540002a0    	b.eq	0x101436c58 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2fec>
101436c08: f90033e9    	str	x9, [sp, #0x60]
101436c0c: dac00308    	rbit	x8, x24
101436c10: dac01108    	clz	x8, x8
101436c14: 8b480ee8    	add	x8, x23, x8, lsr #3
101436c18: a94babe9    	ldp	x9, x10, [sp, #0xb8]
101436c1c: 8a0a0108    	and	x8, x8, x10
101436c20: cb08153c    	sub	x28, x9, x8, lsl #5
101436c24: f85f0388    	ldur	x8, [x28, #-0x10]
101436c28: eb0802df    	cmp	x22, x8
101436c2c: 540000c1    	b.ne	0x101436c44 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2fd8>
101436c30: f85e8381    	ldur	x1, [x28, #-0x18]
101436c34: aa1a03e0    	mov	x0, x26
101436c38: aa1603e2    	mov	x2, x22
101436c3c: 941a4bf8    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101436c40: 340001c0    	cbz	w0, 0x101436c78 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x300c>
101436c44: d1000708    	sub	x8, x24, #0x1
101436c48: ea180118    	ands	x24, x8, x24
101436c4c: f9403ffc    	ldr	x28, [sp, #0x78]
101436c50: f94033e9    	ldr	x9, [sp, #0x60]
101436c54: 54fffdc1    	b.ne	0x101436c0c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2fa0>
101436c58: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
101436c5c: 2e208d40    	cmeq.8b	v0, v10, v0
101436c60: 2e30a800    	umaxv.8b	b0, v0
101436c64: 1e260008    	fmov	w8, s0
101436c68: 37000128    	tbnz	w8, #0x0, 0x101436c8c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3020>
101436c6c: 91002129    	add	x9, x9, #0x8
101436c70: 8b0902e0    	add	x0, x23, x9
101436c74: 17ffffde    	b	0x101436bec <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2f80>
101436c78: fc5f8380    	ldur	d0, [x28, #-0x8]
101436c7c: 52800028    	mov	w8, #0x1                ; =1
101436c80: f9403ffc    	ldr	x28, [sp, #0x78]
101436c84: 14000003    	b	0x101436c90 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3024>
101436c88: 14000003    	b	0x101436c94 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3028>
101436c8c: d2800008    	mov	x8, #0x0                ; =0
101436c90: b9408bee    	ldr	w14, [sp, #0x88]
101436c94: f94077eb    	ldr	x11, [sp, #0xe8]
101436c98: 3707e7ce    	tbnz	w14, #0x0, 0x101436990 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2d24>
101436c9c: d2800009    	mov	x9, #0x0                ; =0
101436ca0: d280000a    	mov	x10, #0x0               ; =0
101436ca4: 1e604008    	fmov	d8, d0
101436ca8: b5ffe768    	cbnz	x8, 0x101436994 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2d28>
101436cac: 17ffff3e    	b	0x1014369a4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2d38>
101436cb0: a9432beb    	ldp	x11, x10, [sp, #0x30]
101436cb4: 17fffb43    	b	0x1014359c0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1d54>
101436cb8: 910683f3    	add	x19, sp, #0x1a0
101436cbc: 910683e8    	add	x8, sp, #0x1a0
101436cc0: aa1a03e0    	mov	x0, x26
101436cc4: aa1703e1    	mov	x1, x23
101436cc8: 940f529b    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
101436ccc: a94a2728    	ldp	x8, x9, [x25, #0xa0]
101436cd0: 52801c0a    	mov	w10, #0xe0              ; =224
101436cd4: 9b0a2129    	madd	x9, x9, x10, x8
101436cd8: a91727e8    	stp	x8, x9, [sp, #0x170]
101436cdc: f900c3f3    	str	x19, [sp, #0x180]
101436ce0: 910c83e0    	add	x0, sp, #0x320
101436ce4: 9105c3e1    	add	x1, sp, #0x170
101436ce8: 97ff5c81    	bl	0x10140deec <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2ba0>
101436cec: f94193e8    	ldr	x8, [sp, #0x320]
101436cf0: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101436cf4: eb09011f    	cmp	x8, x9
101436cf8: 54000a61    	b.ne	0x101436e44 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x31d8>
101436cfc: d2800014    	mov	x20, #0x0               ; =0
101436d00: d2800016    	mov	x22, #0x0               ; =0
101436d04: 52800113    	mov	w19, #0x8               ; =8
101436d08: 14000088    	b	0x101436f28 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x32bc>
101436d0c: aa0b03f3    	mov	x19, x11
101436d10: 17fffb2c    	b	0x1014359c0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1d54>
101436d14: d2800018    	mov	x24, #0x0               ; =0
101436d18: 52800115    	mov	w21, #0x8               ; =8
101436d1c: f9014bff    	str	xzr, [sp, #0x290]
101436d20: f9014ff5    	str	x21, [sp, #0x298]
101436d24: f90153ff    	str	xzr, [sp, #0x2a0]
101436d28: 52800037    	mov	w23, #0x1               ; =1
101436d2c: 5280011c    	mov	w28, #0x8               ; =8
101436d30: 14000415    	b	0x101437d84 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4118>
101436d34: f94043e8    	ldr	x8, [sp, #0x80]
101436d38: eb15011f    	cmp	x8, x21
101436d3c: 54000180    	b.eq	0x101436d6c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3100>
101436d40: d289d8a8    	mov	x8, #0x4ec5             ; =20165
101436d44: f2b89d88    	movk	x8, #0xc4ec, lsl #16
101436d48: f2dd89c8    	movk	x8, #0xec4e, lsl #32
101436d4c: f2e9d888    	movk	x8, #0x4ec4, lsl #48
101436d50: 9bc87e88    	umulh	x8, x20, x8
101436d54: d345fd14    	lsr	x20, x8, #5
101436d58: aa1303e0    	mov	x0, x19
101436d5c: 97db1a5f    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101436d60: 9101a273    	add	x19, x19, #0x68
101436d64: f1000694    	subs	x20, x20, #0x1
101436d68: 54ffff81    	b.ne	0x101436d58 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x30ec>
101436d6c: f9014bf9    	str	x25, [sp, #0x290]
101436d70: f9014ffc    	str	x28, [sp, #0x298]
101436d74: f94077f8    	ldr	x24, [sp, #0xe8]
101436d78: f90153f8    	str	x24, [sp, #0x2a0]
101436d7c: f1000b1f    	cmp	x24, #0x2
101436d80: 5400c0a2    	b.hs	0x101438594 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4928>
101436d84: 52800f08    	mov	w8, #0x78               ; =120
101436d88: 9b087315    	madd	x21, x24, x8, x28
101436d8c: b4007c98    	cbz	x24, 0x101437d1c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x40b0>
101436d90: aa1c03f6    	mov	x22, x28
101436d94: b84786c8    	ldr	w8, [x22], #0x78
101436d98: 37000068    	tbnz	w8, #0x0, 0x101436da4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3138>
101436d9c: eb1502df    	cmp	x22, x21
101436da0: 54ffffa1    	b.ne	0x101436d94 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3128>
101436da4: 36007ee8    	tbz	w8, #0x0, 0x101437d80 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4114>
101436da8: fc5902c8    	ldur	d8, [x22, #-0x70]
101436dac: 97d99e51    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101436db0: 52800400    	mov	w0, #0x20               ; =32
101436db4: 52800101    	mov	w1, #0x8                ; =8
101436db8: 97d99e48    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101436dbc: b400cb20    	cbz	x0, 0x101438720 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ab4>
101436dc0: aa0003f4    	mov	x20, x0
101436dc4: fd000008    	str	d8, [x0]
101436dc8: 52800088    	mov	w8, #0x4                ; =4
101436dcc: f901cbe8    	str	x8, [sp, #0x390]
101436dd0: f901cfe0    	str	x0, [sp, #0x398]
101436dd4: 52800028    	mov	w8, #0x1                ; =1
101436dd8: f901d3e8    	str	x8, [sp, #0x3a0]
101436ddc: eb1502df    	cmp	x22, x21
101436de0: 540094c0    	b.eq	0x101438078 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x440c>
101436de4: 52800033    	mov	w19, #0x1               ; =1
101436de8: 14000006    	b	0x101436e00 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3194>
101436dec: fc337a88    	str	d8, [x20, x19, lsl #3]
101436df0: 91000673    	add	x19, x19, #0x1
101436df4: f901d3f3    	str	x19, [sp, #0x3a0]
101436df8: eb1502df    	cmp	x22, x21
101436dfc: 54009540    	b.eq	0x1014380a4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4438>
101436e00: b84786c8    	ldr	w8, [x22], #0x78
101436e04: 37000068    	tbnz	w8, #0x0, 0x101436e10 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x31a4>
101436e08: eb1502df    	cmp	x22, x21
101436e0c: 54ffffa1    	b.ne	0x101436e00 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3194>
101436e10: 360093c8    	tbz	w8, #0x0, 0x101438088 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x441c>
101436e14: fc5902c8    	ldur	d8, [x22, #-0x70]
101436e18: f941cbe8    	ldr	x8, [sp, #0x390]
101436e1c: eb08027f    	cmp	x19, x8
101436e20: 54fffe61    	b.ne	0x101436dec <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3180>
101436e24: 910e43e0    	add	x0, sp, #0x390
101436e28: aa1303e1    	mov	x1, x19
101436e2c: 52800022    	mov	w2, #0x1                ; =1
101436e30: 52800103    	mov	w3, #0x8                ; =8
101436e34: 52800104    	mov	w4, #0x8                ; =8
101436e38: 9417c686    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101436e3c: f941cff4    	ldr	x20, [sp, #0x398]
101436e40: 17ffffeb    	b	0x101436dec <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3180>
101436e44: 97d99e2b    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101436e48: 52803400    	mov	w0, #0x1a0              ; =416
101436e4c: 52800101    	mov	w1, #0x8                ; =8
101436e50: 97d99e22    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101436e54: b400c540    	cbz	x0, 0x1014386fc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4a90>
101436e58: aa0003f3    	mov	x19, x0
101436e5c: ad5b07e0    	ldp	q0, q1, [sp, #0x360]
101436e60: ad020400    	stp	q0, q1, [x0, #0x40]
101436e64: f941c3e8    	ldr	x8, [sp, #0x380]
101436e68: f9003008    	str	x8, [x0, #0x60]
101436e6c: ad5907e0    	ldp	q0, q1, [sp, #0x320]
101436e70: ad000400    	stp	q0, q1, [x0]
101436e74: ad5a03e1    	ldp	q1, q0, [sp, #0x340]
101436e78: ad010001    	stp	q1, q0, [x0, #0x20]
101436e7c: 52800088    	mov	w8, #0x4                ; =4
101436e80: a91e83e8    	stp	x8, x0, [sp, #0x1e8]
101436e84: 52800034    	mov	w20, #0x1               ; =1
101436e88: f900fff4    	str	x20, [sp, #0x1f8]
101436e8c: 3dc05fe0    	ldr	q0, [sp, #0x170]
101436e90: f940c3e8    	ldr	x8, [sp, #0x180]
101436e94: f90123e8    	str	x8, [sp, #0x240]
101436e98: 52800d15    	mov	w21, #0x68              ; =104
101436e9c: d2f00016    	mov	x22, #-0x8000000000000000 ; =-9223372036854775808
101436ea0: 3d808fe0    	str	q0, [sp, #0x230]
101436ea4: 14000010    	b	0x101436ee4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3278>
101436ea8: f940fbf3    	ldr	x19, [sp, #0x1f0]
101436eac: 8b150268    	add	x8, x19, x21
101436eb0: ad5c87e0    	ldp	q0, q1, [sp, #0x390]
101436eb4: 3dc0efe2    	ldr	q2, [sp, #0x3b0]
101436eb8: ad008901    	stp	q1, q2, [x8, #0x10]
101436ebc: 3d800100    	str	q0, [x8]
101436ec0: ad5e07e0    	ldp	q0, q1, [sp, #0x3c0]
101436ec4: 3dc0fbe2    	ldr	q2, [sp, #0x3e0]
101436ec8: f941fbe9    	ldr	x9, [sp, #0x3f0]
101436ecc: f9003109    	str	x9, [x8, #0x60]
101436ed0: ad020901    	stp	q1, q2, [x8, #0x40]
101436ed4: 3d800d00    	str	q0, [x8, #0x30]
101436ed8: 91000694    	add	x20, x20, #0x1
101436edc: f900fff4    	str	x20, [sp, #0x1f8]
101436ee0: 9101a2b5    	add	x21, x21, #0x68
101436ee4: 910e43e0    	add	x0, sp, #0x390
101436ee8: 9108c3e1    	add	x1, sp, #0x230
101436eec: 97ff5c00    	bl	0x10140deec <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2ba0>
101436ef0: f941cbe8    	ldr	x8, [sp, #0x390]
101436ef4: eb16011f    	cmp	x8, x22
101436ef8: 54000160    	b.eq	0x101436f24 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x32b8>
101436efc: f940f7e8    	ldr	x8, [sp, #0x1e8]
101436f00: eb08029f    	cmp	x20, x8
101436f04: 54fffd41    	b.ne	0x101436eac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3240>
101436f08: 9107a3e0    	add	x0, sp, #0x1e8
101436f0c: aa1403e1    	mov	x1, x20
101436f10: 52800022    	mov	w2, #0x1                ; =1
101436f14: 52800103    	mov	w3, #0x8                ; =8
101436f18: 52800d04    	mov	w4, #0x68               ; =104
101436f1c: 9417c64d    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101436f20: 17ffffe2    	b	0x101436ea8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x323c>
101436f24: f940f7f6    	ldr	x22, [sp, #0x1e8]
101436f28: f940d3e1    	ldr	x1, [sp, #0x1a0]
101436f2c: b4000081    	cbz	x1, 0x101436f3c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x32d0>
101436f30: f940d7e0    	ldr	x0, [sp, #0x1a8]
101436f34: 52800022    	mov	w2, #0x1                ; =1
101436f38: 97d99de9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101436f3c: 52800d08    	mov	w8, #0x68               ; =104
101436f40: 9b087e95    	mul	x21, x20, x8
101436f44: f901cbf3    	str	x19, [sp, #0x390]
101436f48: f901cff3    	str	x19, [sp, #0x398]
101436f4c: 8b150268    	add	x8, x19, x21
101436f50: f901d3f6    	str	x22, [sp, #0x3a0]
101436f54: f901d7e8    	str	x8, [sp, #0x3a8]
101436f58: b500aeb4    	cbnz	x20, 0x10143852c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x48c0>
101436f5c: d2800017    	mov	x23, #0x0               ; =0
101436f60: 52800108    	mov	w8, #0x8                ; =8
101436f64: 52800d09    	mov	w9, #0x68               ; =104
101436f68: 9b0922e0    	madd	x0, x23, x9, x8
101436f6c: aa1303e1    	mov	x1, x19
101436f70: aa1503e2    	mov	x2, x21
101436f74: 941a4b2d    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101436f78: 8b1402e8    	add	x8, x23, x20
101436f7c: f9018be8    	str	x8, [sp, #0x310]
101436f80: b40000f6    	cbz	x22, 0x101436f9c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3330>
101436f84: 52800d08    	mov	w8, #0x68               ; =104
101436f88: 9b087ec1    	mul	x1, x22, x8
101436f8c: aa1303e0    	mov	x0, x19
101436f90: 52800102    	mov	w2, #0x8                ; =8
101436f94: 97d99dd2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101436f98: f94177fa    	ldr	x26, [sp, #0x2e8]
101436f9c: f9417bf7    	ldr	x23, [sp, #0x2f0]
101436fa0: f9400333    	ldr	x19, [x25]
101436fa4: f100127f    	cmp	x19, #0x4
101436fa8: f9004bf7    	str	x23, [sp, #0x90]
101436fac: 540000c1    	b.ne	0x101436fc4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3358>
101436fb0: aa1a03f7    	mov	x23, x26
101436fb4: d2800018    	mov	x24, #0x0               ; =0
101436fb8: d2800013    	mov	x19, #0x0               ; =0
101436fbc: 52800109    	mov	w9, #0x8                ; =8
101436fc0: 140000c1    	b	0x1014372c4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3658>
101436fc4: 9105c3e8    	add	x8, sp, #0x170
101436fc8: aa1a03e0    	mov	x0, x26
101436fcc: aa1703e1    	mov	x1, x23
101436fd0: 940f51d9    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
101436fd4: f90033fa    	str	x26, [sp, #0x60]
101436fd8: d2800018    	mov	x24, #0x0               ; =0
101436fdc: 52800108    	mov	w8, #0x8                ; =8
101436fe0: a91ea3ff    	stp	xzr, x8, [sp, #0x1e8]
101436fe4: f900ffff    	str	xzr, [sp, #0x1f8]
101436fe8: a9412728    	ldp	x8, x9, [x25, #0x10]
101436fec: f1000e7f    	cmp	x19, #0x3
101436ff0: 9a990116    	csel	x22, x8, x25, eq
101436ff4: 9a9f0528    	csinc	x8, x9, xzr, eq
101436ff8: 52800d09    	mov	w9, #0x68               ; =104
101436ffc: 9b095913    	madd	x19, x8, x9, x22
101437000: d2f00015    	mov	x21, #-0x8000000000000000 ; =-9223372036854775808
101437004: a957ebe8    	ldp	x8, x26, [sp, #0x178]
101437008: f90053e8    	str	x8, [sp, #0xa0]
10143700c: 52800108    	mov	w8, #0x8                ; =8
101437010: f90047e8    	str	x8, [sp, #0x88]
101437014: 9101a2d6    	add	x22, x22, #0x68
101437018: d101a2c8    	sub	x8, x22, #0x68
10143701c: eb13011f    	cmp	x8, x19
101437020: 54001420    	b.eq	0x1014372a4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3638>
101437024: f9402908    	ldr	x8, [x8, #0x50]
101437028: eb15011f    	cmp	x8, x21
10143702c: 54ffff40    	b.eq	0x101437014 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x33a8>
101437030: f85f82c8    	ldur	x8, [x22, #-0x8]
101437034: b4ffff08    	cbz	x8, 0x101437014 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x33a8>
101437038: f85f02d4    	ldur	x20, [x22, #-0x10]
10143703c: 52800609    	mov	w9, #0x30               ; =48
101437040: 9b095108    	madd	x8, x8, x9, x20
101437044: f90057e8    	str	x8, [sp, #0xa8]
101437048: 9100c288    	add	x8, x20, #0x30
10143704c: 14000018    	b	0x1014370ac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3440>
101437050: f940fbe8    	ldr	x8, [sp, #0x1f0]
101437054: f90047e8    	str	x8, [sp, #0x88]
101437058: f94047e8    	ldr	x8, [sp, #0x88]
10143705c: 52800d09    	mov	w9, #0x68               ; =104
101437060: 9b092308    	madd	x8, x24, x9, x8
101437064: ad5c87e0    	ldp	q0, q1, [sp, #0x390]
101437068: 3dc0efe2    	ldr	q2, [sp, #0x3b0]
10143706c: ad008901    	stp	q1, q2, [x8, #0x10]
101437070: 3d800100    	str	q0, [x8]
101437074: ad5e07e0    	ldp	q0, q1, [sp, #0x3c0]
101437078: 3dc0fbe2    	ldr	q2, [sp, #0x3e0]
10143707c: f941fbe9    	ldr	x9, [sp, #0x3f0]
101437080: f9003109    	str	x9, [x8, #0x60]
101437084: ad020901    	stp	q1, q2, [x8, #0x40]
101437088: 3d800d00    	str	q0, [x8, #0x30]
10143708c: 91000718    	add	x24, x24, #0x1
101437090: f900fff8    	str	x24, [sp, #0x1f8]
101437094: f94057e8    	ldr	x8, [sp, #0xa8]
101437098: eb08029f    	cmp	x20, x8
10143709c: 52800608    	mov	w8, #0x30               ; =48
1014370a0: 9a8803e8    	csel	x8, xzr, x8, eq
1014370a4: 8b080288    	add	x8, x20, x8
1014370a8: 54fffb60    	b.eq	0x101437014 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x33a8>
1014370ac: f90043f8    	str	x24, [sp, #0x80]
1014370b0: b40004da    	cbz	x26, 0x101437148 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x34dc>
1014370b4: aa1403f8    	mov	x24, x20
1014370b8: 14000007    	b	0x1014370d4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3468>
1014370bc: 9100c288    	add	x8, x20, #0x30
1014370c0: aa1403f8    	mov	x24, x20
1014370c4: f94057e9    	ldr	x9, [sp, #0xa8]
1014370c8: eb09029f    	cmp	x20, x9
1014370cc: d2f00015    	mov	x21, #-0x8000000000000000 ; =-9223372036854775808
1014370d0: 54000e40    	b.eq	0x101437298 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x362c>
1014370d4: aa0803f4    	mov	x20, x8
1014370d8: f9400308    	ldr	x8, [x24]
1014370dc: eb15011f    	cmp	x8, x21
1014370e0: 5280020a    	mov	w10, #0x10              ; =16
1014370e4: 52800308    	mov	w8, #0x18               ; =24
1014370e8: 9a8a0108    	csel	x8, x8, x10, eq
1014370ec: 52800109    	mov	w9, #0x8                ; =8
1014370f0: 9a890149    	csel	x9, x10, x9, eq
1014370f4: f8696b15    	ldr	x21, [x24, x9]
1014370f8: f8686b1b    	ldr	x27, [x24, x8]
1014370fc: 910e43e8    	add	x8, sp, #0x390
101437100: aa1503e0    	mov	x0, x21
101437104: aa1b03e1    	mov	x1, x27
101437108: 940f518b    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
10143710c: f941cff7    	ldr	x23, [sp, #0x398]
101437110: f941d3e8    	ldr	x8, [sp, #0x3a0]
101437114: eb1a011f    	cmp	x8, x26
101437118: 540000c3    	b.lo	0x101437130 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x34c4>
10143711c: f94053e0    	ldr	x0, [sp, #0xa0]
101437120: aa1703e1    	mov	x1, x23
101437124: aa1a03e2    	mov	x2, x26
101437128: 941a4abd    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10143712c: 34000260    	cbz	w0, 0x101437178 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x350c>
101437130: f941cbe1    	ldr	x1, [sp, #0x390]
101437134: b4fffc41    	cbz	x1, 0x1014370bc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3450>
101437138: aa1703e0    	mov	x0, x23
10143713c: 52800022    	mov	w2, #0x1                ; =1
101437140: 97d99d67    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437144: 17ffffde    	b	0x1014370bc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3450>
101437148: f9400289    	ldr	x9, [x20]
10143714c: eb15013f    	cmp	x9, x21
101437150: 5280020b    	mov	w11, #0x10              ; =16
101437154: 52800309    	mov	w9, #0x18               ; =24
101437158: 9a8b0129    	csel	x9, x9, x11, eq
10143715c: 5280010a    	mov	w10, #0x8               ; =8
101437160: 9a8a016a    	csel	x10, x11, x10, eq
101437164: f86a6a95    	ldr	x21, [x20, x10]
101437168: f8696a9b    	ldr	x27, [x20, x9]
10143716c: aa1403f8    	mov	x24, x20
101437170: aa0803f4    	mov	x20, x8
101437174: 14000006    	b	0x10143718c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3520>
101437178: f941cbe1    	ldr	x1, [sp, #0x390]
10143717c: b4000081    	cbz	x1, 0x10143718c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3520>
101437180: aa1703e0    	mov	x0, x23
101437184: 52800022    	mov	w2, #0x1                ; =1
101437188: 97d99d55    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143718c: b400011b    	cbz	x27, 0x1014371ac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3540>
101437190: 97d99d58    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101437194: aa1b03e0    	mov	x0, x27
101437198: 52800021    	mov	w1, #0x1                ; =1
10143719c: 97d99d4f    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014371a0: aa0003f7    	mov	x23, x0
1014371a4: b5000060    	cbnz	x0, 0x1014371b0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3544>
1014371a8: 1400054c    	b	0x1014386d8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4a6c>
1014371ac: 52800037    	mov	w23, #0x1               ; =1
1014371b0: aa1703e0    	mov	x0, x23
1014371b4: aa1503e1    	mov	x1, x21
1014371b8: aa1b03e2    	mov	x2, x27
1014371bc: 941a4a9b    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014371c0: f9400308    	ldr	x8, [x24]
1014371c4: d2f00015    	mov	x21, #-0x8000000000000000 ; =-9223372036854775808
1014371c8: eb15011f    	cmp	x8, x21
1014371cc: 54000080    	b.eq	0x1014371dc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3570>
1014371d0: f9400f08    	ldr	x8, [x24, #0x18]
1014371d4: eb15011f    	cmp	x8, x21
1014371d8: 54000061    	b.ne	0x1014371e4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3578>
1014371dc: f94043f8    	ldr	x24, [sp, #0x80]
1014371e0: 14000012    	b	0x101437228 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x35bc>
1014371e4: a9425701    	ldp	x1, x21, [x24, #0x20]
1014371e8: b4000155    	cbz	x21, 0x101437210 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x35a4>
1014371ec: aa0103f8    	mov	x24, x1
1014371f0: 97d99d40    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014371f4: aa1503e0    	mov	x0, x21
1014371f8: 52800021    	mov	w1, #0x1                ; =1
1014371fc: 97d99d37    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101437200: aa1803e1    	mov	x1, x24
101437204: f94043f8    	ldr	x24, [sp, #0x80]
101437208: b5000080    	cbnz	x0, 0x101437218 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x35ac>
10143720c: 14000549    	b	0x101438730 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ac4>
101437210: 52800020    	mov	w0, #0x1                ; =1
101437214: f94043f8    	ldr	x24, [sp, #0x80]
101437218: f9002fe0    	str	x0, [sp, #0x58]
10143721c: aa1503e2    	mov	x2, x21
101437220: 941a4a82    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101437224: f9002bf5    	str	x21, [sp, #0x50]
101437228: f9011bfb    	str	x27, [sp, #0x230]
10143722c: f9011ff7    	str	x23, [sp, #0x238]
101437230: f90123fb    	str	x27, [sp, #0x240]
101437234: 910c83e8    	add	x8, sp, #0x320
101437238: 9108c3e0    	add	x0, sp, #0x230
10143723c: 940f5fe4    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101437240: f901dbf7    	str	x23, [sp, #0x3b0]
101437244: f901dffb    	str	x27, [sp, #0x3b8]
101437248: 3dc0cbe0    	ldr	q0, [sp, #0x320]
10143724c: f9419be8    	ldr	x8, [sp, #0x330]
101437250: 3d80e7e0    	str	q0, [sp, #0x390]
101437254: f901d7fb    	str	x27, [sp, #0x3a8]
101437258: f901d3e8    	str	x8, [sp, #0x3a0]
10143725c: f901e3f5    	str	x21, [sp, #0x3c0]
101437260: a94527e8    	ldp	x8, x9, [sp, #0x50]
101437264: f901e7e9    	str	x9, [sp, #0x3c8]
101437268: f901ebe8    	str	x8, [sp, #0x3d0]
10143726c: d2f00015    	mov	x21, #-0x8000000000000000 ; =-9223372036854775808
101437270: f901eff5    	str	x21, [sp, #0x3d8]
101437274: 52804008    	mov	w8, #0x200              ; =512
101437278: 7907e3e8    	strh	w8, [sp, #0x3f0]
10143727c: f940f7e8    	ldr	x8, [sp, #0x1e8]
101437280: eb08031f    	cmp	x24, x8
101437284: f9406bfb    	ldr	x27, [sp, #0xd0]
101437288: 54ffee81    	b.ne	0x101437058 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x33ec>
10143728c: 9107a3e0    	add	x0, sp, #0x1e8
101437290: 94196315    	bl	0x101a8fee4 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h79ba5ff6649e4cf8E>
101437294: 17ffff6f    	b	0x101437050 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x33e4>
101437298: f9406bfb    	ldr	x27, [sp, #0xd0]
10143729c: f94043f8    	ldr	x24, [sp, #0x80]
1014372a0: 17ffff5d    	b	0x101437014 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x33a8>
1014372a4: f940f7f3    	ldr	x19, [sp, #0x1e8]
1014372a8: f940bbe1    	ldr	x1, [sp, #0x170]
1014372ac: b4000081    	cbz	x1, 0x1014372bc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3650>
1014372b0: f94053e0    	ldr	x0, [sp, #0xa0]
1014372b4: 52800022    	mov	w2, #0x1                ; =1
1014372b8: 97d99d09    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014372bc: f94033f7    	ldr	x23, [sp, #0x60]
1014372c0: f94047e9    	ldr	x9, [sp, #0x88]
1014372c4: 52800d08    	mov	w8, #0x68               ; =104
1014372c8: 9b087f15    	mul	x21, x24, x8
1014372cc: 8b150128    	add	x8, x9, x21
1014372d0: f901cbe9    	str	x9, [sp, #0x390]
1014372d4: aa0903fa    	mov	x26, x9
1014372d8: f901cfe9    	str	x9, [sp, #0x398]
1014372dc: f901d3f3    	str	x19, [sp, #0x3a0]
1014372e0: f901d7e8    	str	x8, [sp, #0x3a8]
1014372e4: f9418bf6    	ldr	x22, [sp, #0x310]
1014372e8: f94183e8    	ldr	x8, [sp, #0x300]
1014372ec: cb160108    	sub	x8, x8, x22
1014372f0: eb08031f    	cmp	x24, x8
1014372f4: 54008cc8    	b.hi	0x10143848c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4820>
1014372f8: f94187e8    	ldr	x8, [sp, #0x308]
1014372fc: 52800d09    	mov	w9, #0x68               ; =104
101437300: 9b0922c0    	madd	x0, x22, x9, x8
101437304: aa1a03e1    	mov	x1, x26
101437308: aa1503e2    	mov	x2, x21
10143730c: 941a4a47    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101437310: 8b1802d4    	add	x20, x22, x24
101437314: f9018bf4    	str	x20, [sp, #0x310]
101437318: b40000d3    	cbz	x19, 0x101437330 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x36c4>
10143731c: 52800d08    	mov	w8, #0x68               ; =104
101437320: 9b087e61    	mul	x1, x19, x8
101437324: aa1a03e0    	mov	x0, x26
101437328: 52800102    	mov	w2, #0x8                ; =8
10143732c: 97d99cec    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437330: f9414fe4    	ldr	x4, [sp, #0x298]
101437334: f94153e5    	ldr	x5, [sp, #0x2a0]
101437338: 910c83e0    	add	x0, sp, #0x320
10143733c: aa1703e1    	mov	x1, x23
101437340: f9404be2    	ldr	x2, [sp, #0x90]
101437344: aa1903e3    	mov	x3, x25
101437348: f90057e4    	str	x4, [sp, #0xa8]
10143734c: 97ffecbb    	bl	0x101432638 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x2d8>
101437350: f94193f8    	ldr	x24, [sp, #0x320]
101437354: f94197f5    	ldr	x21, [sp, #0x328]
101437358: f9419bf3    	ldr	x19, [sp, #0x330]
10143735c: 52800d08    	mov	w8, #0x68               ; =104
101437360: 9b087e76    	mul	x22, x19, x8
101437364: 8b1602a8    	add	x8, x21, x22
101437368: f901cbf5    	str	x21, [sp, #0x390]
10143736c: f901cff5    	str	x21, [sp, #0x398]
101437370: f901d3f8    	str	x24, [sp, #0x3a0]
101437374: f901d7e8    	str	x8, [sp, #0x3a8]
101437378: f94183e8    	ldr	x8, [sp, #0x300]
10143737c: cb140108    	sub	x8, x8, x20
101437380: eb08027f    	cmp	x19, x8
101437384: 540089a8    	b.hi	0x1014384b8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x484c>
101437388: f94187f7    	ldr	x23, [sp, #0x308]
10143738c: 52800d08    	mov	w8, #0x68               ; =104
101437390: 9b085e80    	madd	x0, x20, x8, x23
101437394: aa1503e1    	mov	x1, x21
101437398: aa1603e2    	mov	x2, x22
10143739c: 941a4a23    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014373a0: 8b130293    	add	x19, x20, x19
1014373a4: f9018bf3    	str	x19, [sp, #0x310]
1014373a8: b40000d8    	cbz	x24, 0x1014373c0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3754>
1014373ac: 52800d08    	mov	w8, #0x68               ; =104
1014373b0: 9b087f01    	mul	x1, x24, x8
1014373b4: aa1503e0    	mov	x0, x21
1014373b8: 52800102    	mov	w2, #0x8                ; =8
1014373bc: 97d99cc8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014373c0: f9406fe8    	ldr	x8, [sp, #0xd8]
1014373c4: b4000728    	cbz	x8, 0x1014374a8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x383c>
1014373c8: f9400328    	ldr	x8, [x25]
1014373cc: f100111f    	cmp	x8, #0x4
1014373d0: 540000a0    	b.eq	0x1014373e4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3778>
1014373d4: f1000d1f    	cmp	x8, #0x3
1014373d8: 54002a81    	b.ne	0x101437928 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3cbc>
1014373dc: a9412339    	ldp	x25, x8, [x25, #0x10]
1014373e0: 14000153    	b	0x10143792c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3cc0>
1014373e4: 52800018    	mov	w24, #0x0               ; =0
1014373e8: 5280001a    	mov	w26, #0x0               ; =0
1014373ec: 940e3c30    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
1014373f0: f94073e8    	ldr	x8, [sp, #0xe0]
1014373f4: eb08001f    	cmp	x0, x8
1014373f8: 540000a1    	b.ne	0x10143740c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x37a0>
1014373fc: b9407bee    	ldr	w14, [sp, #0x78]
101437400: 6b0e003f    	cmp	w1, w14
101437404: 54000083    	b.lo	0x101437414 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x37a8>
101437408: 14000026    	b	0x1014374a0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3834>
10143740c: eb08001f    	cmp	x0, x8
101437410: 5400048a    	b.ge	0x1014374a0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3834>
101437414: f94177e0    	ldr	x0, [sp, #0x2e8]
101437418: f9417be1    	ldr	x1, [sp, #0x2f0]
10143741c: 910c83e8    	add	x8, sp, #0x320
101437420: 12000344    	and	w4, w26, #0x1
101437424: 12000305    	and	w5, w24, #0x1
101437428: f9406fe2    	ldr	x2, [sp, #0xd8]
10143742c: f94067e3    	ldr	x3, [sp, #0xc8]
101437430: 94004713    	bl	0x10144907c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E>
101437434: f94193f9    	ldr	x25, [sp, #0x320]
101437438: f94197f4    	ldr	x20, [sp, #0x328]
10143743c: f9419bf5    	ldr	x21, [sp, #0x330]
101437440: 52800d08    	mov	w8, #0x68               ; =104
101437444: 9b087eb6    	mul	x22, x21, x8
101437448: 8b160288    	add	x8, x20, x22
10143744c: f901cbf4    	str	x20, [sp, #0x390]
101437450: f901cff4    	str	x20, [sp, #0x398]
101437454: f901d3f9    	str	x25, [sp, #0x3a0]
101437458: f901d7e8    	str	x8, [sp, #0x3a8]
10143745c: f94183e8    	ldr	x8, [sp, #0x300]
101437460: cb130108    	sub	x8, x8, x19
101437464: eb0802bf    	cmp	x21, x8
101437468: 54008be8    	b.hi	0x1014385e4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4978>
10143746c: 52800d08    	mov	w8, #0x68               ; =104
101437470: 9b085e60    	madd	x0, x19, x8, x23
101437474: aa1403e1    	mov	x1, x20
101437478: aa1603e2    	mov	x2, x22
10143747c: 941a49eb    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101437480: 8b150268    	add	x8, x19, x21
101437484: f9018be8    	str	x8, [sp, #0x310]
101437488: b40000d9    	cbz	x25, 0x1014374a0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3834>
10143748c: 52800d08    	mov	w8, #0x68               ; =104
101437490: 9b087f21    	mul	x1, x25, x8
101437494: aa1403e0    	mov	x0, x20
101437498: 52800102    	mov	w2, #0x8                ; =8
10143749c: 97d99c90    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014374a0: 0a180348    	and	w8, w26, w24
1014374a4: 36001548    	tbz	w8, #0x0, 0x10143774c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3ae0>
1014374a8: 940e3c01    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
1014374ac: f94073e9    	ldr	x9, [sp, #0xe0]
1014374b0: eb09001f    	cmp	x0, x9
1014374b4: 540000a1    	b.ne	0x1014374c8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x385c>
1014374b8: b9407be8    	ldr	w8, [sp, #0x78]
1014374bc: 6b08003f    	cmp	w1, w8
1014374c0: 54000083    	b.lo	0x1014374d0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3864>
1014374c4: 14000053    	b	0x101437610 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x39a4>
1014374c8: eb09001f    	cmp	x0, x9
1014374cc: 54000a2a    	b.ge	0x101437610 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x39a4>
1014374d0: f9415bf5    	ldr	x21, [sp, #0x2b0]
1014374d4: f9415ff6    	ldr	x22, [sp, #0x2b8]
1014374d8: f94177f3    	ldr	x19, [sp, #0x2e8]
1014374dc: aa0903e1    	mov	x1, x9
1014374e0: f9417bf4    	ldr	x20, [sp, #0x2f0]
1014374e4: f94077e8    	ldr	x8, [sp, #0xe8]
1014374e8: 910be100    	add	x0, x8, #0x2f8
1014374ec: b9407be2    	ldr	w2, [sp, #0x78]
1014374f0: 9400426f    	bl	0x101447eac <__ZN17otty_autocomplete7sources15PathExecutables3get17h2fb85cccc5c7b0a8E>
1014374f4: f900f7e0    	str	x0, [sp, #0x1e8]
1014374f8: f94077eb    	ldr	x11, [sp, #0xe8]
1014374fc: 91068168    	add	x8, x11, #0x1a0
101437500: f940d169    	ldr	x9, [x11, #0x1a0]
101437504: d2f0000a    	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
101437508: eb0a013f    	cmp	x9, x10
10143750c: 9a8803e8    	csel	x8, xzr, x8, eq
101437510: f9011be8    	str	x8, [sp, #0x230]
101437514: 910e2168    	add	x8, x11, #0x388
101437518: f901d3f5    	str	x21, [sp, #0x3a0]
10143751c: f901d7f6    	str	x22, [sp, #0x3a8]
101437520: f94063e9    	ldr	x9, [sp, #0xc0]
101437524: f901dbe9    	str	x9, [sp, #0x3b0]
101437528: f901dffc    	str	x28, [sp, #0x3b8]
10143752c: f901e3f3    	str	x19, [sp, #0x3c0]
101437530: f901e7f4    	str	x20, [sp, #0x3c8]
101437534: f9406fe9    	ldr	x9, [sp, #0xd8]
101437538: f901cbe9    	str	x9, [sp, #0x390]
10143753c: f94067e9    	ldr	x9, [sp, #0xc8]
101437540: f901cfe9    	str	x9, [sp, #0x398]
101437544: f94073e9    	ldr	x9, [sp, #0xe0]
101437548: f90203e9    	str	x9, [sp, #0x400]
10143754c: b9407be9    	ldr	w9, [sp, #0x78]
101437550: b9040be9    	str	w9, [sp, #0x408]
101437554: d0007189    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101437558: 910f4129    	add	x9, x9, #0x3d0
10143755c: 9107a3ea    	add	x10, sp, #0x1e8
101437560: f901ebea    	str	x10, [sp, #0x3d0]
101437564: f901efe9    	str	x9, [sp, #0x3d8]
101437568: 3dc00100    	ldr	q0, [x8]
10143756c: 3d80fbe0    	str	q0, [sp, #0x3e0]
101437570: 9108c3e8    	add	x8, sp, #0x230
101437574: d0007189    	adrp	x9, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
101437578: 91100129    	add	x9, x9, #0x400
10143757c: f901fbe8    	str	x8, [sp, #0x3f0]
101437580: f901ffe9    	str	x9, [sp, #0x3f8]
101437584: f941bd63    	ldr	x3, [x11, #0x378]
101437588: f941c164    	ldr	x4, [x11, #0x380]
10143758c: 910c83e8    	add	x8, sp, #0x320
101437590: 910e43e2    	add	x2, sp, #0x390
101437594: a94b07e0    	ldp	x0, x1, [sp, #0xb0]
101437598: 97ff5d0e    	bl	0x10140e9d0 <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE>
10143759c: f94193f7    	ldr	x23, [sp, #0x320]
1014375a0: f94197f3    	ldr	x19, [sp, #0x328]
1014375a4: f9419bf4    	ldr	x20, [sp, #0x330]
1014375a8: 52800d08    	mov	w8, #0x68               ; =104
1014375ac: 9b087e95    	mul	x21, x20, x8
1014375b0: 8b150268    	add	x8, x19, x21
1014375b4: f901cbf3    	str	x19, [sp, #0x390]
1014375b8: f901cff3    	str	x19, [sp, #0x398]
1014375bc: f901d3f7    	str	x23, [sp, #0x3a0]
1014375c0: f901d7e8    	str	x8, [sp, #0x3a8]
1014375c4: f9418bf6    	ldr	x22, [sp, #0x310]
1014375c8: f94183e8    	ldr	x8, [sp, #0x300]
1014375cc: cb160108    	sub	x8, x8, x22
1014375d0: eb08029f    	cmp	x20, x8
1014375d4: 54007848    	b.hi	0x1014384dc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4870>
1014375d8: f94187e8    	ldr	x8, [sp, #0x308]
1014375dc: 52800d09    	mov	w9, #0x68               ; =104
1014375e0: 9b0922c0    	madd	x0, x22, x9, x8
1014375e4: aa1303e1    	mov	x1, x19
1014375e8: aa1503e2    	mov	x2, x21
1014375ec: 941a498f    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014375f0: 8b1402c8    	add	x8, x22, x20
1014375f4: f9018be8    	str	x8, [sp, #0x310]
1014375f8: b40000d7    	cbz	x23, 0x101437610 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x39a4>
1014375fc: 52800d08    	mov	w8, #0x68               ; =104
101437600: 9b087ee1    	mul	x1, x23, x8
101437604: aa1303e0    	mov	x0, x19
101437608: 52800102    	mov	w2, #0x8                ; =8
10143760c: 97d99c34    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437610: 910c03e0    	add	x0, sp, #0x300
101437614: 97ffdcbe    	bl	0x10142e90c <__ZN17otty_autocomplete4item14dedupe_by_text17hfec778e0c02dfb24E>
101437618: f9418be8    	ldr	x8, [sp, #0x310]
10143761c: b40004c8    	cbz	x8, 0x1014376b4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3a48>
101437620: f9415bf6    	ldr	x22, [sp, #0x2b0]
101437624: f9415ff8    	ldr	x24, [sp, #0x2b8]
101437628: 910683e0    	add	x0, sp, #0x1a0
10143762c: a94b0be1    	ldp	x1, x2, [sp, #0xb0]
101437630: aa1603e3    	mov	x3, x22
101437634: aa1803e4    	mov	x4, x24
101437638: 97ffed33    	bl	0x101432b04 <__ZN17otty_autocomplete6engine12EngineConfig11from_config17h05d0a51b2e3e0e42E+0x7a4>
10143763c: f94183fb    	ldr	x27, [sp, #0x300]
101437640: f94187f4    	ldr	x20, [sp, #0x308]
101437644: f9418bfa    	ldr	x26, [sp, #0x310]
101437648: a95acff5    	ldp	x21, x19, [sp, #0x1a8]
10143764c: b4000cfa    	cbz	x26, 0x1014377e8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3b7c>
101437650: 8b1a0748    	add	x8, x26, x26, lsl #1
101437654: d37df119    	lsl	x25, x8, #3
101437658: 97d99c26    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10143765c: aa1903e0    	mov	x0, x25
101437660: 52800101    	mov	w1, #0x8                ; =8
101437664: 97d99c1d    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101437668: b40081e0    	cbz	x0, 0x1014386a4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4a38>
10143766c: aa0003f7    	mov	x23, x0
101437670: d280001c    	mov	x28, #0x0               ; =0
101437674: f90193fa    	str	x26, [sp, #0x320]
101437678: f90197e0    	str	x0, [sp, #0x328]
10143767c: aa1403f9    	mov	x25, x20
101437680: 910e43e8    	add	x8, sp, #0x390
101437684: aa1903e0    	mov	x0, x25
101437688: 940f5ed1    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10143768c: 3dc0e7e0    	ldr	q0, [sp, #0x390]
101437690: 3d8002e0    	str	q0, [x23]
101437694: f941d3e8    	ldr	x8, [sp, #0x3a0]
101437698: f9000ae8    	str	x8, [x23, #0x10]
10143769c: 9100079c    	add	x28, x28, #0x1
1014376a0: 910062f7    	add	x23, x23, #0x18
1014376a4: 9101a339    	add	x25, x25, #0x68
1014376a8: eb1c035f    	cmp	x26, x28
1014376ac: 54fffea1    	b.ne	0x101437680 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3a14>
1014376b0: 14000051    	b	0x1014377f4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3b88>
1014376b4: 3dc0c3e0    	ldr	q0, [sp, #0x300]
1014376b8: 3d800360    	str	q0, [x27]
1014376bc: f9418be8    	ldr	x8, [sp, #0x310]
1014376c0: f9000b68    	str	x8, [x27, #0x10]
1014376c4: f94173e1    	ldr	x1, [sp, #0x2e0]
1014376c8: b4000081    	cbz	x1, 0x1014376d8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3a6c>
1014376cc: f94177e0    	ldr	x0, [sp, #0x2e8]
1014376d0: 52800022    	mov	w2, #0x1                ; =1
1014376d4: 97d99c02    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014376d8: f9414be8    	ldr	x8, [sp, #0x290]
1014376dc: f9404ff6    	ldr	x22, [sp, #0x98]
1014376e0: b40000a8    	cbz	x8, 0x1014376f4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3a88>
1014376e4: d37df101    	lsl	x1, x8, #3
1014376e8: f94057e0    	ldr	x0, [sp, #0xa8]
1014376ec: 52800102    	mov	w2, #0x8                ; =8
1014376f0: 97d99bfb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014376f4: f9415bf3    	ldr	x19, [sp, #0x2b0]
1014376f8: f9415ff4    	ldr	x20, [sp, #0x2b8]
1014376fc: b4000194    	cbz	x20, 0x10143772c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3ac0>
101437700: 91002275    	add	x21, x19, #0x8
101437704: 14000004    	b	0x101437714 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3aa8>
101437708: 910062b5    	add	x21, x21, #0x18
10143770c: f1000694    	subs	x20, x20, #0x1
101437710: 540000e0    	b.eq	0x10143772c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3ac0>
101437714: f85f82a1    	ldur	x1, [x21, #-0x8]
101437718: b4ffff81    	cbz	x1, 0x101437708 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3a9c>
10143771c: f94002a0    	ldr	x0, [x21]
101437720: 52800022    	mov	w2, #0x1                ; =1
101437724: 97d99bee    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437728: 17fffff8    	b	0x101437708 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3a9c>
10143772c: f94157e8    	ldr	x8, [sp, #0x2a8]
101437730: b4002e68    	cbz	x8, 0x101437cfc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4090>
101437734: 8b080508    	add	x8, x8, x8, lsl #1
101437738: d37df101    	lsl	x1, x8, #3
10143773c: aa1303e0    	mov	x0, x19
101437740: 52800102    	mov	w2, #0x8                ; =8
101437744: 97d99be6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437748: 1400016d    	b	0x101437cfc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4090>
10143774c: f94177f3    	ldr	x19, [sp, #0x2e8]
101437750: f9417bf4    	ldr	x20, [sp, #0x2f0]
101437754: 8b140268    	add	x8, x19, x20
101437758: aa1303e9    	mov	x9, x19
10143775c: 14000004    	b	0x10143776c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3b00>
101437760: aa0b03e9    	mov	x9, x11
101437764: 7100bd5f    	cmp	w10, #0x2f
101437768: 540014e0    	b.eq	0x101437a04 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3d98>
10143776c: eb08013f    	cmp	x9, x8
101437770: 54ffe9c0    	b.eq	0x1014374a8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x383c>
101437774: aa0903eb    	mov	x11, x9
101437778: 38c0156c    	ldrsb	w12, [x11], #0x1
10143777c: 12001d8a    	and	w10, w12, #0xff
101437780: 36ffff0c    	tbz	w12, #0x1f, 0x101437760 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3af4>
101437784: 3940052b    	ldrb	w11, [x9, #0x1]
101437788: 1200156c    	and	w12, w11, #0x3f
10143778c: 7103815f    	cmp	w10, #0xe0
101437790: 540001e3    	b.lo	0x1014377cc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3b60>
101437794: 1200114b    	and	w11, w10, #0x1f
101437798: 3940092d    	ldrb	w13, [x9, #0x2]
10143779c: 120015ad    	and	w13, w13, #0x3f
1014377a0: 2a0c19ac    	orr	w12, w13, w12, lsl #6
1014377a4: 7103c15f    	cmp	w10, #0xf0
1014377a8: 540001a3    	b.lo	0x1014377dc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3b70>
1014377ac: 39400d2a    	ldrb	w10, [x9, #0x3]
1014377b0: 1200154a    	and	w10, w10, #0x3f
1014377b4: 2a0c194a    	orr	w10, w10, w12, lsl #6
1014377b8: 330e096a    	bfi	w10, w11, #18, #3
1014377bc: 7144415f    	cmp	w10, #0x110, lsl #12    ; =0x110000
1014377c0: 54ffe740    	b.eq	0x1014374a8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x383c>
1014377c4: 91001129    	add	x9, x9, #0x4
1014377c8: 17ffffe7    	b	0x101437764 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3af8>
1014377cc: 91000929    	add	x9, x9, #0x2
1014377d0: 331a114c    	bfi	w12, w10, #6, #5
1014377d4: aa0c03ea    	mov	x10, x12
1014377d8: 17ffffe3    	b	0x101437764 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3af8>
1014377dc: 91000d29    	add	x9, x9, #0x3
1014377e0: 2a0b318a    	orr	w10, w12, w11, lsl #12
1014377e4: 17ffffe0    	b	0x101437764 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3af8>
1014377e8: 52800108    	mov	w8, #0x8                ; =8
1014377ec: f90193ff    	str	xzr, [sp, #0x320]
1014377f0: f90197e8    	str	x8, [sp, #0x328]
1014377f4: 3dc0cbe0    	ldr	q0, [sp, #0x320]
1014377f8: 3d805fe0    	str	q0, [sp, #0x170]
1014377fc: f900c3fa    	str	x26, [sp, #0x180]
101437800: f94077ea    	ldr	x10, [sp, #0xe8]
101437804: f940d148    	ldr	x8, [x10, #0x1a0]
101437808: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10143780c: eb09011f    	cmp	x8, x9
101437810: 54000261    	b.ne	0x10143785c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3bf0>
101437814: b0007a20    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101437818: 9131a000    	add	x0, x0, #0xc68
10143781c: f9400008    	ldr	x8, [x0]
101437820: d63f0100    	blr	x8
101437824: aa0003f3    	mov	x19, x0
101437828: 39404008    	ldrb	w8, [x0, #0x10]
10143782c: 7100051f    	cmp	w8, #0x1
101437830: 54006921    	b.ne	0x101438554 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x48e8>
101437834: a9400660    	ldp	x0, x1, [x19]
101437838: 91000408    	add	x8, x0, #0x1
10143783c: f9000268    	str	x8, [x19]
101437840: b0007188    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101437844: 91166108    	add	x8, x8, #0x598
101437848: ad400500    	ldp	q0, q1, [x8]
10143784c: ad1907e0    	stp	q0, q1, [sp, #0x320]
101437850: f901a3e0    	str	x0, [sp, #0x340]
101437854: f901a7e1    	str	x1, [sp, #0x348]
101437858: 1400000b    	b	0x101437884 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3c18>
10143785c: a9578be1    	ldp	x1, x2, [sp, #0x178]
101437860: 910e43e8    	add	x8, sp, #0x390
101437864: 91068140    	add	x0, x10, #0x1a0
101437868: aa1503e3    	mov	x3, x21
10143786c: aa1303e4    	mov	x4, x19
101437870: 94001c4e    	bl	0x10143e9a8 <__ZN17otty_autocomplete7history14CommandHistory15frecency_scores17h97b33baba167a62bE>
101437874: ad5c87e0    	ldp	q0, q1, [sp, #0x390]
101437878: ad1907e0    	stp	q0, q1, [sp, #0x320]
10143787c: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
101437880: 3d80d3e0    	str	q0, [sp, #0x340]
101437884: d2892488    	mov	x8, #0x4924             ; =18724
101437888: f2a49248    	movk	x8, #0x2492, lsl #16
10143788c: f2d24928    	movk	x8, #0x9249, lsl #32
101437890: f2e02488    	movk	x8, #0x124, lsl #48
101437894: eb08035f    	cmp	x26, x8
101437898: 540000a9    	b.ls	0x1014378ac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3c40>
10143789c: d2800000    	mov	x0, #0x0                ; =0
1014378a0: aa1303e1    	mov	x1, x19
1014378a4: 941a2eb4    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014378a8: 140003a5    	b	0x10143873c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ad0>
1014378ac: d379e348    	lsl	x8, x26, #7
1014378b0: cb1a1113    	sub	x19, x8, x26, lsl #4
1014378b4: b4000b9a    	cbz	x26, 0x101437a24 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3db8>
1014378b8: 97d99b8e    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014378bc: aa1303e0    	mov	x0, x19
1014378c0: 52800101    	mov	w1, #0x8                ; =8
1014378c4: 97d99b85    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014378c8: b4006fe0    	cbz	x0, 0x1014386c4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4a58>
1014378cc: aa0003f7    	mov	x23, x0
1014378d0: d2800019    	mov	x25, #0x0               ; =0
1014378d4: 52800d08    	mov	w8, #0x68               ; =104
1014378d8: 9b087f48    	mul	x8, x26, x8
1014378dc: 91002009    	add	x9, x0, #0x8
1014378e0: aa1403ea    	mov	x10, x20
1014378e4: f81f8139    	stur	x25, [x9, #-0x8]
1014378e8: ad400540    	ldp	q0, q1, [x10]
1014378ec: 3dc00942    	ldr	q2, [x10, #0x20]
1014378f0: ad008921    	stp	q1, q2, [x9, #0x10]
1014378f4: 3d800120    	str	q0, [x9]
1014378f8: ad418540    	ldp	q0, q1, [x10, #0x30]
1014378fc: 3dc01542    	ldr	q2, [x10, #0x50]
101437900: f940314b    	ldr	x11, [x10, #0x60]
101437904: 9101a14a    	add	x10, x10, #0x68
101437908: f900312b    	str	x11, [x9, #0x60]
10143790c: ad020921    	stp	q1, q2, [x9, #0x40]
101437910: 3d800d20    	str	q0, [x9, #0x30]
101437914: 91000739    	add	x25, x25, #0x1
101437918: 9101c129    	add	x9, x9, #0x70
10143791c: f101a108    	subs	x8, x8, #0x68
101437920: 54fffe21    	b.ne	0x1014378e4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3c78>
101437924: 14000042    	b	0x101437a2c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3dc0>
101437928: 52800028    	mov	w8, #0x1                ; =1
10143792c: 52800018    	mov	w24, #0x0               ; =0
101437930: 5280001a    	mov	w26, #0x0               ; =0
101437934: 52800d09    	mov	w9, #0x68               ; =104
101437938: 9b096508    	madd	x8, x8, x9, x25
10143793c: 528decc9    	mov	w9, #0x6f66             ; =28518
101437940: 72ac8d89    	movk	w9, #0x646c, lsl #16
101437944: 528cac8a    	mov	w10, #0x6564            ; =25956
101437948: 72ae6e4a    	movk	w10, #0x7372, lsl #16
10143794c: d28d2ccb    	mov	x11, #0x6966            ; =26982
101437950: f2acad8b    	movk	x11, #0x656c, lsl #16
101437954: f2cc2e0b    	movk	x11, #0x6170, lsl #32
101437958: f2ed0e8b    	movk	x11, #0x6874, lsl #48
10143795c: 52800e6c    	mov	w12, #0x73              ; =115
101437960: 5280030d    	mov	w13, #0x18              ; =24
101437964: eb08033f    	cmp	x25, x8
101437968: 54ffd420    	b.eq	0x1014373ec <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3780>
10143796c: aa1903f0    	mov	x16, x25
101437970: f846872e    	ldr	x14, [x25], #0x68
101437974: f10009df    	cmp	x14, #0x2
101437978: 54ffff60    	b.eq	0x101437964 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3cf8>
10143797c: 370000ce    	tbnz	w14, #0x0, 0x101437994 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3d28>
101437980: f9400e0e    	ldr	x14, [x16, #0x18]
101437984: b4ffff0e    	cbz	x14, 0x101437964 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3cf8>
101437988: f9400a0f    	ldr	x15, [x16, #0x10]
10143798c: 9b0d3dce    	madd	x14, x14, x13, x15
101437990: 14000003    	b	0x10143799c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3d30>
101437994: 9100220f    	add	x15, x16, #0x8
101437998: 9100820e    	add	x14, x16, #0x20
10143799c: 910061ef    	add	x15, x15, #0x18
1014379a0: 9101a219    	add	x25, x16, #0x68
1014379a4: 1400000b    	b	0x1014379d0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3d64>
1014379a8: b9400211    	ldr	w17, [x16]
1014379ac: b8403210    	ldur	w16, [x16, #0x3]
1014379b0: 6b09023f    	cmp	w17, w9
1014379b4: 7a4a0200    	ccmp	w16, w10, #0x0, eq
1014379b8: 1a9f17f0    	cset	w16, eq
1014379bc: 2a180218    	orr	w24, w16, w24
1014379c0: 910061ef    	add	x15, x15, #0x18
1014379c4: d10061f0    	sub	x16, x15, #0x18
1014379c8: eb0e021f    	cmp	x16, x14
1014379cc: 54fffcc0    	b.eq	0x101437964 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3cf8>
1014379d0: a97f45f0    	ldp	x16, x17, [x15, #-0x10]
1014379d4: f1001e3f    	cmp	x17, #0x7
1014379d8: 54fffe80    	b.eq	0x1014379a8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3d3c>
1014379dc: f100263f    	cmp	x17, #0x9
1014379e0: 54ffff01    	b.ne	0x1014379c0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3d54>
1014379e4: f9400211    	ldr	x17, [x16]
1014379e8: 39402210    	ldrb	w16, [x16, #0x8]
1014379ec: eb0b023f    	cmp	x17, x11
1014379f0: 7a4c0200    	ccmp	w16, w12, #0x0, eq
1014379f4: 1a9f17f0    	cset	w16, eq
1014379f8: 2a180218    	orr	w24, w16, w24
1014379fc: 2a1a021a    	orr	w26, w16, w26
101437a00: 17fffff0    	b	0x1014379c0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3d54>
101437a04: 940e3aaa    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101437a08: f94073e8    	ldr	x8, [sp, #0xe0]
101437a0c: eb08001f    	cmp	x0, x8
101437a10: 540018a1    	b.ne	0x101437d24 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x40b8>
101437a14: b9407be8    	ldr	w8, [sp, #0x78]
101437a18: 6b08003f    	cmp	w1, w8
101437a1c: 54ffd462    	b.hs	0x1014374a8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x383c>
101437a20: 140000c3    	b	0x101437d2c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x40c0>
101437a24: d2800019    	mov	x25, #0x0               ; =0
101437a28: 52800117    	mov	w23, #0x8               ; =8
101437a2c: b40000db    	cbz	x27, 0x101437a44 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3dd8>
101437a30: 52800d08    	mov	w8, #0x68               ; =104
101437a34: 9b087f61    	mul	x1, x27, x8
101437a38: aa1403e0    	mov	x0, x20
101437a3c: 52800102    	mov	w2, #0x8                ; =8
101437a40: 97d99b27    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437a44: a91edffa    	stp	x26, x23, [sp, #0x1e8]
101437a48: f900fff9    	str	x25, [sp, #0x1f8]
101437a4c: 910c83e8    	add	x8, sp, #0x320
101437a50: f9011be8    	str	x8, [sp, #0x230]
101437a54: 9108c3e8    	add	x8, sp, #0x230
101437a58: d289d8b4    	mov	x20, #0x4ec5            ; =20165
101437a5c: f2b89d94    	movk	x20, #0xc4ec, lsl #16
101437a60: f2dd89d4    	movk	x20, #0xec4e, lsl #32
101437a64: f2e9d894    	movk	x20, #0x4ec4, lsl #48
101437a68: f901cbe8    	str	x8, [sp, #0x390]
101437a6c: f1000b3f    	cmp	x25, #0x2
101437a70: 540057c2    	b.hs	0x101438568 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x48fc>
101437a74: 52800e08    	mov	w8, #0x70               ; =112
101437a78: 9b085f28    	madd	x8, x25, x8, x23
101437a7c: 9bd47e69    	umulh	x9, x19, x20
101437a80: d345fd3b    	lsr	x27, x9, #5
101437a84: aa1703e9    	mov	x9, x23
101437a88: aa1703ea    	mov	x10, x23
101437a8c: b4000259    	cbz	x25, 0x101437ad4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3e68>
101437a90: aa1703ea    	mov	x10, x23
101437a94: aa1703e9    	mov	x9, x23
101437a98: 3cc08120    	ldur	q0, [x9, #0x8]
101437a9c: 3cc18121    	ldur	q1, [x9, #0x18]
101437aa0: 3cc28122    	ldur	q2, [x9, #0x28]
101437aa4: 3cc38123    	ldur	q3, [x9, #0x38]
101437aa8: 3cc48124    	ldur	q4, [x9, #0x48]
101437aac: 3cc58125    	ldur	q5, [x9, #0x58]
101437ab0: f940352b    	ldr	x11, [x9, #0x68]
101437ab4: 9101c129    	add	x9, x9, #0x70
101437ab8: f900314b    	str	x11, [x10, #0x60]
101437abc: ad021544    	stp	q4, q5, [x10, #0x40]
101437ac0: ad010d42    	stp	q2, q3, [x10, #0x20]
101437ac4: ad000540    	stp	q0, q1, [x10]
101437ac8: 9101a14a    	add	x10, x10, #0x68
101437acc: eb08013f    	cmp	x9, x8
101437ad0: 54fffe41    	b.ne	0x101437a98 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3e2c>
101437ad4: cb17014a    	sub	x10, x10, x23
101437ad8: d343fd4a    	lsr	x10, x10, #3
101437adc: 9b147d59    	mul	x25, x10, x20
101437ae0: f9011bf7    	str	x23, [sp, #0x230]
101437ae4: f9011ff9    	str	x25, [sp, #0x238]
101437ae8: f90123fa    	str	x26, [sp, #0x240]
101437aec: 5280010a    	mov	w10, #0x8               ; =8
101437af0: f901cbea    	str	x10, [sp, #0x390]
101437af4: f901cfea    	str	x10, [sp, #0x398]
101437af8: f901d3ff    	str	xzr, [sp, #0x3a0]
101437afc: f901d7ea    	str	x10, [sp, #0x3a8]
101437b00: eb090108    	subs	x8, x8, x9
101437b04: 540001a0    	b.eq	0x101437b38 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3ecc>
101437b08: d344fd08    	lsr	x8, x8, #4
101437b0c: d284926a    	mov	x10, #0x2493            ; =9363
101437b10: f2b2492a    	movk	x10, #0x9249, lsl #16
101437b14: f2c9248a    	movk	x10, #0x4924, lsl #32
101437b18: f2e4924a    	movk	x10, #0x2492, lsl #48
101437b1c: 9bca7d1c    	umulh	x28, x8, x10
101437b20: 91002134    	add	x20, x9, #0x8
101437b24: aa1403e0    	mov	x0, x20
101437b28: 97db16ec    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101437b2c: 9101c294    	add	x20, x20, #0x70
101437b30: f100079c    	subs	x28, x28, #0x1
101437b34: 54ffff81    	b.ne	0x101437b24 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3eb8>
101437b38: b400019a    	cbz	x26, 0x101437b68 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3efc>
101437b3c: 52800d08    	mov	w8, #0x68               ; =104
101437b40: 9b087f74    	mul	x20, x27, x8
101437b44: eb14027f    	cmp	x19, x20
101437b48: 54000100    	b.eq	0x101437b68 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3efc>
101437b4c: aa1703e0    	mov	x0, x23
101437b50: aa1303e1    	mov	x1, x19
101437b54: 52800102    	mov	w2, #0x8                ; =8
101437b58: aa1403e3    	mov	x3, x20
101437b5c: 97d99ae1    	bl	0x100a9e6e0 <__RNvCsdBezzDwma51_7___rustc14___rust_realloc>
101437b60: aa0003f7    	mov	x23, x0
101437b64: b4005540    	cbz	x0, 0x10143860c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x49a0>
101437b68: f9406be8    	ldr	x8, [sp, #0xd0]
101437b6c: a9005d1b    	stp	x27, x23, [x8]
101437b70: f9000919    	str	x25, [x8, #0x10]
101437b74: f94197f3    	ldr	x19, [sp, #0x328]
101437b78: b4000533    	cbz	x19, 0x101437c1c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3fb0>
101437b7c: f9419ff4    	ldr	x20, [sp, #0x338]
101437b80: b40003d4    	cbz	x20, 0x101437bf8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3f8c>
101437b84: f94193f7    	ldr	x23, [sp, #0x320]
101437b88: aa1703f9    	mov	x25, x23
101437b8c: fc408720    	ldr	d0, [x25], #0x8
101437b90: 2e208800    	cmge.8b	v0, v0, #0
101437b94: 9e660008    	fmov	x8, d0
101437b98: 9201c11a    	and	x26, x8, #0x8080808080808080
101437b9c: 14000005    	b	0x101437bb0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3f44>
101437ba0: d1000748    	sub	x8, x26, #0x1
101437ba4: 8a1a011a    	and	x26, x8, x26
101437ba8: d1000694    	sub	x20, x20, #0x1
101437bac: b4000274    	cbz	x20, 0x101437bf8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3f8c>
101437bb0: b50000fa    	cbnz	x26, 0x101437bcc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3f60>
101437bb4: fc408720    	ldr	d0, [x25], #0x8
101437bb8: 2e208800    	cmge.8b	v0, v0, #0
101437bbc: 9e660008    	fmov	x8, d0
101437bc0: d10402f7    	sub	x23, x23, #0x100
101437bc4: 9201c11a    	and	x26, x8, #0x8080808080808080
101437bc8: b4ffff7a    	cbz	x26, 0x101437bb4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3f48>
101437bcc: dac00348    	rbit	x8, x26
101437bd0: dac01108    	clz	x8, x8
101437bd4: d37ef508    	lsl	x8, x8, #2
101437bd8: 927b0d08    	and	x8, x8, #0x1e0
101437bdc: cb0802e8    	sub	x8, x23, x8
101437be0: f85e0101    	ldur	x1, [x8, #-0x20]
101437be4: b4fffde1    	cbz	x1, 0x101437ba0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3f34>
101437be8: f85e8100    	ldur	x0, [x8, #-0x18]
101437bec: 52800022    	mov	w2, #0x1                ; =1
101437bf0: 97d99abb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437bf4: 17ffffeb    	b	0x101437ba0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3f34>
101437bf8: d37bea68    	lsl	x8, x19, #5
101437bfc: 8b130109    	add	x9, x8, x19
101437c00: b100a521    	adds	x1, x9, #0x29
101437c04: 540000c0    	b.eq	0x101437c1c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3fb0>
101437c08: f94193e9    	ldr	x9, [sp, #0x320]
101437c0c: cb080128    	sub	x8, x9, x8
101437c10: d1008100    	sub	x0, x8, #0x20
101437c14: 52800102    	mov	w2, #0x8                ; =8
101437c18: 97d99ab1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437c1c: a957d3f3    	ldp	x19, x20, [sp, #0x178]
101437c20: b4000194    	cbz	x20, 0x101437c50 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3fe4>
101437c24: 91002277    	add	x23, x19, #0x8
101437c28: 14000004    	b	0x101437c38 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3fcc>
101437c2c: 910062f7    	add	x23, x23, #0x18
101437c30: f1000694    	subs	x20, x20, #0x1
101437c34: 540000e0    	b.eq	0x101437c50 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3fe4>
101437c38: f85f82e1    	ldur	x1, [x23, #-0x8]
101437c3c: b4ffff81    	cbz	x1, 0x101437c2c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3fc0>
101437c40: f94002e0    	ldr	x0, [x23]
101437c44: 52800022    	mov	w2, #0x1                ; =1
101437c48: 97d99aa5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437c4c: 17fffff8    	b	0x101437c2c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3fc0>
101437c50: f940bbe8    	ldr	x8, [sp, #0x170]
101437c54: b40000c8    	cbz	x8, 0x101437c6c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4000>
101437c58: 8b080508    	add	x8, x8, x8, lsl #1
101437c5c: d37df101    	lsl	x1, x8, #3
101437c60: aa1303e0    	mov	x0, x19
101437c64: 52800102    	mov	w2, #0x8                ; =8
101437c68: 97d99a9d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437c6c: f940d3e1    	ldr	x1, [sp, #0x1a0]
101437c70: b4000081    	cbz	x1, 0x101437c80 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4014>
101437c74: aa1503e0    	mov	x0, x21
101437c78: 52800022    	mov	w2, #0x1                ; =1
101437c7c: 97d99a98    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437c80: f94173e1    	ldr	x1, [sp, #0x2e0]
101437c84: b4000081    	cbz	x1, 0x101437c94 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4028>
101437c88: f94177e0    	ldr	x0, [sp, #0x2e8]
101437c8c: 52800022    	mov	w2, #0x1                ; =1
101437c90: 97d99a93    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437c94: f9414be8    	ldr	x8, [sp, #0x290]
101437c98: b40000a8    	cbz	x8, 0x101437cac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4040>
101437c9c: d37df101    	lsl	x1, x8, #3
101437ca0: f94057e0    	ldr	x0, [sp, #0xa8]
101437ca4: 52800102    	mov	w2, #0x8                ; =8
101437ca8: 97d99a8d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437cac: b4000198    	cbz	x24, 0x101437cdc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4070>
101437cb0: 910022d3    	add	x19, x22, #0x8
101437cb4: 14000004    	b	0x101437cc4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4058>
101437cb8: 91006273    	add	x19, x19, #0x18
101437cbc: f1000718    	subs	x24, x24, #0x1
101437cc0: 540000e0    	b.eq	0x101437cdc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4070>
101437cc4: f85f8261    	ldur	x1, [x19, #-0x8]
101437cc8: b4ffff81    	cbz	x1, 0x101437cb8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x404c>
101437ccc: f9400260    	ldr	x0, [x19]
101437cd0: 52800022    	mov	w2, #0x1                ; =1
101437cd4: 97d99a82    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437cd8: 17fffff8    	b	0x101437cb8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x404c>
101437cdc: f94157e8    	ldr	x8, [sp, #0x2a8]
101437ce0: b40000c8    	cbz	x8, 0x101437cf8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x408c>
101437ce4: 8b080508    	add	x8, x8, x8, lsl #1
101437ce8: d37df101    	lsl	x1, x8, #3
101437cec: aa1603e0    	mov	x0, x22
101437cf0: 52800102    	mov	w2, #0x8                ; =8
101437cf4: 97d99a7a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437cf8: f9404ff6    	ldr	x22, [sp, #0x98]
101437cfc: 92800008    	mov	x8, #-0x1               ; =-1
101437d00: f86802c8    	ldaddl	x8, x8, [x22]
101437d04: f100051f    	cmp	x8, #0x1
101437d08: 54001941    	b.ne	0x101438030 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x43c4>
101437d0c: d50339bf    	dmb	ishld
101437d10: 9109e3e0    	add	x0, sp, #0x278
101437d14: 9400ce87    	bl	0x10146b730 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E>
101437d18: 140000c6    	b	0x101438030 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x43c4>
101437d1c: 52800037    	mov	w23, #0x1               ; =1
101437d20: 14000019    	b	0x101437d84 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4118>
101437d24: eb08001f    	cmp	x0, x8
101437d28: 54ffbc0a    	b.ge	0x1014374a8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x383c>
101437d2c: 910c83e8    	add	x8, sp, #0x320
101437d30: aa1303e0    	mov	x0, x19
101437d34: aa1403e1    	mov	x1, x20
101437d38: f9406fe2    	ldr	x2, [sp, #0xd8]
101437d3c: f94067e3    	ldr	x3, [sp, #0xc8]
101437d40: 52800024    	mov	w4, #0x1                ; =1
101437d44: 52800025    	mov	w5, #0x1                ; =1
101437d48: 940044cd    	bl	0x10144907c <__ZN17otty_autocomplete7sources20filepath_completions17h84e38b562ae049e9E>
101437d4c: f94193e8    	ldr	x8, [sp, #0x320]
101437d50: f94197e9    	ldr	x9, [sp, #0x328]
101437d54: f9419bea    	ldr	x10, [sp, #0x330]
101437d58: 52800d0b    	mov	w11, #0x68              ; =104
101437d5c: 9b0b254a    	madd	x10, x10, x11, x9
101437d60: f901cbe9    	str	x9, [sp, #0x390]
101437d64: f901cfe9    	str	x9, [sp, #0x398]
101437d68: f901d3e8    	str	x8, [sp, #0x3a0]
101437d6c: f901d7ea    	str	x10, [sp, #0x3a8]
101437d70: 910c03e0    	add	x0, sp, #0x300
101437d74: 910e43e1    	add	x1, sp, #0x390
101437d78: 97ff5aa4    	bl	0x10140e808 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x34bc>
101437d7c: 17fffdcb    	b	0x1014374a8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x383c>
101437d80: 52800017    	mov	w23, #0x0               ; =0
101437d84: d2800016    	mov	x22, #0x0               ; =0
101437d88: 52800033    	mov	w19, #0x1               ; =1
101437d8c: 52800114    	mov	w20, #0x8               ; =8
101437d90: f901cbfc    	str	x28, [sp, #0x390]
101437d94: f901cffc    	str	x28, [sp, #0x398]
101437d98: f901d3f9    	str	x25, [sp, #0x3a0]
101437d9c: f901d7f5    	str	x21, [sp, #0x3a8]
101437da0: f9411be8    	ldr	x8, [sp, #0x230]
101437da4: eb08031f    	cmp	x24, x8
101437da8: 540040a8    	b.hi	0x1014385bc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4950>
101437dac: d280001a    	mov	x26, #0x0               ; =0
101437db0: f9411ff8    	ldr	x24, [sp, #0x238]
101437db4: 37000237    	tbnz	w23, #0x0, 0x101437df8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x418c>
101437db8: 52800d08    	mov	w8, #0x68               ; =104
101437dbc: 9b086348    	madd	x8, x26, x8, x24
101437dc0: aa1c03e9    	mov	x9, x28
101437dc4: ad408520    	ldp	q0, q1, [x9, #0x10]
101437dc8: ad418d22    	ldp	q2, q3, [x9, #0x30]
101437dcc: ad429524    	ldp	q4, q5, [x9, #0x50]
101437dd0: f940392a    	ldr	x10, [x9, #0x70]
101437dd4: 9101e129    	add	x9, x9, #0x78
101437dd8: f900310a    	str	x10, [x8, #0x60]
101437ddc: ad021504    	stp	q4, q5, [x8, #0x40]
101437de0: ad010d02    	stp	q2, q3, [x8, #0x20]
101437de4: 9100075a    	add	x26, x26, #0x1
101437de8: ad000500    	stp	q0, q1, [x8]
101437dec: 9101a108    	add	x8, x8, #0x68
101437df0: eb15013f    	cmp	x9, x21
101437df4: 54fffe81    	b.ne	0x101437dc4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4158>
101437df8: f90123fa    	str	x26, [sp, #0x240]
101437dfc: b40000b9    	cbz	x25, 0x101437e10 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x41a4>
101437e00: aa1c03e0    	mov	x0, x28
101437e04: f9402fe1    	ldr	x1, [sp, #0x58]
101437e08: 52800102    	mov	w2, #0x8                ; =8
101437e0c: 97d99a34    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437e10: f100035f    	cmp	x26, #0x0
101437e14: 1a9f1668    	csinc	w8, w19, wzr, ne
101437e18: 7100051f    	cmp	w8, #0x1
101437e1c: f9406ff5    	ldr	x21, [sp, #0xd8]
101437e20: 54000060    	b.eq	0x101437e2c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x41c0>
101437e24: 52800028    	mov	w8, #0x1                ; =1
101437e28: 39018308    	strb	w8, [x24, #0x60]
101437e2c: b40000b6    	cbz	x22, 0x101437e40 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x41d4>
101437e30: d37df2c1    	lsl	x1, x22, #3
101437e34: aa1403e0    	mov	x0, x20
101437e38: 52800102    	mov	w2, #0x8                ; =8
101437e3c: 97d99a28    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437e40: f94197f3    	ldr	x19, [sp, #0x328]
101437e44: b4000553    	cbz	x19, 0x101437eec <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4280>
101437e48: f9419ff4    	ldr	x20, [sp, #0x338]
101437e4c: b40003d4    	cbz	x20, 0x101437ec4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4258>
101437e50: f94193f5    	ldr	x21, [sp, #0x320]
101437e54: aa1503f6    	mov	x22, x21
101437e58: fc4086c0    	ldr	d0, [x22], #0x8
101437e5c: 2e208800    	cmge.8b	v0, v0, #0
101437e60: 9e660008    	fmov	x8, d0
101437e64: 9201c117    	and	x23, x8, #0x8080808080808080
101437e68: 14000005    	b	0x101437e7c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4210>
101437e6c: d10006e8    	sub	x8, x23, #0x1
101437e70: 8a170117    	and	x23, x8, x23
101437e74: d1000694    	sub	x20, x20, #0x1
101437e78: b4000274    	cbz	x20, 0x101437ec4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4258>
101437e7c: b50000f7    	cbnz	x23, 0x101437e98 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x422c>
101437e80: fc4086c0    	ldr	d0, [x22], #0x8
101437e84: 2e208800    	cmge.8b	v0, v0, #0
101437e88: 9e660008    	fmov	x8, d0
101437e8c: d10402b5    	sub	x21, x21, #0x100
101437e90: 9201c117    	and	x23, x8, #0x8080808080808080
101437e94: b4ffff77    	cbz	x23, 0x101437e80 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4214>
101437e98: dac002e8    	rbit	x8, x23
101437e9c: dac01108    	clz	x8, x8
101437ea0: d37ef508    	lsl	x8, x8, #2
101437ea4: 927b0d08    	and	x8, x8, #0x1e0
101437ea8: cb0802a8    	sub	x8, x21, x8
101437eac: f85e0101    	ldur	x1, [x8, #-0x20]
101437eb0: b4fffde1    	cbz	x1, 0x101437e6c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4200>
101437eb4: f85e8100    	ldur	x0, [x8, #-0x18]
101437eb8: 52800022    	mov	w2, #0x1                ; =1
101437ebc: 97d99a08    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437ec0: 17ffffeb    	b	0x101437e6c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4200>
101437ec4: d37bea68    	lsl	x8, x19, #5
101437ec8: 8b130109    	add	x9, x8, x19
101437ecc: b100a521    	adds	x1, x9, #0x29
101437ed0: f9406ff5    	ldr	x21, [sp, #0xd8]
101437ed4: 540000c0    	b.eq	0x101437eec <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4280>
101437ed8: f94193e9    	ldr	x9, [sp, #0x320]
101437edc: cb080128    	sub	x8, x9, x8
101437ee0: d1008100    	sub	x0, x8, #0x20
101437ee4: 52800102    	mov	w2, #0x8                ; =8
101437ee8: 97d999fd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437eec: b400019b    	cbz	x27, 0x101437f1c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x42b0>
101437ef0: 910022b3    	add	x19, x21, #0x8
101437ef4: 14000004    	b	0x101437f04 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4298>
101437ef8: 91006273    	add	x19, x19, #0x18
101437efc: f100077b    	subs	x27, x27, #0x1
101437f00: 540000e0    	b.eq	0x101437f1c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x42b0>
101437f04: f85f8261    	ldur	x1, [x19, #-0x8]
101437f08: b4ffff81    	cbz	x1, 0x101437ef8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x428c>
101437f0c: f9400260    	ldr	x0, [x19]
101437f10: 52800022    	mov	w2, #0x1                ; =1
101437f14: 97d999f2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437f18: 17fffff8    	b	0x101437ef8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x428c>
101437f1c: f94173e8    	ldr	x8, [sp, #0x2e0]
101437f20: b40000c8    	cbz	x8, 0x101437f38 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x42cc>
101437f24: 8b080508    	add	x8, x8, x8, lsl #1
101437f28: d37df101    	lsl	x1, x8, #3
101437f2c: aa1503e0    	mov	x0, x21
101437f30: 52800102    	mov	w2, #0x8                ; =8
101437f34: 97d999ea    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437f38: f9406bfb    	ldr	x27, [sp, #0xd0]
101437f3c: 3dc08fe0    	ldr	q0, [sp, #0x230]
101437f40: 3d800360    	str	q0, [x27]
101437f44: f94123e8    	ldr	x8, [sp, #0x240]
101437f48: f9000b68    	str	x8, [x27, #0x10]
101437f4c: f94067e9    	ldr	x9, [sp, #0xc8]
101437f50: b4000149    	cbz	x9, 0x101437f78 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x430c>
101437f54: d37ced28    	lsl	x8, x9, #4
101437f58: 8b090109    	add	x9, x8, x9
101437f5c: b1006521    	adds	x1, x9, #0x19
101437f60: 540000c0    	b.eq	0x101437f78 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x430c>
101437f64: f94057e9    	ldr	x9, [sp, #0xa8]
101437f68: cb080128    	sub	x8, x9, x8
101437f6c: d1004100    	sub	x0, x8, #0x10
101437f70: 52800102    	mov	w2, #0x8                ; =8
101437f74: 97d999da    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437f78: a957d7f3    	ldp	x19, x21, [sp, #0x178]
101437f7c: f94053f6    	ldr	x22, [sp, #0xa0]
101437f80: b40000f5    	cbz	x21, 0x101437f9c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4330>
101437f84: aa1303f4    	mov	x20, x19
101437f88: aa1403e0    	mov	x0, x20
101437f8c: 97db15d3    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101437f90: 9101a294    	add	x20, x20, #0x68
101437f94: f10006b5    	subs	x21, x21, #0x1
101437f98: 54ffff81    	b.ne	0x101437f88 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x431c>
101437f9c: f940bbe8    	ldr	x8, [sp, #0x170]
101437fa0: b40000c8    	cbz	x8, 0x101437fb8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x434c>
101437fa4: 52800d09    	mov	w9, #0x68               ; =104
101437fa8: 9b097d01    	mul	x1, x8, x9
101437fac: aa1303e0    	mov	x0, x19
101437fb0: 52800102    	mov	w2, #0x8                ; =8
101437fb4: 97d999ca    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437fb8: b40000b6    	cbz	x22, 0x101437fcc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4360>
101437fbc: f94073e0    	ldr	x0, [sp, #0xe0]
101437fc0: aa1603e1    	mov	x1, x22
101437fc4: 52800022    	mov	w2, #0x1                ; =1
101437fc8: 97d999c5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437fcc: a95ad3f3    	ldp	x19, x20, [sp, #0x1a8]
101437fd0: b4000194    	cbz	x20, 0x101438000 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4394>
101437fd4: 91002275    	add	x21, x19, #0x8
101437fd8: 14000004    	b	0x101437fe8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x437c>
101437fdc: 910062b5    	add	x21, x21, #0x18
101437fe0: f1000694    	subs	x20, x20, #0x1
101437fe4: 540000e0    	b.eq	0x101438000 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4394>
101437fe8: f85f82a1    	ldur	x1, [x21, #-0x8]
101437fec: b4ffff81    	cbz	x1, 0x101437fdc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4370>
101437ff0: f94002a0    	ldr	x0, [x21]
101437ff4: 52800022    	mov	w2, #0x1                ; =1
101437ff8: 97d999b9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101437ffc: 17fffff8    	b	0x101437fdc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4370>
101438000: f940d3e8    	ldr	x8, [sp, #0x1a0]
101438004: b40000c8    	cbz	x8, 0x10143801c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x43b0>
101438008: 8b080508    	add	x8, x8, x8, lsl #1
10143800c: d37df101    	lsl	x1, x8, #3
101438010: aa1303e0    	mov	x0, x19
101438014: 52800102    	mov	w2, #0x8                ; =8
101438018: 97d999b1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143801c: f94183e1    	ldr	x1, [sp, #0x300]
101438020: b4000081    	cbz	x1, 0x101438030 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x43c4>
101438024: f94187e0    	ldr	x0, [sp, #0x308]
101438028: 52800022    	mov	w2, #0x1                ; =1
10143802c: 97d999ac    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438030: f94087e1    	ldr	x1, [sp, #0x108]
101438034: b4000081    	cbz	x1, 0x101438044 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x43d8>
101438038: f9408be0    	ldr	x0, [sp, #0x110]
10143803c: 52800022    	mov	w2, #0x1                ; =1
101438040: 97d999a7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438044: a94fd3f3    	ldp	x19, x20, [sp, #0xf8]
101438048: b4fe3f14    	cbz	x20, 0x101434828 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xbbc>
10143804c: 91002275    	add	x21, x19, #0x8
101438050: 14000004    	b	0x101438060 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x43f4>
101438054: 910062b5    	add	x21, x21, #0x18
101438058: f1000694    	subs	x20, x20, #0x1
10143805c: 54fe3e60    	b.eq	0x101434828 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xbbc>
101438060: f85f82a1    	ldur	x1, [x21, #-0x8]
101438064: b4ffff81    	cbz	x1, 0x101438054 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x43e8>
101438068: f94002a0    	ldr	x0, [x21]
10143806c: 52800022    	mov	w2, #0x1                ; =1
101438070: 97d9999b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438074: 17fffff8    	b	0x101438054 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x43e8>
101438078: 52800017    	mov	w23, #0x0               ; =0
10143807c: 52800013    	mov	w19, #0x0               ; =0
101438080: 52800096    	mov	w22, #0x4               ; =4
101438084: 17ffff43    	b	0x101437d90 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4124>
101438088: f941cbf6    	ldr	x22, [sp, #0x390]
10143808c: f941cff4    	ldr	x20, [sp, #0x398]
101438090: f100067f    	cmp	x19, #0x1
101438094: 540000c1    	b.ne	0x1014380ac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4440>
101438098: 52800017    	mov	w23, #0x0               ; =0
10143809c: 52800013    	mov	w19, #0x0               ; =0
1014380a0: 17ffff3c    	b	0x101437d90 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4124>
1014380a4: f941cbf6    	ldr	x22, [sp, #0x390]
1014380a8: f941cff4    	ldr	x20, [sp, #0x398]
1014380ac: 52800017    	mov	w23, #0x0               ; =0
1014380b0: 6d400680    	ldp	d0, d1, [x20]
1014380b4: 1e6f1002    	fmov	d2, #1.50000000
1014380b8: 1e620821    	fmul	d1, d1, d2
1014380bc: 1e612000    	fcmp	d0, d1
1014380c0: 1a9fa7f3    	cset	w19, lt
1014380c4: 17ffff33    	b	0x101437d90 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4124>
1014380c8: b0007183    	adrp	x3, 0x102269000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x2a0>
1014380cc: 9110c063    	add	x3, x3, #0x430
1014380d0: 52800020    	mov	w0, #0x1                ; =1
1014380d4: aa1c03e2    	mov	x2, x28
1014380d8: 941a2de4    	bl	0x101ac3868 <__ZN4core5slice5index16slice_index_fail17h88b945c1204cb3a0E>
1014380dc: 14000198    	b	0x10143873c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ad0>
1014380e0: 940e1e2a    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
1014380e4: f90006c1    	str	x1, [x22, #0x8]
1014380e8: 52800028    	mov	w8, #0x1                ; =1
1014380ec: 390042c8    	strb	w8, [x22, #0x10]
1014380f0: f9406bfb    	ldr	x27, [sp, #0xd0]
1014380f4: 17fff289    	b	0x101434b18 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xeac>
1014380f8: 910e43e8    	add	x8, sp, #0x390
1014380fc: 910e43e0    	add	x0, sp, #0x390
101438100: 91008102    	add	x2, x8, #0x20
101438104: aa1703f4    	mov	x20, x23
101438108: aa1703e1    	mov	x1, x23
10143810c: 52800023    	mov	w3, #0x1                ; =1
101438110: 9419f026    	bl	0x101ab41a8 <__ZN9hashbrown3raw21RawTable$LT$T$C$A$GT$14reserve_rehash17h8ad6e75f269338c4E>
101438114: f9401ff3    	ldr	x19, [sp, #0x38]
101438118: aa1403f7    	mov	x23, x20
10143811c: f9406bfb    	ldr	x27, [sp, #0xd0]
101438120: 910c83e8    	add	x8, sp, #0x320
101438124: aa1303e0    	mov	x0, x19
101438128: 940f5c29    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10143812c: 910e43e0    	add	x0, sp, #0x390
101438130: 910c83e1    	add	x1, sp, #0x320
101438134: 9400fa86    	bl	0x101476b4c <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xee0>
101438138: 9101a273    	add	x19, x19, #0x68
10143813c: f1000694    	subs	x20, x20, #0x1
101438140: 54ffff01    	b.ne	0x101438120 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x44b4>
101438144: 17fff280    	b	0x101434b44 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0xed8>
101438148: aa1703f9    	mov	x25, x23
10143814c: aa1603f8    	mov	x24, x22
101438150: f100567f    	cmp	x19, #0x15
101438154: 54002902    	b.hs	0x101438674 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4a08>
101438158: aa1903f7    	mov	x23, x25
10143815c: aa1903e0    	mov	x0, x25
101438160: aa1303e1    	mov	x1, x19
101438164: 52800022    	mov	w2, #0x1                ; =1
101438168: 940083a8    	bl	0x101459008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbb80>
10143816c: d10006b5    	sub	x21, x21, #0x1
101438170: 52800034    	mov	w20, #0x1               ; =1
101438174: 52800116    	mov	w22, #0x8               ; =8
101438178: 14000006    	b	0x101438190 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4524>
10143817c: 91000694    	add	x20, x20, #0x1
101438180: d10006b5    	sub	x21, x21, #0x1
101438184: 910022d6    	add	x22, x22, #0x8
101438188: b10006bf    	cmn	x21, #0x1
10143818c: 54001c80    	b.eq	0x10143851c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x48b0>
101438190: 8b1602e9    	add	x9, x23, x22
101438194: a97fa129    	ldp	x9, x8, [x9, #-0x8]
101438198: f9400902    	ldr	x2, [x8, #0x10]
10143819c: f940092a    	ldr	x10, [x9, #0x10]
1014381a0: eb0a005f    	cmp	x2, x10
1014381a4: 54fffec1    	b.ne	0x10143817c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4510>
1014381a8: f9400521    	ldr	x1, [x9, #0x8]
1014381ac: f9400500    	ldr	x0, [x8, #0x8]
1014381b0: 941a469b    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
1014381b4: 35fffe40    	cbnz	w0, 0x10143817c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4510>
1014381b8: 91000688    	add	x8, x20, #0x1
1014381bc: eb13011f    	cmp	x8, x19
1014381c0: 54001a02    	b.hs	0x101438500 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4894>
1014381c4: 910022d3    	add	x19, x22, #0x8
1014381c8: aa1903f7    	mov	x23, x25
1014381cc: 14000007    	b	0x1014381e8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x457c>
1014381d0: f90002d7    	str	x23, [x22]
1014381d4: 91000694    	add	x20, x20, #0x1
1014381d8: 91002273    	add	x19, x19, #0x8
1014381dc: f10006b5    	subs	x21, x21, #0x1
1014381e0: aa1903f7    	mov	x23, x25
1014381e4: 540019a0    	b.eq	0x101438518 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x48ac>
1014381e8: 8b140ef6    	add	x22, x23, x20, lsl #3
1014381ec: f8736af7    	ldr	x23, [x23, x19]
1014381f0: f85f82c8    	ldur	x8, [x22, #-0x8]
1014381f4: f9400ae2    	ldr	x2, [x23, #0x10]
1014381f8: f9400909    	ldr	x9, [x8, #0x10]
1014381fc: eb09005f    	cmp	x2, x9
101438200: 54fffe81    	b.ne	0x1014381d0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4564>
101438204: f9400501    	ldr	x1, [x8, #0x8]
101438208: f94006e0    	ldr	x0, [x23, #0x8]
10143820c: 941a4684    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101438210: 35fffe00    	cbnz	w0, 0x1014381d0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4564>
101438214: 17fffff1    	b	0x1014381d8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x456c>
101438218: 910e43e8    	add	x8, sp, #0x390
10143821c: 910e43e0    	add	x0, sp, #0x390
101438220: 91008102    	add	x2, x8, #0x20
101438224: aa1c03e1    	mov	x1, x28
101438228: 52800023    	mov	w3, #0x1                ; =1
10143822c: 9419ef56    	bl	0x101ab3f84 <__ZN9hashbrown3raw21RawTable$LT$T$C$A$GT$14reserve_rehash17h0bb185934a91215dE>
101438230: f94013e8    	ldr	x8, [sp, #0x20]
101438234: 91004114    	add	x20, x8, #0x10
101438238: aa1c03f5    	mov	x21, x28
10143823c: f9406bfb    	ldr	x27, [sp, #0xd0]
101438240: f94003f7    	ldr	x23, [sp]
101438244: a97f8a81    	ldp	x1, x2, [x20, #-0x8]
101438248: 910e43e0    	add	x0, sp, #0x390
10143824c: 9400f98e    	bl	0x101476884 <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xc18>
101438250: 9100c294    	add	x20, x20, #0x30
101438254: f10006b5    	subs	x21, x21, #0x1
101438258: 54ffff61    	b.ne	0x101438244 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x45d8>
10143825c: 17fff689    	b	0x101435c80 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2014>
101438260: f100567f    	cmp	x19, #0x15
101438264: 54002142    	b.hs	0x10143868c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4a20>
101438268: 910a43e2    	add	x2, sp, #0x290
10143826c: aa1703e0    	mov	x0, x23
101438270: aa1303e1    	mov	x1, x19
101438274: 94008535    	bl	0x101459748 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc2c0>
101438278: f9406bfb    	ldr	x27, [sp, #0xd0]
10143827c: 17fff68b    	b	0x101435ca8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x203c>
101438280: 940e1dc2    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101438284: f90006c1    	str	x1, [x22, #0x8]
101438288: 52800028    	mov	w8, #0x1                ; =1
10143828c: 390042c8    	strb	w8, [x22, #0x10]
101438290: 17fff68c    	b	0x101435cc0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2054>
101438294: 910e43e0    	add	x0, sp, #0x390
101438298: 91008102    	add	x2, x8, #0x20
10143829c: aa1503e1    	mov	x1, x21
1014382a0: 52800023    	mov	w3, #0x1                ; =1
1014382a4: 9419efc1    	bl	0x101ab41a8 <__ZN9hashbrown3raw21RawTable$LT$T$C$A$GT$14reserve_rehash17h8ad6e75f269338c4E>
1014382a8: f9404ff4    	ldr	x20, [sp, #0x98]
1014382ac: aa1503f6    	mov	x22, x21
1014382b0: f9406bfb    	ldr	x27, [sp, #0xd0]
1014382b4: f94003f7    	ldr	x23, [sp]
1014382b8: 910a43e8    	add	x8, sp, #0x290
1014382bc: aa1403e0    	mov	x0, x20
1014382c0: 940f5bc3    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1014382c4: 910e43e0    	add	x0, sp, #0x390
1014382c8: 910a43e1    	add	x1, sp, #0x290
1014382cc: 9400fa20    	bl	0x101476b4c <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xee0>
1014382d0: 9101a294    	add	x20, x20, #0x68
1014382d4: f10006d6    	subs	x22, x22, #0x1
1014382d8: 54ffff01    	b.ne	0x1014382b8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x464c>
1014382dc: 17fff682    	b	0x101435ce4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2078>
1014382e0: 910a43e0    	add	x0, sp, #0x290
1014382e4: aa1603e1    	mov	x1, x22
1014382e8: aa1403e2    	mov	x2, x20
1014382ec: 52800103    	mov	w3, #0x8                ; =8
1014382f0: 52800d04    	mov	w4, #0x68               ; =104
1014382f4: 9417c157    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1014382f8: f94153f6    	ldr	x22, [sp, #0x2a0]
1014382fc: f9406bfb    	ldr	x27, [sp, #0xd0]
101438300: 17fff553    	b	0x10143584c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1be0>
101438304: 910c03e0    	add	x0, sp, #0x300
101438308: aa1603e1    	mov	x1, x22
10143830c: aa1403e2    	mov	x2, x20
101438310: 52800103    	mov	w3, #0x8                ; =8
101438314: 52800d04    	mov	w4, #0x68               ; =104
101438318: 9417c14e    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10143831c: f9418bf6    	ldr	x22, [sp, #0x310]
101438320: f9406bfb    	ldr	x27, [sp, #0xd0]
101438324: 17fff82c    	b	0x1014363d4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2768>
101438328: 940e1d98    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
10143832c: f9000681    	str	x1, [x20, #0x8]
101438330: 52800028    	mov	w8, #0x1                ; =1
101438334: 39004288    	strb	w8, [x20, #0x10]
101438338: f9406bfb    	ldr	x27, [sp, #0xd0]
10143833c: f9405ffc    	ldr	x28, [sp, #0xb8]
101438340: 17fff57c    	b	0x101435930 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1cc4>
101438344: 910e43e8    	add	x8, sp, #0x390
101438348: 910e43e0    	add	x0, sp, #0x390
10143834c: 91008102    	add	x2, x8, #0x20
101438350: aa1603e1    	mov	x1, x22
101438354: 52800023    	mov	w3, #0x1                ; =1
101438358: 9419ef0b    	bl	0x101ab3f84 <__ZN9hashbrown3raw21RawTable$LT$T$C$A$GT$14reserve_rehash17h0bb185934a91215dE>
10143835c: d2800014    	mov	x20, #0x0               ; =0
101438360: 52800d17    	mov	w23, #0x68              ; =104
101438364: 9b174e88    	madd	x8, x20, x23, x19
101438368: a9408901    	ldp	x1, x2, [x8, #0x8]
10143836c: b4000482    	cbz	x2, 0x1014383fc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4790>
101438370: 8b020028    	add	x8, x1, x2
101438374: aa0803e9    	mov	x9, x8
101438378: 14000004    	b	0x101438388 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x471c>
10143837c: aa0903e8    	mov	x8, x9
101438380: eb09003f    	cmp	x1, x9
101438384: 540003c0    	b.eq	0x1014383fc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4790>
101438388: 38dffd2a    	ldrsb	w10, [x9, #-0x1]!
10143838c: 36f802ea    	tbz	w10, #0x1f, 0x1014383e8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x477c>
101438390: aa0803e9    	mov	x9, x8
101438394: 38dfed2b    	ldrsb	w11, [x9, #-0x2]!
101438398: 3101017f    	cmn	w11, #0x40
10143839c: 5400016a    	b.ge	0x1014383c8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x475c>
1014383a0: aa0803e9    	mov	x9, x8
1014383a4: 38dfdd2c    	ldrsb	w12, [x9, #-0x3]!
1014383a8: 3101019f    	cmn	w12, #0x40
1014383ac: 5400012a    	b.ge	0x1014383d0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4764>
1014383b0: 12001d8c    	and	w12, w12, #0xff
1014383b4: aa0803e9    	mov	x9, x8
1014383b8: 385fcd2d    	ldrb	w13, [x9, #-0x4]!
1014383bc: 1200158c    	and	w12, w12, #0x3f
1014383c0: 331a09ac    	bfi	w12, w13, #6, #3
1014383c4: 14000004    	b	0x1014383d4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4768>
1014383c8: 1200116b    	and	w11, w11, #0x1f
1014383cc: 14000005    	b	0x1014383e0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4774>
1014383d0: 12000d8c    	and	w12, w12, #0xf
1014383d4: 12001d6b    	and	w11, w11, #0xff
1014383d8: 1200156b    	and	w11, w11, #0x3f
1014383dc: 2a0c196b    	orr	w11, w11, w12, lsl #6
1014383e0: 1200154a    	and	w10, w10, #0x3f
1014383e4: 2a0b194a    	orr	w10, w10, w11, lsl #6
1014383e8: 7101715f    	cmp	w10, #0x5c
1014383ec: 54fffc80    	b.eq	0x10143837c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4710>
1014383f0: 7100bd5f    	cmp	w10, #0x2f
1014383f4: 54fffc40    	b.eq	0x10143837c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4710>
1014383f8: cb010102    	sub	x2, x8, x1
1014383fc: 910e43e0    	add	x0, sp, #0x390
101438400: 9400f921    	bl	0x101476884 <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xc18>
101438404: 91000694    	add	x20, x20, #0x1
101438408: eb16029f    	cmp	x20, x22
10143840c: 54fffac1    	b.ne	0x101438364 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x46f8>
101438410: f941cbe8    	ldr	x8, [sp, #0x390]
101438414: f90057e8    	str	x8, [sp, #0xa8]
101438418: f941cfe8    	ldr	x8, [sp, #0x398]
10143841c: f90067e8    	str	x8, [sp, #0xc8]
101438420: f941d7e8    	ldr	x8, [sp, #0x3a8]
101438424: f941dbe9    	ldr	x9, [sp, #0x3b0]
101438428: f9003fe9    	str	x9, [sp, #0x78]
10143842c: f941dfe9    	ldr	x9, [sp, #0x3b8]
101438430: f9006fe9    	str	x9, [sp, #0xd8]
101438434: f100011f    	cmp	x8, #0x0
101438438: 1a9f17e8    	cset	w8, eq
10143843c: b900c3e8    	str	w8, [sp, #0xc0]
101438440: f9406bfb    	ldr	x27, [sp, #0xd0]
101438444: f9405ffc    	ldr	x28, [sp, #0xb8]
101438448: f94077ea    	ldr	x10, [sp, #0xe8]
10143844c: f940d148    	ldr	x8, [x10, #0x1a0]
101438450: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101438454: eb09011f    	cmp	x8, x9
101438458: 54fea981    	b.ne	0x101435988 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1d1c>
10143845c: 17fff556    	b	0x1014359b4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1d48>
101438460: 9108c3e0    	add	x0, sp, #0x230
101438464: aa1503e1    	mov	x1, x21
101438468: aa1403e2    	mov	x2, x20
10143846c: 52800103    	mov	w3, #0x8                ; =8
101438470: 52800d04    	mov	w4, #0x68               ; =104
101438474: 9417c0f7    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101438478: f94123f5    	ldr	x21, [sp, #0x240]
10143847c: f9411feb    	ldr	x11, [sp, #0x238]
101438480: f9406bfb    	ldr	x27, [sp, #0xd0]
101438484: f9405ffc    	ldr	x28, [sp, #0xb8]
101438488: 17fff564    	b	0x101435a18 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1dac>
10143848c: 910c03e0    	add	x0, sp, #0x300
101438490: aa1603e1    	mov	x1, x22
101438494: aa1803f4    	mov	x20, x24
101438498: aa1803e2    	mov	x2, x24
10143849c: 52800103    	mov	w3, #0x8                ; =8
1014384a0: 52800d04    	mov	w4, #0x68               ; =104
1014384a4: 9417c0eb    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1014384a8: f9418bf6    	ldr	x22, [sp, #0x310]
1014384ac: f9406bfb    	ldr	x27, [sp, #0xd0]
1014384b0: aa1403f8    	mov	x24, x20
1014384b4: 17fffb91    	b	0x1014372f8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x368c>
1014384b8: 910c03e0    	add	x0, sp, #0x300
1014384bc: aa1403e1    	mov	x1, x20
1014384c0: aa1303e2    	mov	x2, x19
1014384c4: 52800103    	mov	w3, #0x8                ; =8
1014384c8: 52800d04    	mov	w4, #0x68               ; =104
1014384cc: 9417c0e1    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1014384d0: f9418bf4    	ldr	x20, [sp, #0x310]
1014384d4: f9406bfb    	ldr	x27, [sp, #0xd0]
1014384d8: 17fffbac    	b	0x101437388 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x371c>
1014384dc: 910c03e0    	add	x0, sp, #0x300
1014384e0: aa1603e1    	mov	x1, x22
1014384e4: aa1403e2    	mov	x2, x20
1014384e8: 52800103    	mov	w3, #0x8                ; =8
1014384ec: 52800d04    	mov	w4, #0x68               ; =104
1014384f0: 9417c0d8    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1014384f4: f9418bf6    	ldr	x22, [sp, #0x310]
1014384f8: f9406bfb    	ldr	x27, [sp, #0xd0]
1014384fc: 17fffc37    	b	0x1014375d8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x396c>
101438500: aa1403f3    	mov	x19, x20
101438504: f9406bfb    	ldr	x27, [sp, #0xd0]
101438508: f9402fe1    	ldr	x1, [sp, #0x58]
10143850c: aa1803f6    	mov	x22, x24
101438510: aa1903f7    	mov	x23, x25
101438514: 17fff5b6    	b	0x101435bec <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1f80>
101438518: aa1403f3    	mov	x19, x20
10143851c: f9406bfb    	ldr	x27, [sp, #0xd0]
101438520: f9402fe1    	ldr	x1, [sp, #0x58]
101438524: aa1803f6    	mov	x22, x24
101438528: 17fff5b1    	b	0x101435bec <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x1f80>
10143852c: 910c03e0    	add	x0, sp, #0x300
101438530: d2800001    	mov	x1, #0x0                ; =0
101438534: aa1403e2    	mov	x2, x20
101438538: 52800103    	mov	w3, #0x8                ; =8
10143853c: 52800d04    	mov	w4, #0x68               ; =104
101438540: 9417c0c4    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101438544: f9418bf7    	ldr	x23, [sp, #0x310]
101438548: f94187e8    	ldr	x8, [sp, #0x308]
10143854c: f9406bfb    	ldr	x27, [sp, #0xd0]
101438550: 17fffa85    	b	0x101436f64 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x32f8>
101438554: 940e1d0d    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101438558: f9000661    	str	x1, [x19, #0x8]
10143855c: 52800028    	mov	w8, #0x1                ; =1
101438560: 39004268    	strb	w8, [x19, #0x10]
101438564: 17fffcb5    	b	0x101437838 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3bcc>
101438568: f100573f    	cmp	x25, #0x15
10143856c: 54000be2    	b.hs	0x1014386e8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4a7c>
101438570: 9108c3e2    	add	x2, sp, #0x230
101438574: aa1703e0    	mov	x0, x23
101438578: aa1903e1    	mov	x1, x25
10143857c: 94008430    	bl	0x10145963c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc1b4>
101438580: 52800e08    	mov	w8, #0x70               ; =112
101438584: 9b085f28    	madd	x8, x25, x8, x23
101438588: 9bd47e69    	umulh	x9, x19, x20
10143858c: d345fd3b    	lsr	x27, x9, #5
101438590: 17fffd40    	b	0x101437a90 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3e24>
101438594: f100571f    	cmp	x24, #0x15
101438598: 54000ba2    	b.hs	0x10143870c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4aa0>
10143859c: f9403fe0    	ldr	x0, [sp, #0x78]
1014385a0: f94077e1    	ldr	x1, [sp, #0xe8]
1014385a4: 9400835e    	bl	0x10145931c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbe94>
1014385a8: 52800f08    	mov	w8, #0x78               ; =120
1014385ac: f9403ffc    	ldr	x28, [sp, #0x78]
1014385b0: f94077f8    	ldr	x24, [sp, #0xe8]
1014385b4: 9b087315    	madd	x21, x24, x8, x28
1014385b8: 17fff9f6    	b	0x101436d90 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3124>
1014385bc: 9108c3e0    	add	x0, sp, #0x230
1014385c0: d2800001    	mov	x1, #0x0                ; =0
1014385c4: aa1803e2    	mov	x2, x24
1014385c8: 52800103    	mov	w3, #0x8                ; =8
1014385cc: 52800d04    	mov	w4, #0x68               ; =104
1014385d0: 9417c0a0    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1014385d4: f94123fa    	ldr	x26, [sp, #0x240]
1014385d8: f9411ff8    	ldr	x24, [sp, #0x238]
1014385dc: 3607bef7    	tbz	w23, #0x0, 0x101437db8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x414c>
1014385e0: 17fffe06    	b	0x101437df8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x418c>
1014385e4: 910c03e0    	add	x0, sp, #0x300
1014385e8: aa1303e1    	mov	x1, x19
1014385ec: aa1503e2    	mov	x2, x21
1014385f0: 52800103    	mov	w3, #0x8                ; =8
1014385f4: 52800d04    	mov	w4, #0x68               ; =104
1014385f8: 9417c096    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1014385fc: f9418bf3    	ldr	x19, [sp, #0x310]
101438600: f94187f7    	ldr	x23, [sp, #0x308]
101438604: f9406bfb    	ldr	x27, [sp, #0xd0]
101438608: 17fffb99    	b	0x10143746c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3800>
10143860c: 52800100    	mov	w0, #0x8                ; =8
101438610: aa1403e1    	mov	x1, x20
101438614: 941a2b4a    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
101438618: 14000049    	b	0x10143873c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ad0>
10143861c: 910c03e0    	add	x0, sp, #0x300
101438620: d2800001    	mov	x1, #0x0                ; =0
101438624: aa1403e2    	mov	x2, x20
101438628: 52800103    	mov	w3, #0x8                ; =8
10143862c: 52800d04    	mov	w4, #0x68               ; =104
101438630: 9417c088    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101438634: f9418bf7    	ldr	x23, [sp, #0x310]
101438638: f94187e8    	ldr	x8, [sp, #0x308]
10143863c: f9406bfb    	ldr	x27, [sp, #0xd0]
101438640: 17fff7ce    	b	0x101436578 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x290c>
101438644: 52800020    	mov	w0, #0x1                ; =1
101438648: aa1303e1    	mov	x1, x19
10143864c: 941a2b4a    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101438650: 1400003b    	b	0x10143873c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ad0>
101438654: 52800100    	mov	w0, #0x8                ; =8
101438658: 52800c01    	mov	w1, #0x60               ; =96
10143865c: 941a2b46    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101438660: 14000037    	b	0x10143873c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ad0>
101438664: 52800100    	mov	w0, #0x8                ; =8
101438668: 52800401    	mov	w1, #0x20               ; =32
10143866c: 941a2b42    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101438670: 14000033    	b	0x10143873c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ad0>
101438674: d10207a2    	sub	x2, x29, #0x81
101438678: aa1903f7    	mov	x23, x25
10143867c: aa1903e0    	mov	x0, x25
101438680: aa1303e1    	mov	x1, x19
101438684: 9400baf5    	bl	0x101467258 <__ZN4core5slice4sort8unstable7ipnsort17heb70b66ea996a7cdE>
101438688: 17fffeb9    	b	0x10143816c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4500>
10143868c: 910e43e2    	add	x2, sp, #0x390
101438690: aa1703e0    	mov	x0, x23
101438694: aa1303e1    	mov	x1, x19
101438698: 9400872d    	bl	0x10145a34c <__ZN4core5slice4sort6stable14driftsort_main17hae02483e31bbae65E>
10143869c: f9406bfb    	ldr	x27, [sp, #0xd0]
1014386a0: 17fff582    	b	0x101435ca8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x203c>
1014386a4: 52800100    	mov	w0, #0x8                ; =8
1014386a8: aa1903e1    	mov	x1, x25
1014386ac: 941a2b32    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014386b0: 14000023    	b	0x10143873c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ad0>
1014386b4: 52800100    	mov	w0, #0x8                ; =8
1014386b8: aa1303e1    	mov	x1, x19
1014386bc: 941a2b2e    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014386c0: 1400001f    	b	0x10143873c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ad0>
1014386c4: 52800100    	mov	w0, #0x8                ; =8
1014386c8: 17fffc76    	b	0x1014378a0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x3c34>
1014386cc: 52800100    	mov	w0, #0x8                ; =8
1014386d0: f9402fe1    	ldr	x1, [sp, #0x58]
1014386d4: 17fff892    	b	0x10143691c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x2cb0>
1014386d8: 52800020    	mov	w0, #0x1                ; =1
1014386dc: aa1b03e1    	mov	x1, x27
1014386e0: 941a2b25    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014386e4: 14000016    	b	0x10143873c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ad0>
1014386e8: 910e43e2    	add	x2, sp, #0x390
1014386ec: aa1703e0    	mov	x0, x23
1014386f0: aa1903e1    	mov	x1, x25
1014386f4: 94008559    	bl	0x101459c58 <__ZN4core5slice4sort6stable14driftsort_main17h388d987516566555E>
1014386f8: 17ffffa2    	b	0x101438580 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4914>
1014386fc: 52800100    	mov	w0, #0x8                ; =8
101438700: 52803401    	mov	w1, #0x1a0              ; =416
101438704: 941a2b1c    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101438708: 1400000d    	b	0x10143873c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ad0>
10143870c: 910e43e2    	add	x2, sp, #0x390
101438710: f9403fe0    	ldr	x0, [sp, #0x78]
101438714: f94077e1    	ldr	x1, [sp, #0xe8]
101438718: 9400850d    	bl	0x101459b4c <__ZN4core5slice4sort6stable14driftsort_main17h371c44edf376efdaE>
10143871c: 17ffffa3    	b	0x1014385a8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x493c>
101438720: 52800100    	mov	w0, #0x8                ; =8
101438724: 52800401    	mov	w1, #0x20               ; =32
101438728: 941a2b13    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10143872c: 14000004    	b	0x10143873c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ad0>
101438730: 52800020    	mov	w0, #0x1                ; =1
101438734: aa1503e1    	mov	x1, x21
101438738: 941a2b0f    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10143873c: d4200020    	brk	#0x1
101438740: aa0003f3    	mov	x19, x0
101438744: 9107a3e0    	add	x0, sp, #0x1e8
101438748: 940078bf    	bl	0x101456a44 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x95bc>
10143874c: 140001cc    	b	0x101438e7c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5210>
101438750: 1400000e    	b	0x101438788 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4b1c>
101438754: 1400000d    	b	0x101438788 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4b1c>
101438758: aa0003f3    	mov	x19, x0
10143875c: 910e43e0    	add	x0, sp, #0x390
101438760: 940069e6    	bl	0x101452ef8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5a70>
101438764: b4002936    	cbz	x22, 0x101438c88 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x501c>
101438768: d37df2c1    	lsl	x1, x22, #3
10143876c: aa1403e0    	mov	x0, x20
101438770: 52800102    	mov	w2, #0x8                ; =8
101438774: 97d997da    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438778: 14000144    	b	0x101438c88 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x501c>
10143877c: 14000003    	b	0x101438788 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4b1c>
101438780: 14000002    	b	0x101438788 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4b1c>
101438784: 14000001    	b	0x101438788 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4b1c>
101438788: aa0003f3    	mov	x19, x0
10143878c: 910e43e0    	add	x0, sp, #0x390
101438790: 94006972    	bl	0x101452d58 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x58d0>
101438794: 140000c8    	b	0x101438ab4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e48>
101438798: aa0003f3    	mov	x19, x0
10143879c: 910e43e0    	add	x0, sp, #0x390
1014387a0: 9400696e    	bl	0x101452d58 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x58d0>
1014387a4: 1400014f    	b	0x101438ce0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5074>
1014387a8: 14000015    	b	0x1014387fc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4b90>
1014387ac: aa0003f3    	mov	x19, x0
1014387b0: 14000060    	b	0x101438930 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4cc4>
1014387b4: aa0003f3    	mov	x19, x0
1014387b8: 910e43e0    	add	x0, sp, #0x390
1014387bc: 94006967    	bl	0x101452d58 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x58d0>
1014387c0: 910c03e0    	add	x0, sp, #0x300
1014387c4: 14000121    	b	0x101438c48 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4fdc>
1014387c8: aa0003f3    	mov	x19, x0
1014387cc: 910e43e0    	add	x0, sp, #0x390
1014387d0: 94006962    	bl	0x101452d58 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x58d0>
1014387d4: 140000a8    	b	0x101438a74 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e08>
1014387d8: 1400001b    	b	0x101438844 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4bd8>
1014387dc: 1400000c    	b	0x10143880c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ba0>
1014387e0: aa0003f3    	mov	x19, x0
1014387e4: 1400000e    	b	0x10143881c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4bb0>
1014387e8: aa0003f3    	mov	x19, x0
1014387ec: 14000019    	b	0x101438850 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4be4>
1014387f0: 1400001e    	b	0x101438868 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4bfc>
1014387f4: aa0003f3    	mov	x19, x0
1014387f8: 1400001f    	b	0x101438874 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4c08>
1014387fc: aa0003f3    	mov	x19, x0
101438800: f941cbe0    	ldr	x0, [sp, #0x390]
101438804: f941cfe1    	ldr	x1, [sp, #0x398]
101438808: 14000049    	b	0x10143892c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4cc0>
10143880c: aa0003f3    	mov	x19, x0
101438810: f941cbe0    	ldr	x0, [sp, #0x390]
101438814: f941cfe1    	ldr	x1, [sp, #0x398]
101438818: 97ebe53f    	bl	0x100f31d14 <__ZN200_$LT$otty_sync_dotfiles..catalog.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_sync_dotfiles..catalog..CatalogAppSpec$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hace6feb1294ba67fE+0xd43c>
10143881c: 910863e0    	add	x0, sp, #0x218
101438820: 97e649c0    	bl	0x100dcaf20 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf92162d8f5241af7E+0xe060>
101438824: 140000e2    	b	0x101438bac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f40>
101438828: aa0003f3    	mov	x19, x0
10143882c: b400137b    	cbz	x27, 0x101438a98 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e2c>
101438830: aa1703e0    	mov	x0, x23
101438834: aa1b03e1    	mov	x1, x27
101438838: 1400002e    	b	0x1014388f0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4c84>
10143883c: aa0003f3    	mov	x19, x0
101438840: 1400001f    	b	0x1014388bc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4c50>
101438844: aa0003f3    	mov	x19, x0
101438848: 910e43e0    	add	x0, sp, #0x390
10143884c: 97d44084    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
101438850: 52800034    	mov	w20, #0x1               ; =1
101438854: 140000d0    	b	0x101438b94 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f28>
101438858: aa0003f3    	mov	x19, x0
10143885c: 910c83e0    	add	x0, sp, #0x320
101438860: 97db139e    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101438864: 14000065    	b	0x1014389f8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4d8c>
101438868: aa0003f3    	mov	x19, x0
10143886c: 910e43e0    	add	x0, sp, #0x390
101438870: 97d4407b    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
101438874: 910483e0    	add	x0, sp, #0x120
101438878: 9400757b    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10143887c: 9104e3e0    	add	x0, sp, #0x138
101438880: 140000f2    	b	0x101438c48 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4fdc>
101438884: aa0003f3    	mov	x19, x0
101438888: 910e43e0    	add	x0, sp, #0x390
10143888c: 97db1393    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101438890: 14000082    	b	0x101438a98 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e2c>
101438894: aa0003f3    	mov	x19, x0
101438898: 14000058    	b	0x1014389f8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4d8c>
10143889c: 1400007e    	b	0x101438a94 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e28>
1014388a0: aa0003f3    	mov	x19, x0
1014388a4: f941cbe8    	ldr	x8, [sp, #0x390]
1014388a8: b40000a8    	cbz	x8, 0x1014388bc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4c50>
1014388ac: f941cfe0    	ldr	x0, [sp, #0x398]
1014388b0: d37df101    	lsl	x1, x8, #3
1014388b4: 52800102    	mov	w2, #0x8                ; =8
1014388b8: 97d99789    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014388bc: 910a43e0    	add	x0, sp, #0x290
1014388c0: 94006472    	bl	0x101451a88 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x4600>
1014388c4: 140000f1    	b	0x101438c88 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x501c>
1014388c8: aa0003f3    	mov	x19, x0
1014388cc: b40000bb    	cbz	x27, 0x1014388e0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4c74>
1014388d0: aa1703e0    	mov	x0, x23
1014388d4: aa1b03e1    	mov	x1, x27
1014388d8: 52800022    	mov	w2, #0x1                ; =1
1014388dc: 97d99780    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014388e0: f240fabf    	tst	x21, #0x7fffffffffffffff
1014388e4: 54000da0    	b.eq	0x101438a98 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e2c>
1014388e8: f9402fe0    	ldr	x0, [sp, #0x58]
1014388ec: aa1503e1    	mov	x1, x21
1014388f0: 52800022    	mov	w2, #0x1                ; =1
1014388f4: 97d9977a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014388f8: 14000068    	b	0x101438a98 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e2c>
1014388fc: aa0003f3    	mov	x19, x0
101438900: 9105c3e0    	add	x0, sp, #0x170
101438904: 14000089    	b	0x101438b28 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ebc>
101438908: aa0003f3    	mov	x19, x0
10143890c: 14000088    	b	0x101438b2c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4ec0>
101438910: aa0003f3    	mov	x19, x0
101438914: 14000173    	b	0x101438ee0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5274>
101438918: aa0003f3    	mov	x19, x0
10143891c: 140000e8    	b	0x101438cbc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5050>
101438920: aa0003f3    	mov	x19, x0
101438924: f94057e0    	ldr	x0, [sp, #0xa8]
101438928: f94067e1    	ldr	x1, [sp, #0xc8]
10143892c: 97ebe4fa    	bl	0x100f31d14 <__ZN200_$LT$otty_sync_dotfiles..catalog.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_sync_dotfiles..catalog..CatalogAppSpec$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hace6feb1294ba67fE+0xd43c>
101438930: 9107a3e0    	add	x0, sp, #0x1e8
101438934: 9400754c    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101438938: 14000045    	b	0x101438a4c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4de0>
10143893c: aa0003f3    	mov	x19, x0
101438940: f941cbe1    	ldr	x1, [sp, #0x390]
101438944: b4000361    	cbz	x1, 0x1014389b0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4d44>
101438948: aa1503e0    	mov	x0, x21
10143894c: 52800022    	mov	w2, #0x1                ; =1
101438950: 97d99763    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438954: 14000017    	b	0x1014389b0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4d44>
101438958: aa0003f3    	mov	x19, x0
10143895c: f900d7f4    	str	x20, [sp, #0x1a8]
101438960: 910e43e0    	add	x0, sp, #0x390
101438964: 97db135d    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101438968: 910683e0    	add	x0, sp, #0x1a0
10143896c: 940068fb    	bl	0x101452d58 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x58d0>
101438970: 140000b3    	b	0x101438c3c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4fd0>
101438974: f90003f7    	str	x23, [sp]
101438978: aa0003f3    	mov	x19, x0
10143897c: 1400008c    	b	0x101438bac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f40>
101438980: aa0003f3    	mov	x19, x0
101438984: 910e43e0    	add	x0, sp, #0x390
101438988: 97db1354    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10143898c: 14000019    	b	0x1014389f0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4d84>
101438990: aa0003f3    	mov	x19, x0
101438994: b40003d6    	cbz	x22, 0x101438a0c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4da0>
101438998: aa1703e0    	mov	x0, x23
10143899c: aa1603e1    	mov	x1, x22
1014389a0: 52800022    	mov	w2, #0x1                ; =1
1014389a4: 97d9974e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014389a8: 14000019    	b	0x101438a0c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4da0>
1014389ac: aa0003f3    	mov	x19, x0
1014389b0: 910c83e0    	add	x0, sp, #0x320
1014389b4: 9400752c    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
1014389b8: 140000d8    	b	0x101438d18 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50ac>
1014389bc: aa0003f3    	mov	x19, x0
1014389c0: b4001b16    	cbz	x22, 0x101438d20 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50b4>
1014389c4: aa1703e0    	mov	x0, x23
1014389c8: aa1603e1    	mov	x1, x22
1014389cc: 52800022    	mov	w2, #0x1                ; =1
1014389d0: 97d99743    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014389d4: 140000d3    	b	0x101438d20 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50b4>
1014389d8: aa0003f3    	mov	x19, x0
1014389dc: 140000c1    	b	0x101438ce0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5074>
1014389e0: aa0003f3    	mov	x19, x0
1014389e4: 910483e0    	add	x0, sp, #0x120
1014389e8: 14000098    	b	0x101438c48 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4fdc>
1014389ec: aa0003f3    	mov	x19, x0
1014389f0: 9107a3e0    	add	x0, sp, #0x1e8
1014389f4: 9400751c    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
1014389f8: f940d3e1    	ldr	x1, [sp, #0x1a0]
1014389fc: b40005c1    	cbz	x1, 0x101438ab4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e48>
101438a00: f940d7e0    	ldr	x0, [sp, #0x1a8]
101438a04: 1400002a    	b	0x101438aac <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e40>
101438a08: aa0003f3    	mov	x19, x0
101438a0c: 910c83e0    	add	x0, sp, #0x320
101438a10: 140000c3    	b	0x101438d1c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50b0>
101438a14: aa0003f3    	mov	x19, x0
101438a18: 14000134    	b	0x101438ee8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x527c>
101438a1c: aa0003f3    	mov	x19, x0
101438a20: 14000017    	b	0x101438a7c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e10>
101438a24: aa0003f3    	mov	x19, x0
101438a28: 1400007e    	b	0x101438c20 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4fb4>
101438a2c: aa0003f3    	mov	x19, x0
101438a30: f9414be1    	ldr	x1, [sp, #0x290]
101438a34: b4001721    	cbz	x1, 0x101438d18 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50ac>
101438a38: f9414fe0    	ldr	x0, [sp, #0x298]
101438a3c: 140000b5    	b	0x101438d10 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50a4>
101438a40: aa0003f3    	mov	x19, x0
101438a44: 14000079    	b	0x101438c28 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4fbc>
101438a48: aa0003f3    	mov	x19, x0
101438a4c: f94053f4    	ldr	x20, [sp, #0xa0]
101438a50: 140000ab    	b	0x101438cfc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5090>
101438a54: aa0003f3    	mov	x19, x0
101438a58: f941cbe1    	ldr	x1, [sp, #0x390]
101438a5c: b4000561    	cbz	x1, 0x101438b08 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e9c>
101438a60: f941cfe0    	ldr	x0, [sp, #0x398]
101438a64: 52800022    	mov	w2, #0x1                ; =1
101438a68: 97d9971d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438a6c: 14000027    	b	0x101438b08 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e9c>
101438a70: aa0003f3    	mov	x19, x0
101438a74: 910a43e0    	add	x0, sp, #0x290
101438a78: 940074fb    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101438a7c: f94053f4    	ldr	x20, [sp, #0xa0]
101438a80: 140000a1    	b	0x101438d04 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5098>
101438a84: aa0003f3    	mov	x19, x0
101438a88: 1400006d    	b	0x101438c3c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4fd0>
101438a8c: aa0003f3    	mov	x19, x0
101438a90: 14000009    	b	0x101438ab4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e48>
101438a94: aa0003f3    	mov	x19, x0
101438a98: 9107a3e0    	add	x0, sp, #0x1e8
101438a9c: 940074f2    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101438aa0: f940bbe1    	ldr	x1, [sp, #0x170]
101438aa4: b4000081    	cbz	x1, 0x101438ab4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4e48>
101438aa8: f940bfe0    	ldr	x0, [sp, #0x178]
101438aac: 52800022    	mov	w2, #0x1                ; =1
101438ab0: 97d9970b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438ab4: 910c03e0    	add	x0, sp, #0x300
101438ab8: 940074eb    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101438abc: f9404ff6    	ldr	x22, [sp, #0x98]
101438ac0: f94173e1    	ldr	x1, [sp, #0x2e0]
101438ac4: b5002081    	cbnz	x1, 0x101438ed4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5268>
101438ac8: 14000106    	b	0x101438ee0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5274>
101438acc: aa0003f3    	mov	x19, x0
101438ad0: f9400be8    	ldr	x8, [sp, #0x10]
101438ad4: b5000508    	cbnz	x8, 0x101438b74 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f08>
101438ad8: 1400002c    	b	0x101438b88 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f1c>
101438adc: aa0003f3    	mov	x19, x0
101438ae0: 910e43e0    	add	x0, sp, #0x390
101438ae4: 97db12fd    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101438ae8: f9400be8    	ldr	x8, [sp, #0x10]
101438aec: b5000448    	cbnz	x8, 0x101438b74 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f08>
101438af0: 14000026    	b	0x101438b88 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f1c>
101438af4: aa0003f3    	mov	x19, x0
101438af8: 14000103    	b	0x101438f04 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5298>
101438afc: aa0003f3    	mov	x19, x0
101438b00: 14000086    	b	0x101438d18 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50ac>
101438b04: aa0003f3    	mov	x19, x0
101438b08: 910a43f4    	add	x20, sp, #0x290
101438b0c: 1400006d    	b	0x101438cc0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5054>
101438b10: aa0003f3    	mov	x19, x0
101438b14: 910c03e0    	add	x0, sp, #0x300
101438b18: 1400004c    	b	0x101438c48 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4fdc>
101438b1c: aa0003f3    	mov	x19, x0
101438b20: f9019bfc    	str	x28, [sp, #0x330]
101438b24: 910c83e0    	add	x0, sp, #0x320
101438b28: 97d427f9    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101438b2c: 910c03e0    	add	x0, sp, #0x300
101438b30: 940074cd    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101438b34: f9404ff6    	ldr	x22, [sp, #0x98]
101438b38: f940d3e1    	ldr	x1, [sp, #0x1a0]
101438b3c: b4001c81    	cbz	x1, 0x101438ecc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5260>
101438b40: 1400010d    	b	0x101438f74 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5308>
101438b44: aa0003f3    	mov	x19, x0
101438b48: 9103c3e0    	add	x0, sp, #0xf0
101438b4c: 97d427f0    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101438b50: aa1303e0    	mov	x0, x19
101438b54: 941a42a0    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101438b58: aa0003f3    	mov	x19, x0
101438b5c: f94173e1    	ldr	x1, [sp, #0x2e0]
101438b60: b5000321    	cbnz	x1, 0x101438bc4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f58>
101438b64: f240fb7f    	tst	x27, #0x7fffffffffffffff
101438b68: 54000401    	b.ne	0x101438be8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f7c>
101438b6c: f9400be8    	ldr	x8, [sp, #0x10]
101438b70: b40000c8    	cbz	x8, 0x101438b88 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f1c>
101438b74: f9400be8    	ldr	x8, [sp, #0x10]
101438b78: d37df101    	lsl	x1, x8, #3
101438b7c: f94003e0    	ldr	x0, [sp]
101438b80: 52800102    	mov	w2, #0x8                ; =8
101438b84: 97d996d6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438b88: 910a43e0    	add	x0, sp, #0x290
101438b8c: 97d43fb4    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
101438b90: 52800014    	mov	w20, #0x0               ; =0
101438b94: f9411be0    	ldr	x0, [sp, #0x230]
101438b98: f9411fe1    	ldr	x1, [sp, #0x238]
101438b9c: 97ebe45e    	bl	0x100f31d14 <__ZN200_$LT$otty_sync_dotfiles..catalog.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_sync_dotfiles..catalog..CatalogAppSpec$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hace6feb1294ba67fE+0xd43c>
101438ba0: 910863e0    	add	x0, sp, #0x218
101438ba4: 97e648df    	bl	0x100dcaf20 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf92162d8f5241af7E+0xe060>
101438ba8: 360003d4    	tbz	w20, #0x0, 0x101438c20 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4fb4>
101438bac: f9400be8    	ldr	x8, [sp, #0x10]
101438bb0: b4000388    	cbz	x8, 0x101438c20 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4fb4>
101438bb4: f9400be8    	ldr	x8, [sp, #0x10]
101438bb8: d37df101    	lsl	x1, x8, #3
101438bbc: f94003e0    	ldr	x0, [sp]
101438bc0: 14000016    	b	0x101438c18 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4fac>
101438bc4: f94177e0    	ldr	x0, [sp, #0x2e8]
101438bc8: 52800022    	mov	w2, #0x1                ; =1
101438bcc: 97d996c4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438bd0: f240fb7f    	tst	x27, #0x7fffffffffffffff
101438bd4: 54fffcc0    	b.eq	0x101438b6c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f00>
101438bd8: 14000004    	b	0x101438be8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f7c>
101438bdc: aa0003f3    	mov	x19, x0
101438be0: f240fb7f    	tst	x27, #0x7fffffffffffffff
101438be4: 54fffc40    	b.eq	0x101438b6c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f00>
101438be8: f9404be0    	ldr	x0, [sp, #0x90]
101438bec: aa1b03e1    	mov	x1, x27
101438bf0: 52800022    	mov	w2, #0x1                ; =1
101438bf4: 97d996ba    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438bf8: f9400be8    	ldr	x8, [sp, #0x10]
101438bfc: b5fffbc8    	cbnz	x8, 0x101438b74 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f08>
101438c00: 17ffffe2    	b	0x101438b88 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4f1c>
101438c04: aa0003f3    	mov	x19, x0
101438c08: f9414be8    	ldr	x8, [sp, #0x290]
101438c0c: b40000a8    	cbz	x8, 0x101438c20 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4fb4>
101438c10: f9414fe0    	ldr	x0, [sp, #0x298]
101438c14: d37df101    	lsl	x1, x8, #3
101438c18: 52800102    	mov	w2, #0x8                ; =8
101438c1c: 97d996b0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438c20: 9107a3e0    	add	x0, sp, #0x1e8
101438c24: 97d3d76f    	bl	0x10092e9e0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1b9b8>
101438c28: f940ebe1    	ldr	x1, [sp, #0x1d0]
101438c2c: b4000081    	cbz	x1, 0x101438c3c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x4fd0>
101438c30: f940efe0    	ldr	x0, [sp, #0x1d8]
101438c34: 52800022    	mov	w2, #0x1                ; =1
101438c38: 97d996a9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438c3c: 9105c3e0    	add	x0, sp, #0x170
101438c40: 97d43f87    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
101438c44: 910543e0    	add	x0, sp, #0x150
101438c48: 94007487    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101438c4c: 140000ae    	b	0x101438f04 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5298>
101438c50: aa0003f3    	mov	x19, x0
101438c54: 9108c3e0    	add	x0, sp, #0x230
101438c58: 9400662e    	bl	0x101452510 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5088>
101438c5c: 910e43e0    	add	x0, sp, #0x390
101438c60: 94006883    	bl	0x101452e6c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x59e4>
101438c64: 14000086    	b	0x101438e7c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5210>
101438c68: aa0003f3    	mov	x19, x0
101438c6c: 1400002d    	b	0x101438d20 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50b4>
101438c70: aa0003f3    	mov	x19, x0
101438c74: aa1a03e0    	mov	x0, x26
101438c78: 97db1298    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101438c7c: 9101a35a    	add	x26, x26, #0x68
101438c80: f1000739    	subs	x25, x25, #0x1
101438c84: 54ffff81    	b.ne	0x101438c74 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5008>
101438c88: f94197f4    	ldr	x20, [sp, #0x328]
101438c8c: b4000194    	cbz	x20, 0x101438cbc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5050>
101438c90: f9419ff5    	ldr	x21, [sp, #0x338]
101438c94: b50006b5    	cbnz	x21, 0x101438d68 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50fc>
101438c98: d37bea88    	lsl	x8, x20, #5
101438c9c: 8b140109    	add	x9, x8, x20
101438ca0: b100a521    	adds	x1, x9, #0x29
101438ca4: 540000c0    	b.eq	0x101438cbc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5050>
101438ca8: f94193e9    	ldr	x9, [sp, #0x320]
101438cac: cb080128    	sub	x8, x9, x8
101438cb0: d1008100    	sub	x0, x8, #0x20
101438cb4: 52800102    	mov	w2, #0x8                ; =8
101438cb8: 97d99689    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438cbc: 910b83f4    	add	x20, sp, #0x2e0
101438cc0: b50003db    	cbnz	x27, 0x101438d38 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50cc>
101438cc4: f9400288    	ldr	x8, [x20]
101438cc8: b40000c8    	cbz	x8, 0x101438ce0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5074>
101438ccc: 8b080508    	add	x8, x8, x8, lsl #1
101438cd0: d37df101    	lsl	x1, x8, #3
101438cd4: f9406fe0    	ldr	x0, [sp, #0xd8]
101438cd8: 52800102    	mov	w2, #0x8                ; =8
101438cdc: 97d99680    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438ce0: f94053f4    	ldr	x20, [sp, #0xa0]
101438ce4: f94067f5    	ldr	x21, [sp, #0xc8]
101438ce8: 9108c3e0    	add	x0, sp, #0x230
101438cec: 9400745e    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101438cf0: f94057e0    	ldr	x0, [sp, #0xa8]
101438cf4: aa1503e1    	mov	x1, x21
101438cf8: 97ebe407    	bl	0x100f31d14 <__ZN200_$LT$otty_sync_dotfiles..catalog.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_sync_dotfiles..catalog..CatalogAppSpec$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hace6feb1294ba67fE+0xd43c>
101438cfc: 9105c3e0    	add	x0, sp, #0x170
101438d00: 94007459    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101438d04: b40000b4    	cbz	x20, 0x101438d18 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50ac>
101438d08: f94073e0    	ldr	x0, [sp, #0xe0]
101438d0c: aa1403e1    	mov	x1, x20
101438d10: 52800022    	mov	w2, #0x1                ; =1
101438d14: 97d99672    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438d18: 910683e0    	add	x0, sp, #0x1a0
101438d1c: 97d4277c    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101438d20: f94183e1    	ldr	x1, [sp, #0x300]
101438d24: b4000f01    	cbz	x1, 0x101438f04 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5298>
101438d28: f94187e0    	ldr	x0, [sp, #0x308]
101438d2c: 52800022    	mov	w2, #0x1                ; =1
101438d30: 97d9966b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438d34: 14000074    	b	0x101438f04 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5298>
101438d38: f9406fe8    	ldr	x8, [sp, #0xd8]
101438d3c: 91002115    	add	x21, x8, #0x8
101438d40: 14000004    	b	0x101438d50 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50e4>
101438d44: 910062b5    	add	x21, x21, #0x18
101438d48: f100077b    	subs	x27, x27, #0x1
101438d4c: 54fffbc0    	b.eq	0x101438cc4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5058>
101438d50: f85f82a1    	ldur	x1, [x21, #-0x8]
101438d54: b4ffff81    	cbz	x1, 0x101438d44 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50d8>
101438d58: f94002a0    	ldr	x0, [x21]
101438d5c: 52800022    	mov	w2, #0x1                ; =1
101438d60: 97d9965f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438d64: 17fffff8    	b	0x101438d44 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x50d8>
101438d68: f94193f6    	ldr	x22, [sp, #0x320]
101438d6c: aa1603f7    	mov	x23, x22
101438d70: fc4086e0    	ldr	d0, [x23], #0x8
101438d74: 2e208800    	cmge.8b	v0, v0, #0
101438d78: 9e660008    	fmov	x8, d0
101438d7c: 9201c118    	and	x24, x8, #0x8080808080808080
101438d80: 14000005    	b	0x101438d94 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5128>
101438d84: d1000708    	sub	x8, x24, #0x1
101438d88: 8a180118    	and	x24, x8, x24
101438d8c: d10006b5    	sub	x21, x21, #0x1
101438d90: b4fff855    	cbz	x21, 0x101438c98 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x502c>
101438d94: b50000f8    	cbnz	x24, 0x101438db0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5144>
101438d98: fc4086e0    	ldr	d0, [x23], #0x8
101438d9c: 2e208800    	cmge.8b	v0, v0, #0
101438da0: 9e660008    	fmov	x8, d0
101438da4: d10402d6    	sub	x22, x22, #0x100
101438da8: 9201c118    	and	x24, x8, #0x8080808080808080
101438dac: b4ffff78    	cbz	x24, 0x101438d98 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x512c>
101438db0: dac00308    	rbit	x8, x24
101438db4: dac01108    	clz	x8, x8
101438db8: d37ef508    	lsl	x8, x8, #2
101438dbc: 927b0d08    	and	x8, x8, #0x1e0
101438dc0: cb0802c8    	sub	x8, x22, x8
101438dc4: f85e0101    	ldur	x1, [x8, #-0x20]
101438dc8: b4fffde1    	cbz	x1, 0x101438d84 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5118>
101438dcc: f85e8100    	ldur	x0, [x8, #-0x18]
101438dd0: 52800022    	mov	w2, #0x1                ; =1
101438dd4: 97d99642    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438dd8: 17ffffeb    	b	0x101438d84 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5118>
101438ddc: aa0003f3    	mov	x19, x0
101438de0: 9100c296    	add	x22, x20, #0x30
101438de4: 1400000a    	b	0x101438e0c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x51a0>
101438de8: f94006c0    	ldr	x0, [x22, #0x8]
101438dec: 52800022    	mov	w2, #0x1                ; =1
101438df0: 97d9963b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438df4: f9400ec1    	ldr	x1, [x22, #0x18]
101438df8: f240f83f    	tst	x1, #0x7fffffffffffffff
101438dfc: 54000281    	b.ne	0x101438e4c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x51e0>
101438e00: 9101a2d6    	add	x22, x22, #0x68
101438e04: f100075a    	subs	x26, x26, #0x1
101438e08: 540002e0    	b.eq	0x101438e64 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x51f8>
101438e0c: f85d02c1    	ldur	x1, [x22, #-0x30]
101438e10: b4000081    	cbz	x1, 0x101438e20 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x51b4>
101438e14: f85d82c0    	ldur	x0, [x22, #-0x28]
101438e18: 52800022    	mov	w2, #0x1                ; =1
101438e1c: 97d99630    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438e20: f85e82c1    	ldur	x1, [x22, #-0x18]
101438e24: b4000081    	cbz	x1, 0x101438e34 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x51c8>
101438e28: f85f02c0    	ldur	x0, [x22, #-0x10]
101438e2c: 52800022    	mov	w2, #0x1                ; =1
101438e30: 97d9962b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438e34: f94002c1    	ldr	x1, [x22]
101438e38: f240f83f    	tst	x1, #0x7fffffffffffffff
101438e3c: 54fffd61    	b.ne	0x101438de8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x517c>
101438e40: f9400ec1    	ldr	x1, [x22, #0x18]
101438e44: f240f83f    	tst	x1, #0x7fffffffffffffff
101438e48: 54fffdc0    	b.eq	0x101438e00 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5194>
101438e4c: f94012c0    	ldr	x0, [x22, #0x20]
101438e50: 52800022    	mov	w2, #0x1                ; =1
101438e54: 97d99622    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438e58: 9101a2d6    	add	x22, x22, #0x68
101438e5c: f100075a    	subs	x26, x26, #0x1
101438e60: 54fffd61    	b.ne	0x101438e0c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x51a0>
101438e64: b40000db    	cbz	x27, 0x101438e7c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5210>
101438e68: 52800d08    	mov	w8, #0x68               ; =104
101438e6c: 9b087f61    	mul	x1, x27, x8
101438e70: aa1403e0    	mov	x0, x20
101438e74: 52800102    	mov	w2, #0x8                ; =8
101438e78: 97d99619    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438e7c: f94197f4    	ldr	x20, [sp, #0x328]
101438e80: b4000194    	cbz	x20, 0x101438eb0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5244>
101438e84: f9419ff6    	ldr	x22, [sp, #0x338]
101438e88: b5000836    	cbnz	x22, 0x101438f8c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5320>
101438e8c: d37bea88    	lsl	x8, x20, #5
101438e90: 8b140109    	add	x9, x8, x20
101438e94: b100a521    	adds	x1, x9, #0x29
101438e98: 540000c0    	b.eq	0x101438eb0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5244>
101438e9c: f94193e9    	ldr	x9, [sp, #0x320]
101438ea0: cb080128    	sub	x8, x9, x8
101438ea4: d1008100    	sub	x0, x8, #0x20
101438ea8: 52800102    	mov	w2, #0x8                ; =8
101438eac: 97d9960c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438eb0: a957dbf4    	ldp	x20, x22, [sp, #0x178]
101438eb4: b50003b6    	cbnz	x22, 0x101438f28 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x52bc>
101438eb8: f940bbe8    	ldr	x8, [sp, #0x170]
101438ebc: b50004c8    	cbnz	x8, 0x101438f54 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x52e8>
101438ec0: f9404ff6    	ldr	x22, [sp, #0x98]
101438ec4: f940d3e1    	ldr	x1, [sp, #0x1a0]
101438ec8: b5000561    	cbnz	x1, 0x101438f74 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5308>
101438ecc: f94173e1    	ldr	x1, [sp, #0x2e0]
101438ed0: b4000081    	cbz	x1, 0x101438ee0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5274>
101438ed4: f94177e0    	ldr	x0, [sp, #0x2e8]
101438ed8: 52800022    	mov	w2, #0x1                ; =1
101438edc: 97d99600    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438ee0: 910a43e0    	add	x0, sp, #0x290
101438ee4: 94006c2a    	bl	0x101453f8c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6b04>
101438ee8: 92800008    	mov	x8, #-0x1               ; =-1
101438eec: f86802c8    	ldaddl	x8, x8, [x22]
101438ef0: f100051f    	cmp	x8, #0x1
101438ef4: 54000081    	b.ne	0x101438f04 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5298>
101438ef8: d50339bf    	dmb	ishld
101438efc: 9109e3e0    	add	x0, sp, #0x278
101438f00: 9400ca0c    	bl	0x10146b730 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E>
101438f04: f94087e1    	ldr	x1, [sp, #0x108]
101438f08: b4000081    	cbz	x1, 0x101438f18 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x52ac>
101438f0c: f9408be0    	ldr	x0, [sp, #0x110]
101438f10: 52800022    	mov	w2, #0x1                ; =1
101438f14: 97d995f2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438f18: 9103c3e0    	add	x0, sp, #0xf0
101438f1c: 97d426fc    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101438f20: aa1303e0    	mov	x0, x19
101438f24: 941a41ac    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101438f28: 91002297    	add	x23, x20, #0x8
101438f2c: 14000004    	b	0x101438f3c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x52d0>
101438f30: 910062f7    	add	x23, x23, #0x18
101438f34: f10006d6    	subs	x22, x22, #0x1
101438f38: 54fffc00    	b.eq	0x101438eb8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x524c>
101438f3c: f85f82e1    	ldur	x1, [x23, #-0x8]
101438f40: b4ffff81    	cbz	x1, 0x101438f30 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x52c4>
101438f44: f94002e0    	ldr	x0, [x23]
101438f48: 52800022    	mov	w2, #0x1                ; =1
101438f4c: 97d995e4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438f50: 17fffff8    	b	0x101438f30 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x52c4>
101438f54: 8b080508    	add	x8, x8, x8, lsl #1
101438f58: d37df101    	lsl	x1, x8, #3
101438f5c: aa1403e0    	mov	x0, x20
101438f60: 52800102    	mov	w2, #0x8                ; =8
101438f64: 97d995de    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438f68: f9404ff6    	ldr	x22, [sp, #0x98]
101438f6c: f940d3e1    	ldr	x1, [sp, #0x1a0]
101438f70: b4fffae1    	cbz	x1, 0x101438ecc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5260>
101438f74: aa1503e0    	mov	x0, x21
101438f78: 52800022    	mov	w2, #0x1                ; =1
101438f7c: 97d995d8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438f80: f94173e1    	ldr	x1, [sp, #0x2e0]
101438f84: b5fffa81    	cbnz	x1, 0x101438ed4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5268>
101438f88: 17ffffd6    	b	0x101438ee0 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5274>
101438f8c: f94193f7    	ldr	x23, [sp, #0x320]
101438f90: aa1703f8    	mov	x24, x23
101438f94: fc408700    	ldr	d0, [x24], #0x8
101438f98: 2e208800    	cmge.8b	v0, v0, #0
101438f9c: 9e660008    	fmov	x8, d0
101438fa0: 9201c119    	and	x25, x8, #0x8080808080808080
101438fa4: 14000005    	b	0x101438fb8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x534c>
101438fa8: d1000728    	sub	x8, x25, #0x1
101438fac: 8a190119    	and	x25, x8, x25
101438fb0: d10006d6    	sub	x22, x22, #0x1
101438fb4: b4fff6d6    	cbz	x22, 0x101438e8c <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5220>
101438fb8: b50000f9    	cbnz	x25, 0x101438fd4 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5368>
101438fbc: fc408700    	ldr	d0, [x24], #0x8
101438fc0: 2e208800    	cmge.8b	v0, v0, #0
101438fc4: 9e660008    	fmov	x8, d0
101438fc8: d10402f7    	sub	x23, x23, #0x100
101438fcc: 9201c119    	and	x25, x8, #0x8080808080808080
101438fd0: b4ffff79    	cbz	x25, 0x101438fbc <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x5350>
101438fd4: dac00328    	rbit	x8, x25
101438fd8: dac01108    	clz	x8, x8
101438fdc: d37ef508    	lsl	x8, x8, #2
101438fe0: 927b0d08    	and	x8, x8, #0x1e0
101438fe4: cb0802e8    	sub	x8, x23, x8
101438fe8: f85e0101    	ldur	x1, [x8, #-0x20]
101438fec: b4fffde1    	cbz	x1, 0x101438fa8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x533c>
101438ff0: f85e8100    	ldur	x0, [x8, #-0x18]
101438ff4: 52800022    	mov	w2, #0x1                ; =1
101438ff8: 97d995b9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101438ffc: 17ffffeb    	b	0x101438fa8 <__ZN17otty_autocomplete6engine6Engine14record_command17hf891be8ef165f6e7E+0x533c>
101439000: 941a2b49    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
