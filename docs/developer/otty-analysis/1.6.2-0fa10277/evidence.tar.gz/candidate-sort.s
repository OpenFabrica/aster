
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010144d488 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE>:
10145931c: d101c3ff    	sub	sp, sp, #0x70
101459320: d2800008    	mov	x8, #0x0                ; =0
101459324: 52800f09    	mov	w9, #0x78               ; =120
101459328: 9b090029    	madd	x9, x1, x9, x0
10145932c: 9101e00b    	add	x11, x0, #0x78
101459330: aa0003ee    	mov	x14, x0
101459334: 14000010    	b	0x101459374 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbeec>
101459338: aa0003ed    	mov	x13, x0
10145933c: a90031ab    	stp	x11, x12, [x13]
101459340: ad4207e0    	ldp	q0, q1, [sp, #0x40]
101459344: ad0285a0    	stp	q0, q1, [x13, #0x50]
101459348: f94033eb    	ldr	x11, [sp, #0x60]
10145934c: f90039ab    	str	x11, [x13, #0x70]
101459350: ad4007e0    	ldp	q0, q1, [sp]
101459354: ad0085a0    	stp	q0, q1, [x13, #0x10]
101459358: ad4103e1    	ldp	q1, q0, [sp, #0x20]
10145935c: ad0181a1    	stp	q1, q0, [x13, #0x30]
101459360: 9101e14b    	add	x11, x10, #0x78
101459364: 9101e108    	add	x8, x8, #0x78
101459368: aa0a03ee    	mov	x14, x10
10145936c: eb09017f    	cmp	x11, x9
101459370: 540006c0    	b.eq	0x101459448 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbfc0>
101459374: aa0b03ea    	mov	x10, x11
101459378: a947b1cb    	ldp	x11, x12, [x14, #0x78]
10145937c: b94001cd    	ldr	w13, [x14]
101459380: f94005cf    	ldr	x15, [x14, #0x8]
101459384: 710001bf    	cmp	w13, #0x0
101459388: 9a9f11ed    	csel	x13, x15, xzr, ne
10145938c: 7100017f    	cmp	w11, #0x0
101459390: 9a9f118f    	csel	x15, x12, xzr, ne
101459394: 937ffdb0    	asr	x16, x13, #63
101459398: ca5005b0    	eor	x16, x13, x16, lsr #1
10145939c: 937ffded    	asr	x13, x15, #63
1014593a0: ca4d05ed    	eor	x13, x15, x13, lsr #1
1014593a4: eb0d021f    	cmp	x16, x13
1014593a8: 54fffdca    	b.ge	0x101459360 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbed8>
1014593ac: 3ccb81c0    	ldur	q0, [x14, #0xb8]
1014593b0: 3ccc81c1    	ldur	q1, [x14, #0xc8]
1014593b4: 3ccd81c2    	ldur	q2, [x14, #0xd8]
1014593b8: ad020be1    	stp	q1, q2, [sp, #0x40]
1014593bc: f94075cf    	ldr	x15, [x14, #0xe8]
1014593c0: f90033ef    	str	x15, [sp, #0x60]
1014593c4: 3cc881c1    	ldur	q1, [x14, #0x88]
1014593c8: 3cc981c2    	ldur	q2, [x14, #0x98]
1014593cc: ad000be1    	stp	q1, q2, [sp]
1014593d0: 3cca81c1    	ldur	q1, [x14, #0xa8]
1014593d4: aa0803ee    	mov	x14, x8
1014593d8: ad0103e1    	stp	q1, q0, [sp, #0x20]
1014593dc: 8b0e000f    	add	x15, x0, x14
1014593e0: ad4205e0    	ldp	q0, q1, [x15, #0x40]
1014593e4: 3c8b81e0    	stur	q0, [x15, #0xb8]
1014593e8: 3c8c81e1    	stur	q1, [x15, #0xc8]
1014593ec: 3dc019e0    	ldr	q0, [x15, #0x60]
1014593f0: 3c8d81e0    	stur	q0, [x15, #0xd8]
1014593f4: ad4005e0    	ldp	q0, q1, [x15]
1014593f8: 3c8781e0    	stur	q0, [x15, #0x78]
1014593fc: 3c8881e1    	stur	q1, [x15, #0x88]
101459400: ad4105e0    	ldp	q0, q1, [x15, #0x20]
101459404: 3c8981e0    	stur	q0, [x15, #0x98]
101459408: f94039f0    	ldr	x16, [x15, #0x70]
10145940c: f90075f0    	str	x16, [x15, #0xe8]
101459410: 3c8a81e1    	stur	q1, [x15, #0xa8]
101459414: b4fff92e    	cbz	x14, 0x101459338 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbeb0>
101459418: b85881f0    	ldur	w16, [x15, #-0x78]
10145941c: f85901ef    	ldur	x15, [x15, #-0x70]
101459420: 7100021f    	cmp	w16, #0x0
101459424: 9a9f11ef    	csel	x15, x15, xzr, ne
101459428: 937ffdf0    	asr	x16, x15, #63
10145942c: ca5005ef    	eor	x15, x15, x16, lsr #1
101459430: d101e1ce    	sub	x14, x14, #0x78
101459434: eb0d01ff    	cmp	x15, x13
101459438: 54fffd2b    	b.lt	0x1014593dc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbf54>
10145943c: 8b0e000d    	add	x13, x0, x14
101459440: 9101e1ad    	add	x13, x13, #0x78
101459444: 17ffffbe    	b	0x10145933c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbeb4>
101459448: 9101c3ff    	add	sp, sp, #0x70
10145944c: d65f03c0    	ret
101459450: d10203ff    	sub	sp, sp, #0x80
101459454: a9026ffc    	stp	x28, x27, [sp, #0x20]
101459458: a90367fa    	stp	x26, x25, [sp, #0x30]
10145945c: a9045ff8    	stp	x24, x23, [sp, #0x40]
101459460: a90557f6    	stp	x22, x21, [sp, #0x50]
101459464: a9064ff4    	stp	x20, x19, [sp, #0x60]
101459468: a9077bfd    	stp	x29, x30, [sp, #0x70]
10145946c: 9101c3fd    	add	x29, sp, #0x70
101459470: aa0003f3    	mov	x19, x0
101459474: d2800015    	mov	x21, #0x0               ; =0
101459478: 52800508    	mov	w8, #0x28               ; =40
10145947c: 9b080028    	madd	x8, x1, x8, x0
101459480: f90007e8    	str	x8, [sp, #0x8]
101459484: 9100a008    	add	x8, x0, #0x28
101459488: aa0003fc    	mov	x28, x0
10145948c: 1400000e    	b	0x1014594c4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc03c>
101459490: aa1303e8    	mov	x8, x19
101459494: a9006914    	stp	x20, x26, [x8]
101459498: a9016d18    	stp	x24, x27, [x8, #0x10]
10145949c: 39008119    	strb	w25, [x8, #0x20]
1014594a0: b9401be9    	ldr	w9, [sp, #0x18]
1014594a4: b8021109    	stur	w9, [x8, #0x21]
1014594a8: b841b3e9    	ldur	w9, [sp, #0x1b]
1014594ac: b9002509    	str	w9, [x8, #0x24]
1014594b0: a940f3e9    	ldp	x9, x28, [sp, #0x8]
1014594b4: 9100a388    	add	x8, x28, #0x28
1014594b8: 9100a2b5    	add	x21, x21, #0x28
1014594bc: eb09011f    	cmp	x8, x9
1014594c0: 54000ae0    	b.eq	0x10145961c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc194>
1014594c4: f9000be8    	str	x8, [sp, #0x10]
1014594c8: f9401f98    	ldr	x24, [x28, #0x38]
1014594cc: f9400b88    	ldr	x8, [x28, #0x10]
1014594d0: 39408389    	ldrb	w9, [x28, #0x20]
1014594d4: 39412399    	ldrb	w25, [x28, #0x48]
1014594d8: 4b190129    	sub	w9, w9, w25
1014594dc: eb08031f    	cmp	x24, x8
1014594e0: 1a9f97e8    	cset	w8, hi
1014594e4: 5a9f2108    	csinv	w8, w8, wzr, hs
1014594e8: 1a88013b    	csel	w27, w9, w8, eq
1014594ec: 72001f7f    	tst	w27, #0xff
1014594f0: 540000c1    	b.ne	0x101459508 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc080>
1014594f4: f9402388    	ldr	x8, [x28, #0x40]
1014594f8: f9400f89    	ldr	x9, [x28, #0x18]
1014594fc: eb09011f    	cmp	x8, x9
101459500: 1a9f97e8    	cset	w8, hi
101459504: 5a9f211b    	csinv	w27, w8, wzr, hs
101459508: a942eb94    	ldp	x20, x26, [x28, #0x28]
10145950c: a9402381    	ldp	x1, x8, [x28]
101459510: eb080356    	subs	x22, x26, x8
101459514: 9a883342    	csel	x2, x26, x8, lo
101459518: aa1403e0    	mov	x0, x20
10145951c: 9419c1c0    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101459520: 93407c08    	sxtw	x8, w0
101459524: 7100001f    	cmp	w0, #0x0
101459528: 9a8802c8    	csel	x8, x22, x8, eq
10145952c: f100011f    	cmp	x8, #0x0
101459530: 1a9fa7e8    	cset	w8, lt
101459534: 72001f69    	ands	w9, w27, #0xff
101459538: 7103fd3f    	cmp	w9, #0xff
10145953c: 1a9f17e9    	cset	w9, eq
101459540: 72001f7f    	tst	w27, #0xff
101459544: 1a890108    	csel	w8, w8, w9, eq
101459548: 7100051f    	cmp	w8, #0x1
10145954c: 54fffb21    	b.ne	0x1014594b0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc028>
101459550: f940239b    	ldr	x27, [x28, #0x40]
101459554: b8449388    	ldur	w8, [x28, #0x49]
101459558: b9001be8    	str	w8, [sp, #0x18]
10145955c: b9404f88    	ldr	w8, [x28, #0x4c]
101459560: b801b3e8    	stur	w8, [sp, #0x1b]
101459564: aa1503fc    	mov	x28, x21
101459568: 14000014    	b	0x1014595b8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc130>
10145956c: f85d8101    	ldur	x1, [x8, #-0x28]
101459570: 8b1c0268    	add	x8, x19, x28
101459574: f85e0108    	ldur	x8, [x8, #-0x20]
101459578: eb080357    	subs	x23, x26, x8
10145957c: 9a883342    	csel	x2, x26, x8, lo
101459580: aa1403e0    	mov	x0, x20
101459584: 9419c1a6    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101459588: 93407c08    	sxtw	x8, w0
10145958c: 7100001f    	cmp	w0, #0x0
101459590: 9a8802e8    	csel	x8, x23, x8, eq
101459594: f100011f    	cmp	x8, #0x0
101459598: 1a9fa7e8    	cset	w8, lt
10145959c: 72001ec9    	ands	w9, w22, #0xff
1014595a0: 7103fd3f    	cmp	w9, #0xff
1014595a4: 1a9f17e9    	cset	w9, eq
1014595a8: 72001edf    	tst	w22, #0xff
1014595ac: 1a890108    	csel	w8, w8, w9, eq
1014595b0: d100a39c    	sub	x28, x28, #0x28
1014595b4: 360002e8    	tbz	w8, #0x0, 0x101459610 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc188>
1014595b8: 8b1c0268    	add	x8, x19, x28
1014595bc: ad400500    	ldp	q0, q1, [x8]
1014595c0: 3c828100    	stur	q0, [x8, #0x28]
1014595c4: 3c838101    	stur	q1, [x8, #0x38]
1014595c8: f9401109    	ldr	x9, [x8, #0x20]
1014595cc: f9002509    	str	x9, [x8, #0x48]
1014595d0: b4fff61c    	cbz	x28, 0x101459490 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc008>
1014595d4: f85e8109    	ldur	x9, [x8, #-0x18]
1014595d8: 385f810a    	ldurb	w10, [x8, #-0x8]
1014595dc: 4b19014a    	sub	w10, w10, w25
1014595e0: eb09031f    	cmp	x24, x9
1014595e4: 1a9f97e9    	cset	w9, hi
1014595e8: 5a9f2129    	csinv	w9, w9, wzr, hs
1014595ec: 1a890156    	csel	w22, w10, w9, eq
1014595f0: 72001edf    	tst	w22, #0xff
1014595f4: 54fffbc1    	b.ne	0x10145956c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc0e4>
1014595f8: 8b1c0269    	add	x9, x19, x28
1014595fc: f85f0129    	ldur	x9, [x9, #-0x10]
101459600: eb09037f    	cmp	x27, x9
101459604: 1a9f97e9    	cset	w9, hi
101459608: 5a9f2136    	csinv	w22, w9, wzr, hs
10145960c: 17ffffd8    	b	0x10145956c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc0e4>
101459610: 8b1c0268    	add	x8, x19, x28
101459614: 9100a108    	add	x8, x8, #0x28
101459618: 17ffff9f    	b	0x101459494 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc00c>
10145961c: a9477bfd    	ldp	x29, x30, [sp, #0x70]
101459620: a9464ff4    	ldp	x20, x19, [sp, #0x60]
101459624: a94557f6    	ldp	x22, x21, [sp, #0x50]
101459628: a9445ff8    	ldp	x24, x23, [sp, #0x40]
10145962c: a94367fa    	ldp	x26, x25, [sp, #0x30]
101459630: a9426ffc    	ldp	x28, x27, [sp, #0x20]
101459634: 910203ff    	add	sp, sp, #0x80
101459638: d65f03c0    	ret
10145963c: d102c3ff    	sub	sp, sp, #0xb0
101459640: a9075ff8    	stp	x24, x23, [sp, #0x70]
101459644: a90857f6    	stp	x22, x21, [sp, #0x80]
101459648: a9094ff4    	stp	x20, x19, [sp, #0x90]
10145964c: a90a7bfd    	stp	x29, x30, [sp, #0xa0]
101459650: 910283fd    	add	x29, sp, #0xa0
101459654: aa0203f3    	mov	x19, x2
101459658: aa0003f4    	mov	x20, x0
10145965c: d2800016    	mov	x22, #0x0               ; =0
101459660: 52800e08    	mov	w8, #0x70               ; =112
101459664: 9b080037    	madd	x23, x1, x8, x0
101459668: 9101c008    	add	x8, x0, #0x70
10145966c: aa0003f5    	mov	x21, x0
101459670: 1400000e    	b	0x1014596a8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc220>
101459674: aa1403e8    	mov	x8, x20
101459678: ad4207e0    	ldp	q0, q1, [sp, #0x40]
10145967c: ad020500    	stp	q0, q1, [x8, #0x40]
101459680: 3dc01be0    	ldr	q0, [sp, #0x60]
101459684: 3d801900    	str	q0, [x8, #0x60]
101459688: ad4007e0    	ldp	q0, q1, [sp]
10145968c: ad000500    	stp	q0, q1, [x8]
101459690: ad4103e1    	ldp	q1, q0, [sp, #0x20]
101459694: ad010101    	stp	q1, q0, [x8, #0x20]
101459698: 9101c2a8    	add	x8, x21, #0x70
10145969c: 9101c2d6    	add	x22, x22, #0x70
1014596a0: eb17011f    	cmp	x8, x23
1014596a4: 54000460    	b.eq	0x101459730 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc2a8>
1014596a8: aa1503e2    	mov	x2, x21
1014596ac: aa0803f5    	mov	x21, x8
1014596b0: aa1303e0    	mov	x0, x19
1014596b4: aa0803e1    	mov	x1, x8
1014596b8: 94004967    	bl	0x10146bc54 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0x524>
1014596bc: 34fffee0    	cbz	w0, 0x101459698 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc210>
1014596c0: ad4206a0    	ldp	q0, q1, [x21, #0x40]
1014596c4: ad0207e0    	stp	q0, q1, [sp, #0x40]
1014596c8: 3dc01aa0    	ldr	q0, [x21, #0x60]
1014596cc: 3d801be0    	str	q0, [sp, #0x60]
1014596d0: ad4006a0    	ldp	q0, q1, [x21]
1014596d4: ad0007e0    	stp	q0, q1, [sp]
1014596d8: ad4102a1    	ldp	q1, q0, [x21, #0x20]
1014596dc: aa1603f8    	mov	x24, x22
1014596e0: ad0103e1    	stp	q1, q0, [sp, #0x20]
1014596e4: 8b180288    	add	x8, x20, x24
1014596e8: ad420500    	ldp	q0, q1, [x8, #0x40]
1014596ec: ad058500    	stp	q0, q1, [x8, #0xb0]
1014596f0: 3dc01900    	ldr	q0, [x8, #0x60]
1014596f4: 3d803500    	str	q0, [x8, #0xd0]
1014596f8: ad400500    	ldp	q0, q1, [x8]
1014596fc: ad038500    	stp	q0, q1, [x8, #0x70]
