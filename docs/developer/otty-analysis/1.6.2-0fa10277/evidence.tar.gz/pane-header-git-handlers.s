100587dc8:     	stp	x28, x27, [sp, #-0x60]!
100587dcc:     	stp	x26, x25, [sp, #0x10]
100587dd0:     	stp	x24, x23, [sp, #0x20]
100587dd4:     	stp	x22, x21, [sp, #0x30]
100587dd8:     	stp	x20, x19, [sp, #0x40]
100587ddc:     	stp	x29, x30, [sp, #0x50]
100587de0:     	add	x29, sp, #0x50
100587de4:     	sub	sp, sp, #0x60
100587de8:     	mov	x25, x2
100587dec:     	mov	x24, x1
100587df0:     	stur	x0, [x29, #-0xa8]
100587df4:     	mov	x0, #0x0                ; =0
100587df8:     	bl	0x101ac5d88 ; symbol _$s8Dispatch0A13WorkItemFlagsVMa
100587dfc:     	mov	x19, x0
100587e00:     	ldur	x8, [x0, #-0x8]
100587e04:     	stur	x8, [x29, #-0x90]
100587e08:     	ldr	x8, [x8, #0x40]
100587e0c:     	mov	x9, x8
100587e10:     	adrp	x16, 0x1022cb000
100587e14:     	ldr	x16, [x16, #0x398]
100587e18:     	blr	x16
100587e1c:     	mov	x9, sp
100587e20:     	add	x8, x8, #0xf
100587e24:     	and	x8, x8, #0xfffffffffffffff0
100587e28:     	sub	x21, x9, x8
100587e2c:     	mov	sp, x21
100587e30:     	mov	x0, #0x0                ; =0
100587e34:     	bl	0x101ac5dc4 ; symbol _$s8Dispatch0A3QoSVMa
100587e38:     	ldur	x8, [x0, #-0x8]
100587e3c:     	stp	x8, x0, [x29, #-0xa0]
100587e40:     	ldr	x8, [x8, #0x40]
100587e44:     	mov	x9, x8
100587e48:     	adrp	x16, 0x1022cb000
100587e4c:     	ldr	x16, [x16, #0x398]
100587e50:     	blr	x16
100587e54:     	mov	x9, sp
100587e58:     	add	x8, x8, #0xf
100587e5c:     	and	x8, x8, #0xfffffffffffffff0
100587e60:     	sub	x23, x9, x8
100587e64:     	mov	sp, x23
100587e68:     	mov	x0, #0x0                ; =0
100587e6c:     	bl	0x101ac5d94 ; symbol _$s8Dispatch0A3QoSV0B6SClassOMa
100587e70:     	mov	x28, x0
100587e74:     	ldur	x27, [x0, #-0x8]
100587e78:     	ldr	x8, [x27, #0x40]
100587e7c:     	mov	x9, x8
100587e80:     	adrp	x16, 0x1022cb000
100587e84:     	ldr	x16, [x16, #0x398]
100587e88:     	blr	x16
100587e8c:     	mov	x9, sp
100587e90:     	add	x8, x8, #0xf
100587e94:     	and	x8, x8, #0xfffffffffffffff0
100587e98:     	sub	x22, x9, x8
100587e9c:     	mov	sp, x22
100587ea0:     	adrp	x1, 0x102340000
100587ea4:     	add	x1, x1, #0xc40
100587ea8:     	adrp	x2, 0x102326000
100587eac:     	add	x2, x2, #0x9d8
100587eb0:     	mov	x0, #0x0                ; =0
100587eb4:     	bl	0x10002d97c
100587eb8:     	mov	x20, x0
100587ebc:     	adrp	x8, 0x1022cf000
100587ec0:     	ldr	x8, [x8, #0x950]
100587ec4:     	ldr	w1, [x8]
100587ec8:     	ldr	x8, [x27, #0x68]
100587ecc:     	mov	x0, x22
100587ed0:     	mov	x2, x28
100587ed4:     	blr	x8
100587ed8:     	mov	x0, x22
100587edc:     	bl	0x101ac6e80 ; symbol _$sSo17OS_dispatch_queueC8DispatchE6global3qosAbC0D3QoSV0G6SClassO_tFZ
100587ee0:     	mov	x26, x0
100587ee4:     	ldr	x8, [x27, #0x8]
100587ee8:     	mov	x0, x22
100587eec:     	mov	x1, x28
100587ef0:     	blr	x8
100587ef4:     	adrp	x0, 0x1021e1000
100587ef8:     	add	x0, x0, #0x3b0
100587efc:     	mov	w1, #0x28               ; =40
100587f00:     	mov	w2, #0x7                ; =7
100587f04:     	bl	0x101aca588 ; symbol _swift_allocObject
100587f08:     	ldur	x8, [x29, #-0xa8]
100587f0c:     	stp	x8, x24, [x0, #0x10]
100587f10:     	str	x25, [x0, #0x20]
100587f14:     	adrp	x8, 0x100588000
100587f18:     	add	x8, x8, #0x290
100587f1c:     	stp	x8, x0, [x29, #-0x60]
100587f20:     	adrp	x8, 0x1022cb000
100587f24:     	ldr	x8, [x8, #0x300]
100587f28:     	stur	x8, [x29, #-0x80]
100587f2c:     	adrp	x8, 0x101ae1000
100587f30:     	ldr	d0, [x8]
100587f34:     	stur	d0, [x29, #-0x78]
100587f38:     	adrp	x8, 0x100004000
100587f3c:     	add	x8, x8, #0xd0
100587f40:     	adrp	x9, 0x1021e1000
100587f44:     	add	x9, x9, #0x3c8
100587f48:     	stp	x8, x9, [x29, #-0x70]
100587f4c:     	sub	x0, x29, #0x80
100587f50:     	bl	0x101ac9514 ; symbol __Block_copy
100587f54:     	mov	x22, x0
100587f58:     	mov	x0, x25
100587f5c:     	bl	0x101aca978 ; symbol _swift_retain
100587f60:     	mov	x0, x24
100587f64:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100587f68:     	mov	x8, x23
100587f6c:     	bl	0x101ac5da0 ; symbol _$s8Dispatch0A3QoSV11unspecifiedACvgZ
100587f70:     	adrp	x8, 0x1022cf000
100587f74:     	ldr	x8, [x8, #0x4a8]
100587f78:     	stur	x8, [x29, #-0x88]
100587f7c:     	bl	0x100003c08
100587f80:     	mov	x24, x0
100587f84:     	adrp	x0, 0x102340000
100587f88:     	add	x0, x0, #0xc50
100587f8c:     	adrp	x1, 0x101ae1000
100587f90:     	add	x1, x1, #0x280 ; possible literal '�14'
100587f94:     	bl	0x100003c4c
100587f98:     	mov	x20, x0
100587f9c:     	bl	0x100003c9c
100587fa0:     	mov	x2, x0
100587fa4:     	sub	x0, x29, #0x88
100587fa8:     	mov	x8, x21
100587fac:     	mov	x1, x20
100587fb0:     	mov	x20, x19
100587fb4:     	mov	x3, x19
100587fb8:     	mov	x4, x24
100587fbc:     	bl	0x101ac7450 ; symbol _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
100587fc0:     	mov	x0, #0x0                ; =0
100587fc4:     	mov	x1, x23
100587fc8:     	mov	x2, x21
100587fcc:     	mov	x3, x22
100587fd0:     	mov	x20, x26
100587fd4:     	bl	0x101ac6e5c ; symbol _$sSo17OS_dispatch_queueC8DispatchE5async5group3qos5flags7executeySo0a1_b1_F0CSg_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
100587fd8:     	mov	x0, x22
100587fdc:     	bl	0x101ac9520 ; symbol __Block_release
100587fe0:     	mov	x0, x26
100587fe4:     	bl	0x101ac9d30 ; symbol _objc_release
100587fe8:     	ldur	x8, [x29, #-0x90]
100587fec:     	ldr	x8, [x8, #0x8]
100587ff0:     	mov	x0, x21
100587ff4:     	mov	x1, x19
100587ff8:     	blr	x8
100587ffc:     	ldp	x8, x1, [x29, #-0xa0]
100588000:     	ldr	x8, [x8, #0x8]
100588004:     	mov	x0, x23
100588008:     	blr	x8
10058800c:     	ldur	x0, [x29, #-0x58]
100588010:     	bl	0x101aca960 ; symbol _swift_release
100588014:     	sub	sp, x29, #0x50
100588018:     	ldp	x29, x30, [sp, #0x50]
10058801c:     	ldp	x20, x19, [sp, #0x40]
100588020:     	ldp	x22, x21, [sp, #0x30]
100588024:     	ldp	x24, x23, [sp, #0x20]
100588028:     	ldp	x26, x25, [sp, #0x10]
10058802c:     	ldp	x28, x27, [sp], #0x60
100588030:     	ret
100588034:     	stp	x28, x27, [sp, #-0x60]!
100588038:     	stp	x26, x25, [sp, #0x10]
10058803c:     	stp	x24, x23, [sp, #0x20]
100588040:     	stp	x22, x21, [sp, #0x30]
100588044:     	stp	x20, x19, [sp, #0x40]
100588048:     	stp	x29, x30, [sp, #0x50]
10058804c:     	add	x29, sp, #0x50
100588050:     	sub	sp, sp, #0x40
100588054:     	mov	x24, x2
100588058:     	mov	x25, x1
10058805c:     	mov	x26, x0
100588060:     	mov	x0, #0x0                ; =0
100588064:     	bl	0x101ac5d88 ; symbol _$s8Dispatch0A13WorkItemFlagsVMa
100588068:     	mov	x19, x0
10058806c:     	ldur	x8, [x0, #-0x8]
100588070:     	stur	x8, [x29, #-0x88]
100588074:     	ldr	x8, [x8, #0x40]
100588078:     	mov	x9, x8
10058807c:     	adrp	x16, 0x1022cb000
100588080:     	ldr	x16, [x16, #0x398]
100588084:     	blr	x16
100588088:     	mov	x9, sp
10058808c:     	add	x8, x8, #0xf ; possible literal '�t\n'
100588090:     	and	x8, x8, #0xfffffffffffffff0
100588094:     	sub	x21, x9, x8
100588098:     	mov	sp, x21
10058809c:     	mov	x0, #0x0                ; =0
1005880a0:     	bl	0x101ac5dc4 ; symbol _$s8Dispatch0A3QoSVMa
1005880a4:     	stur	x0, [x29, #-0x90]
1005880a8:     	ldur	x22, [x0, #-0x8]
1005880ac:     	ldr	x8, [x22, #0x40]
1005880b0:     	mov	x9, x8
1005880b4:     	adrp	x16, 0x1022cb000
1005880b8:     	ldr	x16, [x16, #0x398]
1005880bc:     	blr	x16
1005880c0:     	mov	x9, sp
1005880c4:     	add	x8, x8, #0xf
1005880c8:     	and	x8, x8, #0xfffffffffffffff0
1005880cc:     	sub	x23, x9, x8
1005880d0:     	mov	sp, x23
1005880d4:     	mov	x0, x26
1005880d8:     	mov	x1, x25
1005880dc:     	bl	0x100582f94
1005880e0:     	cbz	x1, 0x1005880f0
1005880e4:     	mov	x26, x0
1005880e8:     	mov	x25, x1
1005880ec:     	b	0x1005880f8
1005880f0:     	mov	x0, x25
1005880f4:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
1005880f8:     	mov	x0, x26
1005880fc:     	mov	x1, x25
100588100:     	bl	0x100582f8c
100588104:     	mov	x28, x0
100588108:     	adrp	x1, 0x102340000
10058810c:     	add	x1, x1, #0xc40
100588110:     	adrp	x2, 0x102326000
100588114:     	add	x2, x2, #0x9d8
100588118:     	mov	x0, #0x0                ; =0
10058811c:     	bl	0x10002d97c
100588120:     	mov	x20, x0
100588124:     	bl	0x101ac6e44 ; symbol _$sSo17OS_dispatch_queueC8DispatchE4mainABvgZ
100588128:     	mov	x27, x0
10058812c:     	adrp	x0, 0x1021e1000
100588130:     	add	x0, x0, #0x970
100588134:     	mov	w1, #0x30               ; =48
100588138:     	mov	w2, #0x7                ; =7
10058813c:     	bl	0x101aca588 ; symbol _swift_allocObject
100588140:     	stp	x26, x25, [x0, #0x10]
100588144:     	stp	x28, x24, [x0, #0x20]
100588148:     	adrp	x8, 0x10058b000
10058814c:     	add	x8, x8, #0xd3c
100588150:     	stp	x8, x0, [x29, #-0x60]
100588154:     	adrp	x8, 0x1022cb000
100588158:     	ldr	x8, [x8, #0x300]
10058815c:     	stur	x8, [x29, #-0x80]
100588160:     	adrp	x8, 0x101ae1000
100588164:     	ldr	d0, [x8]
100588168:     	stur	d0, [x29, #-0x78]
10058816c:     	adrp	x8, 0x100004000
100588170:     	add	x8, x8, #0xd0
100588174:     	adrp	x9, 0x1021e1000
100588178:     	add	x9, x9, #0x988
10058817c:     	stp	x8, x9, [x29, #-0x70]
100588180:     	sub	x0, x29, #0x80
100588184:     	bl	0x101ac9514 ; symbol __Block_copy
100588188:     	mov	x25, x0
10058818c:     	ldur	x20, [x29, #-0x58]
100588190:     	mov	x0, x24
100588194:     	bl	0x101aca978 ; symbol _swift_retain
100588198:     	mov	x0, x20
10058819c:     	bl	0x101aca960 ; symbol _swift_release
1005881a0:     	mov	x8, x23
1005881a4:     	bl	0x101ac5da0 ; symbol _$s8Dispatch0A3QoSV11unspecifiedACvgZ
1005881a8:     	adrp	x8, 0x1022cf000
1005881ac:     	ldr	x8, [x8, #0x4a8]
1005881b0:     	stur	x8, [x29, #-0x80]
1005881b4:     	bl	0x100003c08
1005881b8:     	mov	x24, x0
1005881bc:     	adrp	x0, 0x102340000
1005881c0:     	add	x0, x0, #0xc50
1005881c4:     	adrp	x1, 0x101ae1000
1005881c8:     	add	x1, x1, #0x280 ; possible literal '�14'
1005881cc:     	bl	0x100003c4c
1005881d0:     	mov	x20, x0
1005881d4:     	bl	0x100003c9c
1005881d8:     	mov	x2, x0
1005881dc:     	sub	x0, x29, #0x80
1005881e0:     	mov	x8, x21
1005881e4:     	mov	x1, x20
1005881e8:     	mov	x20, x19
1005881ec:     	mov	x3, x19
1005881f0:     	mov	x4, x24
1005881f4:     	bl	0x101ac7450 ; symbol _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
1005881f8:     	mov	x0, #0x0                ; =0
1005881fc:     	mov	x1, x23
100588200:     	mov	x2, x21
100588204:     	mov	x3, x25
100588208:     	mov	x20, x27
10058820c:     	bl	0x101ac6e5c ; symbol _$sSo17OS_dispatch_queueC8DispatchE5async5group3qos5flags7executeySo0a1_b1_F0CSg_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
100588210:     	mov	x0, x25
100588214:     	bl	0x101ac9520 ; symbol __Block_release
100588218:     	mov	x0, x27
10058821c:     	bl	0x101ac9d30 ; symbol _objc_release
100588220:     	ldur	x8, [x29, #-0x88]
100588224:     	ldr	x8, [x8, #0x8]
100588228:     	mov	x0, x21
10058822c:     	mov	x1, x19
100588230:     	blr	x8
100588234:     	ldr	x8, [x22, #0x8]
100588238:     	mov	x0, x23
10058823c:     	ldur	x1, [x29, #-0x90]
100588240:     	blr	x8
100588244:     	sub	sp, x29, #0x50
100588248:     	ldp	x29, x30, [sp, #0x50]
10058824c:     	ldp	x20, x19, [sp, #0x40]
100588250:     	ldp	x22, x21, [sp, #0x30]
100588254:     	ldp	x24, x23, [sp, #0x20]
100588258:     	ldp	x26, x25, [sp, #0x10]
10058825c:     	ldp	x28, x27, [sp], #0x60
100588260:     	ret
100588264:     	stp	x29, x30, [sp, #-0x10]!
100588268:     	mov	x29, sp
10058826c:     	ldr	x0, [x20, #0x18]
100588270:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100588274:     	ldr	x0, [x20, #0x20]
100588278:     	bl	0x101aca960 ; symbol _swift_release
10058827c:     	mov	x0, x20
100588280:     	mov	w1, #0x28               ; =40
100588284:     	mov	w2, #0x7                ; =7
100588288:     	ldp	x29, x30, [sp], #0x10
10058828c:     	b	0x101aca6a8 ; symbol _swift_deallocObject
100588290:     	ldp	x0, x1, [x20, #0x10]
100588294:     	ldr	x2, [x20, #0x20]
100588298:     	b	0x100588034
10058829c:     	ldr	x8, [x1, #0x28]
1005882a0:     	ldr	q0, [x1, #0x20]
1005882a4:     	str	q0, [x0, #0x20]
1005882a8:     	mov	x0, x8
1005882ac:     	b	0x101aca978 ; symbol _swift_retain
1005882b0:     	ldr	x0, [x0, #0x28]
1005882b4:     	b	0x101aca960 ; symbol _swift_release
1005882b8:     	stp	x28, x27, [sp, #-0x60]!
1005882bc:     	stp	x26, x25, [sp, #0x10]
1005882c0:     	stp	x24, x23, [sp, #0x20]
1005882c4:     	stp	x22, x21, [sp, #0x30]
1005882c8:     	stp	x20, x19, [sp, #0x40]
1005882cc:     	stp	x29, x30, [sp, #0x50]
1005882d0:     	add	x29, sp, #0x50
1005882d4:     	sub	sp, sp, #0x50
1005882d8:     	mov	x24, x1
1005882dc:     	stur	x0, [x29, #-0xa0]
1005882e0:     	mov	x0, #0x0                ; =0
1005882e4:     	bl	0x101ac5d88 ; symbol _$s8Dispatch0A13WorkItemFlagsVMa
1005882e8:     	mov	x19, x0
1005882ec:     	ldur	x8, [x0, #-0x8]
1005882f0:     	stur	x8, [x29, #-0x90]
1005882f4:     	ldr	x8, [x8, #0x40]
1005882f8:     	mov	x9, x8
1005882fc:     	adrp	x16, 0x1022cb000
100588300:     	ldr	x16, [x16, #0x398]
100588304:     	blr	x16
100588308:     	mov	x9, sp
10058830c:     	add	x8, x8, #0xf ; possible literal '�t\n'
100588310:     	and	x8, x8, #0xfffffffffffffff0
100588314:     	sub	x21, x9, x8
100588318:     	mov	sp, x21
10058831c:     	mov	x0, #0x0                ; =0
100588320:     	bl	0x101ac5dc4 ; symbol _$s8Dispatch0A3QoSVMa
100588324:     	stur	x0, [x29, #-0x98]
100588328:     	ldur	x22, [x0, #-0x8]
10058832c:     	ldr	x8, [x22, #0x40]
100588330:     	mov	x9, x8
100588334:     	adrp	x16, 0x1022cb000
100588338:     	ldr	x16, [x16, #0x398]
10058833c:     	blr	x16
100588340:     	mov	x9, sp
100588344:     	add	x8, x8, #0xf
100588348:     	and	x8, x8, #0xfffffffffffffff0
10058834c:     	sub	x23, x9, x8
100588350:     	mov	sp, x23
100588354:     	mov	x0, #0x0                ; =0
100588358:     	bl	0x101ac5d94 ; symbol _$s8Dispatch0A3QoSV0B6SClassOMa
10058835c:     	mov	x27, x0
100588360:     	ldur	x25, [x0, #-0x8]
100588364:     	ldr	x8, [x25, #0x40]
100588368:     	mov	x9, x8
10058836c:     	adrp	x16, 0x1022cb000
100588370:     	ldr	x16, [x16, #0x398]
100588374:     	blr	x16
100588378:     	mov	x9, sp
10058837c:     	add	x8, x8, #0xf
100588380:     	and	x8, x8, #0xfffffffffffffff0
100588384:     	sub	x28, x9, x8
100588388:     	mov	sp, x28
10058838c:     	adrp	x1, 0x102340000
100588390:     	add	x1, x1, #0xc40
100588394:     	adrp	x2, 0x102326000
100588398:     	add	x2, x2, #0x9d8
10058839c:     	mov	x0, #0x0                ; =0
1005883a0:     	bl	0x10002d97c
1005883a4:     	mov	x20, x0
1005883a8:     	adrp	x8, 0x1022cf000
1005883ac:     	ldr	x8, [x8, #0x950]
1005883b0:     	ldr	w1, [x8]
1005883b4:     	ldr	x8, [x25, #0x68]
1005883b8:     	mov	x0, x28
1005883bc:     	mov	x2, x27
1005883c0:     	blr	x8
1005883c4:     	mov	x0, x28
1005883c8:     	bl	0x101ac6e80 ; symbol _$sSo17OS_dispatch_queueC8DispatchE6global3qosAbC0D3QoSV0G6SClassO_tFZ
1005883cc:     	mov	x26, x0
1005883d0:     	ldr	x8, [x25, #0x8]
1005883d4:     	mov	x0, x28
1005883d8:     	mov	x1, x27
1005883dc:     	blr	x8
1005883e0:     	adrp	x0, 0x1021e1000
1005883e4:     	add	x0, x0, #0x400
1005883e8:     	mov	w1, #0x20               ; =32
1005883ec:     	mov	w2, #0x7                ; =7
1005883f0:     	bl	0x101aca588 ; symbol _swift_allocObject
1005883f4:     	ldur	x8, [x29, #-0xa0]
1005883f8:     	stp	x8, x24, [x0, #0x10]
1005883fc:     	adrp	x8, 0x100588000
100588400:     	add	x8, x8, #0x768
100588404:     	stp	x8, x0, [x29, #-0x60]
100588408:     	adrp	x8, 0x1022cb000
10058840c:     	ldr	x8, [x8, #0x300]
100588410:     	stur	x8, [x29, #-0x80]
100588414:     	adrp	x8, 0x101ae1000
100588418:     	ldr	d0, [x8]
10058841c:     	stur	d0, [x29, #-0x78]
100588420:     	adrp	x8, 0x100004000
100588424:     	add	x8, x8, #0xd0
100588428:     	adrp	x9, 0x1021e1000
10058842c:     	add	x9, x9, #0x418
100588430:     	stp	x8, x9, [x29, #-0x70]
100588434:     	sub	x0, x29, #0x80
100588438:     	bl	0x101ac9514 ; symbol __Block_copy
10058843c:     	mov	x25, x0
100588440:     	mov	x0, x24
100588444:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100588448:     	mov	x8, x23
10058844c:     	bl	0x101ac5da0 ; symbol _$s8Dispatch0A3QoSV11unspecifiedACvgZ
100588450:     	adrp	x8, 0x1022cf000
100588454:     	ldr	x8, [x8, #0x4a8]
100588458:     	stur	x8, [x29, #-0x88]
10058845c:     	bl	0x100003c08
100588460:     	mov	x24, x0
100588464:     	adrp	x0, 0x102340000
100588468:     	add	x0, x0, #0xc50
10058846c:     	adrp	x1, 0x101ae1000
100588470:     	add	x1, x1, #0x280 ; possible literal '�14'
100588474:     	bl	0x100003c4c
100588478:     	mov	x20, x0
10058847c:     	bl	0x100003c9c
100588480:     	mov	x2, x0
100588484:     	sub	x0, x29, #0x88
100588488:     	mov	x8, x21
10058848c:     	mov	x1, x20
100588490:     	mov	x20, x19
100588494:     	mov	x3, x19
100588498:     	mov	x4, x24
10058849c:     	bl	0x101ac7450 ; symbol _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
1005884a0:     	mov	x0, #0x0                ; =0
1005884a4:     	mov	x1, x23
1005884a8:     	mov	x2, x21
1005884ac:     	mov	x3, x25
1005884b0:     	mov	x20, x26
1005884b4:     	bl	0x101ac6e5c ; symbol _$sSo17OS_dispatch_queueC8DispatchE5async5group3qos5flags7executeySo0a1_b1_F0CSg_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
1005884b8:     	mov	x0, x25
1005884bc:     	bl	0x101ac9520 ; symbol __Block_release
1005884c0:     	mov	x0, x26
1005884c4:     	bl	0x101ac9d30 ; symbol _objc_release
1005884c8:     	ldur	x8, [x29, #-0x90]
1005884cc:     	ldr	x8, [x8, #0x8]
1005884d0:     	mov	x0, x21
1005884d4:     	mov	x1, x19
1005884d8:     	blr	x8
1005884dc:     	ldr	x8, [x22, #0x8]
1005884e0:     	mov	x0, x23
1005884e4:     	ldur	x1, [x29, #-0x98]
1005884e8:     	blr	x8
1005884ec:     	ldur	x0, [x29, #-0x58]
1005884f0:     	bl	0x101aca960 ; symbol _swift_release
1005884f4:     	sub	sp, x29, #0x50
1005884f8:     	ldp	x29, x30, [sp, #0x50]
1005884fc:     	ldp	x20, x19, [sp, #0x40]
100588500:     	ldp	x22, x21, [sp, #0x30]
100588504:     	ldp	x24, x23, [sp, #0x20]
100588508:     	ldp	x26, x25, [sp, #0x10]
10058850c:     	ldp	x28, x27, [sp], #0x60
100588510:     	ret
100588514:     	stp	x28, x27, [sp, #-0x60]!
100588518:     	stp	x26, x25, [sp, #0x10]
10058851c:     	stp	x24, x23, [sp, #0x20]
100588520:     	stp	x22, x21, [sp, #0x30]
100588524:     	stp	x20, x19, [sp, #0x40]
100588528:     	stp	x29, x30, [sp, #0x50]
10058852c:     	add	x29, sp, #0x50
100588530:     	sub	sp, sp, #0x40
100588534:     	mov	x24, x1
100588538:     	mov	x26, x0
10058853c:     	mov	x0, #0x0                ; =0
100588540:     	bl	0x101ac5d88 ; symbol _$s8Dispatch0A13WorkItemFlagsVMa
100588544:     	mov	x19, x0
100588548:     	ldur	x8, [x0, #-0x8]
10058854c:     	stur	x8, [x29, #-0x88]
100588550:     	ldr	x8, [x8, #0x40]
100588554:     	mov	x9, x8
100588558:     	adrp	x16, 0x1022cb000
10058855c:     	ldr	x16, [x16, #0x398]
100588560:     	blr	x16
100588564:     	mov	x9, sp
100588568:     	add	x8, x8, #0xf ; possible literal '�t\n'
10058856c:     	and	x8, x8, #0xfffffffffffffff0
100588570:     	sub	x21, x9, x8
100588574:     	mov	sp, x21
100588578:     	mov	x0, #0x0                ; =0
10058857c:     	bl	0x101ac5dc4 ; symbol _$s8Dispatch0A3QoSVMa
100588580:     	stur	x0, [x29, #-0x90]
100588584:     	ldur	x28, [x0, #-0x8]
100588588:     	ldr	x8, [x28, #0x40]
10058858c:     	mov	x9, x8
100588590:     	adrp	x16, 0x1022cb000
100588594:     	ldr	x16, [x16, #0x398]
100588598:     	blr	x16
10058859c:     	mov	x9, sp
1005885a0:     	add	x8, x8, #0xf
1005885a4:     	and	x8, x8, #0xfffffffffffffff0
1005885a8:     	sub	x23, x9, x8
1005885ac:     	mov	sp, x23
1005885b0:     	mov	x0, x26
1005885b4:     	mov	x1, x24
1005885b8:     	bl	0x10058427c
1005885bc:     	mov	x8, #0x7563             ; =30051
1005885c0:     	movk	x8, #0x7272, lsl #16
1005885c4:     	movk	x8, #0x6e65, lsl #32
1005885c8:     	movk	x8, #0x2074, lsl #48
1005885cc:     	cmp	x1, #0x0
1005885d0:     	csel	x27, x8, x0, eq
1005885d4:     	mov	x8, #0x7262             ; =29282
1005885d8:     	movk	x8, #0x6e61, lsl #16
1005885dc:     	movk	x8, #0x6863, lsl #32
1005885e0:     	movk	x8, #0xee00, lsl #48
1005885e4:     	csel	x22, x8, x1, eq
1005885e8:     	adrp	x1, 0x102340000
1005885ec:     	add	x1, x1, #0xc40
1005885f0:     	adrp	x2, 0x102326000
1005885f4:     	add	x2, x2, #0x9d8
1005885f8:     	mov	x0, #0x0                ; =0
1005885fc:     	bl	0x10002d97c
100588600:     	mov	x20, x0
100588604:     	bl	0x101ac6e44 ; symbol _$sSo17OS_dispatch_queueC8DispatchE4mainABvgZ
100588608:     	mov	x25, x0
10058860c:     	adrp	x0, 0x1021e1000
100588610:     	add	x0, x0, #0x8d0
100588614:     	mov	w1, #0x30               ; =48
100588618:     	mov	w2, #0x7                ; =7
10058861c:     	bl	0x101aca588 ; symbol _swift_allocObject
100588620:     	stp	x27, x22, [x0, #0x10]
100588624:     	stp	x26, x24, [x0, #0x20]
100588628:     	adrp	x8, 0x10058b000
10058862c:     	add	x8, x8, #0x964
100588630:     	stp	x8, x0, [x29, #-0x60]
100588634:     	adrp	x8, 0x1022cb000
100588638:     	ldr	x8, [x8, #0x300]
10058863c:     	stur	x8, [x29, #-0x80]
100588640:     	adrp	x8, 0x101ae1000
100588644:     	ldr	d0, [x8]
100588648:     	stur	d0, [x29, #-0x78]
10058864c:     	adrp	x8, 0x100004000
100588650:     	add	x8, x8, #0xd0
100588654:     	adrp	x9, 0x1021e1000
100588658:     	add	x9, x9, #0x8e8
10058865c:     	stp	x8, x9, [x29, #-0x70]
100588660:     	sub	x0, x29, #0x80
100588664:     	bl	0x101ac9514 ; symbol __Block_copy
100588668:     	mov	x26, x0
10058866c:     	ldur	x20, [x29, #-0x58]
100588670:     	mov	x0, x24
100588674:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100588678:     	mov	x0, x20
10058867c:     	bl	0x101aca960 ; symbol _swift_release
100588680:     	mov	x8, x23
100588684:     	bl	0x101ac5da0 ; symbol _$s8Dispatch0A3QoSV11unspecifiedACvgZ
100588688:     	adrp	x8, 0x1022cf000
10058868c:     	ldr	x8, [x8, #0x4a8]
100588690:     	stur	x8, [x29, #-0x80]
100588694:     	bl	0x100003c08
100588698:     	mov	x24, x0
10058869c:     	adrp	x0, 0x102340000
1005886a0:     	add	x0, x0, #0xc50
1005886a4:     	adrp	x1, 0x101ae1000
1005886a8:     	add	x1, x1, #0x280 ; possible literal '�14'
1005886ac:     	bl	0x100003c4c
1005886b0:     	mov	x20, x0
1005886b4:     	bl	0x100003c9c
1005886b8:     	mov	x2, x0
1005886bc:     	sub	x0, x29, #0x80
1005886c0:     	mov	x8, x21
1005886c4:     	mov	x1, x20
1005886c8:     	mov	x20, x19
1005886cc:     	mov	x3, x19
1005886d0:     	mov	x4, x24
1005886d4:     	bl	0x101ac7450 ; symbol _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
1005886d8:     	mov	x0, #0x0                ; =0
1005886dc:     	mov	x1, x23
1005886e0:     	mov	x2, x21
1005886e4:     	mov	x3, x26
1005886e8:     	mov	x20, x25
1005886ec:     	bl	0x101ac6e5c ; symbol _$sSo17OS_dispatch_queueC8DispatchE5async5group3qos5flags7executeySo0a1_b1_F0CSg_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
1005886f0:     	mov	x0, x26
1005886f4:     	bl	0x101ac9520 ; symbol __Block_release
1005886f8:     	mov	x0, x25
1005886fc:     	bl	0x101ac9d30 ; symbol _objc_release
100588700:     	ldur	x8, [x29, #-0x88]
100588704:     	ldr	x8, [x8, #0x8]
100588708:     	mov	x0, x21
10058870c:     	mov	x1, x19
100588710:     	blr	x8
100588714:     	ldr	x8, [x28, #0x8]
100588718:     	mov	x0, x23
10058871c:     	ldur	x1, [x29, #-0x90]
100588720:     	blr	x8
100588724:     	sub	sp, x29, #0x50
100588728:     	ldp	x29, x30, [sp, #0x50]
10058872c:     	ldp	x20, x19, [sp, #0x40]
100588730:     	ldp	x22, x21, [sp, #0x30]
100588734:     	ldp	x24, x23, [sp, #0x20]
100588738:     	ldp	x26, x25, [sp, #0x10]
10058873c:     	ldp	x28, x27, [sp], #0x60
100588740:     	ret
100588744:     	stp	x29, x30, [sp, #-0x10]!
100588748:     	mov	x29, sp
10058874c:     	ldr	x0, [x20, #0x18]
100588750:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100588754:     	mov	x0, x20
100588758:     	mov	w1, #0x20               ; =32
10058875c:     	mov	w2, #0x7                ; =7
100588760:     	ldp	x29, x30, [sp], #0x10
100588764:     	b	0x101aca6a8 ; symbol _swift_deallocObject
100588768:     	ldp	x0, x1, [x20, #0x10]
10058876c:     	b	0x100588514
100588770:     	sub	sp, sp, #0x90
100588774:     	stp	x28, x27, [sp, #0x30]
100588778:     	stp	x26, x25, [sp, #0x40]
10058877c:     	stp	x24, x23, [sp, #0x50]
100588780:     	stp	x22, x21, [sp, #0x60]
100588784:     	stp	x20, x19, [sp, #0x70]
100588788:     	stp	x29, x30, [sp, #0x80]
10058878c:     	add	x29, sp, #0x80
100588790:     	mov	x21, x2
100588794:     	mov	x19, x1
100588798:     	mov	x22, x0
10058879c:     	mov	w27, #0x7550            ; =30032
1005887a0:     	movk	w27, #0x6c6c, lsl #16
1005887a4:     	adrp	x0, 0x102341000
1005887a8:     	add	x0, x0, #0x6d0
1005887ac:     	adrp	x1, 0x101ae1000
1005887b0:     	add	x1, x1, #0x7e0 ; possible literal '\n14'
1005887b4:     	bl	0x100003c4c
1005887b8:     	mov	w1, #0x60               ; =96
1005887bc:     	mov	w2, #0x7                ; =7
1005887c0:     	bl	0x101aca588 ; symbol _swift_allocObject
1005887c4:     	adrp	x8, 0x101ae1000
1005887c8:     	ldr	q0, [x8, #0x120]
1005887cc:     	str	q0, [x0, #0x10]
1005887d0:     	mov	w8, #0x6967             ; =26983
1005887d4:     	movk	w8, #0x74, lsl #16
1005887d8:     	mov	x9, #-0x1d00000000000000 ; =-2089670227099910144
1005887dc:     	stp	x8, x9, [x0, #0x20]
1005887e0:     	mov	w8, #0x432d             ; =17197
1005887e4:     	mov	x9, #-0x1e00000000000000 ; =-2161727821137838080
1005887e8:     	stp	x8, x9, [x0, #0x30]
1005887ec:     	stp	x22, x19, [x0, #0x40]
1005887f0:     	orr	x8, x27, #0x20
1005887f4:     	mov	x9, #-0x1c00000000000000 ; =-2017612633061982208
1005887f8:     	stp	x8, x9, [x0, #0x50]
1005887fc:     	adrp	x8, 0x1022ca000
100588800:     	ldr	x8, [x8, #0x558]
100588804:     	ldr	x23, [x8]
100588808:     	cbz	x23, 0x100588a48
10058880c:     	mov	x20, x0
100588810:     	mov	x0, x19
100588814:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100588818:     	mov	x0, x23
10058881c:     	bl	0x101acf200 ; selector keyWindow
100588820:     	mov	x29, x29
100588824:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
100588828:     	cbz	x0, 0x100588a24
10058882c:     	mov	x23, x0
100588830:     	adrp	x8, 0x101ddd000
100588834:     	add	x8, x8, #0x7d0 ; possible literal 'Pull from Remote'
100588838:     	sub	x25, x8, #0x20
10058883c:     	adrp	x8, 0x101ddd000
100588840:     	add	x8, x8, #0x7f0 ; possible literal 'Pull latest changes from the remote repository?'
100588844:     	sub	x26, x8, #0x20
100588848:     	adrp	x8, 0x102326000
10058884c:     	ldr	x0, [x8, #0xaa8]
100588850:     	bl	0x101ac9cb8 ; symbol _objc_allocWithZone
100588854:     	bl	0x101ace2c0 ; selector init
100588858:     	mov	x24, x0
10058885c:     	mov	x28, #0x10              ; =16
100588860:     	movk	x28, #0xd000, lsl #48
100588864:     	orr	x1, x25, #0x8000000000000000
100588868:     	mov	x0, #0x10               ; =16
10058886c:     	movk	x0, #0xd000, lsl #48
100588870:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
100588874:     	mov	x25, x0
100588878:     	mov	x0, x24
10058887c:     	mov	x2, x25
100588880:     	bl	0x101ad3660 ; selector setMessageText:
100588884:     	mov	x0, x25
100588888:     	bl	0x101ac9d30 ; symbol _objc_release
10058888c:     	add	x0, x28, #0x1f
100588890:     	orr	x1, x26, #0x8000000000000000
100588894:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
100588898:     	mov	x25, x0
10058889c:     	mov	x0, x24
1005888a0:     	mov	x2, x25
1005888a4:     	bl	0x101ad30c0 ; selector setInformativeText:
1005888a8:     	mov	x0, x25
1005888ac:     	bl	0x101ac9d30 ; symbol _objc_release
1005888b0:     	mov	x28, #-0x1c00000000000000 ; =-2017612633061982208
1005888b4:     	mov	w0, #0x7550             ; =30032
1005888b8:     	movk	w0, #0x6c6c, lsl #16
1005888bc:     	mov	x1, #-0x1c00000000000000 ; =-2017612633061982208
1005888c0:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1005888c4:     	mov	x25, x0
1005888c8:     	mov	x0, x24
1005888cc:     	mov	x2, x25
1005888d0:     	bl	0x101acb200 ; selector addButtonWithTitle:
1005888d4:     	mov	x29, x29
1005888d8:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
1005888dc:     	mov	x26, x0
1005888e0:     	mov	x0, x25
1005888e4:     	bl	0x101ac9d30 ; symbol _objc_release
1005888e8:     	mov	x0, x26
1005888ec:     	bl	0x101ac9d30 ; symbol _objc_release
1005888f0:     	mov	x0, #0x6143             ; =24899
1005888f4:     	movk	x0, #0x636e, lsl #16
1005888f8:     	movk	x0, #0x6c65, lsl #32
1005888fc:     	mov	x1, #-0x1a00000000000000 ; =-1873497444986126336
100588900:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
100588904:     	mov	x25, x0
100588908:     	mov	x0, x24
10058890c:     	mov	x2, x25
100588910:     	bl	0x101acb200 ; selector addButtonWithTitle:
100588914:     	mov	x29, x29
100588918:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
10058891c:     	mov	x26, x0
100588920:     	mov	x0, x25
100588924:     	bl	0x101ac9d30 ; symbol _objc_release
100588928:     	mov	x0, x26
10058892c:     	bl	0x101ac9d30 ; symbol _objc_release
100588930:     	adrp	x0, 0x1021e1000
100588934:     	add	x0, x0, #0x450
100588938:     	mov	w1, #0x50               ; =80
10058893c:     	mov	w2, #0x7                ; =7
100588940:     	bl	0x101aca588 ; symbol _swift_allocObject
100588944:     	stp	x27, x28, [x0, #0x10]
100588948:     	mov	x8, #0x7550             ; =30032
10058894c:     	movk	x8, #0x6c6c, lsl #16
100588950:     	movk	x8, #0x6e69, lsl #32
100588954:     	movk	x8, #0x2e67, lsl #48
100588958:     	mov	x9, #0x2e2e             ; =11822
10058895c:     	movk	x9, #0xea00, lsl #48
100588960:     	stp	x8, x9, [x0, #0x20]
100588964:     	stp	x20, x22, [x0, #0x30]
100588968:     	stp	x19, x21, [x0, #0x40]
10058896c:     	adrp	x8, 0x100589000
100588970:     	add	x8, x8, #0x498
100588974:     	stp	x8, x0, [sp, #0x20]
100588978:     	adrp	x8, 0x1022cb000
10058897c:     	ldr	x8, [x8, #0x300]
100588980:     	str	x8, [sp]
100588984:     	adrp	x8, 0x101ae1000
100588988:     	ldr	d0, [x8]
10058898c:     	str	d0, [sp, #0x8]
100588990:     	adrp	x8, 0x100071000
100588994:     	add	x8, x8, #0xb1c
100588998:     	adrp	x9, 0x1021e1000
10058899c:     	add	x9, x9, #0x468
1005889a0:     	stp	x8, x9, [sp, #0x10]
1005889a4:     	mov	x0, sp
1005889a8:     	bl	0x101ac9514 ; symbol __Block_copy
1005889ac:     	mov	x22, x0
1005889b0:     	ldr	x25, [sp, #0x28]
1005889b4:     	mov	x0, x21
1005889b8:     	bl	0x101aca978 ; symbol _swift_retain
1005889bc:     	mov	x0, x19
1005889c0:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
1005889c4:     	mov	x0, x20
1005889c8:     	bl	0x101aca978 ; symbol _swift_retain
1005889cc:     	mov	x0, x25
1005889d0:     	bl	0x101aca960 ; symbol _swift_release
1005889d4:     	mov	x0, x24
1005889d8:     	mov	x2, x23
1005889dc:     	mov	x3, x22
1005889e0:     	bl	0x101acbb80 ; selector beginSheetModalForWindow:completionHandler:
1005889e4:     	mov	x0, x20
1005889e8:     	bl	0x101aca960 ; symbol _swift_release
1005889ec:     	mov	x0, x22
1005889f0:     	bl	0x101ac9520 ; symbol __Block_release
1005889f4:     	mov	x0, x23
1005889f8:     	bl	0x101ac9d30 ; symbol _objc_release
1005889fc:     	mov	x0, x24
100588a00:     	bl	0x101ac9d30 ; symbol _objc_release
100588a04:     	ldp	x29, x30, [sp, #0x80]
100588a08:     	ldp	x20, x19, [sp, #0x70]
100588a0c:     	ldp	x22, x21, [sp, #0x60]
100588a10:     	ldp	x24, x23, [sp, #0x50]
100588a14:     	ldp	x26, x25, [sp, #0x40]
100588a18:     	ldp	x28, x27, [sp, #0x30]
100588a1c:     	add	sp, sp, #0x90
100588a20:     	ret
100588a24:     	mov	x0, x20
100588a28:     	ldp	x29, x30, [sp, #0x80]
100588a2c:     	ldp	x20, x19, [sp, #0x70]
100588a30:     	ldp	x22, x21, [sp, #0x60]
100588a34:     	ldp	x24, x23, [sp, #0x50]
100588a38:     	ldp	x26, x25, [sp, #0x40]
100588a3c:     	ldp	x28, x27, [sp, #0x30]
100588a40:     	add	sp, sp, #0x90
100588a44:     	b	0x101aca960 ; symbol _swift_release
100588a48:     	brk	#0x1
100588a4c:     	sub	sp, sp, #0x80
100588a50:     	stp	x28, x27, [sp, #0x20]
100588a54:     	stp	x26, x25, [sp, #0x30]
100588a58:     	stp	x24, x23, [sp, #0x40]
100588a5c:     	stp	x22, x21, [sp, #0x50]
100588a60:     	stp	x20, x19, [sp, #0x60]
100588a64:     	stp	x29, x30, [sp, #0x70]
100588a68:     	add	x29, sp, #0x70
100588a6c:     	mov	x21, x1
100588a70:     	mov	x23, x0
100588a74:     	mov	x27, #0x6546            ; =25926
100588a78:     	movk	x27, #0x6374, lsl #16
100588a7c:     	movk	x27, #0x68, lsl #32
100588a80:     	adrp	x0, 0x102341000
100588a84:     	add	x0, x0, #0x6d0
100588a88:     	adrp	x1, 0x101ae1000
100588a8c:     	add	x1, x1, #0x7e0 ; possible literal '\n14'
100588a90:     	bl	0x100003c4c
100588a94:     	mov	w1, #0x60               ; =96
100588a98:     	mov	w2, #0x7                ; =7
100588a9c:     	bl	0x101aca588 ; symbol _swift_allocObject
100588aa0:     	mov	x19, x0
100588aa4:     	adrp	x8, 0x101ae1000
100588aa8:     	ldr	q0, [x8, #0x120]
100588aac:     	str	q0, [x0, #0x10]
100588ab0:     	mov	w8, #0x6967             ; =26983
100588ab4:     	movk	w8, #0x74, lsl #16
100588ab8:     	mov	x9, #-0x1d00000000000000 ; =-2089670227099910144
100588abc:     	stp	x8, x9, [x0, #0x20]
100588ac0:     	mov	w8, #0x432d             ; =17197
100588ac4:     	mov	x9, #-0x1e00000000000000 ; =-2161727821137838080
100588ac8:     	stp	x8, x9, [x0, #0x30]
100588acc:     	stp	x23, x21, [x0, #0x40]
100588ad0:     	orr	x8, x27, #0x20
100588ad4:     	mov	x28, #-0x1b00000000000000 ; =-1945555039024054272
100588ad8:     	stp	x8, x28, [x0, #0x50]
100588adc:     	adrp	x0, 0x1021e1000
100588ae0:     	add	x0, x0, #0x4a0
100588ae4:     	mov	w1, #0x18               ; =24
100588ae8:     	mov	w2, #0x7                ; =7
100588aec:     	bl	0x101aca588 ; symbol _swift_allocObject
100588af0:     	mov	x22, x0
100588af4:     	mov	x25, x0
100588af8:     	str	xzr, [x25, #0x10]!
100588afc:     	adrp	x0, 0x1021e1000
100588b00:     	add	x0, x0, #0x4c8
100588b04:     	mov	w1, #0x11               ; =17
100588b08:     	mov	w2, #0x7                ; =7
100588b0c:     	bl	0x101aca588 ; symbol _swift_allocObject
100588b10:     	mov	x24, x0
100588b14:     	strb	wzr, [x0, #0x10]
100588b18:     	mov	x0, x21
100588b1c:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100588b20:     	bl	0x10058a970
100588b24:     	cbz	x0, 0x100588bbc
100588b28:     	mov	x26, x0
100588b2c:     	mov	x0, #0x0                ; =0
100588b30:     	bl	0x100801674
100588b34:     	mov	x20, x0
100588b38:     	adrp	x0, 0x1021e1000
100588b3c:     	add	x0, x0, #0x518
100588b40:     	mov	w1, #0x20               ; =32
100588b44:     	mov	w2, #0x7                ; =7
100588b48:     	bl	0x101aca588 ; symbol _swift_allocObject
100588b4c:     	mov	x28, x27
100588b50:     	mov	x27, x0
100588b54:     	stp	x24, x22, [x0, #0x10]
100588b58:     	mov	x0, x24
100588b5c:     	bl	0x101aca978 ; symbol _swift_retain
100588b60:     	mov	x0, x22
100588b64:     	bl	0x101aca978 ; symbol _swift_retain
100588b68:     	adrp	x4, 0x10058a000
100588b6c:     	add	x4, x4, #0xb68
100588b70:     	mov	x0, #0x6546             ; =25926
100588b74:     	movk	x0, #0x6374, lsl #16
100588b78:     	movk	x0, #0x6968, lsl #32
100588b7c:     	movk	x0, #0x676e, lsl #48
100588b80:     	mov	x1, #0x2e2e             ; =11822
100588b84:     	movk	x1, #0x2e, lsl #16
100588b88:     	movk	x1, #0xeb00, lsl #48
100588b8c:     	mov	x2, x26
100588b90:     	mov	w3, #0x1                ; =1
100588b94:     	mov	x5, x27
100588b98:     	bl	0x1007ffdf8
100588b9c:     	mov	x20, x0
100588ba0:     	mov	x0, x26
100588ba4:     	bl	0x101ac9d30 ; symbol _objc_release
100588ba8:     	mov	x0, x27
100588bac:     	mov	x27, x28
100588bb0:     	mov	x28, #-0x1b00000000000000 ; =-1945555039024054272
100588bb4:     	bl	0x101aca960 ; symbol _swift_release
100588bb8:     	b	0x100588bc0
100588bbc:     	mov	x20, #0x0               ; =0
100588bc0:     	adrp	x0, 0x1021e1000
100588bc4:     	add	x0, x0, #0x4f0
100588bc8:     	mov	w1, #0x50               ; =80
100588bcc:     	mov	w2, #0x7                ; =7
100588bd0:     	bl	0x101aca588 ; symbol _swift_allocObject
100588bd4:     	mov	x26, x0
100588bd8:     	stp	x24, x22, [x0, #0x10]
100588bdc:     	stp	x20, x27, [x0, #0x20]
100588be0:     	stp	x28, x23, [x0, #0x30]
100588be4:     	stp	x21, xzr, [x0, #0x40]
100588be8:     	mov	x0, x20
100588bec:     	bl	0x101ac9d3c ; symbol _objc_retain
100588bf0:     	mov	x20, x0
100588bf4:     	mov	x0, x21
100588bf8:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100588bfc:     	mov	x0, x24
100588c00:     	bl	0x101aca978 ; symbol _swift_retain
100588c04:     	mov	x0, x22
100588c08:     	bl	0x101aca978 ; symbol _swift_retain
100588c0c:     	adrp	x1, 0x10058a000
100588c10:     	add	x1, x1, #0xb60
100588c14:     	mov	x0, x19
100588c18:     	mov	x2, x26
100588c1c:     	bl	0x1005854b0
100588c20:     	mov	x21, x0
100588c24:     	mov	x0, x26
100588c28:     	bl	0x101aca960 ; symbol _swift_release
100588c2c:     	mov	x0, x20
100588c30:     	bl	0x101ac9d30 ; symbol _objc_release
100588c34:     	mov	x0, x19
100588c38:     	bl	0x101aca960 ; symbol _swift_release
100588c3c:     	add	x1, sp, #0x8
100588c40:     	mov	x0, x25
100588c44:     	mov	w2, #0x1                ; =1
100588c48:     	mov	x3, #0x0                ; =0
100588c4c:     	bl	0x101aca600 ; symbol _swift_beginAccess
100588c50:     	ldr	x19, [x22, #0x10]
100588c54:     	str	x21, [x22, #0x10]
100588c58:     	mov	x0, x22
100588c5c:     	bl	0x101aca960 ; symbol _swift_release
100588c60:     	mov	x0, x24
100588c64:     	bl	0x101aca960 ; symbol _swift_release
100588c68:     	mov	x0, x19
100588c6c:     	bl	0x101ac9d30 ; symbol _objc_release
100588c70:     	ldp	x29, x30, [sp, #0x70]
100588c74:     	ldp	x20, x19, [sp, #0x60]
100588c78:     	ldp	x22, x21, [sp, #0x50]
100588c7c:     	ldp	x24, x23, [sp, #0x40]
100588c80:     	ldp	x26, x25, [sp, #0x30]
100588c84:     	ldp	x28, x27, [sp, #0x20]
100588c88:     	add	sp, sp, #0x80
100588c8c:     	ret
100588c90:     	stp	x28, x27, [sp, #-0x60]!
100588c94:     	stp	x26, x25, [sp, #0x10]
100588c98:     	stp	x24, x23, [sp, #0x20]
100588c9c:     	stp	x22, x21, [sp, #0x30]
100588ca0:     	stp	x20, x19, [sp, #0x40]
100588ca4:     	stp	x29, x30, [sp, #0x50]
100588ca8:     	add	x29, sp, #0x50
100588cac:     	sub	sp, sp, #0x70
100588cb0:     	stur	x2, [x29, #-0xb0]
100588cb4:     	mov	x25, x1
100588cb8:     	mov	x28, x0
100588cbc:     	mov	x0, #0x0                ; =0
100588cc0:     	bl	0x101ac5d88 ; symbol _$s8Dispatch0A13WorkItemFlagsVMa
100588cc4:     	stur	x0, [x29, #-0xa8]
100588cc8:     	ldur	x8, [x0, #-0x8]
100588ccc:     	stur	x8, [x29, #-0x90]
100588cd0:     	ldr	x8, [x8, #0x40]
100588cd4:     	mov	x9, x8
100588cd8:     	adrp	x16, 0x1022cb000
100588cdc:     	ldr	x16, [x16, #0x398]
100588ce0:     	blr	x16
100588ce4:     	mov	x9, sp
100588ce8:     	add	x8, x8, #0xf
100588cec:     	and	x8, x8, #0xfffffffffffffff0
100588cf0:     	sub	x21, x9, x8
100588cf4:     	mov	sp, x21
100588cf8:     	mov	x0, #0x0                ; =0
100588cfc:     	bl	0x101ac5dc4 ; symbol _$s8Dispatch0A3QoSVMa
100588d00:     	ldur	x8, [x0, #-0x8]
100588d04:     	stp	x8, x0, [x29, #-0xa0]
100588d08:     	ldr	x8, [x8, #0x40]
100588d0c:     	mov	x9, x8
100588d10:     	adrp	x16, 0x1022cb000
100588d14:     	ldr	x16, [x16, #0x398]
100588d18:     	blr	x16
100588d1c:     	mov	x9, sp
100588d20:     	add	x8, x8, #0xf
100588d24:     	and	x8, x8, #0xfffffffffffffff0
100588d28:     	sub	x23, x9, x8
100588d2c:     	mov	sp, x23
100588d30:     	mov	x0, #0x0                ; =0
100588d34:     	bl	0x101ac5d94 ; symbol _$s8Dispatch0A3QoSV0B6SClassOMa
100588d38:     	mov	x22, x0
100588d3c:     	ldur	x19, [x0, #-0x8]
100588d40:     	ldr	x8, [x19, #0x40]
100588d44:     	mov	x9, x8
100588d48:     	adrp	x16, 0x1022cb000
100588d4c:     	ldr	x16, [x16, #0x398]
100588d50:     	blr	x16
100588d54:     	mov	x9, sp
100588d58:     	add	x8, x8, #0xf
100588d5c:     	and	x8, x8, #0xfffffffffffffff0
100588d60:     	sub	x26, x9, x8
100588d64:     	mov	sp, x26
100588d68:     	adrp	x8, 0x101ddd000
100588d6c:     	add	x8, x8, #0x820 ; possible literal 'Select a branch to merge into the current branch:'
100588d70:     	sub	x8, x8, #0x20
100588d74:     	orr	x8, x8, #0x8000000000000000
100588d78:     	stur	x8, [x29, #-0xb8]
100588d7c:     	adrp	x0, 0x1021e1000
100588d80:     	add	x0, x0, #0x540
100588d84:     	mov	w1, #0x20               ; =32
100588d88:     	mov	w2, #0x7                ; =7
100588d8c:     	bl	0x101aca588 ; symbol _swift_allocObject
100588d90:     	mov	x24, x0
100588d94:     	stp	x28, x25, [x0, #0x10]
100588d98:     	adrp	x1, 0x102340000
100588d9c:     	add	x1, x1, #0xc40
100588da0:     	adrp	x2, 0x102326000
100588da4:     	add	x2, x2, #0x9d8
100588da8:     	mov	x0, #0x0                ; =0
100588dac:     	bl	0x10002d97c
100588db0:     	mov	x20, x0
100588db4:     	adrp	x8, 0x1022cf000
100588db8:     	ldr	x8, [x8, #0x950]
100588dbc:     	ldr	w1, [x8]
100588dc0:     	ldr	x8, [x19, #0x68]
100588dc4:     	mov	x0, x26
100588dc8:     	mov	x2, x22
100588dcc:     	blr	x8
100588dd0:     	mov	x0, x25
100588dd4:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100588dd8:     	mov	x0, x26
100588ddc:     	bl	0x101ac6e80 ; symbol _$sSo17OS_dispatch_queueC8DispatchE6global3qosAbC0D3QoSV0G6SClassO_tFZ
100588de0:     	mov	x27, x0
100588de4:     	ldr	x8, [x19, #0x8]
100588de8:     	mov	x0, x26
100588dec:     	mov	x1, x22
100588df0:     	blr	x8
100588df4:     	adrp	x0, 0x1021e1000
100588df8:     	add	x0, x0, #0x568
100588dfc:     	mov	w1, #0x68               ; =104
100588e00:     	mov	w2, #0x7                ; =7
100588e04:     	bl	0x101aca588 ; symbol _swift_allocObject
100588e08:     	stp	x28, x25, [x0, #0x10]
100588e0c:     	mov	x8, #0x654d             ; =25933
100588e10:     	movk	x8, #0x6772, lsl #16
100588e14:     	movk	x8, #0x2065, lsl #32
100588e18:     	movk	x8, #0x7242, lsl #48
100588e1c:     	mov	x9, #0x6e61             ; =28257
100588e20:     	movk	x9, #0x6863, lsl #16
100588e24:     	movk	x9, #0xec00, lsl #48
100588e28:     	stp	x8, x9, [x0, #0x20]
100588e2c:     	mov	x8, #0x31               ; =49
100588e30:     	movk	x8, #0xd000, lsl #48
100588e34:     	str	x8, [x0, #0x30]
100588e38:     	ldp	x10, x19, [x29, #-0xb8]
100588e3c:     	mov	x8, #0x654d             ; =25933
100588e40:     	movk	x8, #0x6772, lsl #16
100588e44:     	movk	x8, #0x65, lsl #32
100588e48:     	mov	x9, #-0x1b00000000000000 ; =-1945555039024054272
100588e4c:     	stp	x10, x8, [x0, #0x38]
100588e50:     	stp	x9, x19, [x0, #0x48]
100588e54:     	adrp	x8, 0x10058a000
100588e58:     	add	x8, x8, #0xb70
100588e5c:     	stp	x8, x24, [x0, #0x58]
100588e60:     	adrp	x8, 0x10058a000
100588e64:     	add	x8, x8, #0xbc0
100588e68:     	stp	x8, x0, [x29, #-0x60]
100588e6c:     	adrp	x8, 0x1022cb000
100588e70:     	ldr	x8, [x8, #0x300]
100588e74:     	stur	x8, [x29, #-0x80]
100588e78:     	adrp	x8, 0x101ae1000
100588e7c:     	ldr	d0, [x8]
100588e80:     	stur	d0, [x29, #-0x78]
100588e84:     	adrp	x8, 0x100004000
100588e88:     	add	x8, x8, #0xd0
100588e8c:     	adrp	x9, 0x1021e1000
100588e90:     	add	x9, x9, #0x580
100588e94:     	stp	x8, x9, [x29, #-0x70]
100588e98:     	sub	x0, x29, #0x80
100588e9c:     	bl	0x101ac9514 ; symbol __Block_copy
100588ea0:     	mov	x22, x0
100588ea4:     	mov	x0, x19
100588ea8:     	bl	0x101aca978 ; symbol _swift_retain
100588eac:     	mov	x0, x24
100588eb0:     	bl	0x101aca978 ; symbol _swift_retain
100588eb4:     	mov	x0, x25
100588eb8:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100588ebc:     	mov	x8, x23
100588ec0:     	bl	0x101ac5da0 ; symbol _$s8Dispatch0A3QoSV11unspecifiedACvgZ
100588ec4:     	adrp	x8, 0x1022cf000
100588ec8:     	ldr	x8, [x8, #0x4a8]
100588ecc:     	stur	x8, [x29, #-0x88]
100588ed0:     	bl	0x100003c08
100588ed4:     	mov	x25, x0
100588ed8:     	adrp	x0, 0x102340000
100588edc:     	add	x0, x0, #0xc50
100588ee0:     	adrp	x1, 0x101ae1000
100588ee4:     	add	x1, x1, #0x280 ; possible literal '�14'
100588ee8:     	bl	0x100003c4c
100588eec:     	mov	x20, x0
100588ef0:     	bl	0x100003c9c
100588ef4:     	mov	x2, x0
100588ef8:     	sub	x0, x29, #0x88
100588efc:     	mov	x8, x21
100588f00:     	mov	x1, x20
100588f04:     	ldur	x19, [x29, #-0xa8]
100588f08:     	mov	x20, x19
100588f0c:     	mov	x3, x19
100588f10:     	mov	x4, x25
100588f14:     	bl	0x101ac7450 ; symbol _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
100588f18:     	mov	x0, #0x0                ; =0
100588f1c:     	mov	x1, x23
100588f20:     	mov	x2, x21
100588f24:     	mov	x3, x22
100588f28:     	mov	x20, x27
100588f2c:     	bl	0x101ac6e5c ; symbol _$sSo17OS_dispatch_queueC8DispatchE5async5group3qos5flags7executeySo0a1_b1_F0CSg_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
100588f30:     	mov	x0, x22
100588f34:     	bl	0x101ac9520 ; symbol __Block_release
100588f38:     	mov	x0, x27
100588f3c:     	bl	0x101ac9d30 ; symbol _objc_release
100588f40:     	ldur	x8, [x29, #-0x90]
100588f44:     	ldr	x8, [x8, #0x8]
100588f48:     	mov	x0, x21
100588f4c:     	mov	x1, x19
100588f50:     	blr	x8
100588f54:     	ldp	x8, x1, [x29, #-0xa0]
100588f58:     	ldr	x8, [x8, #0x8]
100588f5c:     	mov	x0, x23
100588f60:     	blr	x8
100588f64:     	ldur	x0, [x29, #-0x58]
100588f68:     	bl	0x101aca960 ; symbol _swift_release
100588f6c:     	mov	x0, x24
100588f70:     	bl	0x101aca960 ; symbol _swift_release
100588f74:     	sub	sp, x29, #0x50
100588f78:     	ldp	x29, x30, [sp, #0x50]
100588f7c:     	ldp	x20, x19, [sp, #0x40]
100588f80:     	ldp	x22, x21, [sp, #0x30]
100588f84:     	ldp	x24, x23, [sp, #0x20]
100588f88:     	ldp	x26, x25, [sp, #0x10]
100588f8c:     	ldp	x28, x27, [sp], #0x60
100588f90:     	ret
100588f94:     	stp	x28, x27, [sp, #-0x60]!
100588f98:     	stp	x26, x25, [sp, #0x10]
100588f9c:     	stp	x24, x23, [sp, #0x20]
100588fa0:     	stp	x22, x21, [sp, #0x30]
100588fa4:     	stp	x20, x19, [sp, #0x40]
100588fa8:     	stp	x29, x30, [sp, #0x50]
100588fac:     	add	x29, sp, #0x50
100588fb0:     	sub	sp, sp, #0x70
100588fb4:     	stur	x2, [x29, #-0xb0]
100588fb8:     	mov	x24, x1
100588fbc:     	mov	x19, x0
100588fc0:     	mov	x0, #0x0                ; =0
100588fc4:     	bl	0x101ac5d88 ; symbol _$s8Dispatch0A13WorkItemFlagsVMa
100588fc8:     	stur	x0, [x29, #-0xa8]
100588fcc:     	ldur	x8, [x0, #-0x8]
100588fd0:     	stur	x8, [x29, #-0x90]
100588fd4:     	ldr	x8, [x8, #0x40]
100588fd8:     	mov	x9, x8
100588fdc:     	adrp	x16, 0x1022cb000
100588fe0:     	ldr	x16, [x16, #0x398]
100588fe4:     	blr	x16
100588fe8:     	mov	x9, sp
100588fec:     	add	x8, x8, #0xf ; possible literal '�t\n'
100588ff0:     	and	x8, x8, #0xfffffffffffffff0
100588ff4:     	sub	x21, x9, x8
100588ff8:     	mov	sp, x21
100588ffc:     	mov	x0, #0x0                ; =0
100589000:     	bl	0x101ac5dc4 ; symbol _$s8Dispatch0A3QoSVMa
100589004:     	ldur	x8, [x0, #-0x8]
100589008:     	stp	x8, x0, [x29, #-0xa0]
10058900c:     	ldr	x8, [x8, #0x40]
100589010:     	mov	x9, x8
100589014:     	adrp	x16, 0x1022cb000
100589018:     	ldr	x16, [x16, #0x398]
10058901c:     	blr	x16
100589020:     	mov	x9, sp
100589024:     	add	x8, x8, #0xf
100589028:     	and	x8, x8, #0xfffffffffffffff0
10058902c:     	sub	x23, x9, x8
100589030:     	mov	sp, x23
100589034:     	mov	x0, #0x0                ; =0
100589038:     	bl	0x101ac5d94 ; symbol _$s8Dispatch0A3QoSV0B6SClassOMa
10058903c:     	mov	x22, x0
100589040:     	ldur	x28, [x0, #-0x8]
100589044:     	ldr	x8, [x28, #0x40]
100589048:     	mov	x9, x8
10058904c:     	adrp	x16, 0x1022cb000
100589050:     	ldr	x16, [x16, #0x398]
100589054:     	blr	x16
100589058:     	mov	x9, sp
10058905c:     	add	x8, x8, #0xf
100589060:     	and	x8, x8, #0xfffffffffffffff0
100589064:     	sub	x26, x9, x8
100589068:     	mov	sp, x26
10058906c:     	adrp	x8, 0x101ddd000
100589070:     	add	x8, x8, #0x860 ; possible literal 'Rebase onto Branch'
100589074:     	sub	x8, x8, #0x20
100589078:     	orr	x8, x8, #0x8000000000000000
10058907c:     	stur	x8, [x29, #-0xc0]
100589080:     	adrp	x8, 0x101ddd000
100589084:     	add	x8, x8, #0x880 ; possible literal 'Select a branch to rebase the current branch onto:'
100589088:     	sub	x8, x8, #0x20
10058908c:     	orr	x27, x8, #0x8000000000000000
100589090:     	adrp	x0, 0x1021e1000
100589094:     	add	x0, x0, #0x5b8
100589098:     	mov	w1, #0x20               ; =32
10058909c:     	mov	w2, #0x7                ; =7
1005890a0:     	bl	0x101aca588 ; symbol _swift_allocObject
1005890a4:     	mov	x25, x0
1005890a8:     	stp	x19, x24, [x0, #0x10]
1005890ac:     	adrp	x1, 0x102340000
1005890b0:     	add	x1, x1, #0xc40
1005890b4:     	adrp	x2, 0x102326000
1005890b8:     	add	x2, x2, #0x9d8
1005890bc:     	mov	x0, #0x0                ; =0
1005890c0:     	bl	0x10002d97c
1005890c4:     	mov	x20, x0
1005890c8:     	adrp	x8, 0x1022cf000
1005890cc:     	ldr	x8, [x8, #0x950]
1005890d0:     	ldr	w1, [x8]
1005890d4:     	ldr	x8, [x28, #0x68]
1005890d8:     	mov	x0, x26
1005890dc:     	mov	x2, x22
1005890e0:     	blr	x8
1005890e4:     	mov	x0, x24
1005890e8:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
1005890ec:     	mov	x0, x26
1005890f0:     	bl	0x101ac6e80 ; symbol _$sSo17OS_dispatch_queueC8DispatchE6global3qosAbC0D3QoSV0G6SClassO_tFZ
1005890f4:     	stur	x0, [x29, #-0xb8]
1005890f8:     	ldr	x8, [x28, #0x8]
1005890fc:     	mov	x0, x26
100589100:     	mov	x1, x22
100589104:     	blr	x8
100589108:     	adrp	x0, 0x1021e1000
10058910c:     	add	x0, x0, #0x5e0
100589110:     	mov	w1, #0x68               ; =104
100589114:     	mov	w2, #0x7                ; =7
100589118:     	bl	0x101aca588 ; symbol _swift_allocObject
10058911c:     	stp	x19, x24, [x0, #0x10]
100589120:     	mov	x8, #0x12               ; =18
100589124:     	movk	x8, #0xd000, lsl #48
100589128:     	ldur	x9, [x29, #-0xc0]
10058912c:     	stp	x8, x9, [x0, #0x20]
100589130:     	orr	x8, x8, #0x20
100589134:     	stp	x8, x27, [x0, #0x30]
100589138:     	mov	x8, #0x6552             ; =25938
10058913c:     	movk	x8, #0x6162, lsl #16
100589140:     	movk	x8, #0x6573, lsl #32
100589144:     	mov	x9, #-0x1a00000000000000 ; =-1873497444986126336
100589148:     	stp	x8, x9, [x0, #0x40]
10058914c:     	adrp	x8, 0x10058a000
100589150:     	add	x8, x8, #0xbc4
100589154:     	ldur	x19, [x29, #-0xb0]
100589158:     	stp	x19, x8, [x0, #0x50]
10058915c:     	str	x25, [x0, #0x60]
100589160:     	adrp	x8, 0x10058b000
100589164:     	add	x8, x8, #0xe10
100589168:     	stp	x8, x0, [x29, #-0x60]
10058916c:     	adrp	x8, 0x1022cb000
100589170:     	ldr	x8, [x8, #0x300]
100589174:     	stur	x8, [x29, #-0x80]
100589178:     	adrp	x8, 0x101ae1000
10058917c:     	ldr	d0, [x8]
100589180:     	stur	d0, [x29, #-0x78]
100589184:     	adrp	x8, 0x100004000
100589188:     	add	x8, x8, #0xd0
10058918c:     	adrp	x9, 0x1021e1000
100589190:     	add	x9, x9, #0x5f8
100589194:     	stp	x8, x9, [x29, #-0x70]
100589198:     	sub	x0, x29, #0x80
10058919c:     	bl	0x101ac9514 ; symbol __Block_copy
1005891a0:     	mov	x22, x0
1005891a4:     	mov	x0, x19
1005891a8:     	bl	0x101aca978 ; symbol _swift_retain
1005891ac:     	mov	x0, x25
1005891b0:     	bl	0x101aca978 ; symbol _swift_retain
1005891b4:     	mov	x0, x24
1005891b8:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
1005891bc:     	mov	x8, x23
1005891c0:     	bl	0x101ac5da0 ; symbol _$s8Dispatch0A3QoSV11unspecifiedACvgZ
1005891c4:     	adrp	x8, 0x1022cf000
1005891c8:     	ldr	x8, [x8, #0x4a8]
1005891cc:     	stur	x8, [x29, #-0x88]
1005891d0:     	bl	0x100003c08
1005891d4:     	mov	x24, x0
1005891d8:     	adrp	x0, 0x102340000
1005891dc:     	add	x0, x0, #0xc50
1005891e0:     	adrp	x1, 0x101ae1000
1005891e4:     	add	x1, x1, #0x280 ; possible literal '�14'
1005891e8:     	bl	0x100003c4c
1005891ec:     	mov	x20, x0
1005891f0:     	bl	0x100003c9c
1005891f4:     	mov	x2, x0
1005891f8:     	sub	x0, x29, #0x88
1005891fc:     	mov	x8, x21
100589200:     	mov	x1, x20
100589204:     	ldur	x19, [x29, #-0xa8]
100589208:     	mov	x20, x19
10058920c:     	mov	x3, x19
100589210:     	mov	x4, x24
100589214:     	bl	0x101ac7450 ; symbol _$ss10SetAlgebraPyxqd__ncSTRd__7ElementQyd__ACRtzlufCTj
100589218:     	mov	x0, #0x0                ; =0
10058921c:     	mov	x1, x23
100589220:     	mov	x2, x21
100589224:     	mov	x3, x22
100589228:     	ldur	x20, [x29, #-0xb8]
10058922c:     	bl	0x101ac6e5c ; symbol _$sSo17OS_dispatch_queueC8DispatchE5async5group3qos5flags7executeySo0a1_b1_F0CSg_AC0D3QoSVAC0D13WorkItemFlagsVyyXBtF
100589230:     	mov	x0, x22
100589234:     	bl	0x101ac9520 ; symbol __Block_release
100589238:     	mov	x0, x20
10058923c:     	bl	0x101ac9d30 ; symbol _objc_release
100589240:     	ldur	x8, [x29, #-0x90]
100589244:     	ldr	x8, [x8, #0x8]
100589248:     	mov	x0, x21
10058924c:     	mov	x1, x19
100589250:     	blr	x8
100589254:     	ldp	x8, x1, [x29, #-0xa0]
100589258:     	ldr	x8, [x8, #0x8]
10058925c:     	mov	x0, x23
100589260:     	blr	x8
100589264:     	ldur	x0, [x29, #-0x58]
100589268:     	bl	0x101aca960 ; symbol _swift_release
10058926c:     	mov	x0, x25
100589270:     	bl	0x101aca960 ; symbol _swift_release
100589274:     	sub	sp, x29, #0x50
100589278:     	ldp	x29, x30, [sp, #0x50]
10058927c:     	ldp	x20, x19, [sp, #0x40]
100589280:     	ldp	x22, x21, [sp, #0x30]
100589284:     	ldp	x24, x23, [sp, #0x20]
100589288:     	ldp	x26, x25, [sp, #0x10]
10058928c:     	ldp	x28, x27, [sp], #0x60
100589290:     	ret
100589294:     	cmp	x0, #0x3e8
100589298:     	b.ne	0x100589494
10058929c:     	sub	sp, sp, #0xa0
1005892a0:     	stp	x28, x27, [sp, #0x40]
1005892a4:     	stp	x26, x25, [sp, #0x50]
1005892a8:     	stp	x24, x23, [sp, #0x60]
1005892ac:     	stp	x22, x21, [sp, #0x70]
1005892b0:     	stp	x20, x19, [sp, #0x80]
1005892b4:     	stp	x29, x30, [sp, #0x90]
1005892b8:     	add	x29, sp, #0x90
1005892bc:     	mov	x22, x7
1005892c0:     	mov	x28, x6
1005892c4:     	mov	x27, x5
1005892c8:     	mov	x20, x4
1005892cc:     	mov	x21, x3
1005892d0:     	mov	x25, x2
1005892d4:     	str	x1, [sp, #0x20]
1005892d8:     	ldr	x8, [x29, #0x10]
1005892dc:     	str	x8, [sp, #0x18]
1005892e0:     	adrp	x0, 0x1021e1000
1005892e4:     	add	x0, x0, #0x4a0
1005892e8:     	mov	w1, #0x18               ; =24
1005892ec:     	mov	w2, #0x7                ; =7
1005892f0:     	bl	0x101aca588 ; symbol _swift_allocObject
1005892f4:     	mov	x19, x0
1005892f8:     	mov	x24, x0
1005892fc:     	str	xzr, [x24, #0x10]!
100589300:     	adrp	x0, 0x1021e1000
100589304:     	add	x0, x0, #0x4c8
100589308:     	mov	w1, #0x11               ; =17
10058930c:     	mov	w2, #0x7                ; =7
100589310:     	bl	0x101aca588 ; symbol _swift_allocObject
100589314:     	mov	x23, x0
100589318:     	strb	wzr, [x0, #0x10]
10058931c:     	bl	0x10058a970
100589320:     	cbz	x0, 0x1005893b4
100589324:     	mov	x26, x0
100589328:     	mov	x0, #0x0                ; =0
10058932c:     	bl	0x100801674
100589330:     	str	x27, [sp, #0x10]
100589334:     	mov	x27, x0
100589338:     	adrp	x0, 0x1021e1000
10058933c:     	add	x0, x0, #0x8a8
100589340:     	mov	w1, #0x20               ; =32
100589344:     	mov	w2, #0x7                ; =7
100589348:     	bl	0x101aca588 ; symbol _swift_allocObject
10058934c:     	str	x22, [sp, #0x8]
100589350:     	mov	x22, x28
100589354:     	mov	x28, x0
100589358:     	stp	x23, x19, [x0, #0x10]
10058935c:     	mov	x0, x23
100589360:     	bl	0x101aca978 ; symbol _swift_retain
100589364:     	mov	x0, x19
100589368:     	bl	0x101aca978 ; symbol _swift_retain
10058936c:     	adrp	x4, 0x10058b000
100589370:     	add	x4, x4, #0xe00
100589374:     	mov	x0, x21
100589378:     	mov	x1, x20
10058937c:     	mov	x2, x26
100589380:     	mov	w3, #0x1                ; =1
100589384:     	mov	x5, x28
100589388:     	mov	x20, x27
10058938c:     	ldr	x27, [sp, #0x10]
100589390:     	bl	0x1007ffdf8
100589394:     	mov	x20, x0
100589398:     	mov	x0, x26
10058939c:     	bl	0x101ac9d30 ; symbol _objc_release
1005893a0:     	mov	x0, x28
1005893a4:     	mov	x28, x22
1005893a8:     	ldr	x22, [sp, #0x8]
1005893ac:     	bl	0x101aca960 ; symbol _swift_release
1005893b0:     	b	0x1005893b8
1005893b4:     	mov	x20, #0x0               ; =0
1005893b8:     	adrp	x0, 0x1021e1000
1005893bc:     	add	x0, x0, #0x880
1005893c0:     	mov	w1, #0x50               ; =80
1005893c4:     	mov	w2, #0x7                ; =7
1005893c8:     	bl	0x101aca588 ; symbol _swift_allocObject
1005893cc:     	mov	x21, x0
1005893d0:     	stp	x23, x19, [x0, #0x10]
1005893d4:     	ldr	x8, [sp, #0x20]
1005893d8:     	stp	x20, x8, [x0, #0x20]
1005893dc:     	stp	x25, x28, [x0, #0x30]
1005893e0:     	str	x22, [x0, #0x40]
1005893e4:     	ldr	x0, [sp, #0x18]
1005893e8:     	str	x0, [x21, #0x48]
1005893ec:     	bl	0x101aca978 ; symbol _swift_retain
1005893f0:     	mov	x0, x23
1005893f4:     	bl	0x101aca978 ; symbol _swift_retain
1005893f8:     	mov	x0, x19
1005893fc:     	bl	0x101aca978 ; symbol _swift_retain
100589400:     	mov	x0, x20
100589404:     	bl	0x101ac9d3c ; symbol _objc_retain
100589408:     	mov	x20, x0
10058940c:     	mov	x0, x25
100589410:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
100589414:     	mov	x0, x22
100589418:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10058941c:     	adrp	x1, 0x10058b000
100589420:     	add	x1, x1, #0xe04
100589424:     	mov	x0, x27
100589428:     	mov	x2, x21
10058942c:     	bl	0x1005854b0
100589430:     	mov	x22, x0
100589434:     	mov	x0, x21
100589438:     	bl	0x101aca960 ; symbol _swift_release
10058943c:     	mov	x0, x20
100589440:     	bl	0x101ac9d30 ; symbol _objc_release
100589444:     	add	x1, sp, #0x28
100589448:     	mov	x0, x24
10058944c:     	mov	w2, #0x1                ; =1
100589450:     	mov	x3, #0x0                ; =0
100589454:     	bl	0x101aca600 ; symbol _swift_beginAccess
100589458:     	ldr	x20, [x19, #0x10]
10058945c:     	str	x22, [x19, #0x10]
100589460:     	mov	x0, x19
100589464:     	bl	0x101aca960 ; symbol _swift_release
100589468:     	mov	x0, x23
10058946c:     	bl	0x101aca960 ; symbol _swift_release
100589470:     	mov	x0, x20
100589474:     	bl	0x101ac9d30 ; symbol _objc_release
100589478:     	ldp	x29, x30, [sp, #0x90]
10058947c:     	ldp	x20, x19, [sp, #0x80]
100589480:     	ldp	x22, x21, [sp, #0x70]
100589484:     	ldp	x24, x23, [sp, #0x60]
100589488:     	ldp	x26, x25, [sp, #0x50]
10058948c:     	ldp	x28, x27, [sp, #0x40]
100589490:     	add	sp, sp, #0xa0
100589494:     	ret
100589498:     	adrp	x1, 0x100589000
10058949c:     	add	x1, x1, #0x294
1005894a0:     	b	0x10058bcd4
1005894a4:     	stp	x29, x30, [sp, #-0x10]!
1005894a8:     	mov	x29, sp
1005894ac:     	ldr	x0, [x20, #0x10]
1005894b0:     	bl	0x101ac9d30 ; symbol _objc_release
1005894b4:     	mov	x0, x20
1005894b8:     	mov	w1, #0x18               ; =24
1005894bc:     	mov	w2, #0x7                ; =7
1005894c0:     	ldp	x29, x30, [sp], #0x10
1005894c4:     	b	0x101aca6a8 ; symbol _swift_deallocObject
1005894c8:     	mov	x0, x20
1005894cc:     	mov	w1, #0x11               ; =17
1005894d0:     	mov	w2, #0x7                ; =7
1005894d4:     	b	0x101aca6a8 ; symbol _swift_deallocObject
1005894d8:     	stp	x28, x27, [sp, #-0x60]!
1005894dc:     	stp	x26, x25, [sp, #0x10]
1005894e0:     	stp	x24, x23, [sp, #0x20]
1005894e4:     	stp	x22, x21, [sp, #0x30]
1005894e8:     	stp	x20, x19, [sp, #0x40]
1005894ec:     	stp	x29, x30, [sp, #0x50]
1005894f0:     	add	x29, sp, #0x50
1005894f4:     	sub	sp, sp, #0x80
1005894f8:     	stp	x6, x7, [x29, #-0xb8]
1005894fc:     	stur	x4, [x29, #-0xd0]
