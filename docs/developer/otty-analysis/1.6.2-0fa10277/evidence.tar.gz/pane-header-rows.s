1004a6000:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004a6004:	mov	x20, x0
1004a6008:	ldr	x0, [sp, #0x10]
1004a600c:	mov	x2, x20
1004a6010:	bl	0x101acf240 ; selector labelWithString:
1004a6014:	mov	x29, x29
1004a6018:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a601c:	mov	x21, x0
1004a6020:	mov	x0, x20
1004a6024:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6028:	mov	x0, x21
1004a602c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a6030:	mov	x20, x0
1004a6034:	bl	0x10002dd04
1004a6038:	mov.16b	v1, v0
1004a603c:	fmov	d0, #14.00000000
1004a6040:	bl	0x100004700
1004a6044:	mov	x21, x0
1004a6048:	mov	x0, x20
1004a604c:	mov	x2, x21
1004a6050:	bl	0x101ad2aa0 ; selector setFont:
1004a6054:	mov	x0, x21
1004a6058:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a605c:	ldr	x0, [sp, #0x18]
1004a6060:	bl	0x101ad58a0 ; selector tertiaryLabelColor
1004a6064:	mov	x29, x29
1004a6068:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a606c:	mov	x21, x0
1004a6070:	mov	x0, x20
1004a6074:	mov	x2, x21
1004a6078:	bl	0x101ad4660 ; selector setTextColor:
1004a607c:	mov	x0, x21
1004a6080:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6084:	mov	x0, x20
1004a6088:	mov	w2, #0x2
1004a608c:	bl	0x101ad1820 ; selector setAlignment:
1004a6090:	mov	x0, x20
1004a6094:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6098:	mov	x0, x20
1004a609c:	bl	0x101ad4fe0 ; selector sizeToFit
1004a60a0:	mov	x0, x20
1004a60a4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a60a8:	mov	x20, x0
1004a60ac:	mov	x0, x19
1004a60b0:	bl	0x101acbde0 ; selector bounds
1004a60b4:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004a60b8:	mov.16b	v9, v0
1004a60bc:	mov	x0, x20
1004a60c0:	bl	0x101acdcc0 ; selector frame
1004a60c4:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004a60c8:	fsub	d0, d9, d0
1004a60cc:	fmov	d1, #0.50000000
1004a60d0:	fmul	d9, d0, d1
1004a60d4:	mov	x0, x20
1004a60d8:	bl	0x101acdcc0 ; selector frame
1004a60dc:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004a60e0:	mov.16b	v3, v0
1004a60e4:	fmov	d2, #16.00000000
1004a60e8:	mov	x0, x20
1004a60ec:	mov.16b	v0, v8
1004a60f0:	mov.16b	v1, v9
1004a60f4:	bl	0x101ad2b80 ; selector setFrame:
1004a60f8:	mov	x0, x20
1004a60fc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6100:	mov	x0, x20
1004a6104:	mov	w2, #0x0
1004a6108:	bl	0x101ad28e0 ; selector setEditable:
1004a610c:	mov	x0, x20
1004a6110:	mov	w2, #0x0
1004a6114:	bl	0x101ad1fa0 ; selector setBordered:
1004a6118:	mov	x0, x20
1004a611c:	mov	w2, #0x0
1004a6120:	bl	0x101ad2860 ; selector setDrawsBackground:
1004a6124:	mov	x0, x19
1004a6128:	mov	x2, x20
1004a612c:	bl	0x101acb460 ; selector addSubview:
1004a6130:	mov	x0, x22
1004a6134:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6138:	ldr	x0, [sp, #0x8]
1004a613c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6140:	adrp	x8, 7854 ; 0x102354000
1004a6144:	ldr	x8, [x8, #0xdf0]
1004a6148:	ldr	x21, [x19, x8]
1004a614c:	str	x20, [x19, x8]
1004a6150:	mov	x0, x25
1004a6154:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6158:	mov	x0, x21
1004a615c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6160:	ldp	x29, x30, [sp, #0xd0]
1004a6164:	ldp	x20, x19, [sp, #0xc0]
1004a6168:	ldp	x22, x21, [sp, #0xb0]
1004a616c:	ldp	x24, x23, [sp, #0xa0]
1004a6170:	ldp	x26, x25, [sp, #0x90]
1004a6174:	ldp	x28, x27, [sp, #0x80]
1004a6178:	ldp	d9, d8, [sp, #0x70]
1004a617c:	ldp	d11, d10, [sp, #0x60]
1004a6180:	ldp	d13, d12, [sp, #0x50]
1004a6184:	ldp	d15, d14, [sp, #0x40]
1004a6188:	add	sp, sp, #0xe0
1004a618c:	ret
1004a6190:	sub	sp, sp, #0x20
1004a6194:	stp	x29, x30, [sp, #0x10]
1004a6198:	add	x29, sp, #0x10
1004a619c:	adrp	x8, 7854 ; 0x102354000
1004a61a0:	ldr	x8, [x8, #0xdf8]
1004a61a4:	ldr	x0, [x20, x8]
1004a61a8:	cbz	x0, 0x1004a61b4
1004a61ac:	mov	x2, #0x0
1004a61b0:	bl	0x101acfec0 ; selector orderOut:
1004a61b4:	bl	0x1004a7e0c
1004a61b8:	stp	x20, x0, [sp]
1004a61bc:	adrp	x8, 7803 ; 0x102321000
1004a61c0:	ldr	x1, [x8, #0x2d8] ; Objc selector ref: dealloc
1004a61c4:	mov	x0, sp
1004a61c8:	bl	0x101ac9d0c ; Objc message: -[[x0 super] dealloc]
1004a61cc:	ldp	x29, x30, [sp, #0x10]
1004a61d0:	add	sp, sp, #0x20
1004a61d4:	ret
1004a61d8:	sub	sp, sp, #0x30
1004a61dc:	stp	x20, x19, [sp, #0x10]
1004a61e0:	stp	x29, x30, [sp, #0x20]
1004a61e4:	add	x29, sp, #0x20
1004a61e8:	mov	x19, x0
1004a61ec:	adrp	x8, 7854 ; 0x102354000
1004a61f0:	ldr	x8, [x8, #0xdf8]
1004a61f4:	ldr	x20, [x0, x8]
1004a61f8:	cbz	x20, 0x1004a6214
1004a61fc:	mov	x0, x19
1004a6200:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a6204:	mov	x0, x20
1004a6208:	mov	x2, #0x0
1004a620c:	bl	0x101acfec0 ; selector orderOut:
1004a6210:	b	0x1004a621c
1004a6214:	mov	x0, x19
1004a6218:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a621c:	bl	0x1004a7e0c
1004a6220:	stp	x19, x0, [sp]
1004a6224:	adrp	x8, 7803 ; 0x102321000
1004a6228:	ldr	x1, [x8, #0x2d8] ; Objc selector ref: dealloc
1004a622c:	mov	x0, sp
1004a6230:	bl	0x101ac9d0c ; Objc message: -[[x0 super] dealloc]
1004a6234:	ldp	x29, x30, [sp, #0x20]
1004a6238:	ldp	x20, x19, [sp, #0x10]
1004a623c:	add	sp, sp, #0x30
1004a6240:	ret
1004a6244:	stp	x20, x19, [sp, #-0x20]!
1004a6248:	stp	x29, x30, [sp, #0x10]
1004a624c:	add	x29, sp, #0x10
1004a6250:	mov	x19, x0
1004a6254:	adrp	x8, 7854 ; 0x102354000
1004a6258:	ldr	x8, [x8, #0xde0]
1004a625c:	ldr	x0, [x0, x8]
1004a6260:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6264:	adrp	x8, 7854 ; 0x102354000
1004a6268:	ldr	x8, [x8, #0xde8]
1004a626c:	ldr	x0, [x19, x8]
1004a6270:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6274:	adrp	x8, 7854 ; 0x102354000
1004a6278:	ldr	x8, [x8, #0xdf0]
1004a627c:	ldr	x0, [x19, x8]
1004a6280:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6284:	adrp	x8, 7854 ; 0x102354000
1004a6288:	ldr	x8, [x8, #0xdd0]
1004a628c:	add	x8, x19, x8
1004a6290:	ldp	x0, x1, [x8]
1004a6294:	bl	0x100003840
1004a6298:	adrp	x8, 7854 ; 0x102354000
1004a629c:	ldr	x8, [x8, #0xe00]
1004a62a0:	ldr	x0, [x19, x8]
1004a62a4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a62a8:	adrp	x8, 7854 ; 0x102354000
1004a62ac:	ldr	x8, [x8, #0xe08]
1004a62b0:	ldr	x0, [x19, x8]
1004a62b4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a62b8:	adrp	x8, 7854 ; 0x102354000
1004a62bc:	ldr	x8, [x8, #0xdd8]
1004a62c0:	add	x0, x19, x8
1004a62c4:	bl	0x101acaabc ; symbol stub for: _swift_unknownObjectWeakDestroy
1004a62c8:	adrp	x8, 7854 ; 0x102354000
1004a62cc:	ldr	x8, [x8, #0xdf8]
1004a62d0:	ldr	x0, [x19, x8]
1004a62d4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a62d8:	adrp	x8, 7854 ; 0x102354000
1004a62dc:	ldr	x8, [x8, #0xe10]
1004a62e0:	ldr	x0, [x19, x8]
1004a62e4:	ldp	x29, x30, [sp, #0x10]
1004a62e8:	ldp	x20, x19, [sp], #0x20
1004a62ec:	b	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a62f0:	sub	sp, sp, #0x60
1004a62f4:	stp	d11, d10, [sp, #0x10]
1004a62f8:	stp	d9, d8, [sp, #0x20]
1004a62fc:	stp	x22, x21, [sp, #0x30]
1004a6300:	stp	x20, x19, [sp, #0x40]
1004a6304:	stp	x29, x30, [sp, #0x50]
1004a6308:	add	x29, sp, #0x50
1004a630c:	bl	0x1004a7e0c
1004a6310:	stp	x20, x0, [sp]
1004a6314:	adrp	x8, 7806 ; 0x102324000
1004a6318:	ldr	x1, [x8, #0xea8] ; Objc selector ref: updateTrackingAreas
1004a631c:	mov	x0, sp
1004a6320:	bl	0x101ac9d0c ; Objc message: -[[x0 super] updateTrackingAreas]
1004a6324:	adrp	x8, 7854 ; 0x102354000
1004a6328:	ldr	x21, [x8, #0xe00]
1004a632c:	ldr	x2, [x20, x21]
1004a6330:	cbz	x2, 0x1004a633c
1004a6334:	mov	x0, x20
1004a6338:	bl	0x101ad0c40 ; selector removeTrackingArea:
1004a633c:	mov	x0, x20
1004a6340:	bl	0x101acbde0 ; selector bounds
1004a6344:	mov.16b	v8, v0
1004a6348:	mov.16b	v9, v1
1004a634c:	mov.16b	v10, v2
1004a6350:	mov.16b	v11, v3
1004a6354:	adrp	x8, 7808 ; 0x102326000
1004a6358:	ldr	x0, [x8, #0xa48] ; Objc class ref: _OBJC_CLASS_$_NSTrackingArea
1004a635c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004a6360:	mov.16b	v0, v8
1004a6364:	mov.16b	v1, v9
1004a6368:	mov.16b	v2, v10
1004a636c:	mov.16b	v3, v11
1004a6370:	mov	x3, x20
1004a6374:	mov	w2, #0x81
1004a6378:	mov	x4, #0x0
1004a637c:	bl	0x101ace7c0 ; selector initWithRect:options:owner:userInfo:
1004a6380:	mov	x19, x0
1004a6384:	mov	x0, x20
1004a6388:	mov	x2, x19
1004a638c:	bl	0x101acb540 ; selector addTrackingArea:
1004a6390:	ldr	x0, [x20, x21]
1004a6394:	str	x19, [x20, x21]
1004a6398:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a639c:	ldp	x29, x30, [sp, #0x50]
1004a63a0:	ldp	x20, x19, [sp, #0x40]
1004a63a4:	ldp	x22, x21, [sp, #0x30]
1004a63a8:	ldp	d9, d8, [sp, #0x20]
1004a63ac:	ldp	d11, d10, [sp, #0x10]
1004a63b0:	add	sp, sp, #0x60
1004a63b4:	ret
1004a63b8:	stp	x20, x19, [sp, #-0x20]!
1004a63bc:	stp	x29, x30, [sp, #0x10]
1004a63c0:	add	x29, sp, #0x10
1004a63c4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a63c8:	mov	x20, x0
1004a63cc:	bl	0x1004a62f0
1004a63d0:	mov	x0, x20
1004a63d4:	ldp	x29, x30, [sp, #0x10]
1004a63d8:	ldp	x20, x19, [sp], #0x20
1004a63dc:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004a63e0:	b	0x1004a7e2c
1004a63e4:	stp	x22, x21, [sp, #-0x30]!
1004a63e8:	stp	x20, x19, [sp, #0x10]
1004a63ec:	stp	x29, x30, [sp, #0x20]
1004a63f0:	add	x29, sp, #0x20
1004a63f4:	mov	x19, x0
1004a63f8:	mov	x0, x2
1004a63fc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a6400:	mov	x21, x0
1004a6404:	mov	x0, x19
1004a6408:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a640c:	mov	x20, x0
1004a6410:	bl	0x1004a7e2c
1004a6414:	mov	x0, x21
1004a6418:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a641c:	mov	x0, x20
1004a6420:	ldp	x29, x30, [sp, #0x20]
1004a6424:	ldp	x20, x19, [sp, #0x10]
1004a6428:	ldp	x22, x21, [sp], #0x30
1004a642c:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004a6430:	b	0x1004a7e84
1004a6434:	stp	x22, x21, [sp, #-0x30]!
1004a6438:	stp	x20, x19, [sp, #0x10]
1004a643c:	stp	x29, x30, [sp, #0x20]
1004a6440:	add	x29, sp, #0x20
1004a6444:	mov	x19, x0
1004a6448:	mov	x0, x2
1004a644c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a6450:	mov	x21, x0
1004a6454:	mov	x0, x19
1004a6458:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a645c:	mov	x20, x0
1004a6460:	bl	0x1004a7e84
1004a6464:	mov	x0, x21
1004a6468:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a646c:	mov	x0, x20
1004a6470:	ldp	x29, x30, [sp, #0x20]
1004a6474:	ldp	x20, x19, [sp, #0x10]
1004a6478:	ldp	x22, x21, [sp], #0x30
1004a647c:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004a6480:	sub	sp, sp, #0x70
1004a6484:	stp	d15, d14, [sp, #0x10]
1004a6488:	stp	d13, d12, [sp, #0x20]
1004a648c:	stp	d11, d10, [sp, #0x30]
1004a6490:	stp	d9, d8, [sp, #0x40]
1004a6494:	stp	x20, x19, [sp, #0x50]
1004a6498:	stp	x29, x30, [sp, #0x60]
1004a649c:	add	x29, sp, #0x60
1004a64a0:	mov.16b	v8, v3
1004a64a4:	mov.16b	v9, v2
1004a64a8:	mov.16b	v10, v1
1004a64ac:	mov.16b	v11, v0
1004a64b0:	adrp	x8, 7854 ; 0x102354000
1004a64b4:	ldr	x8, [x8, #0xe18]
1004a64b8:	ldrb	w8, [x20, x8]
1004a64bc:	cmp	w8, #0x1
1004a64c0:	b.ne	0x1004a653c
1004a64c4:	bl	0x1004adb20
1004a64c8:	mov	x19, x0
1004a64cc:	bl	0x101ad29c0 ; selector setFill
1004a64d0:	mov	x0, x19
1004a64d4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a64d8:	mov	x0, x20
1004a64dc:	bl	0x101acbde0 ; selector bounds
1004a64e0:	fmov	d4, #4.00000000
1004a64e4:	fmov	d5, #1.00000000
1004a64e8:	bl	0x101ac8dc4 ; symbol stub for: _CGRectInset
1004a64ec:	mov.16b	v12, v0
1004a64f0:	mov.16b	v13, v1
1004a64f4:	mov.16b	v14, v2
1004a64f8:	mov.16b	v15, v3
1004a64fc:	adrp	x8, 7808 ; 0x102326000
1004a6500:	ldr	x0, [x8, #0xb38] ; Objc class ref: _OBJC_CLASS_$_NSBezierPath
1004a6504:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004a6508:	fmov	d4, #6.00000000
1004a650c:	fmov	d5, #6.00000000
1004a6510:	mov.16b	v0, v12
1004a6514:	mov.16b	v1, v13
1004a6518:	mov.16b	v2, v14
1004a651c:	mov.16b	v3, v15
1004a6520:	bl	0x101acbc40 ; selector bezierPathWithRoundedRect:xRadius:yRadius:
1004a6524:	mov	x29, x29
1004a6528:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a652c:	mov	x19, x0
1004a6530:	bl	0x101acda20 ; selector fill
1004a6534:	mov	x0, x19
1004a6538:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a653c:	bl	0x1004a7e0c
1004a6540:	stp	x20, x0, [sp]
1004a6544:	adrp	x8, 7803 ; 0x102321000
1004a6548:	ldr	x1, [x8, #0x3b8] ; Objc selector ref: drawRect:
1004a654c:	mov	x0, sp
1004a6550:	mov.16b	v0, v11
1004a6554:	mov.16b	v1, v10
1004a6558:	mov.16b	v2, v9
1004a655c:	mov.16b	v3, v8
1004a6560:	bl	0x101ac9d0c ; Objc message: -[[x0 super] drawRect:]
1004a6564:	ldp	x29, x30, [sp, #0x60]
1004a6568:	ldp	x20, x19, [sp, #0x50]
1004a656c:	ldp	d9, d8, [sp, #0x40]
1004a6570:	ldp	d11, d10, [sp, #0x30]
1004a6574:	ldp	d13, d12, [sp, #0x20]
1004a6578:	ldp	d15, d14, [sp, #0x10]
1004a657c:	add	sp, sp, #0x70
1004a6580:	ret
1004a6584:	stp	d11, d10, [sp, #-0x40]!
1004a6588:	stp	d9, d8, [sp, #0x10]
1004a658c:	stp	x20, x19, [sp, #0x20]
1004a6590:	stp	x29, x30, [sp, #0x30]
1004a6594:	add	x29, sp, #0x30
1004a6598:	mov.16b	v8, v3
1004a659c:	mov.16b	v9, v2
1004a65a0:	mov.16b	v10, v1
1004a65a4:	mov.16b	v11, v0
1004a65a8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a65ac:	mov	x20, x0
1004a65b0:	mov.16b	v0, v11
1004a65b4:	mov.16b	v1, v10
1004a65b8:	mov.16b	v2, v9
1004a65bc:	mov.16b	v3, v8
1004a65c0:	bl	0x1004a6480
1004a65c4:	mov	x0, x20
1004a65c8:	ldp	x29, x30, [sp, #0x30]
1004a65cc:	ldp	x20, x19, [sp, #0x20]
1004a65d0:	ldp	d9, d8, [sp, #0x10]
1004a65d4:	ldp	d11, d10, [sp], #0x40
1004a65d8:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004a65dc:	sub	sp, sp, #0x130
1004a65e0:	stp	d15, d14, [sp, #0x90]
1004a65e4:	stp	d13, d12, [sp, #0xa0]
1004a65e8:	stp	d11, d10, [sp, #0xb0]
1004a65ec:	stp	d9, d8, [sp, #0xc0]
1004a65f0:	stp	x28, x27, [sp, #0xd0]
1004a65f4:	stp	x26, x25, [sp, #0xe0]
1004a65f8:	stp	x24, x23, [sp, #0xf0]
1004a65fc:	stp	x22, x21, [sp, #0x100]
1004a6600:	stp	x20, x19, [sp, #0x110]
1004a6604:	stp	x29, x30, [sp, #0x120]
1004a6608:	add	x29, sp, #0x120
1004a660c:	adrp	x8, 7854 ; 0x102354000
1004a6610:	ldr	x8, [x8, #0xdd0]
1004a6614:	add	x8, x20, x8
1004a6618:	ldr	x21, [x8]
1004a661c:	cbz	x21, 0x1004a72bc
1004a6620:	mov	x22, x20
1004a6624:	ldr	x20, [x8, #0x8]
1004a6628:	mov	x0, x21
1004a662c:	mov	x1, x20
1004a6630:	bl	0x100003f5c
1004a6634:	blr	x21
1004a6638:	mov	x23, x0
1004a663c:	mov	x0, x21
1004a6640:	mov	x1, x20
1004a6644:	bl	0x100003840
1004a6648:	mov	x0, #0x0
1004a664c:	bl	0x1004ad03c
1004a6650:	mov	x20, x0
1004a6654:	bl	0x1004a9cc4
1004a6658:	mov	x20, x22
1004a665c:	bl	0x1004a72f8
1004a6660:	adrp	x8, 7854 ; 0x102354000
1004a6664:	ldr	x21, [x8, #0xe10]
1004a6668:	add	x0, x22, x21
1004a666c:	add	x1, sp, #0x70
1004a6670:	mov	w2, #0x1
1004a6674:	mov	x3, #0x0
1004a6678:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a667c:	ldr	x0, [x22, x21]
1004a6680:	adrp	x8, 7721 ; 0x1022cf000
1004a6684:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004a6688:	str	x8, [x22, x21]
1004a668c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6690:	adrp	x8, 7854 ; 0x102354000
1004a6694:	ldr	x8, [x8, #0xe20]
1004a6698:	mov	x9, #-0x1
1004a669c:	str	x9, [x22, x8]
1004a66a0:	adrp	x8, 7854 ; 0x102354000
1004a66a4:	ldr	x19, [x8, #0xdc8]
1004a66a8:	add	x0, x22, x19
1004a66ac:	add	x1, sp, #0x58
1004a66b0:	mov	w2, #0x1
1004a66b4:	mov	x3, #0x0
1004a66b8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a66bc:	strb	wzr, [x22, x19]
1004a66c0:	mov	x0, #0x0
1004a66c4:	bl	0x10006d00c
1004a66c8:	mov	x8, #0x400000000000
1004a66cc:	movk	x8, #0x4070, lsl #48
1004a66d0:	fmov	d2, x8
1004a66d4:	movi.2d	v0, #0000000000000000
1004a66d8:	movi.2d	v1, #0000000000000000
1004a66dc:	movi.2d	v3, #0000000000000000
1004a66e0:	mov	x20, x0
1004a66e4:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004a66e8:	str	x0, [sp, #0x30]
1004a66ec:	ldr	x10, [x23, #0x10]
1004a66f0:	str	x22, [sp, #0x20]
1004a66f4:	cbz	x10, 0x1004a6f30
1004a66f8:	str	x21, [sp, #0x8]
1004a66fc:	mov	x26, #0x0
1004a6700:	adrp	x8, 7716 ; 0x1022ca000
1004a6704:	ldr	x8, [x8, #0x610] ; literal pool symbol address: _NSFontWeightMedium
1004a6708:	adrp	x9, 7716 ; 0x1022ca000
1004a670c:	ldr	x9, [x9, #0x620] ; literal pool symbol address: _NSFontWeightSemibold
1004a6710:	ldr	d8, [x8]
1004a6714:	ldr	d9, [x9]
1004a6718:	mov	x8, #0x800000000000
1004a671c:	movk	x8, #0x406c, lsl #48
1004a6720:	fmov	d10, x8
1004a6724:	mov	x8, #0x400000000000
1004a6728:	movk	x8, #0x4070, lsl #48
1004a672c:	fmov	d11, x8
1004a6730:	fmov	d15, #2.00000000
1004a6734:	mov	x8, #0x800000000000
1004a6738:	movk	x8, #0x406d, lsl #48
1004a673c:	fmov	d13, x8
1004a6740:	fmov	d12, #4.00000000
1004a6744:	mov	x22, x23
1004a6748:	str	x23, [sp, #0x10]
1004a674c:	b	0x1004a679c
1004a6750:	ldr	x0, [sp, #0x30]
1004a6754:	mov	x2, x25
1004a6758:	bl	0x101acb460 ; selector addSubview:
1004a675c:	mov	x0, x19
1004a6760:	bl	0x101aca960 ; symbol stub for: _swift_release
1004a6764:	mov	x0, x20
1004a6768:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a676c:	mov	x0, x27
1004a6770:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6774:	mov	x0, x24
1004a6778:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a677c:	fmov	d14, #5.00000000
1004a6780:	mov	x0, x25
1004a6784:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6788:	fadd	d12, d12, d14
1004a678c:	add	x26, x26, #0x38
1004a6790:	ldr	x10, [sp, #0x38]
1004a6794:	subs	x10, x10, #0x1
1004a6798:	b.eq	0x1004a6f1c
1004a679c:	str	x10, [sp, #0x38]
1004a67a0:	add	x19, x22, x26
1004a67a4:	ldp	x28, x24, [x19, #0x20]
1004a67a8:	ldp	x20, x27, [x19, #0x30]
1004a67ac:	ldr	x25, [x19, #0x40]
1004a67b0:	adrp	x0, 7476 ; 0x1021da000
1004a67b4:	add	x0, x0, #0x610
1004a67b8:	mov	w1, #0x20
1004a67bc:	mov	w2, #0x7
1004a67c0:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004a67c4:	ldr	x21, [x19, #0x50]
1004a67c8:	ldur	q0, [x19, #0x48]
1004a67cc:	mov	x19, x0
1004a67d0:	str	q0, [x0, #0x10]
1004a67d4:	mov	w8, #0x2d2d
1004a67d8:	movk	w8, #0x2d, lsl #16
1004a67dc:	cmp	x28, x8
1004a67e0:	mov	x8, #-0x1d00000000000000
1004a67e4:	ccmp	x24, x8, #0x0, eq
1004a67e8:	b.eq	0x1004a680c
1004a67ec:	mov	x0, x28
1004a67f0:	mov	x1, x24
1004a67f4:	mov	w2, #0x2d2d
1004a67f8:	movk	w2, #0x2d, lsl #16
1004a67fc:	mov	x3, #-0x1d00000000000000
1004a6800:	mov	w4, #0x0
1004a6804:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004a6808:	tbz	w0, #0x0, 0x1004a68d0
1004a680c:	fadd	d14, d12, d15
1004a6810:	adrp	x8, 7808 ; 0x102326000
1004a6814:	ldr	x23, [x8, #0xa40] ; Objc class ref: _OBJC_CLASS_$_NSView
1004a6818:	mov	x0, x24
1004a681c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a6820:	mov	x0, x27
1004a6824:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a6828:	mov	x0, x25
1004a682c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a6830:	mov	x20, x0
1004a6834:	mov	x0, x21
1004a6838:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004a683c:	mov	x0, x23
1004a6840:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004a6844:	fmov	d0, #12.00000000
1004a6848:	fmov	d3, #1.00000000
1004a684c:	mov.16b	v1, v14
1004a6850:	mov.16b	v2, v13
1004a6854:	bl	0x101ace5a0 ; selector initWithFrame:
1004a6858:	mov	x25, x0
1004a685c:	mov	w2, #0x1
1004a6860:	bl	0x101ad4ca0 ; selector setWantsLayer:
1004a6864:	mov	x0, x25
1004a6868:	bl	0x101acf2c0 ; selector layer
1004a686c:	mov	x29, x29
1004a6870:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a6874:	cbz	x0, 0x1004a6750
1004a6878:	mov	x21, x0
1004a687c:	adrp	x8, 7808 ; 0x102326000
1004a6880:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004a6884:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004a6888:	bl	0x101ad1600 ; selector separatorColor
1004a688c:	mov	x29, x29
1004a6890:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a6894:	mov	x23, x0
1004a6898:	bl	0x101acad00 ; selector CGColor
1004a689c:	mov	x29, x29
1004a68a0:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a68a4:	mov	x28, x0
1004a68a8:	mov	x0, x23
1004a68ac:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a68b0:	mov	x0, x21
1004a68b4:	mov	x2, x28
1004a68b8:	bl	0x101ad1e00 ; selector setBackgroundColor:
1004a68bc:	mov	x0, x21
1004a68c0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a68c4:	mov	x0, x28
1004a68c8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a68cc:	b	0x1004a6750
1004a68d0:	mov	x0, x28
1004a68d4:	mov	x1, x24
1004a68d8:	bl	0x101ac6328 ; symbol stub for: _$sSS10uppercasedSSyF
1004a68dc:	mov	x23, x1
1004a68e0:	cmp	x28, x0
1004a68e4:	ccmp	x24, x1, #0x0, eq
1004a68e8:	str	x19, [sp, #0x28]
1004a68ec:	b.eq	0x1004a694c
1004a68f0:	mov	x2, x0
1004a68f4:	mov	x0, x28
1004a68f8:	mov	x1, x24
1004a68fc:	mov	x3, x23
1004a6900:	mov	w4, #0x0
1004a6904:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004a6908:	mov	x22, x0
1004a690c:	mov	x0, x25
1004a6910:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a6914:	mov	x0, x21
1004a6918:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004a691c:	mov	x0, x24
1004a6920:	mov	w1, #0x2
1004a6924:	bl	0x101aca630 ; symbol stub for: _swift_bridgeObjectRetain_n
1004a6928:	mov	x0, x27
1004a692c:	mov	w1, #0x2
1004a6930:	bl	0x101aca630 ; symbol stub for: _swift_bridgeObjectRetain_n
1004a6934:	mov	x0, x23
1004a6938:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a693c:	tbnz	w22, #0x0, 0x1004a697c
1004a6940:	cbnz	x27, 0x1004a6980
1004a6944:	str	wzr, [sp, #0x18]
1004a6948:	b	0x1004a69d0
1004a694c:	mov	x0, x25
1004a6950:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a6954:	mov	x0, x21
1004a6958:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004a695c:	mov	x0, x24
1004a6960:	mov	w1, #0x2
1004a6964:	bl	0x101aca630 ; symbol stub for: _swift_bridgeObjectRetain_n
1004a6968:	mov	x0, x27
1004a696c:	mov	w1, #0x2
1004a6970:	bl	0x101aca630 ; symbol stub for: _swift_bridgeObjectRetain_n
1004a6974:	mov	x0, x23
1004a6978:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a697c:	cbz	x27, 0x1004a6c74
1004a6980:	mov	w8, #0x9ce2
1004a6984:	movk	w8, #0x93, lsl #16
1004a6988:	cmp	x20, x8
1004a698c:	b.ne	0x1004a69a8
1004a6990:	mov	x8, #-0x5d00000000000000
1004a6994:	cmp	x27, x8
1004a6998:	b.ne	0x1004a69a8
1004a699c:	mov	w8, #0x1
1004a69a0:	str	w8, [sp, #0x18]
1004a69a4:	b	0x1004a69c8
1004a69a8:	mov	x0, x20
1004a69ac:	mov	x1, x27
1004a69b0:	mov	w2, #0x9ce2
1004a69b4:	movk	w2, #0x93, lsl #16
1004a69b8:	mov	x3, #-0x5d00000000000000
1004a69bc:	mov	w4, #0x0
1004a69c0:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004a69c4:	str	w0, [sp, #0x18]
1004a69c8:	mov	x0, x27
1004a69cc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a69d0:	mov	x0, #0x0
1004a69d4:	bl	0x1004aede4
1004a69d8:	movi.2d	v0, #0000000000000000
1004a69dc:	fmov	d3, #26.00000000
1004a69e0:	mov.16b	v1, v12
1004a69e4:	mov.16b	v2, v11
1004a69e8:	mov	x20, x0
1004a69ec:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004a69f0:	mov	x23, x0
1004a69f4:	ldr	x8, [x0]
1004a69f8:	adrp	x21, 7721 ; 0x1022cf000
1004a69fc:	ldr	x21, [x21, #0x718] ; literal pool symbol address: _swift_isaMask
1004a6a00:	ldr	x9, [x21]
1004a6a04:	and	x8, x9, x8
1004a6a08:	ldr	x8, [x8, #0x130]
1004a6a0c:	mov	w0, #0x1
1004a6a10:	mov	x20, x23
1004a6a14:	blr	x8
1004a6a18:	adrp	x0, 7476 ; 0x1021da000
1004a6a1c:	add	x0, x0, #0x638
1004a6a20:	mov	w1, #0x18
1004a6a24:	mov	w2, #0x7
1004a6a28:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004a6a2c:	mov	x22, x0
1004a6a30:	add	x0, x0, #0x10
1004a6a34:	ldr	x1, [sp, #0x20]
1004a6a38:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004a6a3c:	adrp	x0, 7476 ; 0x1021da000
1004a6a40:	add	x0, x0, #0x660
1004a6a44:	mov	w1, #0x28
1004a6a48:	mov	w2, #0x7
1004a6a4c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004a6a50:	mov	x19, x0
1004a6a54:	adrp	x8, -1187 ; 0x100003000
1004a6a58:	add	x8, x8, #0x8c4
1004a6a5c:	str	x8, [x0, #0x10]
1004a6a60:	ldr	x0, [sp, #0x28]
1004a6a64:	stp	x0, x22, [x19, #0x18]
1004a6a68:	mov	w1, #0x2
1004a6a6c:	bl	0x101aca984 ; symbol stub for: _swift_retain_n
1004a6a70:	mov	x0, x22
1004a6a74:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004a6a78:	bl	_$s9TextStory09BufferingA7StorageC16bufferingEnabledSbvpfi
1004a6a7c:	ldr	x8, [x23]
1004a6a80:	ldr	x9, [x21]
1004a6a84:	and	x8, x9, x8
1004a6a88:	ldr	x8, [x8, #0x140]
1004a6a8c:	str	x19, [sp]
1004a6a90:	and	w4, w0, #0x1
1004a6a94:	mov	x0, x28
1004a6a98:	mov	x1, x24
1004a6a9c:	mov	x2, #0x0
1004a6aa0:	mov	x3, #0x0
1004a6aa4:	mov	x5, #0x4040000000000000
1004a6aa8:	mov	w6, #0x0
1004a6aac:	adrp	x7, 2 ; 0x1004a8000
1004a6ab0:	add	x7, x7, #0xa8
1004a6ab4:	blr	x8
1004a6ab8:	mov	x0, x22
1004a6abc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004a6ac0:	mov	x0, x19
1004a6ac4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004a6ac8:	mov	x0, x24
1004a6acc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6ad0:	ldr	w8, [sp, #0x18]
1004a6ad4:	tbz	w8, #0x0, 0x1004a6bdc
1004a6ad8:	mov	w0, #0x9ce2
1004a6adc:	movk	w0, #0x93, lsl #16
1004a6ae0:	mov	x1, #-0x5d00000000000000
1004a6ae4:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004a6ae8:	mov	x19, x0
1004a6aec:	adrp	x8, 7808 ; 0x102326000
1004a6af0:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004a6af4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004a6af8:	mov	x2, x19
1004a6afc:	bl	0x101acf240 ; selector labelWithString:
1004a6b00:	mov	x29, x29
1004a6b04:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a6b08:	mov	x20, x0
1004a6b0c:	mov	x0, x19
1004a6b10:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6b14:	mov	x0, x20
1004a6b18:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a6b1c:	mov	x19, x0
1004a6b20:	fmov	d0, #13.00000000
1004a6b24:	mov.16b	v1, v8
1004a6b28:	bl	0x100004700
1004a6b2c:	mov	x20, x0
1004a6b30:	mov	x0, x19
1004a6b34:	mov	x2, x20
1004a6b38:	bl	0x101ad2aa0 ; selector setFont:
1004a6b3c:	mov	x0, x19
1004a6b40:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6b44:	mov	x0, x20
1004a6b48:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6b4c:	adrp	x8, 7808 ; 0x102326000
1004a6b50:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004a6b54:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004a6b58:	bl	0x101acf220 ; selector labelColor
1004a6b5c:	mov	x29, x29
1004a6b60:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a6b64:	mov	x20, x0
1004a6b68:	mov	x0, x19
1004a6b6c:	mov	x2, x20
1004a6b70:	bl	0x101ad4660 ; selector setTextColor:
1004a6b74:	mov	x0, x20
1004a6b78:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6b7c:	mov	x0, x19
1004a6b80:	bl	0x101ad4fe0 ; selector sizeToFit
1004a6b84:	mov	x0, x19
1004a6b88:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a6b8c:	mov	x19, x0
1004a6b90:	bl	0x101acdcc0 ; selector frame
1004a6b94:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004a6b98:	fmov	d1, #26.00000000
1004a6b9c:	fsub	d0, d1, d0
1004a6ba0:	fmov	d1, #0.50000000
1004a6ba4:	fmul	d14, d0, d1
1004a6ba8:	mov	x0, x19
1004a6bac:	bl	0x101acdcc0 ; selector frame
1004a6bb0:	fmov	d0, #16.00000000
1004a6bb4:	mov	x0, x19
1004a6bb8:	mov.16b	v1, v14
1004a6bbc:	bl	0x101ad2b80 ; selector setFrame:
1004a6bc0:	mov	x0, x19
1004a6bc4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6bc8:	mov	x0, x23
1004a6bcc:	mov	x2, x19
1004a6bd0:	bl	0x101acb460 ; selector addSubview:
1004a6bd4:	mov	x0, x19
1004a6bd8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6bdc:	ldr	x0, [sp, #0x30]
1004a6be0:	mov	x2, x23
1004a6be4:	bl	0x101acb460 ; selector addSubview:
1004a6be8:	ldr	x22, [sp, #0x20]
1004a6bec:	ldr	x28, [sp, #0x8]
1004a6bf0:	add	x0, x22, x28
1004a6bf4:	add	x1, sp, #0x40
1004a6bf8:	mov	w2, #0x21
1004a6bfc:	mov	x3, #0x0
1004a6c00:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a6c04:	add	x20, x22, x28
1004a6c08:	bl	0x101ac6748 ; symbol stub for: _$sSa034_makeUniqueAndReserveCapacityIfNotB0yyFyXl_Ts5
1004a6c0c:	ldr	x8, [x22, x28]
1004a6c10:	and	x8, x8, #0xffffffffffffff8
1004a6c14:	ldp	x21, x8, [x8, #0x10]
1004a6c18:	cmp	x21, x8, lsr #1
1004a6c1c:	b.hs	0x1004a6f00
1004a6c20:	mov	x0, x23
1004a6c24:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a6c28:	mov	x19, x0
1004a6c2c:	add	x20, x22, x28
1004a6c30:	mov	x0, x21
1004a6c34:	mov	x1, x19
1004a6c38:	bl	0x101ac67c0 ; symbol stub for: _$sSa37_appendElementAssumeUniqueAndCapacity_03newB0ySi_xntFyXl_Ts5
1004a6c3c:	add	x0, sp, #0x40
1004a6c40:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004a6c44:	mov	x0, x24
1004a6c48:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6c4c:	mov	x0, x19
1004a6c50:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6c54:	ldr	x0, [sp, #0x28]
1004a6c58:	mov	w1, #0x2
1004a6c5c:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004a6c60:	mov	x0, x27
1004a6c64:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6c68:	fmov	d14, #26.00000000
1004a6c6c:	ldr	x22, [sp, #0x10]
1004a6c70:	b	0x1004a6780
1004a6c74:	mov	x0, #0x94e2
1004a6c78:	movk	x0, #0xe280, lsl #16
1004a6c7c:	movk	x0, #0x8094, lsl #32
1004a6c80:	movk	x0, #0x20, lsl #48
1004a6c84:	mov	x1, #-0x5900000000000000
1004a6c88:	mov	x2, x28
1004a6c8c:	mov	x3, x24
1004a6c90:	bl	0x101ac658c ; symbol stub for: _$sSS9hasPrefixySbSSF
1004a6c94:	tbz	w0, #0x0, 0x1004a6da4
1004a6c98:	mov	x0, #0xe220
1004a6c9c:	movk	x0, #0x8094, lsl #16
1004a6ca0:	movk	x0, #0x94e2, lsl #32
1004a6ca4:	movk	x0, #0x80, lsl #48
1004a6ca8:	mov	x1, #-0x5900000000000000
1004a6cac:	mov	x2, x28
1004a6cb0:	mov	x3, x24
1004a6cb4:	bl	0x101ac6598 ; symbol stub for: _$sSS9hasSuffixySbSSF
1004a6cb8:	mov	x20, x0
1004a6cbc:	mov	x0, x24
1004a6cc0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6cc4:	tbz	w20, #0x0, 0x1004a6dac
1004a6cc8:	stp	x28, x24, [sp, #0x40]
1004a6ccc:	ubfx	x8, x24, #56, #4
1004a6cd0:	tst	x24, #0x2000000000000000
1004a6cd4:	csel	x8, x28, x8, eq
1004a6cd8:	tst	x24, #0x1000000000000000
1004a6cdc:	ubfx	x9, x28, #59, #1
1004a6ce0:	csinc	w9, w9, wzr, ne
1004a6ce4:	cmp	w9, #0x0
1004a6ce8:	mov	w21, #0x7
1004a6cec:	mov	w22, #0xb
1004a6cf0:	csel	x9, x21, x22, ne
1004a6cf4:	orr	x20, x9, x8, lsl #16
1004a6cf8:	mov	x0, x24
1004a6cfc:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a6d00:	mov	w0, #0xf
1004a6d04:	mov	w1, #0x3
1004a6d08:	mov	x2, x20
1004a6d0c:	mov	x3, x28
1004a6d10:	mov	x4, x24
1004a6d14:	bl	0x101ac6454 ; symbol stub for: _$sSS5index_8offsetBy07limitedC0SS5IndexVSgAE_SiAEtF
1004a6d18:	and	w8, w1, #0xff
1004a6d1c:	cmp	w8, #0x1
1004a6d20:	b.eq	0x1004a72f4
1004a6d24:	mov	x2, x0
1004a6d28:	add	x20, sp, #0x40
1004a6d2c:	mov	w0, #0xf
1004a6d30:	mov	x1, x2
1004a6d34:	bl	0x101ac634c ; symbol stub for: _$sSS14removeSubrangeyySnySS5IndexVGF
1004a6d38:	ldp	x3, x4, [sp, #0x40]
1004a6d3c:	and	x8, x3, #0xffffffffffff
1004a6d40:	ubfx	x9, x4, #56, #4
1004a6d44:	tst	x4, #0x2000000000000000
1004a6d48:	csel	x19, x8, x9, eq
1004a6d4c:	tst	x4, #0x1000000000000000
1004a6d50:	ubfx	x8, x3, #59, #1
1004a6d54:	csinc	w8, w8, wzr, ne
1004a6d58:	cmp	w8, #0x0
1004a6d5c:	csel	x8, x21, x22, ne
1004a6d60:	orr	x21, x8, x19, lsl #16
1004a6d64:	mov	x0, x21
1004a6d68:	mov	x1, #-0x3
1004a6d6c:	mov	w2, #0xf
1004a6d70:	bl	0x101ac6454 ; symbol stub for: _$sSS5index_8offsetBy07limitedC0SS5IndexVSgAE_SiAEtF
1004a6d74:	and	w8, w1, #0xff
1004a6d78:	cmp	w8, #0x1
1004a6d7c:	b.eq	0x1004a72f0
1004a6d80:	lsl	x8, x19, #2
1004a6d84:	cmp	x8, x0, lsr #14
1004a6d88:	b.lo	0x1004a72ec
1004a6d8c:	add	x20, sp, #0x40
1004a6d90:	mov	x1, x21
1004a6d94:	bl	0x101ac634c ; symbol stub for: _$sSS14removeSubrangeyySnySS5IndexVGF
1004a6d98:	ldp	x28, x20, [sp, #0x40]
1004a6d9c:	mov	w19, #0x1
1004a6da0:	b	0x1004a6dbc
1004a6da4:	mov	x0, x24
1004a6da8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6dac:	mov	x0, x24
1004a6db0:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a6db4:	mov	w19, #0x0
1004a6db8:	mov	x20, x24
1004a6dbc:	mov	x0, x20
1004a6dc0:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a6dc4:	mov	x0, x28
1004a6dc8:	mov	x1, x20
1004a6dcc:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004a6dd0:	mov	x21, x0
1004a6dd4:	mov	x0, x20
1004a6dd8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6ddc:	adrp	x8, 7808 ; 0x102326000
1004a6de0:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004a6de4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004a6de8:	mov	x2, x21
1004a6dec:	bl	0x101acf240 ; selector labelWithString:
1004a6df0:	mov	x29, x29
1004a6df4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a6df8:	mov	x22, x0
1004a6dfc:	mov	x0, x21
1004a6e00:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6e04:	mov	x0, x22
1004a6e08:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a6e0c:	mov	x23, x0
1004a6e10:	cbz	w19, 0x1004a6e20
1004a6e14:	fmov	d0, #12.00000000
1004a6e18:	mov.16b	v1, v9
1004a6e1c:	b	0x1004a6e28
1004a6e20:	fmov	d0, #11.00000000
1004a6e24:	mov.16b	v1, v8
1004a6e28:	bl	0x100004700
1004a6e2c:	mov	x21, x0
1004a6e30:	ldr	x22, [sp, #0x10]
1004a6e34:	mov	x0, x23
1004a6e38:	mov	x2, x21
1004a6e3c:	bl	0x101ad2aa0 ; selector setFont:
1004a6e40:	mov	x0, x23
1004a6e44:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6e48:	mov	x0, x21
1004a6e4c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6e50:	adrp	x8, 7808 ; 0x102326000
1004a6e54:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004a6e58:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004a6e5c:	cbz	w19, 0x1004a6e68
1004a6e60:	bl	0x101ad12e0 ; selector secondaryLabelColor
1004a6e64:	b	0x1004a6e6c
1004a6e68:	bl	0x101ad58a0 ; selector tertiaryLabelColor
1004a6e6c:	mov	x29, x29
1004a6e70:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a6e74:	mov	x21, x0
1004a6e78:	mov	x0, x23
1004a6e7c:	mov	x2, x21
1004a6e80:	bl	0x101ad4660 ; selector setTextColor:
1004a6e84:	mov	x0, x21
1004a6e88:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6e8c:	fmov	d0, #4.00000000
1004a6e90:	fadd	d1, d12, d0
1004a6e94:	fmov	d0, #16.00000000
1004a6e98:	fmov	d3, #14.00000000
1004a6e9c:	mov	x0, x23
1004a6ea0:	mov.16b	v2, v10
1004a6ea4:	bl	0x101ad2b80 ; selector setFrame:
1004a6ea8:	mov	x0, x23
1004a6eac:	mov	w2, #0x0
1004a6eb0:	bl	0x101ad28e0 ; selector setEditable:
1004a6eb4:	mov	x0, x23
1004a6eb8:	mov	w2, #0x0
1004a6ebc:	bl	0x101ad1fa0 ; selector setBordered:
1004a6ec0:	mov	x0, x23
1004a6ec4:	mov	w2, #0x0
1004a6ec8:	bl	0x101ad2860 ; selector setDrawsBackground:
1004a6ecc:	ldr	x0, [sp, #0x30]
1004a6ed0:	mov	x2, x23
1004a6ed4:	bl	0x101acb460 ; selector addSubview:
1004a6ed8:	ldr	x0, [sp, #0x28]
1004a6edc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004a6ee0:	mov	x0, x24
1004a6ee4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6ee8:	mov	x0, x23
1004a6eec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6ef0:	mov	x0, x20
1004a6ef4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6ef8:	fmov	d14, #22.00000000
1004a6efc:	b	0x1004a6780
1004a6f00:	cmp	x8, #0x1
1004a6f04:	cset	w0, hi
1004a6f08:	add	x1, x21, #0x1
1004a6f0c:	add	x20, x22, x28
1004a6f10:	mov	w2, #0x1
1004a6f14:	bl	0x101ac6790 ; symbol stub for: _$sSa16_createNewBuffer14bufferIsUnique15minimumCapacity13growForAppendySb_SiSbtFyXl_Ts5
1004a6f18:	b	0x1004a6c20
1004a6f1c:	mov	x0, x22
1004a6f20:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6f24:	fmov	d0, #4.00000000
1004a6f28:	fadd	d8, d12, d0
1004a6f2c:	b	0x1004a6f3c
1004a6f30:	mov	x0, x23
1004a6f34:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a6f38:	fmov	d8, #8.00000000
1004a6f3c:	ldr	x0, [sp, #0x30]
1004a6f40:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a6f44:	mov	x20, x0
1004a6f48:	bl	0x101acdcc0 ; selector frame
1004a6f4c:	mov	x0, x20
1004a6f50:	mov.16b	v3, v8
1004a6f54:	bl	0x101ad2b80 ; selector setFrame:
1004a6f58:	adrp	x8, 7808 ; 0x102326000
1004a6f5c:	ldr	x0, [x8, #0xa28] ; Objc class ref: _OBJC_CLASS_$_NSPanel
1004a6f60:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004a6f64:	mov	x8, #0x400000000000
1004a6f68:	movk	x8, #0x4070, lsl #48
1004a6f6c:	fmov	d9, x8
1004a6f70:	movi.2d	v0, #0000000000000000
1004a6f74:	movi.2d	v1, #0000000000000000
1004a6f78:	mov.16b	v2, v9
1004a6f7c:	mov.16b	v3, v8
1004a6f80:	mov	w2, #0x80
1004a6f84:	mov	w3, #0x2
1004a6f88:	mov	w4, #0x0
1004a6f8c:	bl	0x101ace420 ; selector initWithContentRect:styleMask:backing:defer:
1004a6f90:	mov	x19, x0
1004a6f94:	mov	w22, #0x1
1004a6f98:	mov	w2, #0x1
1004a6f9c:	bl	0x101ad2a60 ; selector setFloatingPanel:
1004a6fa0:	mov	x0, x19
1004a6fa4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a6fa8:	mov	x21, x0
1004a6fac:	mov	w2, #0x65
1004a6fb0:	bl	0x101ad3320 ; selector setLevel:
1004a6fb4:	mov	x0, x21
1004a6fb8:	mov	w2, #0x0
1004a6fbc:	bl	0x101ad3980 ; selector setOpaque:
1004a6fc0:	adrp	x8, 7808 ; 0x102326000
1004a6fc4:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004a6fc8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004a6fcc:	bl	0x101acc200 ; selector clearColor
1004a6fd0:	mov	x29, x29
1004a6fd4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a6fd8:	mov	x19, x0
1004a6fdc:	mov	x0, x21
1004a6fe0:	mov	x2, x19
1004a6fe4:	bl	0x101ad1e00 ; selector setBackgroundColor:
1004a6fe8:	mov	x0, x19
1004a6fec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a6ff0:	bl	_$s9TextStory09BufferingA7StorageC16bufferingEnabledSbvpfi
1004a6ff4:	bic	w2, w22, w0
1004a6ff8:	mov	x0, x21
1004a6ffc:	bl	0x101ad2d20 ; selector setHasShadow:
1004a7000:	fmov	d2, #8.00000000
1004a7004:	mov.16b	v0, v9
1004a7008:	mov.16b	v1, v8
1004a700c:	bl	0x1004ad2c4
1004a7010:	mov	x23, x0
1004a7014:	mov	x22, x1
1004a7018:	mov	x0, x1
1004a701c:	mov	x2, x20
1004a7020:	bl	0x101acb460 ; selector addSubview:
1004a7024:	movi.2d	v0, #0000000000000000
1004a7028:	movi.2d	v1, #0000000000000000
1004a702c:	mov	x0, x20
1004a7030:	mov.16b	v2, v9
1004a7034:	mov.16b	v3, v8
1004a7038:	bl	0x101ad2b80 ; selector setFrame:
1004a703c:	mov	x0, x20
1004a7040:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a7044:	mov	x0, x21
1004a7048:	mov	x2, x23
1004a704c:	bl	0x101ad2340 ; selector setContentView:
1004a7050:	mov	x0, x21
1004a7054:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a7058:	ldr	x0, [sp, #0x20]
1004a705c:	bl	0x101ad6200 ; selector window
1004a7060:	mov	x29, x29
1004a7064:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a7068:	cbz	x0, 0x1004a7230
1004a706c:	mov	x24, x0
1004a7070:	bl	0x101ad1140 ; selector screen
1004a7074:	mov	x29, x29
1004a7078:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a707c:	cbnz	x0, 0x1004a709c
1004a7080:	adrp	x8, 7807 ; 0x102326000
1004a7084:	ldr	x0, [x8, #0xa18] ; Objc class ref: _OBJC_CLASS_$_NSScreen
1004a7088:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004a708c:	bl	0x101acf6a0 ; selector mainScreen
1004a7090:	mov	x29, x29
1004a7094:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a7098:	cbz	x0, 0x1004a7228
1004a709c:	mov	x25, x0
1004a70a0:	str	d8, [sp, #0x30]
1004a70a4:	ldr	x19, [sp, #0x20]
1004a70a8:	mov	x0, x19
1004a70ac:	bl	0x101acbde0 ; selector bounds
1004a70b0:	mov	x0, x19
1004a70b4:	mov	x2, #0x0
1004a70b8:	bl	0x101acc9c0 ; selector convertRect:toView:
1004a70bc:	mov	x0, x24
1004a70c0:	bl	0x101acca00 ; selector convertRectToScreen:
1004a70c4:	mov.16b	v14, v0
1004a70c8:	mov.16b	v15, v1
1004a70cc:	mov.16b	v13, v2
1004a70d0:	mov.16b	v8, v3
1004a70d4:	mov	x0, x25
1004a70d8:	bl	0x101ad6080 ; selector visibleFrame
1004a70dc:	mov.16b	v10, v0
1004a70e0:	str	d1, [sp, #0x18]
1004a70e4:	mov.16b	v11, v2
1004a70e8:	mov.16b	v12, v3
1004a70ec:	mov.16b	v0, v14
1004a70f0:	mov.16b	v1, v15
1004a70f4:	mov.16b	v2, v13
1004a70f8:	mov.16b	v3, v8
1004a70fc:	bl	0x101ac8d70 ; symbol stub for: _CGRectGetMaxX
1004a7100:	fmov	d1, #2.00000000
1004a7104:	fadd	d1, d0, d1
1004a7108:	mov	x8, #0x400000000000
1004a710c:	movk	x8, #0x4070, lsl #48
1004a7110:	fmov	d0, x8
1004a7114:	str	d1, [sp, #0x38]
1004a7118:	fadd	d9, d1, d0
1004a711c:	str	d10, [sp, #0x28]
1004a7120:	mov.16b	v0, v10
1004a7124:	ldr	d10, [sp, #0x18]
1004a7128:	mov.16b	v1, v10
1004a712c:	mov.16b	v2, v11
1004a7130:	mov.16b	v3, v12
1004a7134:	bl	0x101ac8d70 ; symbol stub for: _CGRectGetMaxX
1004a7138:	fcmp	d0, d9
1004a713c:	b.pl	0x1004a7170
1004a7140:	mov.16b	v0, v14
1004a7144:	mov.16b	v1, v15
1004a7148:	mov.16b	v2, v13
1004a714c:	mov.16b	v3, v8
1004a7150:	bl	0x101ac8da0 ; symbol stub for: _CGRectGetMinX
1004a7154:	mov	x8, #0x400000000000
1004a7158:	movk	x8, #0xc070, lsl #48
1004a715c:	fmov	d1, x8
1004a7160:	fadd	d0, d0, d1
1004a7164:	fmov	d1, #-2.00000000
1004a7168:	fadd	d0, d0, d1
1004a716c:	str	d0, [sp, #0x38]
1004a7170:	mov.16b	v0, v14
1004a7174:	mov.16b	v1, v15
1004a7178:	mov.16b	v2, v13
1004a717c:	mov.16b	v3, v8
1004a7180:	bl	0x101ac8d7c ; symbol stub for: _CGRectGetMaxY
1004a7184:	ldp	d14, d13, [sp, #0x28]
1004a7188:	fsub	d8, d0, d13
1004a718c:	mov.16b	v0, v14
1004a7190:	mov.16b	v1, v10
1004a7194:	mov.16b	v2, v11
1004a7198:	mov.16b	v3, v12
1004a719c:	bl	0x101ac8dac ; symbol stub for: _CGRectGetMinY
1004a71a0:	fcmp	d8, d0
1004a71a4:	b.pl	0x1004a71c0
1004a71a8:	mov.16b	v0, v14
1004a71ac:	mov.16b	v1, v10
1004a71b0:	mov.16b	v2, v11
1004a71b4:	mov.16b	v3, v12
1004a71b8:	bl	0x101ac8dac ; symbol stub for: _CGRectGetMinY
1004a71bc:	mov.16b	v8, v0
1004a71c0:	fadd	d9, d13, d8
1004a71c4:	mov.16b	v0, v14
1004a71c8:	mov.16b	v1, v10
1004a71cc:	mov.16b	v2, v11
1004a71d0:	mov.16b	v3, v12
1004a71d4:	bl	0x101ac8d7c ; symbol stub for: _CGRectGetMaxY
1004a71d8:	fcmp	d0, d9
1004a71dc:	b.pl	0x1004a71f8
1004a71e0:	mov.16b	v0, v14
1004a71e4:	mov.16b	v1, v10
1004a71e8:	mov.16b	v2, v11
1004a71ec:	mov.16b	v3, v12
1004a71f0:	bl	0x101ac8d7c ; symbol stub for: _CGRectGetMaxY
1004a71f4:	fsub	d8, d0, d13
1004a71f8:	mov	x8, #0x400000000000
1004a71fc:	movk	x8, #0x4070, lsl #48
1004a7200:	fmov	d2, x8
1004a7204:	ldr	d0, [sp, #0x38]
1004a7208:	mov.16b	v1, v8
1004a720c:	mov.16b	v3, v13
1004a7210:	bl	0x1004ad2a8
1004a7214:	mov	x0, x21
1004a7218:	mov	w2, #0x1
1004a721c:	bl	0x101ad2ba0 ; selector setFrame:display:
1004a7220:	mov	x0, x25
1004a7224:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a7228:	mov	x0, x24
1004a722c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a7230:	mov	x0, x21
1004a7234:	mov	x2, #0x0
1004a7238:	bl	0x101acfe40 ; selector orderFront:
1004a723c:	adrp	x8, 7853 ; 0x102354000
1004a7240:	ldr	x8, [x8, #0xdf8]
1004a7244:	ldr	x9, [sp, #0x20]
1004a7248:	ldr	x19, [x9, x8]
1004a724c:	str	x21, [x9, x8]
1004a7250:	mov	x0, x21
1004a7254:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a7258:	mov	x21, x0
1004a725c:	mov	x0, x19
1004a7260:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a7264:	mov	x0, x21
1004a7268:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a726c:	mov	x19, x0
1004a7270:	bl	0x1004a9980
1004a7274:	mov	x21, x0
1004a7278:	add	x1, sp, #0x40
1004a727c:	mov	w2, #0x1
1004a7280:	mov	x3, #0x0
1004a7284:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a7288:	mov	x0, x21
1004a728c:	mov	x1, x19
1004a7290:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004a7294:	mov	x0, x23
1004a7298:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a729c:	mov	x0, x22
1004a72a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a72a4:	mov	x0, x20
1004a72a8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a72ac:	mov	x0, x19
1004a72b0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a72b4:	mov	x0, x19
1004a72b8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a72bc:	ldp	x29, x30, [sp, #0x120]
1004a72c0:	ldp	x20, x19, [sp, #0x110]
1004a72c4:	ldp	x22, x21, [sp, #0x100]
1004a72c8:	ldp	x24, x23, [sp, #0xf0]
1004a72cc:	ldp	x26, x25, [sp, #0xe0]
1004a72d0:	ldp	x28, x27, [sp, #0xd0]
1004a72d4:	ldp	d9, d8, [sp, #0xc0]
1004a72d8:	ldp	d11, d10, [sp, #0xb0]
1004a72dc:	ldp	d13, d12, [sp, #0xa0]
1004a72e0:	ldp	d15, d14, [sp, #0x90]
1004a72e4:	add	sp, sp, #0x130
1004a72e8:	ret
1004a72ec:	brk	#0x1
1004a72f0:	brk	#0x1
1004a72f4:	brk	#0x1
1004a72f8:	sub	sp, sp, #0x70
1004a72fc:	stp	x24, x23, [sp, #0x30]
1004a7300:	stp	x22, x21, [sp, #0x40]
1004a7304:	stp	x20, x19, [sp, #0x50]
1004a7308:	stp	x29, x30, [sp, #0x60]
1004a730c:	add	x29, sp, #0x60
1004a7310:	adrp	x8, 7853 ; 0x102354000
1004a7314:	ldr	x23, [x8, #0xdf8]
1004a7318:	ldr	x0, [x20, x23]
1004a731c:	cbz	x0, 0x1004a7328
1004a7320:	mov	x2, #0x0
1004a7324:	bl	0x101acfec0 ; selector orderOut:
1004a7328:	bl	0x1004a9980
1004a732c:	mov	x19, x0
1004a7330:	add	x1, sp, #0x18
1004a7334:	mov	x2, #0x0
1004a7338:	mov	x3, #0x0
1004a733c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a7340:	mov	x0, x19
1004a7344:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004a7348:	ldr	x21, [x20, x23]
1004a734c:	cbz	x0, 0x1004a7368
1004a7350:	cbz	x21, 0x1004a7398
1004a7354:	mov	x22, x0
1004a7358:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a735c:	cmp	x22, x21
1004a7360:	b.ne	0x1004a73ac
1004a7364:	b	0x1004a7374
1004a7368:	cbnz	x21, 0x1004a73ac
1004a736c:	mov	x0, x21
1004a7370:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a7374:	mov	x1, sp
1004a7378:	mov	x0, x19
1004a737c:	mov	w2, #0x1
1004a7380:	mov	x3, #0x0
1004a7384:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a7388:	mov	x0, x19
1004a738c:	mov	x1, #0x0
1004a7390:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004a7394:	b	0x1004a73ac
1004a7398:	mov	x19, x0
1004a739c:	mov	x0, x21
1004a73a0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a73a4:	mov	x0, x19
1004a73a8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a73ac:	ldr	x0, [x20, x23]
1004a73b0:	str	xzr, [x20, x23]
1004a73b4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a73b8:	ldp	x29, x30, [sp, #0x60]
1004a73bc:	ldp	x20, x19, [sp, #0x50]
1004a73c0:	ldp	x22, x21, [sp, #0x40]
1004a73c4:	ldp	x24, x23, [sp, #0x30]
1004a73c8:	add	sp, sp, #0x70
1004a73cc:	ret
1004a73d0:	sub	sp, sp, #0x40
1004a73d4:	stp	x20, x19, [sp, #0x20]
1004a73d8:	stp	x29, x30, [sp, #0x30]
1004a73dc:	add	x29, sp, #0x30
1004a73e0:	mov	x19, x0
1004a73e4:	bl	0x1004a594c
1004a73e8:	mov	x0, x20
1004a73ec:	bl	0x101acbde0 ; selector bounds
1004a73f0:	mov	x0, x20
1004a73f4:	bl	0x101ad3820 ; selector setNeedsDisplayInRect:
1004a73f8:	tbz	w19, #0x0, 0x1004a740c
1004a73fc:	ldp	x29, x30, [sp, #0x30]
1004a7400:	ldp	x20, x19, [sp, #0x20]
1004a7404:	add	sp, sp, #0x40
1004a7408:	b	0x1004a65dc
1004a740c:	adrp	x8, 7853 ; 0x102354000
1004a7410:	ldr	x19, [x8, #0xdc8]
1004a7414:	add	x0, x20, x19
1004a7418:	add	x1, sp, #0x8
1004a741c:	mov	w2, #0x1
1004a7420:	mov	x3, #0x0
1004a7424:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a7428:	strb	wzr, [x20, x19]
1004a742c:	bl	0x1004a72f8
1004a7430:	ldp	x29, x30, [sp, #0x30]
1004a7434:	ldp	x20, x19, [sp, #0x20]
1004a7438:	add	sp, sp, #0x40
1004a743c:	ret
1004a7440:	stp	x29, x30, [sp, #-0x10]!
1004a7444:	mov	x29, sp
1004a7448:	bl	0x1004a65dc
1004a744c:	ldr	x8, [x20]
1004a7450:	adrp	x9, 7720 ; 0x1022cf000
1004a7454:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004a7458:	ldr	x9, [x9]
1004a745c:	and	x8, x9, x8
1004a7460:	ldr	x0, [x8, #0x210]
1004a7464:	ldp	x29, x30, [sp], #0x10
1004a7468:	br	x0
1004a746c:	sub	sp, sp, #0x50
1004a7470:	stp	x22, x21, [sp, #0x20]
1004a7474:	stp	x20, x19, [sp, #0x30]
1004a7478:	stp	x29, x30, [sp, #0x40]
1004a747c:	add	x29, sp, #0x40
1004a7480:	adrp	x8, 7853 ; 0x102354000
1004a7484:	ldr	x19, [x8, #0xdc8]
1004a7488:	mov	w21, #0x1
1004a748c:	add	x0, x20, x19
1004a7490:	add	x1, sp, #0x8
1004a7494:	mov	w2, #0x1
1004a7498:	mov	x3, #0x0
1004a749c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a74a0:	strb	w21, [x20, x19]
1004a74a4:	adrp	x8, 7853 ; 0x102354000
1004a74a8:	ldr	x8, [x8, #0xe20]
1004a74ac:	mov	x9, #-0x1
1004a74b0:	str	x9, [x20, x8]
1004a74b4:	mov	w0, #0x1
1004a74b8:	bl	0x1004a7694
1004a74bc:	ldp	x29, x30, [sp, #0x40]
1004a74c0:	ldp	x20, x19, [sp, #0x30]
1004a74c4:	ldp	x22, x21, [sp, #0x20]
1004a74c8:	add	sp, sp, #0x50
1004a74cc:	ret
1004a74d0:	sub	sp, sp, #0x60
1004a74d4:	stp	x24, x23, [sp, #0x20]
1004a74d8:	stp	x22, x21, [sp, #0x30]
1004a74dc:	stp	x20, x19, [sp, #0x40]
1004a74e0:	stp	x29, x30, [sp, #0x50]
1004a74e4:	add	x29, sp, #0x50
1004a74e8:	mov	x21, x0
1004a74ec:	ldr	x8, [x20]
1004a74f0:	adrp	x22, 7720 ; 0x1022cf000
1004a74f4:	ldr	x22, [x22, #0x718] ; literal pool symbol address: _swift_isaMask
1004a74f8:	ldr	x9, [x22]
1004a74fc:	and	x8, x9, x8
1004a7500:	ldr	x8, [x8, #0x1d0]
1004a7504:	blr	x8
1004a7508:	mov	w19, #0x0
1004a750c:	tbz	w0, #0x0, 0x1004a762c
1004a7510:	and	w8, w21, #0xffff
1004a7514:	cmp	w8, #0x7a
1004a7518:	b.le	0x1004a7544
1004a751c:	cmp	w8, #0x7b
1004a7520:	b.eq	0x1004a75f0
1004a7524:	cmp	w8, #0x7e
1004a7528:	b.eq	0x1004a7620
1004a752c:	cmp	w8, #0x7d
1004a7530:	b.ne	0x1004a762c
1004a7534:	mov	w19, #0x1
1004a7538:	mov	w0, #0x1
1004a753c:	bl	0x1004a7694
1004a7540:	b	0x1004a762c
1004a7544:	cmp	w8, #0x24
1004a7548:	b.eq	0x1004a7554
1004a754c:	cmp	w8, #0x4c
1004a7550:	b.ne	0x1004a762c
1004a7554:	adrp	x8, 7853 ; 0x102354000
1004a7558:	ldr	x19, [x8, #0xe20]
1004a755c:	ldr	x23, [x20, x19]
1004a7560:	tbnz	x23, #0x3f, 0x1004a7628
1004a7564:	adrp	x8, 7853 ; 0x102354000
1004a7568:	ldr	x21, [x8, #0xe10]
1004a756c:	add	x0, x20, x21
1004a7570:	add	x1, sp, #0x8
1004a7574:	mov	x2, #0x0
1004a7578:	mov	x3, #0x0
1004a757c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a7580:	ldr	x8, [x20, x21]
1004a7584:	lsr	x9, x8, #62
1004a7588:	cbnz	x9, 0x1004a7648
1004a758c:	and	x8, x8, #0xffffffffffffff8
1004a7590:	ldr	x0, [x8, #0x10]
1004a7594:	cmp	x23, x0
1004a7598:	b.ge	0x1004a7628
1004a759c:	ldr	x8, [x20, x19]
1004a75a0:	ldr	x19, [x20, x21]
1004a75a4:	tst	x19, #0xc000000000000001
1004a75a8:	b.ne	0x1004a7664
1004a75ac:	tbnz	x8, #0x3f, 0x1004a768c
1004a75b0:	and	x9, x19, #0xffffffffffffff8
1004a75b4:	ldr	x9, [x9, #0x10]
1004a75b8:	cmp	x8, x9
1004a75bc:	b.hs	0x1004a7690
1004a75c0:	add	x8, x19, x8, lsl #3
1004a75c4:	ldr	x0, [x8, #0x20]
1004a75c8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a75cc:	mov	x20, x0
1004a75d0:	ldr	x8, [x20]
1004a75d4:	ldr	x9, [x22]
1004a75d8:	and	x8, x9, x8
1004a75dc:	ldr	x8, [x8, #0x150]
1004a75e0:	blr	x8
1004a75e4:	mov	x0, x20
1004a75e8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a75ec:	b	0x1004a7628
1004a75f0:	bl	0x1004a78e0
1004a75f4:	adrp	x8, 7853 ; 0x102354000
1004a75f8:	ldr	x19, [x8, #0xdc8]
1004a75fc:	mov	w21, #0x1
1004a7600:	add	x0, x20, x19
1004a7604:	add	x1, sp, #0x8
1004a7608:	mov	w2, #0x1
1004a760c:	mov	x3, #0x0
1004a7610:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a7614:	strb	wzr, [x20, x19]
1004a7618:	mov	x19, x21
1004a761c:	b	0x1004a762c
1004a7620:	mov	x0, #-0x1
1004a7624:	bl	0x1004a7694
1004a7628:	mov	w19, #0x1
1004a762c:	mov	x0, x19
1004a7630:	ldp	x29, x30, [sp, #0x50]
1004a7634:	ldp	x20, x19, [sp, #0x40]
1004a7638:	ldp	x22, x21, [sp, #0x30]
1004a763c:	ldp	x24, x23, [sp, #0x20]
1004a7640:	add	sp, sp, #0x60
1004a7644:	ret
1004a7648:	and	x9, x8, #0xffffffffffffff8
1004a764c:	cmn	x8, #0x1
1004a7650:	csel	x0, x9, x8, gt
1004a7654:	bl	0x101ac7900 ; symbol stub for: _$ss18_CocoaArrayWrapperV8endIndexSivg
1004a7658:	cmp	x23, x0
1004a765c:	b.lt	0x1004a759c
1004a7660:	b	0x1004a7628
1004a7664:	mov	x20, x8
1004a7668:	mov	x0, x19
1004a766c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a7670:	mov	x0, x20
1004a7674:	mov	x1, x19
1004a7678:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004a767c:	mov	x20, x0
1004a7680:	mov	x0, x19
1004a7684:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a7688:	b	0x1004a75d0
1004a768c:	brk	#0x1
1004a7690:	brk	#0x1
1004a7694:	sub	sp, sp, #0x60
1004a7698:	stp	x24, x23, [sp, #0x20]
1004a769c:	stp	x22, x21, [sp, #0x30]
1004a76a0:	stp	x20, x19, [sp, #0x40]
1004a76a4:	stp	x29, x30, [sp, #0x50]
1004a76a8:	add	x29, sp, #0x50
1004a76ac:	adrp	x8, 7853 ; 0x102354000
1004a76b0:	ldr	x23, [x8, #0xe20]
1004a76b4:	ldr	x21, [x20, x23]
1004a76b8:	adds	x19, x21, x0
1004a76bc:	b.vs	0x1004a7824
1004a76c0:	adrp	x8, 7853 ; 0x102354000
1004a76c4:	ldr	x22, [x8, #0xe10]
1004a76c8:	add	x0, x20, x22
1004a76cc:	add	x1, sp, #0x8
1004a76d0:	mov	x2, #0x0
1004a76d4:	mov	x3, #0x0
1004a76d8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a76dc:	ldr	x8, [x20, x22]
1004a76e0:	lsr	x9, x8, #62
1004a76e4:	cbnz	x9, 0x1004a7828
1004a76e8:	and	x8, x8, #0xffffffffffffff8
1004a76ec:	ldr	x0, [x8, #0x10]
1004a76f0:	subs	x8, x0, #0x1
1004a76f4:	b.vs	0x1004a7840
1004a76f8:	cmp	x19, x8
1004a76fc:	csel	x19, x19, x8, lt
1004a7700:	tbnz	x19, #0x3f, 0x1004a7714
1004a7704:	cmp	x19, x21
1004a7708:	b.eq	0x1004a780c
1004a770c:	tbz	x21, #0x3f, 0x1004a7720
1004a7710:	b	0x1004a7798
1004a7714:	cbz	x21, 0x1004a780c
1004a7718:	mov	x19, #0x0
1004a771c:	tbnz	x21, #0x3f, 0x1004a7798
1004a7720:	ldr	x8, [x20, x22]
1004a7724:	lsr	x9, x8, #62
1004a7728:	cbnz	x9, 0x1004a7860
1004a772c:	and	x8, x8, #0xffffffffffffff8
1004a7730:	ldr	x0, [x8, #0x10]
1004a7734:	cmp	x21, x0
1004a7738:	b.ge	0x1004a7798
1004a773c:	ldr	x8, [x20, x22]
1004a7740:	tst	x8, #0xc000000000000001
1004a7744:	b.ne	0x1004a78a8
1004a7748:	and	x9, x8, #0xffffffffffffff8
1004a774c:	ldr	x9, [x9, #0x10]
1004a7750:	cmp	x21, x9
1004a7754:	b.hs	0x1004a78dc
1004a7758:	mov	x24, x20
1004a775c:	add	x8, x8, x21, lsl #3
1004a7760:	ldr	x0, [x8, #0x20]
1004a7764:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a7768:	mov	x20, x0
1004a776c:	ldr	x8, [x20]
1004a7770:	adrp	x9, 7720 ; 0x1022cf000
1004a7774:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004a7778:	ldr	x9, [x9]
1004a777c:	and	x8, x9, x8
1004a7780:	ldr	x8, [x8, #0x148]
1004a7784:	mov	w0, #0x0
1004a7788:	blr	x8
1004a778c:	mov	x0, x20
1004a7790:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a7794:	mov	x20, x24
1004a7798:	str	x19, [x20, x23]
1004a779c:	ldr	x8, [x20, x22]
1004a77a0:	lsr	x9, x8, #62
1004a77a4:	cbnz	x9, 0x1004a7844
1004a77a8:	and	x8, x8, #0xffffffffffffff8
1004a77ac:	ldr	x0, [x8, #0x10]
1004a77b0:	cmp	x19, x0
1004a77b4:	b.ge	0x1004a780c
1004a77b8:	ldr	x20, [x20, x22]
1004a77bc:	tst	x20, #0xc000000000000001
1004a77c0:	b.ne	0x1004a787c
1004a77c4:	and	x8, x20, #0xffffffffffffff8
1004a77c8:	ldr	x8, [x8, #0x10]
1004a77cc:	cmp	x19, x8
1004a77d0:	b.hs	0x1004a78a4
1004a77d4:	add	x8, x20, x19, lsl #3
1004a77d8:	ldr	x0, [x8, #0x20]
1004a77dc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a77e0:	ldr	x8, [x0]
1004a77e4:	adrp	x9, 7720 ; 0x1022cf000
1004a77e8:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004a77ec:	ldr	x9, [x9]
1004a77f0:	and	x8, x9, x8
1004a77f4:	ldr	x8, [x8, #0x148]
1004a77f8:	mov	x20, x0
1004a77fc:	mov	w0, #0x1
1004a7800:	blr	x8
1004a7804:	mov	x0, x20
1004a7808:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a780c:	ldp	x29, x30, [sp, #0x50]
1004a7810:	ldp	x20, x19, [sp, #0x40]
1004a7814:	ldp	x22, x21, [sp, #0x30]
1004a7818:	ldp	x24, x23, [sp, #0x20]
1004a781c:	add	sp, sp, #0x60
1004a7820:	ret
1004a7824:	brk	#0x1
1004a7828:	and	x9, x8, #0xffffffffffffff8
1004a782c:	cmn	x8, #0x1
1004a7830:	csel	x0, x9, x8, gt
1004a7834:	bl	0x101ac7900 ; symbol stub for: _$ss18_CocoaArrayWrapperV8endIndexSivg
1004a7838:	subs	x8, x0, #0x1
1004a783c:	b.vc	0x1004a76f8
1004a7840:	brk	#0x1
1004a7844:	and	x9, x8, #0xffffffffffffff8
1004a7848:	cmn	x8, #0x1
1004a784c:	csel	x0, x9, x8, gt
1004a7850:	bl	0x101ac7900 ; symbol stub for: _$ss18_CocoaArrayWrapperV8endIndexSivg
1004a7854:	cmp	x19, x0
1004a7858:	b.lt	0x1004a77b8
1004a785c:	b	0x1004a780c
1004a7860:	and	x9, x8, #0xffffffffffffff8
1004a7864:	cmn	x8, #0x1
1004a7868:	csel	x0, x9, x8, gt
1004a786c:	bl	0x101ac7900 ; symbol stub for: _$ss18_CocoaArrayWrapperV8endIndexSivg
1004a7870:	cmp	x21, x0
1004a7874:	b.lt	0x1004a773c
1004a7878:	b	0x1004a7798
1004a787c:	mov	x0, x20
1004a7880:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a7884:	mov	x0, x19
1004a7888:	mov	x1, x20
1004a788c:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004a7890:	mov	x19, x0
1004a7894:	mov	x0, x20
1004a7898:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a789c:	mov	x0, x19
1004a78a0:	b	0x1004a77e0
1004a78a4:	brk	#0x1
1004a78a8:	mov	x24, x20
1004a78ac:	str	x22, [sp]
1004a78b0:	mov	x22, x8
1004a78b4:	mov	x0, x8
1004a78b8:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a78bc:	mov	x0, x21
1004a78c0:	mov	x1, x22
1004a78c4:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004a78c8:	mov	x20, x0
1004a78cc:	mov	x0, x22
1004a78d0:	ldr	x22, [sp]
1004a78d4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a78d8:	b	0x1004a776c
1004a78dc:	brk	#0x1
1004a78e0:	sub	sp, sp, #0x60
1004a78e4:	stp	x24, x23, [sp, #0x20]
1004a78e8:	stp	x22, x21, [sp, #0x30]
1004a78ec:	stp	x20, x19, [sp, #0x40]
1004a78f0:	stp	x29, x30, [sp, #0x50]
1004a78f4:	add	x29, sp, #0x50
1004a78f8:	adrp	x8, 7853 ; 0x102354000
1004a78fc:	ldr	x22, [x8, #0xe20]
1004a7900:	ldr	x19, [x20, x22]
1004a7904:	tbnz	x19, #0x3f, 0x1004a79a4
1004a7908:	adrp	x8, 7853 ; 0x102354000
1004a790c:	ldr	x21, [x8, #0xe10]
1004a7910:	add	x0, x20, x21
1004a7914:	add	x1, sp, #0x8
1004a7918:	mov	x2, #0x0
1004a791c:	mov	x3, #0x0
1004a7920:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a7924:	ldr	x8, [x20, x21]
1004a7928:	lsr	x9, x8, #62
1004a792c:	cbnz	x9, 0x1004a79c4
1004a7930:	and	x8, x8, #0xffffffffffffff8
1004a7934:	ldr	x0, [x8, #0x10]
1004a7938:	cmp	x19, x0
1004a793c:	b.ge	0x1004a79a4
1004a7940:	ldr	x19, [x20, x22]
1004a7944:	ldr	x21, [x20, x21]
1004a7948:	tst	x21, #0xc000000000000001
1004a794c:	b.ne	0x1004a79e0
1004a7950:	tbnz	x19, #0x3f, 0x1004a7a08
1004a7954:	and	x8, x21, #0xffffffffffffff8
1004a7958:	ldr	x8, [x8, #0x10]
1004a795c:	cmp	x19, x8
1004a7960:	b.hs	0x1004a7a0c
1004a7964:	mov	x23, x20
1004a7968:	add	x8, x21, x19, lsl #3
1004a796c:	ldr	x0, [x8, #0x20]
1004a7970:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a7974:	mov	x20, x0
1004a7978:	ldr	x8, [x20]
1004a797c:	adrp	x9, 7720 ; 0x1022cf000
1004a7980:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004a7984:	ldr	x9, [x9]
1004a7988:	and	x8, x9, x8
1004a798c:	ldr	x8, [x8, #0x148]
1004a7990:	mov	w0, #0x0
1004a7994:	blr	x8
1004a7998:	mov	x0, x20
1004a799c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a79a0:	mov	x20, x23
1004a79a4:	mov	x8, #-0x1
1004a79a8:	str	x8, [x20, x22]
1004a79ac:	ldp	x29, x30, [sp, #0x50]
1004a79b0:	ldp	x20, x19, [sp, #0x40]
1004a79b4:	ldp	x22, x21, [sp, #0x30]
1004a79b8:	ldp	x24, x23, [sp, #0x20]
1004a79bc:	add	sp, sp, #0x60
1004a79c0:	ret
1004a79c4:	and	x9, x8, #0xffffffffffffff8
1004a79c8:	cmn	x8, #0x1
1004a79cc:	csel	x0, x9, x8, gt
1004a79d0:	bl	0x101ac7900 ; symbol stub for: _$ss18_CocoaArrayWrapperV8endIndexSivg
1004a79d4:	cmp	x19, x0
1004a79d8:	b.lt	0x1004a7940
1004a79dc:	b	0x1004a79a4
1004a79e0:	mov	x23, x20
1004a79e4:	mov	x0, x21
1004a79e8:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a79ec:	mov	x0, x19
1004a79f0:	mov	x1, x21
1004a79f4:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004a79f8:	mov	x20, x0
1004a79fc:	mov	x0, x21
1004a7a00:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a7a04:	b	0x1004a7978
1004a7a08:	brk	#0x1
1004a7a0c:	brk	#0x1
1004a7a10:	sub	sp, sp, #0x50
1004a7a14:	stp	d11, d10, [sp, #0x10]
1004a7a18:	stp	d9, d8, [sp, #0x20]
1004a7a1c:	stp	x20, x19, [sp, #0x30]
1004a7a20:	stp	x29, x30, [sp, #0x40]
1004a7a24:	add	x29, sp, #0x40
1004a7a28:	mov.16b	v8, v3
1004a7a2c:	mov.16b	v9, v2
1004a7a30:	mov.16b	v10, v1
1004a7a34:	mov.16b	v11, v0
1004a7a38:	adrp	x8, 7853 ; 0x102354000
1004a7a3c:	ldr	x8, [x8, #0xde0]
1004a7a40:	str	xzr, [x20, x8]
1004a7a44:	adrp	x8, 7853 ; 0x102354000
1004a7a48:	ldr	x8, [x8, #0xde8]
1004a7a4c:	adrp	x19, 7720 ; 0x1022cf000
1004a7a50:	ldr	x19, [x19, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004a7a54:	str	x19, [x20, x8]
1004a7a58:	adrp	x8, 7853 ; 0x102354000
1004a7a5c:	ldr	x8, [x8, #0xdf0]
1004a7a60:	str	xzr, [x20, x8]
1004a7a64:	adrp	x8, 7853 ; 0x102354000
1004a7a68:	ldr	x8, [x8, #0xdd0]
1004a7a6c:	add	x8, x20, x8
1004a7a70:	stp	xzr, xzr, [x8]
1004a7a74:	adrp	x8, 7853 ; 0x102354000
1004a7a78:	ldr	x8, [x8, #0xe00]
1004a7a7c:	str	xzr, [x20, x8]
1004a7a80:	adrp	x8, 7853 ; 0x102354000
1004a7a84:	ldr	x8, [x8, #0xe08]
1004a7a88:	str	x19, [x20, x8]
1004a7a8c:	adrp	x8, 7853 ; 0x102354000
1004a7a90:	ldr	x8, [x8, #0xe18]
1004a7a94:	strb	wzr, [x20, x8]
1004a7a98:	adrp	x8, 7853 ; 0x102354000
1004a7a9c:	ldr	x8, [x8, #0xdd8]
1004a7aa0:	add	x0, x20, x8
1004a7aa4:	mov	x1, #0x0
1004a7aa8:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004a7aac:	adrp	x8, 7853 ; 0x102354000
1004a7ab0:	ldr	x8, [x8, #0xdf8]
1004a7ab4:	str	xzr, [x20, x8]
1004a7ab8:	adrp	x8, 7853 ; 0x102354000
1004a7abc:	ldr	x8, [x8, #0xe10]
1004a7ac0:	str	x19, [x20, x8]
1004a7ac4:	adrp	x8, 7853 ; 0x102354000
1004a7ac8:	ldr	x8, [x8, #0xe20]
1004a7acc:	mov	x9, #-0x1
1004a7ad0:	str	x9, [x20, x8]
1004a7ad4:	adrp	x8, 7853 ; 0x102354000
1004a7ad8:	ldr	x8, [x8, #0xdc8]
1004a7adc:	strb	wzr, [x20, x8]
1004a7ae0:	adrp	x8, 7853 ; 0x102354000
1004a7ae4:	ldr	x8, [x8, #0xe28]
1004a7ae8:	mov	x9, #0x4030000000000000
1004a7aec:	str	x9, [x20, x8]
1004a7af0:	adrp	x8, 7853 ; 0x102354000
1004a7af4:	ldr	x8, [x8, #0xe30]
1004a7af8:	mov	x9, #0x402a000000000000
1004a7afc:	str	x9, [x20, x8]
1004a7b00:	adrp	x8, 7853 ; 0x102354000
1004a7b04:	ldr	x8, [x8, #0xe38]
1004a7b08:	mov	x9, #0x4018000000000000
1004a7b0c:	str	x9, [x20, x8]
1004a7b10:	bl	0x1004a7e0c
1004a7b14:	stp	x20, x0, [sp]
1004a7b18:	adrp	x8, 7804 ; 0x102323000
1004a7b1c:	ldr	x1, [x8, #0x50] ; Objc selector ref: initWithFrame:
1004a7b20:	mov	x0, sp
1004a7b24:	mov.16b	v0, v11
1004a7b28:	mov.16b	v1, v10
1004a7b2c:	mov.16b	v2, v9
1004a7b30:	mov.16b	v3, v8
1004a7b34:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithFrame:]
1004a7b38:	ldp	x29, x30, [sp, #0x40]
1004a7b3c:	ldp	x20, x19, [sp, #0x30]
1004a7b40:	ldp	d9, d8, [sp, #0x20]
1004a7b44:	ldp	d11, d10, [sp, #0x10]
1004a7b48:	add	sp, sp, #0x50
1004a7b4c:	ret
1004a7b50:	stp	x20, x19, [sp, #-0x20]!
1004a7b54:	stp	x29, x30, [sp, #0x10]
1004a7b58:	add	x29, sp, #0x10
1004a7b5c:	mov	x20, x0
1004a7b60:	bl	0x1004a7a10
1004a7b64:	ldp	x29, x30, [sp, #0x10]
1004a7b68:	ldp	x20, x19, [sp], #0x20
1004a7b6c:	ret
1004a7b70:	sub	sp, sp, #0x40
1004a7b74:	stp	x22, x21, [sp, #0x10]
1004a7b78:	stp	x20, x19, [sp, #0x20]
1004a7b7c:	stp	x29, x30, [sp, #0x30]
1004a7b80:	add	x29, sp, #0x30
1004a7b84:	mov	x19, x0
1004a7b88:	adrp	x8, 7853 ; 0x102354000
1004a7b8c:	ldr	x8, [x8, #0xde0]
1004a7b90:	str	xzr, [x20, x8]
1004a7b94:	adrp	x8, 7853 ; 0x102354000
1004a7b98:	ldr	x8, [x8, #0xde8]
1004a7b9c:	adrp	x21, 7720 ; 0x1022cf000
1004a7ba0:	ldr	x21, [x21, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004a7ba4:	str	x21, [x20, x8]
1004a7ba8:	adrp	x8, 7853 ; 0x102354000
1004a7bac:	ldr	x8, [x8, #0xdf0]
1004a7bb0:	str	xzr, [x20, x8]
1004a7bb4:	adrp	x8, 7853 ; 0x102354000
1004a7bb8:	ldr	x8, [x8, #0xdd0]
1004a7bbc:	add	x8, x20, x8
1004a7bc0:	stp	xzr, xzr, [x8]
1004a7bc4:	adrp	x8, 7853 ; 0x102354000
1004a7bc8:	ldr	x8, [x8, #0xe00]
1004a7bcc:	str	xzr, [x20, x8]
1004a7bd0:	adrp	x8, 7853 ; 0x102354000
1004a7bd4:	ldr	x8, [x8, #0xe08]
1004a7bd8:	str	x21, [x20, x8]
1004a7bdc:	adrp	x8, 7853 ; 0x102354000
1004a7be0:	ldr	x8, [x8, #0xe18]
1004a7be4:	strb	wzr, [x20, x8]
1004a7be8:	adrp	x8, 7853 ; 0x102354000
1004a7bec:	ldr	x8, [x8, #0xdd8]
1004a7bf0:	add	x0, x20, x8
1004a7bf4:	mov	x1, #0x0
1004a7bf8:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004a7bfc:	adrp	x8, 7853 ; 0x102354000
1004a7c00:	ldr	x8, [x8, #0xdf8]
1004a7c04:	str	xzr, [x20, x8]
1004a7c08:	adrp	x8, 7853 ; 0x102354000
1004a7c0c:	ldr	x8, [x8, #0xe10]
1004a7c10:	str	x21, [x20, x8]
1004a7c14:	adrp	x8, 7853 ; 0x102354000
1004a7c18:	ldr	x8, [x8, #0xe20]
1004a7c1c:	mov	x9, #-0x1
1004a7c20:	str	x9, [x20, x8]
1004a7c24:	adrp	x8, 7853 ; 0x102354000
1004a7c28:	ldr	x8, [x8, #0xdc8]
1004a7c2c:	strb	wzr, [x20, x8]
1004a7c30:	adrp	x8, 7853 ; 0x102354000
1004a7c34:	ldr	x8, [x8, #0xe28]
1004a7c38:	mov	x9, #0x4030000000000000
1004a7c3c:	str	x9, [x20, x8]
1004a7c40:	adrp	x8, 7853 ; 0x102354000
1004a7c44:	ldr	x8, [x8, #0xe30]
1004a7c48:	mov	x9, #0x402a000000000000
1004a7c4c:	str	x9, [x20, x8]
1004a7c50:	adrp	x8, 7853 ; 0x102354000
1004a7c54:	ldr	x8, [x8, #0xe38]
1004a7c58:	mov	x9, #0x4018000000000000
1004a7c5c:	str	x9, [x20, x8]
1004a7c60:	bl	0x1004a7e0c
1004a7c64:	stp	x20, x0, [sp]
1004a7c68:	adrp	x8, 7803 ; 0x102322000
1004a7c6c:	ldr	x1, [x8, #0xfd8] ; Objc selector ref: initWithCoder:
1004a7c70:	mov	x0, sp
1004a7c74:	mov	x2, x19
1004a7c78:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithCoder:]
1004a7c7c:	mov	x29, x29
1004a7c80:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a7c84:	mov	x20, x0
1004a7c88:	mov	x0, x19
1004a7c8c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a7c90:	cbz	x20, 0x1004a7c9c
1004a7c94:	mov	x0, x20
1004a7c98:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a7c9c:	mov	x0, x20
1004a7ca0:	ldp	x29, x30, [sp, #0x30]
1004a7ca4:	ldp	x20, x19, [sp, #0x20]
1004a7ca8:	ldp	x22, x21, [sp, #0x10]
1004a7cac:	add	sp, sp, #0x40
1004a7cb0:	ret
1004a7cb4:	stp	x20, x19, [sp, #-0x20]!
1004a7cb8:	stp	x29, x30, [sp, #0x10]
1004a7cbc:	add	x29, sp, #0x10
1004a7cc0:	mov	x20, x0
1004a7cc4:	mov	x0, x2
1004a7cc8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a7ccc:	bl	0x1004a7b70
1004a7cd0:	ldp	x29, x30, [sp, #0x10]
1004a7cd4:	ldp	x20, x19, [sp], #0x20
1004a7cd8:	ret
1004a7cdc:	stp	x24, x23, [sp, #-0x40]!
1004a7ce0:	stp	x22, x21, [sp, #0x10]
1004a7ce4:	stp	x20, x19, [sp, #0x20]
1004a7ce8:	stp	x29, x30, [sp, #0x30]
1004a7cec:	add	x29, sp, #0x30
1004a7cf0:	mov	x19, x3
1004a7cf4:	mov	x20, x0
1004a7cf8:	tbz	w2, #0x0, 0x1004a7d28
1004a7cfc:	ldr	x9, [x19, #0x18]
1004a7d00:	lsr	x8, x9, #1
1004a7d04:	cmp	x8, x1
1004a7d08:	b.ge	0x1004a7d2c
1004a7d0c:	mov	x10, #0x4000000000000000
1004a7d10:	cmn	x8, x10
1004a7d14:	b.mi	0x1004a7e08
1004a7d18:	and	x8, x9, #0xfffffffffffffffe
1004a7d1c:	cmp	x8, x1
1004a7d20:	csel	x8, x8, x1, gt
1004a7d24:	b	0x1004a7d2c
1004a7d28:	mov	x8, x1
1004a7d2c:	ldr	x21, [x19, #0x10]
1004a7d30:	cmp	x8, x21
1004a7d34:	csel	x22, x8, x21, gt
1004a7d38:	cbz	x22, 0x1004a7d84
1004a7d3c:	adrp	x0, 7853 ; 0x102354000
1004a7d40:	add	x0, x0, #0xe68
1004a7d44:	adrp	x1, 5710 ; 0x101af5000
1004a7d48:	add	x1, x1, #0xc18
1004a7d4c:	bl	0x100003c4c
1004a7d50:	lsl	x8, x22, #4
1004a7d54:	add	x1, x8, #0x20
1004a7d58:	mov	w2, #0x7
1004a7d5c:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004a7d60:	mov	x22, x0
1004a7d64:	bl	0x101ac9c04 ; symbol stub for: _malloc_size
1004a7d68:	subs	x8, x0, #0x20
1004a7d6c:	sub	x9, x0, #0x11
1004a7d70:	csel	x8, x9, x8, lt
1004a7d74:	asr	x8, x8, #4
1004a7d78:	lsl	x8, x8, #1
1004a7d7c:	stp	x21, x8, [x22, #0x10]
1004a7d80:	b	0x1004a7d8c
1004a7d84:	adrp	x22, 7720 ; 0x1022cf000
1004a7d88:	ldr	x22, [x22, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004a7d8c:	add	x23, x22, #0x20
1004a7d90:	add	x24, x19, #0x20
1004a7d94:	tbz	w20, #0x0, 0x1004a7dc0
1004a7d98:	add	x8, x24, x21, lsl #4
1004a7d9c:	cmp	x22, x19
1004a7da0:	ccmp	x23, x8, #0x2, eq
1004a7da4:	b.lo	0x1004a7db8
1004a7da8:	lsl	x2, x21, #4
1004a7dac:	mov	x0, x23
1004a7db0:	mov	x1, x24
1004a7db4:	bl	0x101ac9c40 ; symbol stub for: _memmove
1004a7db8:	str	xzr, [x19, #0x10]
1004a7dbc:	b	0x1004a7de8
1004a7dc0:	adrp	x0, 7853 ; 0x102354000
1004a7dc4:	add	x0, x0, #0xe70
1004a7dc8:	adrp	x1, 5710 ; 0x101af5000
1004a7dcc:	add	x1, x1, #0xc20
1004a7dd0:	bl	0x100003c4c
1004a7dd4:	mov	x3, x0
1004a7dd8:	mov	x0, x23
1004a7ddc:	mov	x1, x24
1004a7de0:	mov	x2, x21
1004a7de4:	bl	0x101aca5b8 ; symbol stub for: _swift_arrayInitWithCopy
1004a7de8:	mov	x0, x19
1004a7dec:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a7df0:	mov	x0, x22
1004a7df4:	ldp	x29, x30, [sp, #0x30]
1004a7df8:	ldp	x20, x19, [sp, #0x20]
1004a7dfc:	ldp	x22, x21, [sp, #0x10]
1004a7e00:	ldp	x24, x23, [sp], #0x40
1004a7e04:	ret
1004a7e08:	brk	#0x1
1004a7e0c:	stp	x29, x30, [sp, #-0x10]!
1004a7e10:	mov	x29, sp
1004a7e14:	adrp	x0, 7817 ; 0x102330000
1004a7e18:	add	x0, x0, #0xab8
1004a7e1c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004a7e20:	mov	x1, #0x0
1004a7e24:	ldp	x29, x30, [sp], #0x10
1004a7e28:	ret
1004a7e2c:	stp	x29, x30, [sp, #-0x10]!
1004a7e30:	mov	x29, sp
1004a7e34:	adrp	x8, 7853 ; 0x102354000
1004a7e38:	ldr	x8, [x8, #0xe18]
1004a7e3c:	ldrb	w9, [x20, x8]
1004a7e40:	mov	w10, #0x1
1004a7e44:	strb	w10, [x20, x8]
1004a7e48:	tbnz	w9, #0x0, 0x1004a7e6c
1004a7e4c:	mov	x0, x20
1004a7e50:	bl	0x1004adb68
1004a7e54:	adrp	x8, 7853 ; 0x102354000
1004a7e58:	ldr	x9, [x8, #0xe08]
1004a7e5c:	ldr	x8, [x20, x9]
1004a7e60:	str	x0, [x20, x9]
1004a7e64:	mov	x0, x8
1004a7e68:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a7e6c:	mov	x0, x20
1004a7e70:	bl	0x101acbde0 ; selector bounds
1004a7e74:	mov	x0, x20
1004a7e78:	bl	0x101ad3820 ; selector setNeedsDisplayInRect:
1004a7e7c:	ldp	x29, x30, [sp], #0x10
1004a7e80:	b	0x1004a65dc
1004a7e84:	stp	x22, x21, [sp, #-0x30]!
1004a7e88:	stp	x20, x19, [sp, #0x10]
1004a7e8c:	stp	x29, x30, [sp, #0x20]
1004a7e90:	add	x29, sp, #0x20
1004a7e94:	adrp	x8, 7853 ; 0x102354000
1004a7e98:	ldr	x8, [x8, #0xe18]
1004a7e9c:	ldrb	w9, [x20, x8]
1004a7ea0:	strb	wzr, [x20, x8]
1004a7ea4:	cmp	w9, #0x1
1004a7ea8:	b.ne	0x1004a7ee0
1004a7eac:	adrp	x8, 7853 ; 0x102354000
1004a7eb0:	ldr	x21, [x8, #0xe08]
1004a7eb4:	ldr	x19, [x20, x21]
1004a7eb8:	mov	x0, x19
1004a7ebc:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a7ec0:	bl	0x1004adb6c
1004a7ec4:	mov	x0, x19
1004a7ec8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a7ecc:	ldr	x0, [x20, x21]
1004a7ed0:	adrp	x8, 7720 ; 0x1022cf000
1004a7ed4:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004a7ed8:	str	x8, [x20, x21]
1004a7edc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a7ee0:	mov	x0, x20
1004a7ee4:	bl	0x101acbde0 ; selector bounds
1004a7ee8:	mov	x0, x20
1004a7eec:	ldp	x29, x30, [sp, #0x20]
1004a7ef0:	ldp	x20, x19, [sp, #0x10]
1004a7ef4:	ldp	x22, x21, [sp], #0x30
1004a7ef8:	b	0x101ad3820 ; selector setNeedsDisplayInRect:
1004a7efc:	stp	x22, x21, [sp, #-0x30]!
1004a7f00:	stp	x20, x19, [sp, #0x10]
1004a7f04:	stp	x29, x30, [sp, #0x20]
1004a7f08:	add	x29, sp, #0x20
1004a7f0c:	mov	x19, x0
1004a7f10:	ldr	x8, [x1]
1004a7f14:	str	x8, [x0]
1004a7f18:	ldur	q0, [x1, #0x8]
1004a7f1c:	stur	q0, [x0, #0x8]
1004a7f20:	ldp	x20, x21, [x1, #0x10]
1004a7f24:	str	x21, [x0, #0x18]
1004a7f28:	fmov	x0, d0
1004a7f2c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a7f30:	mov	x0, x20
1004a7f34:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a7f38:	mov	x0, x21
1004a7f3c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a7f40:	mov	x0, x19
1004a7f44:	ldp	x29, x30, [sp, #0x20]
1004a7f48:	ldp	x20, x19, [sp, #0x10]
1004a7f4c:	ldp	x22, x21, [sp], #0x30
1004a7f50:	ret
1004a7f54:	stp	x22, x21, [sp, #-0x30]!
1004a7f58:	stp	x20, x19, [sp, #0x10]
1004a7f5c:	stp	x29, x30, [sp, #0x20]
1004a7f60:	add	x29, sp, #0x20
1004a7f64:	mov	x19, x1
1004a7f68:	mov	x20, x0
1004a7f6c:	ldr	x8, [x1]
1004a7f70:	str	x8, [x0]
1004a7f74:	ldr	x0, [x1, #0x8]
1004a7f78:	ldr	x21, [x20, #0x8]
1004a7f7c:	str	x0, [x20, #0x8]
1004a7f80:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a7f84:	mov	x0, x21
1004a7f88:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a7f8c:	ldr	x21, [x20, #0x10]
1004a7f90:	ldr	x0, [x19, #0x10]
1004a7f94:	str	x0, [x20, #0x10]
1004a7f98:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a7f9c:	mov	x0, x21
1004a7fa0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a7fa4:	ldr	x21, [x20, #0x18]
1004a7fa8:	ldr	x0, [x19, #0x18]
1004a7fac:	str	x0, [x20, #0x18]
1004a7fb0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a7fb4:	mov	x0, x21
1004a7fb8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a7fbc:	mov	x0, x20
1004a7fc0:	ldp	x29, x30, [sp, #0x20]
1004a7fc4:	ldp	x20, x19, [sp, #0x10]
1004a7fc8:	ldp	x22, x21, [sp], #0x30
1004a7fcc:	ret
1004a7fd0:	stp	x20, x19, [sp, #-0x20]!
1004a7fd4:	stp	x29, x30, [sp, #0x10]
1004a7fd8:	add	x29, sp, #0x10
1004a7fdc:	mov	x19, x1
1004a7fe0:	mov	x20, x0
1004a7fe4:	ldr	x8, [x1]
1004a7fe8:	str	x8, [x0]
1004a7fec:	ldr	x0, [x0, #0x8]
1004a7ff0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a7ff4:	ldr	x0, [x20, #0x10]
1004a7ff8:	ldur	q0, [x19, #0x8]
1004a7ffc:	stur	q0, [x20, #0x8]
1004a8000:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8004:	ldr	x0, [x20, #0x18]
1004a8008:	ldr	x8, [x19, #0x18]
1004a800c:	str	x8, [x20, #0x18]
1004a8010:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8014:	mov	x0, x20
1004a8018:	ldp	x29, x30, [sp, #0x10]
1004a801c:	ldp	x20, x19, [sp], #0x20
1004a8020:	ret
1004a8024:	adrp	x0, 7474 ; 0x1021da000
1004a8028:	add	x0, x0, #0x5e0
1004a802c:	mov	x1, #0x0
1004a8030:	ret
1004a8034:	stp	x29, x30, [sp, #-0x10]!
1004a8038:	mov	x29, sp
1004a803c:	ldr	x0, [x20, #0x18]
1004a8040:	bl	0x101aca960 ; symbol stub for: _swift_release
1004a8044:	mov	x0, x20
1004a8048:	mov	w1, #0x20
1004a804c:	mov	w2, #0x7
1004a8050:	ldp	x29, x30, [sp], #0x10
1004a8054:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004a8058:	stp	x29, x30, [sp, #-0x10]!
1004a805c:	mov	x29, sp
1004a8060:	add	x0, x20, #0x10
1004a8064:	bl	0x101acaabc ; symbol stub for: _swift_unknownObjectWeakDestroy
1004a8068:	mov	x0, x20
1004a806c:	mov	w1, #0x18
1004a8070:	mov	w2, #0x7
1004a8074:	ldp	x29, x30, [sp], #0x10
1004a8078:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004a807c:	stp	x29, x30, [sp, #-0x10]!
1004a8080:	mov	x29, sp
1004a8084:	ldr	x0, [x20, #0x18]
1004a8088:	bl	0x101aca960 ; symbol stub for: _swift_release
1004a808c:	ldr	x0, [x20, #0x20]
1004a8090:	bl	0x101aca960 ; symbol stub for: _swift_release
1004a8094:	mov	x0, x20
1004a8098:	mov	w1, #0x28
1004a809c:	mov	w2, #0x7
1004a80a0:	ldp	x29, x30, [sp], #0x10
1004a80a4:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004a80a8:	sub	sp, sp, #0x40
1004a80ac:	stp	x20, x19, [sp, #0x20]
1004a80b0:	stp	x29, x30, [sp, #0x30]
1004a80b4:	add	x29, sp, #0x30
1004a80b8:	ldp	x9, x8, [x20, #0x10]
1004a80bc:	ldr	x19, [x20, #0x20]
1004a80c0:	mov	x20, x8
1004a80c4:	blr	x9
1004a80c8:	add	x0, x19, #0x10
1004a80cc:	add	x1, sp, #0x8
1004a80d0:	mov	x2, #0x0
1004a80d4:	mov	x3, #0x0
1004a80d8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a80dc:	add	x0, x19, #0x10
1004a80e0:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004a80e4:	cbz	x0, 0x1004a80f8
1004a80e8:	mov	x20, x0
1004a80ec:	bl	0x1004a65dc
1004a80f0:	mov	x0, x20
1004a80f4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a80f8:	ldp	x29, x30, [sp, #0x30]
1004a80fc:	ldp	x20, x19, [sp, #0x20]
1004a8100:	add	sp, sp, #0x40
1004a8104:	ret
1004a8108:	stp	x28, x27, [sp, #-0x60]!
1004a810c:	stp	x26, x25, [sp, #0x10]
1004a8110:	stp	x24, x23, [sp, #0x20]
1004a8114:	stp	x22, x21, [sp, #0x30]
1004a8118:	stp	x20, x19, [sp, #0x40]
1004a811c:	stp	x29, x30, [sp, #0x50]
1004a8120:	add	x29, sp, #0x50
1004a8124:	sub	sp, sp, #0x10
1004a8128:	mov	x21, x0
1004a812c:	mov	x0, #0x0
1004a8130:	bl	0x101ac4fd8 ; symbol stub for: _$s10Foundation4DateVMa
1004a8134:	mov	x22, x0
1004a8138:	ldur	x27, [x0, #-0x8]
1004a813c:	ldr	x8, [x27, #0x40]
1004a8140:	mov	x9, x8
1004a8144:	adrp	x16, 7715 ; 0x1022cb000
1004a8148:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004a814c:	blr	x16
1004a8150:	mov	x9, sp
1004a8154:	add	x8, x8, #0xf
1004a8158:	and	x8, x8, #0xfffffffffffffff0
1004a815c:	sub	x23, x9, x8
1004a8160:	mov	sp, x23
1004a8164:	adrp	x0, 7833 ; 0x102341000
1004a8168:	add	x0, x0, #0x6d0
1004a816c:	adrp	x1, 5689 ; 0x101ae1000
1004a8170:	add	x1, x1, #0x7e0
1004a8174:	bl	0x100003c4c
1004a8178:	mov	w1, #0x30
1004a817c:	mov	w2, #0x7
1004a8180:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004a8184:	mov	x19, x0
1004a8188:	adrp	x8, 5689 ; 0x101ae1000
1004a818c:	ldr	q0, [x8, #0x130]
1004a8190:	str	q0, [x0, #0x10]
1004a8194:	mov	x8, #0x6150
1004a8198:	movk	x8, #0x656e, lsl #16
1004a819c:	movk	x8, #0x4920, lsl #32
1004a81a0:	movk	x8, #0x3a44, lsl #48
1004a81a4:	mov	x9, #0x20
1004a81a8:	movk	x9, #0xe900, lsl #48
1004a81ac:	stp	x8, x9, [x29, #-0x60]
1004a81b0:	ldp	x0, x1, [x21, #0x18]
1004a81b4:	sub	x20, x29, #0x60
1004a81b8:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a81bc:	ldp	x8, x9, [x29, #-0x60]
1004a81c0:	stp	x8, x9, [x19, #0x20]
1004a81c4:	mov	x0, x21
1004a81c8:	bl	0x1004a8824
1004a81cc:	cbz	x1, 0x1004a8264
1004a81d0:	mov	x25, x0
1004a81d4:	mov	x24, x1
1004a81d8:	mov	x8, #-0x2000000000000000
1004a81dc:	stp	xzr, x8, [x29, #-0x60]
1004a81e0:	tst	w2, #0x1
1004a81e4:	mov	w8, #0x5554
1004a81e8:	movk	w8, #0x49, lsl #16
1004a81ec:	mov	x9, #0x6f43
1004a81f0:	movk	x9, #0x6d6d, lsl #16
1004a81f4:	movk	x9, #0x6e61, lsl #32
1004a81f8:	movk	x9, #0x64, lsl #48
1004a81fc:	csel	x0, x8, x9, ne
1004a8200:	mov	x8, #-0x1900000000000000
1004a8204:	mov	x9, #-0x1d00000000000000
1004a8208:	csel	x26, x9, x8, ne
1004a820c:	mov	x1, x26
1004a8210:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a8214:	mov	x0, x26
1004a8218:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a821c:	mov	w0, #0x203a
1004a8220:	mov	x1, #-0x1e00000000000000
1004a8224:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a8228:	mov	x0, x25
1004a822c:	mov	x1, x24
1004a8230:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a8234:	mov	x0, x24
1004a8238:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a823c:	ldp	x20, x24, [x29, #-0x60]
1004a8240:	mov	w25, #0x2
1004a8244:	mov	w0, #0x1
1004a8248:	mov	w1, #0x2
1004a824c:	mov	w2, #0x1
1004a8250:	mov	x3, x19
1004a8254:	bl	0x100030d24
1004a8258:	mov	x19, x0
1004a825c:	str	x25, [x0, #0x10]
1004a8260:	stp	x20, x24, [x0, #0x30]
1004a8264:	mov	x8, #0x704f
1004a8268:	movk	x8, #0x6e65, lsl #16
1004a826c:	movk	x8, #0x6465, lsl #32
1004a8270:	movk	x8, #0x203a, lsl #48
1004a8274:	mov	x26, #-0x1800000000000000
1004a8278:	stp	x8, x26, [x29, #-0x60]
1004a827c:	ldr	x8, [x21]
1004a8280:	ldr	x9, [x8, #0x8f8]
1004a8284:	mov	x8, x23
1004a8288:	mov	x20, x21
1004a828c:	blr	x9
1004a8290:	mov	x0, x23
1004a8294:	bl	0x1004a8c10
1004a8298:	mov	x24, x0
1004a829c:	mov	x25, x1
1004a82a0:	ldr	x8, [x27, #0x8]
1004a82a4:	mov	x0, x23
1004a82a8:	mov	x1, x22
1004a82ac:	blr	x8
1004a82b0:	sub	x20, x29, #0x60
1004a82b4:	mov	x0, x24
1004a82b8:	mov	x1, x25
1004a82bc:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a82c0:	mov	x0, x25
1004a82c4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a82c8:	ldp	x22, x23, [x29, #-0x60]
1004a82cc:	ldp	x24, x8, [x19, #0x10]
1004a82d0:	add	x20, x24, #0x1
1004a82d4:	cmp	x24, x8, lsr #1
1004a82d8:	b.hs	0x1004a83e8
1004a82dc:	str	x20, [x19, #0x10]
1004a82e0:	add	x8, x19, x24, lsl #4
1004a82e4:	stp	x22, x23, [x8, #0x20]
1004a82e8:	mov	x8, #0x6544
1004a82ec:	movk	x8, #0x6976, lsl #16
1004a82f0:	movk	x8, #0x6563, lsl #32
1004a82f4:	movk	x8, #0x203a, lsl #48
1004a82f8:	stp	x8, x26, [x29, #-0x60]
1004a82fc:	mov	x0, x21
1004a8300:	bl	0x1004a8d80
1004a8304:	mov	x22, x1
1004a8308:	sub	x20, x29, #0x60
1004a830c:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a8310:	mov	x0, x22
1004a8314:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8318:	ldp	x22, x23, [x29, #-0x60]
1004a831c:	ldp	x24, x8, [x19, #0x10]
1004a8320:	add	x20, x24, #0x1
1004a8324:	cmp	x24, x8, lsr #1
1004a8328:	b.hs	0x1004a8408
1004a832c:	str	x20, [x19, #0x10]
1004a8330:	add	x8, x19, x24, lsl #4
1004a8334:	stp	x22, x23, [x8, #0x20]
1004a8338:	ldr	x8, [x21]
1004a833c:	ldr	x8, [x8, #0x470]
1004a8340:	mov	x20, x21
1004a8344:	blr	x8
1004a8348:	cbz	x1, 0x1004a83c4
1004a834c:	and	x8, x0, #0xffffffffffff
1004a8350:	ubfx	x9, x1, #56, #4
1004a8354:	tst	x1, #0x2000000000000000
1004a8358:	csel	x8, x8, x9, eq
1004a835c:	cbz	x8, 0x1004a83bc
1004a8360:	mov	x8, #0x704f
1004a8364:	movk	x8, #0x6e65, lsl #16
1004a8368:	movk	x8, #0x6465, lsl #32
1004a836c:	movk	x8, #0x6620, lsl #48
1004a8370:	mov	x9, #0x6f72
1004a8374:	movk	x9, #0x3a6d, lsl #16
1004a8378:	movk	x9, #0x20, lsl #32
1004a837c:	movk	x9, #0xed00, lsl #48
1004a8380:	stp	x8, x9, [x29, #-0x60]
1004a8384:	sub	x20, x29, #0x60
1004a8388:	mov	x21, x1
1004a838c:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a8390:	mov	x0, x21
1004a8394:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8398:	ldp	x21, x22, [x29, #-0x60]
1004a839c:	ldp	x23, x8, [x19, #0x10]
1004a83a0:	add	x20, x23, #0x1
1004a83a4:	cmp	x23, x8, lsr #1
1004a83a8:	b.hs	0x1004a8428
1004a83ac:	str	x20, [x19, #0x10]
1004a83b0:	add	x8, x19, x23, lsl #4
1004a83b4:	stp	x21, x22, [x8, #0x20]
1004a83b8:	b	0x1004a83c4
1004a83bc:	mov	x0, x1
1004a83c0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a83c4:	mov	x0, x19
1004a83c8:	sub	sp, x29, #0x50
1004a83cc:	ldp	x29, x30, [sp, #0x50]
1004a83d0:	ldp	x20, x19, [sp, #0x40]
1004a83d4:	ldp	x22, x21, [sp, #0x30]
1004a83d8:	ldp	x24, x23, [sp, #0x20]
1004a83dc:	ldp	x26, x25, [sp, #0x10]
1004a83e0:	ldp	x28, x27, [sp], #0x60
1004a83e4:	ret
1004a83e8:	cmp	x8, #0x1
1004a83ec:	cset	w0, hi
1004a83f0:	mov	x1, x20
1004a83f4:	mov	w2, #0x1
1004a83f8:	mov	x3, x19
1004a83fc:	bl	0x100030d24
1004a8400:	mov	x19, x0
1004a8404:	b	0x1004a82dc
1004a8408:	cmp	x8, #0x1
1004a840c:	cset	w0, hi
1004a8410:	mov	x1, x20
1004a8414:	mov	w2, #0x1
1004a8418:	mov	x3, x19
1004a841c:	bl	0x100030d24
1004a8420:	mov	x19, x0
1004a8424:	b	0x1004a832c
1004a8428:	cmp	x8, #0x1
1004a842c:	cset	w0, hi
1004a8430:	mov	x1, x20
1004a8434:	mov	w2, #0x1
1004a8438:	mov	x3, x19
1004a843c:	bl	0x100030d24
1004a8440:	mov	x19, x0
1004a8444:	b	0x1004a83ac
1004a8448:	b	0x1004a8824
1004a844c:	b	0x1004a8c10
1004a8450:	b	0x1004a8d80
1004a8454:	sub	sp, sp, #0x30
1004a8458:	stp	x20, x19, [sp, #0x10]
1004a845c:	stp	x29, x30, [sp, #0x20]
1004a8460:	add	x29, sp, #0x20
1004a8464:	mov	w8, #0x5f74
1004a8468:	mov	x9, #-0x1e00000000000000
1004a846c:	stp	x8, x9, [sp]
1004a8470:	ldr	x8, [x0]
1004a8474:	ldr	x8, [x8, #0x698]
1004a8478:	mov	x20, x0
1004a847c:	blr	x8
1004a8480:	mov	x19, x1
1004a8484:	mov	x20, sp
1004a8488:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a848c:	mov	x0, x19
1004a8490:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8494:	ldp	x0, x1, [sp]
1004a8498:	ldp	x29, x30, [sp, #0x20]
1004a849c:	ldp	x20, x19, [sp, #0x10]
1004a84a0:	add	sp, sp, #0x30
1004a84a4:	ret
1004a84a8:	b	0x1004a9130
1004a84ac:	sub	sp, sp, #0x70
1004a84b0:	stp	x28, x27, [sp, #0x10]
1004a84b4:	stp	x26, x25, [sp, #0x20]
1004a84b8:	stp	x24, x23, [sp, #0x30]
1004a84bc:	stp	x22, x21, [sp, #0x40]
1004a84c0:	stp	x20, x19, [sp, #0x50]
1004a84c4:	stp	x29, x30, [sp, #0x60]
1004a84c8:	add	x29, sp, #0x60
1004a84cc:	mov	x20, x0
1004a84d0:	adrp	x26, 7806 ; 0x102326000
1004a84d4:	ldr	x0, [x26, #0xac8] ; Objc class ref: _OBJC_CLASS_$_NSMenuItem
1004a84d8:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004a84dc:	mov	x19, x0
1004a84e0:	mov	x0, #0x6241
1004a84e4:	movk	x0, #0x756f, lsl #16
1004a84e8:	movk	x0, #0x2074, lsl #32
1004a84ec:	movk	x0, #0x6874, lsl #48
1004a84f0:	mov	x1, #0x7369
1004a84f4:	movk	x1, #0x5420, lsl #16
1004a84f8:	movk	x1, #0x6261, lsl #32
1004a84fc:	movk	x1, #0xee00, lsl #48
1004a8500:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004a8504:	mov	x21, x0
1004a8508:	mov	x0, #0x0
1004a850c:	mov	x1, #-0x2000000000000000
1004a8510:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004a8514:	mov	x22, x0
1004a8518:	mov	x0, x19
1004a851c:	mov	x2, x21
1004a8520:	mov	x3, #0x0
1004a8524:	mov	x4, x22
1004a8528:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1004a852c:	mov	x19, x0
1004a8530:	mov	x0, x21
1004a8534:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8538:	mov	x0, x22
1004a853c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8540:	adrp	x8, 7806 ; 0x102326000
1004a8544:	ldr	x0, [x8, #0xac0] ; Objc class ref: _OBJC_CLASS_$_NSMenu
1004a8548:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004a854c:	bl	0x101ace2c0 ; selector init
1004a8550:	mov	x21, x0
1004a8554:	mov	w2, #0x0
1004a8558:	bl	0x101ad1c60 ; selector setAutoenablesItems:
1004a855c:	mov	x0, x20
1004a8560:	bl	0x1004a9130
1004a8564:	mov	x22, x0
1004a8568:	ldr	x27, [x0, #0x10]
1004a856c:	cbz	x27, 0x1004a85f8
1004a8570:	add	x28, x22, #0x28
1004a8574:	ldp	x23, x24, [x28, #-0x8]
1004a8578:	ldr	x0, [x26, #0xac8]
1004a857c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004a8580:	mov	x25, x0
1004a8584:	mov	x0, x23
1004a8588:	mov	x1, x24
1004a858c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004a8590:	mov	x23, x0
1004a8594:	mov	x0, #0x0
1004a8598:	mov	x1, #-0x2000000000000000
1004a859c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004a85a0:	mov	x24, x0
1004a85a4:	mov	x0, x25
1004a85a8:	mov	x2, x23
1004a85ac:	mov	x3, #0x0
1004a85b0:	mov	x4, x24
1004a85b4:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1004a85b8:	mov	x25, x0
1004a85bc:	mov	x0, x23
1004a85c0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a85c4:	mov	x0, x24
1004a85c8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a85cc:	mov	x0, x25
1004a85d0:	mov	w2, #0x0
1004a85d4:	bl	0x101ad2920 ; selector setEnabled:
1004a85d8:	mov	x0, x21
1004a85dc:	mov	x2, x25
1004a85e0:	bl	0x101acb2c0 ; selector addItem:
1004a85e4:	mov	x0, x25
1004a85e8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a85ec:	add	x28, x28, #0x10
1004a85f0:	subs	x27, x27, #0x1
1004a85f4:	b.ne	0x1004a8574
1004a85f8:	mov	x0, x22
1004a85fc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8600:	ldr	x0, [x26, #0xac8]
1004a8604:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004a8608:	bl	0x101ad1620 ; selector separatorItem
1004a860c:	mov	x29, x29
1004a8610:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a8614:	mov	x22, x0
1004a8618:	mov	x0, x21
1004a861c:	mov	x2, x22
1004a8620:	bl	0x101acb2c0 ; selector addItem:
1004a8624:	mov	x0, x22
1004a8628:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a862c:	adrp	x8, 7802 ; 0x102322000
1004a8630:	ldr	x22, [x8, #0x980] ; Objc selector ref: copy:
1004a8634:	ldr	x0, [x26, #0xac8]
1004a8638:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004a863c:	mov	x23, x0
1004a8640:	mov	x0, #0x6f43
1004a8644:	movk	x0, #0x7970, lsl #16
1004a8648:	movk	x0, #0x5420, lsl #32
1004a864c:	movk	x0, #0x6261, lsl #48
1004a8650:	mov	x1, #0x4920
1004a8654:	movk	x1, #0x44, lsl #16
1004a8658:	movk	x1, #0xeb00, lsl #48
1004a865c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004a8660:	mov	x24, x0
1004a8664:	mov	x0, #0x0
1004a8668:	mov	x1, #-0x2000000000000000
1004a866c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004a8670:	mov	x25, x0
1004a8674:	mov	x0, x23
1004a8678:	mov	x2, x24
1004a867c:	mov	x3, x22
1004a8680:	mov	x4, x25
1004a8684:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1004a8688:	mov	x22, x0
1004a868c:	mov	x0, x24
1004a8690:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8694:	mov	x0, x25
1004a8698:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a869c:	adrp	x8, 7924 ; 0x10239c000
1004a86a0:	ldr	x8, [x8, #0xf00]
1004a86a4:	cmn	x8, #0x1
1004a86a8:	b.ne	0x1004a8760
1004a86ac:	adrp	x8, 7924 ; 0x10239c000
1004a86b0:	ldr	x2, [x8, #0xf08]
1004a86b4:	mov	x0, x22
1004a86b8:	bl	0x101ad45e0 ; selector setTarget:
1004a86bc:	mov	w8, #0x5f74
1004a86c0:	mov	x9, #-0x1e00000000000000
1004a86c4:	stp	x8, x9, [sp]
1004a86c8:	ldr	x8, [x20]
1004a86cc:	ldr	x8, [x8, #0x698]
1004a86d0:	blr	x8
1004a86d4:	mov	x23, x1
1004a86d8:	mov	x20, sp
1004a86dc:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a86e0:	mov	x0, x23
1004a86e4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a86e8:	ldp	x0, x20, [sp]
1004a86ec:	mov	x1, x20
1004a86f0:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004a86f4:	mov	x23, x0
1004a86f8:	mov	x0, x20
1004a86fc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8700:	mov	x0, x22
1004a8704:	mov	x2, x23
1004a8708:	bl	0x101ad3d60 ; selector setRepresentedObject:
1004a870c:	mov	x0, x23
1004a8710:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8714:	mov	x0, x21
1004a8718:	mov	x2, x22
1004a871c:	bl	0x101acb2c0 ; selector addItem:
1004a8720:	mov	x0, x19
1004a8724:	mov	x2, x21
1004a8728:	bl	0x101ad44e0 ; selector setSubmenu:
1004a872c:	mov	x0, x21
1004a8730:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8734:	mov	x0, x22
1004a8738:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a873c:	mov	x0, x19
1004a8740:	ldp	x29, x30, [sp, #0x60]
1004a8744:	ldp	x20, x19, [sp, #0x50]
1004a8748:	ldp	x22, x21, [sp, #0x40]
1004a874c:	ldp	x24, x23, [sp, #0x30]
1004a8750:	ldp	x26, x25, [sp, #0x20]
1004a8754:	ldp	x28, x27, [sp, #0x10]
1004a8758:	add	sp, sp, #0x70
1004a875c:	ret
1004a8760:	adrp	x0, 7924 ; 0x10239c000
1004a8764:	add	x0, x0, #0xf00
1004a8768:	adrp	x1, 0 ; 0x1004a8000
1004a876c:	add	x1, x1, #0x778
1004a8770:	bl	0x101aca948 ; symbol stub for: _swift_once
1004a8774:	b	0x1004a86ac
1004a8778:	stp	x29, x30, [sp, #-0x10]!
1004a877c:	mov	x29, sp
1004a8780:	bl	0x1004a9598
1004a8784:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004a8788:	bl	0x101ace2c0 ; selector init
1004a878c:	adrp	x8, 7924 ; 0x10239c000
1004a8790:	str	x0, [x8, #0xf08]
1004a8794:	ldp	x29, x30, [sp], #0x10
1004a8798:	ret
1004a879c:	stp	x20, x19, [sp, #-0x20]!
1004a87a0:	stp	x29, x30, [sp, #0x10]
1004a87a4:	add	x29, sp, #0x10
1004a87a8:	mov	x19, x0
1004a87ac:	mov	x0, x2
1004a87b0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a87b4:	mov	x20, x0
1004a87b8:	mov	x0, x19
1004a87bc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a87c0:	mov	x19, x0
1004a87c4:	mov	x0, x20
1004a87c8:	bl	0x1004a95b8
1004a87cc:	mov	x0, x20
1004a87d0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a87d4:	mov	x0, x19
1004a87d8:	ldp	x29, x30, [sp, #0x10]
1004a87dc:	ldp	x20, x19, [sp], #0x20
1004a87e0:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004a87e4:	sub	sp, sp, #0x30
1004a87e8:	stp	x20, x19, [sp, #0x10]
1004a87ec:	stp	x29, x30, [sp, #0x20]
1004a87f0:	add	x29, sp, #0x20
1004a87f4:	mov	x19, x0
1004a87f8:	bl	0x101aca7f8 ; symbol stub for: _swift_getObjectType
1004a87fc:	stp	x19, x0, [sp]
1004a8800:	adrp	x8, 7802 ; 0x102322000
1004a8804:	ldr	x1, [x8, #0xf98] ; Objc selector ref: init
1004a8808:	mov	x0, sp
1004a880c:	bl	0x101ac9d0c ; Objc message: -[[x0 super] init]
1004a8810:	ldp	x29, x30, [sp, #0x20]
1004a8814:	ldp	x20, x19, [sp, #0x10]
1004a8818:	add	sp, sp, #0x30
1004a881c:	ret
1004a8820:	ret
1004a8824:	sub	sp, sp, #0xa0
1004a8828:	stp	x26, x25, [sp, #0x50]
1004a882c:	stp	x24, x23, [sp, #0x60]
1004a8830:	stp	x22, x21, [sp, #0x70]
1004a8834:	stp	x20, x19, [sp, #0x80]
1004a8838:	stp	x29, x30, [sp, #0x90]
1004a883c:	add	x29, sp, #0x90
1004a8840:	mov	x20, x0
1004a8844:	ldr	x8, [x0]
1004a8848:	ldr	x8, [x8, #0xbb0]
1004a884c:	blr	x8
1004a8850:	tbz	w0, #0x0, 0x1004a885c
1004a8854:	mov	w19, #0x1
1004a8858:	b	0x1004a8868
1004a885c:	ldr	x0, [x20, #0x10]
1004a8860:	bl	_otty_session_program_owns_keyboard
1004a8864:	mov	x19, x0
1004a8868:	ldr	x8, [x20]
1004a886c:	ldr	x8, [x8, #0x5c0]
1004a8870:	blr	x8
1004a8874:	cbz	x1, 0x1004a889c
1004a8878:	mov	w19, #0x1
1004a887c:	mov	x2, x19
1004a8880:	ldp	x29, x30, [sp, #0x90]
1004a8884:	ldp	x20, x19, [sp, #0x80]
1004a8888:	ldp	x22, x21, [sp, #0x70]
1004a888c:	ldp	x24, x23, [sp, #0x60]
1004a8890:	ldp	x26, x25, [sp, #0x50]
1004a8894:	add	sp, sp, #0xa0
1004a8898:	ret
1004a889c:	ldr	x8, [x20]
1004a88a0:	ldr	x8, [x8, #0x780]
1004a88a4:	blr	x8
1004a88a8:	cbz	x1, 0x1004a89c0
1004a88ac:	mov	x21, x1
1004a88b0:	and	x8, x0, #0xffffffffffff
1004a88b4:	ubfx	x9, x1, #56, #4
1004a88b8:	tst	x1, #0x2000000000000000
1004a88bc:	csel	x8, x8, x9, eq
1004a88c0:	cbz	x8, 0x1004a89b8
1004a88c4:	stp	x0, x21, [sp, #0x40]
1004a88c8:	mov	w8, #0xa
1004a88cc:	mov	x9, #-0x1f00000000000000
1004a88d0:	stp	x8, x9, [sp, #0x30]
1004a88d4:	mov	x8, #0xe220
1004a88d8:	movk	x8, #0x8e8f, lsl #16
1004a88dc:	movk	x8, #0x20, lsl #32
1004a88e0:	mov	x9, #-0x5b00000000000000
1004a88e4:	stp	x8, x9, [sp, #0x20]
1004a88e8:	bl	0x10002a718
1004a88ec:	adrp	x6, 7718 ; 0x1022ce000
1004a88f0:	ldr	x6, [x6, #0x38] ; literal pool symbol address: _$sSSN
1004a88f4:	stp	x0, x0, [sp, #0x10]
1004a88f8:	stp	x6, x0, [sp]
1004a88fc:	add	x0, sp, #0x30
1004a8900:	add	x1, sp, #0x20
1004a8904:	add	x20, sp, #0x40
1004a8908:	mov	x2, #0x0
1004a890c:	mov	x3, #0x0
1004a8910:	mov	x4, #0x0
1004a8914:	mov	w5, #0x1
1004a8918:	mov	x7, x6
1004a891c:	bl	0x101ac72a0 ; symbol stub for: _$sSy10FoundationE20replacingOccurrences2of4with7options5rangeSSqd___qd_0_So22NSStringCompareOptionsVSnySS5IndexVGSgtSyRd__SyRd_0_r0_lF
1004a8920:	mov	x20, x0
1004a8924:	mov	x22, x1
1004a8928:	bl	0x101ac6430 ; symbol stub for: _$sSS5countSivg
1004a892c:	cmp	x0, #0x3d
1004a8930:	b.lt	0x1004a8b8c
1004a8934:	mov	w0, #0x3b
1004a8938:	mov	x1, x20
1004a893c:	mov	x20, x22
1004a8940:	mov	x2, x22
1004a8944:	bl	0x100025388
1004a8948:	mov	x22, x0
1004a894c:	mov	x23, x1
1004a8950:	mov	x24, x2
1004a8954:	mov	x25, x3
1004a8958:	mov	x0, x20
1004a895c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8960:	mov	x0, x22
1004a8964:	mov	x1, x23
1004a8968:	mov	x2, x24
1004a896c:	mov	x3, x25
1004a8970:	bl	0x101ac6340 ; symbol stub for: _$sSS14_fromSubstringySSSshFZ
1004a8974:	mov	x20, x0
1004a8978:	mov	x22, x1
1004a897c:	mov	x0, x25
1004a8980:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8984:	stp	x20, x22, [sp, #0x40]
1004a8988:	mov	x0, x22
1004a898c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a8990:	add	x20, sp, #0x40
1004a8994:	mov	w0, #0x80e2
1004a8998:	movk	w0, #0xa6, lsl #16
1004a899c:	mov	x1, #-0x5d00000000000000
1004a89a0:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a89a4:	mov	x0, x22
1004a89a8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a89ac:	mov	x0, x21
1004a89b0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a89b4:	b	0x1004a8c08
1004a89b8:	mov	x0, x21
1004a89bc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a89c0:	ldr	x8, [x20]
1004a89c4:	ldr	x8, [x8, #0x488]
1004a89c8:	blr	x8
1004a89cc:	cbz	x1, 0x1004a8b08
1004a89d0:	bl	0x100054624
1004a89d4:	cbz	w19, 0x1004a8ba0
1004a89d8:	ldr	x8, [x20]
1004a89dc:	ldr	x22, [x8, #0x2d0]
1004a89e0:	blr	x22
1004a89e4:	mov	x19, x0
1004a89e8:	mov	x21, x1
1004a89ec:	mov	x0, x1
1004a89f0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a89f4:	and	x8, x19, #0xffffffffffff
1004a89f8:	ubfx	x9, x21, #56, #4
1004a89fc:	tst	x21, #0x2000000000000000
1004a8a00:	csel	x8, x8, x9, eq
1004a8a04:	cbz	x8, 0x1004a8bac
1004a8a08:	blr	x22
1004a8a0c:	mov	x19, x1
1004a8a10:	stp	x0, x1, [sp, #0x40]
1004a8a14:	mov	w8, #0xa
1004a8a18:	mov	x9, #-0x1f00000000000000
1004a8a1c:	stp	x8, x9, [sp, #0x30]
1004a8a20:	mov	x8, #0xe220
1004a8a24:	movk	x8, #0x8e8f, lsl #16
1004a8a28:	movk	x8, #0x20, lsl #32
1004a8a2c:	mov	x9, #-0x5b00000000000000
1004a8a30:	stp	x8, x9, [sp, #0x20]
1004a8a34:	bl	0x10002a718
1004a8a38:	adrp	x6, 7718 ; 0x1022ce000
1004a8a3c:	ldr	x6, [x6, #0x38] ; literal pool symbol address: _$sSSN
1004a8a40:	stp	x0, x0, [sp, #0x10]
1004a8a44:	stp	x6, x0, [sp]
1004a8a48:	add	x0, sp, #0x30
1004a8a4c:	add	x1, sp, #0x20
1004a8a50:	add	x20, sp, #0x40
1004a8a54:	mov	x2, #0x0
1004a8a58:	mov	x3, #0x0
1004a8a5c:	mov	x4, #0x0
1004a8a60:	mov	w5, #0x1
1004a8a64:	mov	x7, x6
1004a8a68:	bl	0x101ac72a0 ; symbol stub for: _$sSy10FoundationE20replacingOccurrences2of4with7options5rangeSSqd___qd_0_So22NSStringCompareOptionsVSnySS5IndexVGSgtSyRd__SyRd_0_r0_lF
1004a8a6c:	mov	x20, x0
1004a8a70:	mov	x21, x1
1004a8a74:	bl	0x101ac6430 ; symbol stub for: _$sSS5countSivg
1004a8a78:	cmp	x0, #0x3d
1004a8a7c:	b.lt	0x1004a8bbc
1004a8a80:	mov	w0, #0x3b
1004a8a84:	mov	x1, x20
1004a8a88:	mov	x20, x21
1004a8a8c:	mov	x2, x21
1004a8a90:	bl	0x100025388
1004a8a94:	mov	x21, x0
1004a8a98:	mov	x22, x1
1004a8a9c:	mov	x23, x2
1004a8aa0:	mov	x24, x3
1004a8aa4:	mov	x0, x20
1004a8aa8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8aac:	mov	x0, x21
1004a8ab0:	mov	x1, x22
1004a8ab4:	mov	x2, x23
1004a8ab8:	mov	x3, x24
1004a8abc:	bl	0x101ac6340 ; symbol stub for: _$sSS14_fromSubstringySSSshFZ
1004a8ac0:	mov	x20, x0
1004a8ac4:	mov	x21, x1
1004a8ac8:	mov	x0, x24
1004a8acc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8ad0:	stp	x20, x21, [sp, #0x40]
1004a8ad4:	mov	x0, x21
1004a8ad8:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a8adc:	add	x20, sp, #0x40
1004a8ae0:	mov	w0, #0x80e2
1004a8ae4:	movk	w0, #0xa6, lsl #16
1004a8ae8:	mov	x1, #-0x5d00000000000000
1004a8aec:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a8af0:	mov	x0, x21
1004a8af4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8af8:	mov	x0, x19
1004a8afc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8b00:	ldp	x0, x1, [sp, #0x40]
1004a8b04:	b	0x1004a8878
1004a8b08:	ldr	x0, [x20, #0x10]
1004a8b0c:	bl	_otty_session_foreground_pid_path
1004a8b10:	cbz	x0, 0x1004a8bd8
1004a8b14:	mov	x21, x0
1004a8b18:	bl	0x101ac64c0 ; symbol stub for: _$sSS7cStringSSSPys4Int8VG_tcfC
1004a8b1c:	mov	x22, x1
1004a8b20:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004a8b24:	mov	x23, x0
1004a8b28:	mov	x0, x22
1004a8b2c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8b30:	mov	x0, x23
1004a8b34:	bl	0x101acf280 ; selector lastPathComponent
1004a8b38:	mov	x29, x29
1004a8b3c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a8b40:	mov	x22, x0
1004a8b44:	mov	x0, x23
1004a8b48:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8b4c:	mov	x0, x22
1004a8b50:	bl	0x101ac625c ; symbol stub for: _$sSS10FoundationE36_unconditionallyBridgeFromObjectiveCySSSo8NSStringCSgFZ
1004a8b54:	mov	x23, x0
1004a8b58:	mov	x24, x1
1004a8b5c:	mov	x0, x22
1004a8b60:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8b64:	mov	x0, x21
1004a8b68:	bl	_otty_free_string
1004a8b6c:	mov	x1, x24
1004a8b70:	and	x8, x23, #0xffffffffffff
1004a8b74:	ubfx	x9, x24, #56, #4
1004a8b78:	tst	x24, #0x2000000000000000
1004a8b7c:	csel	x8, x8, x9, eq
1004a8b80:	cbz	x8, 0x1004a8bd0
1004a8b84:	mov	x0, x23
1004a8b88:	b	0x1004a887c
1004a8b8c:	mov	x0, x21
1004a8b90:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8b94:	mov	x1, x22
1004a8b98:	mov	x0, x20
1004a8b9c:	b	0x1004a887c
1004a8ba0:	mov	x0, #0x0
1004a8ba4:	mov	x1, #0x0
1004a8ba8:	b	0x1004a887c
1004a8bac:	mov	x0, #0x0
1004a8bb0:	mov	x1, #0x0
1004a8bb4:	mov	w19, #0x0
1004a8bb8:	b	0x1004a887c
1004a8bbc:	mov	x0, x19
1004a8bc0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8bc4:	mov	x1, x21
1004a8bc8:	mov	x0, x20
1004a8bcc:	b	0x1004a8878
1004a8bd0:	mov	x0, x1
1004a8bd4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8bd8:	ldr	x8, [x20]
1004a8bdc:	ldr	x8, [x8, #0x450]
1004a8be0:	blr	x8
1004a8be4:	stp	x0, x1, [sp, #0x40]
1004a8be8:	mov	x0, #0x2820
1004a8bec:	movk	x0, #0x6469, lsl #16
1004a8bf0:	movk	x0, #0x656c, lsl #32
1004a8bf4:	movk	x0, #0x29, lsl #48
1004a8bf8:	add	x20, sp, #0x40
1004a8bfc:	mov	x1, #-0x1900000000000000
1004a8c00:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a8c04:	mov	w19, #0x0
1004a8c08:	ldp	x0, x1, [sp, #0x40]
1004a8c0c:	b	0x1004a887c
1004a8c10:	sub	sp, sp, #0x50
1004a8c14:	stp	x24, x23, [sp, #0x10]
1004a8c18:	stp	x22, x21, [sp, #0x20]
1004a8c1c:	stp	x20, x19, [sp, #0x30]
1004a8c20:	stp	x29, x30, [sp, #0x40]
1004a8c24:	add	x29, sp, #0x40
1004a8c28:	mov	x20, x0
1004a8c2c:	adrp	x8, 7806 ; 0x102326000
1004a8c30:	ldr	x0, [x8, #0xad8] ; Objc class ref: _OBJC_CLASS_$_NSDateFormatter
1004a8c34:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004a8c38:	bl	0x101ace2c0 ; selector init
1004a8c3c:	mov	x19, x0
1004a8c40:	mov	w2, #0x2
1004a8c44:	bl	0x101ad25a0 ; selector setDateStyle:
1004a8c48:	mov	x0, x19
1004a8c4c:	mov	w2, #0x1
1004a8c50:	bl	0x101ad46e0 ; selector setTimeStyle:
1004a8c54:	mov	x0, x19
1004a8c58:	mov	w2, #0x1
1004a8c5c:	bl	0x101ad2760 ; selector setDoesRelativeDateFormatting:
1004a8c60:	bl	0x101ac4fa8 ; symbol stub for: _$s10Foundation4DateV21timeIntervalSince1970Sdvg
1004a8c64:	bl	0x1000653b8
1004a8c68:	mov	x21, x1
1004a8c6c:	and	x8, x0, #0xffffffffffff
1004a8c70:	ubfx	x9, x1, #56, #4
1004a8c74:	tst	x1, #0x2000000000000000
1004a8c78:	csel	x8, x8, x9, eq
1004a8c7c:	cbz	x8, 0x1004a8d10
1004a8c80:	mov	x22, x0
1004a8c84:	bl	0x101ac4f60 ; symbol stub for: _$s10Foundation4DateV19_bridgeToObjectiveCSo6NSDateCyF
1004a8c88:	mov	x20, x0
1004a8c8c:	mov	x0, x19
1004a8c90:	mov	x2, x20
1004a8c94:	bl	0x101ad5420 ; selector stringFromDate:
1004a8c98:	mov	x29, x29
1004a8c9c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a8ca0:	mov	x23, x0
1004a8ca4:	mov	x0, x20
1004a8ca8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8cac:	mov	x0, x23
1004a8cb0:	bl	0x101ac625c ; symbol stub for: _$sSS10FoundationE36_unconditionallyBridgeFromObjectiveCySSSo8NSStringCSgFZ
1004a8cb4:	mov	x20, x0
1004a8cb8:	mov	x24, x1
1004a8cbc:	mov	x0, x23
1004a8cc0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8cc4:	stp	x20, x24, [sp]
1004a8cc8:	mov	x20, sp
1004a8ccc:	mov	w0, #0x2820
1004a8cd0:	mov	x1, #-0x1e00000000000000
1004a8cd4:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a8cd8:	mov	x20, sp
1004a8cdc:	mov	x0, x22
1004a8ce0:	mov	x1, x21
1004a8ce4:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a8ce8:	mov	x0, x21
1004a8cec:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8cf0:	mov	x20, sp
1004a8cf4:	mov	w0, #0x29
1004a8cf8:	mov	x1, #-0x1f00000000000000
1004a8cfc:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a8d00:	mov	x0, x19
1004a8d04:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8d08:	ldp	x0, x1, [sp]
1004a8d0c:	b	0x1004a8d68
1004a8d10:	mov	x0, x21
1004a8d14:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8d18:	bl	0x101ac4f60 ; symbol stub for: _$s10Foundation4DateV19_bridgeToObjectiveCSo6NSDateCyF
1004a8d1c:	mov	x20, x0
1004a8d20:	mov	x0, x19
1004a8d24:	mov	x2, x20
1004a8d28:	bl	0x101ad5420 ; selector stringFromDate:
1004a8d2c:	mov	x29, x29
1004a8d30:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a8d34:	mov	x21, x0
1004a8d38:	mov	x0, x20
1004a8d3c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8d40:	mov	x0, x21
1004a8d44:	bl	0x101ac625c ; symbol stub for: _$sSS10FoundationE36_unconditionallyBridgeFromObjectiveCySSSo8NSStringCSgFZ
1004a8d48:	mov	x20, x0
1004a8d4c:	mov	x22, x1
1004a8d50:	mov	x0, x21
1004a8d54:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8d58:	mov	x0, x19
1004a8d5c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8d60:	mov	x0, x20
1004a8d64:	mov	x1, x22
1004a8d68:	ldp	x29, x30, [sp, #0x40]
1004a8d6c:	ldp	x20, x19, [sp, #0x30]
1004a8d70:	ldp	x22, x21, [sp, #0x20]
1004a8d74:	ldp	x24, x23, [sp, #0x10]
1004a8d78:	add	sp, sp, #0x50
1004a8d7c:	ret
1004a8d80:	stp	x26, x25, [sp, #-0x50]!
1004a8d84:	stp	x24, x23, [sp, #0x10]
1004a8d88:	stp	x22, x21, [sp, #0x20]
1004a8d8c:	stp	x20, x19, [sp, #0x30]
1004a8d90:	stp	x29, x30, [sp, #0x40]
1004a8d94:	add	x29, sp, #0x40
1004a8d98:	sub	sp, sp, #0x10
1004a8d9c:	mov	x20, x0
1004a8da0:	adrp	x0, 7867 ; 0x102363000
1004a8da4:	add	x0, x0, #0x770
1004a8da8:	adrp	x1, 5689 ; 0x101ae1000
1004a8dac:	add	x1, x1, #0xc50
1004a8db0:	bl	0x100003c4c
1004a8db4:	ldur	x8, [x0, #-0x8]
1004a8db8:	ldr	x9, [x8, #0x40]
1004a8dbc:	add	x8, x9, #0xf
1004a8dc0:	and	x8, x8, #0xfffffffffffffff0
1004a8dc4:	adrp	x16, 7715 ; 0x1022cb000
1004a8dc8:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004a8dcc:	blr	x16
1004a8dd0:	mov	x9, sp
1004a8dd4:	sub	x23, x9, x8
1004a8dd8:	mov	sp, x23
1004a8ddc:	mov	x0, #0x0
1004a8de0:	bl	0x1001e12dc
1004a8de4:	mov	x25, x0
1004a8de8:	ldur	x26, [x0, #-0x8]
1004a8dec:	ldr	x8, [x26, #0x40]
1004a8df0:	mov	x9, x8
1004a8df4:	adrp	x16, 7715 ; 0x1022cb000
1004a8df8:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004a8dfc:	blr	x16
1004a8e00:	mov	x9, sp
1004a8e04:	add	x8, x8, #0xf
1004a8e08:	and	x8, x8, #0xfffffffffffffff0
1004a8e0c:	sub	x22, x9, x8
1004a8e10:	mov	sp, x22
1004a8e14:	ldr	x8, [x20]
1004a8e18:	ldr	x8, [x8, #0x488]
1004a8e1c:	blr	x8
1004a8e20:	cbz	x1, 0x1004a8eb0
1004a8e24:	mov	x19, x0
1004a8e28:	mov	x24, x1
1004a8e2c:	mov	x21, x3
1004a8e30:	mov	x0, #0x616d
1004a8e34:	movk	x0, #0x6f63, lsl #16
1004a8e38:	movk	x0, #0x73, lsl #32
1004a8e3c:	cmp	x2, x0
1004a8e40:	mov	x8, #-0x1b00000000000000
1004a8e44:	ccmp	x3, x8, #0x0, eq
1004a8e48:	b.eq	0x1004a8e64
1004a8e4c:	mov	x1, #-0x1b00000000000000
1004a8e50:	mov	x20, x2
1004a8e54:	mov	x3, x21
1004a8e58:	mov	w4, #0x0
1004a8e5c:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004a8e60:	tbz	w0, #0x0, 0x1004a8f40
1004a8e64:	mov	x22, #0x616d
1004a8e68:	movk	x22, #0x4f63, lsl #16
1004a8e6c:	movk	x22, #0x53, lsl #32
1004a8e70:	mov	x0, x21
1004a8e74:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8e78:	mov	x21, #-0x1b00000000000000
1004a8e7c:	stp	x19, x24, [x29, #-0x50]
1004a8e80:	sub	x20, x29, #0x50
1004a8e84:	mov	w0, #0xc220
1004a8e88:	movk	w0, #0x20b7, lsl #16
1004a8e8c:	mov	x1, #-0x5c00000000000000
1004a8e90:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a8e94:	mov	x0, x22
1004a8e98:	mov	x1, x21
1004a8e9c:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a8ea0:	mov	x0, x21
1004a8ea4:	mov	w1, #0x2
1004a8ea8:	bl	0x101aca618 ; symbol stub for: _swift_bridgeObjectRelease_n
1004a8eac:	b	0x1004a8fc8
1004a8eb0:	ldr	x8, [x20]
1004a8eb4:	ldr	x9, [x8, #0x458]
1004a8eb8:	mov	x8, x23
1004a8ebc:	blr	x9
1004a8ec0:	ldr	x8, [x26, #0x30]
1004a8ec4:	mov	x0, x23
1004a8ec8:	mov	w1, #0x1
1004a8ecc:	mov	x2, x25
1004a8ed0:	blr	x8
1004a8ed4:	cmp	w0, #0x1
1004a8ed8:	b.ne	0x1004a8f20
1004a8edc:	adrp	x1, 7867 ; 0x102363000
1004a8ee0:	add	x1, x1, #0x770
1004a8ee4:	adrp	x2, 5689 ; 0x101ae1000
1004a8ee8:	add	x2, x2, #0xc50
1004a8eec:	mov	x0, x23
1004a8ef0:	bl	0x10002d870
1004a8ef4:	mov	x0, #0x0
1004a8ef8:	mov	x1, #0x0
1004a8efc:	bl	0x101ac9490 ; symbol stub for: _SCDynamicStoreCopyComputerName
1004a8f00:	cbz	x0, 0x1004a8f90
1004a8f04:	mov	x21, x0
1004a8f08:	bl	0x101ac625c ; symbol stub for: _$sSS10FoundationE36_unconditionallyBridgeFromObjectiveCySSSo8NSStringCSgFZ
1004a8f0c:	mov	x20, x0
1004a8f10:	mov	x19, x1
1004a8f14:	mov	x0, x21
1004a8f18:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a8f1c:	b	0x1004a8fa4
1004a8f20:	mov	x0, x23
1004a8f24:	mov	x1, x22
1004a8f28:	bl	0x1001217e0
1004a8f2c:	ldr	x20, [x22, #0x40]
1004a8f30:	cbz	x20, 0x1004a8fe8
1004a8f34:	ldr	x21, [x22, #0x38]
1004a8f38:	mov	x23, x20
1004a8f3c:	b	0x1004a8ff4
1004a8f40:	mov	x22, #0x6957
1004a8f44:	movk	x22, #0x646e, lsl #16
1004a8f48:	movk	x22, #0x776f, lsl #32
1004a8f4c:	movk	x22, #0x73, lsl #48
1004a8f50:	orr	x8, x22, #0x20
1004a8f54:	cmp	x20, x8
1004a8f58:	mov	x8, #-0x1900000000000000
1004a8f5c:	ccmp	x21, x8, #0x0, eq
1004a8f60:	b.eq	0x1004a8f80
1004a8f64:	mov	x2, x20
1004a8f68:	add	x0, x22, #0x20
1004a8f6c:	mov	x1, #-0x1900000000000000
1004a8f70:	mov	x3, x21
1004a8f74:	mov	w4, #0x0
1004a8f78:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004a8f7c:	tbz	w0, #0x0, 0x1004a908c
1004a8f80:	mov	x0, x21
1004a8f84:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a8f88:	mov	x21, #-0x1900000000000000
1004a8f8c:	b	0x1004a8e7c
1004a8f90:	mov	x19, #-0x1800000000000000
1004a8f94:	mov	x20, #0x6854
1004a8f98:	movk	x20, #0x7369, lsl #16
1004a8f9c:	movk	x20, #0x4d20, lsl #32
1004a8fa0:	movk	x20, #0x6361, lsl #48
1004a8fa4:	stp	x20, x19, [x29, #-0x50]
1004a8fa8:	mov	x0, #0xc220
1004a8fac:	movk	x0, #0x20b7, lsl #16
1004a8fb0:	movk	x0, #0x616d, lsl #32
1004a8fb4:	movk	x0, #0x4f63, lsl #48
1004a8fb8:	sub	x20, x29, #0x50
1004a8fbc:	mov	x1, #0x53
1004a8fc0:	movk	x1, #0xa900, lsl #48
1004a8fc4:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a8fc8:	ldp	x0, x1, [x29, #-0x50]
1004a8fcc:	sub	sp, x29, #0x40
1004a8fd0:	ldp	x29, x30, [sp, #0x40]
1004a8fd4:	ldp	x20, x19, [sp, #0x30]
1004a8fd8:	ldp	x22, x21, [sp, #0x20]
1004a8fdc:	ldp	x24, x23, [sp, #0x10]
1004a8fe0:	ldp	x26, x25, [sp], #0x50
1004a8fe4:	ret
1004a8fe8:	ldp	x21, x23, [x22, #0x10]
1004a8fec:	mov	x0, x23
1004a8ff0:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a8ff4:	mov	x19, #0xc220
1004a8ff8:	movk	x19, #0x20b7, lsl #16
1004a8ffc:	movk	x19, #0x5353, lsl #32
1004a9000:	movk	x19, #0x48, lsl #48
1004a9004:	ldp	x8, x24, [x22]
1004a9008:	and	x9, x8, #0xffffffffffff
1004a900c:	ubfx	x10, x24, #56, #4
1004a9010:	tst	x24, #0x2000000000000000
1004a9014:	csel	x9, x9, x10, eq
1004a9018:	cbz	x9, 0x1004a9058
1004a901c:	stp	x8, x24, [x29, #-0x50]
1004a9020:	mov	x0, x20
1004a9024:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a9028:	mov	x0, x24
1004a902c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a9030:	sub	x20, x29, #0x50
1004a9034:	mov	w0, #0x40
1004a9038:	mov	x1, #-0x1f00000000000000
1004a903c:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a9040:	mov	x0, x21
1004a9044:	mov	x1, x23
1004a9048:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a904c:	mov	x0, x23
1004a9050:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a9054:	b	0x1004a9068
1004a9058:	stp	x21, x23, [x29, #-0x50]
1004a905c:	mov	x0, x20
1004a9060:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a9064:	sub	x20, x29, #0x50
1004a9068:	mov	x0, x19
1004a906c:	mov	x1, #-0x5900000000000000
1004a9070:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a9074:	ldp	x19, x20, [x29, #-0x50]
1004a9078:	mov	x0, x22
1004a907c:	bl	0x1001e00c4
1004a9080:	mov	x0, x19
1004a9084:	mov	x1, x20
1004a9088:	b	0x1004a8fcc
1004a908c:	mov	x22, #0x694c
1004a9090:	movk	x22, #0x756e, lsl #16
1004a9094:	movk	x22, #0x78, lsl #32
1004a9098:	orr	x8, x22, #0x20
1004a909c:	mov	x2, x20
1004a90a0:	cmp	x20, x8
1004a90a4:	b.ne	0x1004a90b4
1004a90a8:	mov	x8, #-0x1b00000000000000
1004a90ac:	cmp	x21, x8
1004a90b0:	b.eq	0x1004a8e70
1004a90b4:	add	x0, x22, #0x20
1004a90b8:	mov	x1, #-0x1b00000000000000
1004a90bc:	mov	x3, x21
1004a90c0:	mov	w4, #0x0
1004a90c4:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004a90c8:	tbnz	w0, #0x0, 0x1004a8e70
1004a90cc:	mov	w22, #0x4f69
1004a90d0:	movk	w22, #0x53, lsl #16
1004a90d4:	mov	w8, #0x2000
1004a90d8:	movk	w8, #0x20, lsl #16
1004a90dc:	orr	x8, x22, x8
1004a90e0:	mov	x2, x20
1004a90e4:	cmp	x20, x8
1004a90e8:	b.ne	0x1004a90f8
1004a90ec:	mov	x8, #-0x1d00000000000000
1004a90f0:	cmp	x21, x8
1004a90f4:	b.eq	0x1004a9110
1004a90f8:	add	x0, x22, #0x202, lsl #12
1004a90fc:	mov	x1, #-0x1d00000000000000
1004a9100:	mov	x3, x21
1004a9104:	mov	w4, #0x0
1004a9108:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004a910c:	tbz	w0, #0x0, 0x1004a9120
1004a9110:	mov	x0, x21
1004a9114:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a9118:	mov	x21, #-0x1d00000000000000
1004a911c:	b	0x1004a8e7c
1004a9120:	mov	x0, x21
1004a9124:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004a9128:	mov	x22, x20
1004a912c:	b	0x1004a8e7c
1004a9130:	stp	x28, x27, [sp, #-0x60]!
1004a9134:	stp	x26, x25, [sp, #0x10]
1004a9138:	stp	x24, x23, [sp, #0x20]
1004a913c:	stp	x22, x21, [sp, #0x30]
1004a9140:	stp	x20, x19, [sp, #0x40]
1004a9144:	stp	x29, x30, [sp, #0x50]
1004a9148:	add	x29, sp, #0x50
1004a914c:	sub	sp, sp, #0x20
1004a9150:	mov	x23, x0
1004a9154:	mov	x0, #0x0
1004a9158:	bl	0x101ac4fd8 ; symbol stub for: _$s10Foundation4DateVMa
1004a915c:	mov	x21, x0
1004a9160:	ldur	x28, [x0, #-0x8]
1004a9164:	ldr	x8, [x28, #0x40]
1004a9168:	mov	x9, x8
1004a916c:	adrp	x16, 7714 ; 0x1022cb000
1004a9170:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004a9174:	blr	x16
1004a9178:	mov	x9, sp
1004a917c:	add	x8, x8, #0xf
1004a9180:	and	x8, x8, #0xfffffffffffffff0
1004a9184:	sub	x22, x9, x8
1004a9188:	mov	sp, x22
1004a918c:	adrp	x0, 7832 ; 0x102341000
1004a9190:	add	x0, x0, #0x6d0
1004a9194:	adrp	x1, 5688 ; 0x101ae1000
1004a9198:	add	x1, x1, #0x7e0
1004a919c:	bl	0x100003c4c
1004a91a0:	mov	w1, #0x30
1004a91a4:	mov	w2, #0x7
1004a91a8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004a91ac:	mov	x19, x0
1004a91b0:	adrp	x8, 5688 ; 0x101ae1000
1004a91b4:	ldr	q0, [x8, #0x130]
1004a91b8:	str	q0, [x0, #0x10]
1004a91bc:	mov	x8, #0x6154
1004a91c0:	movk	x8, #0x2062, lsl #16
1004a91c4:	movk	x8, #0x4449, lsl #32
1004a91c8:	movk	x8, #0x203a, lsl #48
1004a91cc:	mov	x9, #-0x1800000000000000
1004a91d0:	stp	x8, x9, [x29, #-0x60]
1004a91d4:	mov	w8, #0x5f74
1004a91d8:	mov	x9, #-0x1e00000000000000
1004a91dc:	stp	x8, x9, [x29, #-0x70]
1004a91e0:	ldr	x8, [x23]
1004a91e4:	ldr	x8, [x8, #0x698]
1004a91e8:	mov	x20, x23
1004a91ec:	blr	x8
1004a91f0:	mov	x24, x1
1004a91f4:	sub	x20, x29, #0x70
1004a91f8:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a91fc:	mov	x0, x24
1004a9200:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a9204:	ldp	x0, x24, [x29, #-0x70]
1004a9208:	sub	x20, x29, #0x60
1004a920c:	mov	x1, x24
1004a9210:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a9214:	mov	x0, x24
1004a9218:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a921c:	ldp	x8, x9, [x29, #-0x60]
1004a9220:	stp	x8, x9, [x19, #0x20]
1004a9224:	ldr	x24, [x23, #0x18]
1004a9228:	ldr	x8, [x24]
1004a922c:	ldr	x8, [x8, #0x78]
1004a9230:	mov	x20, x24
1004a9234:	blr	x8
1004a9238:	mov	x25, x0
1004a923c:	ldr	x8, [x0]
1004a9240:	ldr	x8, [x8, #0x108]
1004a9244:	mov	x20, x0
1004a9248:	blr	x8
1004a924c:	mov	x20, x0
1004a9250:	mov	x0, x25
1004a9254:	bl	0x101aca960 ; symbol stub for: _swift_release
1004a9258:	cmp	x20, #0x2
1004a925c:	b.lt	0x1004a92d0
1004a9260:	mov	x8, #0x6150
1004a9264:	movk	x8, #0x656e, lsl #16
1004a9268:	movk	x8, #0x3a73, lsl #32
1004a926c:	movk	x8, #0x20, lsl #48
1004a9270:	mov	x9, #-0x1900000000000000
1004a9274:	stp	x8, x9, [x29, #-0x60]
1004a9278:	stur	x20, [x29, #-0x70]
1004a927c:	adrp	x0, 7717 ; 0x1022ce000
1004a9280:	ldr	x0, [x0, #0x370] ; literal pool symbol address: _$sSiN
1004a9284:	adrp	x1, 7717 ; 0x1022ce000
1004a9288:	ldr	x1, [x1, #0x3c8] ; literal pool symbol address: _$sSis23CustomStringConvertiblesWP
1004a928c:	sub	x20, x29, #0x70
1004a9290:	bl	0x101ac7bb8 ; symbol stub for: _$ss23CustomStringConvertibleP11descriptionSSvgTj
1004a9294:	mov	x25, x1
1004a9298:	sub	x20, x29, #0x60
1004a929c:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a92a0:	mov	x0, x25
1004a92a4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a92a8:	ldp	x20, x25, [x29, #-0x60]
1004a92ac:	mov	w26, #0x2
1004a92b0:	mov	w0, #0x1
1004a92b4:	mov	w1, #0x2
1004a92b8:	mov	w2, #0x1
1004a92bc:	mov	x3, x19
1004a92c0:	bl	0x100030d24
1004a92c4:	mov	x19, x0
1004a92c8:	str	x26, [x0, #0x10]
1004a92cc:	stp	x20, x25, [x0, #0x30]
1004a92d0:	mov	x27, #0x704f
1004a92d4:	movk	x27, #0x6e65, lsl #16
1004a92d8:	movk	x27, #0x6465, lsl #32
1004a92dc:	movk	x27, #0x203a, lsl #48
1004a92e0:	ldr	x8, [x24]
1004a92e4:	ldr	x8, [x8, #0x128]
1004a92e8:	mov	x20, x24
1004a92ec:	blr	x8
1004a92f0:	cbz	x0, 0x1004a9470
1004a92f4:	mov	x24, x0
1004a92f8:	bl	0x1004a8824
1004a92fc:	cbz	x1, 0x1004a93a0
1004a9300:	mov	x26, x0
1004a9304:	mov	x25, x1
1004a9308:	mov	x8, #-0x2000000000000000
1004a930c:	stp	xzr, x8, [x29, #-0x60]
1004a9310:	tst	w2, #0x1
1004a9314:	mov	w8, #0x5554
1004a9318:	movk	w8, #0x49, lsl #16
1004a931c:	mov	x9, #0x6f43
1004a9320:	movk	x9, #0x6d6d, lsl #16
1004a9324:	movk	x9, #0x6e61, lsl #32
1004a9328:	movk	x9, #0x64, lsl #48
1004a932c:	csel	x0, x8, x9, ne
1004a9330:	mov	x8, #-0x1900000000000000
1004a9334:	mov	x9, #-0x1d00000000000000
1004a9338:	csel	x27, x9, x8, ne
1004a933c:	sub	x20, x29, #0x60
1004a9340:	mov	x1, x27
1004a9344:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a9348:	mov	x0, x27
1004a934c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a9350:	mov	w0, #0x203a
1004a9354:	mov	x1, #-0x1e00000000000000
1004a9358:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a935c:	mov	x0, x26
1004a9360:	mov	x1, x25
1004a9364:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a9368:	mov	x0, x25
1004a936c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a9370:	ldp	x25, x26, [x29, #-0x60]
1004a9374:	ldp	x27, x8, [x19, #0x10]
1004a9378:	add	x20, x27, #0x1
1004a937c:	cmp	x27, x8, lsr #1
1004a9380:	b.hs	0x1004a9548
1004a9384:	str	x20, [x19, #0x10]
1004a9388:	add	x8, x19, x27, lsl #4
1004a938c:	stp	x25, x26, [x8, #0x20]
1004a9390:	mov	x27, #0x704f
1004a9394:	movk	x27, #0x6e65, lsl #16
1004a9398:	movk	x27, #0x6465, lsl #32
1004a939c:	movk	x27, #0x203a, lsl #48
1004a93a0:	mov	x26, #-0x1800000000000000
1004a93a4:	stp	x27, x26, [x29, #-0x60]
1004a93a8:	ldr	x8, [x23]
1004a93ac:	ldr	x9, [x8, #0x1a0]
1004a93b0:	mov	x8, x22
1004a93b4:	mov	x20, x23
1004a93b8:	blr	x9
1004a93bc:	mov	x0, x22
1004a93c0:	bl	0x1004a8c10
1004a93c4:	mov	x23, x0
1004a93c8:	mov	x25, x1
1004a93cc:	ldr	x8, [x28, #0x8]
1004a93d0:	mov	x0, x22
1004a93d4:	mov	x1, x21
1004a93d8:	blr	x8
1004a93dc:	sub	x20, x29, #0x60
1004a93e0:	mov	x0, x23
1004a93e4:	mov	x1, x25
1004a93e8:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a93ec:	mov	x0, x25
1004a93f0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a93f4:	ldp	x21, x22, [x29, #-0x60]
1004a93f8:	ldp	x23, x8, [x19, #0x10]
1004a93fc:	add	x20, x23, #0x1
1004a9400:	cmp	x23, x8, lsr #1
1004a9404:	b.hs	0x1004a9508
1004a9408:	str	x20, [x19, #0x10]
1004a940c:	add	x8, x19, x23, lsl #4
1004a9410:	stp	x21, x22, [x8, #0x20]
1004a9414:	mov	x8, #0x6544
1004a9418:	movk	x8, #0x6976, lsl #16
1004a941c:	movk	x8, #0x6563, lsl #32
1004a9420:	movk	x8, #0x203a, lsl #48
1004a9424:	stp	x8, x26, [x29, #-0x60]
1004a9428:	mov	x0, x24
1004a942c:	bl	0x1004a8d80
1004a9430:	mov	x21, x1
1004a9434:	sub	x20, x29, #0x60
1004a9438:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a943c:	mov	x0, x21
1004a9440:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a9444:	ldp	x21, x22, [x29, #-0x60]
1004a9448:	ldp	x23, x8, [x19, #0x10]
1004a944c:	add	x20, x23, #0x1
1004a9450:	cmp	x23, x8, lsr #1
1004a9454:	b.hs	0x1004a9528
1004a9458:	str	x20, [x19, #0x10]
1004a945c:	add	x8, x19, x23, lsl #4
1004a9460:	stp	x21, x22, [x8, #0x20]
1004a9464:	mov	x0, x24
1004a9468:	bl	0x101aca960 ; symbol stub for: _swift_release
1004a946c:	b	0x1004a94e4
1004a9470:	mov	x8, #-0x1800000000000000
1004a9474:	stp	x27, x8, [x29, #-0x60]
1004a9478:	ldr	x8, [x23]
1004a947c:	ldr	x9, [x8, #0x1a0]
1004a9480:	mov	x8, x22
1004a9484:	mov	x20, x23
1004a9488:	blr	x9
1004a948c:	mov	x0, x22
1004a9490:	bl	0x1004a8c10
1004a9494:	mov	x23, x0
1004a9498:	mov	x24, x1
1004a949c:	ldr	x8, [x28, #0x8]
1004a94a0:	mov	x0, x22
1004a94a4:	mov	x1, x21
1004a94a8:	blr	x8
1004a94ac:	sub	x20, x29, #0x60
1004a94b0:	mov	x0, x23
1004a94b4:	mov	x1, x24
1004a94b8:	bl	0x101ac649c ; symbol stub for: _$sSS6appendyySSF
1004a94bc:	mov	x0, x24
1004a94c0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a94c4:	ldp	x21, x22, [x29, #-0x60]
1004a94c8:	ldp	x23, x8, [x19, #0x10]
1004a94cc:	add	x20, x23, #0x1
1004a94d0:	cmp	x23, x8, lsr #1
1004a94d4:	b.hs	0x1004a9568
1004a94d8:	str	x20, [x19, #0x10]
1004a94dc:	add	x8, x19, x23, lsl #4
1004a94e0:	stp	x21, x22, [x8, #0x20]
1004a94e4:	mov	x0, x19
1004a94e8:	sub	sp, x29, #0x50
1004a94ec:	ldp	x29, x30, [sp, #0x50]
1004a94f0:	ldp	x20, x19, [sp, #0x40]
1004a94f4:	ldp	x22, x21, [sp, #0x30]
1004a94f8:	ldp	x24, x23, [sp, #0x20]
1004a94fc:	ldp	x26, x25, [sp, #0x10]
1004a9500:	ldp	x28, x27, [sp], #0x60
1004a9504:	ret
1004a9508:	cmp	x8, #0x1
1004a950c:	cset	w0, hi
1004a9510:	mov	x1, x20
1004a9514:	mov	w2, #0x1
1004a9518:	mov	x3, x19
1004a951c:	bl	0x100030d24
1004a9520:	mov	x19, x0
1004a9524:	b	0x1004a9408
1004a9528:	cmp	x8, #0x1
1004a952c:	cset	w0, hi
1004a9530:	mov	x1, x20
1004a9534:	mov	w2, #0x1
1004a9538:	mov	x3, x19
1004a953c:	bl	0x100030d24
1004a9540:	mov	x19, x0
1004a9544:	b	0x1004a9458
1004a9548:	cmp	x8, #0x1
1004a954c:	cset	w0, hi
1004a9550:	mov	x1, x20
1004a9554:	mov	w2, #0x1
1004a9558:	mov	x3, x19
1004a955c:	bl	0x100030d24
1004a9560:	mov	x19, x0
1004a9564:	b	0x1004a9384
1004a9568:	cmp	x8, #0x1
1004a956c:	cset	w0, hi
1004a9570:	mov	x1, x20
1004a9574:	mov	w2, #0x1
1004a9578:	mov	x3, x19
1004a957c:	bl	0x100030d24
1004a9580:	mov	x19, x0
1004a9584:	b	0x1004a94d8
1004a9588:	adrp	x0, 7473 ; 0x1021da000
1004a958c:	add	x0, x0, #0x688
1004a9590:	mov	x1, #0x0
1004a9594:	ret
1004a9598:	stp	x29, x30, [sp, #-0x10]!
1004a959c:	mov	x29, sp
1004a95a0:	adrp	x0, 7815 ; 0x102330000
1004a95a4:	add	x0, x0, #0xd48
1004a95a8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004a95ac:	mov	x1, #0x0
1004a95b0:	ldp	x29, x30, [sp], #0x10
1004a95b4:	ret
1004a95b8:	sub	sp, sp, #0x80
1004a95bc:	stp	x22, x21, [sp, #0x50]
1004a95c0:	stp	x20, x19, [sp, #0x60]
1004a95c4:	stp	x29, x30, [sp, #0x70]
1004a95c8:	add	x29, sp, #0x70
1004a95cc:	bl	0x101ad0d60 ; selector representedObject
1004a95d0:	mov	x29, x29
1004a95d4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a95d8:	cbz	x0, 0x1004a95f4
1004a95dc:	add	x8, sp, #0x10
1004a95e0:	mov	x19, x0
1004a95e4:	bl	0x101ac7390 ; symbol stub for: _$ss018_bridgeAnyObjectToB0yypyXlSgF
1004a95e8:	mov	x0, x19
1004a95ec:	bl	0x101acaa68 ; symbol stub for: _swift_unknownObjectRelease
1004a95f0:	b	0x1004a95fc
1004a95f4:	movi.2d	v0, #0000000000000000
1004a95f8:	stp	q0, q0, [sp, #0x10]
1004a95fc:	ldp	q1, q0, [sp, #0x10]
1004a9600:	stp	q1, q0, [sp, #0x30]
1004a9604:	ldr	x8, [sp, #0x48]
1004a9608:	cbz	x8, 0x1004a9698
1004a960c:	adrp	x8, 7718 ; 0x1022cf000
1004a9610:	ldr	x8, [x8, #0x490] ; literal pool symbol address: _$sypN
1004a9614:	adrp	x3, 7717 ; 0x1022ce000
1004a9618:	ldr	x3, [x3, #0x38] ; literal pool symbol address: _$sSSN
1004a961c:	mov	x0, sp
1004a9620:	add	x1, sp, #0x30
1004a9624:	add	x2, x8, #0x8
1004a9628:	mov	w4, #0x6
1004a962c:	bl	0x101aca6f0 ; symbol stub for: _swift_dynamicCast
1004a9630:	tbz	w0, #0x0, 0x1004a96b0
1004a9634:	adrp	x22, 7713 ; 0x1022ca000
1004a9638:	ldr	x22, [x22, #0x558] ; literal pool symbol address: _NSApp
1004a963c:	ldr	x0, [x22]
1004a9640:	cbz	x0, 0x1004a96c4
1004a9644:	ldp	x20, x19, [sp]
1004a9648:	bl	0x101acf200 ; selector keyWindow
1004a964c:	mov	x29, x29
1004a9650:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a9654:	mov	x21, x0
1004a9658:	cbnz	x0, 0x1004a9674
1004a965c:	ldr	x0, [x22]
1004a9660:	cbz	x0, 0x1004a96c8
1004a9664:	bl	0x101acf6c0 ; selector mainWindow
1004a9668:	mov	x29, x29
1004a966c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004a9670:	mov	x21, x0
1004a9674:	mov	x0, x20
1004a9678:	mov	x1, x19
1004a967c:	mov	x2, x21
1004a9680:	bl	0x1005ffef8
1004a9684:	mov	x0, x19
1004a9688:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a968c:	mov	x0, x21
1004a9690:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a9694:	b	0x1004a96b0
1004a9698:	adrp	x1, 7831 ; 0x102340000
1004a969c:	add	x1, x1, #0xc30
1004a96a0:	adrp	x2, 5688 ; 0x101ae1000
1004a96a4:	add	x2, x2, #0x100
1004a96a8:	add	x0, sp, #0x30
1004a96ac:	bl	0x10002d870
1004a96b0:	ldp	x29, x30, [sp, #0x70]
1004a96b4:	ldp	x20, x19, [sp, #0x60]
1004a96b8:	ldp	x22, x21, [sp, #0x50]
1004a96bc:	add	sp, sp, #0x80
1004a96c0:	ret
1004a96c4:	brk	#0x1
1004a96c8:	brk	#0x1
1004a96cc:	adrp	x0, 7473 ; 0x1021da000
1004a96d0:	add	x0, x0, #0x698
1004a96d4:	ret
1004a96d8:	adrp	x8, 6447 ; 0x101dd8000
1004a96dc:	add	x8, x8, #0x90 ; literal pool for: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"><path fill=\"black\" d=\"M7.83 11H5v2h2.83L10 15.17v-3.76l-1.29-1.29z\" opacity=\".15\"/><path fill=\"black\" d=\"M4.34 2.93L2.93 4.34L7.29 8.7L7 9H3v6h4l5 5v-6.59l4.18 4.18c-.65.49-1.38.88-2.18 1.11v2.06a8.94 8.94 0 0 0 3.61-1.75l2.05 2.05l1.41-1.41zM10 15.17L7.83 13H5v-2h2.83l.88-.88L10 11.41zM19 12c0 .82-.15 1.61-.41 2.34l1.53 1.53c.56-1.17.88-2.48.88-3.87c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71m-7-8l-1.88 1.88L12 7.76zm4.5 8A4.5 4.5 0 0 0 14 7.97v1.79l2.48 2.48c.01-.08.02-.16.02-.24\"/></svg>"
1004a96e0:	sub	x8, x8, #0x20
1004a96e4:	orr	x1, x8, #0x8000000000000000
1004a96e8:	mov	x0, #0x249
1004a96ec:	movk	x0, #0xd000, lsl #48
1004a96f0:	ret
1004a96f4:	adrp	x0, 7473 ; 0x1021da000
1004a96f8:	add	x0, x0, #0x6a8
1004a96fc:	ret
1004a9700:	adrp	x8, 6447 ; 0x101dd8000
1004a9704:	add	x8, x8, #0x2e0 ; literal pool for: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"><path fill=\"black\" d=\"M7 13h2.83L12 15.17V8.83L9.83 11H7z\" opacity=\".15\"/><path fill=\"black\" d=\"M16 7.97v8.05c1.48-.73 2.5-2.25 2.5-4.02A4.5 4.5 0 0 0 16 7.97M5 9v6h4l5 5V4L9 9zm7-.17v6.34L9.83 13H7v-2h2.83z\"/></svg>"
1004a9708:	sub	x8, x8, #0x20
1004a970c:	orr	x1, x8, #0x8000000000000000
1004a9710:	mov	x0, #0x12b
1004a9714:	movk	x0, #0xd000, lsl #48
1004a9718:	ret
1004a971c:	adrp	x0, 7473 ; 0x1021da000
1004a9720:	add	x0, x0, #0x6b8
1004a9724:	ret
1004a9728:	adrp	x8, 6447 ; 0x101dd8000
1004a972c:	add	x8, x8, #0x410 ; literal pool for: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"><path fill=\"black\" d=\"M5 13h2.83L10 15.17V8.83L7.83 11H5z\" opacity=\".15\"/><path fill=\"black\" d=\"M3 9v6h4l5 5V4L7 9zm7-.17v6.34L7.83 13H5v-2h2.83zm4-.86v8.05c1.48-.73 2.5-2.25 2.5-4.02A4.5 4.5 0 0 0 14 7.97m0-4.74v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77\"/></svg>"
1004a9730:	sub	x8, x8, #0x20
1004a9734:	orr	x1, x8, #0x8000000000000000
1004a9738:	mov	x0, #0x18b
1004a973c:	movk	x0, #0xd000, lsl #48
1004a9740:	ret
1004a9744:	adrp	x0, 7473 ; 0x1021da000
1004a9748:	add	x0, x0, #0x6c8
1004a974c:	ret
1004a9750:	adrp	x8, 6447 ; 0x101dd8000
1004a9754:	add	x8, x8, #0x5a0 ; literal pool for: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"><path fill=\"black\" d=\"M8 17h8v-.24L8.34 9.1C8.12 9.68 8 10.32 8 11zm4-10.5c-.19 0-.37.03-.55.06L16 11.1V11c0-2.48-1.51-4.5-4-4.5\" opacity=\".15\"/><path fill=\"black\" d=\"M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2m0-15.5c2.49 0 4 2.02 4 4.5v.1l2 2V11c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68c-.24.06-.47.15-.69.23l1.64 1.64c.18-.02.36-.05.55-.05M5.41 3.35L4 4.76l2.81 2.81C6.29 8.57 6 9.74 6 11v5l-2 2v1h14.24l1.74 1.74l1.41-1.41zM16 17H8v-6c0-.68.12-1.32.34-1.9L16 16.76z\"/></svg>"
1004a9758:	sub	x8, x8, #0x20
1004a975c:	orr	x1, x8, #0x8000000000000000
1004a9760:	mov	x0, #0x249
1004a9764:	movk	x0, #0xd000, lsl #48
1004a9768:	ret
1004a976c:	adrp	x0, 7473 ; 0x1021da000
1004a9770:	add	x0, x0, #0x6d8
1004a9774:	ret
1004a9778:	adrp	x8, 6447 ; 0x101dd8000
1004a977c:	add	x8, x8, #0x7f0 ; literal pool for: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"><path fill=\"black\" d=\"M12 6.5c-2.49 0-4 2.02-4 4.5v6h8v-6c0-2.48-1.51-4.5-4-4.5m2.5 3.3l-2.8 3.4h2.8V15h-5v-1.8l2.8-3.4H9.5V8h5z\" opacity=\".15\"/><path fill=\"black\" d=\"M9.5 9.8h2.8l-2.8 3.4V15h5v-1.8h-2.8l2.8-3.4V8h-5zM18 16v-5c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1zm-2 1H8v-6c0-2.48 1.51-4.5 4-4.5s4 2.02 4 4.5zm-4 5c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2\"/></svg>"
1004a9780:	sub	x8, x8, #0x20
1004a9784:	orr	x1, x8, #0x8000000000000000
1004a9788:	mov	x0, #0x1fd
1004a978c:	movk	x0, #0xd000, lsl #48
1004a9790:	ret
1004a9794:	adrp	x0, 7473 ; 0x1021da000
1004a9798:	add	x0, x0, #0x6e8
1004a979c:	ret
1004a97a0:	adrp	x8, 6447 ; 0x101dd8000
1004a97a4:	add	x8, x8, #0x9f0 ; literal pool for: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"><path fill=\"black\" d=\"M12 6c-2.76 0-5 2.24-5 5v7h10v-7c0-2.76-2.24-5-5-5m1 10h-2v-2h2zm0-4h-2V8h2z\" opacity=\".15\"/><path fill=\"black\" d=\"M12 23c1.1 0 1.99-.89 1.99-1.99h-3.98c0 1.1.89 1.99 1.99 1.99m7-6v-6c0-3.35-2.36-6.15-5.5-6.83V3c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v1.17C7.36 4.85 5 7.65 5 11v6l-2 2v1h18v-1zm-2 1H7v-7c0-2.76 2.24-5 5-5s5 2.24 5 5zM11 8h2v4h-2zm0 6h2v2h-2z\"/></svg>"
1004a97a8:	sub	x8, x8, #0x20
1004a97ac:	orr	x1, x8, #0x8000000000000000
1004a97b0:	mov	x0, #0x1d7
1004a97b4:	movk	x0, #0xd000, lsl #48
1004a97b8:	ret
1004a97bc:	adrp	x0, 7473 ; 0x1021da000
1004a97c0:	add	x0, x0, #0x6f8
1004a97c4:	ret
1004a97c8:	adrp	x8, 6447 ; 0x101dd8000
1004a97cc:	add	x8, x8, #0xbd0 ; literal pool for: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"><path fill=\"black\" d=\"M12 6.5c-2.49 0-4 2.02-4 4.5v6h8v-6c0-2.48-1.51-4.5-4-4.5\" opacity=\".15\"/><path fill=\"black\" d=\"M18 16v-5c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1zm-2 1H8v-6c0-2.48 1.51-4.5 4-4.5s4 2.02 4 4.5zm-4 5c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2\"/></svg>"
1004a97d0:	sub	x8, x8, #0x20
1004a97d4:	orr	x1, x8, #0x8000000000000000
1004a97d8:	mov	x0, #0x19a
1004a97dc:	movk	x0, #0xd000, lsl #48
1004a97e0:	ret
1004a97e4:	adrp	x0, 7473 ; 0x1021da000
1004a97e8:	add	x0, x0, #0x708
1004a97ec:	ret
1004a97f0:	adrp	x8, 6447 ; 0x101dd8000
1004a97f4:	add	x8, x8, #0xd70 ; literal pool for: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\"><path fill=\"black\" d=\"M8 15h6c1.1 0 2-.9 2-2V5H6v8c0 1.1.9 2 2 2\" opacity=\".15\"/><path fill=\"black\" d=\"M2 19h18v2H2zm2-6c0 2.21 1.79 4 4 4h6c2.21 0 4-1.79 4-4v-3h2c1.11 0 2-.89 2-2V5c0-1.11-.89-2-2-2H4zm14-8h2v3h-2zM6 5h10v8c0 1.1-.9 2-2 2H8c-1.1 0-2-.9-2-2z\"/></svg>"
1004a97f8:	sub	x8, x8, #0x20
1004a97fc:	orr	x1, x8, #0x8000000000000000
1004a9800:	mov	x0, #0x15e
1004a9804:	movk	x0, #0xd000, lsl #48
1004a9808:	ret
1004a980c:	stp	x24, x23, [sp, #-0x40]!
1004a9810:	stp	x22, x21, [sp, #0x10]
1004a9814:	stp	x20, x19, [sp, #0x20]
1004a9818:	stp	x29, x30, [sp, #0x30]
1004a981c:	add	x29, sp, #0x30
1004a9820:	sub	sp, sp, #0x10
1004a9824:	mov	x19, x1
1004a9828:	mov	x20, x0
1004a982c:	mov	x0, #0x0
1004a9830:	bl	0x101ac62ec ; symbol stub for: _$sSS10FoundationE8EncodingVMa
1004a9834:	mov	x21, x0
1004a9838:	ldur	x23, [x0, #-0x8]
1004a983c:	ldr	x8, [x23, #0x40]
1004a9840:	mov	x9, x8
1004a9844:	adrp	x16, 7714 ; 0x1022cb000
1004a9848:	ldr	x16, [x16, #0x398] ; literal pool symbol address: ___chkstk_darwin
1004a984c:	blr	x16
1004a9850:	mov	x9, sp
1004a9854:	add	x8, x8, #0xf
1004a9858:	and	x8, x8, #0xfffffffffffffff0
1004a985c:	sub	x22, x9, x8
1004a9860:	mov	sp, x22
1004a9864:	stp	x20, x19, [x29, #-0x40]
1004a9868:	mov	x8, x22
1004a986c:	bl	0x101ac62b0 ; symbol stub for: _$sSS10FoundationE8EncodingV4utf8ACvgZ
1004a9870:	bl	0x10002a718
1004a9874:	mov	x3, x0
1004a9878:	adrp	x2, 7717 ; 0x1022ce000
1004a987c:	ldr	x2, [x2, #0x38] ; literal pool symbol address: _$sSSN
1004a9880:	sub	x20, x29, #0x40
1004a9884:	mov	x0, x22
1004a9888:	mov	w1, #0x0
1004a988c:	bl	0x101ac72e8 ; symbol stub for: _$sSy10FoundationE4data5using20allowLossyConversionAA4DataVSgSSAAE8EncodingV_SbtF
1004a9890:	mov	x19, x0
1004a9894:	mov	x20, x1
1004a9898:	ldr	x8, [x23, #0x8]
1004a989c:	mov	x0, x22
1004a98a0:	mov	x1, x21
1004a98a4:	blr	x8
1004a98a8:	mov	x21, #0x0
1004a98ac:	lsr	x8, x20, #60
1004a98b0:	cmp	x8, #0xe
1004a98b4:	b.hi	0x1004a990c
1004a98b8:	adrp	x8, 7805 ; 0x102326000
1004a98bc:	ldr	x0, [x8, #0xb28] ; Objc class ref: _OBJC_CLASS_$_NSImage
1004a98c0:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004a98c4:	mov	x21, x0
1004a98c8:	mov	x0, x19
1004a98cc:	mov	x1, x20
1004a98d0:	bl	0x101ac4ec4 ; symbol stub for: _$s10Foundation4DataV19_bridgeToObjectiveCSo6NSDataCyF
1004a98d4:	mov	x22, x0
1004a98d8:	mov	x0, x21
1004a98dc:	mov	x2, x22
1004a98e0:	bl	0x101ace4c0 ; selector initWithData:
1004a98e4:	mov	x21, x0
1004a98e8:	mov	x0, x22
1004a98ec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a98f0:	cbz	x21, 0x1004a9900
1004a98f4:	mov	x0, x21
1004a98f8:	mov	w2, #0x1
1004a98fc:	bl	0x101ad4600 ; selector setTemplate:
1004a9900:	mov	x0, x19
1004a9904:	mov	x1, x20
1004a9908:	bl	0x10002d9f0
1004a990c:	mov	x0, x21
1004a9910:	sub	sp, x29, #0x30
1004a9914:	ldp	x29, x30, [sp, #0x30]
1004a9918:	ldp	x20, x19, [sp, #0x20]
1004a991c:	ldp	x22, x21, [sp, #0x10]
1004a9920:	ldp	x24, x23, [sp], #0x40
1004a9924:	ret
1004a9928:	adrp	x0, 7473 ; 0x1021da000
1004a992c:	add	x0, x0, #0x728
1004a9930:	mov	x1, #0x0
1004a9934:	ret
1004a9938:	adrp	x0, 5708 ; 0x101af5000
1004a993c:	add	x0, x0, #0xc80
1004a9940:	ret
1004a9944:	mov	x0, #0x5f5f
1004a9948:	movk	x0, #0x616c, lsl #16
1004a994c:	movk	x0, #0x6562, lsl #32
1004a9950:	movk	x0, #0x5f6c, lsl #48
1004a9954:	mov	x1, #0x5f
1004a9958:	movk	x1, #0xe900, lsl #48
1004a995c:	ret
1004a9960:	adrp	x0, 7923 ; 0x10239c000
1004a9964:	add	x0, x0, #0xf28
1004a9968:	mov	x1, #0x0
1004a996c:	b	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004a9970:	adrp	x0, 7984 ; 0x1023d9000
1004a9974:	add	x0, x0, #0xf78
1004a9978:	mov	x1, #0x0
1004a997c:	b	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004a9980:	adrp	x8, 7923 ; 0x10239c000
1004a9984:	ldr	x8, [x8, #0xf10]
1004a9988:	cmn	x8, #0x1
1004a998c:	b.ne	0x1004a999c
1004a9990:	adrp	x0, 7984 ; 0x1023d9000
1004a9994:	add	x0, x0, #0xf78
1004a9998:	ret
1004a999c:	stp	x29, x30, [sp, #-0x10]!
1004a99a0:	mov	x29, sp
1004a99a4:	adrp	x0, 7923 ; 0x10239c000
1004a99a8:	add	x0, x0, #0xf10
1004a99ac:	adrp	x1, 0 ; 0x1004a9000
1004a99b0:	add	x1, x1, #0x970
1004a99b4:	bl	0x101aca948 ; symbol stub for: _swift_once
1004a99b8:	ldp	x29, x30, [sp], #0x10
1004a99bc:	b	0x1004a9990
1004a99c0:	adrp	x0, 7923 ; 0x10239c000
1004a99c4:	add	x0, x0, #0xf10
1004a99c8:	adrp	x1, 7984 ; 0x1023d9000
1004a99cc:	add	x1, x1, #0xf78
1004a99d0:	adrp	x2, 0 ; 0x1004a9000
1004a99d4:	add	x2, x2, #0x970
1004a99d8:	b	0x1004a9ae8
1004a99dc:	adrp	x1, 7923 ; 0x10239c000
1004a99e0:	add	x1, x1, #0xf10
1004a99e4:	adrp	x2, 7984 ; 0x1023d9000
1004a99e8:	add	x2, x2, #0xf78
1004a99ec:	adrp	x3, 0 ; 0x1004a9000
1004a99f0:	add	x3, x3, #0x970
1004a99f4:	b	0x1004a9b5c
1004a99f8:	stp	x20, x19, [sp, #-0x20]!
1004a99fc:	stp	x29, x30, [sp, #0x10]
1004a9a00:	add	x29, sp, #0x10
1004a9a04:	mov	x19, x0
1004a9a08:	adrp	x8, 7923 ; 0x10239c000
1004a9a0c:	ldr	x8, [x8, #0xf10]
1004a9a10:	cmn	x8, #0x1
1004a9a14:	b.ne	0x1004a9a58
1004a9a18:	adrp	x20, 7984 ; 0x1023d9000
1004a9a1c:	add	x20, x20, #0xf78
1004a9a20:	mov	x0, x20
1004a9a24:	mov	x1, x19
1004a9a28:	mov	w2, #0x21
1004a9a2c:	mov	x3, #0x0
1004a9a30:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a9a34:	mov	x0, x20
1004a9a38:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004a9a3c:	str	x0, [x19, #0x18]!
1004a9a40:	adrp	x0, 0 ; 0x1004a9000
1004a9a44:	add	x0, x0, #0xa70
1004a9a48:	mov	x1, x19
1004a9a4c:	ldp	x29, x30, [sp, #0x10]
1004a9a50:	ldp	x20, x19, [sp], #0x20
1004a9a54:	ret
1004a9a58:	adrp	x0, 7923 ; 0x10239c000
1004a9a5c:	add	x0, x0, #0xf10
1004a9a60:	adrp	x1, 0 ; 0x1004a9000
1004a9a64:	add	x1, x1, #0x970
1004a9a68:	bl	0x101aca948 ; symbol stub for: _swift_once
1004a9a6c:	b	0x1004a9a18
1004a9a70:	adrp	x2, 7984 ; 0x1023d9000
1004a9a74:	add	x2, x2, #0xf78
1004a9a78:	b	0x1004a9c4c
1004a9a7c:	adrp	x0, 7984 ; 0x1023d9000
1004a9a80:	add	x0, x0, #0xf80
1004a9a84:	mov	x1, #0x0
1004a9a88:	b	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004a9a8c:	adrp	x8, 7923 ; 0x10239c000
1004a9a90:	ldr	x8, [x8, #0xf18]
1004a9a94:	cmn	x8, #0x1
1004a9a98:	b.ne	0x1004a9aa8
1004a9a9c:	adrp	x0, 7984 ; 0x1023d9000
1004a9aa0:	add	x0, x0, #0xf80
1004a9aa4:	ret
1004a9aa8:	stp	x29, x30, [sp, #-0x10]!
1004a9aac:	mov	x29, sp
1004a9ab0:	adrp	x0, 7923 ; 0x10239c000
1004a9ab4:	add	x0, x0, #0xf18
1004a9ab8:	adrp	x1, 0 ; 0x1004a9000
1004a9abc:	add	x1, x1, #0xa7c
1004a9ac0:	bl	0x101aca948 ; symbol stub for: _swift_once
1004a9ac4:	ldp	x29, x30, [sp], #0x10
1004a9ac8:	b	0x1004a9a9c
1004a9acc:	adrp	x0, 7923 ; 0x10239c000
1004a9ad0:	add	x0, x0, #0xf18
1004a9ad4:	adrp	x1, 7984 ; 0x1023d9000
1004a9ad8:	add	x1, x1, #0xf80
1004a9adc:	adrp	x2, 0 ; 0x1004a9000
1004a9ae0:	add	x2, x2, #0xa7c
1004a9ae4:	b	0x1004a9ae8
1004a9ae8:	sub	sp, sp, #0x40
1004a9aec:	stp	x20, x19, [sp, #0x20]
1004a9af0:	stp	x29, x30, [sp, #0x30]
1004a9af4:	add	x29, sp, #0x30
1004a9af8:	mov	x19, x1
1004a9afc:	ldr	x8, [x0]
1004a9b00:	cmn	x8, #0x1
1004a9b04:	b.ne	0x1004a9b34
1004a9b08:	add	x1, sp, #0x8
1004a9b0c:	mov	x0, x19
1004a9b10:	mov	x2, #0x0
1004a9b14:	mov	x3, #0x0
1004a9b18:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a9b1c:	mov	x0, x19
1004a9b20:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004a9b24:	ldp	x29, x30, [sp, #0x30]
1004a9b28:	ldp	x20, x19, [sp, #0x20]
1004a9b2c:	add	sp, sp, #0x40
1004a9b30:	ret
1004a9b34:	mov	x1, x2
1004a9b38:	bl	0x101aca948 ; symbol stub for: _swift_once
1004a9b3c:	b	0x1004a9b08
1004a9b40:	adrp	x1, 7923 ; 0x10239c000
1004a9b44:	add	x1, x1, #0xf18
1004a9b48:	adrp	x2, 7984 ; 0x1023d9000
1004a9b4c:	add	x2, x2, #0xf80
1004a9b50:	adrp	x3, 0 ; 0x1004a9000
1004a9b54:	add	x3, x3, #0xa7c
1004a9b58:	b	0x1004a9b5c
1004a9b5c:	sub	sp, sp, #0x40
1004a9b60:	stp	x20, x19, [sp, #0x20]
1004a9b64:	stp	x29, x30, [sp, #0x30]
1004a9b68:	add	x29, sp, #0x30
1004a9b6c:	mov	x20, x2
1004a9b70:	mov	x19, x0
1004a9b74:	ldr	x8, [x1]
1004a9b78:	cmn	x8, #0x1
1004a9b7c:	b.ne	0x1004a9bb8
1004a9b80:	add	x1, sp, #0x8
1004a9b84:	mov	x0, x20
1004a9b88:	mov	w2, #0x1
1004a9b8c:	mov	x3, #0x0
1004a9b90:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a9b94:	mov	x0, x20
1004a9b98:	mov	x1, x19
1004a9b9c:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004a9ba0:	mov	x0, x19
1004a9ba4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a9ba8:	ldp	x29, x30, [sp, #0x30]
1004a9bac:	ldp	x20, x19, [sp, #0x20]
1004a9bb0:	add	sp, sp, #0x40
1004a9bb4:	ret
1004a9bb8:	mov	x0, x1
1004a9bbc:	mov	x1, x3
1004a9bc0:	bl	0x101aca948 ; symbol stub for: _swift_once
1004a9bc4:	b	0x1004a9b80
1004a9bc8:	stp	x20, x19, [sp, #-0x20]!
1004a9bcc:	stp	x29, x30, [sp, #0x10]
1004a9bd0:	add	x29, sp, #0x10
1004a9bd4:	mov	x19, x0
1004a9bd8:	adrp	x8, 7923 ; 0x10239c000
1004a9bdc:	ldr	x8, [x8, #0xf18]
1004a9be0:	cmn	x8, #0x1
1004a9be4:	b.ne	0x1004a9c28
1004a9be8:	adrp	x20, 7984 ; 0x1023d9000
1004a9bec:	add	x20, x20, #0xf80
1004a9bf0:	mov	x0, x20
1004a9bf4:	mov	x1, x19
1004a9bf8:	mov	w2, #0x21
1004a9bfc:	mov	x3, #0x0
1004a9c00:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a9c04:	mov	x0, x20
1004a9c08:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004a9c0c:	str	x0, [x19, #0x18]!
1004a9c10:	adrp	x0, 0 ; 0x1004a9000
1004a9c14:	add	x0, x0, #0xc40
1004a9c18:	mov	x1, x19
1004a9c1c:	ldp	x29, x30, [sp, #0x10]
1004a9c20:	ldp	x20, x19, [sp], #0x20
1004a9c24:	ret
1004a9c28:	adrp	x0, 7923 ; 0x10239c000
1004a9c2c:	add	x0, x0, #0xf18
1004a9c30:	adrp	x1, 0 ; 0x1004a9000
1004a9c34:	add	x1, x1, #0xa7c
1004a9c38:	bl	0x101aca948 ; symbol stub for: _swift_once
1004a9c3c:	b	0x1004a9be8
1004a9c40:	adrp	x2, 7984 ; 0x1023d9000
1004a9c44:	add	x2, x2, #0xf80
1004a9c48:	b	0x1004a9c4c
1004a9c4c:	stp	x22, x21, [sp, #-0x30]!
1004a9c50:	stp	x20, x19, [sp, #0x10]
1004a9c54:	stp	x29, x30, [sp, #0x20]
1004a9c58:	add	x29, sp, #0x20
1004a9c5c:	mov	x21, x1
1004a9c60:	mov	x19, x0
1004a9c64:	mov	x8, x0
1004a9c68:	ldr	x20, [x8, #0x18]!
1004a9c6c:	mov	x0, x2
1004a9c70:	mov	x1, x20
1004a9c74:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004a9c78:	tbz	w21, #0x0, 0x1004a9c98
1004a9c7c:	mov	x0, x20
1004a9c80:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a9c84:	mov	x0, x19
1004a9c88:	ldp	x29, x30, [sp, #0x20]
1004a9c8c:	ldp	x20, x19, [sp, #0x10]
1004a9c90:	ldp	x22, x21, [sp], #0x30
1004a9c94:	b	0x101aca738 ; symbol stub for: _swift_endAccess
1004a9c98:	mov	x0, x19
1004a9c9c:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004a9ca0:	mov	x0, x20
1004a9ca4:	ldp	x29, x30, [sp, #0x20]
1004a9ca8:	ldp	x20, x19, [sp, #0x10]
1004a9cac:	ldp	x22, x21, [sp], #0x30
1004a9cb0:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004a9cb4:	adrp	x0, 7923 ; 0x10239c000
1004a9cb8:	add	x0, x0, #0xf38
1004a9cbc:	mov	x1, #0x0
1004a9cc0:	b	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004a9cc4:	b	0x1004acf1c
1004a9cc8:	b	0x1004ace00
1004a9ccc:	sub	sp, sp, #0x70
1004a9cd0:	stp	d9, d8, [sp, #0x30]
1004a9cd4:	stp	x22, x21, [sp, #0x40]
1004a9cd8:	stp	x20, x19, [sp, #0x50]
1004a9cdc:	stp	x29, x30, [sp, #0x60]
1004a9ce0:	add	x29, sp, #0x60
1004a9ce4:	mov.16b	v8, v1
1004a9ce8:	mov.16b	v9, v0
1004a9cec:	adrp	x8, 7923 ; 0x10239c000
1004a9cf0:	ldr	x8, [x8, #0xf20]
1004a9cf4:	cmn	x8, #0x1
1004a9cf8:	b.ne	0x1004a9ea4
1004a9cfc:	adrp	x0, 7923 ; 0x10239c000
1004a9d00:	add	x0, x0, #0xf28
1004a9d04:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004a9d08:	cbz	x0, 0x1004a9d80
1004a9d0c:	adrp	x8, 7851 ; 0x102354000
1004a9d10:	ldr	x8, [x8, #0xea0]
1004a9d14:	ldr	x8, [x0, x8]
1004a9d18:	cbz	x8, 0x1004a9d7c
1004a9d1c:	mov	x19, x0
1004a9d20:	mov	x0, x8
1004a9d24:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004a9d28:	mov	x20, x0
1004a9d2c:	bl	0x101acdcc0 ; selector frame
1004a9d30:	mov.16b	v4, v0
1004a9d34:	mov.16b	v5, v1
1004a9d38:	mov.16b	v6, v2
1004a9d3c:	mov.16b	v7, v3
1004a9d40:	mov.16b	v0, v9
1004a9d44:	mov.16b	v1, v8
1004a9d48:	mov.16b	v2, v4
1004a9d4c:	mov.16b	v3, v5
1004a9d50:	mov.16b	v4, v6
1004a9d54:	mov	w0, #0x0
1004a9d58:	mov.16b	v5, v7
1004a9d5c:	bl	0x101ac9424 ; symbol stub for: _NSMouseInRect
1004a9d60:	mov	x21, x0
1004a9d64:	mov	x0, x20
1004a9d68:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a9d6c:	mov	x0, x19
1004a9d70:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a9d74:	tbz	w21, #0x0, 0x1004a9d80
1004a9d78:	b	0x1004a9e80
1004a9d7c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a9d80:	adrp	x8, 7923 ; 0x10239c000
1004a9d84:	ldr	x8, [x8, #0xf10]
1004a9d88:	cmn	x8, #0x1
1004a9d8c:	b.ne	0x1004a9ebc
1004a9d90:	adrp	x19, 7984 ; 0x1023d9000
1004a9d94:	add	x19, x19, #0xf78
1004a9d98:	add	x1, sp, #0x18
1004a9d9c:	mov	x0, x19
1004a9da0:	mov	x2, #0x0
1004a9da4:	mov	x3, #0x0
1004a9da8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a9dac:	mov	x0, x19
1004a9db0:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004a9db4:	cbz	x0, 0x1004a9e00
1004a9db8:	mov	x19, x0
1004a9dbc:	bl	0x101acdcc0 ; selector frame
1004a9dc0:	mov.16b	v4, v0
1004a9dc4:	mov.16b	v5, v1
1004a9dc8:	mov.16b	v6, v2
1004a9dcc:	mov.16b	v7, v3
1004a9dd0:	mov.16b	v0, v9
1004a9dd4:	mov.16b	v1, v8
1004a9dd8:	mov.16b	v2, v4
1004a9ddc:	mov.16b	v3, v5
1004a9de0:	mov.16b	v4, v6
1004a9de4:	mov	w0, #0x0
1004a9de8:	mov.16b	v5, v7
1004a9dec:	bl	0x101ac9424 ; symbol stub for: _NSMouseInRect
1004a9df0:	mov	x20, x0
1004a9df4:	mov	x0, x19
1004a9df8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a9dfc:	tbnz	w20, #0x0, 0x1004a9e80
1004a9e00:	adrp	x8, 7923 ; 0x10239c000
1004a9e04:	ldr	x8, [x8, #0xf18]
1004a9e08:	cmn	x8, #0x1
1004a9e0c:	b.ne	0x1004a9ed4
1004a9e10:	adrp	x19, 7984 ; 0x1023d9000
1004a9e14:	add	x19, x19, #0xf80
1004a9e18:	mov	x1, sp
1004a9e1c:	mov	x0, x19
1004a9e20:	mov	x2, #0x0
1004a9e24:	mov	x3, #0x0
1004a9e28:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004a9e2c:	mov	x0, x19
1004a9e30:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004a9e34:	cbz	x0, 0x1004a9e88
1004a9e38:	mov	x19, x0
1004a9e3c:	bl	0x101acdcc0 ; selector frame
1004a9e40:	mov.16b	v4, v0
1004a9e44:	mov.16b	v5, v1
1004a9e48:	mov.16b	v6, v2
1004a9e4c:	mov.16b	v7, v3
1004a9e50:	mov.16b	v0, v9
1004a9e54:	mov.16b	v1, v8
1004a9e58:	mov.16b	v2, v4
1004a9e5c:	mov.16b	v3, v5
1004a9e60:	mov.16b	v4, v6
1004a9e64:	mov	w0, #0x0
1004a9e68:	mov.16b	v5, v7
1004a9e6c:	bl	0x101ac9424 ; symbol stub for: _NSMouseInRect
1004a9e70:	mov	x20, x0
1004a9e74:	mov	x0, x19
1004a9e78:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a9e7c:	tbz	w20, #0x0, 0x1004a9e88
1004a9e80:	mov	w0, #0x1
1004a9e84:	b	0x1004a9e8c
1004a9e88:	mov	w0, #0x0
1004a9e8c:	ldp	x29, x30, [sp, #0x60]
1004a9e90:	ldp	x20, x19, [sp, #0x50]
1004a9e94:	ldp	x22, x21, [sp, #0x40]
1004a9e98:	ldp	d9, d8, [sp, #0x30]
1004a9e9c:	add	sp, sp, #0x70
1004a9ea0:	ret
1004a9ea4:	adrp	x0, 7923 ; 0x10239c000
1004a9ea8:	add	x0, x0, #0xf20
1004a9eac:	adrp	x1, 0 ; 0x1004a9000
1004a9eb0:	add	x1, x1, #0x960
1004a9eb4:	bl	0x101aca948 ; symbol stub for: _swift_once
1004a9eb8:	b	0x1004a9cfc
1004a9ebc:	adrp	x0, 7923 ; 0x10239c000
1004a9ec0:	add	x0, x0, #0xf10
1004a9ec4:	adrp	x1, 0 ; 0x1004a9000
1004a9ec8:	add	x1, x1, #0x970
1004a9ecc:	bl	0x101aca948 ; symbol stub for: _swift_once
1004a9ed0:	b	0x1004a9d90
1004a9ed4:	adrp	x0, 7923 ; 0x10239c000
1004a9ed8:	add	x0, x0, #0xf18
1004a9edc:	adrp	x1, 0 ; 0x1004a9000
1004a9ee0:	add	x1, x1, #0xa7c
1004a9ee4:	bl	0x101aca948 ; symbol stub for: _swift_once
1004a9ee8:	b	0x1004a9e10
1004a9eec:	adrp	x0, 7851 ; 0x102354000
1004a9ef0:	add	x0, x0, #0xea0
1004a9ef4:	adrp	x1, 4 ; 0x1004ad000
1004a9ef8:	add	x1, x1, #0x3c
1004a9efc:	b	0x1004ab94c
1004a9f00:	adrp	x2, 7851 ; 0x102354000
1004a9f04:	add	x2, x2, #0xea0
1004a9f08:	adrp	x3, 4 ; 0x1004ad000
1004a9f0c:	add	x3, x3, #0x3c
1004a9f10:	b	0x1004ab9b0
1004a9f14:	stp	x20, x19, [sp, #-0x20]!
1004a9f18:	stp	x29, x30, [sp, #0x10]
1004a9f1c:	add	x29, sp, #0x10
1004a9f20:	mov	x19, x0
1004a9f24:	adrp	x8, 7851 ; 0x102354000
1004a9f28:	ldr	x8, [x8, #0xea8]
1004a9f2c:	ldr	x0, [x0, x8]
1004a9f30:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a9f34:	adrp	x8, 7851 ; 0x102354000
1004a9f38:	ldr	x8, [x8, #0xeb0]
1004a9f3c:	ldr	x0, [x19, x8]
1004a9f40:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a9f44:	adrp	x8, 7851 ; 0x102354000
1004a9f48:	ldr	x8, [x8, #0xeb8]
1004a9f4c:	add	x8, x19, x8
1004a9f50:	ldp	x0, x1, [x8]
1004a9f54:	bl	0x100003840
1004a9f58:	adrp	x8, 7851 ; 0x102354000
1004a9f5c:	ldr	x8, [x8, #0xec0]
1004a9f60:	add	x8, x19, x8
1004a9f64:	ldp	x0, x1, [x8]
1004a9f68:	bl	0x100003840
1004a9f6c:	adrp	x8, 7851 ; 0x102354000
1004a9f70:	ldr	x8, [x8, #0xec8]
1004a9f74:	ldr	x0, [x19, x8]
1004a9f78:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a9f7c:	adrp	x8, 7851 ; 0x102354000
1004a9f80:	ldr	x8, [x8, #0xed0]
1004a9f84:	ldr	x0, [x19, x8]
1004a9f88:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004a9f8c:	adrp	x8, 7851 ; 0x102354000
1004a9f90:	ldr	x8, [x8, #0xed8]
1004a9f94:	add	x0, x19, x8
1004a9f98:	bl	0x101acaabc ; symbol stub for: _swift_unknownObjectWeakDestroy
1004a9f9c:	adrp	x8, 7851 ; 0x102354000
1004a9fa0:	ldr	x8, [x8, #0xea0]
1004a9fa4:	ldr	x0, [x19, x8]
1004a9fa8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004a9fac:	adrp	x8, 7851 ; 0x102354000
1004a9fb0:	ldr	x8, [x8, #0xee0]
1004a9fb4:	ldr	x0, [x19, x8]
1004a9fb8:	ldp	x29, x30, [sp, #0x10]
1004a9fbc:	ldp	x20, x19, [sp], #0x20
1004a9fc0:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004a9fc4:	stp	x22, x21, [sp, #-0x30]!
1004a9fc8:	stp	x20, x19, [sp, #0x10]
1004a9fcc:	stp	x29, x30, [sp, #0x20]
1004a9fd0:	add	x29, sp, #0x20
1004a9fd4:	and	w8, w0, #0x1
1004a9fd8:	adrp	x9, 7851 ; 0x102354000
1004a9fdc:	ldr	x9, [x9, #0xee8]
1004a9fe0:	ldrb	w10, [x20, x9]
1004a9fe4:	strb	w0, [x20, x9]
1004a9fe8:	cmp	w8, w10
1004a9fec:	b.eq	0x1004aa014
1004a9ff0:	tbz	w0, #0x0, 0x1004aa024
1004a9ff4:	mov	x0, x20
1004a9ff8:	bl	0x1004adb68
1004a9ffc:	mov	x8, x0
1004aa000:	adrp	x9, 7850 ; 0x102354000
1004aa004:	ldr	x9, [x9, #0xed0]
1004aa008:	ldr	x0, [x20, x9]
1004aa00c:	str	x8, [x20, x9]
1004aa010:	b	0x1004aa054
1004aa014:	ldp	x29, x30, [sp, #0x20]
1004aa018:	ldp	x20, x19, [sp, #0x10]
1004aa01c:	ldp	x22, x21, [sp], #0x30
1004aa020:	ret
1004aa024:	adrp	x8, 7850 ; 0x102354000
1004aa028:	ldr	x21, [x8, #0xed0]
1004aa02c:	ldr	x19, [x20, x21]
1004aa030:	mov	x0, x19
1004aa034:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004aa038:	bl	0x1004adb6c
1004aa03c:	mov	x0, x19
1004aa040:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aa044:	ldr	x0, [x20, x21]
1004aa048:	adrp	x8, 7717 ; 0x1022cf000
1004aa04c:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004aa050:	str	x8, [x20, x21]
1004aa054:	ldp	x29, x30, [sp, #0x20]
1004aa058:	ldp	x20, x19, [sp, #0x10]
1004aa05c:	ldp	x22, x21, [sp], #0x30
1004aa060:	b	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aa064:	stp	d11, d10, [sp, #-0x70]!
1004aa068:	stp	d9, d8, [sp, #0x10]
1004aa06c:	stp	x26, x25, [sp, #0x20]
1004aa070:	stp	x24, x23, [sp, #0x30]
1004aa074:	stp	x22, x21, [sp, #0x40]
1004aa078:	stp	x20, x19, [sp, #0x50]
1004aa07c:	stp	x29, x30, [sp, #0x60]
1004aa080:	add	x29, sp, #0x60
1004aa084:	mov	x19, x6
1004aa088:	mov	x21, x5
1004aa08c:	mov	x22, x2
1004aa090:	mov.16b	v8, v0
1004aa094:	mov	x23, x1
1004aa098:	mov	x24, x0
1004aa09c:	adrp	x8, 7850 ; 0x102354000
1004aa0a0:	ldr	x8, [x8, #0xeb8]
1004aa0a4:	add	x8, x20, x8
1004aa0a8:	ldp	x25, x26, [x8]
1004aa0ac:	stp	x3, x4, [x8]
1004aa0b0:	mov	x0, x4
1004aa0b4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004aa0b8:	mov	x0, x25
1004aa0bc:	mov	x1, x26
1004aa0c0:	bl	0x100003840
1004aa0c4:	adrp	x8, 7850 ; 0x102354000
1004aa0c8:	ldr	x8, [x8, #0xec0]
1004aa0cc:	add	x8, x20, x8
1004aa0d0:	ldp	x0, x1, [x8]
1004aa0d4:	stp	x21, x19, [x8]
1004aa0d8:	bl	0x100003840
1004aa0dc:	adrp	x8, 7850 ; 0x102354000
1004aa0e0:	ldr	x8, [x8, #0xed8]
1004aa0e4:	add	x0, x20, x8
1004aa0e8:	mov	x1, x22
1004aa0ec:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004aa0f0:	mov	x0, x21
1004aa0f4:	mov	x1, x19
1004aa0f8:	bl	0x100003f5c
1004aa0fc:	mov	x0, x24
1004aa100:	mov	x1, x23
1004aa104:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004aa108:	mov	x19, x0
1004aa10c:	adrp	x8, 7804 ; 0x102326000
1004aa110:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004aa114:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004aa118:	mov	x21, x0
1004aa11c:	mov	x2, x19
1004aa120:	bl	0x101acf240 ; selector labelWithString:
1004aa124:	mov	x29, x29
1004aa128:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aa12c:	mov	x22, x0
1004aa130:	mov	x0, x19
1004aa134:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa138:	mov	x0, x22
1004aa13c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa140:	mov	x19, x0
1004aa144:	bl	0x10002dd04
1004aa148:	mov.16b	v1, v0
1004aa14c:	fmov	d0, #13.00000000
1004aa150:	bl	0x100004700
1004aa154:	mov	x22, x0
1004aa158:	mov	x0, x19
1004aa15c:	mov	x2, x22
1004aa160:	bl	0x101ad2aa0 ; selector setFont:
1004aa164:	mov	x0, x19
1004aa168:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa16c:	mov	x0, x22
1004aa170:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa174:	adrp	x8, 7804 ; 0x102326000
1004aa178:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004aa17c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004aa180:	mov	x22, x0
1004aa184:	bl	0x101acf220 ; selector labelColor
1004aa188:	mov	x29, x29
1004aa18c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aa190:	mov	x23, x0
1004aa194:	mov	x0, x19
1004aa198:	mov	x2, x23
1004aa19c:	bl	0x101ad4660 ; selector setTextColor:
1004aa1a0:	mov	x0, x23
1004aa1a4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa1a8:	mov	x8, #-0x3fc0000000000000
1004aa1ac:	fmov	d0, x8
1004aa1b0:	fadd	d0, d8, d0
1004aa1b4:	fmov	d1, #-20.00000000
1004aa1b8:	fadd	d9, d0, d1
1004aa1bc:	mov	x0, x19
1004aa1c0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa1c4:	mov	x19, x0
1004aa1c8:	mov	x0, x20
1004aa1cc:	bl	0x101acbde0 ; selector bounds
1004aa1d0:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004aa1d4:	mov.16b	v3, v0
1004aa1d8:	fmov	d0, #16.00000000
1004aa1dc:	movi.2d	v1, #0000000000000000
1004aa1e0:	mov	x0, x19
1004aa1e4:	mov.16b	v2, v9
1004aa1e8:	bl	0x101ad2b80 ; selector setFrame:
1004aa1ec:	mov	x0, x19
1004aa1f0:	mov	w2, #0x0
1004aa1f4:	bl	0x101ad28e0 ; selector setEditable:
1004aa1f8:	mov	x0, x19
1004aa1fc:	mov	w2, #0x0
1004aa200:	bl	0x101ad1fa0 ; selector setBordered:
1004aa204:	mov	x0, x19
1004aa208:	mov	w2, #0x0
1004aa20c:	bl	0x101ad2860 ; selector setDrawsBackground:
1004aa210:	mov	x0, x20
1004aa214:	mov	x2, x19
1004aa218:	bl	0x101acb460 ; selector addSubview:
1004aa21c:	adrp	x8, 7850 ; 0x102354000
1004aa220:	ldr	x8, [x8, #0xea8]
1004aa224:	ldr	x23, [x20, x8]
1004aa228:	str	x19, [x20, x8]
1004aa22c:	mov	x0, x19
1004aa230:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa234:	mov	x19, x0
1004aa238:	mov	x0, x23
1004aa23c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa240:	mov	x0, x19
1004aa244:	bl	0x101ad4fe0 ; selector sizeToFit
1004aa248:	mov	x0, x20
1004aa24c:	bl	0x101acbde0 ; selector bounds
1004aa250:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004aa254:	mov.16b	v10, v0
1004aa258:	mov	x0, x19
1004aa25c:	bl	0x101acdcc0 ; selector frame
1004aa260:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004aa264:	fsub	d0, d10, d0
1004aa268:	fmov	d11, #0.50000000
1004aa26c:	fmul	d10, d0, d11
1004aa270:	mov	x0, x19
1004aa274:	bl	0x101acdcc0 ; selector frame
1004aa278:	mov	x0, x19
1004aa27c:	mov.16b	v1, v10
1004aa280:	bl	0x101ad2b80 ; selector setFrame:
1004aa284:	mov	x0, x19
1004aa288:	bl	0x101acdcc0 ; selector frame
1004aa28c:	mov	x0, x19
1004aa290:	mov.16b	v2, v9
1004aa294:	bl	0x101ad2b80 ; selector setFrame:
1004aa298:	mov	x0, x19
1004aa29c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa2a0:	mov	w0, #0x80e2
1004aa2a4:	movk	w0, #0xba, lsl #16
1004aa2a8:	mov	x1, #-0x5d00000000000000
1004aa2ac:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004aa2b0:	mov	x23, x0
1004aa2b4:	mov	x0, x21
1004aa2b8:	mov	x2, x23
1004aa2bc:	bl	0x101acf240 ; selector labelWithString:
1004aa2c0:	mov	x29, x29
1004aa2c4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aa2c8:	mov	x21, x0
1004aa2cc:	mov	x0, x23
1004aa2d0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa2d4:	mov	x0, x21
1004aa2d8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa2dc:	mov	x21, x0
1004aa2e0:	bl	0x10002dd04
1004aa2e4:	mov.16b	v1, v0
1004aa2e8:	fmov	d0, #14.00000000
1004aa2ec:	bl	0x100004700
1004aa2f0:	mov	x23, x0
1004aa2f4:	mov	x0, x21
1004aa2f8:	mov	x2, x23
1004aa2fc:	bl	0x101ad2aa0 ; selector setFont:
1004aa300:	mov	x0, x23
1004aa304:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa308:	mov	x0, x22
1004aa30c:	bl	0x101ad58a0 ; selector tertiaryLabelColor
1004aa310:	mov	x29, x29
1004aa314:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aa318:	mov	x22, x0
1004aa31c:	mov	x0, x21
1004aa320:	mov	x2, x22
1004aa324:	bl	0x101ad4660 ; selector setTextColor:
1004aa328:	mov	x0, x22
1004aa32c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa330:	mov	x0, x21
1004aa334:	mov	w2, #0x2
1004aa338:	bl	0x101ad1820 ; selector setAlignment:
1004aa33c:	mov	x0, x21
1004aa340:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa344:	fmov	d0, #-16.00000000
1004aa348:	fadd	d1, d8, d0
1004aa34c:	fadd	d8, d1, d0
1004aa350:	mov	x0, x21
1004aa354:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa358:	mov	x21, x0
1004aa35c:	mov	x0, x20
1004aa360:	bl	0x101acbde0 ; selector bounds
1004aa364:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004aa368:	mov.16b	v3, v0
1004aa36c:	movi.2d	v1, #0000000000000000
1004aa370:	fmov	d2, #16.00000000
1004aa374:	mov	x0, x21
1004aa378:	mov.16b	v0, v8
1004aa37c:	bl	0x101ad2b80 ; selector setFrame:
1004aa380:	mov	x0, x21
1004aa384:	mov	w2, #0x0
1004aa388:	bl	0x101ad28e0 ; selector setEditable:
1004aa38c:	mov	x0, x21
1004aa390:	mov	w2, #0x0
1004aa394:	bl	0x101ad1fa0 ; selector setBordered:
1004aa398:	mov	x0, x21
1004aa39c:	mov	w2, #0x0
1004aa3a0:	bl	0x101ad2860 ; selector setDrawsBackground:
1004aa3a4:	mov	x0, x20
1004aa3a8:	mov	x2, x21
1004aa3ac:	bl	0x101acb460 ; selector addSubview:
1004aa3b0:	adrp	x8, 7850 ; 0x102354000
1004aa3b4:	ldr	x8, [x8, #0xeb0]
1004aa3b8:	ldr	x22, [x20, x8]
1004aa3bc:	str	x21, [x20, x8]
1004aa3c0:	mov	x0, x21
1004aa3c4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa3c8:	mov	x21, x0
1004aa3cc:	mov	x0, x22
1004aa3d0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa3d4:	mov	x0, x21
1004aa3d8:	bl	0x101ad4fe0 ; selector sizeToFit
1004aa3dc:	mov	x0, x20
1004aa3e0:	bl	0x101acbde0 ; selector bounds
1004aa3e4:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004aa3e8:	mov.16b	v9, v0
1004aa3ec:	mov	x0, x21
1004aa3f0:	bl	0x101acdcc0 ; selector frame
1004aa3f4:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004aa3f8:	fsub	d0, d9, d0
1004aa3fc:	fmul	d9, d0, d11
1004aa400:	mov	x0, x21
1004aa404:	bl	0x101acdcc0 ; selector frame
1004aa408:	mov	x0, x21
1004aa40c:	mov.16b	v1, v9
1004aa410:	bl	0x101ad2b80 ; selector setFrame:
1004aa414:	mov	x0, x21
1004aa418:	bl	0x101acdcc0 ; selector frame
1004aa41c:	fmov	d2, #16.00000000
1004aa420:	mov	x0, x21
1004aa424:	bl	0x101ad2b80 ; selector setFrame:
1004aa428:	mov	x0, x21
1004aa42c:	bl	0x101acdcc0 ; selector frame
1004aa430:	mov	x0, x21
1004aa434:	mov.16b	v0, v8
1004aa438:	bl	0x101ad2b80 ; selector setFrame:
1004aa43c:	mov	x0, x19
1004aa440:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa444:	mov	x0, x21
1004aa448:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa44c:	mov	x0, x21
1004aa450:	ldp	x29, x30, [sp, #0x60]
1004aa454:	ldp	x20, x19, [sp, #0x50]
1004aa458:	ldp	x22, x21, [sp, #0x40]
1004aa45c:	ldp	x24, x23, [sp, #0x30]
1004aa460:	ldp	x26, x25, [sp, #0x20]
1004aa464:	ldp	d9, d8, [sp, #0x10]
1004aa468:	ldp	d11, d10, [sp], #0x70
1004aa46c:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004aa470:	adrp	x0, 3 ; 0x1004ad000
1004aa474:	add	x0, x0, #0x3c
1004aa478:	adrp	x1, 7850 ; 0x102354000
1004aa47c:	add	x1, x1, #0xec8
1004aa480:	b	0x1004abe68
1004aa484:	stp	x20, x19, [sp, #-0x20]!
1004aa488:	stp	x29, x30, [sp, #0x10]
1004aa48c:	add	x29, sp, #0x10
1004aa490:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa494:	mov	x20, x0
1004aa498:	adrp	x0, 3 ; 0x1004ad000
1004aa49c:	add	x0, x0, #0x3c
1004aa4a0:	adrp	x1, 7850 ; 0x102354000
1004aa4a4:	add	x1, x1, #0xec8
1004aa4a8:	bl	0x1004abe68
1004aa4ac:	mov	x0, x20
1004aa4b0:	ldp	x29, x30, [sp, #0x10]
1004aa4b4:	ldp	x20, x19, [sp], #0x20
1004aa4b8:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004aa4bc:	stp	x29, x30, [sp, #-0x10]!
1004aa4c0:	mov	x29, sp
1004aa4c4:	adrp	x0, 7850 ; 0x102354000
1004aa4c8:	add	x0, x0, #0xee8
1004aa4cc:	adrp	x1, 7850 ; 0x102354000
1004aa4d0:	add	x1, x1, #0xed0
1004aa4d4:	adrp	x2, 0 ; 0x1004aa000
1004aa4d8:	add	x2, x2, #0x648
1004aa4dc:	bl	0x1004ad07c
1004aa4e0:	ldp	x29, x30, [sp], #0x10
1004aa4e4:	ret
1004aa4e8:	stp	x22, x21, [sp, #-0x30]!
1004aa4ec:	stp	x20, x19, [sp, #0x10]
1004aa4f0:	stp	x29, x30, [sp, #0x20]
1004aa4f4:	add	x29, sp, #0x20
1004aa4f8:	mov	x19, x0
1004aa4fc:	mov	x0, x2
1004aa500:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa504:	mov	x21, x0
1004aa508:	mov	x0, x19
1004aa50c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa510:	mov	x20, x0
1004aa514:	adrp	x0, 7850 ; 0x102354000
1004aa518:	add	x0, x0, #0xee8
1004aa51c:	adrp	x1, 7850 ; 0x102354000
1004aa520:	add	x1, x1, #0xed0
1004aa524:	adrp	x2, 0 ; 0x1004aa000
1004aa528:	add	x2, x2, #0x648
1004aa52c:	bl	0x1004ad07c
1004aa530:	mov	x0, x21
1004aa534:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa538:	mov	x0, x20
1004aa53c:	ldp	x29, x30, [sp, #0x20]
1004aa540:	ldp	x20, x19, [sp, #0x10]
1004aa544:	ldp	x22, x21, [sp], #0x30
1004aa548:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004aa54c:	stp	x29, x30, [sp, #-0x10]!
1004aa550:	mov	x29, sp
1004aa554:	adrp	x0, 7850 ; 0x102354000
1004aa558:	add	x0, x0, #0xee8
1004aa55c:	adrp	x1, 7850 ; 0x102354000
1004aa560:	add	x1, x1, #0xed0
1004aa564:	bl	0x1004ad0e8
1004aa568:	ldp	x29, x30, [sp], #0x10
1004aa56c:	ret
1004aa570:	stp	x22, x21, [sp, #-0x30]!
1004aa574:	stp	x20, x19, [sp, #0x10]
1004aa578:	stp	x29, x30, [sp, #0x20]
1004aa57c:	add	x29, sp, #0x20
1004aa580:	mov	x19, x0
1004aa584:	mov	x0, x2
1004aa588:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa58c:	mov	x21, x0
1004aa590:	mov	x0, x19
1004aa594:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa598:	mov	x20, x0
1004aa59c:	adrp	x0, 7850 ; 0x102354000
1004aa5a0:	add	x0, x0, #0xee8
1004aa5a4:	adrp	x1, 7850 ; 0x102354000
1004aa5a8:	add	x1, x1, #0xed0
1004aa5ac:	bl	0x1004ad0e8
1004aa5b0:	mov	x0, x21
1004aa5b4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa5b8:	mov	x0, x20
1004aa5bc:	ldp	x29, x30, [sp, #0x20]
1004aa5c0:	ldp	x20, x19, [sp, #0x10]
1004aa5c4:	ldp	x22, x21, [sp], #0x30
1004aa5c8:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004aa5cc:	adrp	x0, 7850 ; 0x102354000
1004aa5d0:	add	x0, x0, #0xee8
1004aa5d4:	adrp	x1, 3 ; 0x1004ad000
1004aa5d8:	add	x1, x1, #0x3c
1004aa5dc:	b	0x1004ac08c
1004aa5e0:	stp	d11, d10, [sp, #-0x40]!
1004aa5e4:	stp	d9, d8, [sp, #0x10]
1004aa5e8:	stp	x20, x19, [sp, #0x20]
1004aa5ec:	stp	x29, x30, [sp, #0x30]
1004aa5f0:	add	x29, sp, #0x30
1004aa5f4:	mov.16b	v8, v3
1004aa5f8:	mov.16b	v9, v2
1004aa5fc:	mov.16b	v10, v1
1004aa600:	mov.16b	v11, v0
1004aa604:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa608:	mov	x20, x0
1004aa60c:	adrp	x0, 7850 ; 0x102354000
1004aa610:	add	x0, x0, #0xee8
1004aa614:	adrp	x1, 3 ; 0x1004ad000
1004aa618:	add	x1, x1, #0x3c
1004aa61c:	mov.16b	v0, v11
1004aa620:	mov.16b	v1, v10
1004aa624:	mov.16b	v2, v9
1004aa628:	mov.16b	v3, v8
1004aa62c:	bl	0x1004ac08c
1004aa630:	mov	x0, x20
1004aa634:	ldp	x29, x30, [sp, #0x30]
1004aa638:	ldp	x20, x19, [sp, #0x20]
1004aa63c:	ldp	d9, d8, [sp, #0x10]
1004aa640:	ldp	d11, d10, [sp], #0x40
1004aa644:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004aa648:	sub	sp, sp, #0x170
1004aa64c:	stp	d15, d14, [sp, #0xd0]
1004aa650:	stp	d13, d12, [sp, #0xe0]
1004aa654:	stp	d11, d10, [sp, #0xf0]
1004aa658:	stp	d9, d8, [sp, #0x100]
1004aa65c:	stp	x28, x27, [sp, #0x110]
1004aa660:	stp	x26, x25, [sp, #0x120]
1004aa664:	stp	x24, x23, [sp, #0x130]
1004aa668:	stp	x22, x21, [sp, #0x140]
1004aa66c:	stp	x20, x19, [sp, #0x150]
1004aa670:	stp	x29, x30, [sp, #0x160]
1004aa674:	add	x29, sp, #0x160
1004aa678:	adrp	x8, 7850 ; 0x102354000
1004aa67c:	ldr	x8, [x8, #0xeb8]
1004aa680:	str	x20, [sp, #0x60]
1004aa684:	add	x8, x20, x8
1004aa688:	ldr	x19, [x8]
1004aa68c:	cbz	x19, 0x1004ab63c
1004aa690:	ldr	x20, [x8, #0x8]
1004aa694:	mov	x0, x19
1004aa698:	mov	x1, x20
1004aa69c:	bl	0x100003f5c
1004aa6a0:	blr	x19
1004aa6a4:	mov	x25, x0
1004aa6a8:	mov	x0, x19
1004aa6ac:	mov	x1, x20
1004aa6b0:	bl	0x100003840
1004aa6b4:	bl	0x1004acf1c
1004aa6b8:	adrp	x8, 7922 ; 0x10239c000
1004aa6bc:	ldr	x8, [x8, #0xf20]
1004aa6c0:	cmn	x8, #0x1
1004aa6c4:	b.ne	0x1004ab670
1004aa6c8:	mov	w22, #0x9ce2
1004aa6cc:	movk	w22, #0x93, lsl #16
1004aa6d0:	adrp	x0, 7922 ; 0x10239c000
1004aa6d4:	add	x0, x0, #0xf28
1004aa6d8:	ldr	x1, [sp, #0x60]
1004aa6dc:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004aa6e0:	ldr	x23, [x25, #0x10]
1004aa6e4:	fmov	d9, #16.00000000
1004aa6e8:	cbz	x23, 0x1004aa758
1004aa6ec:	mov	x19, #0x0
1004aa6f0:	add	x20, x25, #0x38
1004aa6f4:	mov	x21, #-0x5d00000000000000
1004aa6f8:	b	0x1004aa70c
1004aa6fc:	add	x19, x19, #0x1
1004aa700:	add	x20, x20, #0x38
1004aa704:	cmp	x23, x19
1004aa708:	b.eq	0x1004aa758
1004aa70c:	ldr	x8, [x25, #0x10]
1004aa710:	cmp	x19, x8
1004aa714:	b.hs	0x1004ab66c
1004aa718:	ldr	x1, [x20]
1004aa71c:	cbz	x1, 0x1004aa6fc
1004aa720:	ldur	x0, [x20, #-0x8]
1004aa724:	cmp	x0, x22
1004aa728:	ccmp	x1, x21, #0x0, eq
1004aa72c:	b.eq	0x1004aa748
1004aa730:	mov	w2, #0x9ce2
1004aa734:	movk	w2, #0x93, lsl #16
1004aa738:	mov	x3, #-0x5d00000000000000
1004aa73c:	mov	w4, #0x0
1004aa740:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004aa744:	tbz	w0, #0x0, 0x1004aa6fc
1004aa748:	str	wzr, [sp, #0x30]
1004aa74c:	mov	x8, #0x4040000000000000
1004aa750:	fmov	d9, x8
1004aa754:	b	0x1004aa760
1004aa758:	mov	w8, #0x1
1004aa75c:	str	w8, [sp, #0x30]
1004aa760:	bl	0x10002dd04
1004aa764:	mov.16b	v1, v0
1004aa768:	fmov	d0, #13.00000000
1004aa76c:	bl	0x100004700
1004aa770:	str	x0, [sp, #0x48]
1004aa774:	str	x25, [sp, #0x68]
1004aa778:	str	x23, [sp, #0x78]
1004aa77c:	cbz	x23, 0x1004aa938
1004aa780:	add	x21, x25, #0x28
1004aa784:	mov	x8, #0x4064000000000000
1004aa788:	fmov	d10, x8
1004aa78c:	mov	x19, #-0x1d00000000000000
1004aa790:	adrp	x8, 5687 ; 0x101ae1000
1004aa794:	ldr	q0, [x8, #0x130]
1004aa798:	str	q0, [sp, #0x50]
1004aa79c:	b	0x1004aa7b0
1004aa7a0:	ldr	x25, [sp, #0x68]
1004aa7a4:	add	x21, x21, #0x38
1004aa7a8:	subs	x23, x23, #0x1
1004aa7ac:	b.eq	0x1004aa940
1004aa7b0:	ldp	x27, x24, [x21, #-0x8]
1004aa7b4:	mov	w8, #0x2d2d
1004aa7b8:	movk	w8, #0x2d, lsl #16
1004aa7bc:	cmp	x27, x8
1004aa7c0:	ccmp	x24, x19, #0x0, eq
1004aa7c4:	b.eq	0x1004aa7a4
1004aa7c8:	ldp	x25, x22, [x21, #0x10]
1004aa7cc:	ldr	x26, [x21, #0x28]
1004aa7d0:	mov	x0, x27
1004aa7d4:	mov	x1, x24
1004aa7d8:	mov	w2, #0x2d2d
1004aa7dc:	movk	w2, #0x2d, lsl #16
1004aa7e0:	mov	x3, #-0x1d00000000000000
1004aa7e4:	mov	w4, #0x0
1004aa7e8:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004aa7ec:	tbnz	w0, #0x0, 0x1004aa7a0
1004aa7f0:	mov	x0, x22
1004aa7f4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa7f8:	str	x0, [sp, #0x70]
1004aa7fc:	mov	x0, x26
1004aa800:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004aa804:	mov	x0, x24
1004aa808:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004aa80c:	mov	x0, x25
1004aa810:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004aa814:	mov	x0, x27
1004aa818:	mov	x1, x24
1004aa81c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004aa820:	mov	x27, x0
1004aa824:	adrp	x0, 7840 ; 0x10234a000
1004aa828:	add	x0, x0, #0xb40
1004aa82c:	adrp	x1, 5687 ; 0x101ae1000
1004aa830:	add	x1, x1, #0x290
1004aa834:	bl	0x100003c4c
1004aa838:	add	x1, sp, #0x80
1004aa83c:	bl	0x101aca8b8 ; symbol stub for: _swift_initStackObject
1004aa840:	mov	x28, x0
1004aa844:	ldr	q0, [sp, #0x50]
1004aa848:	str	q0, [x0, #0x10]
1004aa84c:	adrp	x8, 7712 ; 0x1022ca000
1004aa850:	ldr	x8, [x8, #0x5c8] ; literal pool symbol address: _NSFontAttributeName
1004aa854:	ldr	x19, [x8]
1004aa858:	mov	x20, x0
1004aa85c:	str	x19, [x20, #0x20]!
1004aa860:	mov	x0, #0x0
1004aa864:	bl	0x10013254c
1004aa868:	str	x0, [x28, #0x40]
1004aa86c:	ldr	x22, [sp, #0x48]
1004aa870:	str	x22, [x28, #0x28]
1004aa874:	mov	x0, x19
1004aa878:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa87c:	mov	x0, x22
1004aa880:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aa884:	mov	x0, x28
1004aa888:	bl	0x10002afac
1004aa88c:	mov	x19, x0
1004aa890:	mov	x0, x28
1004aa894:	bl	0x101aca990 ; symbol stub for: _swift_setDeallocating
1004aa898:	mov	x0, x20
1004aa89c:	bl	0x10010498c
1004aa8a0:	mov	x0, #0x0
1004aa8a4:	bl	0x10002c784
1004aa8a8:	mov	x20, x0
1004aa8ac:	adrp	x0, 7830 ; 0x102340000
1004aa8b0:	add	x0, x0, #0xf30
1004aa8b4:	adrp	x1, 5688 ; 0x101ae2000
1004aa8b8:	add	x1, x1, #0x620
1004aa8bc:	bl	0x100074f70
1004aa8c0:	mov	x3, x0
1004aa8c4:	adrp	x8, 7717 ; 0x1022cf000
1004aa8c8:	ldr	x8, [x8, #0x490] ; literal pool symbol address: _$sypN
1004aa8cc:	add	x2, x8, #0x8
1004aa8d0:	mov	x0, x19
1004aa8d4:	mov	x1, x20
1004aa8d8:	bl	0x101ac5ed8 ; symbol stub for: _$sSD10FoundationE19_bridgeToObjectiveCSo12NSDictionaryCyF
1004aa8dc:	mov	x20, x0
1004aa8e0:	mov	x0, x19
1004aa8e4:	mov	x19, #-0x1d00000000000000
1004aa8e8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aa8ec:	mov	x0, x27
1004aa8f0:	mov	x2, x20
1004aa8f4:	bl	0x101ad5000 ; selector sizeWithAttributes:
1004aa8f8:	mov.16b	v8, v0
1004aa8fc:	mov	x0, x27
1004aa900:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa904:	mov	x0, x20
1004aa908:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa90c:	mov	x0, x26
1004aa910:	bl	0x101aca960 ; symbol stub for: _swift_release
1004aa914:	ldr	x0, [sp, #0x70]
1004aa918:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa91c:	mov	x0, x25
1004aa920:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aa924:	mov	x0, x24
1004aa928:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aa92c:	fcmp	d10, d8
1004aa930:	fcsel	d10, d8, d10, ls
1004aa934:	b	0x1004aa7a0
1004aa938:	mov	x8, #0x4064000000000000
1004aa93c:	fmov	d10, x8
1004aa940:	fadd	d0, d9, d10
1004aa944:	fmov	d1, #16.00000000
1004aa948:	fadd	d0, d0, d1
1004aa94c:	fadd	d0, d0, d1
1004aa950:	frintp	d8, d0
1004aa954:	mov	x0, #0x0
1004aa958:	bl	0x10006d00c
1004aa95c:	movi.2d	v0, #0000000000000000
1004aa960:	movi.2d	v1, #0000000000000000
1004aa964:	movi.2d	v3, #0000000000000000
1004aa968:	mov.16b	v2, v8
1004aa96c:	mov	x20, x0
1004aa970:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004aa974:	str	x0, [sp, #0x70]
1004aa978:	str	d8, [sp, #0x40]
1004aa97c:	ldr	x10, [sp, #0x78]
1004aa980:	cbz	x10, 0x1004ab31c
1004aa984:	mov	x26, #0x0
1004aa988:	adrp	x8, 7850 ; 0x102354000
1004aa98c:	ldr	x8, [x8, #0xec0]
1004aa990:	ldr	x9, [sp, #0x60]
1004aa994:	add	x8, x9, x8
1004aa998:	str	x8, [sp, #0x38]
1004aa99c:	adrp	x8, 7850 ; 0x102354000
1004aa9a0:	ldr	x8, [x8, #0xed8]
1004aa9a4:	str	x8, [sp, #0x18]
1004aa9a8:	fsub	d0, d8, d9
1004aa9ac:	fmov	d1, #-16.00000000
1004aa9b0:	fadd	d10, d0, d1
1004aa9b4:	str	d9, [sp, #0x8]
1004aa9b8:	adrp	x8, 7712 ; 0x1022ca000
1004aa9bc:	ldr	x8, [x8, #0x610] ; literal pool symbol address: _NSFontWeightMedium
1004aa9c0:	ldr	d0, [x8]
1004aa9c4:	str	d0, [sp, #0x10]
1004aa9c8:	fmov	d0, #-24.00000000
1004aa9cc:	fadd	d13, d8, d0
1004aa9d0:	fmov	d12, #4.00000000
1004aa9d4:	fmov	d15, #0.50000000
1004aa9d8:	fmov	d14, #2.00000000
1004aa9dc:	b	0x1004aaa2c
1004aa9e0:	ldr	x0, [sp, #0x70]
1004aa9e4:	mov	x2, x20
1004aa9e8:	bl	0x101acb460 ; selector addSubview:
1004aa9ec:	mov	x0, x22
1004aa9f0:	bl	0x101aca960 ; symbol stub for: _swift_release
1004aa9f4:	mov	x0, x19
1004aa9f8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aa9fc:	mov	x0, x28
1004aaa00:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aaa04:	mov	x0, x27
1004aaa08:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aaa0c:	mov	x0, x20
1004aaa10:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aaa14:	fmov	d11, #5.00000000
1004aaa18:	ldr	x10, [sp, #0x78]
1004aaa1c:	fadd	d12, d12, d11
1004aaa20:	add	x26, x26, #0x38
1004aaa24:	subs	x10, x10, #0x1
1004aaa28:	b.eq	0x1004ab304
1004aaa2c:	str	x10, [sp, #0x78]
1004aaa30:	add	x20, x25, x26
1004aaa34:	ldp	x19, x27, [x20, #0x20]
1004aaa38:	ldp	x21, x28, [x20, #0x30]
1004aaa3c:	ldr	x24, [x20, #0x40]
1004aaa40:	adrp	x0, 7472 ; 0x1021da000
1004aaa44:	add	x0, x0, #0x7c0
1004aaa48:	mov	w1, #0x20
1004aaa4c:	mov	w2, #0x7
1004aaa50:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004aaa54:	mov	x22, x0
1004aaa58:	ldr	x23, [x20, #0x50]
1004aaa5c:	ldur	q0, [x20, #0x48]
1004aaa60:	str	q0, [x0, #0x10]
1004aaa64:	mov	w8, #0x2d2d
1004aaa68:	movk	w8, #0x2d, lsl #16
1004aaa6c:	cmp	x19, x8
1004aaa70:	mov	x8, #-0x1d00000000000000
1004aaa74:	ccmp	x27, x8, #0x0, eq
1004aaa78:	b.eq	0x1004aaa9c
1004aaa7c:	mov	x0, x19
1004aaa80:	mov	x1, x27
1004aaa84:	mov	w2, #0x2d2d
1004aaa88:	movk	w2, #0x2d, lsl #16
1004aaa8c:	mov	x3, #-0x1d00000000000000
1004aaa90:	mov	w4, #0x0
1004aaa94:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004aaa98:	tbz	w0, #0x0, 0x1004aab68
1004aaa9c:	fadd	d8, d12, d14
1004aaaa0:	adrp	x8, 7804 ; 0x102326000
1004aaaa4:	ldr	x20, [x8, #0xa40] ; Objc class ref: _OBJC_CLASS_$_NSView
1004aaaa8:	mov	x0, x27
1004aaaac:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004aaab0:	mov	x0, x28
1004aaab4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004aaab8:	mov	x0, x24
1004aaabc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aaac0:	mov	x19, x0
1004aaac4:	mov	x0, x23
1004aaac8:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004aaacc:	mov	x0, x20
1004aaad0:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004aaad4:	fmov	d0, #12.00000000
1004aaad8:	fmov	d3, #1.00000000
1004aaadc:	mov.16b	v1, v8
1004aaae0:	mov.16b	v2, v13
1004aaae4:	bl	0x101ace5a0 ; selector initWithFrame:
1004aaae8:	mov	x20, x0
1004aaaec:	mov	w2, #0x1
1004aaaf0:	bl	0x101ad4ca0 ; selector setWantsLayer:
1004aaaf4:	mov	x0, x20
1004aaaf8:	bl	0x101acf2c0 ; selector layer
1004aaafc:	mov	x29, x29
1004aab00:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aab04:	cbz	x0, 0x1004aa9e0
1004aab08:	mov	x21, x0
1004aab0c:	adrp	x8, 7804 ; 0x102326000
1004aab10:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004aab14:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004aab18:	bl	0x101ad1600 ; selector separatorColor
1004aab1c:	mov	x29, x29
1004aab20:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aab24:	mov	x24, x22
1004aab28:	mov	x22, x0
1004aab2c:	bl	0x101acad00 ; selector CGColor
1004aab30:	mov	x29, x29
1004aab34:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aab38:	mov	x23, x0
1004aab3c:	mov	x0, x22
1004aab40:	mov	x22, x24
1004aab44:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aab48:	mov	x0, x21
1004aab4c:	mov	x2, x23
1004aab50:	bl	0x101ad1e00 ; selector setBackgroundColor:
1004aab54:	mov	x0, x21
1004aab58:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aab5c:	mov	x0, x23
1004aab60:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aab64:	b	0x1004aa9e0
1004aab68:	cbz	x28, 0x1004aad44
1004aab6c:	mov	x8, #0x5f5f
1004aab70:	movk	x8, #0x616c, lsl #16
1004aab74:	movk	x8, #0x6562, lsl #32
1004aab78:	movk	x8, #0x5f6c, lsl #48
1004aab7c:	cmp	x21, x8
1004aab80:	mov	x8, #0x5f
1004aab84:	movk	x8, #0xe900, lsl #48
1004aab88:	ccmp	x28, x8, #0x0, eq
1004aab8c:	b.eq	0x1004aabbc
1004aab90:	mov	x0, x21
1004aab94:	mov	x1, x28
1004aab98:	mov	x2, #0x5f5f
1004aab9c:	movk	x2, #0x616c, lsl #16
1004aaba0:	movk	x2, #0x6562, lsl #32
1004aaba4:	movk	x2, #0x5f6c, lsl #48
1004aaba8:	mov	x3, #0x5f
1004aabac:	movk	x3, #0xe900, lsl #48
1004aabb0:	mov	w4, #0x0
1004aabb4:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004aabb8:	tbz	w0, #0x0, 0x1004aad44
1004aabbc:	mov	x0, x24
1004aabc0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aabc4:	mov	x20, x0
1004aabc8:	mov	x0, x23
1004aabcc:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004aabd0:	mov	x0, x27
1004aabd4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004aabd8:	mov	x0, x28
1004aabdc:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004aabe0:	mov	x0, x19
1004aabe4:	mov	x1, x27
1004aabe8:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004aabec:	mov	x19, x0
1004aabf0:	adrp	x8, 7804 ; 0x102326000
1004aabf4:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004aabf8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004aabfc:	mov	x2, x19
1004aac00:	bl	0x101acf240 ; selector labelWithString:
1004aac04:	mov	x29, x29
1004aac08:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aac0c:	mov	x21, x0
1004aac10:	mov	x0, x19
1004aac14:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aac18:	mov	x0, x21
1004aac1c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aac20:	mov	x19, x0
1004aac24:	bl	0x10002dd04
1004aac28:	mov.16b	v1, v0
1004aac2c:	fmov	d0, #12.00000000
1004aac30:	bl	0x100004700
1004aac34:	mov	x21, x0
1004aac38:	mov	x0, x19
1004aac3c:	mov	x2, x21
1004aac40:	bl	0x101ad2aa0 ; selector setFont:
1004aac44:	mov	x0, x21
1004aac48:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aac4c:	adrp	x8, 7804 ; 0x102326000
1004aac50:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004aac54:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004aac58:	bl	0x101ad58a0 ; selector tertiaryLabelColor
1004aac5c:	mov	x29, x29
1004aac60:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aac64:	mov	x21, x0
1004aac68:	mov	x0, x19
1004aac6c:	mov	x2, x21
1004aac70:	bl	0x101ad4660 ; selector setTextColor:
1004aac74:	mov	x0, x21
1004aac78:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aac7c:	mov	x0, x19
1004aac80:	mov	w2, #0x4
1004aac84:	bl	0x101ad3340 ; selector setLineBreakMode:
1004aac88:	mov	x0, x19
1004aac8c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aac90:	mov	x0, x19
1004aac94:	mov	w2, #0x0
1004aac98:	bl	0x101ad28e0 ; selector setEditable:
1004aac9c:	mov	x0, x19
1004aaca0:	mov	w2, #0x0
1004aaca4:	bl	0x101ad1fa0 ; selector setBordered:
1004aaca8:	mov	x0, x19
1004aacac:	mov	w2, #0x0
1004aacb0:	bl	0x101ad2860 ; selector setDrawsBackground:
1004aacb4:	mov	x0, x19
1004aacb8:	bl	0x101ad4fe0 ; selector sizeToFit
1004aacbc:	mov	x0, x19
1004aacc0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aacc4:	mov	x19, x0
1004aacc8:	bl	0x101acdcc0 ; selector frame
1004aaccc:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004aacd0:	fmov	d11, #28.00000000
1004aacd4:	fsub	d0, d11, d0
1004aacd8:	fmul	d0, d0, d15
1004aacdc:	fadd	d8, d12, d0
1004aace0:	mov	x0, x19
1004aace4:	bl	0x101acdcc0 ; selector frame
1004aace8:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004aacec:	mov.16b	v3, v0
1004aacf0:	mov	x0, x19
1004aacf4:	mov.16b	v0, v9
1004aacf8:	mov.16b	v1, v8
1004aacfc:	mov.16b	v2, v10
1004aad00:	bl	0x101ad2b80 ; selector setFrame:
1004aad04:	mov	x0, x19
1004aad08:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aad0c:	ldr	x0, [sp, #0x70]
1004aad10:	mov	x2, x19
1004aad14:	bl	0x101acb460 ; selector addSubview:
1004aad18:	mov	x0, x19
1004aad1c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aad20:	mov	x0, x22
1004aad24:	bl	0x101aca960 ; symbol stub for: _swift_release
1004aad28:	mov	x0, x20
1004aad2c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aad30:	mov	x0, x28
1004aad34:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aad38:	mov	x0, x27
1004aad3c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aad40:	b	0x1004aaa18
1004aad44:	str	x22, [sp, #0x50]
1004aad48:	ldr	x8, [sp, #0x38]
1004aad4c:	ldr	x25, [x8]
1004aad50:	cbz	x25, 0x1004aae80
1004aad54:	ldr	x20, [x8, #0x8]
1004aad58:	mov	x0, x24
1004aad5c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aad60:	mov	x22, x0
1004aad64:	mov	x0, x23
1004aad68:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004aad6c:	mov	x0, x27
1004aad70:	mov	w1, #0x2
1004aad74:	bl	0x101aca630 ; symbol stub for: _swift_bridgeObjectRetain_n
1004aad78:	mov	x0, x28
1004aad7c:	mov	w1, #0x2
1004aad80:	bl	0x101aca630 ; symbol stub for: _swift_bridgeObjectRetain_n
1004aad84:	mov	x0, x25
1004aad88:	mov	x1, x20
1004aad8c:	bl	0x100003f5c
1004aad90:	mov	x0, x19
1004aad94:	mov	x1, x27
1004aad98:	blr	x25
1004aad9c:	mov	x23, x0
1004aada0:	mov	x0, x25
1004aada4:	mov	x1, x20
1004aada8:	bl	0x100003840
1004aadac:	cbz	x23, 0x1004aaea8
1004aadb0:	mov	x0, x28
1004aadb4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aadb8:	bl	0x1004ad05c
1004aadbc:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004aadc0:	fmov	d11, #28.00000000
1004aadc4:	movi.2d	v0, #0000000000000000
1004aadc8:	fmov	d3, #28.00000000
1004aadcc:	mov.16b	v1, v12
1004aadd0:	ldr	d8, [sp, #0x40]
1004aadd4:	mov.16b	v2, v8
1004aadd8:	bl	0x101ace5a0 ; selector initWithFrame:
1004aaddc:	mov	x20, x0
1004aade0:	ldr	x8, [sp, #0x60]
1004aade4:	ldr	x9, [sp, #0x18]
1004aade8:	add	x0, x8, x9
1004aadec:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004aadf0:	mov	x21, x0
1004aadf4:	ldr	x8, [x20]
1004aadf8:	adrp	x9, 7717 ; 0x1022cf000
1004aadfc:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004aae00:	ldr	x9, [x9]
1004aae04:	and	x8, x9, x8
1004aae08:	ldr	x8, [x8, #0x1b0]
1004aae0c:	fmov	d2, #28.00000000
1004aae10:	mov	x0, x19
1004aae14:	mov	x1, x27
1004aae18:	mov.16b	v0, v8
1004aae1c:	mov.16b	v1, v9
1004aae20:	mov	x2, x23
1004aae24:	mov	x3, x21
1004aae28:	blr	x8
1004aae2c:	mov	x0, x23
1004aae30:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aae34:	mov	x0, x21
1004aae38:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aae3c:	mov	x0, x27
1004aae40:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aae44:	ldr	x0, [sp, #0x70]
1004aae48:	mov	x2, x20
1004aae4c:	bl	0x101acb460 ; selector addSubview:
1004aae50:	ldr	x0, [sp, #0x50]
1004aae54:	bl	0x101aca960 ; symbol stub for: _swift_release
1004aae58:	mov	x0, x22
1004aae5c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aae60:	mov	x0, x28
1004aae64:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aae68:	mov	x0, x27
1004aae6c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aae70:	mov	x0, x20
1004aae74:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aae78:	ldr	x25, [sp, #0x68]
1004aae7c:	b	0x1004aaa18
1004aae80:	mov	x0, x24
1004aae84:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aae88:	mov	x0, x23
1004aae8c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004aae90:	mov	x0, x27
1004aae94:	mov	w1, #0x2
1004aae98:	bl	0x101aca630 ; symbol stub for: _swift_bridgeObjectRetain_n
1004aae9c:	mov	x0, x28
1004aaea0:	mov	w1, #0x2
1004aaea4:	bl	0x101aca630 ; symbol stub for: _swift_bridgeObjectRetain_n
1004aaea8:	cbz	x28, 0x1004aaed4
1004aaeac:	mov	w8, #0x9ce2
1004aaeb0:	movk	w8, #0x93, lsl #16
1004aaeb4:	cmp	x21, x8
1004aaeb8:	b.ne	0x1004aaedc
1004aaebc:	mov	x8, #-0x5d00000000000000
1004aaec0:	cmp	x28, x8
1004aaec4:	b.ne	0x1004aaedc
1004aaec8:	mov	w8, #0x1
1004aaecc:	str	w8, [sp, #0x34]
1004aaed0:	b	0x1004aaefc
1004aaed4:	str	wzr, [sp, #0x34]
1004aaed8:	b	0x1004aaf04
1004aaedc:	mov	x0, x21
1004aaee0:	mov	x1, x28
1004aaee4:	mov	w2, #0x9ce2
1004aaee8:	movk	w2, #0x93, lsl #16
1004aaeec:	mov	x3, #-0x5d00000000000000
1004aaef0:	mov	w4, #0x0
1004aaef4:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004aaef8:	str	w0, [sp, #0x34]
1004aaefc:	mov	x0, x28
1004aaf00:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aaf04:	mov	x0, #0x0
1004aaf08:	bl	0x1004aede4
1004aaf0c:	movi.2d	v0, #0000000000000000
1004aaf10:	fmov	d3, #28.00000000
1004aaf14:	mov.16b	v1, v12
1004aaf18:	ldr	d2, [sp, #0x40]
1004aaf1c:	mov	x20, x0
1004aaf20:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004aaf24:	mov	x20, x0
1004aaf28:	ldr	x8, [x0]
1004aaf2c:	adrp	x9, 7717 ; 0x1022cf000
1004aaf30:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004aaf34:	ldr	x9, [x9]
1004aaf38:	and	x8, x9, x8
1004aaf3c:	ldr	x8, [x8, #0x130]
1004aaf40:	mov	w0, #0x1
1004aaf44:	blr	x8
1004aaf48:	cbz	x24, 0x1004ab090
1004aaf4c:	adrp	x8, 7804 ; 0x102326000
1004aaf50:	ldr	x0, [x8, #0xb50] ; Objc class ref: _OBJC_CLASS_$_NSImageView
1004aaf54:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004aaf58:	mov	x22, x0
1004aaf5c:	mov	x0, x24
1004aaf60:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aaf64:	mov	x23, x0
1004aaf68:	ldr	x0, [sp, #0x50]
1004aaf6c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004aaf70:	fmov	d0, #12.00000000
1004aaf74:	fmov	d1, #6.00000000
1004aaf78:	fmov	d2, #16.00000000
1004aaf7c:	fmov	d3, #16.00000000
1004aaf80:	mov	x0, x22
1004aaf84:	bl	0x101ace5a0 ; selector initWithFrame:
1004aaf88:	mov	x25, x0
1004aaf8c:	str	x23, [sp, #0x20]
1004aaf90:	mov	x2, x23
1004aaf94:	bl	0x101ad2f60 ; selector setImage:
1004aaf98:	mov	x0, x25
1004aaf9c:	mov	x2, #0x0
1004aafa0:	bl	0x101ad3000 ; selector setImageScaling:
1004aafa4:	mov	x0, x20
1004aafa8:	mov	x2, x25
1004aafac:	bl	0x101acb460 ; selector addSubview:
1004aafb0:	mov	x2, #0x0
1004aafb4:	str	xzr, [sp, #0x28]
1004aafb8:	ldr	w8, [sp, #0x30]
1004aafbc:	cbz	w8, 0x1004aafd0
1004aafc0:	mov	x0, x28
1004aafc4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004aafc8:	mov	x2, x21
1004aafcc:	str	x28, [sp, #0x28]
1004aafd0:	adrp	x0, 7472 ; 0x1021da000
1004aafd4:	add	x0, x0, #0x7e8
1004aafd8:	mov	w1, #0x18
1004aafdc:	mov	x21, x2
1004aafe0:	mov	w2, #0x7
1004aafe4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004aafe8:	mov	x23, x0
1004aafec:	add	x0, x0, #0x10
1004aaff0:	ldr	x1, [sp, #0x60]
1004aaff4:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004aaff8:	adrp	x0, 7472 ; 0x1021da000
1004aaffc:	add	x0, x0, #0x838
1004ab000:	mov	w1, #0x28
1004ab004:	mov	w2, #0x7
1004ab008:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ab00c:	mov	x22, x0
1004ab010:	adrp	x8, -1191 ; 0x100004000
1004ab014:	add	x8, x8, #0xcc
1004ab018:	str	x8, [x0, #0x10]
1004ab01c:	ldr	x0, [sp, #0x50]
1004ab020:	stp	x0, x23, [x22, #0x18]
1004ab024:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ab028:	mov	x0, x23
1004ab02c:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ab030:	bl	_$s9TextStory09BufferingA7StorageC16bufferingEnabledSbvpfi
1004ab034:	ldr	x8, [x20]
1004ab038:	adrp	x9, 7716 ; 0x1022cf000
1004ab03c:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004ab040:	ldr	x9, [x9]
1004ab044:	and	x8, x9, x8
1004ab048:	ldr	x8, [x8, #0x140]
1004ab04c:	str	x22, [sp]
1004ab050:	and	w4, w0, #0x1
1004ab054:	mov	x0, x19
1004ab058:	mov	x1, x27
1004ab05c:	mov	x2, x21
1004ab060:	ldr	x19, [sp, #0x28]
1004ab064:	mov	x3, x19
1004ab068:	mov	x5, #0x4041000000000000
1004ab06c:	mov	w6, #0x0
1004ab070:	adrp	x7, 2 ; 0x1004ad000
1004ab074:	add	x7, x7, #0x1dc
1004ab078:	blr	x8
1004ab07c:	ldr	x0, [sp, #0x20]
1004ab080:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab084:	mov	x0, x25
1004ab088:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab08c:	b	0x1004ab174
1004ab090:	ldr	w8, [sp, #0x30]
1004ab094:	cbz	w8, 0x1004ab0b4
1004ab098:	mov	x0, x28
1004ab09c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004ab0a0:	str	xzr, [sp, #0x20]
1004ab0a4:	mov	w8, #0x1
1004ab0a8:	str	w8, [sp, #0x28]
1004ab0ac:	mov	x25, x28
1004ab0b0:	b	0x1004ab0c8
1004ab0b4:	str	wzr, [sp, #0x28]
1004ab0b8:	mov	x21, #0x0
1004ab0bc:	mov	x25, #0x0
1004ab0c0:	ldr	x8, [sp, #0x8]
1004ab0c4:	str	x8, [sp, #0x20]
1004ab0c8:	adrp	x0, 7471 ; 0x1021da000
1004ab0cc:	add	x0, x0, #0x7e8
1004ab0d0:	mov	w1, #0x18
1004ab0d4:	mov	w2, #0x7
1004ab0d8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ab0dc:	mov	x23, x0
1004ab0e0:	add	x0, x0, #0x10
1004ab0e4:	ldr	x1, [sp, #0x60]
1004ab0e8:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004ab0ec:	adrp	x0, 7471 ; 0x1021da000
1004ab0f0:	add	x0, x0, #0x810
1004ab0f4:	mov	w1, #0x28
1004ab0f8:	mov	w2, #0x7
1004ab0fc:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ab100:	mov	x22, x0
1004ab104:	adrp	x8, -1191 ; 0x100004000
1004ab108:	add	x8, x8, #0xcc
1004ab10c:	str	x8, [x0, #0x10]
1004ab110:	ldr	x0, [sp, #0x50]
1004ab114:	stp	x0, x23, [x22, #0x18]
1004ab118:	mov	w1, #0x2
1004ab11c:	bl	0x101aca984 ; symbol stub for: _swift_retain_n
1004ab120:	mov	x0, x23
1004ab124:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ab128:	bl	_$s9TextStory09BufferingA7StorageC16bufferingEnabledSbvpfi
1004ab12c:	ldr	x8, [x20]
1004ab130:	adrp	x9, 7716 ; 0x1022cf000
1004ab134:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004ab138:	ldr	x9, [x9]
1004ab13c:	and	x8, x9, x8
1004ab140:	ldr	x8, [x8, #0x140]
1004ab144:	str	x22, [sp]
1004ab148:	and	w4, w0, #0x1
1004ab14c:	mov	x0, x19
1004ab150:	mov	x1, x27
1004ab154:	mov	x2, x21
1004ab158:	mov	x19, x25
1004ab15c:	mov	x3, x25
1004ab160:	ldr	x5, [sp, #0x20]
1004ab164:	ldr	w6, [sp, #0x28]
1004ab168:	adrp	x7, 2 ; 0x1004ad000
1004ab16c:	add	x7, x7, #0x298
1004ab170:	blr	x8
1004ab174:	mov	x0, x23
1004ab178:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ab17c:	mov	x0, x22
1004ab180:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ab184:	mov	x0, x27
1004ab188:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ab18c:	mov	x0, x19
1004ab190:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ab194:	ldr	x25, [sp, #0x68]
1004ab198:	ldr	w8, [sp, #0x34]
1004ab19c:	tbz	w8, #0x0, 0x1004ab2c4
1004ab1a0:	mov	w0, #0x9ce2
1004ab1a4:	movk	w0, #0x93, lsl #16
1004ab1a8:	mov	x1, #-0x5d00000000000000
1004ab1ac:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004ab1b0:	mov	x19, x0
1004ab1b4:	adrp	x8, 7803 ; 0x102326000
1004ab1b8:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004ab1bc:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004ab1c0:	mov	x2, x19
1004ab1c4:	bl	0x101acf240 ; selector labelWithString:
1004ab1c8:	mov	x29, x29
1004ab1cc:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ab1d0:	mov	x21, x0
1004ab1d4:	mov	x0, x19
1004ab1d8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab1dc:	mov	x0, x21
1004ab1e0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ab1e4:	mov	x19, x0
1004ab1e8:	fmov	d0, #13.00000000
1004ab1ec:	ldr	d1, [sp, #0x10]
1004ab1f0:	bl	0x100004700
1004ab1f4:	mov	x21, x0
1004ab1f8:	mov	x0, x19
1004ab1fc:	mov	x2, x21
1004ab200:	bl	0x101ad2aa0 ; selector setFont:
1004ab204:	mov	x0, x19
1004ab208:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab20c:	mov	x0, x21
1004ab210:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab214:	adrp	x8, 7803 ; 0x102326000
1004ab218:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004ab21c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004ab220:	bl	0x101acf220 ; selector labelColor
1004ab224:	mov	x29, x29
1004ab228:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ab22c:	mov	x21, x0
1004ab230:	mov	x0, x19
1004ab234:	mov	x2, x21
1004ab238:	bl	0x101ad4660 ; selector setTextColor:
1004ab23c:	mov	x0, x21
1004ab240:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab244:	mov	x0, x19
1004ab248:	bl	0x101ad4fe0 ; selector sizeToFit
1004ab24c:	mov	x0, x19
1004ab250:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ab254:	mov	x19, x0
1004ab258:	bl	0x101acdcc0 ; selector frame
1004ab25c:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004ab260:	fmov	d1, #28.00000000
1004ab264:	fsub	d0, d1, d0
1004ab268:	fmul	d8, d0, d15
1004ab26c:	mov	x0, x19
1004ab270:	bl	0x101acdcc0 ; selector frame
1004ab274:	fmov	d0, #16.00000000
1004ab278:	mov	x0, x19
1004ab27c:	mov.16b	v1, v8
1004ab280:	bl	0x101ad2b80 ; selector setFrame:
1004ab284:	mov	x0, x19
1004ab288:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab28c:	mov	x0, x19
1004ab290:	mov	w2, #0x0
1004ab294:	bl	0x101ad28e0 ; selector setEditable:
1004ab298:	mov	x0, x19
1004ab29c:	mov	w2, #0x0
1004ab2a0:	bl	0x101ad1fa0 ; selector setBordered:
1004ab2a4:	mov	x0, x19
1004ab2a8:	mov	w2, #0x0
1004ab2ac:	bl	0x101ad2860 ; selector setDrawsBackground:
1004ab2b0:	mov	x0, x20
1004ab2b4:	mov	x2, x19
1004ab2b8:	bl	0x101acb460 ; selector addSubview:
1004ab2bc:	mov	x0, x19
1004ab2c0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab2c4:	ldr	x0, [sp, #0x70]
1004ab2c8:	mov	x2, x20
1004ab2cc:	bl	0x101acb460 ; selector addSubview:
1004ab2d0:	mov	x0, x20
1004ab2d4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab2d8:	mov	x0, x27
1004ab2dc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ab2e0:	ldr	x0, [sp, #0x50]
1004ab2e4:	mov	w1, #0x2
1004ab2e8:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004ab2ec:	mov	x0, x28
1004ab2f0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ab2f4:	mov	x0, x24
1004ab2f8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab2fc:	fmov	d11, #28.00000000
1004ab300:	b	0x1004aaa18
1004ab304:	mov	x0, x25
1004ab308:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ab30c:	fmov	d0, #4.00000000
1004ab310:	fadd	d9, d12, d0
1004ab314:	ldr	d8, [sp, #0x40]
1004ab318:	b	0x1004ab328
1004ab31c:	mov	x0, x25
1004ab320:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ab324:	fmov	d9, #8.00000000
1004ab328:	ldr	x0, [sp, #0x70]
1004ab32c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ab330:	mov	x19, x0
1004ab334:	bl	0x101acdcc0 ; selector frame
1004ab338:	mov	x0, x19
1004ab33c:	mov.16b	v3, v9
1004ab340:	bl	0x101ad2b80 ; selector setFrame:
1004ab344:	adrp	x8, 7803 ; 0x102326000
1004ab348:	ldr	x0, [x8, #0xa28] ; Objc class ref: _OBJC_CLASS_$_NSPanel
1004ab34c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004ab350:	movi.2d	v0, #0000000000000000
1004ab354:	movi.2d	v1, #0000000000000000
1004ab358:	mov.16b	v2, v8
1004ab35c:	mov.16b	v3, v9
1004ab360:	mov	w2, #0x80
1004ab364:	mov	w3, #0x2
1004ab368:	mov	w4, #0x0
1004ab36c:	bl	0x101ace420 ; selector initWithContentRect:styleMask:backing:defer:
1004ab370:	mov	x20, x0
1004ab374:	mov	w22, #0x1
1004ab378:	mov	w2, #0x1
1004ab37c:	bl	0x101ad2a60 ; selector setFloatingPanel:
1004ab380:	mov	x0, x20
1004ab384:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ab388:	mov	x20, x0
1004ab38c:	mov	w2, #0x65
1004ab390:	bl	0x101ad3320 ; selector setLevel:
1004ab394:	mov	x0, x20
1004ab398:	mov	w2, #0x0
1004ab39c:	bl	0x101ad3980 ; selector setOpaque:
1004ab3a0:	adrp	x8, 7803 ; 0x102326000
1004ab3a4:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004ab3a8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004ab3ac:	bl	0x101acc200 ; selector clearColor
1004ab3b0:	mov	x29, x29
1004ab3b4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ab3b8:	mov	x21, x0
1004ab3bc:	mov	x0, x20
1004ab3c0:	mov	x2, x21
1004ab3c4:	bl	0x101ad1e00 ; selector setBackgroundColor:
1004ab3c8:	mov	x0, x21
1004ab3cc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab3d0:	bl	_$s9TextStory09BufferingA7StorageC16bufferingEnabledSbvpfi
1004ab3d4:	bic	w2, w22, w0
1004ab3d8:	mov	x0, x20
1004ab3dc:	bl	0x101ad2d20 ; selector setHasShadow:
1004ab3e0:	fmov	d2, #8.00000000
1004ab3e4:	mov.16b	v0, v8
1004ab3e8:	mov.16b	v1, v9
1004ab3ec:	bl	0x1004ad2c4
1004ab3f0:	mov	x22, x0
1004ab3f4:	mov	x21, x1
1004ab3f8:	mov	x0, x1
1004ab3fc:	mov	x2, x19
1004ab400:	bl	0x101acb460 ; selector addSubview:
1004ab404:	movi.2d	v0, #0000000000000000
1004ab408:	movi.2d	v1, #0000000000000000
1004ab40c:	mov	x0, x19
1004ab410:	mov.16b	v2, v8
1004ab414:	mov.16b	v3, v9
1004ab418:	bl	0x101ad2b80 ; selector setFrame:
1004ab41c:	mov	x0, x19
1004ab420:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab424:	mov	x0, x20
1004ab428:	mov	x2, x22
1004ab42c:	bl	0x101ad2340 ; selector setContentView:
1004ab430:	mov	x0, x20
1004ab434:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab438:	ldr	x0, [sp, #0x60]
1004ab43c:	bl	0x101ad6200 ; selector window
1004ab440:	mov	x29, x29
1004ab444:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ab448:	cbz	x0, 0x1004ab5f8
1004ab44c:	mov	x23, x0
1004ab450:	bl	0x101ad1140 ; selector screen
1004ab454:	mov	x29, x29
1004ab458:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ab45c:	cbnz	x0, 0x1004ab47c
1004ab460:	adrp	x8, 7803 ; 0x102326000
1004ab464:	ldr	x0, [x8, #0xa18] ; Objc class ref: _OBJC_CLASS_$_NSScreen
1004ab468:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004ab46c:	bl	0x101acf6a0 ; selector mainScreen
1004ab470:	mov	x29, x29
1004ab474:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ab478:	cbz	x0, 0x1004ab5f0
1004ab47c:	mov	x24, x0
1004ab480:	str	d9, [sp, #0x70]
1004ab484:	ldr	x25, [sp, #0x60]
1004ab488:	mov	x0, x25
1004ab48c:	bl	0x101acbde0 ; selector bounds
1004ab490:	mov	x0, x25
1004ab494:	mov	x2, #0x0
1004ab498:	bl	0x101acc9c0 ; selector convertRect:toView:
1004ab49c:	mov	x0, x23
1004ab4a0:	bl	0x101acca00 ; selector convertRectToScreen:
1004ab4a4:	mov.16b	v15, v0
1004ab4a8:	mov.16b	v8, v1
1004ab4ac:	mov.16b	v14, v2
1004ab4b0:	mov.16b	v9, v3
1004ab4b4:	mov	x0, x24
1004ab4b8:	bl	0x101ad6080 ; selector visibleFrame
1004ab4bc:	mov.16b	v11, v0
1004ab4c0:	str	d1, [sp, #0x50]
1004ab4c4:	mov.16b	v12, v2
1004ab4c8:	mov.16b	v13, v3
1004ab4cc:	mov.16b	v0, v15
1004ab4d0:	mov.16b	v1, v8
1004ab4d4:	mov.16b	v2, v14
1004ab4d8:	mov.16b	v3, v9
1004ab4dc:	bl	0x101ac8d70 ; symbol stub for: _CGRectGetMaxX
1004ab4e0:	fmov	d1, #2.00000000
1004ab4e4:	fadd	d1, d0, d1
1004ab4e8:	ldr	d0, [sp, #0x40]
1004ab4ec:	str	d1, [sp, #0x78]
1004ab4f0:	fadd	d10, d0, d1
1004ab4f4:	str	d11, [sp, #0x68]
1004ab4f8:	mov.16b	v0, v11
1004ab4fc:	ldr	d11, [sp, #0x50]
1004ab500:	mov.16b	v1, v11
1004ab504:	mov.16b	v2, v12
1004ab508:	mov.16b	v3, v13
1004ab50c:	bl	0x101ac8d70 ; symbol stub for: _CGRectGetMaxX
1004ab510:	fcmp	d0, d10
1004ab514:	ldr	d10, [sp, #0x40]
1004ab518:	b.pl	0x1004ab540
1004ab51c:	mov.16b	v0, v15
1004ab520:	mov.16b	v1, v8
1004ab524:	mov.16b	v2, v14
1004ab528:	mov.16b	v3, v9
1004ab52c:	bl	0x101ac8da0 ; symbol stub for: _CGRectGetMinX
1004ab530:	fsub	d0, d0, d10
1004ab534:	fmov	d1, #-2.00000000
1004ab538:	fadd	d0, d0, d1
1004ab53c:	str	d0, [sp, #0x78]
1004ab540:	mov.16b	v0, v15
1004ab544:	mov.16b	v1, v8
1004ab548:	mov.16b	v2, v14
1004ab54c:	mov.16b	v3, v9
1004ab550:	bl	0x101ac8d7c ; symbol stub for: _CGRectGetMaxY
1004ab554:	ldp	d15, d14, [sp, #0x68]
1004ab558:	fsub	d8, d0, d14
1004ab55c:	mov.16b	v0, v15
1004ab560:	mov.16b	v1, v11
1004ab564:	mov.16b	v2, v12
1004ab568:	mov.16b	v3, v13
1004ab56c:	bl	0x101ac8dac ; symbol stub for: _CGRectGetMinY
1004ab570:	fcmp	d8, d0
1004ab574:	b.pl	0x1004ab590
1004ab578:	mov.16b	v0, v15
1004ab57c:	mov.16b	v1, v11
1004ab580:	mov.16b	v2, v12
1004ab584:	mov.16b	v3, v13
1004ab588:	bl	0x101ac8dac ; symbol stub for: _CGRectGetMinY
1004ab58c:	mov.16b	v8, v0
1004ab590:	fadd	d9, d14, d8
1004ab594:	mov.16b	v0, v15
1004ab598:	mov.16b	v1, v11
1004ab59c:	mov.16b	v2, v12
1004ab5a0:	mov.16b	v3, v13
1004ab5a4:	bl	0x101ac8d7c ; symbol stub for: _CGRectGetMaxY
1004ab5a8:	fcmp	d0, d9
1004ab5ac:	b.pl	0x1004ab5c8
1004ab5b0:	mov.16b	v0, v15
1004ab5b4:	mov.16b	v1, v11
1004ab5b8:	mov.16b	v2, v12
1004ab5bc:	mov.16b	v3, v13
1004ab5c0:	bl	0x101ac8d7c ; symbol stub for: _CGRectGetMaxY
1004ab5c4:	fsub	d8, d0, d14
1004ab5c8:	ldr	d0, [sp, #0x78]
1004ab5cc:	mov.16b	v1, v8
1004ab5d0:	mov.16b	v2, v10
1004ab5d4:	mov.16b	v3, v14
1004ab5d8:	bl	0x1004ad2a8
1004ab5dc:	mov	x0, x20
1004ab5e0:	mov	w2, #0x1
1004ab5e4:	bl	0x101ad2ba0 ; selector setFrame:display:
1004ab5e8:	mov	x0, x24
1004ab5ec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab5f0:	mov	x0, x23
1004ab5f4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab5f8:	mov	x0, x20
1004ab5fc:	mov	x2, #0x0
1004ab600:	bl	0x101acfe40 ; selector orderFront:
1004ab604:	ldr	x0, [sp, #0x48]
1004ab608:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab60c:	mov	x0, x19
1004ab610:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab614:	mov	x0, x22
1004ab618:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab61c:	mov	x0, x21
1004ab620:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab624:	adrp	x8, 7849 ; 0x102354000
1004ab628:	ldr	x8, [x8, #0xea0]
1004ab62c:	ldr	x9, [sp, #0x60]
1004ab630:	ldr	x0, [x9, x8]
1004ab634:	str	x20, [x9, x8]
1004ab638:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab63c:	ldp	x29, x30, [sp, #0x160]
1004ab640:	ldp	x20, x19, [sp, #0x150]
1004ab644:	ldp	x22, x21, [sp, #0x140]
1004ab648:	ldp	x24, x23, [sp, #0x130]
1004ab64c:	ldp	x26, x25, [sp, #0x120]
1004ab650:	ldp	x28, x27, [sp, #0x110]
1004ab654:	ldp	d9, d8, [sp, #0x100]
1004ab658:	ldp	d11, d10, [sp, #0xf0]
1004ab65c:	ldp	d13, d12, [sp, #0xe0]
1004ab660:	ldp	d15, d14, [sp, #0xd0]
1004ab664:	add	sp, sp, #0x170
1004ab668:	ret
1004ab66c:	brk	#0x1
1004ab670:	adrp	x0, 7921 ; 0x10239c000
1004ab674:	add	x0, x0, #0xf20
1004ab678:	adrp	x1, -2 ; 0x1004a9000
1004ab67c:	add	x1, x1, #0x960
1004ab680:	bl	0x101aca948 ; symbol stub for: _swift_once
1004ab684:	b	0x1004aa6c8
1004ab688:	stp	x20, x19, [sp, #-0x20]!
1004ab68c:	stp	x29, x30, [sp, #0x10]
1004ab690:	add	x29, sp, #0x10
1004ab694:	mov	x19, x0
1004ab698:	bl	0x1004a9fc4
1004ab69c:	mov	x0, x20
1004ab6a0:	bl	0x101acbde0 ; selector bounds
1004ab6a4:	mov	x0, x20
1004ab6a8:	bl	0x101ad3820 ; selector setNeedsDisplayInRect:
1004ab6ac:	tbz	w19, #0x0, 0x1004ab6bc
1004ab6b0:	ldp	x29, x30, [sp, #0x10]
1004ab6b4:	ldp	x20, x19, [sp], #0x20
1004ab6b8:	b	0x1004aa648
1004ab6bc:	adrp	x8, 7849 ; 0x102354000
1004ab6c0:	ldr	x19, [x8, #0xea0]
1004ab6c4:	ldr	x0, [x20, x19]
1004ab6c8:	cbz	x0, 0x1004ab6d8
1004ab6cc:	mov	x2, #0x0
1004ab6d0:	bl	0x101acfec0 ; selector orderOut:
1004ab6d4:	ldr	x0, [x20, x19]
1004ab6d8:	str	xzr, [x20, x19]
1004ab6dc:	ldp	x29, x30, [sp, #0x10]
1004ab6e0:	ldp	x20, x19, [sp], #0x20
1004ab6e4:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004ab6e8:	b	0x1004aa648
1004ab6ec:	sub	sp, sp, #0x40
1004ab6f0:	stp	d11, d10, [sp, #0x10]
1004ab6f4:	stp	d9, d8, [sp, #0x20]
1004ab6f8:	stp	x29, x30, [sp, #0x30]
1004ab6fc:	add	x29, sp, #0x30
1004ab700:	mov.16b	v8, v3
1004ab704:	mov.16b	v9, v2
1004ab708:	mov.16b	v10, v1
1004ab70c:	mov.16b	v11, v0
1004ab710:	adrp	x8, 7849 ; 0x102354000
1004ab714:	ldr	x8, [x8, #0xea8]
1004ab718:	str	xzr, [x20, x8]
1004ab71c:	adrp	x8, 7849 ; 0x102354000
1004ab720:	ldr	x8, [x8, #0xeb0]
1004ab724:	str	xzr, [x20, x8]
1004ab728:	adrp	x8, 7849 ; 0x102354000
1004ab72c:	ldr	x8, [x8, #0xeb8]
1004ab730:	add	x8, x20, x8
1004ab734:	stp	xzr, xzr, [x8]
1004ab738:	adrp	x8, 7849 ; 0x102354000
1004ab73c:	ldr	x8, [x8, #0xec0]
1004ab740:	add	x8, x20, x8
1004ab744:	stp	xzr, xzr, [x8]
1004ab748:	adrp	x8, 7849 ; 0x102354000
1004ab74c:	ldr	x8, [x8, #0xec8]
1004ab750:	str	xzr, [x20, x8]
1004ab754:	adrp	x8, 7849 ; 0x102354000
1004ab758:	ldr	x8, [x8, #0xed0]
1004ab75c:	adrp	x9, 7716 ; 0x1022cf000
1004ab760:	ldr	x9, [x9, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004ab764:	str	x9, [x20, x8]
1004ab768:	adrp	x8, 7849 ; 0x102354000
1004ab76c:	ldr	x8, [x8, #0xee8]
1004ab770:	strb	wzr, [x20, x8]
1004ab774:	adrp	x8, 7849 ; 0x102354000
1004ab778:	ldr	x8, [x8, #0xed8]
1004ab77c:	add	x0, x20, x8
1004ab780:	mov	x1, #0x0
1004ab784:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004ab788:	adrp	x8, 7849 ; 0x102354000
1004ab78c:	ldr	x8, [x8, #0xea0]
1004ab790:	str	xzr, [x20, x8]
1004ab794:	adrp	x8, 7849 ; 0x102354000
1004ab798:	ldr	x8, [x8, #0xee0]
1004ab79c:	str	xzr, [x20, x8]
1004ab7a0:	adrp	x8, 7849 ; 0x102354000
1004ab7a4:	ldr	x8, [x8, #0xef0]
1004ab7a8:	mov	x9, #0x4030000000000000
1004ab7ac:	str	x9, [x20, x8]
1004ab7b0:	bl	0x1004ad03c
1004ab7b4:	stp	x20, x0, [sp]
1004ab7b8:	adrp	x8, 7800 ; 0x102323000
1004ab7bc:	ldr	x1, [x8, #0x50] ; Objc selector ref: initWithFrame:
1004ab7c0:	mov	x0, sp
1004ab7c4:	mov.16b	v0, v11
1004ab7c8:	mov.16b	v1, v10
1004ab7cc:	mov.16b	v2, v9
1004ab7d0:	mov.16b	v3, v8
1004ab7d4:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithFrame:]
1004ab7d8:	ldp	x29, x30, [sp, #0x30]
1004ab7dc:	ldp	d9, d8, [sp, #0x20]
1004ab7e0:	ldp	d11, d10, [sp, #0x10]
1004ab7e4:	add	sp, sp, #0x40
1004ab7e8:	ret
1004ab7ec:	stp	x20, x19, [sp, #-0x20]!
1004ab7f0:	stp	x29, x30, [sp, #0x10]
1004ab7f4:	add	x29, sp, #0x10
1004ab7f8:	mov	x20, x0
1004ab7fc:	bl	0x1004ab6ec
1004ab800:	ldp	x29, x30, [sp, #0x10]
1004ab804:	ldp	x20, x19, [sp], #0x20
1004ab808:	ret
1004ab80c:	sub	sp, sp, #0x30
1004ab810:	stp	x20, x19, [sp, #0x10]
1004ab814:	stp	x29, x30, [sp, #0x20]
1004ab818:	add	x29, sp, #0x20
1004ab81c:	mov	x19, x0
1004ab820:	adrp	x8, 7849 ; 0x102354000
1004ab824:	ldr	x8, [x8, #0xea8]
1004ab828:	str	xzr, [x20, x8]
1004ab82c:	adrp	x8, 7849 ; 0x102354000
1004ab830:	ldr	x8, [x8, #0xeb0]
1004ab834:	str	xzr, [x20, x8]
1004ab838:	adrp	x8, 7849 ; 0x102354000
1004ab83c:	ldr	x8, [x8, #0xeb8]
1004ab840:	add	x8, x20, x8
1004ab844:	stp	xzr, xzr, [x8]
1004ab848:	adrp	x8, 7849 ; 0x102354000
1004ab84c:	ldr	x8, [x8, #0xec0]
1004ab850:	add	x8, x20, x8
1004ab854:	stp	xzr, xzr, [x8]
1004ab858:	adrp	x8, 7849 ; 0x102354000
1004ab85c:	ldr	x8, [x8, #0xec8]
1004ab860:	str	xzr, [x20, x8]
1004ab864:	adrp	x8, 7849 ; 0x102354000
1004ab868:	ldr	x8, [x8, #0xed0]
1004ab86c:	adrp	x9, 7716 ; 0x1022cf000
1004ab870:	ldr	x9, [x9, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004ab874:	str	x9, [x20, x8]
1004ab878:	adrp	x8, 7849 ; 0x102354000
1004ab87c:	ldr	x8, [x8, #0xee8]
1004ab880:	strb	wzr, [x20, x8]
1004ab884:	adrp	x8, 7849 ; 0x102354000
1004ab888:	ldr	x8, [x8, #0xed8]
1004ab88c:	add	x0, x20, x8
1004ab890:	mov	x1, #0x0
1004ab894:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004ab898:	adrp	x8, 7849 ; 0x102354000
1004ab89c:	ldr	x8, [x8, #0xea0]
1004ab8a0:	str	xzr, [x20, x8]
1004ab8a4:	adrp	x8, 7849 ; 0x102354000
1004ab8a8:	ldr	x8, [x8, #0xee0]
1004ab8ac:	str	xzr, [x20, x8]
1004ab8b0:	adrp	x8, 7849 ; 0x102354000
1004ab8b4:	ldr	x8, [x8, #0xef0]
1004ab8b8:	mov	x9, #0x4030000000000000
1004ab8bc:	str	x9, [x20, x8]
1004ab8c0:	bl	0x1004ad03c
1004ab8c4:	stp	x20, x0, [sp]
1004ab8c8:	adrp	x8, 7799 ; 0x102322000
1004ab8cc:	ldr	x1, [x8, #0xfd8] ; Objc selector ref: initWithCoder:
1004ab8d0:	mov	x0, sp
1004ab8d4:	mov	x2, x19
1004ab8d8:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithCoder:]
1004ab8dc:	mov	x29, x29
1004ab8e0:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ab8e4:	mov	x20, x0
1004ab8e8:	mov	x0, x19
1004ab8ec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab8f0:	cbz	x20, 0x1004ab8fc
1004ab8f4:	mov	x0, x20
1004ab8f8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ab8fc:	mov	x0, x20
1004ab900:	ldp	x29, x30, [sp, #0x20]
1004ab904:	ldp	x20, x19, [sp, #0x10]
1004ab908:	add	sp, sp, #0x30
1004ab90c:	ret
1004ab910:	stp	x20, x19, [sp, #-0x20]!
1004ab914:	stp	x29, x30, [sp, #0x10]
1004ab918:	add	x29, sp, #0x10
1004ab91c:	mov	x20, x0
1004ab920:	mov	x0, x2
1004ab924:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ab928:	bl	0x1004ab80c
1004ab92c:	ldp	x29, x30, [sp, #0x10]
1004ab930:	ldp	x20, x19, [sp], #0x20
1004ab934:	ret
1004ab938:	adrp	x0, 7849 ; 0x102354000
1004ab93c:	add	x0, x0, #0xef8
1004ab940:	adrp	x1, 2 ; 0x1004ad000
1004ab944:	add	x1, x1, #0x5c
1004ab948:	b	0x1004ab94c
1004ab94c:	sub	sp, sp, #0x30
1004ab950:	stp	x20, x19, [sp, #0x10]
1004ab954:	stp	x29, x30, [sp, #0x20]
1004ab958:	add	x29, sp, #0x20
1004ab95c:	mov	x19, x1
1004ab960:	ldr	x8, [x0]
1004ab964:	ldr	x0, [x20, x8]
1004ab968:	cbz	x0, 0x1004ab974
1004ab96c:	mov	x2, #0x0
1004ab970:	bl	0x101acfec0 ; selector orderOut:
1004ab974:	blr	x19
1004ab978:	stp	x20, x0, [sp]
1004ab97c:	adrp	x8, 7798 ; 0x102321000
1004ab980:	ldr	x1, [x8, #0x2d8] ; Objc selector ref: dealloc
1004ab984:	mov	x0, sp
1004ab988:	bl	0x101ac9d0c ; Objc message: -[[x0 super] dealloc]
1004ab98c:	ldp	x29, x30, [sp, #0x20]
1004ab990:	ldp	x20, x19, [sp, #0x10]
1004ab994:	add	sp, sp, #0x30
1004ab998:	ret
1004ab99c:	adrp	x2, 7849 ; 0x102354000
1004ab9a0:	add	x2, x2, #0xef8
1004ab9a4:	adrp	x3, 2 ; 0x1004ad000
1004ab9a8:	add	x3, x3, #0x5c
1004ab9ac:	b	0x1004ab9b0
1004ab9b0:	sub	sp, sp, #0x40
1004ab9b4:	stp	x22, x21, [sp, #0x10]
1004ab9b8:	stp	x20, x19, [sp, #0x20]
1004ab9bc:	stp	x29, x30, [sp, #0x30]
1004ab9c0:	add	x29, sp, #0x30
1004ab9c4:	mov	x20, x3
1004ab9c8:	mov	x19, x0
1004ab9cc:	ldr	x8, [x2]
1004ab9d0:	ldr	x21, [x0, x8]
1004ab9d4:	cbz	x21, 0x1004ab9f0
1004ab9d8:	mov	x0, x19
1004ab9dc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ab9e0:	mov	x0, x21
1004ab9e4:	mov	x2, #0x0
1004ab9e8:	bl	0x101acfec0 ; selector orderOut:
1004ab9ec:	b	0x1004ab9f8
1004ab9f0:	mov	x0, x19
1004ab9f4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ab9f8:	blr	x20
1004ab9fc:	stp	x19, x0, [sp]
1004aba00:	adrp	x8, 7798 ; 0x102321000
1004aba04:	ldr	x1, [x8, #0x2d8] ; Objc selector ref: dealloc
1004aba08:	mov	x0, sp
1004aba0c:	bl	0x101ac9d0c ; Objc message: -[[x0 super] dealloc]
1004aba10:	ldp	x29, x30, [sp, #0x30]
1004aba14:	ldp	x20, x19, [sp, #0x20]
1004aba18:	ldp	x22, x21, [sp, #0x10]
1004aba1c:	add	sp, sp, #0x40
1004aba20:	ret
1004aba24:	stp	x20, x19, [sp, #-0x20]!
1004aba28:	stp	x29, x30, [sp, #0x10]
1004aba2c:	add	x29, sp, #0x10
1004aba30:	mov	x19, x0
1004aba34:	adrp	x8, 7849 ; 0x102354000
1004aba38:	ldr	x8, [x8, #0xf00]
1004aba3c:	ldr	x0, [x0, x8]
1004aba40:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aba44:	adrp	x8, 7849 ; 0x102354000
1004aba48:	ldr	x8, [x8, #0xf08]
1004aba4c:	ldr	x0, [x19, x8]
1004aba50:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aba54:	adrp	x8, 7849 ; 0x102354000
1004aba58:	ldr	x8, [x8, #0xf10]
1004aba5c:	ldr	x0, [x19, x8]
1004aba60:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aba64:	adrp	x8, 7849 ; 0x102354000
1004aba68:	ldr	x8, [x8, #0xf18]
1004aba6c:	ldr	x0, [x19, x8]
1004aba70:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aba74:	adrp	x8, 7849 ; 0x102354000
1004aba78:	ldr	x8, [x8, #0xf20]
1004aba7c:	ldr	x0, [x19, x8]
1004aba80:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aba84:	adrp	x8, 7849 ; 0x102354000
1004aba88:	ldr	x8, [x8, #0xf28]
1004aba8c:	add	x0, x19, x8
1004aba90:	bl	0x101acaabc ; symbol stub for: _swift_unknownObjectWeakDestroy
1004aba94:	adrp	x8, 7849 ; 0x102354000
1004aba98:	ldr	x8, [x8, #0xef8]
1004aba9c:	ldr	x0, [x19, x8]
1004abaa0:	ldp	x29, x30, [sp, #0x10]
1004abaa4:	ldp	x20, x19, [sp], #0x20
1004abaa8:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004abaac:	stp	d11, d10, [sp, #-0x60]!
1004abab0:	stp	d9, d8, [sp, #0x10]
1004abab4:	stp	x24, x23, [sp, #0x20]
1004abab8:	stp	x22, x21, [sp, #0x30]
1004ababc:	stp	x20, x19, [sp, #0x40]
1004abac0:	stp	x29, x30, [sp, #0x50]
1004abac4:	add	x29, sp, #0x50
1004abac8:	mov	x19, x3
1004abacc:	mov	x21, x2
1004abad0:	mov.16b	v10, v2
1004abad4:	mov.16b	v9, v1
1004abad8:	mov.16b	v8, v0
1004abadc:	mov	x22, x1
1004abae0:	mov	x23, x0
1004abae4:	adrp	x8, 7849 ; 0x102354000
1004abae8:	ldr	x8, [x8, #0xf20]
1004abaec:	ldr	x0, [x20, x8]
1004abaf0:	str	x2, [x20, x8]
1004abaf4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004abaf8:	adrp	x8, 7849 ; 0x102354000
1004abafc:	ldr	x8, [x8, #0xf28]
1004abb00:	add	x0, x20, x8
1004abb04:	mov	x1, x19
1004abb08:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004abb0c:	adrp	x8, 7849 ; 0x102354000
1004abb10:	ldr	x8, [x8, #0xf30]
1004abb14:	str	d9, [x20, x8]
1004abb18:	adrp	x8, 7849 ; 0x102354000
1004abb1c:	ldr	x8, [x8, #0xf38]
1004abb20:	str	d10, [x20, x8]
1004abb24:	adrp	x8, 7849 ; 0x102354000
1004abb28:	ldr	x8, [x8, #0xf40]
1004abb2c:	str	d8, [x20, x8]
1004abb30:	mov	x0, x21
1004abb34:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004abb38:	mov	x0, x23
1004abb3c:	mov	x1, x22
1004abb40:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004abb44:	mov	x19, x0
1004abb48:	adrp	x8, 7803 ; 0x102326000
1004abb4c:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004abb50:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004abb54:	mov	x21, x0
1004abb58:	mov	x2, x19
1004abb5c:	bl	0x101acf240 ; selector labelWithString:
1004abb60:	mov	x29, x29
1004abb64:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004abb68:	mov	x22, x0
1004abb6c:	mov	x0, x19
1004abb70:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abb74:	mov	x0, x22
1004abb78:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004abb7c:	mov	x19, x0
1004abb80:	bl	0x10002dd04
1004abb84:	mov.16b	v1, v0
1004abb88:	fmov	d0, #13.00000000
1004abb8c:	bl	0x100004700
1004abb90:	mov	x22, x0
1004abb94:	mov	x0, x19
1004abb98:	mov	x2, x22
1004abb9c:	bl	0x101ad2aa0 ; selector setFont:
1004abba0:	mov	x0, x19
1004abba4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abba8:	mov	x0, x22
1004abbac:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abbb0:	adrp	x8, 7803 ; 0x102326000
1004abbb4:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004abbb8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004abbbc:	mov	x22, x0
1004abbc0:	bl	0x101acf220 ; selector labelColor
1004abbc4:	mov	x29, x29
1004abbc8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004abbcc:	mov	x23, x0
1004abbd0:	mov	x0, x19
1004abbd4:	mov	x2, x23
1004abbd8:	bl	0x101ad4660 ; selector setTextColor:
1004abbdc:	mov	x0, x23
1004abbe0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abbe4:	fsub	d0, d8, d9
1004abbe8:	mov	x8, #-0x3fc0000000000000
1004abbec:	fmov	d1, x8
1004abbf0:	fadd	d10, d0, d1
1004abbf4:	mov	x0, x19
1004abbf8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004abbfc:	mov	x19, x0
1004abc00:	mov	x0, x20
1004abc04:	bl	0x101acbde0 ; selector bounds
1004abc08:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004abc0c:	mov.16b	v3, v0
1004abc10:	movi.2d	v1, #0000000000000000
1004abc14:	mov	x0, x19
1004abc18:	mov.16b	v0, v9
1004abc1c:	mov.16b	v2, v10
1004abc20:	bl	0x101ad2b80 ; selector setFrame:
1004abc24:	mov	x0, x19
1004abc28:	mov	w2, #0x0
1004abc2c:	bl	0x101ad28e0 ; selector setEditable:
1004abc30:	mov	x0, x19
1004abc34:	mov	w2, #0x0
1004abc38:	bl	0x101ad1fa0 ; selector setBordered:
1004abc3c:	mov	x0, x19
1004abc40:	mov	w2, #0x0
1004abc44:	bl	0x101ad2860 ; selector setDrawsBackground:
1004abc48:	mov	x0, x20
1004abc4c:	mov	x2, x19
1004abc50:	bl	0x101acb460 ; selector addSubview:
1004abc54:	adrp	x8, 7849 ; 0x102354000
1004abc58:	ldr	x8, [x8, #0xf00]
1004abc5c:	ldr	x23, [x20, x8]
1004abc60:	str	x19, [x20, x8]
1004abc64:	mov	x0, x19
1004abc68:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004abc6c:	mov	x19, x0
1004abc70:	mov	x0, x23
1004abc74:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abc78:	mov	x0, x19
1004abc7c:	bl	0x101ad4fe0 ; selector sizeToFit
1004abc80:	mov	x0, x20
1004abc84:	bl	0x101acbde0 ; selector bounds
1004abc88:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004abc8c:	mov.16b	v9, v0
1004abc90:	mov	x0, x19
1004abc94:	bl	0x101acdcc0 ; selector frame
1004abc98:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004abc9c:	fsub	d0, d9, d0
1004abca0:	fmov	d11, #0.50000000
1004abca4:	fmul	d9, d0, d11
1004abca8:	mov	x0, x19
1004abcac:	bl	0x101acdcc0 ; selector frame
1004abcb0:	mov	x0, x19
1004abcb4:	mov.16b	v1, v9
1004abcb8:	bl	0x101ad2b80 ; selector setFrame:
1004abcbc:	mov	x0, x19
1004abcc0:	bl	0x101acdcc0 ; selector frame
1004abcc4:	mov	x0, x19
1004abcc8:	mov.16b	v2, v10
1004abccc:	bl	0x101ad2b80 ; selector setFrame:
1004abcd0:	mov	x0, x19
1004abcd4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abcd8:	mov	w0, #0x80e2
1004abcdc:	movk	w0, #0xba, lsl #16
1004abce0:	mov	x1, #-0x5d00000000000000
1004abce4:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004abce8:	mov	x23, x0
1004abcec:	mov	x0, x21
1004abcf0:	mov	x2, x23
1004abcf4:	bl	0x101acf240 ; selector labelWithString:
1004abcf8:	mov	x29, x29
1004abcfc:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004abd00:	mov	x21, x0
1004abd04:	mov	x0, x23
1004abd08:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abd0c:	mov	x0, x21
1004abd10:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004abd14:	mov	x21, x0
1004abd18:	bl	0x10002dd04
1004abd1c:	mov.16b	v1, v0
1004abd20:	fmov	d0, #14.00000000
1004abd24:	bl	0x100004700
1004abd28:	mov	x23, x0
1004abd2c:	mov	x0, x21
1004abd30:	mov	x2, x23
1004abd34:	bl	0x101ad2aa0 ; selector setFont:
1004abd38:	mov	x0, x23
1004abd3c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abd40:	mov	x0, x22
1004abd44:	bl	0x101ad58a0 ; selector tertiaryLabelColor
1004abd48:	mov	x29, x29
1004abd4c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004abd50:	mov	x22, x0
1004abd54:	mov	x0, x21
1004abd58:	mov	x2, x22
1004abd5c:	bl	0x101ad4660 ; selector setTextColor:
1004abd60:	mov	x0, x22
1004abd64:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abd68:	mov	x0, x21
1004abd6c:	mov	w2, #0x2
1004abd70:	bl	0x101ad1820 ; selector setAlignment:
1004abd74:	mov	x0, x21
1004abd78:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abd7c:	mov	x0, x21
1004abd80:	mov	w2, #0x0
1004abd84:	bl	0x101ad28e0 ; selector setEditable:
1004abd88:	mov	x0, x21
1004abd8c:	mov	w2, #0x0
1004abd90:	bl	0x101ad1fa0 ; selector setBordered:
1004abd94:	mov	x0, x21
1004abd98:	mov	w2, #0x0
1004abd9c:	bl	0x101ad2860 ; selector setDrawsBackground:
1004abda0:	mov	x0, x21
1004abda4:	bl	0x101ad4fe0 ; selector sizeToFit
1004abda8:	fmov	d0, #-16.00000000
1004abdac:	fadd	d0, d8, d0
1004abdb0:	fmov	d1, #-12.00000000
1004abdb4:	fadd	d8, d0, d1
1004abdb8:	mov	x0, x21
1004abdbc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004abdc0:	mov	x21, x0
1004abdc4:	mov	x0, x20
1004abdc8:	bl	0x101acbde0 ; selector bounds
1004abdcc:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004abdd0:	mov.16b	v9, v0
1004abdd4:	mov	x0, x21
1004abdd8:	bl	0x101acdcc0 ; selector frame
1004abddc:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004abde0:	fsub	d0, d9, d0
1004abde4:	fmul	d9, d0, d11
1004abde8:	mov	x0, x21
1004abdec:	bl	0x101acdcc0 ; selector frame
1004abdf0:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004abdf4:	mov.16b	v3, v0
1004abdf8:	fmov	d2, #16.00000000
1004abdfc:	mov	x0, x21
1004abe00:	mov.16b	v0, v8
1004abe04:	mov.16b	v1, v9
1004abe08:	bl	0x101ad2b80 ; selector setFrame:
1004abe0c:	mov	x0, x21
1004abe10:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abe14:	mov	x0, x20
1004abe18:	mov	x2, x21
1004abe1c:	bl	0x101acb460 ; selector addSubview:
1004abe20:	mov	x0, x19
1004abe24:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abe28:	adrp	x8, 7849 ; 0x102354000
1004abe2c:	ldr	x8, [x8, #0xf08]
1004abe30:	ldr	x0, [x20, x8]
1004abe34:	str	x21, [x20, x8]
1004abe38:	ldp	x29, x30, [sp, #0x50]
1004abe3c:	ldp	x20, x19, [sp, #0x40]
1004abe40:	ldp	x22, x21, [sp, #0x30]
1004abe44:	ldp	x24, x23, [sp, #0x20]
1004abe48:	ldp	d9, d8, [sp, #0x10]
1004abe4c:	ldp	d11, d10, [sp], #0x60
1004abe50:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004abe54:	adrp	x0, 2 ; 0x1004ad000
1004abe58:	add	x0, x0, #0x5c
1004abe5c:	adrp	x1, 7849 ; 0x102354000
1004abe60:	add	x1, x1, #0xf10
1004abe64:	b	0x1004abe68
1004abe68:	sub	sp, sp, #0x60
1004abe6c:	stp	d11, d10, [sp, #0x10]
1004abe70:	stp	d9, d8, [sp, #0x20]
1004abe74:	stp	x22, x21, [sp, #0x30]
1004abe78:	stp	x20, x19, [sp, #0x40]
1004abe7c:	stp	x29, x30, [sp, #0x50]
1004abe80:	add	x29, sp, #0x50
1004abe84:	mov	x19, x1
1004abe88:	blr	x0
1004abe8c:	stp	x20, x0, [sp]
1004abe90:	adrp	x8, 7801 ; 0x102324000
1004abe94:	ldr	x1, [x8, #0xea8] ; Objc selector ref: updateTrackingAreas
1004abe98:	mov	x0, sp
1004abe9c:	bl	0x101ac9d0c ; Objc message: -[[x0 super] updateTrackingAreas]
1004abea0:	ldr	x21, [x19]
1004abea4:	ldr	x2, [x20, x21]
1004abea8:	cbz	x2, 0x1004abeb4
1004abeac:	mov	x0, x20
1004abeb0:	bl	0x101ad0c40 ; selector removeTrackingArea:
1004abeb4:	mov	x0, x20
1004abeb8:	bl	0x101acbde0 ; selector bounds
1004abebc:	mov.16b	v8, v0
1004abec0:	mov.16b	v9, v1
1004abec4:	mov.16b	v10, v2
1004abec8:	mov.16b	v11, v3
1004abecc:	adrp	x8, 7803 ; 0x102326000
1004abed0:	ldr	x0, [x8, #0xa48] ; Objc class ref: _OBJC_CLASS_$_NSTrackingArea
1004abed4:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004abed8:	mov.16b	v0, v8
1004abedc:	mov.16b	v1, v9
1004abee0:	mov.16b	v2, v10
1004abee4:	mov.16b	v3, v11
1004abee8:	mov	x3, x20
1004abeec:	mov	w2, #0x81
1004abef0:	mov	x4, #0x0
1004abef4:	bl	0x101ace7c0 ; selector initWithRect:options:owner:userInfo:
1004abef8:	mov	x19, x0
1004abefc:	mov	x0, x20
1004abf00:	mov	x2, x19
1004abf04:	bl	0x101acb540 ; selector addTrackingArea:
1004abf08:	ldr	x0, [x20, x21]
1004abf0c:	str	x19, [x20, x21]
1004abf10:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abf14:	ldp	x29, x30, [sp, #0x50]
1004abf18:	ldp	x20, x19, [sp, #0x40]
1004abf1c:	ldp	x22, x21, [sp, #0x30]
1004abf20:	ldp	d9, d8, [sp, #0x20]
1004abf24:	ldp	d11, d10, [sp, #0x10]
1004abf28:	add	sp, sp, #0x60
1004abf2c:	ret
1004abf30:	stp	x20, x19, [sp, #-0x20]!
1004abf34:	stp	x29, x30, [sp, #0x10]
1004abf38:	add	x29, sp, #0x10
1004abf3c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004abf40:	mov	x20, x0
1004abf44:	adrp	x0, 2 ; 0x1004ad000
1004abf48:	add	x0, x0, #0x5c
1004abf4c:	adrp	x1, 7849 ; 0x102354000
1004abf50:	add	x1, x1, #0xf10
1004abf54:	bl	0x1004abe68
1004abf58:	mov	x0, x20
1004abf5c:	ldp	x29, x30, [sp, #0x10]
1004abf60:	ldp	x20, x19, [sp], #0x20
1004abf64:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004abf68:	stp	x29, x30, [sp, #-0x10]!
1004abf6c:	mov	x29, sp
1004abf70:	adrp	x0, 7849 ; 0x102354000
1004abf74:	add	x0, x0, #0xf48
1004abf78:	adrp	x1, 7849 ; 0x102354000
1004abf7c:	add	x1, x1, #0xf18
1004abf80:	adrp	x2, 1 ; 0x1004ac000
1004abf84:	add	x2, x2, #0x200
1004abf88:	bl	0x1004ad07c
1004abf8c:	ldp	x29, x30, [sp], #0x10
1004abf90:	ret
1004abf94:	stp	x22, x21, [sp, #-0x30]!
1004abf98:	stp	x20, x19, [sp, #0x10]
1004abf9c:	stp	x29, x30, [sp, #0x20]
1004abfa0:	add	x29, sp, #0x20
1004abfa4:	mov	x19, x0
1004abfa8:	mov	x0, x2
1004abfac:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004abfb0:	mov	x21, x0
1004abfb4:	mov	x0, x19
1004abfb8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004abfbc:	mov	x20, x0
1004abfc0:	adrp	x0, 7849 ; 0x102354000
1004abfc4:	add	x0, x0, #0xf48
1004abfc8:	adrp	x1, 7849 ; 0x102354000
1004abfcc:	add	x1, x1, #0xf18
1004abfd0:	adrp	x2, 1 ; 0x1004ac000
1004abfd4:	add	x2, x2, #0x200
1004abfd8:	bl	0x1004ad07c
1004abfdc:	mov	x0, x21
1004abfe0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004abfe4:	mov	x0, x20
1004abfe8:	ldp	x29, x30, [sp, #0x20]
1004abfec:	ldp	x20, x19, [sp, #0x10]
1004abff0:	ldp	x22, x21, [sp], #0x30
1004abff4:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004abff8:	stp	x29, x30, [sp, #-0x10]!
1004abffc:	mov	x29, sp
1004ac000:	adrp	x0, 7848 ; 0x102354000
1004ac004:	add	x0, x0, #0xf48
1004ac008:	adrp	x1, 7848 ; 0x102354000
1004ac00c:	add	x1, x1, #0xf18
1004ac010:	bl	0x1004ad0e8
1004ac014:	ldp	x29, x30, [sp], #0x10
1004ac018:	ret
1004ac01c:	stp	x22, x21, [sp, #-0x30]!
1004ac020:	stp	x20, x19, [sp, #0x10]
1004ac024:	stp	x29, x30, [sp, #0x20]
1004ac028:	add	x29, sp, #0x20
1004ac02c:	mov	x19, x0
1004ac030:	mov	x0, x2
1004ac034:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ac038:	mov	x21, x0
1004ac03c:	mov	x0, x19
1004ac040:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ac044:	mov	x20, x0
1004ac048:	adrp	x0, 7848 ; 0x102354000
1004ac04c:	add	x0, x0, #0xf48
1004ac050:	adrp	x1, 7848 ; 0x102354000
1004ac054:	add	x1, x1, #0xf18
1004ac058:	bl	0x1004ad0e8
1004ac05c:	mov	x0, x21
1004ac060:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac064:	mov	x0, x20
1004ac068:	ldp	x29, x30, [sp, #0x20]
1004ac06c:	ldp	x20, x19, [sp, #0x10]
1004ac070:	ldp	x22, x21, [sp], #0x30
1004ac074:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004ac078:	adrp	x0, 7848 ; 0x102354000
1004ac07c:	add	x0, x0, #0xf48
1004ac080:	adrp	x1, 1 ; 0x1004ad000
1004ac084:	add	x1, x1, #0x5c
1004ac088:	b	0x1004ac08c
1004ac08c:	sub	sp, sp, #0x80
1004ac090:	stp	d15, d14, [sp, #0x10]
1004ac094:	stp	d13, d12, [sp, #0x20]
1004ac098:	stp	d11, d10, [sp, #0x30]
1004ac09c:	stp	d9, d8, [sp, #0x40]
1004ac0a0:	stp	x22, x21, [sp, #0x50]
1004ac0a4:	stp	x20, x19, [sp, #0x60]
1004ac0a8:	stp	x29, x30, [sp, #0x70]
1004ac0ac:	add	x29, sp, #0x70
1004ac0b0:	mov	x19, x1
1004ac0b4:	mov.16b	v8, v3
1004ac0b8:	mov.16b	v9, v2
1004ac0bc:	mov.16b	v10, v1
1004ac0c0:	mov.16b	v11, v0
1004ac0c4:	ldr	x8, [x0]
1004ac0c8:	ldrb	w8, [x20, x8]
1004ac0cc:	cmp	w8, #0x1
1004ac0d0:	b.ne	0x1004ac14c
1004ac0d4:	bl	0x1004adb20
1004ac0d8:	mov	x21, x0
1004ac0dc:	bl	0x101ad29c0 ; selector setFill
1004ac0e0:	mov	x0, x21
1004ac0e4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac0e8:	mov	x0, x20
1004ac0ec:	bl	0x101acbde0 ; selector bounds
1004ac0f0:	fmov	d4, #4.00000000
1004ac0f4:	fmov	d5, #1.00000000
1004ac0f8:	bl	0x101ac8dc4 ; symbol stub for: _CGRectInset
1004ac0fc:	mov.16b	v12, v0
1004ac100:	mov.16b	v13, v1
1004ac104:	mov.16b	v14, v2
1004ac108:	mov.16b	v15, v3
1004ac10c:	adrp	x8, 7802 ; 0x102326000
1004ac110:	ldr	x0, [x8, #0xb38] ; Objc class ref: _OBJC_CLASS_$_NSBezierPath
1004ac114:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004ac118:	fmov	d4, #6.00000000
1004ac11c:	fmov	d5, #6.00000000
1004ac120:	mov.16b	v0, v12
1004ac124:	mov.16b	v1, v13
1004ac128:	mov.16b	v2, v14
1004ac12c:	mov.16b	v3, v15
1004ac130:	bl	0x101acbc40 ; selector bezierPathWithRoundedRect:xRadius:yRadius:
1004ac134:	mov	x29, x29
1004ac138:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ac13c:	mov	x21, x0
1004ac140:	bl	0x101acda20 ; selector fill
1004ac144:	mov	x0, x21
1004ac148:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac14c:	blr	x19
1004ac150:	stp	x20, x0, [sp]
1004ac154:	adrp	x8, 7797 ; 0x102321000
1004ac158:	ldr	x1, [x8, #0x3b8] ; Objc selector ref: drawRect:
1004ac15c:	mov	x0, sp
1004ac160:	mov.16b	v0, v11
1004ac164:	mov.16b	v1, v10
1004ac168:	mov.16b	v2, v9
1004ac16c:	mov.16b	v3, v8
1004ac170:	bl	0x101ac9d0c ; Objc message: -[[x0 super] drawRect:]
1004ac174:	ldp	x29, x30, [sp, #0x70]
1004ac178:	ldp	x20, x19, [sp, #0x60]
1004ac17c:	ldp	x22, x21, [sp, #0x50]
1004ac180:	ldp	d9, d8, [sp, #0x40]
1004ac184:	ldp	d11, d10, [sp, #0x30]
1004ac188:	ldp	d13, d12, [sp, #0x20]
1004ac18c:	ldp	d15, d14, [sp, #0x10]
1004ac190:	add	sp, sp, #0x80
1004ac194:	ret
1004ac198:	stp	d11, d10, [sp, #-0x40]!
1004ac19c:	stp	d9, d8, [sp, #0x10]
1004ac1a0:	stp	x20, x19, [sp, #0x20]
1004ac1a4:	stp	x29, x30, [sp, #0x30]
1004ac1a8:	add	x29, sp, #0x30
1004ac1ac:	mov.16b	v8, v3
1004ac1b0:	mov.16b	v9, v2
1004ac1b4:	mov.16b	v10, v1
1004ac1b8:	mov.16b	v11, v0
1004ac1bc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ac1c0:	mov	x20, x0
1004ac1c4:	adrp	x0, 7848 ; 0x102354000
1004ac1c8:	add	x0, x0, #0xf48
1004ac1cc:	adrp	x1, 1 ; 0x1004ad000
1004ac1d0:	add	x1, x1, #0x5c
1004ac1d4:	mov.16b	v0, v11
1004ac1d8:	mov.16b	v1, v10
1004ac1dc:	mov.16b	v2, v9
1004ac1e0:	mov.16b	v3, v8
1004ac1e4:	bl	0x1004ac08c
1004ac1e8:	mov	x0, x20
1004ac1ec:	ldp	x29, x30, [sp, #0x30]
1004ac1f0:	ldp	x20, x19, [sp, #0x20]
1004ac1f4:	ldp	d9, d8, [sp, #0x10]
1004ac1f8:	ldp	d11, d10, [sp], #0x40
1004ac1fc:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004ac200:	sub	sp, sp, #0x150
1004ac204:	stp	d15, d14, [sp, #0xb0]
1004ac208:	stp	d13, d12, [sp, #0xc0]
1004ac20c:	stp	d11, d10, [sp, #0xd0]
1004ac210:	stp	d9, d8, [sp, #0xe0]
1004ac214:	stp	x28, x27, [sp, #0xf0]
1004ac218:	stp	x26, x25, [sp, #0x100]
1004ac21c:	stp	x24, x23, [sp, #0x110]
1004ac220:	stp	x22, x21, [sp, #0x120]
1004ac224:	stp	x20, x19, [sp, #0x130]
1004ac228:	stp	x29, x30, [sp, #0x140]
1004ac22c:	add	x29, sp, #0x140
1004ac230:	bl	0x1004ace00
1004ac234:	adrp	x8, 7848 ; 0x102354000
1004ac238:	ldr	x8, [x8, #0xf38]
1004ac23c:	ldr	d9, [x20, x8]
1004ac240:	bl	0x10002dd04
1004ac244:	mov.16b	v1, v0
1004ac248:	fmov	d0, #13.00000000
1004ac24c:	bl	0x100004700
1004ac250:	str	x0, [sp, #0x10]
1004ac254:	adrp	x8, 7848 ; 0x102354000
1004ac258:	ldr	x8, [x8, #0xf20]
1004ac25c:	stp	x8, x20, [sp, #0x20]
1004ac260:	ldr	x0, [x20, x8]
1004ac264:	ldr	x25, [x0, #0x10]
1004ac268:	cbz	x25, 0x1004ac448
1004ac26c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004ac270:	str	x0, [sp, #0x18]
1004ac274:	add	x20, x0, #0x28
1004ac278:	mov	x8, #0x800000000000
1004ac27c:	movk	x8, #0x4061, lsl #48
1004ac280:	fmov	d10, x8
1004ac284:	mov	x22, #-0x1d00000000000000
1004ac288:	adrp	x8, 5685 ; 0x101ae1000
1004ac28c:	ldr	q0, [x8, #0x130]
1004ac290:	str	q0, [sp, #0x30]
1004ac294:	b	0x1004ac2a4
1004ac298:	add	x20, x20, #0x38
1004ac29c:	subs	x25, x25, #0x1
1004ac2a0:	b.eq	0x1004ac42c
1004ac2a4:	ldp	x28, x26, [x20, #-0x8]
1004ac2a8:	mov	w8, #0x2d2d
1004ac2ac:	movk	w8, #0x2d, lsl #16
1004ac2b0:	cmp	x28, x8
1004ac2b4:	ccmp	x26, x22, #0x0, eq
1004ac2b8:	b.eq	0x1004ac298
1004ac2bc:	ldp	x27, x21, [x20, #0x10]
1004ac2c0:	ldr	x19, [x20, #0x28]
1004ac2c4:	mov	x0, x28
1004ac2c8:	mov	x1, x26
1004ac2cc:	mov	w2, #0x2d2d
1004ac2d0:	movk	w2, #0x2d, lsl #16
1004ac2d4:	mov	x3, #-0x1d00000000000000
1004ac2d8:	mov	w4, #0x0
1004ac2dc:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004ac2e0:	tbnz	w0, #0x0, 0x1004ac298
1004ac2e4:	mov	x0, x21
1004ac2e8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ac2ec:	str	x0, [sp, #0x40]
1004ac2f0:	mov	x0, x19
1004ac2f4:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ac2f8:	mov	x0, x26
1004ac2fc:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004ac300:	mov	x0, x27
1004ac304:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004ac308:	mov	x0, x28
1004ac30c:	mov	x1, x26
1004ac310:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004ac314:	mov	x28, x0
1004ac318:	adrp	x0, 7838 ; 0x10234a000
1004ac31c:	add	x0, x0, #0xb40
1004ac320:	adrp	x1, 5685 ; 0x101ae1000
1004ac324:	add	x1, x1, #0x290
1004ac328:	bl	0x100003c4c
1004ac32c:	add	x1, sp, #0x60
1004ac330:	bl	0x101aca8b8 ; symbol stub for: _swift_initStackObject
1004ac334:	mov	x22, x0
1004ac338:	ldr	q0, [sp, #0x30]
1004ac33c:	str	q0, [x0, #0x10]
1004ac340:	adrp	x8, 7710 ; 0x1022ca000
1004ac344:	ldr	x8, [x8, #0x5c8] ; literal pool symbol address: _NSFontAttributeName
1004ac348:	ldr	x23, [x8]
1004ac34c:	mov	x24, x0
1004ac350:	str	x23, [x24, #0x20]!
1004ac354:	mov	x0, #0x0
1004ac358:	bl	0x10013254c
1004ac35c:	str	x0, [x22, #0x40]
1004ac360:	ldr	x21, [sp, #0x10]
1004ac364:	str	x21, [x22, #0x28]
1004ac368:	mov	x0, x23
1004ac36c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ac370:	mov	x0, x21
1004ac374:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ac378:	mov	x0, x22
1004ac37c:	bl	0x10002afac
1004ac380:	mov	x23, x0
1004ac384:	mov	x0, x22
1004ac388:	bl	0x101aca990 ; symbol stub for: _swift_setDeallocating
1004ac38c:	mov	x0, x24
1004ac390:	bl	0x10010498c
1004ac394:	mov	x0, #0x0
1004ac398:	bl	0x10002c784
1004ac39c:	mov	x22, x0
1004ac3a0:	adrp	x0, 7828 ; 0x102340000
1004ac3a4:	add	x0, x0, #0xf30
1004ac3a8:	adrp	x1, 5686 ; 0x101ae2000
1004ac3ac:	add	x1, x1, #0x620
1004ac3b0:	bl	0x100074f70
1004ac3b4:	mov	x3, x0
1004ac3b8:	adrp	x8, 7715 ; 0x1022cf000
1004ac3bc:	ldr	x8, [x8, #0x490] ; literal pool symbol address: _$sypN
1004ac3c0:	add	x2, x8, #0x8
1004ac3c4:	mov	x0, x23
1004ac3c8:	mov	x1, x22
1004ac3cc:	bl	0x101ac5ed8 ; symbol stub for: _$sSD10FoundationE19_bridgeToObjectiveCSo12NSDictionaryCyF
1004ac3d0:	mov	x22, x0
1004ac3d4:	mov	x0, x23
1004ac3d8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ac3dc:	mov	x0, x28
1004ac3e0:	mov	x2, x22
1004ac3e4:	bl	0x101ad5000 ; selector sizeWithAttributes:
1004ac3e8:	mov.16b	v8, v0
1004ac3ec:	mov	x0, x28
1004ac3f0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac3f4:	mov	x0, x22
1004ac3f8:	mov	x22, #-0x1d00000000000000
1004ac3fc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac400:	mov	x0, x19
1004ac404:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ac408:	ldr	x0, [sp, #0x40]
1004ac40c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac410:	mov	x0, x27
1004ac414:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ac418:	mov	x0, x26
1004ac41c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ac420:	fcmp	d10, d8
1004ac424:	fcsel	d10, d8, d10, ls
1004ac428:	b	0x1004ac298
1004ac42c:	ldr	x0, [sp, #0x18]
1004ac430:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ac434:	fmov	d0, #16.00000000
1004ac438:	fadd	d1, d10, d0
1004ac43c:	fadd	d1, d1, d0
1004ac440:	fadd	d0, d1, d0
1004ac444:	b	0x1004ac454
1004ac448:	mov	x8, #0x800000000000
1004ac44c:	movk	x8, #0x4067, lsl #48
1004ac450:	fmov	d0, x8
1004ac454:	frintp	d13, d0
1004ac458:	mov	x0, #0x0
1004ac45c:	bl	0x10006d00c
1004ac460:	movi.2d	v0, #0000000000000000
1004ac464:	movi.2d	v1, #0000000000000000
1004ac468:	movi.2d	v3, #0000000000000000
1004ac46c:	mov.16b	v2, v13
1004ac470:	mov	x20, x0
1004ac474:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004ac478:	str	x0, [sp, #0x40]
1004ac47c:	ldp	x9, x8, [sp, #0x20]
1004ac480:	ldr	x0, [x8, x9]
1004ac484:	ldr	x23, [x0, #0x10]
1004ac488:	cbz	x23, 0x1004ac7b4
1004ac48c:	fmov	d0, #-24.00000000
1004ac490:	fadd	d11, d13, d0
1004ac494:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004ac498:	mov	x25, #0x0
1004ac49c:	fmov	d10, #4.00000000
1004ac4a0:	fmov	d12, #2.00000000
1004ac4a4:	str	x0, [sp, #0x30]
1004ac4a8:	b	0x1004ac4f8
1004ac4ac:	ldr	x0, [sp, #0x40]
1004ac4b0:	mov	x2, x20
1004ac4b4:	bl	0x101acb460 ; selector addSubview:
1004ac4b8:	mov	x0, x26
1004ac4bc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ac4c0:	mov	x0, x19
1004ac4c4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac4c8:	mov	x0, x22
1004ac4cc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ac4d0:	mov	x0, x28
1004ac4d4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ac4d8:	mov	x0, x20
1004ac4dc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac4e0:	fmov	d0, #5.00000000
1004ac4e4:	fadd	d10, d10, d0
1004ac4e8:	add	x25, x25, #0x38
1004ac4ec:	subs	x23, x23, #0x1
1004ac4f0:	ldr	x0, [sp, #0x30]
1004ac4f4:	b.eq	0x1004ac7a4
1004ac4f8:	add	x21, x0, x25
1004ac4fc:	ldp	x27, x28, [x21, #0x20]
1004ac500:	ldp	x19, x22, [x21, #0x30]
1004ac504:	ldr	x20, [x21, #0x40]
1004ac508:	adrp	x0, 7470 ; 0x1021da000
1004ac50c:	add	x0, x0, #0x748
1004ac510:	mov	w1, #0x20
1004ac514:	mov	w2, #0x7
1004ac518:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ac51c:	mov	x26, x0
1004ac520:	ldr	x24, [x21, #0x50]
1004ac524:	ldur	q0, [x21, #0x48]
1004ac528:	str	q0, [x0, #0x10]
1004ac52c:	mov	w8, #0x2d2d
1004ac530:	movk	w8, #0x2d, lsl #16
1004ac534:	cmp	x27, x8
1004ac538:	mov	x8, #-0x1d00000000000000
1004ac53c:	ccmp	x28, x8, #0x0, eq
1004ac540:	b.eq	0x1004ac564
1004ac544:	mov	x0, x27
1004ac548:	mov	x1, x28
1004ac54c:	mov	w2, #0x2d2d
1004ac550:	movk	w2, #0x2d, lsl #16
1004ac554:	mov	x3, #-0x1d00000000000000
1004ac558:	mov	w4, #0x0
1004ac55c:	bl	0x101ac7c90 ; symbol stub for: _$ss27_stringCompareWithSmolCheck__9expectingSbs11_StringGutsV_ADs01_G16ComparisonResultOtF
1004ac560:	tbz	w0, #0x0, 0x1004ac628
1004ac564:	fadd	d8, d10, d12
1004ac568:	adrp	x8, 7802 ; 0x102326000
1004ac56c:	ldr	x21, [x8, #0xa40] ; Objc class ref: _OBJC_CLASS_$_NSView
1004ac570:	mov	x0, x28
1004ac574:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004ac578:	mov	x0, x22
1004ac57c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004ac580:	mov	x0, x20
1004ac584:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ac588:	mov	x19, x0
1004ac58c:	mov	x0, x24
1004ac590:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ac594:	mov	x0, x21
1004ac598:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004ac59c:	fmov	d0, #12.00000000
1004ac5a0:	fmov	d3, #1.00000000
1004ac5a4:	mov.16b	v1, v8
1004ac5a8:	mov.16b	v2, v11
1004ac5ac:	bl	0x101ace5a0 ; selector initWithFrame:
1004ac5b0:	mov	x20, x0
1004ac5b4:	mov	w2, #0x1
1004ac5b8:	bl	0x101ad4ca0 ; selector setWantsLayer:
1004ac5bc:	mov	x0, x20
1004ac5c0:	bl	0x101acf2c0 ; selector layer
1004ac5c4:	mov	x29, x29
1004ac5c8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ac5cc:	cbz	x0, 0x1004ac4ac
1004ac5d0:	mov	x21, x0
1004ac5d4:	adrp	x8, 7802 ; 0x102326000
1004ac5d8:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004ac5dc:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004ac5e0:	bl	0x101ad1600 ; selector separatorColor
1004ac5e4:	mov	x29, x29
1004ac5e8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ac5ec:	mov	x24, x0
1004ac5f0:	bl	0x101acad00 ; selector CGColor
1004ac5f4:	mov	x29, x29
1004ac5f8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ac5fc:	mov	x27, x0
1004ac600:	mov	x0, x24
1004ac604:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac608:	mov	x0, x21
1004ac60c:	mov	x2, x27
1004ac610:	bl	0x101ad1e00 ; selector setBackgroundColor:
1004ac614:	mov	x0, x21
1004ac618:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac61c:	mov	x0, x27
1004ac620:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac624:	b	0x1004ac4ac
1004ac628:	mov	x0, #0x0
1004ac62c:	bl	0x1004aede4
1004ac630:	str	x19, [sp, #0x18]
1004ac634:	mov	x19, x0
1004ac638:	mov	x0, x20
1004ac63c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ac640:	str	x0, [sp, #0x20]
1004ac644:	mov	x0, x24
1004ac648:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ac64c:	mov	x0, x28
1004ac650:	mov	w1, #0x2
1004ac654:	bl	0x101aca630 ; symbol stub for: _swift_bridgeObjectRetain_n
1004ac658:	mov	x21, x22
1004ac65c:	mov	x0, x22
1004ac660:	mov	w1, #0x2
1004ac664:	bl	0x101aca630 ; symbol stub for: _swift_bridgeObjectRetain_n
1004ac668:	movi.2d	v0, #0000000000000000
1004ac66c:	mov.16b	v1, v10
1004ac670:	mov.16b	v2, v13
1004ac674:	mov.16b	v3, v9
1004ac678:	mov	x20, x19
1004ac67c:	bl	_$s16CodeEditTextView0cD0C5frameACSo6CGRectV_tcfC
1004ac680:	mov	x20, x0
1004ac684:	ldr	x8, [x0]
1004ac688:	adrp	x19, 7715 ; 0x1022cf000
1004ac68c:	ldr	x19, [x19, #0x718] ; literal pool symbol address: _swift_isaMask
1004ac690:	ldr	x9, [x19]
1004ac694:	and	x8, x9, x8
1004ac698:	ldr	x8, [x8, #0x130]
1004ac69c:	mov	w0, #0x1
1004ac6a0:	blr	x8
1004ac6a4:	adrp	x0, 7470 ; 0x1021da000
1004ac6a8:	add	x0, x0, #0x770
1004ac6ac:	mov	w1, #0x18
1004ac6b0:	mov	w2, #0x7
1004ac6b4:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ac6b8:	mov	x22, x0
1004ac6bc:	add	x0, x0, #0x10
1004ac6c0:	ldr	x1, [sp, #0x28]
1004ac6c4:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004ac6c8:	adrp	x0, 7470 ; 0x1021da000
1004ac6cc:	add	x0, x0, #0x798
1004ac6d0:	mov	w1, #0x28
1004ac6d4:	mov	w2, #0x7
1004ac6d8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ac6dc:	mov	x24, x0
1004ac6e0:	adrp	x8, -1193 ; 0x100003000
1004ac6e4:	add	x8, x8, #0x8c4
1004ac6e8:	stp	x8, x26, [x0, #0x10]
1004ac6ec:	str	x22, [x0, #0x20]
1004ac6f0:	mov	x0, x26
1004ac6f4:	mov	w1, #0x2
1004ac6f8:	bl	0x101aca984 ; symbol stub for: _swift_retain_n
1004ac6fc:	mov	x0, x22
1004ac700:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004ac704:	bl	_$s9TextStory09BufferingA7StorageC16bufferingEnabledSbvpfi
1004ac708:	ldr	x8, [x20]
1004ac70c:	ldr	x9, [x19]
1004ac710:	and	x8, x9, x8
1004ac714:	ldr	x8, [x8, #0x140]
1004ac718:	str	x24, [sp]
1004ac71c:	and	w4, w0, #0x1
1004ac720:	mov	x0, x27
1004ac724:	mov	x1, x28
1004ac728:	ldr	x2, [sp, #0x18]
1004ac72c:	mov	x3, x21
1004ac730:	mov	x5, #0x4030000000000000
1004ac734:	mov	w6, #0x0
1004ac738:	adrp	x7, 1 ; 0x1004ad000
1004ac73c:	add	x7, x7, #0x1a0
1004ac740:	blr	x8
1004ac744:	mov	x0, x22
1004ac748:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ac74c:	mov	x0, x24
1004ac750:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ac754:	mov	x0, x28
1004ac758:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ac75c:	mov	x0, x21
1004ac760:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ac764:	ldr	x0, [sp, #0x40]
1004ac768:	mov	x2, x20
1004ac76c:	bl	0x101acb460 ; selector addSubview:
1004ac770:	ldr	x0, [sp, #0x20]
1004ac774:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac778:	mov	x0, x21
1004ac77c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ac780:	mov	x0, x28
1004ac784:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ac788:	mov	x0, x20
1004ac78c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac790:	mov	x0, x26
1004ac794:	mov	w1, #0x2
1004ac798:	bl	0x101aca96c ; symbol stub for: _swift_release_n
1004ac79c:	mov.16b	v0, v9
1004ac7a0:	b	0x1004ac4e4
1004ac7a4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ac7a8:	fmov	d0, #4.00000000
1004ac7ac:	fadd	d8, d10, d0
1004ac7b0:	b	0x1004ac7b8
1004ac7b4:	fmov	d8, #8.00000000
1004ac7b8:	ldr	x0, [sp, #0x40]
1004ac7bc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ac7c0:	mov	x20, x0
1004ac7c4:	bl	0x101acdcc0 ; selector frame
1004ac7c8:	mov	x0, x20
1004ac7cc:	mov.16b	v3, v8
1004ac7d0:	bl	0x101ad2b80 ; selector setFrame:
1004ac7d4:	adrp	x8, 7802 ; 0x102326000
1004ac7d8:	ldr	x0, [x8, #0xa28] ; Objc class ref: _OBJC_CLASS_$_NSPanel
1004ac7dc:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004ac7e0:	movi.2d	v0, #0000000000000000
1004ac7e4:	movi.2d	v1, #0000000000000000
1004ac7e8:	mov.16b	v2, v13
1004ac7ec:	mov.16b	v3, v8
1004ac7f0:	mov	w2, #0x80
1004ac7f4:	mov	w3, #0x2
1004ac7f8:	mov	w4, #0x0
1004ac7fc:	bl	0x101ace420 ; selector initWithContentRect:styleMask:backing:defer:
1004ac800:	mov	x19, x0
1004ac804:	mov	w21, #0x1
1004ac808:	mov	w2, #0x1
1004ac80c:	bl	0x101ad2a60 ; selector setFloatingPanel:
1004ac810:	mov	x0, x19
1004ac814:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ac818:	mov	x24, x0
1004ac81c:	mov	w2, #0x65
1004ac820:	bl	0x101ad3320 ; selector setLevel:
1004ac824:	mov	x0, x24
1004ac828:	mov	w2, #0x0
1004ac82c:	bl	0x101ad3980 ; selector setOpaque:
1004ac830:	adrp	x8, 7802 ; 0x102326000
1004ac834:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004ac838:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004ac83c:	bl	0x101acc200 ; selector clearColor
1004ac840:	mov	x29, x29
1004ac844:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ac848:	mov	x19, x0
1004ac84c:	mov	x0, x24
1004ac850:	mov	x2, x19
1004ac854:	bl	0x101ad1e00 ; selector setBackgroundColor:
1004ac858:	mov	x0, x19
1004ac85c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac860:	bl	_$s9TextStory09BufferingA7StorageC16bufferingEnabledSbvpfi
1004ac864:	bic	w2, w21, w0
1004ac868:	mov	x0, x24
1004ac86c:	bl	0x101ad2d20 ; selector setHasShadow:
1004ac870:	fmov	d2, #8.00000000
1004ac874:	mov.16b	v0, v13
1004ac878:	mov.16b	v1, v8
1004ac87c:	bl	0x1004ad2c4
1004ac880:	mov	x23, x0
1004ac884:	mov	x22, x1
1004ac888:	mov	x0, x1
1004ac88c:	mov	x2, x20
1004ac890:	bl	0x101acb460 ; selector addSubview:
1004ac894:	movi.2d	v0, #0000000000000000
1004ac898:	movi.2d	v1, #0000000000000000
1004ac89c:	mov	x0, x20
1004ac8a0:	mov.16b	v2, v13
1004ac8a4:	mov.16b	v3, v8
1004ac8a8:	bl	0x101ad2b80 ; selector setFrame:
1004ac8ac:	mov	x0, x20
1004ac8b0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac8b4:	mov	x0, x24
1004ac8b8:	mov	x2, x23
1004ac8bc:	bl	0x101ad2340 ; selector setContentView:
1004ac8c0:	mov	x0, x24
1004ac8c4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ac8c8:	ldr	x0, [sp, #0x28]
1004ac8cc:	bl	0x101ad6200 ; selector window
1004ac8d0:	mov	x29, x29
1004ac8d4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ac8d8:	cbz	x0, 0x1004aca8c
1004ac8dc:	mov	x25, x0
1004ac8e0:	bl	0x101ad1140 ; selector screen
1004ac8e4:	mov	x29, x29
1004ac8e8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ac8ec:	cbnz	x0, 0x1004ac90c
1004ac8f0:	adrp	x8, 7802 ; 0x102326000
1004ac8f4:	ldr	x0, [x8, #0xa18] ; Objc class ref: _OBJC_CLASS_$_NSScreen
1004ac8f8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004ac8fc:	bl	0x101acf6a0 ; selector mainScreen
1004ac900:	mov	x29, x29
1004ac904:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ac908:	cbz	x0, 0x1004aca84
1004ac90c:	mov	x26, x0
1004ac910:	str	d8, [sp, #0x20]
1004ac914:	str	d13, [sp, #0x40]
1004ac918:	ldr	x19, [sp, #0x28]
1004ac91c:	mov	x0, x19
1004ac920:	bl	0x101acbde0 ; selector bounds
1004ac924:	mov	x0, x19
1004ac928:	mov	x2, #0x0
1004ac92c:	bl	0x101acc9c0 ; selector convertRect:toView:
1004ac930:	mov	x0, x25
1004ac934:	bl	0x101acca00 ; selector convertRectToScreen:
1004ac938:	mov.16b	v15, v0
1004ac93c:	mov.16b	v8, v1
1004ac940:	mov.16b	v14, v2
1004ac944:	mov.16b	v9, v3
1004ac948:	mov	x0, x26
1004ac94c:	bl	0x101ad6080 ; selector visibleFrame
1004ac950:	mov.16b	v11, v0
1004ac954:	str	d1, [sp, #0x8]
1004ac958:	mov.16b	v12, v2
1004ac95c:	mov.16b	v13, v3
1004ac960:	mov.16b	v0, v15
1004ac964:	mov.16b	v1, v8
1004ac968:	mov.16b	v2, v14
1004ac96c:	mov.16b	v3, v9
1004ac970:	bl	0x101ac8d70 ; symbol stub for: _CGRectGetMaxX
1004ac974:	fmov	d1, #2.00000000
1004ac978:	fadd	d1, d0, d1
1004ac97c:	ldr	d0, [sp, #0x40]
1004ac980:	str	d1, [sp, #0x30]
1004ac984:	fadd	d10, d0, d1
1004ac988:	str	d11, [sp, #0x18]
1004ac98c:	mov.16b	v0, v11
1004ac990:	ldr	d11, [sp, #0x8]
1004ac994:	mov.16b	v1, v11
1004ac998:	mov.16b	v2, v12
1004ac99c:	mov.16b	v3, v13
1004ac9a0:	bl	0x101ac8d70 ; symbol stub for: _CGRectGetMaxX
1004ac9a4:	fcmp	d0, d10
1004ac9a8:	b.pl	0x1004ac9d4
1004ac9ac:	mov.16b	v0, v15
1004ac9b0:	mov.16b	v1, v8
1004ac9b4:	mov.16b	v2, v14
1004ac9b8:	mov.16b	v3, v9
1004ac9bc:	bl	0x101ac8da0 ; symbol stub for: _CGRectGetMinX
1004ac9c0:	ldr	d1, [sp, #0x40]
1004ac9c4:	fsub	d0, d0, d1
1004ac9c8:	fmov	d1, #-2.00000000
1004ac9cc:	fadd	d0, d0, d1
1004ac9d0:	str	d0, [sp, #0x30]
1004ac9d4:	mov.16b	v0, v15
1004ac9d8:	mov.16b	v1, v8
1004ac9dc:	mov.16b	v2, v14
1004ac9e0:	mov.16b	v3, v9
1004ac9e4:	bl	0x101ac8d7c ; symbol stub for: _CGRectGetMaxY
1004ac9e8:	ldp	d14, d10, [sp, #0x18]
1004ac9ec:	fsub	d8, d0, d10
1004ac9f0:	mov.16b	v0, v14
1004ac9f4:	mov.16b	v1, v11
1004ac9f8:	mov.16b	v2, v12
1004ac9fc:	mov.16b	v3, v13
1004aca00:	bl	0x101ac8dac ; symbol stub for: _CGRectGetMinY
1004aca04:	fcmp	d8, d0
1004aca08:	b.pl	0x1004aca24
1004aca0c:	mov.16b	v0, v14
1004aca10:	mov.16b	v1, v11
1004aca14:	mov.16b	v2, v12
1004aca18:	mov.16b	v3, v13
1004aca1c:	bl	0x101ac8dac ; symbol stub for: _CGRectGetMinY
1004aca20:	mov.16b	v8, v0
1004aca24:	fadd	d9, d10, d8
1004aca28:	mov.16b	v0, v14
1004aca2c:	mov.16b	v1, v11
1004aca30:	mov.16b	v2, v12
1004aca34:	mov.16b	v3, v13
1004aca38:	bl	0x101ac8d7c ; symbol stub for: _CGRectGetMaxY
1004aca3c:	fcmp	d0, d9
1004aca40:	b.pl	0x1004aca5c
1004aca44:	mov.16b	v0, v14
1004aca48:	mov.16b	v1, v11
1004aca4c:	mov.16b	v2, v12
1004aca50:	mov.16b	v3, v13
1004aca54:	bl	0x101ac8d7c ; symbol stub for: _CGRectGetMaxY
1004aca58:	fsub	d8, d0, d10
1004aca5c:	ldr	d0, [sp, #0x30]
1004aca60:	mov.16b	v1, v8
1004aca64:	ldr	d2, [sp, #0x40]
1004aca68:	mov.16b	v3, v10
1004aca6c:	bl	0x1004ad2a8
1004aca70:	mov	x0, x24
1004aca74:	mov	w2, #0x1
1004aca78:	bl	0x101ad2ba0 ; selector setFrame:display:
1004aca7c:	mov	x0, x26
1004aca80:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aca84:	mov	x0, x25
1004aca88:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aca8c:	mov	x0, x24
1004aca90:	mov	x2, #0x0
1004aca94:	bl	0x101acfe40 ; selector orderFront:
1004aca98:	adrp	x8, 7848 ; 0x102354000
1004aca9c:	ldr	x8, [x8, #0xef8]
1004acaa0:	ldr	x9, [sp, #0x28]
1004acaa4:	ldr	x19, [x9, x8]
1004acaa8:	str	x24, [x9, x8]
1004acaac:	mov	x0, x24
1004acab0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004acab4:	mov	x21, x0
1004acab8:	mov	x0, x19
1004acabc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004acac0:	adrp	x8, 7920 ; 0x10239c000
1004acac4:	ldr	x24, [x8, #0xf18]
1004acac8:	mov	x0, x21
1004acacc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004acad0:	mov	x19, x0
1004acad4:	cmn	x24, #0x1
1004acad8:	b.ne	0x1004acb84
1004acadc:	adrp	x21, 7981 ; 0x1023d9000
1004acae0:	add	x21, x21, #0xf80
1004acae4:	add	x1, sp, #0x48
1004acae8:	mov	x0, x21
1004acaec:	mov	w2, #0x1
1004acaf0:	mov	x3, #0x0
1004acaf4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004acaf8:	mov	x0, x21
1004acafc:	mov	x1, x19
1004acb00:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004acb04:	mov	x0, x19
1004acb08:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004acb0c:	adrp	x8, 7920 ; 0x10239c000
1004acb10:	ldr	x8, [x8, #0xf30]
1004acb14:	cmn	x8, #0x1
1004acb18:	b.ne	0x1004acb9c
1004acb1c:	adrp	x0, 7920 ; 0x10239c000
1004acb20:	add	x0, x0, #0xf38
1004acb24:	ldr	x1, [sp, #0x28]
1004acb28:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004acb2c:	mov	x0, x19
1004acb30:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004acb34:	mov	x0, x23
1004acb38:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004acb3c:	mov	x0, x22
1004acb40:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004acb44:	mov	x0, x20
1004acb48:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004acb4c:	ldr	x0, [sp, #0x10]
1004acb50:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004acb54:	ldp	x29, x30, [sp, #0x140]
1004acb58:	ldp	x20, x19, [sp, #0x130]
1004acb5c:	ldp	x22, x21, [sp, #0x120]
1004acb60:	ldp	x24, x23, [sp, #0x110]
1004acb64:	ldp	x26, x25, [sp, #0x100]
1004acb68:	ldp	x28, x27, [sp, #0xf0]
1004acb6c:	ldp	d9, d8, [sp, #0xe0]
1004acb70:	ldp	d11, d10, [sp, #0xd0]
1004acb74:	ldp	d13, d12, [sp, #0xc0]
1004acb78:	ldp	d15, d14, [sp, #0xb0]
1004acb7c:	add	sp, sp, #0x150
1004acb80:	ret
1004acb84:	adrp	x0, 7920 ; 0x10239c000
1004acb88:	add	x0, x0, #0xf18
1004acb8c:	adrp	x1, -3 ; 0x1004a9000
1004acb90:	add	x1, x1, #0xa7c
1004acb94:	bl	0x101aca948 ; symbol stub for: _swift_once
1004acb98:	b	0x1004acadc
1004acb9c:	adrp	x0, 7920 ; 0x10239c000
1004acba0:	add	x0, x0, #0xf30
1004acba4:	adrp	x1, -3 ; 0x1004a9000
1004acba8:	add	x1, x1, #0xcb4
1004acbac:	bl	0x101aca948 ; symbol stub for: _swift_once
1004acbb0:	b	0x1004acb1c
1004acbb4:	sub	sp, sp, #0x40
1004acbb8:	stp	d11, d10, [sp, #0x10]
1004acbbc:	stp	d9, d8, [sp, #0x20]
1004acbc0:	stp	x29, x30, [sp, #0x30]
1004acbc4:	add	x29, sp, #0x30
1004acbc8:	mov.16b	v8, v3
1004acbcc:	mov.16b	v9, v2
1004acbd0:	mov.16b	v10, v1
1004acbd4:	mov.16b	v11, v0
1004acbd8:	adrp	x8, 7848 ; 0x102354000
1004acbdc:	ldr	x8, [x8, #0xf00]
1004acbe0:	str	xzr, [x20, x8]
1004acbe4:	adrp	x8, 7848 ; 0x102354000
1004acbe8:	ldr	x8, [x8, #0xf08]
1004acbec:	str	xzr, [x20, x8]
1004acbf0:	adrp	x8, 7848 ; 0x102354000
1004acbf4:	ldr	x8, [x8, #0xf10]
1004acbf8:	str	xzr, [x20, x8]
1004acbfc:	adrp	x8, 7848 ; 0x102354000
1004acc00:	ldr	x8, [x8, #0xf18]
1004acc04:	adrp	x9, 7715 ; 0x1022cf000
1004acc08:	ldr	x9, [x9, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004acc0c:	str	x9, [x20, x8]
1004acc10:	adrp	x8, 7848 ; 0x102354000
1004acc14:	ldr	x8, [x8, #0xf48]
1004acc18:	strb	wzr, [x20, x8]
1004acc1c:	adrp	x8, 7848 ; 0x102354000
1004acc20:	ldr	x8, [x8, #0xf20]
1004acc24:	str	x9, [x20, x8]
1004acc28:	adrp	x8, 7848 ; 0x102354000
1004acc2c:	ldr	x8, [x8, #0xf28]
1004acc30:	add	x0, x20, x8
1004acc34:	mov	x1, #0x0
1004acc38:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004acc3c:	adrp	x8, 7848 ; 0x102354000
1004acc40:	ldr	x8, [x8, #0xef8]
1004acc44:	str	xzr, [x20, x8]
1004acc48:	adrp	x8, 7848 ; 0x102354000
1004acc4c:	ldr	x8, [x8, #0xf30]
1004acc50:	mov	x9, #0x4030000000000000
1004acc54:	str	x9, [x20, x8]
1004acc58:	adrp	x8, 7848 ; 0x102354000
1004acc5c:	ldr	x8, [x8, #0xf38]
1004acc60:	mov	x9, #0x403c000000000000
1004acc64:	str	x9, [x20, x8]
1004acc68:	adrp	x8, 7848 ; 0x102354000
1004acc6c:	ldr	x8, [x8, #0xf40]
1004acc70:	mov	x9, #0x4069000000000000
1004acc74:	str	x9, [x20, x8]
1004acc78:	bl	0x1004ad05c
1004acc7c:	stp	x20, x0, [sp]
1004acc80:	adrp	x8, 7799 ; 0x102323000
1004acc84:	ldr	x1, [x8, #0x50] ; Objc selector ref: initWithFrame:
1004acc88:	mov	x0, sp
1004acc8c:	mov.16b	v0, v11
1004acc90:	mov.16b	v1, v10
1004acc94:	mov.16b	v2, v9
1004acc98:	mov.16b	v3, v8
1004acc9c:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithFrame:]
1004acca0:	ldp	x29, x30, [sp, #0x30]
1004acca4:	ldp	d9, d8, [sp, #0x20]
1004acca8:	ldp	d11, d10, [sp, #0x10]
1004accac:	add	sp, sp, #0x40
1004accb0:	ret
1004accb4:	stp	x20, x19, [sp, #-0x20]!
1004accb8:	stp	x29, x30, [sp, #0x10]
1004accbc:	add	x29, sp, #0x10
1004accc0:	mov	x20, x0
1004accc4:	bl	0x1004acbb4
1004accc8:	ldp	x29, x30, [sp, #0x10]
1004acccc:	ldp	x20, x19, [sp], #0x20
1004accd0:	ret
1004accd4:	sub	sp, sp, #0x30
1004accd8:	stp	x20, x19, [sp, #0x10]
1004accdc:	stp	x29, x30, [sp, #0x20]
1004acce0:	add	x29, sp, #0x20
1004acce4:	mov	x19, x0
1004acce8:	adrp	x8, 7848 ; 0x102354000
1004accec:	ldr	x8, [x8, #0xf00]
1004accf0:	str	xzr, [x20, x8]
1004accf4:	adrp	x8, 7848 ; 0x102354000
1004accf8:	ldr	x8, [x8, #0xf08]
1004accfc:	str	xzr, [x20, x8]
1004acd00:	adrp	x8, 7848 ; 0x102354000
1004acd04:	ldr	x8, [x8, #0xf10]
1004acd08:	str	xzr, [x20, x8]
1004acd0c:	adrp	x8, 7848 ; 0x102354000
1004acd10:	ldr	x8, [x8, #0xf18]
1004acd14:	adrp	x9, 7715 ; 0x1022cf000
1004acd18:	ldr	x9, [x9, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004acd1c:	str	x9, [x20, x8]
1004acd20:	adrp	x8, 7848 ; 0x102354000
1004acd24:	ldr	x8, [x8, #0xf48]
1004acd28:	strb	wzr, [x20, x8]
1004acd2c:	adrp	x8, 7848 ; 0x102354000
1004acd30:	ldr	x8, [x8, #0xf20]
1004acd34:	str	x9, [x20, x8]
1004acd38:	adrp	x8, 7848 ; 0x102354000
1004acd3c:	ldr	x8, [x8, #0xf28]
1004acd40:	add	x0, x20, x8
1004acd44:	mov	x1, #0x0
1004acd48:	bl	0x101acaac8 ; symbol stub for: _swift_unknownObjectWeakInit
1004acd4c:	adrp	x8, 7848 ; 0x102354000
1004acd50:	ldr	x8, [x8, #0xef8]
1004acd54:	str	xzr, [x20, x8]
1004acd58:	adrp	x8, 7848 ; 0x102354000
1004acd5c:	ldr	x8, [x8, #0xf30]
1004acd60:	mov	x9, #0x4030000000000000
1004acd64:	str	x9, [x20, x8]
1004acd68:	adrp	x8, 7848 ; 0x102354000
1004acd6c:	ldr	x8, [x8, #0xf38]
1004acd70:	mov	x9, #0x403c000000000000
1004acd74:	str	x9, [x20, x8]
1004acd78:	adrp	x8, 7848 ; 0x102354000
1004acd7c:	ldr	x8, [x8, #0xf40]
1004acd80:	mov	x9, #0x4069000000000000
1004acd84:	str	x9, [x20, x8]
1004acd88:	bl	0x1004ad05c
1004acd8c:	stp	x20, x0, [sp]
1004acd90:	adrp	x8, 7798 ; 0x102322000
1004acd94:	ldr	x1, [x8, #0xfd8] ; Objc selector ref: initWithCoder:
1004acd98:	mov	x0, sp
1004acd9c:	mov	x2, x19
1004acda0:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithCoder:]
1004acda4:	mov	x29, x29
1004acda8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004acdac:	mov	x20, x0
1004acdb0:	mov	x0, x19
1004acdb4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004acdb8:	cbz	x20, 0x1004acdc4
1004acdbc:	mov	x0, x20
1004acdc0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004acdc4:	mov	x0, x20
1004acdc8:	ldp	x29, x30, [sp, #0x20]
1004acdcc:	ldp	x20, x19, [sp, #0x10]
1004acdd0:	add	sp, sp, #0x30
1004acdd4:	ret
1004acdd8:	stp	x20, x19, [sp, #-0x20]!
1004acddc:	stp	x29, x30, [sp, #0x10]
1004acde0:	add	x29, sp, #0x10
1004acde4:	mov	x20, x0
1004acde8:	mov	x0, x2
1004acdec:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004acdf0:	bl	0x1004accd4
1004acdf4:	ldp	x29, x30, [sp, #0x10]
1004acdf8:	ldp	x20, x19, [sp], #0x20
1004acdfc:	ret
1004ace00:	sub	sp, sp, #0x40
1004ace04:	stp	x20, x19, [sp, #0x20]
1004ace08:	stp	x29, x30, [sp, #0x30]
1004ace0c:	add	x29, sp, #0x30
1004ace10:	adrp	x8, 7920 ; 0x10239c000
1004ace14:	ldr	x8, [x8, #0xf30]
1004ace18:	cmn	x8, #0x1
1004ace1c:	b.ne	0x1004aceec
1004ace20:	adrp	x0, 7920 ; 0x10239c000
1004ace24:	add	x0, x0, #0xf38
1004ace28:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004ace2c:	cbz	x0, 0x1004ace70
1004ace30:	adrp	x8, 7848 ; 0x102354000
1004ace34:	ldr	x20, [x8, #0xef8]
1004ace38:	ldr	x8, [x0, x20]
1004ace3c:	cbz	x8, 0x1004ace5c
1004ace40:	mov	x19, x0
1004ace44:	mov	x0, x8
1004ace48:	mov	x2, #0x0
1004ace4c:	bl	0x101acfec0 ; selector orderOut:
1004ace50:	mov	x0, x19
1004ace54:	ldr	x19, [x19, x20]
1004ace58:	b	0x1004ace60
1004ace5c:	mov	x19, #0x0
1004ace60:	str	xzr, [x0, x20]
1004ace64:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ace68:	mov	x0, x19
1004ace6c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ace70:	adrp	x0, 7920 ; 0x10239c000
1004ace74:	add	x0, x0, #0xf38
1004ace78:	mov	x1, #0x0
1004ace7c:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004ace80:	adrp	x8, 7920 ; 0x10239c000
1004ace84:	ldr	x8, [x8, #0xf18]
1004ace88:	cmn	x8, #0x1
1004ace8c:	b.ne	0x1004acf04
1004ace90:	adrp	x19, 7981 ; 0x1023d9000
1004ace94:	add	x19, x19, #0xf80
1004ace98:	add	x1, sp, #0x8
1004ace9c:	mov	x0, x19
1004acea0:	mov	w2, #0x1
1004acea4:	mov	x3, #0x0
1004acea8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004aceac:	mov	x0, x19
1004aceb0:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004aceb4:	cbz	x0, 0x1004acecc
1004aceb8:	mov	x19, x0
1004acebc:	mov	x2, #0x0
1004acec0:	bl	0x101acfec0 ; selector orderOut:
1004acec4:	mov	x0, x19
1004acec8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004acecc:	adrp	x0, 7981 ; 0x1023d9000
1004aced0:	add	x0, x0, #0xf80
1004aced4:	mov	x1, #0x0
1004aced8:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004acedc:	ldp	x29, x30, [sp, #0x30]
1004acee0:	ldp	x20, x19, [sp, #0x20]
1004acee4:	add	sp, sp, #0x40
1004acee8:	ret
1004aceec:	adrp	x0, 7920 ; 0x10239c000
1004acef0:	add	x0, x0, #0xf30
1004acef4:	adrp	x1, -3 ; 0x1004a9000
1004acef8:	add	x1, x1, #0xcb4
1004acefc:	bl	0x101aca948 ; symbol stub for: _swift_once
1004acf00:	b	0x1004ace20
1004acf04:	adrp	x0, 7920 ; 0x10239c000
1004acf08:	add	x0, x0, #0xf18
1004acf0c:	adrp	x1, -3 ; 0x1004a9000
1004acf10:	add	x1, x1, #0xa7c
1004acf14:	bl	0x101aca948 ; symbol stub for: _swift_once
1004acf18:	b	0x1004ace90
1004acf1c:	sub	sp, sp, #0x40
1004acf20:	stp	x20, x19, [sp, #0x20]
1004acf24:	stp	x29, x30, [sp, #0x30]
1004acf28:	add	x29, sp, #0x30
1004acf2c:	adrp	x8, 7920 ; 0x10239c000
1004acf30:	ldr	x8, [x8, #0xf20]
1004acf34:	cmn	x8, #0x1
1004acf38:	b.ne	0x1004ad00c
1004acf3c:	adrp	x0, 7920 ; 0x10239c000
1004acf40:	add	x0, x0, #0xf28
1004acf44:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004acf48:	cbz	x0, 0x1004acf8c
1004acf4c:	adrp	x8, 7848 ; 0x102354000
1004acf50:	ldr	x20, [x8, #0xea0]
1004acf54:	ldr	x8, [x0, x20]
1004acf58:	cbz	x8, 0x1004acf78
1004acf5c:	mov	x19, x0
1004acf60:	mov	x0, x8
1004acf64:	mov	x2, #0x0
1004acf68:	bl	0x101acfec0 ; selector orderOut:
1004acf6c:	mov	x0, x19
1004acf70:	ldr	x19, [x19, x20]
1004acf74:	b	0x1004acf7c
1004acf78:	mov	x19, #0x0
1004acf7c:	str	xzr, [x0, x20]
1004acf80:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004acf84:	mov	x0, x19
1004acf88:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004acf8c:	adrp	x0, 7920 ; 0x10239c000
1004acf90:	add	x0, x0, #0xf28
1004acf94:	mov	x1, #0x0
1004acf98:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004acf9c:	adrp	x8, 7920 ; 0x10239c000
1004acfa0:	ldr	x8, [x8, #0xf10]
1004acfa4:	cmn	x8, #0x1
1004acfa8:	b.ne	0x1004ad024
1004acfac:	adrp	x19, 7981 ; 0x1023d9000
1004acfb0:	add	x19, x19, #0xf78
1004acfb4:	add	x1, sp, #0x8
1004acfb8:	mov	x0, x19
1004acfbc:	mov	w2, #0x1
1004acfc0:	mov	x3, #0x0
1004acfc4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004acfc8:	mov	x0, x19
1004acfcc:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004acfd0:	cbz	x0, 0x1004acfe8
1004acfd4:	mov	x19, x0
1004acfd8:	mov	x2, #0x0
1004acfdc:	bl	0x101acfec0 ; selector orderOut:
1004acfe0:	mov	x0, x19
1004acfe4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004acfe8:	adrp	x0, 7981 ; 0x1023d9000
1004acfec:	add	x0, x0, #0xf78
1004acff0:	mov	x1, #0x0
1004acff4:	bl	0x101acaa98 ; symbol stub for: _swift_unknownObjectWeakAssign
1004acff8:	bl	0x1004ace00
1004acffc:	ldp	x29, x30, [sp, #0x30]
1004ad000:	ldp	x20, x19, [sp, #0x20]
1004ad004:	add	sp, sp, #0x40
1004ad008:	ret
1004ad00c:	adrp	x0, 7919 ; 0x10239c000
1004ad010:	add	x0, x0, #0xf20
1004ad014:	adrp	x1, -4 ; 0x1004a9000
1004ad018:	add	x1, x1, #0x960
1004ad01c:	bl	0x101aca948 ; symbol stub for: _swift_once
1004ad020:	b	0x1004acf3c
1004ad024:	adrp	x0, 7919 ; 0x10239c000
1004ad028:	add	x0, x0, #0xf10
1004ad02c:	adrp	x1, -4 ; 0x1004a9000
1004ad030:	add	x1, x1, #0x970
1004ad034:	bl	0x101aca948 ; symbol stub for: _swift_once
1004ad038:	b	0x1004acfac
1004ad03c:	stp	x29, x30, [sp, #-0x10]!
1004ad040:	mov	x29, sp
1004ad044:	adrp	x0, 7811 ; 0x102330000
1004ad048:	add	x0, x0, #0xdf8
1004ad04c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004ad050:	mov	x1, #0x0
1004ad054:	ldp	x29, x30, [sp], #0x10
1004ad058:	ret
1004ad05c:	stp	x29, x30, [sp, #-0x10]!
1004ad060:	mov	x29, sp
1004ad064:	adrp	x0, 7812 ; 0x102331000
1004ad068:	add	x0, x0, #0x18
1004ad06c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004ad070:	mov	x1, #0x0
1004ad074:	ldp	x29, x30, [sp], #0x10
1004ad078:	ret
1004ad07c:	sub	sp, sp, #0x30
1004ad080:	stp	x20, x19, [sp, #0x10]
1004ad084:	stp	x29, x30, [sp, #0x20]
1004ad088:	add	x29, sp, #0x20
1004ad08c:	str	x2, [sp, #0x8]
1004ad090:	ldr	x8, [x0]
1004ad094:	ldrb	w9, [x20, x8]
1004ad098:	mov	w10, #0x1
1004ad09c:	strb	w10, [x20, x8]
1004ad0a0:	tbnz	w9, #0x0, 0x1004ad0c4
1004ad0a4:	mov	x19, x1
1004ad0a8:	mov	x0, x20
1004ad0ac:	bl	0x1004adb68
1004ad0b0:	ldr	x9, [x19]
1004ad0b4:	ldr	x8, [x20, x9]
1004ad0b8:	str	x0, [x20, x9]
1004ad0bc:	mov	x0, x8
1004ad0c0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ad0c4:	mov	x0, x20
1004ad0c8:	bl	0x101acbde0 ; selector bounds
1004ad0cc:	mov	x0, x20
1004ad0d0:	bl	0x101ad3820 ; selector setNeedsDisplayInRect:
1004ad0d4:	ldr	x0, [sp, #0x8]
1004ad0d8:	ldp	x29, x30, [sp, #0x20]
1004ad0dc:	ldp	x20, x19, [sp, #0x10]
1004ad0e0:	add	sp, sp, #0x30
1004ad0e4:	br	x0
1004ad0e8:	stp	x22, x21, [sp, #-0x30]!
1004ad0ec:	stp	x20, x19, [sp, #0x10]
1004ad0f0:	stp	x29, x30, [sp, #0x20]
1004ad0f4:	add	x29, sp, #0x20
1004ad0f8:	ldr	x8, [x0]
1004ad0fc:	ldrb	w9, [x20, x8]
1004ad100:	strb	wzr, [x20, x8]
1004ad104:	cmp	w9, #0x1
1004ad108:	b.ne	0x1004ad13c
1004ad10c:	ldr	x21, [x1]
1004ad110:	ldr	x19, [x20, x21]
1004ad114:	mov	x0, x19
1004ad118:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004ad11c:	bl	0x1004adb6c
1004ad120:	mov	x0, x19
1004ad124:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ad128:	ldr	x0, [x20, x21]
1004ad12c:	adrp	x8, 7714 ; 0x1022cf000
1004ad130:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004ad134:	str	x8, [x20, x21]
1004ad138:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ad13c:	mov	x0, x20
1004ad140:	bl	0x101acbde0 ; selector bounds
1004ad144:	mov	x0, x20
1004ad148:	ldp	x29, x30, [sp, #0x20]
1004ad14c:	ldp	x20, x19, [sp, #0x10]
1004ad150:	ldp	x22, x21, [sp], #0x30
1004ad154:	b	0x101ad3820 ; selector setNeedsDisplayInRect:
1004ad158:	stp	x29, x30, [sp, #-0x10]!
1004ad15c:	mov	x29, sp
1004ad160:	ldr	x0, [x20, #0x18]
1004ad164:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ad168:	mov	x0, x20
1004ad16c:	mov	w1, #0x20
1004ad170:	mov	w2, #0x7
1004ad174:	ldp	x29, x30, [sp], #0x10
1004ad178:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004ad17c:	stp	x29, x30, [sp, #-0x10]!
1004ad180:	mov	x29, sp
1004ad184:	add	x0, x20, #0x10
1004ad188:	bl	0x101acaabc ; symbol stub for: _swift_unknownObjectWeakDestroy
1004ad18c:	mov	x0, x20
1004ad190:	mov	w1, #0x18
1004ad194:	mov	w2, #0x7
1004ad198:	ldp	x29, x30, [sp], #0x10
1004ad19c:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004ad1a0:	adrp	x0, 7847 ; 0x102354000
1004ad1a4:	add	x0, x0, #0xf28
1004ad1a8:	b	0x1004ad1e8
1004ad1ac:	b	0x1004ad1b0
1004ad1b0:	stp	x29, x30, [sp, #-0x10]!
1004ad1b4:	mov	x29, sp
1004ad1b8:	ldr	x0, [x20, #0x18]
1004ad1bc:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ad1c0:	ldr	x0, [x20, #0x20]
1004ad1c4:	bl	0x101aca960 ; symbol stub for: _swift_release
1004ad1c8:	mov	x0, x20
1004ad1cc:	mov	w1, #0x28
1004ad1d0:	mov	w2, #0x7
1004ad1d4:	ldp	x29, x30, [sp], #0x10
1004ad1d8:	b	0x101aca6a8 ; symbol stub for: _swift_deallocObject
1004ad1dc:	adrp	x0, 7847 ; 0x102354000
1004ad1e0:	add	x0, x0, #0xed8
1004ad1e4:	b	0x1004ad1e8
1004ad1e8:	sub	sp, sp, #0x50
1004ad1ec:	stp	x22, x21, [sp, #0x20]
1004ad1f0:	stp	x20, x19, [sp, #0x30]
1004ad1f4:	stp	x29, x30, [sp, #0x40]
1004ad1f8:	add	x29, sp, #0x40
1004ad1fc:	mov	x19, x0
1004ad200:	ldp	x9, x8, [x20, #0x10]
1004ad204:	ldr	x21, [x20, #0x20]
1004ad208:	mov	x20, x8
1004ad20c:	blr	x9
1004ad210:	add	x0, x21, #0x10
1004ad214:	add	x1, sp, #0x8
1004ad218:	mov	x2, #0x0
1004ad21c:	mov	x3, #0x0
1004ad220:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004ad224:	add	x0, x21, #0x10
1004ad228:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004ad22c:	cbz	x0, 0x1004ad274
1004ad230:	ldr	x8, [x19]
1004ad234:	mov	x19, x0
1004ad238:	add	x0, x0, x8
1004ad23c:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004ad240:	mov	x20, x0
1004ad244:	mov	x0, x19
1004ad248:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad24c:	cbz	x20, 0x1004ad274
1004ad250:	ldr	x8, [x20]
1004ad254:	adrp	x9, 7714 ; 0x1022cf000
1004ad258:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004ad25c:	ldr	x9, [x9]
1004ad260:	and	x8, x9, x8
1004ad264:	ldr	x8, [x8, #0x248]
1004ad268:	blr	x8
1004ad26c:	mov	x0, x20
1004ad270:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad274:	ldp	x29, x30, [sp, #0x40]
1004ad278:	ldp	x20, x19, [sp, #0x30]
1004ad27c:	ldp	x22, x21, [sp, #0x20]
1004ad280:	add	sp, sp, #0x50
1004ad284:	ret
1004ad288:	b	0x1004ad158
1004ad28c:	b	0x1004ad17c
1004ad290:	b	0x1004ad1ac
1004ad294:	b	0x1004ad1ac
1004ad298:	b	0x1004ad1dc
1004ad29c:	adrp	x0, 5704 ; 0x101af5000
1004ad2a0:	add	x0, x0, #0xd00
1004ad2a4:	ret
1004ad2a8:	mov	x8, #-0x8000000000000000
1004ad2ac:	fmov	d4, x8
1004ad2b0:	b	0x1004ad2bc
1004ad2b4:	movi.2d	v4, #0000000000000000
1004ad2b8:	b	0x1004ad2bc
1004ad2bc:	mov.16b	v5, v4
1004ad2c0:	b	0x101ac8dc4 ; symbol stub for: _CGRectInset
1004ad2c4:	stp	d11, d10, [sp, #-0x40]!
1004ad2c8:	stp	d9, d8, [sp, #0x10]
1004ad2cc:	stp	x20, x19, [sp, #0x20]
1004ad2d0:	stp	x29, x30, [sp, #0x30]
1004ad2d4:	add	x29, sp, #0x30
1004ad2d8:	mov.16b	v8, v2
1004ad2dc:	mov.16b	v9, v1
1004ad2e0:	mov.16b	v10, v0
1004ad2e4:	adrp	x8, 7801 ; 0x102326000
1004ad2e8:	ldr	x0, [x8, #0xa40] ; Objc class ref: _OBJC_CLASS_$_NSView
1004ad2ec:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004ad2f0:	movi.2d	v0, #0000000000000000
1004ad2f4:	movi.2d	v1, #0000000000000000
1004ad2f8:	mov.16b	v2, v10
1004ad2fc:	mov.16b	v3, v9
1004ad300:	bl	0x101ace5a0 ; selector initWithFrame:
1004ad304:	mov	x19, x0
1004ad308:	mov	w2, #0x1
1004ad30c:	bl	0x101ad4ca0 ; selector setWantsLayer:
1004ad310:	mov	x0, x19
1004ad314:	bl	0x101acf2c0 ; selector layer
1004ad318:	mov	x29, x29
1004ad31c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ad320:	mov	x20, x0
1004ad324:	mov.16b	v0, v8
1004ad328:	bl	0x101ad2440 ; selector setCornerRadius:
1004ad32c:	mov	x0, x20
1004ad330:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad334:	mov	x0, x19
1004ad338:	bl	0x101acf2c0 ; selector layer
1004ad33c:	mov	x29, x29
1004ad340:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ad344:	cbz	x0, 0x1004ad364
1004ad348:	adrp	x8, 7709 ; 0x1022ca000
1004ad34c:	ldr	x8, [x8, #0x7f0] ; literal pool symbol address: _kCACornerCurveContinuous
1004ad350:	ldr	x2, [x8]
1004ad354:	mov	x20, x0
1004ad358:	bl	0x101ad2420 ; selector setCornerCurve:
1004ad35c:	mov	x0, x20
1004ad360:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad364:	mov	x0, x19
1004ad368:	bl	0x101acf2c0 ; selector layer
1004ad36c:	mov	x29, x29
1004ad370:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ad374:	mov	x20, x0
1004ad378:	mov	w2, #0x1
1004ad37c:	bl	0x101ad3520 ; selector setMasksToBounds:
1004ad380:	mov	x0, x20
1004ad384:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad388:	mov	x0, x19
1004ad38c:	bl	0x101acbde0 ; selector bounds
1004ad390:	mov.16b	v8, v0
1004ad394:	mov.16b	v9, v1
1004ad398:	mov.16b	v10, v2
1004ad39c:	mov.16b	v11, v3
1004ad3a0:	adrp	x8, 7801 ; 0x102326000
1004ad3a4:	ldr	x0, [x8, #0x9f8] ; Objc class ref: _OBJC_CLASS_$_NSVisualEffectView
1004ad3a8:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004ad3ac:	mov.16b	v0, v8
1004ad3b0:	mov.16b	v1, v9
1004ad3b4:	mov.16b	v2, v10
1004ad3b8:	mov.16b	v3, v11
1004ad3bc:	bl	0x101ace5a0 ; selector initWithFrame:
1004ad3c0:	mov	x20, x0
1004ad3c4:	mov	w2, #0x5
1004ad3c8:	bl	0x101ad3540 ; selector setMaterial:
1004ad3cc:	mov	x0, x20
1004ad3d0:	mov	w2, #0x1
1004ad3d4:	bl	0x101ad4360 ; selector setState:
1004ad3d8:	mov	x0, x20
1004ad3dc:	mov	x2, #0x0
1004ad3e0:	bl	0x101ad1ee0 ; selector setBlendingMode:
1004ad3e4:	mov	x0, x20
1004ad3e8:	mov	w2, #0x12
1004ad3ec:	bl	0x101ad1dc0 ; selector setAutoresizingMask:
1004ad3f0:	mov	x0, x19
1004ad3f4:	mov	x2, x20
1004ad3f8:	bl	0x101acb460 ; selector addSubview:
1004ad3fc:	mov	x0, x19
1004ad400:	mov	x1, x20
1004ad404:	ldp	x29, x30, [sp, #0x30]
1004ad408:	ldp	x20, x19, [sp, #0x20]
1004ad40c:	ldp	d9, d8, [sp, #0x10]
1004ad410:	ldp	d11, d10, [sp], #0x40
1004ad414:	ret
1004ad418:	sub	sp, sp, #0x60
1004ad41c:	stp	d9, d8, [sp, #0x20]
1004ad420:	stp	x22, x21, [sp, #0x30]
1004ad424:	stp	x20, x19, [sp, #0x40]
1004ad428:	stp	x29, x30, [sp, #0x50]
1004ad42c:	add	x29, sp, #0x50
1004ad430:	mov.16b	v8, v0
1004ad434:	adrp	x8, 7847 ; 0x102354000
1004ad438:	ldr	x21, [x8, #0xfa0]
1004ad43c:	add	x0, x20, x21
1004ad440:	add	x1, sp, #0x8
1004ad444:	mov	w2, #0x1
1004ad448:	mov	x3, #0x0
1004ad44c:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004ad450:	str	d8, [x20, x21]
1004ad454:	mov	x0, x20
1004ad458:	bl	0x101acf2c0 ; selector layer
1004ad45c:	mov	x29, x29
1004ad460:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ad464:	cbz	x0, 0x1004ad4a4
1004ad468:	mov	x19, x0
1004ad46c:	mov	x0, x20
1004ad470:	bl	0x101acbde0 ; selector bounds
1004ad474:	ldr	d4, [x20, x21]
1004ad478:	mov	x0, #0x0
1004ad47c:	mov.16b	v5, v4
1004ad480:	bl	0x101ac8d1c ; symbol stub for: _CGPathCreateWithRoundedRect
1004ad484:	mov	x20, x0
1004ad488:	mov	x0, x19
1004ad48c:	mov	x2, x20
1004ad490:	bl	0x101ad4140 ; selector setShadowPath:
1004ad494:	mov	x0, x19
1004ad498:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad49c:	mov	x0, x20
1004ad4a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad4a4:	ldp	x29, x30, [sp, #0x50]
1004ad4a8:	ldp	x20, x19, [sp, #0x40]
1004ad4ac:	ldp	x22, x21, [sp, #0x30]
1004ad4b0:	ldp	d9, d8, [sp, #0x20]
1004ad4b4:	add	sp, sp, #0x60
1004ad4b8:	ret
1004ad4bc:	sub	sp, sp, #0x70
1004ad4c0:	stp	d11, d10, [sp, #0x20]
1004ad4c4:	stp	d9, d8, [sp, #0x30]
1004ad4c8:	stp	x22, x21, [sp, #0x40]
1004ad4cc:	stp	x20, x19, [sp, #0x50]
1004ad4d0:	stp	x29, x30, [sp, #0x60]
1004ad4d4:	add	x29, sp, #0x60
1004ad4d8:	mov	x0, x20
1004ad4dc:	bl	0x101acf2c0 ; selector layer
1004ad4e0:	mov	x29, x29
1004ad4e4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ad4e8:	cbz	x0, 0x1004ad564
1004ad4ec:	mov	x19, x0
1004ad4f0:	mov	x0, x20
1004ad4f4:	bl	0x101acbde0 ; selector bounds
1004ad4f8:	mov.16b	v8, v0
1004ad4fc:	mov.16b	v9, v1
1004ad500:	mov.16b	v10, v2
1004ad504:	mov.16b	v11, v3
1004ad508:	adrp	x8, 7847 ; 0x102354000
1004ad50c:	ldr	x21, [x8, #0xfa0]
1004ad510:	add	x0, x20, x21
1004ad514:	add	x1, sp, #0x8
1004ad518:	mov	x2, #0x0
1004ad51c:	mov	x3, #0x0
1004ad520:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004ad524:	ldr	d4, [x20, x21]
1004ad528:	mov.16b	v0, v8
1004ad52c:	mov.16b	v1, v9
1004ad530:	mov.16b	v2, v10
1004ad534:	mov.16b	v3, v11
1004ad538:	mov	x0, #0x0
1004ad53c:	mov.16b	v5, v4
1004ad540:	bl	0x101ac8d1c ; symbol stub for: _CGPathCreateWithRoundedRect
1004ad544:	mov	x20, x0
1004ad548:	mov	x0, x19
1004ad54c:	mov	x2, x20
1004ad550:	bl	0x101ad4140 ; selector setShadowPath:
1004ad554:	mov	x0, x19
1004ad558:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad55c:	mov	x0, x20
1004ad560:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad564:	ldp	x29, x30, [sp, #0x60]
1004ad568:	ldp	x20, x19, [sp, #0x50]
1004ad56c:	ldp	x22, x21, [sp, #0x40]
1004ad570:	ldp	d9, d8, [sp, #0x30]
1004ad574:	ldp	d11, d10, [sp, #0x20]
1004ad578:	add	sp, sp, #0x70
1004ad57c:	ret
1004ad580:	sub	sp, sp, #0x40
1004ad584:	stp	x20, x19, [sp, #0x20]
1004ad588:	stp	x29, x30, [sp, #0x30]
1004ad58c:	add	x29, sp, #0x30
1004ad590:	adrp	x8, 7847 ; 0x102354000
1004ad594:	ldr	x19, [x8, #0xfa0]
1004ad598:	add	x0, x20, x19
1004ad59c:	add	x1, sp, #0x8
1004ad5a0:	mov	x2, #0x0
1004ad5a4:	mov	x3, #0x0
1004ad5a8:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004ad5ac:	ldr	d0, [x20, x19]
1004ad5b0:	ldp	x29, x30, [sp, #0x30]
1004ad5b4:	ldp	x20, x19, [sp, #0x20]
1004ad5b8:	add	sp, sp, #0x40
1004ad5bc:	ret
1004ad5c0:	stp	x20, x19, [sp, #-0x20]!
1004ad5c4:	stp	x29, x30, [sp, #0x10]
1004ad5c8:	add	x29, sp, #0x10
1004ad5cc:	mov	x19, x0
1004ad5d0:	mov	w0, #0x28
1004ad5d4:	adrp	x8, 7714 ; 0x1022cf000
1004ad5d8:	ldr	x8, [x8, #0x560] ; literal pool symbol address: _swift_coroFrameAlloc
1004ad5dc:	cbz	x8, 0x1004ad5ec
1004ad5e0:	mov	w1, #0xe803
1004ad5e4:	bl	0x101aca684 ; symbol stub for: _swift_coroFrameAlloc
1004ad5e8:	b	0x1004ad5f0
1004ad5ec:	bl	0x101ac9bf8 ; symbol stub for: _malloc
1004ad5f0:	mov	x1, x0
1004ad5f4:	str	x0, [x19]
1004ad5f8:	adrp	x8, 7847 ; 0x102354000
1004ad5fc:	ldr	x19, [x8, #0xfa0]
1004ad600:	stp	x20, x19, [x0, #0x18]
1004ad604:	add	x0, x20, x19
1004ad608:	mov	w2, #0x21
1004ad60c:	mov	x3, #0x0
1004ad610:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004ad614:	adrp	x0, 0 ; 0x1004ad000
1004ad618:	add	x0, x0, #0x62c
1004ad61c:	add	x1, x20, x19
1004ad620:	ldp	x29, x30, [sp, #0x10]
1004ad624:	ldp	x20, x19, [sp], #0x20
1004ad628:	ret
1004ad62c:	stp	x22, x21, [sp, #-0x30]!
1004ad630:	stp	x20, x19, [sp, #0x10]
1004ad634:	stp	x29, x30, [sp, #0x20]
1004ad638:	add	x29, sp, #0x20
1004ad63c:	mov	x20, x1
1004ad640:	ldr	x19, [x0]
1004ad644:	mov	x0, x19
1004ad648:	bl	0x101aca738 ; symbol stub for: _swift_endAccess
1004ad64c:	tbnz	w20, #0x0, 0x1004ad6a4
1004ad650:	ldr	x0, [x19, #0x18]
1004ad654:	bl	0x101acf2c0 ; selector layer
1004ad658:	mov	x29, x29
1004ad65c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ad660:	cbz	x0, 0x1004ad6a4
1004ad664:	mov	x20, x0
1004ad668:	ldp	x21, x22, [x19, #0x18]
1004ad66c:	mov	x0, x21
1004ad670:	bl	0x101acbde0 ; selector bounds
1004ad674:	ldr	d4, [x21, x22]
1004ad678:	mov	x0, #0x0
1004ad67c:	mov.16b	v5, v4
1004ad680:	bl	0x101ac8d1c ; symbol stub for: _CGPathCreateWithRoundedRect
1004ad684:	mov	x21, x0
1004ad688:	mov	x0, x20
1004ad68c:	mov	x2, x21
1004ad690:	bl	0x101ad4140 ; selector setShadowPath:
1004ad694:	mov	x0, x21
1004ad698:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad69c:	mov	x0, x20
1004ad6a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad6a4:	mov	x0, x19
1004ad6a8:	ldp	x29, x30, [sp, #0x20]
1004ad6ac:	ldp	x20, x19, [sp, #0x10]
1004ad6b0:	ldp	x22, x21, [sp], #0x30
1004ad6b4:	b	0x101ac99dc ; symbol stub for: _free
1004ad6b8:	sub	sp, sp, #0x80
1004ad6bc:	stp	d11, d10, [sp, #0x30]
1004ad6c0:	stp	d9, d8, [sp, #0x40]
1004ad6c4:	stp	x22, x21, [sp, #0x50]
1004ad6c8:	stp	x20, x19, [sp, #0x60]
1004ad6cc:	stp	x29, x30, [sp, #0x70]
1004ad6d0:	add	x29, sp, #0x70
1004ad6d4:	mov.16b	v8, v1
1004ad6d8:	mov.16b	v9, v0
1004ad6dc:	mov	x0, x20
1004ad6e0:	bl	0x101aca7f8 ; symbol stub for: _swift_getObjectType
1004ad6e4:	stp	x20, x0, [sp, #0x20]
1004ad6e8:	adrp	x8, 7799 ; 0x102324000
1004ad6ec:	ldr	x1, [x8, #0x1f0] ; Objc selector ref: setFrameSize:
1004ad6f0:	add	x0, sp, #0x20
1004ad6f4:	mov.16b	v0, v9
1004ad6f8:	mov.16b	v1, v8
1004ad6fc:	bl	0x101ac9d0c ; Objc message: -[[x0 super] setFrameSize:]
1004ad700:	mov	x0, x20
1004ad704:	bl	0x101acf2c0 ; selector layer
1004ad708:	mov	x29, x29
1004ad70c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ad710:	cbz	x0, 0x1004ad78c
1004ad714:	mov	x19, x0
1004ad718:	mov	x0, x20
1004ad71c:	bl	0x101acbde0 ; selector bounds
1004ad720:	mov.16b	v8, v0
1004ad724:	mov.16b	v9, v1
1004ad728:	mov.16b	v10, v2
1004ad72c:	mov.16b	v11, v3
1004ad730:	adrp	x8, 7847 ; 0x102354000
1004ad734:	ldr	x21, [x8, #0xfa0]
1004ad738:	add	x0, x20, x21
1004ad73c:	add	x1, sp, #0x8
1004ad740:	mov	x2, #0x0
1004ad744:	mov	x3, #0x0
1004ad748:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004ad74c:	ldr	d4, [x20, x21]
1004ad750:	mov.16b	v0, v8
1004ad754:	mov.16b	v1, v9
1004ad758:	mov.16b	v2, v10
1004ad75c:	mov.16b	v3, v11
1004ad760:	mov	x0, #0x0
1004ad764:	mov.16b	v5, v4
1004ad768:	bl	0x101ac8d1c ; symbol stub for: _CGPathCreateWithRoundedRect
1004ad76c:	mov	x20, x0
1004ad770:	mov	x0, x19
1004ad774:	mov	x2, x20
1004ad778:	bl	0x101ad4140 ; selector setShadowPath:
1004ad77c:	mov	x0, x19
1004ad780:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad784:	mov	x0, x20
1004ad788:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad78c:	ldp	x29, x30, [sp, #0x70]
1004ad790:	ldp	x20, x19, [sp, #0x60]
1004ad794:	ldp	x22, x21, [sp, #0x50]
1004ad798:	ldp	d9, d8, [sp, #0x40]
1004ad79c:	ldp	d11, d10, [sp, #0x30]
1004ad7a0:	add	sp, sp, #0x80
1004ad7a4:	ret
1004ad7a8:	stp	d9, d8, [sp, #-0x30]!
1004ad7ac:	stp	x20, x19, [sp, #0x10]
1004ad7b0:	stp	x29, x30, [sp, #0x20]
1004ad7b4:	add	x29, sp, #0x20
1004ad7b8:	mov.16b	v8, v1
1004ad7bc:	mov.16b	v9, v0
1004ad7c0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ad7c4:	mov	x20, x0
1004ad7c8:	mov.16b	v0, v9
1004ad7cc:	mov.16b	v1, v8
1004ad7d0:	bl	0x1004ad6b8
1004ad7d4:	mov	x0, x20
1004ad7d8:	ldp	x29, x30, [sp, #0x20]
1004ad7dc:	ldp	x20, x19, [sp, #0x10]
1004ad7e0:	ldp	d9, d8, [sp], #0x30
1004ad7e4:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004ad7e8:	sub	sp, sp, #0x80
1004ad7ec:	stp	d11, d10, [sp, #0x30]
1004ad7f0:	stp	d9, d8, [sp, #0x40]
1004ad7f4:	stp	x22, x21, [sp, #0x50]
1004ad7f8:	stp	x20, x19, [sp, #0x60]
1004ad7fc:	stp	x29, x30, [sp, #0x70]
1004ad800:	add	x29, sp, #0x70
1004ad804:	mov	x0, x20
1004ad808:	bl	0x101aca7f8 ; symbol stub for: _swift_getObjectType
1004ad80c:	stp	x20, x0, [sp, #0x20]
1004ad810:	adrp	x8, 7796 ; 0x102321000
1004ad814:	ldr	x1, [x8, #0x3f0] ; Objc selector ref: layout
1004ad818:	add	x0, sp, #0x20
1004ad81c:	bl	0x101ac9d0c ; Objc message: -[[x0 super] layout]
1004ad820:	mov	x0, x20
1004ad824:	bl	0x101acf2c0 ; selector layer
1004ad828:	mov	x29, x29
1004ad82c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ad830:	cbz	x0, 0x1004ad8ac
1004ad834:	mov	x19, x0
1004ad838:	mov	x0, x20
1004ad83c:	bl	0x101acbde0 ; selector bounds
1004ad840:	mov.16b	v8, v0
1004ad844:	mov.16b	v9, v1
1004ad848:	mov.16b	v10, v2
1004ad84c:	mov.16b	v11, v3
1004ad850:	adrp	x8, 7847 ; 0x102354000
1004ad854:	ldr	x21, [x8, #0xfa0]
1004ad858:	add	x0, x20, x21
1004ad85c:	add	x1, sp, #0x8
1004ad860:	mov	x2, #0x0
1004ad864:	mov	x3, #0x0
1004ad868:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004ad86c:	ldr	d4, [x20, x21]
1004ad870:	mov.16b	v0, v8
1004ad874:	mov.16b	v1, v9
1004ad878:	mov.16b	v2, v10
1004ad87c:	mov.16b	v3, v11
1004ad880:	mov	x0, #0x0
1004ad884:	mov.16b	v5, v4
1004ad888:	bl	0x101ac8d1c ; symbol stub for: _CGPathCreateWithRoundedRect
1004ad88c:	mov	x20, x0
1004ad890:	mov	x0, x19
1004ad894:	mov	x2, x20
1004ad898:	bl	0x101ad4140 ; selector setShadowPath:
1004ad89c:	mov	x0, x19
1004ad8a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad8a4:	mov	x0, x20
1004ad8a8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ad8ac:	ldp	x29, x30, [sp, #0x70]
1004ad8b0:	ldp	x20, x19, [sp, #0x60]
1004ad8b4:	ldp	x22, x21, [sp, #0x50]
1004ad8b8:	ldp	d9, d8, [sp, #0x40]
1004ad8bc:	ldp	d11, d10, [sp, #0x30]
1004ad8c0:	add	sp, sp, #0x80
1004ad8c4:	ret
1004ad8c8:	stp	x20, x19, [sp, #-0x20]!
1004ad8cc:	stp	x29, x30, [sp, #0x10]
1004ad8d0:	add	x29, sp, #0x10
1004ad8d4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ad8d8:	mov	x20, x0
1004ad8dc:	bl	0x1004ad7e8
1004ad8e0:	mov	x0, x20
1004ad8e4:	ldp	x29, x30, [sp, #0x10]
1004ad8e8:	ldp	x20, x19, [sp], #0x20
1004ad8ec:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004ad8f0:	sub	sp, sp, #0x40
1004ad8f4:	stp	d11, d10, [sp, #0x10]
1004ad8f8:	stp	d9, d8, [sp, #0x20]
1004ad8fc:	stp	x29, x30, [sp, #0x30]
1004ad900:	add	x29, sp, #0x30
1004ad904:	mov.16b	v8, v3
1004ad908:	mov.16b	v9, v2
1004ad90c:	mov.16b	v10, v1
1004ad910:	mov.16b	v11, v0
1004ad914:	mov	x0, x20
1004ad918:	bl	0x101aca7f8 ; symbol stub for: _swift_getObjectType
1004ad91c:	adrp	x8, 7847 ; 0x102354000
1004ad920:	ldr	x8, [x8, #0xfa0]
1004ad924:	mov	x9, #0x4020000000000000
1004ad928:	str	x9, [x20, x8]
1004ad92c:	stp	x20, x0, [sp]
1004ad930:	adrp	x8, 7798 ; 0x102323000
1004ad934:	ldr	x1, [x8, #0x50] ; Objc selector ref: initWithFrame:
1004ad938:	mov	x0, sp
1004ad93c:	mov.16b	v0, v11
1004ad940:	mov.16b	v1, v10
1004ad944:	mov.16b	v2, v9
1004ad948:	mov.16b	v3, v8
1004ad94c:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithFrame:]
1004ad950:	ldp	x29, x30, [sp, #0x30]
1004ad954:	ldp	d9, d8, [sp, #0x20]
1004ad958:	ldp	d11, d10, [sp, #0x10]
1004ad95c:	add	sp, sp, #0x40
1004ad960:	ret
1004ad964:	sub	sp, sp, #0x50
1004ad968:	stp	d11, d10, [sp, #0x10]
1004ad96c:	stp	d9, d8, [sp, #0x20]
1004ad970:	stp	x20, x19, [sp, #0x30]
1004ad974:	stp	x29, x30, [sp, #0x40]
1004ad978:	add	x29, sp, #0x40
1004ad97c:	mov.16b	v8, v3
1004ad980:	mov.16b	v9, v2
1004ad984:	mov.16b	v10, v1
1004ad988:	mov.16b	v11, v0
1004ad98c:	mov	x19, x0
1004ad990:	bl	0x101aca7f8 ; symbol stub for: _swift_getObjectType
1004ad994:	adrp	x8, 7847 ; 0x102354000
1004ad998:	ldr	x8, [x8, #0xfa0]
1004ad99c:	mov	x9, #0x4020000000000000
1004ad9a0:	str	x9, [x19, x8]
1004ad9a4:	stp	x19, x0, [sp]
1004ad9a8:	adrp	x8, 7798 ; 0x102323000
1004ad9ac:	ldr	x1, [x8, #0x50] ; Objc selector ref: initWithFrame:
1004ad9b0:	mov	x0, sp
1004ad9b4:	mov.16b	v0, v11
1004ad9b8:	mov.16b	v1, v10
1004ad9bc:	mov.16b	v2, v9
1004ad9c0:	mov.16b	v3, v8
1004ad9c4:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithFrame:]
1004ad9c8:	ldp	x29, x30, [sp, #0x40]
1004ad9cc:	ldp	x20, x19, [sp, #0x30]
1004ad9d0:	ldp	d9, d8, [sp, #0x20]
1004ad9d4:	ldp	d11, d10, [sp, #0x10]
1004ad9d8:	add	sp, sp, #0x50
1004ad9dc:	ret
1004ad9e0:	sub	sp, sp, #0x40
1004ad9e4:	stp	x22, x21, [sp, #0x10]
1004ad9e8:	stp	x20, x19, [sp, #0x20]
1004ad9ec:	stp	x29, x30, [sp, #0x30]
1004ad9f0:	add	x29, sp, #0x30
1004ad9f4:	mov	x21, x0
1004ad9f8:	mov	x0, x20
1004ad9fc:	bl	0x101aca7f8 ; symbol stub for: _swift_getObjectType
1004ada00:	adrp	x8, 7847 ; 0x102354000
1004ada04:	ldr	x8, [x8, #0xfa0]
1004ada08:	mov	x9, #0x4020000000000000
1004ada0c:	str	x9, [x20, x8]
1004ada10:	stp	x20, x0, [sp]
1004ada14:	adrp	x8, 7797 ; 0x102322000
1004ada18:	ldr	x1, [x8, #0xfd8] ; Objc selector ref: initWithCoder:
1004ada1c:	mov	x0, sp
1004ada20:	mov	x2, x21
1004ada24:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithCoder:]
1004ada28:	mov	x29, x29
1004ada2c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ada30:	mov	x19, x0
1004ada34:	mov	x0, x21
1004ada38:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ada3c:	cbz	x19, 0x1004ada48
1004ada40:	mov	x0, x19
1004ada44:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ada48:	mov	x0, x19
1004ada4c:	ldp	x29, x30, [sp, #0x30]
1004ada50:	ldp	x20, x19, [sp, #0x20]
1004ada54:	ldp	x22, x21, [sp, #0x10]
1004ada58:	add	sp, sp, #0x40
1004ada5c:	ret
1004ada60:	sub	sp, sp, #0x40
1004ada64:	stp	x22, x21, [sp, #0x10]
1004ada68:	stp	x20, x19, [sp, #0x20]
1004ada6c:	stp	x29, x30, [sp, #0x30]
1004ada70:	add	x29, sp, #0x30
1004ada74:	mov	x19, x2
1004ada78:	mov	x20, x0
1004ada7c:	bl	0x101aca7f8 ; symbol stub for: _swift_getObjectType
1004ada80:	adrp	x8, 7847 ; 0x102354000
1004ada84:	ldr	x8, [x8, #0xfa0]
1004ada88:	mov	x9, #0x4020000000000000
1004ada8c:	str	x9, [x20, x8]
1004ada90:	stp	x20, x0, [sp]
1004ada94:	adrp	x8, 7797 ; 0x102322000
1004ada98:	ldr	x20, [x8, #0xfd8] ; Objc selector ref: initWithCoder:
1004ada9c:	mov	x0, x19
1004adaa0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004adaa4:	mov	x21, x0
1004adaa8:	mov	x0, sp
1004adaac:	mov	x1, x20
1004adab0:	mov	x2, x21
1004adab4:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithCoder:]
1004adab8:	mov	x29, x29
1004adabc:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004adac0:	mov	x19, x0
1004adac4:	mov	x0, x21
1004adac8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004adacc:	cbz	x19, 0x1004adad8
1004adad0:	mov	x0, x19
1004adad4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004adad8:	mov	x0, x19
1004adadc:	ldp	x29, x30, [sp, #0x30]
1004adae0:	ldp	x20, x19, [sp, #0x20]
1004adae4:	ldp	x22, x21, [sp, #0x10]
1004adae8:	add	sp, sp, #0x40
1004adaec:	ret
1004adaf0:	adrp	x0, 7469 ; 0x1021da000
1004adaf4:	add	x0, x0, #0x910
1004adaf8:	mov	x1, #0x0
1004adafc:	ret
1004adb00:	stp	x29, x30, [sp, #-0x10]!
1004adb04:	mov	x29, sp
1004adb08:	adrp	x0, 7812 ; 0x102331000
1004adb0c:	add	x0, x0, #0x240
1004adb10:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004adb14:	mov	x1, #0x0
1004adb18:	ldp	x29, x30, [sp], #0x10
1004adb1c:	ret
1004adb20:	stp	x29, x30, [sp, #-0x10]!
1004adb24:	mov	x29, sp
1004adb28:	adrp	x8, 7801 ; 0x102326000
1004adb2c:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004adb30:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004adb34:	bl	0x101ad1460 ; selector selectedContentBackgroundColor
1004adb38:	mov	x29, x29
1004adb3c:	ldp	x29, x30, [sp], #0x10
1004adb40:	b	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004adb44:	stp	x29, x30, [sp, #-0x10]!
1004adb48:	mov	x29, sp
1004adb4c:	adrp	x8, 7801 ; 0x102326000
1004adb50:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004adb54:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004adb58:	bl	0x101ad14a0 ; selector selectedMenuItemTextColor
1004adb5c:	mov	x29, x29
1004adb60:	ldp	x29, x30, [sp], #0x10
1004adb64:	b	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004adb68:	b	0x1004aea88
1004adb6c:	b	0x1004aed30
1004adb70:	stp	x22, x21, [sp, #-0x30]!
1004adb74:	stp	x20, x19, [sp, #0x10]
1004adb78:	stp	x29, x30, [sp, #0x20]
1004adb7c:	add	x29, sp, #0x20
1004adb80:	and	w8, w0, #0x1
1004adb84:	adrp	x9, 7847 ; 0x102354000
1004adb88:	ldr	x9, [x9, #0xff8]
1004adb8c:	ldrb	w10, [x20, x9]
1004adb90:	strb	w0, [x20, x9]
1004adb94:	cmp	w8, w10
1004adb98:	b.eq	0x1004adbc0
1004adb9c:	tbz	w0, #0x0, 0x1004adbd0
1004adba0:	mov	x0, x20
1004adba4:	bl	0x1004aea88
1004adba8:	mov	x8, x0
1004adbac:	adrp	x9, 7848 ; 0x102355000
1004adbb0:	ldr	x9, [x9]
1004adbb4:	ldr	x0, [x20, x9]
1004adbb8:	str	x8, [x20, x9]
1004adbbc:	b	0x1004adc00
1004adbc0:	ldp	x29, x30, [sp, #0x20]
1004adbc4:	ldp	x20, x19, [sp, #0x10]
1004adbc8:	ldp	x22, x21, [sp], #0x30
1004adbcc:	ret
1004adbd0:	adrp	x8, 7848 ; 0x102355000
1004adbd4:	ldr	x21, [x8]
1004adbd8:	ldr	x19, [x20, x21]
1004adbdc:	mov	x0, x19
1004adbe0:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004adbe4:	bl	0x1004aed30
1004adbe8:	mov	x0, x19
1004adbec:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004adbf0:	ldr	x0, [x20, x21]
1004adbf4:	adrp	x8, 7714 ; 0x1022cf000
1004adbf8:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004adbfc:	str	x8, [x20, x21]
1004adc00:	ldp	x29, x30, [sp, #0x20]
1004adc04:	ldp	x20, x19, [sp, #0x10]
1004adc08:	ldp	x22, x21, [sp], #0x30
1004adc0c:	b	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004adc10:	sub	sp, sp, #0x40
1004adc14:	stp	x20, x19, [sp, #0x20]
1004adc18:	stp	x29, x30, [sp, #0x30]
1004adc1c:	add	x29, sp, #0x30
1004adc20:	adrp	x8, 7847 ; 0x102354000
1004adc24:	ldr	x19, [x8, #0xfd0]
1004adc28:	add	x0, x20, x19
1004adc2c:	add	x1, sp, #0x8
1004adc30:	mov	x2, #0x0
1004adc34:	mov	x3, #0x0
1004adc38:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004adc3c:	ldrb	w0, [x20, x19]
1004adc40:	ldp	x29, x30, [sp, #0x30]
1004adc44:	ldp	x20, x19, [sp, #0x20]
1004adc48:	add	sp, sp, #0x40
1004adc4c:	ret
1004adc50:	sub	sp, sp, #0x50
1004adc54:	stp	x22, x21, [sp, #0x20]
1004adc58:	stp	x20, x19, [sp, #0x30]
1004adc5c:	stp	x29, x30, [sp, #0x40]
1004adc60:	add	x29, sp, #0x40
1004adc64:	mov	x19, x0
1004adc68:	adrp	x8, 7847 ; 0x102354000
1004adc6c:	ldr	x21, [x8, #0xfd0]
1004adc70:	add	x0, x20, x21
1004adc74:	add	x1, sp, #0x8
1004adc78:	mov	w2, #0x1
1004adc7c:	mov	x3, #0x0
1004adc80:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004adc84:	strb	w19, [x20, x21]
1004adc88:	ldp	x29, x30, [sp, #0x40]
1004adc8c:	ldp	x20, x19, [sp, #0x30]
1004adc90:	ldp	x22, x21, [sp, #0x20]
1004adc94:	add	sp, sp, #0x50
1004adc98:	ret
1004adc9c:	stp	x20, x19, [sp, #-0x20]!
1004adca0:	stp	x29, x30, [sp, #0x10]
1004adca4:	add	x29, sp, #0x10
1004adca8:	mov	x1, x0
1004adcac:	adrp	x8, 7847 ; 0x102354000
1004adcb0:	ldr	x19, [x8, #0xfd0]
1004adcb4:	add	x0, x20, x19
1004adcb8:	mov	w2, #0x21
1004adcbc:	mov	x3, #0x0
1004adcc0:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004adcc4:	adrp	x0, -1190 ; 0x100007000
1004adcc8:	add	x0, x0, #0x468
1004adccc:	add	x1, x20, x19
1004adcd0:	ldp	x29, x30, [sp, #0x10]
1004adcd4:	ldp	x20, x19, [sp], #0x20
1004adcd8:	ret
1004adcdc:	stp	d13, d12, [sp, #-0x90]!
1004adce0:	stp	d11, d10, [sp, #0x10]
1004adce4:	stp	d9, d8, [sp, #0x20]
1004adce8:	stp	x28, x27, [sp, #0x30]
1004adcec:	stp	x26, x25, [sp, #0x40]
1004adcf0:	stp	x24, x23, [sp, #0x50]
1004adcf4:	stp	x22, x21, [sp, #0x60]
1004adcf8:	stp	x20, x19, [sp, #0x70]
1004adcfc:	stp	x29, x30, [sp, #0x80]
1004add00:	add	x29, sp, #0x80
1004add04:	mov	x19, x5
1004add08:	mov	x24, x4
1004add0c:	mov	x21, x3
1004add10:	mov	x22, x2
1004add14:	mov	x23, x1
1004add18:	mov	x25, x0
1004add1c:	ldr	x0, [x29, #0x10]
1004add20:	adrp	x8, 7847 ; 0x102354000
1004add24:	ldr	x8, [x8, #0xfd8]
1004add28:	add	x8, x20, x8
1004add2c:	ldp	x26, x27, [x8]
1004add30:	and	w28, w6, #0xff
1004add34:	stp	x7, x0, [x8]
1004add38:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004add3c:	mov	x0, x26
1004add40:	mov	x1, x27
1004add44:	bl	0x100003840
1004add48:	fmov	d0, x19
1004add4c:	cmp	w28, #0x1
1004add50:	fmov	d1, #16.00000000
1004add54:	fcsel	d8, d1, d0, eq
1004add58:	mov	x0, x25
1004add5c:	mov	x1, x23
1004add60:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004add64:	mov	x25, x0
1004add68:	adrp	x8, 7801 ; 0x102326000
1004add6c:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004add70:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004add74:	mov	x23, x0
1004add78:	mov	x2, x25
1004add7c:	bl	0x101acf240 ; selector labelWithString:
1004add80:	mov	x29, x29
1004add84:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004add88:	mov	x19, x0
1004add8c:	mov	x0, x25
1004add90:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004add94:	tbz	w24, #0x0, 0x1004addb0
1004add98:	adrp	x8, 7709 ; 0x1022ca000
1004add9c:	ldr	x8, [x8, #0x620] ; literal pool symbol address: _NSFontWeightSemibold
1004adda0:	ldr	d9, [x8]
1004adda4:	mov	x0, x19
1004adda8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004addac:	b	0x1004addc0
1004addb0:	mov	x0, x19
1004addb4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004addb8:	bl	0x10002dd04
1004addbc:	mov.16b	v9, v0
1004addc0:	fmov	d0, #13.00000000
1004addc4:	mov.16b	v1, v9
1004addc8:	bl	0x100004700
1004addcc:	mov	x24, x0
1004addd0:	mov	x0, x19
1004addd4:	mov	x2, x24
1004addd8:	bl	0x101ad2aa0 ; selector setFont:
1004adddc:	mov	x0, x24
1004adde0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004adde4:	adrp	x8, 7801 ; 0x102326000
1004adde8:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004addec:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004addf0:	mov	x24, x0
1004addf4:	bl	0x101acf220 ; selector labelColor
1004addf8:	mov	x29, x29
1004addfc:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ade00:	mov	x25, x0
1004ade04:	mov	x0, x19
1004ade08:	mov	x2, x25
1004ade0c:	bl	0x101ad4660 ; selector setTextColor:
1004ade10:	mov	x0, x25
1004ade14:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ade18:	mov	x0, x19
1004ade1c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ade20:	mov	x19, x0
1004ade24:	mov	x0, x20
1004ade28:	bl	0x101acbde0 ; selector bounds
1004ade2c:	bl	0x101ac8db8 ; symbol stub for: _CGRectGetWidth
1004ade30:	cmp	x21, #0x0
1004ade34:	mov	x8, #0x4049000000000000
1004ade38:	fmov	d1, x8
1004ade3c:	movi.2d	v2, #0000000000000000
1004ade40:	fcsel	d12, d2, d1, eq
1004ade44:	fsub	d0, d0, d8
1004ade48:	fmov	d10, #-16.00000000
1004ade4c:	fadd	d0, d0, d10
1004ade50:	fsub	d9, d0, d12
1004ade54:	mov	x0, x20
1004ade58:	bl	0x101acbde0 ; selector bounds
1004ade5c:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004ade60:	mov.16b	v3, v0
1004ade64:	movi.2d	v1, #0000000000000000
1004ade68:	mov	x0, x19
1004ade6c:	mov.16b	v0, v8
1004ade70:	mov.16b	v2, v9
1004ade74:	bl	0x101ad2b80 ; selector setFrame:
1004ade78:	mov	x0, x19
1004ade7c:	mov	w2, #0x4
1004ade80:	bl	0x101ad3340 ; selector setLineBreakMode:
1004ade84:	mov	x0, x19
1004ade88:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ade8c:	mov	x0, x19
1004ade90:	mov	w2, #0x0
1004ade94:	bl	0x101ad28e0 ; selector setEditable:
1004ade98:	mov	x0, x19
1004ade9c:	mov	w2, #0x0
1004adea0:	bl	0x101ad1fa0 ; selector setBordered:
1004adea4:	mov	x0, x19
1004adea8:	mov	w2, #0x0
1004adeac:	bl	0x101ad2860 ; selector setDrawsBackground:
1004adeb0:	mov	x0, x20
1004adeb4:	mov	x2, x19
1004adeb8:	bl	0x101acb460 ; selector addSubview:
1004adebc:	adrp	x8, 7847 ; 0x102354000
1004adec0:	ldr	x8, [x8, #0xfe0]
1004adec4:	ldr	x25, [x20, x8]
1004adec8:	str	x19, [x20, x8]
1004adecc:	mov	x0, x19
1004aded0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aded4:	mov	x19, x0
1004aded8:	mov	x0, x25
1004adedc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004adee0:	mov	x0, x19
1004adee4:	bl	0x101ad4fe0 ; selector sizeToFit
1004adee8:	mov	x0, x20
1004adeec:	bl	0x101acbde0 ; selector bounds
1004adef0:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004adef4:	mov.16b	v9, v0
1004adef8:	mov	x0, x19
1004adefc:	bl	0x101acdcc0 ; selector frame
1004adf00:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004adf04:	fsub	d0, d9, d0
1004adf08:	fmov	d11, #0.50000000
1004adf0c:	fmul	d9, d0, d11
1004adf10:	mov	x0, x19
1004adf14:	bl	0x101acdcc0 ; selector frame
1004adf18:	mov	x0, x19
1004adf1c:	mov.16b	v1, v9
1004adf20:	bl	0x101ad2b80 ; selector setFrame:
1004adf24:	mov	x0, x20
1004adf28:	bl	0x101acbde0 ; selector bounds
1004adf2c:	bl	0x101ac8db8 ; symbol stub for: _CGRectGetWidth
1004adf30:	fsub	d0, d0, d8
1004adf34:	fadd	d0, d0, d10
1004adf38:	fsub	d8, d0, d12
1004adf3c:	mov	x0, x19
1004adf40:	bl	0x101acdcc0 ; selector frame
1004adf44:	mov	x0, x19
1004adf48:	mov.16b	v2, v8
1004adf4c:	bl	0x101ad2b80 ; selector setFrame:
1004adf50:	mov	x0, x19
1004adf54:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004adf58:	cbz	x21, 0x1004ae130
1004adf5c:	mov	x0, x22
1004adf60:	mov	x1, x21
1004adf64:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004adf68:	mov	x21, x0
1004adf6c:	mov	x0, x23
1004adf70:	mov	x2, x21
1004adf74:	bl	0x101acf240 ; selector labelWithString:
1004adf78:	mov	x29, x29
1004adf7c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004adf80:	mov	x22, x0
1004adf84:	mov	x0, x21
1004adf88:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004adf8c:	mov	x0, x22
1004adf90:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004adf94:	mov	x21, x0
1004adf98:	bl	0x10002dd04
1004adf9c:	mov.16b	v1, v0
1004adfa0:	fmov	d0, #12.00000000
1004adfa4:	bl	0x100004700
1004adfa8:	mov	x22, x0
1004adfac:	mov	x0, x21
1004adfb0:	mov	x2, x22
1004adfb4:	bl	0x101ad2aa0 ; selector setFont:
1004adfb8:	mov	x0, x22
1004adfbc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004adfc0:	mov	x0, x24
1004adfc4:	bl	0x101ad58a0 ; selector tertiaryLabelColor
1004adfc8:	mov	x29, x29
1004adfcc:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004adfd0:	mov	x22, x0
1004adfd4:	mov	x0, x21
1004adfd8:	mov	x2, x22
1004adfdc:	bl	0x101ad4660 ; selector setTextColor:
1004adfe0:	mov	x0, x22
1004adfe4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004adfe8:	mov	x0, x21
1004adfec:	mov	w2, #0x2
1004adff0:	bl	0x101ad1820 ; selector setAlignment:
1004adff4:	mov	x0, x21
1004adff8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004adffc:	mov	x0, x21
1004ae000:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ae004:	mov	x21, x0
1004ae008:	mov	x0, x20
1004ae00c:	bl	0x101acbde0 ; selector bounds
1004ae010:	bl	0x101ac8db8 ; symbol stub for: _CGRectGetWidth
1004ae014:	fadd	d0, d0, d10
1004ae018:	mov	x8, #-0x3fb7000000000000
1004ae01c:	fmov	d12, x8
1004ae020:	fadd	d9, d0, d12
1004ae024:	mov	x0, x20
1004ae028:	bl	0x101acbde0 ; selector bounds
1004ae02c:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004ae030:	mov.16b	v3, v0
1004ae034:	mov	x8, #0x4049000000000000
1004ae038:	fmov	d8, x8
1004ae03c:	movi.2d	v1, #0000000000000000
1004ae040:	mov	x0, x21
1004ae044:	mov.16b	v0, v9
1004ae048:	mov.16b	v2, v8
1004ae04c:	bl	0x101ad2b80 ; selector setFrame:
1004ae050:	mov	x0, x21
1004ae054:	mov	w2, #0x0
1004ae058:	bl	0x101ad28e0 ; selector setEditable:
1004ae05c:	mov	x0, x21
1004ae060:	mov	w2, #0x0
1004ae064:	bl	0x101ad1fa0 ; selector setBordered:
1004ae068:	mov	x0, x21
1004ae06c:	mov	w2, #0x0
1004ae070:	bl	0x101ad2860 ; selector setDrawsBackground:
1004ae074:	mov	x0, x20
1004ae078:	mov	x2, x21
1004ae07c:	bl	0x101acb460 ; selector addSubview:
1004ae080:	adrp	x8, 7846 ; 0x102354000
1004ae084:	ldr	x8, [x8, #0xfe8]
1004ae088:	ldr	x22, [x20, x8]
1004ae08c:	str	x21, [x20, x8]
1004ae090:	mov	x0, x21
1004ae094:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ae098:	mov	x21, x0
1004ae09c:	mov	x0, x22
1004ae0a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae0a4:	mov	x0, x21
1004ae0a8:	bl	0x101ad4fe0 ; selector sizeToFit
1004ae0ac:	mov	x0, x20
1004ae0b0:	bl	0x101acbde0 ; selector bounds
1004ae0b4:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004ae0b8:	mov.16b	v9, v0
1004ae0bc:	mov	x0, x21
1004ae0c0:	bl	0x101acdcc0 ; selector frame
1004ae0c4:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004ae0c8:	fsub	d0, d9, d0
1004ae0cc:	fmul	d9, d0, d11
1004ae0d0:	mov	x0, x21
1004ae0d4:	bl	0x101acdcc0 ; selector frame
1004ae0d8:	mov	x0, x21
1004ae0dc:	mov.16b	v1, v9
1004ae0e0:	bl	0x101ad2b80 ; selector setFrame:
1004ae0e4:	mov	x0, x21
1004ae0e8:	bl	0x101acdcc0 ; selector frame
1004ae0ec:	mov	x0, x21
1004ae0f0:	mov.16b	v2, v8
1004ae0f4:	bl	0x101ad2b80 ; selector setFrame:
1004ae0f8:	mov	x0, x20
1004ae0fc:	bl	0x101acbde0 ; selector bounds
1004ae100:	bl	0x101ac8db8 ; symbol stub for: _CGRectGetWidth
1004ae104:	fadd	d0, d0, d10
1004ae108:	fadd	d8, d0, d12
1004ae10c:	mov	x0, x21
1004ae110:	bl	0x101acdcc0 ; selector frame
1004ae114:	mov	x0, x21
1004ae118:	mov.16b	v0, v8
1004ae11c:	bl	0x101ad2b80 ; selector setFrame:
1004ae120:	mov	x0, x21
1004ae124:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae128:	mov	x0, x21
1004ae12c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae130:	mov	x0, x19
1004ae134:	ldp	x29, x30, [sp, #0x80]
1004ae138:	ldp	x20, x19, [sp, #0x70]
1004ae13c:	ldp	x22, x21, [sp, #0x60]
1004ae140:	ldp	x24, x23, [sp, #0x50]
1004ae144:	ldp	x26, x25, [sp, #0x40]
1004ae148:	ldp	x28, x27, [sp, #0x30]
1004ae14c:	ldp	d9, d8, [sp, #0x20]
1004ae150:	ldp	d11, d10, [sp, #0x10]
1004ae154:	ldp	d13, d12, [sp], #0x90
1004ae158:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004ae15c:	sub	sp, sp, #0x70
1004ae160:	stp	d11, d10, [sp, #0x10]
1004ae164:	stp	d9, d8, [sp, #0x20]
1004ae168:	stp	x24, x23, [sp, #0x30]
1004ae16c:	stp	x22, x21, [sp, #0x40]
1004ae170:	stp	x20, x19, [sp, #0x50]
1004ae174:	stp	x29, x30, [sp, #0x60]
1004ae178:	add	x29, sp, #0x60
1004ae17c:	bl	0x1004aede4
1004ae180:	stp	x20, x0, [sp]
1004ae184:	adrp	x8, 7798 ; 0x102324000
1004ae188:	ldr	x1, [x8, #0xea8] ; Objc selector ref: updateTrackingAreas
1004ae18c:	mov	x0, sp
1004ae190:	bl	0x101ac9d0c ; Objc message: -[[x0 super] updateTrackingAreas]
1004ae194:	adrp	x8, 7846 ; 0x102354000
1004ae198:	ldr	x22, [x8, #0xff0]
1004ae19c:	ldr	x2, [x20, x22]
1004ae1a0:	cbz	x2, 0x1004ae1ac
1004ae1a4:	mov	x0, x20
1004ae1a8:	bl	0x101ad0c40 ; selector removeTrackingArea:
1004ae1ac:	mov	x0, x20
1004ae1b0:	bl	0x101acbde0 ; selector bounds
1004ae1b4:	mov.16b	v8, v0
1004ae1b8:	mov.16b	v9, v1
1004ae1bc:	mov.16b	v10, v2
1004ae1c0:	mov.16b	v11, v3
1004ae1c4:	adrp	x8, 7800 ; 0x102326000
1004ae1c8:	ldr	x0, [x8, #0xa48] ; Objc class ref: _OBJC_CLASS_$_NSTrackingArea
1004ae1cc:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004ae1d0:	mov.16b	v0, v8
1004ae1d4:	mov.16b	v1, v9
1004ae1d8:	mov.16b	v2, v10
1004ae1dc:	mov.16b	v3, v11
1004ae1e0:	mov	x3, x20
1004ae1e4:	mov	w2, #0x81
1004ae1e8:	mov	x4, #0x0
1004ae1ec:	bl	0x101ace7c0 ; selector initWithRect:options:owner:userInfo:
1004ae1f0:	mov	x19, x0
1004ae1f4:	mov	x0, x20
1004ae1f8:	mov	x2, x19
1004ae1fc:	bl	0x101acb540 ; selector addTrackingArea:
1004ae200:	ldr	x21, [x20, x22]
1004ae204:	str	x19, [x20, x22]
1004ae208:	mov	x0, x19
1004ae20c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ae210:	mov	x19, x0
1004ae214:	mov	x0, x21
1004ae218:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae21c:	mov	x0, x20
1004ae220:	bl	0x101ad6200 ; selector window
1004ae224:	mov	x29, x29
1004ae228:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ae22c:	cbz	x0, 0x1004ae2c8
1004ae230:	mov	x21, x0
1004ae234:	bl	0x101acf940 ; selector mouseLocationOutsideOfEventStream
1004ae238:	mov	x0, x20
1004ae23c:	mov	x2, #0x0
1004ae240:	bl	0x101acc920 ; selector convertPoint:fromView:
1004ae244:	mov.16b	v8, v0
1004ae248:	mov.16b	v9, v1
1004ae24c:	mov	x0, x20
1004ae250:	bl	0x101acbde0 ; selector bounds
1004ae254:	mov.16b	v4, v8
1004ae258:	mov.16b	v5, v9
1004ae25c:	bl	0x101ac8d40 ; symbol stub for: _CGRectContainsPoint
1004ae260:	tbnz	w0, #0x0, 0x1004ae2c0
1004ae264:	adrp	x8, 7846 ; 0x102354000
1004ae268:	ldr	x8, [x8, #0xff8]
1004ae26c:	ldrb	w9, [x20, x8]
1004ae270:	cmp	w9, #0x1
1004ae274:	b.ne	0x1004ae2c0
1004ae278:	strb	wzr, [x20, x8]
1004ae27c:	adrp	x8, 7847 ; 0x102355000
1004ae280:	ldr	x23, [x8]
1004ae284:	ldr	x22, [x20, x23]
1004ae288:	mov	x0, x22
1004ae28c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004ae290:	bl	0x1004aed30
1004ae294:	mov	x0, x22
1004ae298:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ae29c:	ldr	x0, [x20, x23]
1004ae2a0:	adrp	x8, 7713 ; 0x1022cf000
1004ae2a4:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004ae2a8:	str	x8, [x20, x23]
1004ae2ac:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ae2b0:	mov	x0, x20
1004ae2b4:	bl	0x101acbde0 ; selector bounds
1004ae2b8:	mov	x0, x20
1004ae2bc:	bl	0x101ad3820 ; selector setNeedsDisplayInRect:
1004ae2c0:	mov	x0, x21
1004ae2c4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae2c8:	mov	x0, x19
1004ae2cc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae2d0:	ldp	x29, x30, [sp, #0x60]
1004ae2d4:	ldp	x20, x19, [sp, #0x50]
1004ae2d8:	ldp	x22, x21, [sp, #0x40]
1004ae2dc:	ldp	x24, x23, [sp, #0x30]
1004ae2e0:	ldp	d9, d8, [sp, #0x20]
1004ae2e4:	ldp	d11, d10, [sp, #0x10]
1004ae2e8:	add	sp, sp, #0x70
1004ae2ec:	ret
1004ae2f0:	stp	x20, x19, [sp, #-0x20]!
1004ae2f4:	stp	x29, x30, [sp, #0x10]
1004ae2f8:	add	x29, sp, #0x10
1004ae2fc:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ae300:	mov	x20, x0
1004ae304:	bl	0x1004ae15c
1004ae308:	mov	x0, x20
1004ae30c:	ldp	x29, x30, [sp, #0x10]
1004ae310:	ldp	x20, x19, [sp], #0x20
1004ae314:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004ae318:	b	0x1004aee04
1004ae31c:	stp	x22, x21, [sp, #-0x30]!
1004ae320:	stp	x20, x19, [sp, #0x10]
1004ae324:	stp	x29, x30, [sp, #0x20]
1004ae328:	add	x29, sp, #0x20
1004ae32c:	mov	x19, x0
1004ae330:	mov	x0, x2
1004ae334:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ae338:	mov	x21, x0
1004ae33c:	mov	x0, x19
1004ae340:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ae344:	mov	x20, x0
1004ae348:	bl	0x1004aee04
1004ae34c:	mov	x0, x21
1004ae350:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae354:	mov	x0, x20
1004ae358:	ldp	x29, x30, [sp, #0x20]
1004ae35c:	ldp	x20, x19, [sp, #0x10]
1004ae360:	ldp	x22, x21, [sp], #0x30
1004ae364:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004ae368:	b	0x1004aef18
1004ae36c:	stp	x22, x21, [sp, #-0x30]!
1004ae370:	stp	x20, x19, [sp, #0x10]
1004ae374:	stp	x29, x30, [sp, #0x20]
1004ae378:	add	x29, sp, #0x20
1004ae37c:	mov	x19, x0
1004ae380:	mov	x0, x2
1004ae384:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ae388:	mov	x21, x0
1004ae38c:	mov	x0, x19
1004ae390:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ae394:	mov	x20, x0
1004ae398:	bl	0x1004aef18
1004ae39c:	mov	x0, x21
1004ae3a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae3a4:	mov	x0, x20
1004ae3a8:	ldp	x29, x30, [sp, #0x20]
1004ae3ac:	ldp	x20, x19, [sp, #0x10]
1004ae3b0:	ldp	x22, x21, [sp], #0x30
1004ae3b4:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004ae3b8:	stp	d11, d10, [sp, #-0x40]!
1004ae3bc:	stp	d9, d8, [sp, #0x10]
1004ae3c0:	stp	x20, x19, [sp, #0x20]
1004ae3c4:	stp	x29, x30, [sp, #0x30]
1004ae3c8:	add	x29, sp, #0x30
1004ae3cc:	mov	x19, x0
1004ae3d0:	mov	x0, x20
1004ae3d4:	bl	0x101acbde0 ; selector bounds
1004ae3d8:	mov.16b	v8, v0
1004ae3dc:	mov.16b	v9, v1
1004ae3e0:	mov.16b	v10, v2
1004ae3e4:	mov.16b	v11, v3
1004ae3e8:	mov	x0, x19
1004ae3ec:	bl	0x101acf5a0 ; selector locationInWindow
1004ae3f0:	mov	x0, x20
1004ae3f4:	mov	x2, #0x0
1004ae3f8:	bl	0x101acc920 ; selector convertPoint:fromView:
1004ae3fc:	mov.16b	v4, v0
1004ae400:	mov.16b	v5, v1
1004ae404:	mov.16b	v0, v8
1004ae408:	mov.16b	v1, v9
1004ae40c:	mov.16b	v2, v10
1004ae410:	mov.16b	v3, v11
1004ae414:	bl	0x101ac8d40 ; symbol stub for: _CGRectContainsPoint
1004ae418:	cbz	w0, 0x1004ae460
1004ae41c:	adrp	x8, 7846 ; 0x102354000
1004ae420:	ldr	x8, [x8, #0xfd8]
1004ae424:	add	x8, x20, x8
1004ae428:	ldr	x19, [x8]
1004ae42c:	cbz	x19, 0x1004ae460
1004ae430:	ldr	x20, [x8, #0x8]
1004ae434:	mov	x0, x19
1004ae438:	mov	x1, x20
1004ae43c:	bl	0x100003f5c
1004ae440:	blr	x19
1004ae444:	mov	x0, x19
1004ae448:	mov	x1, x20
1004ae44c:	ldp	x29, x30, [sp, #0x30]
1004ae450:	ldp	x20, x19, [sp, #0x20]
1004ae454:	ldp	d9, d8, [sp, #0x10]
1004ae458:	ldp	d11, d10, [sp], #0x40
1004ae45c:	b	0x100003840
1004ae460:	ldp	x29, x30, [sp, #0x30]
1004ae464:	ldp	x20, x19, [sp, #0x20]
1004ae468:	ldp	d9, d8, [sp, #0x10]
1004ae46c:	ldp	d11, d10, [sp], #0x40
1004ae470:	ret
1004ae474:	stp	x22, x21, [sp, #-0x30]!
1004ae478:	stp	x20, x19, [sp, #0x10]
1004ae47c:	stp	x29, x30, [sp, #0x20]
1004ae480:	add	x29, sp, #0x20
1004ae484:	mov	x19, x0
1004ae488:	mov	x0, x2
1004ae48c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ae490:	mov	x21, x0
1004ae494:	mov	x0, x19
1004ae498:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ae49c:	mov	x20, x0
1004ae4a0:	mov	x0, x21
1004ae4a4:	bl	0x1004ae3b8
1004ae4a8:	mov	x0, x21
1004ae4ac:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae4b0:	mov	x0, x20
1004ae4b4:	ldp	x29, x30, [sp, #0x20]
1004ae4b8:	ldp	x20, x19, [sp, #0x10]
1004ae4bc:	ldp	x22, x21, [sp], #0x30
1004ae4c0:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004ae4c4:	sub	sp, sp, #0x70
1004ae4c8:	stp	d15, d14, [sp, #0x10]
1004ae4cc:	stp	d13, d12, [sp, #0x20]
1004ae4d0:	stp	d11, d10, [sp, #0x30]
1004ae4d4:	stp	d9, d8, [sp, #0x40]
1004ae4d8:	stp	x20, x19, [sp, #0x50]
1004ae4dc:	stp	x29, x30, [sp, #0x60]
1004ae4e0:	add	x29, sp, #0x60
1004ae4e4:	mov.16b	v8, v3
1004ae4e8:	mov.16b	v9, v2
1004ae4ec:	mov.16b	v10, v1
1004ae4f0:	mov.16b	v11, v0
1004ae4f4:	adrp	x8, 7846 ; 0x102354000
1004ae4f8:	ldr	x8, [x8, #0xff8]
1004ae4fc:	ldrb	w8, [x20, x8]
1004ae500:	cmp	w8, #0x1
1004ae504:	b.ne	0x1004ae594
1004ae508:	adrp	x8, 7800 ; 0x102326000
1004ae50c:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004ae510:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004ae514:	bl	0x101ad1460 ; selector selectedContentBackgroundColor
1004ae518:	mov	x29, x29
1004ae51c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ae520:	mov	x19, x0
1004ae524:	bl	0x101ad29c0 ; selector setFill
1004ae528:	mov	x0, x19
1004ae52c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae530:	mov	x0, x20
1004ae534:	bl	0x101acbde0 ; selector bounds
1004ae538:	fmov	d4, #4.00000000
1004ae53c:	fmov	d5, #1.00000000
1004ae540:	bl	0x101ac8dc4 ; symbol stub for: _CGRectInset
1004ae544:	mov.16b	v12, v0
1004ae548:	mov.16b	v13, v1
1004ae54c:	mov.16b	v14, v2
1004ae550:	mov.16b	v15, v3
1004ae554:	adrp	x8, 7800 ; 0x102326000
1004ae558:	ldr	x0, [x8, #0xb38] ; Objc class ref: _OBJC_CLASS_$_NSBezierPath
1004ae55c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004ae560:	fmov	d4, #6.00000000
1004ae564:	fmov	d5, #6.00000000
1004ae568:	mov.16b	v0, v12
1004ae56c:	mov.16b	v1, v13
1004ae570:	mov.16b	v2, v14
1004ae574:	mov.16b	v3, v15
1004ae578:	bl	0x101acbc40 ; selector bezierPathWithRoundedRect:xRadius:yRadius:
1004ae57c:	mov	x29, x29
1004ae580:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ae584:	mov	x19, x0
1004ae588:	bl	0x101acda20 ; selector fill
1004ae58c:	mov	x0, x19
1004ae590:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae594:	bl	0x1004aede4
1004ae598:	stp	x20, x0, [sp]
1004ae59c:	adrp	x8, 7795 ; 0x102321000
1004ae5a0:	ldr	x1, [x8, #0x3b8] ; Objc selector ref: drawRect:
1004ae5a4:	mov	x0, sp
1004ae5a8:	mov.16b	v0, v11
1004ae5ac:	mov.16b	v1, v10
1004ae5b0:	mov.16b	v2, v9
1004ae5b4:	mov.16b	v3, v8
1004ae5b8:	bl	0x101ac9d0c ; Objc message: -[[x0 super] drawRect:]
1004ae5bc:	ldp	x29, x30, [sp, #0x60]
1004ae5c0:	ldp	x20, x19, [sp, #0x50]
1004ae5c4:	ldp	d9, d8, [sp, #0x40]
1004ae5c8:	ldp	d11, d10, [sp, #0x30]
1004ae5cc:	ldp	d13, d12, [sp, #0x20]
1004ae5d0:	ldp	d15, d14, [sp, #0x10]
1004ae5d4:	add	sp, sp, #0x70
1004ae5d8:	ret
1004ae5dc:	stp	d11, d10, [sp, #-0x40]!
1004ae5e0:	stp	d9, d8, [sp, #0x10]
1004ae5e4:	stp	x20, x19, [sp, #0x20]
1004ae5e8:	stp	x29, x30, [sp, #0x30]
1004ae5ec:	add	x29, sp, #0x30
1004ae5f0:	mov.16b	v8, v3
1004ae5f4:	mov.16b	v9, v2
1004ae5f8:	mov.16b	v10, v1
1004ae5fc:	mov.16b	v11, v0
1004ae600:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ae604:	mov	x20, x0
1004ae608:	mov.16b	v0, v11
1004ae60c:	mov.16b	v1, v10
1004ae610:	mov.16b	v2, v9
1004ae614:	mov.16b	v3, v8
1004ae618:	bl	0x1004ae4c4
1004ae61c:	mov	x0, x20
1004ae620:	ldp	x29, x30, [sp, #0x30]
1004ae624:	ldp	x20, x19, [sp, #0x20]
1004ae628:	ldp	d9, d8, [sp, #0x10]
1004ae62c:	ldp	d11, d10, [sp], #0x40
1004ae630:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004ae634:	stp	x29, x30, [sp, #-0x10]!
1004ae638:	mov	x29, sp
1004ae63c:	bl	0x1004adb70
1004ae640:	mov	x0, x20
1004ae644:	bl	0x101acbde0 ; selector bounds
1004ae648:	mov	x0, x20
1004ae64c:	ldp	x29, x30, [sp], #0x10
1004ae650:	b	0x101ad3820 ; selector setNeedsDisplayInRect:
1004ae654:	stp	x20, x19, [sp, #-0x20]!
1004ae658:	stp	x29, x30, [sp, #0x10]
1004ae65c:	add	x29, sp, #0x10
1004ae660:	adrp	x8, 7846 ; 0x102354000
1004ae664:	ldr	x8, [x8, #0xfd8]
1004ae668:	add	x8, x20, x8
1004ae66c:	ldr	x19, [x8]
1004ae670:	cbz	x19, 0x1004ae69c
1004ae674:	ldr	x20, [x8, #0x8]
1004ae678:	mov	x0, x19
1004ae67c:	mov	x1, x20
1004ae680:	bl	0x100003f5c
1004ae684:	blr	x19
1004ae688:	mov	x0, x19
1004ae68c:	mov	x1, x20
1004ae690:	ldp	x29, x30, [sp, #0x10]
1004ae694:	ldp	x20, x19, [sp], #0x20
1004ae698:	b	0x100003840
1004ae69c:	ldp	x29, x30, [sp, #0x10]
1004ae6a0:	ldp	x20, x19, [sp], #0x20
1004ae6a4:	ret
1004ae6a8:	sub	sp, sp, #0x40
1004ae6ac:	stp	d11, d10, [sp, #0x10]
1004ae6b0:	stp	d9, d8, [sp, #0x20]
1004ae6b4:	stp	x29, x30, [sp, #0x30]
1004ae6b8:	add	x29, sp, #0x30
1004ae6bc:	mov.16b	v8, v3
1004ae6c0:	mov.16b	v9, v2
1004ae6c4:	mov.16b	v10, v1
1004ae6c8:	mov.16b	v11, v0
1004ae6cc:	adrp	x8, 7846 ; 0x102354000
1004ae6d0:	ldr	x8, [x8, #0xfe0]
1004ae6d4:	str	xzr, [x20, x8]
1004ae6d8:	adrp	x8, 7846 ; 0x102354000
1004ae6dc:	ldr	x8, [x8, #0xfe8]
1004ae6e0:	str	xzr, [x20, x8]
1004ae6e4:	adrp	x8, 7846 ; 0x102354000
1004ae6e8:	ldr	x8, [x8, #0xfd8]
1004ae6ec:	add	x8, x20, x8
1004ae6f0:	stp	xzr, xzr, [x8]
1004ae6f4:	adrp	x8, 7846 ; 0x102354000
1004ae6f8:	ldr	x8, [x8, #0xff0]
1004ae6fc:	str	xzr, [x20, x8]
1004ae700:	adrp	x8, 7847 ; 0x102355000
1004ae704:	ldr	x8, [x8]
1004ae708:	adrp	x9, 7713 ; 0x1022cf000
1004ae70c:	ldr	x9, [x9, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004ae710:	str	x9, [x20, x8]
1004ae714:	adrp	x8, 7846 ; 0x102354000
1004ae718:	ldr	x8, [x8, #0xff8]
1004ae71c:	strb	wzr, [x20, x8]
1004ae720:	adrp	x8, 7846 ; 0x102354000
1004ae724:	ldr	x8, [x8, #0xfd0]
1004ae728:	strb	wzr, [x20, x8]
1004ae72c:	adrp	x8, 7847 ; 0x102355000
1004ae730:	ldr	x8, [x8, #0x8]
1004ae734:	mov	x9, #0x4030000000000000
1004ae738:	str	x9, [x20, x8]
1004ae73c:	adrp	x8, 7847 ; 0x102355000
1004ae740:	ldr	x8, [x8, #0x10]
1004ae744:	mov	x9, #0x4010000000000000
1004ae748:	str	x9, [x20, x8]
1004ae74c:	bl	0x1004aede4
1004ae750:	stp	x20, x0, [sp]
1004ae754:	adrp	x8, 7797 ; 0x102323000
1004ae758:	ldr	x1, [x8, #0x50] ; Objc selector ref: initWithFrame:
1004ae75c:	mov	x0, sp
1004ae760:	mov.16b	v0, v11
1004ae764:	mov.16b	v1, v10
1004ae768:	mov.16b	v2, v9
1004ae76c:	mov.16b	v3, v8
1004ae770:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithFrame:]
1004ae774:	ldp	x29, x30, [sp, #0x30]
1004ae778:	ldp	d9, d8, [sp, #0x20]
1004ae77c:	ldp	d11, d10, [sp, #0x10]
1004ae780:	add	sp, sp, #0x40
1004ae784:	ret
1004ae788:	stp	x20, x19, [sp, #-0x20]!
1004ae78c:	stp	x29, x30, [sp, #0x10]
1004ae790:	add	x29, sp, #0x10
1004ae794:	mov	x20, x0
1004ae798:	bl	0x1004ae6a8
1004ae79c:	ldp	x29, x30, [sp, #0x10]
1004ae7a0:	ldp	x20, x19, [sp], #0x20
1004ae7a4:	ret
1004ae7a8:	sub	sp, sp, #0x40
1004ae7ac:	stp	x22, x21, [sp, #0x10]
1004ae7b0:	stp	x20, x19, [sp, #0x20]
1004ae7b4:	stp	x29, x30, [sp, #0x30]
1004ae7b8:	add	x29, sp, #0x30
1004ae7bc:	mov	x21, x0
1004ae7c0:	adrp	x8, 7846 ; 0x102354000
1004ae7c4:	ldr	x8, [x8, #0xfe0]
1004ae7c8:	str	xzr, [x20, x8]
1004ae7cc:	adrp	x8, 7846 ; 0x102354000
1004ae7d0:	ldr	x8, [x8, #0xfe8]
1004ae7d4:	str	xzr, [x20, x8]
1004ae7d8:	adrp	x8, 7846 ; 0x102354000
1004ae7dc:	ldr	x8, [x8, #0xfd8]
1004ae7e0:	add	x8, x20, x8
1004ae7e4:	stp	xzr, xzr, [x8]
1004ae7e8:	adrp	x8, 7846 ; 0x102354000
1004ae7ec:	ldr	x8, [x8, #0xff0]
1004ae7f0:	str	xzr, [x20, x8]
1004ae7f4:	adrp	x8, 7847 ; 0x102355000
1004ae7f8:	ldr	x8, [x8]
1004ae7fc:	adrp	x9, 7713 ; 0x1022cf000
1004ae800:	ldr	x9, [x9, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004ae804:	str	x9, [x20, x8]
1004ae808:	adrp	x8, 7846 ; 0x102354000
1004ae80c:	ldr	x8, [x8, #0xff8]
1004ae810:	strb	wzr, [x20, x8]
1004ae814:	adrp	x8, 7846 ; 0x102354000
1004ae818:	ldr	x8, [x8, #0xfd0]
1004ae81c:	strb	wzr, [x20, x8]
1004ae820:	adrp	x8, 7847 ; 0x102355000
1004ae824:	ldr	x8, [x8, #0x8]
1004ae828:	mov	x9, #0x4030000000000000
1004ae82c:	str	x9, [x20, x8]
1004ae830:	adrp	x8, 7847 ; 0x102355000
1004ae834:	ldr	x8, [x8, #0x10]
1004ae838:	mov	x9, #0x4010000000000000
1004ae83c:	str	x9, [x20, x8]
1004ae840:	bl	0x1004aede4
1004ae844:	stp	x20, x0, [sp]
1004ae848:	adrp	x8, 7796 ; 0x102322000
1004ae84c:	ldr	x1, [x8, #0xfd8] ; Objc selector ref: initWithCoder:
1004ae850:	mov	x0, sp
1004ae854:	mov	x2, x21
1004ae858:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithCoder:]
1004ae85c:	mov	x29, x29
1004ae860:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004ae864:	mov	x19, x0
1004ae868:	mov	x0, x21
1004ae86c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae870:	cbz	x19, 0x1004ae87c
1004ae874:	mov	x0, x19
1004ae878:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae87c:	mov	x0, x19
1004ae880:	ldp	x29, x30, [sp, #0x30]
1004ae884:	ldp	x20, x19, [sp, #0x20]
1004ae888:	ldp	x22, x21, [sp, #0x10]
1004ae88c:	add	sp, sp, #0x40
1004ae890:	ret
1004ae894:	stp	x20, x19, [sp, #-0x20]!
1004ae898:	stp	x29, x30, [sp, #0x10]
1004ae89c:	add	x29, sp, #0x10
1004ae8a0:	mov	x20, x0
1004ae8a4:	mov	x0, x2
1004ae8a8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004ae8ac:	bl	0x1004ae7a8
1004ae8b0:	ldp	x29, x30, [sp, #0x10]
1004ae8b4:	ldp	x20, x19, [sp], #0x20
1004ae8b8:	ret
1004ae8bc:	sub	sp, sp, #0x20
1004ae8c0:	stp	x29, x30, [sp, #0x10]
1004ae8c4:	add	x29, sp, #0x10
1004ae8c8:	bl	0x1004aede4
1004ae8cc:	stp	x20, x0, [sp]
1004ae8d0:	adrp	x8, 7795 ; 0x102321000
1004ae8d4:	ldr	x1, [x8, #0x2d8] ; Objc selector ref: dealloc
1004ae8d8:	mov	x0, sp
1004ae8dc:	bl	0x101ac9d0c ; Objc message: -[[x0 super] dealloc]
1004ae8e0:	ldp	x29, x30, [sp, #0x10]
1004ae8e4:	add	sp, sp, #0x20
1004ae8e8:	ret
1004ae8ec:	stp	x20, x19, [sp, #-0x20]!
1004ae8f0:	stp	x29, x30, [sp, #0x10]
1004ae8f4:	add	x29, sp, #0x10
1004ae8f8:	mov	x19, x0
1004ae8fc:	adrp	x8, 7846 ; 0x102354000
1004ae900:	ldr	x8, [x8, #0xfe0]
1004ae904:	ldr	x0, [x0, x8]
1004ae908:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae90c:	adrp	x8, 7846 ; 0x102354000
1004ae910:	ldr	x8, [x8, #0xfe8]
1004ae914:	ldr	x0, [x19, x8]
1004ae918:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae91c:	adrp	x8, 7846 ; 0x102354000
1004ae920:	ldr	x8, [x8, #0xfd8]
1004ae924:	add	x8, x19, x8
1004ae928:	ldp	x0, x1, [x8]
1004ae92c:	bl	0x100003840
1004ae930:	adrp	x8, 7846 ; 0x102354000
1004ae934:	ldr	x8, [x8, #0xff0]
1004ae938:	ldr	x0, [x19, x8]
1004ae93c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004ae940:	adrp	x8, 7847 ; 0x102355000
1004ae944:	ldr	x8, [x8]
1004ae948:	ldr	x0, [x19, x8]
1004ae94c:	ldp	x29, x30, [sp, #0x10]
1004ae950:	ldp	x20, x19, [sp], #0x20
1004ae954:	b	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004ae958:	stp	x24, x23, [sp, #-0x40]!
1004ae95c:	stp	x22, x21, [sp, #0x10]
1004ae960:	stp	x20, x19, [sp, #0x20]
1004ae964:	stp	x29, x30, [sp, #0x30]
1004ae968:	add	x29, sp, #0x30
1004ae96c:	mov	x19, x3
1004ae970:	mov	x20, x0
1004ae974:	tbz	w2, #0x0, 0x1004ae9a4
1004ae978:	ldr	x9, [x19, #0x18]
1004ae97c:	lsr	x8, x9, #1
1004ae980:	cmp	x8, x1
1004ae984:	b.ge	0x1004ae9a8
1004ae988:	mov	x10, #0x4000000000000000
1004ae98c:	cmn	x8, x10
1004ae990:	b.mi	0x1004aea84
1004ae994:	and	x8, x9, #0xfffffffffffffffe
1004ae998:	cmp	x8, x1
1004ae99c:	csel	x8, x8, x1, gt
1004ae9a0:	b	0x1004ae9a8
1004ae9a4:	mov	x8, x1
1004ae9a8:	ldr	x21, [x19, #0x10]
1004ae9ac:	cmp	x8, x21
1004ae9b0:	csel	x22, x8, x21, gt
1004ae9b4:	cbz	x22, 0x1004aea00
1004ae9b8:	adrp	x0, 7847 ; 0x102355000
1004ae9bc:	add	x0, x0, #0x40
1004ae9c0:	adrp	x1, 5703 ; 0x101af5000
1004ae9c4:	add	x1, x1, #0xd58
1004ae9c8:	bl	0x100003c4c
1004ae9cc:	lsl	x8, x22, #4
1004ae9d0:	add	x1, x8, #0x20
1004ae9d4:	mov	w2, #0x7
1004ae9d8:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1004ae9dc:	mov	x22, x0
1004ae9e0:	bl	0x101ac9c04 ; symbol stub for: _malloc_size
1004ae9e4:	subs	x8, x0, #0x20
1004ae9e8:	sub	x9, x0, #0x11
1004ae9ec:	csel	x8, x9, x8, lt
1004ae9f0:	asr	x8, x8, #4
1004ae9f4:	lsl	x8, x8, #1
1004ae9f8:	stp	x21, x8, [x22, #0x10]
1004ae9fc:	b	0x1004aea08
1004aea00:	adrp	x22, 7713 ; 0x1022cf000
1004aea04:	ldr	x22, [x22, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004aea08:	add	x23, x22, #0x20
1004aea0c:	add	x24, x19, #0x20
1004aea10:	tbz	w20, #0x0, 0x1004aea3c
1004aea14:	add	x8, x24, x21, lsl #4
1004aea18:	cmp	x22, x19
1004aea1c:	ccmp	x23, x8, #0x2, eq
1004aea20:	b.lo	0x1004aea34
1004aea24:	lsl	x2, x21, #4
1004aea28:	mov	x0, x23
1004aea2c:	mov	x1, x24
1004aea30:	bl	0x101ac9c40 ; symbol stub for: _memmove
1004aea34:	str	xzr, [x19, #0x10]
1004aea38:	b	0x1004aea64
1004aea3c:	adrp	x0, 7847 ; 0x102355000
1004aea40:	add	x0, x0, #0x48
1004aea44:	adrp	x1, 5703 ; 0x101af5000
1004aea48:	add	x1, x1, #0xd60
1004aea4c:	bl	0x100003c4c
1004aea50:	mov	x3, x0
1004aea54:	mov	x0, x23
1004aea58:	mov	x1, x24
1004aea5c:	mov	x2, x21
1004aea60:	bl	0x101aca5b8 ; symbol stub for: _swift_arrayInitWithCopy
1004aea64:	mov	x0, x19
1004aea68:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aea6c:	mov	x0, x22
1004aea70:	ldp	x29, x30, [sp, #0x30]
1004aea74:	ldp	x20, x19, [sp, #0x20]
1004aea78:	ldp	x22, x21, [sp, #0x10]
1004aea7c:	ldp	x24, x23, [sp], #0x40
1004aea80:	ret
1004aea84:	brk	#0x1
1004aea88:	stp	x28, x27, [sp, #-0x60]!
1004aea8c:	stp	x26, x25, [sp, #0x10]
1004aea90:	stp	x24, x23, [sp, #0x20]
1004aea94:	stp	x22, x21, [sp, #0x30]
1004aea98:	stp	x20, x19, [sp, #0x40]
1004aea9c:	stp	x29, x30, [sp, #0x50]
1004aeaa0:	add	x29, sp, #0x50
1004aeaa4:	bl	0x101ad5540 ; selector subviews
1004aeaa8:	mov	x29, x29
1004aeaac:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aeab0:	mov	x20, x0
1004aeab4:	mov	x0, #0x0
1004aeab8:	bl	0x10026e478
1004aeabc:	mov	x1, x0
1004aeac0:	mov	x0, x20
1004aeac4:	bl	0x101ac676c ; symbol stub for: _$sSa10FoundationE36_unconditionallyBridgeFromObjectiveCySayxGSo7NSArrayCSgFZ
1004aeac8:	mov	x19, x0
1004aeacc:	mov	x0, x20
1004aead0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aead4:	lsr	x8, x19, #62
1004aead8:	cbnz	x8, 0x1004aece4
1004aeadc:	and	x8, x19, #0xffffffffffffff8
1004aeae0:	ldr	x20, [x8, #0x10]
1004aeae4:	cbz	x20, 0x1004aecfc
1004aeae8:	cmp	x20, #0x1
1004aeaec:	b.lt	0x1004aed2c
1004aeaf0:	mov	x21, #0x0
1004aeaf4:	and	x27, x19, #0xc000000000000001
1004aeaf8:	adrp	x22, 7713 ; 0x1022cf000
1004aeafc:	ldr	x22, [x22, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004aeb00:	b	0x1004aeb58
1004aeb04:	str	x26, [x22, #0x10]
1004aeb08:	add	x8, x22, x28, lsl #4
1004aeb0c:	stp	x24, x25, [x8, #0x20]
1004aeb10:	adrp	x8, 7800 ; 0x102326000
1004aeb14:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004aeb18:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004aeb1c:	bl	0x101ad14a0 ; selector selectedMenuItemTextColor
1004aeb20:	mov	x29, x29
1004aeb24:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aeb28:	mov	x25, x0
1004aeb2c:	mov	x0, x24
1004aeb30:	mov	x2, x25
1004aeb34:	bl	0x101ad4660 ; selector setTextColor:
1004aeb38:	mov	x0, x23
1004aeb3c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aeb40:	mov	x23, x25
1004aeb44:	add	x21, x21, #0x1
1004aeb48:	mov	x0, x23
1004aeb4c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aeb50:	cmp	x20, x21
1004aeb54:	b.eq	0x1004aed04
1004aeb58:	cbz	x27, 0x1004aeb6c
1004aeb5c:	mov	x0, x21
1004aeb60:	mov	x1, x19
1004aeb64:	bl	0x101ac75ac ; symbol stub for: _$ss12_ArrayBufferV19_getElementSlowPathyyXlSiFyXl_Ts5
1004aeb68:	b	0x1004aeb78
1004aeb6c:	add	x8, x19, x21, lsl #3
1004aeb70:	ldr	x0, [x8, #0x20]
1004aeb74:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aeb78:	mov	x23, x0
1004aeb7c:	adrp	x8, 7800 ; 0x102326000
1004aeb80:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004aeb84:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004aeb88:	mov	x1, x0
1004aeb8c:	mov	x0, x23
1004aeb90:	bl	0x101aca714 ; symbol stub for: _swift_dynamicCastObjCClass
1004aeb94:	cbz	x0, 0x1004aebf4
1004aeb98:	mov	x24, x0
1004aeb9c:	mov	x0, x23
1004aeba0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aeba4:	mov	x0, x24
1004aeba8:	bl	0x101ad5900 ; selector textColor
1004aebac:	mov	x29, x29
1004aebb0:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aebb4:	mov	x25, x0
1004aebb8:	mov	x0, x22
1004aebbc:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004aebc0:	tbz	w0, #0x0, 0x1004aec84
1004aebc4:	ldp	x28, x8, [x22, #0x10]
1004aebc8:	add	x26, x28, #0x1
1004aebcc:	cmp	x28, x8, lsr #1
1004aebd0:	b.lo	0x1004aeb04
1004aebd4:	cmp	x8, #0x1
1004aebd8:	cset	w0, hi
1004aebdc:	mov	x1, x26
1004aebe0:	mov	w2, #0x1
1004aebe4:	mov	x3, x22
1004aebe8:	bl	0x1004ae958
1004aebec:	mov	x22, x0
1004aebf0:	b	0x1004aeb04
1004aebf4:	adrp	x8, 7800 ; 0x102326000
1004aebf8:	ldr	x0, [x8, #0xb50] ; Objc class ref: _OBJC_CLASS_$_NSImageView
1004aebfc:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004aec00:	mov	x1, x0
1004aec04:	mov	x0, x23
1004aec08:	bl	0x101aca714 ; symbol stub for: _swift_dynamicCastObjCClass
1004aec0c:	cbz	x0, 0x1004aeb44
1004aec10:	mov	x24, x0
1004aec14:	mov	x0, x23
1004aec18:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aec1c:	mov	x0, x24
1004aec20:	bl	0x101acc780 ; selector contentTintColor
1004aec24:	mov	x29, x29
1004aec28:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aec2c:	mov	x25, x0
1004aec30:	mov	x0, x22
1004aec34:	bl	0x101aca930 ; symbol stub for: _swift_isUniquelyReferenced_nonNull_native
1004aec38:	tbz	w0, #0x0, 0x1004aeca4
1004aec3c:	ldp	x28, x8, [x22, #0x10]
1004aec40:	add	x26, x28, #0x1
1004aec44:	cmp	x28, x8, lsr #1
1004aec48:	b.hs	0x1004aecc4
1004aec4c:	str	x26, [x22, #0x10]
1004aec50:	add	x8, x22, x28, lsl #4
1004aec54:	stp	x24, x25, [x8, #0x20]
1004aec58:	adrp	x8, 7800 ; 0x102326000
1004aec5c:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004aec60:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004aec64:	bl	0x101ad14a0 ; selector selectedMenuItemTextColor
1004aec68:	mov	x29, x29
1004aec6c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aec70:	mov	x25, x0
1004aec74:	mov	x0, x24
1004aec78:	mov	x2, x25
1004aec7c:	bl	0x101ad2300 ; selector setContentTintColor:
1004aec80:	b	0x1004aeb38
1004aec84:	ldr	x8, [x22, #0x10]
1004aec88:	add	x1, x8, #0x1
1004aec8c:	mov	w0, #0x0
1004aec90:	mov	w2, #0x1
1004aec94:	mov	x3, x22
1004aec98:	bl	0x1004ae958
1004aec9c:	mov	x22, x0
1004aeca0:	b	0x1004aebc4
1004aeca4:	ldr	x8, [x22, #0x10]
1004aeca8:	add	x1, x8, #0x1
1004aecac:	mov	w0, #0x0
1004aecb0:	mov	w2, #0x1
1004aecb4:	mov	x3, x22
1004aecb8:	bl	0x1004ae958
1004aecbc:	mov	x22, x0
1004aecc0:	b	0x1004aec3c
1004aecc4:	cmp	x8, #0x1
1004aecc8:	cset	w0, hi
1004aeccc:	mov	x1, x26
1004aecd0:	mov	w2, #0x1
1004aecd4:	mov	x3, x22
1004aecd8:	bl	0x1004ae958
1004aecdc:	mov	x22, x0
1004aece0:	b	0x1004aec4c
1004aece4:	and	x8, x19, #0xffffffffffffff8
1004aece8:	cmn	x19, #0x1
1004aecec:	csel	x0, x8, x19, gt
1004aecf0:	bl	0x101ac7900 ; symbol stub for: _$ss18_CocoaArrayWrapperV8endIndexSivg
1004aecf4:	mov	x20, x0
1004aecf8:	cbnz	x20, 0x1004aeae8
1004aecfc:	adrp	x22, 7713 ; 0x1022cf000
1004aed00:	ldr	x22, [x22, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004aed04:	mov	x0, x19
1004aed08:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aed0c:	mov	x0, x22
1004aed10:	ldp	x29, x30, [sp, #0x50]
1004aed14:	ldp	x20, x19, [sp, #0x40]
1004aed18:	ldp	x22, x21, [sp, #0x30]
1004aed1c:	ldp	x24, x23, [sp, #0x20]
1004aed20:	ldp	x26, x25, [sp, #0x10]
1004aed24:	ldp	x28, x27, [sp], #0x60
1004aed28:	ret
1004aed2c:	brk	#0x1
1004aed30:	stp	x26, x25, [sp, #-0x50]!
1004aed34:	stp	x24, x23, [sp, #0x10]
1004aed38:	stp	x22, x21, [sp, #0x20]
1004aed3c:	stp	x20, x19, [sp, #0x30]
1004aed40:	stp	x29, x30, [sp, #0x40]
1004aed44:	add	x29, sp, #0x40
1004aed48:	ldr	x22, [x0, #0x10]
1004aed4c:	cbz	x22, 0x1004aedcc
1004aed50:	add	x23, x0, #0x28
1004aed54:	adrp	x24, 7800 ; 0x102326000
1004aed58:	adrp	x25, 7800 ; 0x102326000
1004aed5c:	b	0x1004aed74
1004aed60:	mov	x2, x19
1004aed64:	bl	0x101ad4660 ; selector setTextColor:
1004aed68:	add	x23, x23, #0x10
1004aed6c:	subs	x22, x22, #0x1
1004aed70:	b.eq	0x1004aedcc
1004aed74:	ldp	x20, x19, [x23, #-0x8]
1004aed78:	ldr	x0, [x24, #0xb30]
1004aed7c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004aed80:	mov	x1, x0
1004aed84:	mov	x0, x20
1004aed88:	bl	0x101aca714 ; symbol stub for: _swift_dynamicCastObjCClass
1004aed8c:	cbnz	x0, 0x1004aed60
1004aed90:	ldr	x0, [x25, #0xb50]
1004aed94:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004aed98:	mov	x1, x0
1004aed9c:	mov	x0, x20
1004aeda0:	bl	0x101aca714 ; symbol stub for: _swift_dynamicCastObjCClass
1004aeda4:	mov	x21, x0
1004aeda8:	cbz	x0, 0x1004aedb4
1004aedac:	mov	x0, x20
1004aedb0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aedb4:	mov	x0, x21
1004aedb8:	mov	x2, x19
1004aedbc:	bl	0x101ad2300 ; selector setContentTintColor:
1004aedc0:	mov	x0, x21
1004aedc4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aedc8:	b	0x1004aed68
1004aedcc:	ldp	x29, x30, [sp, #0x40]
1004aedd0:	ldp	x20, x19, [sp, #0x30]
1004aedd4:	ldp	x22, x21, [sp, #0x20]
1004aedd8:	ldp	x24, x23, [sp, #0x10]
1004aeddc:	ldp	x26, x25, [sp], #0x50
1004aede0:	ret
1004aede4:	stp	x29, x30, [sp, #-0x10]!
1004aede8:	mov	x29, sp
1004aedec:	adrp	x0, 7811 ; 0x102331000
1004aedf0:	add	x0, x0, #0x2f8
1004aedf4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004aedf8:	mov	x1, #0x0
1004aedfc:	ldp	x29, x30, [sp], #0x10
1004aee00:	ret
1004aee04:	sub	sp, sp, #0x40
1004aee08:	stp	x20, x19, [sp, #0x20]
1004aee0c:	stp	x29, x30, [sp, #0x30]
1004aee10:	add	x29, sp, #0x30
1004aee14:	adrp	x8, 7846 ; 0x102354000
1004aee18:	ldr	x8, [x8, #0xff8]
1004aee1c:	ldrb	w9, [x20, x8]
1004aee20:	mov	w10, #0x1
1004aee24:	strb	w10, [x20, x8]
1004aee28:	tbnz	w9, #0x0, 0x1004aee4c
1004aee2c:	mov	x0, x20
1004aee30:	bl	0x1004aea88
1004aee34:	adrp	x8, 7847 ; 0x102355000
1004aee38:	ldr	x9, [x8]
1004aee3c:	ldr	x8, [x20, x9]
1004aee40:	str	x0, [x20, x9]
1004aee44:	mov	x0, x8
1004aee48:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aee4c:	mov	x0, x20
1004aee50:	bl	0x101acbde0 ; selector bounds
1004aee54:	mov	x0, x20
1004aee58:	bl	0x101ad3820 ; selector setNeedsDisplayInRect:
1004aee5c:	ldr	x8, [x20]
1004aee60:	adrp	x9, 7713 ; 0x1022cf000
1004aee64:	ldr	x9, [x9, #0x718] ; literal pool symbol address: _swift_isaMask
1004aee68:	ldr	x9, [x9]
1004aee6c:	and	x8, x9, x8
1004aee70:	ldr	x8, [x8, #0x128]
1004aee74:	blr	x8
1004aee78:	tbz	w0, #0x0, 0x1004aeed4
1004aee7c:	mov	x0, x20
1004aee80:	bl	0x101ad6200 ; selector window
1004aee84:	mov	x29, x29
1004aee88:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aee8c:	mov	x19, x0
1004aee90:	bl	0x1004a9a8c
1004aee94:	mov	x20, x0
1004aee98:	add	x1, sp, #0x8
1004aee9c:	mov	x2, #0x0
1004aeea0:	mov	x3, #0x0
1004aeea4:	bl	0x101aca600 ; symbol stub for: _swift_beginAccess
1004aeea8:	mov	x0, x20
1004aeeac:	bl	0x101acaad4 ; symbol stub for: _swift_unknownObjectWeakLoadStrong
1004aeeb0:	cbz	x19, 0x1004aeee8
1004aeeb4:	cbz	x0, 0x1004aeef0
1004aeeb8:	mov	x20, x0
1004aeebc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aeec0:	mov	x0, x19
1004aeec4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aeec8:	cmp	x19, x20
1004aeecc:	b.ne	0x1004aeef8
1004aeed0:	b	0x1004aef08
1004aeed4:	mov	x0, #0x0
1004aeed8:	bl	0x1004ad03c
1004aeedc:	mov	x20, x0
1004aeee0:	bl	0x1004a9cc4
1004aeee4:	b	0x1004aef08
1004aeee8:	cbnz	x0, 0x1004aeef4
1004aeeec:	b	0x1004aef08
1004aeef0:	mov	x0, x19
1004aeef4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aeef8:	mov	x0, #0x0
1004aeefc:	bl	0x1004ad03c
1004aef00:	mov	x20, x0
1004aef04:	bl	0x1004a9cc8
1004aef08:	ldp	x29, x30, [sp, #0x30]
1004aef0c:	ldp	x20, x19, [sp, #0x20]
1004aef10:	add	sp, sp, #0x40
1004aef14:	ret
1004aef18:	stp	x22, x21, [sp, #-0x30]!
1004aef1c:	stp	x20, x19, [sp, #0x10]
1004aef20:	stp	x29, x30, [sp, #0x20]
1004aef24:	add	x29, sp, #0x20
1004aef28:	adrp	x8, 7846 ; 0x102354000
1004aef2c:	ldr	x8, [x8, #0xff8]
1004aef30:	ldrb	w9, [x20, x8]
1004aef34:	strb	wzr, [x20, x8]
1004aef38:	cmp	w9, #0x1
1004aef3c:	b.ne	0x1004aef74
1004aef40:	adrp	x8, 7847 ; 0x102355000
1004aef44:	ldr	x21, [x8]
1004aef48:	ldr	x19, [x20, x21]
1004aef4c:	mov	x0, x19
1004aef50:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004aef54:	bl	0x1004aed30
1004aef58:	mov	x0, x19
1004aef5c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aef60:	ldr	x0, [x20, x21]
1004aef64:	adrp	x8, 7713 ; 0x1022cf000
1004aef68:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004aef6c:	str	x8, [x20, x21]
1004aef70:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aef74:	mov	x0, x20
1004aef78:	bl	0x101acbde0 ; selector bounds
1004aef7c:	mov	x0, x20
1004aef80:	ldp	x29, x30, [sp, #0x20]
1004aef84:	ldp	x20, x19, [sp, #0x10]
1004aef88:	ldp	x22, x21, [sp], #0x30
1004aef8c:	b	0x101ad3820 ; selector setNeedsDisplayInRect:
1004aef90:	adrp	x0, 7468 ; 0x1021da000
1004aef94:	add	x0, x0, #0x930
1004aef98:	mov	x1, #0x0
1004aef9c:	ret
1004aefa0:	stp	x22, x21, [sp, #-0x30]!
1004aefa4:	stp	x20, x19, [sp, #0x10]
1004aefa8:	stp	x29, x30, [sp, #0x20]
1004aefac:	add	x29, sp, #0x20
1004aefb0:	and	w8, w0, #0x1
1004aefb4:	adrp	x9, 7847 ; 0x102355000
1004aefb8:	ldr	x9, [x9, #0x78]
1004aefbc:	ldrb	w10, [x20, x9]
1004aefc0:	strb	w0, [x20, x9]
1004aefc4:	cmp	w8, w10
1004aefc8:	b.eq	0x1004aeff0
1004aefcc:	tbz	w0, #0x0, 0x1004af000
1004aefd0:	mov	x0, x20
1004aefd4:	bl	0x1004adb68
1004aefd8:	mov	x8, x0
1004aefdc:	adrp	x9, 7847 ; 0x102355000
1004aefe0:	ldr	x9, [x9, #0x80]
1004aefe4:	ldr	x0, [x20, x9]
1004aefe8:	str	x8, [x20, x9]
1004aefec:	b	0x1004af030
1004aeff0:	ldp	x29, x30, [sp, #0x20]
1004aeff4:	ldp	x20, x19, [sp, #0x10]
1004aeff8:	ldp	x22, x21, [sp], #0x30
1004aeffc:	ret
1004af000:	adrp	x8, 7846 ; 0x102355000
1004af004:	ldr	x21, [x8, #0x80]
1004af008:	ldr	x19, [x20, x21]
1004af00c:	mov	x0, x19
1004af010:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004af014:	bl	0x1004adb6c
1004af018:	mov	x0, x19
1004af01c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004af020:	ldr	x0, [x20, x21]
1004af024:	adrp	x8, 7712 ; 0x1022cf000
1004af028:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004af02c:	str	x8, [x20, x21]
1004af030:	ldp	x29, x30, [sp, #0x20]
1004af034:	ldp	x20, x19, [sp, #0x10]
1004af038:	ldp	x22, x21, [sp], #0x30
1004af03c:	b	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004af040:	sub	sp, sp, #0xc0
1004af044:	stp	d13, d12, [sp, #0x30]
1004af048:	stp	d11, d10, [sp, #0x40]
1004af04c:	stp	d9, d8, [sp, #0x50]
1004af050:	stp	x28, x27, [sp, #0x60]
1004af054:	stp	x26, x25, [sp, #0x70]
1004af058:	stp	x24, x23, [sp, #0x80]
1004af05c:	stp	x22, x21, [sp, #0x90]
1004af060:	stp	x20, x19, [sp, #0xa0]
1004af064:	stp	x29, x30, [sp, #0xb0]
1004af068:	add	x29, sp, #0xb0
1004af06c:	mov	x24, x6
1004af070:	mov	x25, x5
1004af074:	mov	x26, x4
1004af078:	mov	x19, x3
1004af07c:	mov	x21, x2
1004af080:	mov	x22, x1
1004af084:	mov	x23, x0
1004af088:	ldr	x0, [x29, #0x10]
1004af08c:	adrp	x8, 7846 ; 0x102355000
1004af090:	ldr	x8, [x8, #0x50]
1004af094:	add	x8, x20, x8
1004af098:	ldp	x27, x28, [x8]
1004af09c:	stp	x7, x0, [x8]
1004af0a0:	bl	0x101aca978 ; symbol stub for: _swift_retain
1004af0a4:	mov	x0, x27
1004af0a8:	mov	x1, x28
1004af0ac:	bl	0x100003840
1004af0b0:	adrp	x8, 7846 ; 0x102355000
1004af0b4:	ldr	x8, [x8, #0x58]
1004af0b8:	add	x8, x20, x8
1004af0bc:	ldr	x0, [x8, #0x8]
1004af0c0:	stp	x25, x24, [x8]
1004af0c4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004af0c8:	adrp	x27, 7799 ; 0x102326000
1004af0cc:	tbz	w26, #0x0, 0x1004af23c
1004af0d0:	adrp	x8, 0 ; 0x1004af000
1004af0d4:	add	x8, x8, #0x634
1004af0d8:	stp	x8, xzr, [sp, #0x20]
1004af0dc:	adrp	x8, 7708 ; 0x1022cb000
1004af0e0:	ldr	x8, [x8, #0x300] ; literal pool symbol address: __NSConcreteStackBlock
1004af0e4:	str	x8, [sp]
1004af0e8:	adrp	x8, 5682 ; 0x101ae1000
1004af0ec:	ldr	d0, [x8]
1004af0f0:	str	d0, [sp, #0x8]
1004af0f4:	adrp	x8, -1076 ; 0x10007b000
1004af0f8:	add	x8, x8, #0x528
1004af0fc:	adrp	x9, 7467 ; 0x1021da000
1004af100:	add	x9, x9, #0x940
1004af104:	stp	x8, x9, [sp, #0x10]
1004af108:	mov	x0, sp
1004af10c:	bl	0x101ac9514 ; symbol stub for: __Block_copy
1004af110:	mov	x25, x0
1004af114:	adrp	x8, 7799 ; 0x102326000
1004af118:	ldr	x0, [x8, #0xb28] ; Objc class ref: _OBJC_CLASS_$_NSImage
1004af11c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004af120:	mov	x26, x0
1004af124:	mov	x0, x24
1004af128:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004af12c:	fmov	d0, #4.00000000
1004af130:	fmov	d1, #4.00000000
1004af134:	mov	x0, x26
1004af138:	mov	w2, #0x0
1004af13c:	mov	x3, x25
1004af140:	bl	0x101ace1e0 ; selector imageWithSize:flipped:drawingHandler:
1004af144:	mov	x29, x29
1004af148:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004af14c:	mov	x24, x0
1004af150:	mov	x0, x25
1004af154:	bl	0x101ac9520 ; symbol stub for: __Block_release
1004af158:	ldr	x0, [sp, #0x28]
1004af15c:	bl	0x101aca960 ; symbol stub for: _swift_release
1004af160:	mov	x0, x24
1004af164:	mov	w2, #0x1
1004af168:	bl	0x101ad4600 ; selector setTemplate:
1004af16c:	mov	x0, #0x6f46
1004af170:	movk	x0, #0x7563, lsl #16
1004af174:	movk	x0, #0x6573, lsl #32
1004af178:	movk	x0, #0x64, lsl #48
1004af17c:	mov	x1, #-0x1900000000000000
1004af180:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004af184:	mov	x25, x0
1004af188:	mov	x0, x24
1004af18c:	mov	x2, x25
1004af190:	bl	0x101ad16c0 ; selector setAccessibilityDescription:
1004af194:	mov	x0, x25
1004af198:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af19c:	mov	x0, x20
1004af1a0:	bl	0x101acbde0 ; selector bounds
1004af1a4:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004af1a8:	fmov	d1, #-4.00000000
1004af1ac:	fadd	d0, d0, d1
1004af1b0:	fmov	d1, #0.50000000
1004af1b4:	fmul	d8, d0, d1
1004af1b8:	adrp	x8, 7799 ; 0x102326000
1004af1bc:	ldr	x0, [x8, #0xb50] ; Objc class ref: _OBJC_CLASS_$_NSImageView
1004af1c0:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004af1c4:	fmov	d0, #16.00000000
1004af1c8:	fmov	d2, #4.00000000
1004af1cc:	fmov	d3, #4.00000000
1004af1d0:	mov.16b	v1, v8
1004af1d4:	bl	0x101ace5a0 ; selector initWithFrame:
1004af1d8:	mov	x25, x0
1004af1dc:	mov	x2, x24
1004af1e0:	bl	0x101ad2f60 ; selector setImage:
1004af1e4:	mov	x0, x25
1004af1e8:	mov	w2, #0x2
1004af1ec:	bl	0x101ad3000 ; selector setImageScaling:
1004af1f0:	ldr	x0, [x27, #0x9c8]
1004af1f4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004af1f8:	bl	0x101acf220 ; selector labelColor
1004af1fc:	mov	x29, x29
1004af200:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004af204:	mov	x26, x0
1004af208:	mov	x0, x25
1004af20c:	mov	x2, x26
1004af210:	bl	0x101ad2300 ; selector setContentTintColor:
1004af214:	mov	x0, x26
1004af218:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af21c:	mov	x0, x20
1004af220:	mov	x2, x25
1004af224:	bl	0x101acb460 ; selector addSubview:
1004af228:	mov	x0, x24
1004af22c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af230:	mov	x0, x25
1004af234:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af238:	b	0x1004af244
1004af23c:	mov	x0, x24
1004af240:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004af244:	mov	x0, x23
1004af248:	mov	x1, x22
1004af24c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004af250:	mov	x22, x0
1004af254:	adrp	x8, 7799 ; 0x102326000
1004af258:	ldr	x0, [x8, #0xb30] ; Objc class ref: _OBJC_CLASS_$_NSTextField
1004af25c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004af260:	mov	x23, x0
1004af264:	mov	x2, x22
1004af268:	bl	0x101acf240 ; selector labelWithString:
1004af26c:	mov	x29, x29
1004af270:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004af274:	mov	x24, x0
1004af278:	mov	x0, x22
1004af27c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af280:	mov	x0, x24
1004af284:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004af288:	mov	x22, x0
1004af28c:	bl	0x10002dd04
1004af290:	mov.16b	v1, v0
1004af294:	fmov	d0, #13.00000000
1004af298:	bl	0x100004700
1004af29c:	mov	x24, x0
1004af2a0:	mov	x0, x22
1004af2a4:	mov	x2, x24
1004af2a8:	bl	0x101ad2aa0 ; selector setFont:
1004af2ac:	mov	x0, x24
1004af2b0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af2b4:	ldr	x0, [x27, #0x9c8]
1004af2b8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004af2bc:	mov	x24, x0
1004af2c0:	bl	0x101acf220 ; selector labelColor
1004af2c4:	mov	x29, x29
1004af2c8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004af2cc:	mov	x25, x0
1004af2d0:	mov	x0, x22
1004af2d4:	mov	x2, x25
1004af2d8:	bl	0x101ad4660 ; selector setTextColor:
1004af2dc:	mov	x0, x25
1004af2e0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af2e4:	mov	x0, x22
1004af2e8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004af2ec:	mov	x22, x0
1004af2f0:	mov	x0, x20
1004af2f4:	bl	0x101acbde0 ; selector bounds
1004af2f8:	bl	0x101ac8db8 ; symbol stub for: _CGRectGetWidth
1004af2fc:	cmp	x19, #0x0
1004af300:	mov	x8, #0x4044000000000000
1004af304:	fmov	d1, x8
1004af308:	movi.2d	v2, #0000000000000000
1004af30c:	fcsel	d9, d2, d1, eq
1004af310:	fmov	d12, #-28.00000000
1004af314:	fadd	d0, d0, d12
1004af318:	fmov	d10, #-16.00000000
1004af31c:	fadd	d0, d0, d10
1004af320:	fsub	d8, d0, d9
1004af324:	mov	x0, x20
1004af328:	bl	0x101acbde0 ; selector bounds
1004af32c:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004af330:	mov.16b	v3, v0
1004af334:	fmov	d0, #28.00000000
1004af338:	movi.2d	v1, #0000000000000000
1004af33c:	mov	x0, x22
1004af340:	mov.16b	v2, v8
1004af344:	bl	0x101ad2b80 ; selector setFrame:
1004af348:	mov	x0, x22
1004af34c:	mov	w2, #0x4
1004af350:	bl	0x101ad3340 ; selector setLineBreakMode:
1004af354:	mov	x0, x22
1004af358:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af35c:	mov	x0, x22
1004af360:	mov	w2, #0x0
1004af364:	bl	0x101ad28e0 ; selector setEditable:
1004af368:	mov	x0, x22
1004af36c:	mov	w2, #0x0
1004af370:	bl	0x101ad1fa0 ; selector setBordered:
1004af374:	mov	x0, x22
1004af378:	mov	w2, #0x0
1004af37c:	bl	0x101ad2860 ; selector setDrawsBackground:
1004af380:	mov	x0, x20
1004af384:	mov	x2, x22
1004af388:	bl	0x101acb460 ; selector addSubview:
1004af38c:	adrp	x8, 7846 ; 0x102355000
1004af390:	ldr	x8, [x8, #0x60]
1004af394:	ldr	x25, [x20, x8]
1004af398:	str	x22, [x20, x8]
1004af39c:	mov	x0, x22
1004af3a0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004af3a4:	mov	x22, x0
1004af3a8:	mov	x0, x25
1004af3ac:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af3b0:	mov	x0, x22
1004af3b4:	bl	0x101ad4fe0 ; selector sizeToFit
1004af3b8:	mov	x0, x20
1004af3bc:	bl	0x101acbde0 ; selector bounds
1004af3c0:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004af3c4:	mov.16b	v8, v0
1004af3c8:	mov	x0, x22
1004af3cc:	bl	0x101acdcc0 ; selector frame
1004af3d0:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004af3d4:	fsub	d0, d8, d0
1004af3d8:	fmov	d11, #0.50000000
1004af3dc:	fmul	d8, d0, d11
1004af3e0:	mov	x0, x22
1004af3e4:	bl	0x101acdcc0 ; selector frame
1004af3e8:	mov	x0, x22
1004af3ec:	mov.16b	v1, v8
1004af3f0:	bl	0x101ad2b80 ; selector setFrame:
1004af3f4:	mov	x0, x20
1004af3f8:	bl	0x101acbde0 ; selector bounds
1004af3fc:	bl	0x101ac8db8 ; symbol stub for: _CGRectGetWidth
1004af400:	fadd	d0, d0, d12
1004af404:	fadd	d0, d0, d10
1004af408:	fsub	d8, d0, d9
1004af40c:	mov	x0, x22
1004af410:	bl	0x101acdcc0 ; selector frame
1004af414:	mov	x0, x22
1004af418:	mov.16b	v2, v8
1004af41c:	bl	0x101ad2b80 ; selector setFrame:
1004af420:	mov	x0, x22
1004af424:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af428:	cbz	x19, 0x1004af600
1004af42c:	mov	x0, x21
1004af430:	mov	x1, x19
1004af434:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004af438:	mov	x19, x0
1004af43c:	mov	x0, x23
1004af440:	mov	x2, x19
1004af444:	bl	0x101acf240 ; selector labelWithString:
1004af448:	mov	x29, x29
1004af44c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004af450:	mov	x21, x0
1004af454:	mov	x0, x19
1004af458:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af45c:	mov	x0, x21
1004af460:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004af464:	mov	x19, x0
1004af468:	bl	0x10002dd04
1004af46c:	mov.16b	v1, v0
1004af470:	fmov	d0, #12.00000000
1004af474:	bl	0x100004700
1004af478:	mov	x21, x0
1004af47c:	mov	x0, x19
1004af480:	mov	x2, x21
1004af484:	bl	0x101ad2aa0 ; selector setFont:
1004af488:	mov	x0, x21
1004af48c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af490:	mov	x0, x24
1004af494:	bl	0x101ad58a0 ; selector tertiaryLabelColor
1004af498:	mov	x29, x29
1004af49c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004af4a0:	mov	x21, x0
1004af4a4:	mov	x0, x19
1004af4a8:	mov	x2, x21
1004af4ac:	bl	0x101ad4660 ; selector setTextColor:
1004af4b0:	mov	x0, x21
1004af4b4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af4b8:	mov	x0, x19
1004af4bc:	mov	w2, #0x2
1004af4c0:	bl	0x101ad1820 ; selector setAlignment:
1004af4c4:	mov	x0, x19
1004af4c8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af4cc:	mov	x0, x19
1004af4d0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004af4d4:	mov	x19, x0
1004af4d8:	mov	x0, x20
1004af4dc:	bl	0x101acbde0 ; selector bounds
1004af4e0:	bl	0x101ac8db8 ; symbol stub for: _CGRectGetWidth
1004af4e4:	fadd	d0, d0, d10
1004af4e8:	mov	x8, #-0x3fbc000000000000
1004af4ec:	fmov	d12, x8
1004af4f0:	fadd	d9, d0, d12
1004af4f4:	mov	x0, x20
1004af4f8:	bl	0x101acbde0 ; selector bounds
1004af4fc:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004af500:	mov.16b	v3, v0
1004af504:	mov	x8, #0x4044000000000000
1004af508:	fmov	d8, x8
1004af50c:	movi.2d	v1, #0000000000000000
1004af510:	mov	x0, x19
1004af514:	mov.16b	v0, v9
1004af518:	mov.16b	v2, v8
1004af51c:	bl	0x101ad2b80 ; selector setFrame:
1004af520:	mov	x0, x19
1004af524:	mov	w2, #0x0
1004af528:	bl	0x101ad28e0 ; selector setEditable:
1004af52c:	mov	x0, x19
1004af530:	mov	w2, #0x0
1004af534:	bl	0x101ad1fa0 ; selector setBordered:
1004af538:	mov	x0, x19
1004af53c:	mov	w2, #0x0
1004af540:	bl	0x101ad2860 ; selector setDrawsBackground:
1004af544:	mov	x0, x20
1004af548:	mov	x2, x19
1004af54c:	bl	0x101acb460 ; selector addSubview:
1004af550:	adrp	x8, 7846 ; 0x102355000
1004af554:	ldr	x8, [x8, #0x68]
1004af558:	ldr	x21, [x20, x8]
1004af55c:	str	x19, [x20, x8]
1004af560:	mov	x0, x19
1004af564:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004af568:	mov	x19, x0
1004af56c:	mov	x0, x21
1004af570:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af574:	mov	x0, x19
1004af578:	bl	0x101ad4fe0 ; selector sizeToFit
1004af57c:	mov	x0, x20
1004af580:	bl	0x101acbde0 ; selector bounds
1004af584:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004af588:	mov.16b	v9, v0
1004af58c:	mov	x0, x19
1004af590:	bl	0x101acdcc0 ; selector frame
1004af594:	bl	0x101ac8d64 ; symbol stub for: _CGRectGetHeight
1004af598:	fsub	d0, d9, d0
1004af59c:	fmul	d9, d0, d11
1004af5a0:	mov	x0, x19
1004af5a4:	bl	0x101acdcc0 ; selector frame
1004af5a8:	mov	x0, x19
1004af5ac:	mov.16b	v1, v9
1004af5b0:	bl	0x101ad2b80 ; selector setFrame:
1004af5b4:	mov	x0, x19
1004af5b8:	bl	0x101acdcc0 ; selector frame
1004af5bc:	mov	x0, x19
1004af5c0:	mov.16b	v2, v8
1004af5c4:	bl	0x101ad2b80 ; selector setFrame:
1004af5c8:	mov	x0, x20
1004af5cc:	bl	0x101acbde0 ; selector bounds
1004af5d0:	bl	0x101ac8db8 ; symbol stub for: _CGRectGetWidth
1004af5d4:	fadd	d0, d0, d10
1004af5d8:	fadd	d8, d0, d12
1004af5dc:	mov	x0, x19
1004af5e0:	bl	0x101acdcc0 ; selector frame
1004af5e4:	mov	x0, x19
1004af5e8:	mov.16b	v0, v8
1004af5ec:	bl	0x101ad2b80 ; selector setFrame:
1004af5f0:	mov	x0, x19
1004af5f4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af5f8:	mov	x0, x19
1004af5fc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af600:	mov	x0, x22
1004af604:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af608:	ldp	x29, x30, [sp, #0xb0]
1004af60c:	ldp	x20, x19, [sp, #0xa0]
1004af610:	ldp	x22, x21, [sp, #0x90]
1004af614:	ldp	x24, x23, [sp, #0x80]
1004af618:	ldp	x26, x25, [sp, #0x70]
1004af61c:	ldp	x28, x27, [sp, #0x60]
1004af620:	ldp	d9, d8, [sp, #0x50]
1004af624:	ldp	d11, d10, [sp, #0x40]
1004af628:	ldp	d13, d12, [sp, #0x30]
1004af62c:	add	sp, sp, #0xc0
1004af630:	ret
1004af634:	stp	d11, d10, [sp, #-0x40]!
1004af638:	stp	d9, d8, [sp, #0x10]
1004af63c:	stp	x20, x19, [sp, #0x20]
1004af640:	stp	x29, x30, [sp, #0x30]
1004af644:	add	x29, sp, #0x30
1004af648:	mov.16b	v8, v3
1004af64c:	mov.16b	v9, v2
1004af650:	mov.16b	v10, v1
1004af654:	mov.16b	v11, v0
1004af658:	adrp	x8, 7799 ; 0x102326000
1004af65c:	ldr	x0, [x8, #0x9c8] ; Objc class ref: _OBJC_CLASS_$_NSColor
1004af660:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004af664:	bl	0x101acbc80 ; selector blackColor
1004af668:	mov	x29, x29
1004af66c:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004af670:	mov	x19, x0
1004af674:	bl	0x101ad29c0 ; selector setFill
1004af678:	mov	x0, x19
1004af67c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af680:	adrp	x8, 7799 ; 0x102326000
1004af684:	ldr	x0, [x8, #0xb38] ; Objc class ref: _OBJC_CLASS_$_NSBezierPath
1004af688:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004af68c:	mov.16b	v0, v11
1004af690:	mov.16b	v1, v10
1004af694:	mov.16b	v2, v9
1004af698:	mov.16b	v3, v8
1004af69c:	bl	0x101acbc00 ; selector bezierPathWithOvalInRect:
1004af6a0:	mov	x29, x29
1004af6a4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004af6a8:	mov	x19, x0
1004af6ac:	bl	0x101acda20 ; selector fill
1004af6b0:	mov	x0, x19
1004af6b4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af6b8:	mov	w0, #0x1
1004af6bc:	ldp	x29, x30, [sp, #0x30]
1004af6c0:	ldp	x20, x19, [sp, #0x20]
1004af6c4:	ldp	d9, d8, [sp, #0x10]
1004af6c8:	ldp	d11, d10, [sp], #0x40
1004af6cc:	ret
1004af6d0:	ldr	x8, [x1, #0x28]
1004af6d4:	ldr	q0, [x1, #0x20]
1004af6d8:	str	q0, [x0, #0x20]
1004af6dc:	mov	x0, x8
1004af6e0:	b	0x101aca978 ; symbol stub for: _swift_retain
1004af6e4:	ldr	x0, [x0, #0x28]
1004af6e8:	b	0x101aca960 ; symbol stub for: _swift_release
1004af6ec:	sub	sp, sp, #0x60
1004af6f0:	stp	d11, d10, [sp, #0x10]
1004af6f4:	stp	d9, d8, [sp, #0x20]
1004af6f8:	stp	x22, x21, [sp, #0x30]
1004af6fc:	stp	x20, x19, [sp, #0x40]
1004af700:	stp	x29, x30, [sp, #0x50]
1004af704:	add	x29, sp, #0x50
1004af708:	bl	0x1004af7b4
1004af70c:	stp	x20, x0, [sp]
1004af710:	adrp	x8, 7797 ; 0x102324000
1004af714:	ldr	x1, [x8, #0xea8] ; Objc selector ref: updateTrackingAreas
1004af718:	mov	x0, sp
1004af71c:	bl	0x101ac9d0c ; Objc message: -[[x0 super] updateTrackingAreas]
1004af720:	adrp	x8, 7846 ; 0x102355000
1004af724:	ldr	x21, [x8, #0x70]
1004af728:	ldr	x2, [x20, x21]
1004af72c:	cbz	x2, 0x1004af738
1004af730:	mov	x0, x20
1004af734:	bl	0x101ad0c40 ; selector removeTrackingArea:
1004af738:	mov	x0, x20
1004af73c:	bl	0x101acbde0 ; selector bounds
1004af740:	mov.16b	v8, v0
1004af744:	mov.16b	v9, v1
1004af748:	mov.16b	v10, v2
1004af74c:	mov.16b	v11, v3
1004af750:	adrp	x8, 7799 ; 0x102326000
1004af754:	ldr	x0, [x8, #0xa48] ; Objc class ref: _OBJC_CLASS_$_NSTrackingArea
1004af758:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1004af75c:	mov.16b	v0, v8
1004af760:	mov.16b	v1, v9
1004af764:	mov.16b	v2, v10
1004af768:	mov.16b	v3, v11
1004af76c:	mov	x3, x20
1004af770:	mov	w2, #0x81
1004af774:	mov	x4, #0x0
1004af778:	bl	0x101ace7c0 ; selector initWithRect:options:owner:userInfo:
1004af77c:	mov	x19, x0
1004af780:	mov	x0, x20
1004af784:	mov	x2, x19
1004af788:	bl	0x101acb540 ; selector addTrackingArea:
1004af78c:	ldr	x0, [x20, x21]
1004af790:	str	x19, [x20, x21]
1004af794:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af798:	ldp	x29, x30, [sp, #0x50]
1004af79c:	ldp	x20, x19, [sp, #0x40]
1004af7a0:	ldp	x22, x21, [sp, #0x30]
1004af7a4:	ldp	d9, d8, [sp, #0x20]
1004af7a8:	ldp	d11, d10, [sp, #0x10]
1004af7ac:	add	sp, sp, #0x60
1004af7b0:	ret
1004af7b4:	stp	x29, x30, [sp, #-0x10]!
1004af7b8:	mov	x29, sp
1004af7bc:	adrp	x0, 7810 ; 0x102331000
1004af7c0:	add	x0, x0, #0x4b0
1004af7c4:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004af7c8:	mov	x1, #0x0
1004af7cc:	ldp	x29, x30, [sp], #0x10
1004af7d0:	ret
1004af7d4:	stp	x20, x19, [sp, #-0x20]!
1004af7d8:	stp	x29, x30, [sp, #0x10]
1004af7dc:	add	x29, sp, #0x10
1004af7e0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004af7e4:	mov	x20, x0
1004af7e8:	bl	0x1004af6ec
1004af7ec:	mov	x0, x20
1004af7f0:	ldp	x29, x30, [sp, #0x10]
1004af7f4:	ldp	x20, x19, [sp], #0x20
1004af7f8:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004af7fc:	b	0x1004afe5c
1004af800:	stp	x22, x21, [sp, #-0x30]!
1004af804:	stp	x20, x19, [sp, #0x10]
1004af808:	stp	x29, x30, [sp, #0x20]
1004af80c:	add	x29, sp, #0x20
1004af810:	mov	x19, x0
1004af814:	mov	x0, x2
1004af818:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004af81c:	mov	x21, x0
1004af820:	mov	x0, x19
1004af824:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004af828:	mov	x20, x0
1004af82c:	bl	0x1004afe5c
1004af830:	mov	x0, x21
1004af834:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af838:	mov	x0, x20
1004af83c:	ldp	x29, x30, [sp, #0x20]
1004af840:	ldp	x20, x19, [sp, #0x10]
1004af844:	ldp	x22, x21, [sp], #0x30
1004af848:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004af84c:	b	0x1004aff78
1004af850:	stp	x22, x21, [sp, #-0x30]!
1004af854:	stp	x20, x19, [sp, #0x10]
1004af858:	stp	x29, x30, [sp, #0x20]
1004af85c:	add	x29, sp, #0x20
1004af860:	mov	x19, x0
1004af864:	mov	x0, x2
1004af868:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004af86c:	mov	x21, x0
1004af870:	mov	x0, x19
1004af874:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004af878:	mov	x20, x0
1004af87c:	bl	0x1004aff78
1004af880:	mov	x0, x21
1004af884:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af888:	mov	x0, x20
1004af88c:	ldp	x29, x30, [sp, #0x20]
1004af890:	ldp	x20, x19, [sp, #0x10]
1004af894:	ldp	x22, x21, [sp], #0x30
1004af898:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004af89c:	stp	d11, d10, [sp, #-0x40]!
1004af8a0:	stp	d9, d8, [sp, #0x10]
1004af8a4:	stp	x20, x19, [sp, #0x20]
1004af8a8:	stp	x29, x30, [sp, #0x30]
1004af8ac:	add	x29, sp, #0x30
1004af8b0:	mov	x19, x0
1004af8b4:	mov	x0, x20
1004af8b8:	bl	0x101acbde0 ; selector bounds
1004af8bc:	mov.16b	v8, v0
1004af8c0:	mov.16b	v9, v1
1004af8c4:	mov.16b	v10, v2
1004af8c8:	mov.16b	v11, v3
1004af8cc:	mov	x0, x19
1004af8d0:	bl	0x101acf5a0 ; selector locationInWindow
1004af8d4:	mov	x0, x20
1004af8d8:	mov	x2, #0x0
1004af8dc:	bl	0x101acc920 ; selector convertPoint:fromView:
1004af8e0:	mov.16b	v4, v0
1004af8e4:	mov.16b	v5, v1
1004af8e8:	mov.16b	v0, v8
1004af8ec:	mov.16b	v1, v9
1004af8f0:	mov.16b	v2, v10
1004af8f4:	mov.16b	v3, v11
1004af8f8:	bl	0x101ac8d40 ; symbol stub for: _CGRectContainsPoint
1004af8fc:	cbz	w0, 0x1004af944
1004af900:	adrp	x8, 7846 ; 0x102355000
1004af904:	ldr	x8, [x8, #0x50]
1004af908:	add	x8, x20, x8
1004af90c:	ldr	x19, [x8]
1004af910:	cbz	x19, 0x1004af944
1004af914:	ldr	x20, [x8, #0x8]
1004af918:	mov	x0, x19
1004af91c:	mov	x1, x20
1004af920:	bl	0x100003f5c
1004af924:	blr	x19
1004af928:	mov	x0, x19
1004af92c:	mov	x1, x20
1004af930:	ldp	x29, x30, [sp, #0x30]
1004af934:	ldp	x20, x19, [sp, #0x20]
1004af938:	ldp	d9, d8, [sp, #0x10]
1004af93c:	ldp	d11, d10, [sp], #0x40
1004af940:	b	0x100003840
1004af944:	ldp	x29, x30, [sp, #0x30]
1004af948:	ldp	x20, x19, [sp, #0x20]
1004af94c:	ldp	d9, d8, [sp, #0x10]
1004af950:	ldp	d11, d10, [sp], #0x40
1004af954:	ret
1004af958:	stp	x22, x21, [sp, #-0x30]!
1004af95c:	stp	x20, x19, [sp, #0x10]
1004af960:	stp	x29, x30, [sp, #0x20]
1004af964:	add	x29, sp, #0x20
1004af968:	mov	x19, x0
1004af96c:	mov	x0, x2
1004af970:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004af974:	mov	x21, x0
1004af978:	mov	x0, x19
1004af97c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004af980:	mov	x20, x0
1004af984:	mov	x0, x21
1004af988:	bl	0x1004af89c
1004af98c:	mov	x0, x21
1004af990:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004af994:	mov	x0, x20
1004af998:	ldp	x29, x30, [sp, #0x20]
1004af99c:	ldp	x20, x19, [sp, #0x10]
1004af9a0:	ldp	x22, x21, [sp], #0x30
1004af9a4:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004af9a8:	sub	sp, sp, #0x70
1004af9ac:	stp	d15, d14, [sp, #0x10]
1004af9b0:	stp	d13, d12, [sp, #0x20]
1004af9b4:	stp	d11, d10, [sp, #0x30]
1004af9b8:	stp	d9, d8, [sp, #0x40]
1004af9bc:	stp	x20, x19, [sp, #0x50]
1004af9c0:	stp	x29, x30, [sp, #0x60]
1004af9c4:	add	x29, sp, #0x60
1004af9c8:	mov.16b	v8, v3
1004af9cc:	mov.16b	v9, v2
1004af9d0:	mov.16b	v10, v1
1004af9d4:	mov.16b	v11, v0
1004af9d8:	adrp	x8, 7846 ; 0x102355000
1004af9dc:	ldr	x8, [x8, #0x78]
1004af9e0:	ldrb	w8, [x20, x8]
1004af9e4:	cmp	w8, #0x1
1004af9e8:	b.ne	0x1004afa64
1004af9ec:	bl	0x1004adb20
1004af9f0:	mov	x19, x0
1004af9f4:	bl	0x101ad29c0 ; selector setFill
1004af9f8:	mov	x0, x19
1004af9fc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004afa00:	mov	x0, x20
1004afa04:	bl	0x101acbde0 ; selector bounds
1004afa08:	fmov	d4, #4.00000000
1004afa0c:	fmov	d5, #1.00000000
1004afa10:	bl	0x101ac8dc4 ; symbol stub for: _CGRectInset
1004afa14:	mov.16b	v12, v0
1004afa18:	mov.16b	v13, v1
1004afa1c:	mov.16b	v14, v2
1004afa20:	mov.16b	v15, v3
1004afa24:	adrp	x8, 7799 ; 0x102326000
1004afa28:	ldr	x0, [x8, #0xb38] ; Objc class ref: _OBJC_CLASS_$_NSBezierPath
1004afa2c:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004afa30:	fmov	d4, #6.00000000
1004afa34:	fmov	d5, #6.00000000
1004afa38:	mov.16b	v0, v12
1004afa3c:	mov.16b	v1, v13
1004afa40:	mov.16b	v2, v14
1004afa44:	mov.16b	v3, v15
1004afa48:	bl	0x101acbc40 ; selector bezierPathWithRoundedRect:xRadius:yRadius:
1004afa4c:	mov	x29, x29
1004afa50:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004afa54:	mov	x19, x0
1004afa58:	bl	0x101acda20 ; selector fill
1004afa5c:	mov	x0, x19
1004afa60:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004afa64:	bl	0x1004af7b4
1004afa68:	stp	x20, x0, [sp]
1004afa6c:	adrp	x8, 7794 ; 0x102321000
1004afa70:	ldr	x1, [x8, #0x3b8] ; Objc selector ref: drawRect:
1004afa74:	mov	x0, sp
1004afa78:	mov.16b	v0, v11
1004afa7c:	mov.16b	v1, v10
1004afa80:	mov.16b	v2, v9
1004afa84:	mov.16b	v3, v8
1004afa88:	bl	0x101ac9d0c ; Objc message: -[[x0 super] drawRect:]
1004afa8c:	ldp	x29, x30, [sp, #0x60]
1004afa90:	ldp	x20, x19, [sp, #0x50]
1004afa94:	ldp	d9, d8, [sp, #0x40]
1004afa98:	ldp	d11, d10, [sp, #0x30]
1004afa9c:	ldp	d13, d12, [sp, #0x20]
1004afaa0:	ldp	d15, d14, [sp, #0x10]
1004afaa4:	add	sp, sp, #0x70
1004afaa8:	ret
1004afaac:	stp	d11, d10, [sp, #-0x40]!
1004afab0:	stp	d9, d8, [sp, #0x10]
1004afab4:	stp	x20, x19, [sp, #0x20]
1004afab8:	stp	x29, x30, [sp, #0x30]
1004afabc:	add	x29, sp, #0x30
1004afac0:	mov.16b	v8, v3
1004afac4:	mov.16b	v9, v2
1004afac8:	mov.16b	v10, v1
1004afacc:	mov.16b	v11, v0
1004afad0:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004afad4:	mov	x20, x0
1004afad8:	mov.16b	v0, v11
1004afadc:	mov.16b	v1, v10
1004afae0:	mov.16b	v2, v9
1004afae4:	mov.16b	v3, v8
1004afae8:	bl	0x1004af9a8
1004afaec:	mov	x0, x20
1004afaf0:	ldp	x29, x30, [sp, #0x30]
1004afaf4:	ldp	x20, x19, [sp, #0x20]
1004afaf8:	ldp	d9, d8, [sp, #0x10]
1004afafc:	ldp	d11, d10, [sp], #0x40
1004afb00:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004afb04:	stp	x29, x30, [sp, #-0x10]!
1004afb08:	mov	x29, sp
1004afb0c:	bl	0x1004aefa0
1004afb10:	mov	x0, x20
1004afb14:	bl	0x101acbde0 ; selector bounds
1004afb18:	mov	x0, x20
1004afb1c:	ldp	x29, x30, [sp], #0x10
1004afb20:	b	0x101ad3820 ; selector setNeedsDisplayInRect:
1004afb24:	stp	x20, x19, [sp, #-0x20]!
1004afb28:	stp	x29, x30, [sp, #0x10]
1004afb2c:	add	x29, sp, #0x10
1004afb30:	adrp	x8, 7846 ; 0x102355000
1004afb34:	ldr	x8, [x8, #0x50]
1004afb38:	add	x8, x20, x8
1004afb3c:	ldr	x19, [x8]
1004afb40:	cbz	x19, 0x1004afb6c
1004afb44:	ldr	x20, [x8, #0x8]
1004afb48:	mov	x0, x19
1004afb4c:	mov	x1, x20
1004afb50:	bl	0x100003f5c
1004afb54:	blr	x19
1004afb58:	mov	x0, x19
1004afb5c:	mov	x1, x20
1004afb60:	ldp	x29, x30, [sp, #0x10]
1004afb64:	ldp	x20, x19, [sp], #0x20
1004afb68:	b	0x100003840
1004afb6c:	ldp	x29, x30, [sp, #0x10]
1004afb70:	ldp	x20, x19, [sp], #0x20
1004afb74:	ret
1004afb78:	sub	sp, sp, #0x40
1004afb7c:	stp	d11, d10, [sp, #0x10]
1004afb80:	stp	d9, d8, [sp, #0x20]
1004afb84:	stp	x29, x30, [sp, #0x30]
1004afb88:	add	x29, sp, #0x30
1004afb8c:	mov.16b	v8, v3
1004afb90:	mov.16b	v9, v2
1004afb94:	mov.16b	v10, v1
1004afb98:	mov.16b	v11, v0
1004afb9c:	adrp	x8, 7846 ; 0x102355000
1004afba0:	ldr	x8, [x8, #0x60]
1004afba4:	str	xzr, [x20, x8]
1004afba8:	adrp	x8, 7846 ; 0x102355000
1004afbac:	ldr	x8, [x8, #0x68]
1004afbb0:	str	xzr, [x20, x8]
1004afbb4:	adrp	x8, 7846 ; 0x102355000
1004afbb8:	ldr	x8, [x8, #0x50]
1004afbbc:	add	x8, x20, x8
1004afbc0:	stp	xzr, xzr, [x8]
1004afbc4:	adrp	x8, 7846 ; 0x102355000
1004afbc8:	ldr	x8, [x8, #0x58]
1004afbcc:	add	x8, x20, x8
1004afbd0:	stp	xzr, xzr, [x8]
1004afbd4:	adrp	x8, 7846 ; 0x102355000
1004afbd8:	ldr	x8, [x8, #0x70]
1004afbdc:	str	xzr, [x20, x8]
1004afbe0:	adrp	x8, 7846 ; 0x102355000
1004afbe4:	ldr	x8, [x8, #0x80]
1004afbe8:	adrp	x9, 7712 ; 0x1022cf000
1004afbec:	ldr	x9, [x9, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004afbf0:	str	x9, [x20, x8]
1004afbf4:	adrp	x8, 7846 ; 0x102355000
1004afbf8:	ldr	x8, [x8, #0x78]
1004afbfc:	strb	wzr, [x20, x8]
1004afc00:	adrp	x8, 7846 ; 0x102355000
1004afc04:	ldr	x8, [x8, #0x88]
1004afc08:	mov	x9, #0x4030000000000000
1004afc0c:	str	x9, [x20, x8]
1004afc10:	adrp	x8, 7846 ; 0x102355000
1004afc14:	ldr	x8, [x8, #0x90]
1004afc18:	mov	x9, #0x4028000000000000
1004afc1c:	str	x9, [x20, x8]
1004afc20:	adrp	x8, 7846 ; 0x102355000
1004afc24:	ldr	x8, [x8, #0x98]
1004afc28:	mov	x9, #0x4010000000000000
1004afc2c:	str	x9, [x20, x8]
1004afc30:	bl	0x1004af7b4
1004afc34:	stp	x20, x0, [sp]
1004afc38:	adrp	x8, 7796 ; 0x102323000
1004afc3c:	ldr	x1, [x8, #0x50] ; Objc selector ref: initWithFrame:
1004afc40:	mov	x0, sp
1004afc44:	mov.16b	v0, v11
1004afc48:	mov.16b	v1, v10
1004afc4c:	mov.16b	v2, v9
1004afc50:	mov.16b	v3, v8
1004afc54:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithFrame:]
1004afc58:	ldp	x29, x30, [sp, #0x30]
1004afc5c:	ldp	d9, d8, [sp, #0x20]
1004afc60:	ldp	d11, d10, [sp, #0x10]
1004afc64:	add	sp, sp, #0x40
1004afc68:	ret
1004afc6c:	stp	x20, x19, [sp, #-0x20]!
1004afc70:	stp	x29, x30, [sp, #0x10]
1004afc74:	add	x29, sp, #0x10
1004afc78:	mov	x20, x0
1004afc7c:	bl	0x1004afb78
1004afc80:	ldp	x29, x30, [sp, #0x10]
1004afc84:	ldp	x20, x19, [sp], #0x20
1004afc88:	ret
1004afc8c:	sub	sp, sp, #0x30
1004afc90:	stp	x20, x19, [sp, #0x10]
1004afc94:	stp	x29, x30, [sp, #0x20]
1004afc98:	add	x29, sp, #0x20
1004afc9c:	mov	x19, x0
1004afca0:	adrp	x8, 7846 ; 0x102355000
1004afca4:	ldr	x8, [x8, #0x60]
1004afca8:	str	xzr, [x20, x8]
1004afcac:	adrp	x8, 7846 ; 0x102355000
1004afcb0:	ldr	x8, [x8, #0x68]
1004afcb4:	str	xzr, [x20, x8]
1004afcb8:	adrp	x8, 7846 ; 0x102355000
1004afcbc:	ldr	x8, [x8, #0x50]
1004afcc0:	add	x8, x20, x8
1004afcc4:	stp	xzr, xzr, [x8]
1004afcc8:	adrp	x8, 7846 ; 0x102355000
1004afccc:	ldr	x8, [x8, #0x58]
1004afcd0:	add	x8, x20, x8
1004afcd4:	stp	xzr, xzr, [x8]
1004afcd8:	adrp	x8, 7846 ; 0x102355000
1004afcdc:	ldr	x8, [x8, #0x70]
1004afce0:	str	xzr, [x20, x8]
1004afce4:	adrp	x8, 7846 ; 0x102355000
1004afce8:	ldr	x8, [x8, #0x80]
1004afcec:	adrp	x9, 7712 ; 0x1022cf000
1004afcf0:	ldr	x9, [x9, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004afcf4:	str	x9, [x20, x8]
1004afcf8:	adrp	x8, 7846 ; 0x102355000
1004afcfc:	ldr	x8, [x8, #0x78]
1004afd00:	strb	wzr, [x20, x8]
1004afd04:	adrp	x8, 7846 ; 0x102355000
1004afd08:	ldr	x8, [x8, #0x88]
1004afd0c:	mov	x9, #0x4030000000000000
1004afd10:	str	x9, [x20, x8]
1004afd14:	adrp	x8, 7846 ; 0x102355000
1004afd18:	ldr	x8, [x8, #0x90]
1004afd1c:	mov	x9, #0x4028000000000000
1004afd20:	str	x9, [x20, x8]
1004afd24:	adrp	x8, 7846 ; 0x102355000
1004afd28:	ldr	x8, [x8, #0x98]
1004afd2c:	mov	x9, #0x4010000000000000
1004afd30:	str	x9, [x20, x8]
1004afd34:	bl	0x1004af7b4
1004afd38:	stp	x20, x0, [sp]
1004afd3c:	adrp	x8, 7795 ; 0x102322000
1004afd40:	ldr	x1, [x8, #0xfd8] ; Objc selector ref: initWithCoder:
1004afd44:	mov	x0, sp
1004afd48:	mov	x2, x19
1004afd4c:	bl	0x101ac9d0c ; Objc message: -[[x0 super] initWithCoder:]
1004afd50:	mov	x29, x29
1004afd54:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004afd58:	mov	x20, x0
1004afd5c:	mov	x0, x19
1004afd60:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004afd64:	cbz	x20, 0x1004afd70
1004afd68:	mov	x0, x20
1004afd6c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004afd70:	mov	x0, x20
1004afd74:	ldp	x29, x30, [sp, #0x20]
1004afd78:	ldp	x20, x19, [sp, #0x10]
1004afd7c:	add	sp, sp, #0x30
1004afd80:	ret
1004afd84:	stp	x20, x19, [sp, #-0x20]!
1004afd88:	stp	x29, x30, [sp, #0x10]
1004afd8c:	add	x29, sp, #0x10
1004afd90:	mov	x20, x0
1004afd94:	mov	x0, x2
1004afd98:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004afd9c:	bl	0x1004afc8c
1004afda0:	ldp	x29, x30, [sp, #0x10]
1004afda4:	ldp	x20, x19, [sp], #0x20
1004afda8:	ret
1004afdac:	sub	sp, sp, #0x20
1004afdb0:	stp	x29, x30, [sp, #0x10]
1004afdb4:	add	x29, sp, #0x10
1004afdb8:	bl	0x1004af7b4
1004afdbc:	stp	x20, x0, [sp]
1004afdc0:	adrp	x8, 7794 ; 0x102321000
1004afdc4:	ldr	x1, [x8, #0x2d8] ; Objc selector ref: dealloc
1004afdc8:	mov	x0, sp
1004afdcc:	bl	0x101ac9d0c ; Objc message: -[[x0 super] dealloc]
1004afdd0:	ldp	x29, x30, [sp, #0x10]
1004afdd4:	add	sp, sp, #0x20
1004afdd8:	ret
1004afddc:	stp	x20, x19, [sp, #-0x20]!
1004afde0:	stp	x29, x30, [sp, #0x10]
1004afde4:	add	x29, sp, #0x10
1004afde8:	mov	x19, x0
1004afdec:	adrp	x8, 7846 ; 0x102355000
1004afdf0:	ldr	x8, [x8, #0x60]
1004afdf4:	ldr	x0, [x0, x8]
1004afdf8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004afdfc:	adrp	x8, 7846 ; 0x102355000
1004afe00:	ldr	x8, [x8, #0x68]
1004afe04:	ldr	x0, [x19, x8]
1004afe08:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004afe0c:	adrp	x8, 7846 ; 0x102355000
1004afe10:	ldr	x8, [x8, #0x50]
1004afe14:	add	x8, x19, x8
1004afe18:	ldp	x0, x1, [x8]
1004afe1c:	bl	0x100003840
1004afe20:	adrp	x8, 7846 ; 0x102355000
1004afe24:	ldr	x8, [x8, #0x58]
1004afe28:	add	x8, x19, x8
1004afe2c:	ldr	x0, [x8, #0x8]
1004afe30:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004afe34:	adrp	x8, 7846 ; 0x102355000
1004afe38:	ldr	x8, [x8, #0x70]
1004afe3c:	ldr	x0, [x19, x8]
1004afe40:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004afe44:	adrp	x8, 7846 ; 0x102355000
1004afe48:	ldr	x8, [x8, #0x80]
1004afe4c:	ldr	x0, [x19, x8]
1004afe50:	ldp	x29, x30, [sp, #0x10]
1004afe54:	ldp	x20, x19, [sp], #0x20
1004afe58:	b	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004afe5c:	stp	x22, x21, [sp, #-0x30]!
1004afe60:	stp	x20, x19, [sp, #0x10]
1004afe64:	stp	x29, x30, [sp, #0x20]
1004afe68:	add	x29, sp, #0x20
1004afe6c:	mov	x19, x20
1004afe70:	adrp	x8, 7846 ; 0x102355000
1004afe74:	ldr	x8, [x8, #0x78]
1004afe78:	ldrb	w9, [x20, x8]
1004afe7c:	mov	w10, #0x1
1004afe80:	strb	w10, [x20, x8]
1004afe84:	tbnz	w9, #0x0, 0x1004afea8
1004afe88:	mov	x0, x19
1004afe8c:	bl	0x1004adb68
1004afe90:	adrp	x8, 7846 ; 0x102355000
1004afe94:	ldr	x9, [x8, #0x80]
1004afe98:	ldr	x8, [x19, x9]
1004afe9c:	str	x0, [x19, x9]
1004afea0:	mov	x0, x8
1004afea4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004afea8:	mov	x0, x19
1004afeac:	bl	0x101acbde0 ; selector bounds
1004afeb0:	mov	x0, x19
1004afeb4:	bl	0x101ad3820 ; selector setNeedsDisplayInRect:
1004afeb8:	mov	x0, #0x0
1004afebc:	bl	0x1004ad03c
1004afec0:	mov	x20, x0
1004afec4:	bl	0x1004a9cc4
1004afec8:	adrp	x8, 7846 ; 0x102355000
1004afecc:	ldr	x8, [x8, #0x58]
1004afed0:	add	x8, x19, x8
1004afed4:	ldr	x19, [x8, #0x8]
1004afed8:	cbz	x19, 0x1004aff68
1004afedc:	ldr	x20, [x8]
1004afee0:	adrp	x8, 7799 ; 0x102326000
1004afee4:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004afee8:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004afeec:	mov	x21, x0
1004afef0:	mov	x0, x19
1004afef4:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004afef8:	mov	x0, x21
1004afefc:	bl	0x101acce80 ; selector defaultCenter
1004aff00:	mov	x29, x29
1004aff04:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004aff08:	mov	x21, x0
1004aff0c:	bl	0x10006eba4
1004aff10:	ldr	x0, [x0]
1004aff14:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1004aff18:	mov	x22, x0
1004aff1c:	mov	x0, x20
1004aff20:	mov	x1, x19
1004aff24:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1004aff28:	mov	x20, x0
1004aff2c:	mov	x0, x19
1004aff30:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004aff34:	mov	x0, x21
1004aff38:	mov	x2, x22
1004aff3c:	mov	x3, x20
1004aff40:	bl	0x101ad0340 ; selector postNotificationName:object:
1004aff44:	mov	x0, x21
1004aff48:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aff4c:	mov	x0, x22
1004aff50:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1004aff54:	mov	x0, x20
1004aff58:	ldp	x29, x30, [sp, #0x20]
1004aff5c:	ldp	x20, x19, [sp, #0x10]
1004aff60:	ldp	x22, x21, [sp], #0x30
1004aff64:	b	0x101ac9d30 ; symbol stub for: _objc_release
1004aff68:	ldp	x29, x30, [sp, #0x20]
1004aff6c:	ldp	x20, x19, [sp, #0x10]
1004aff70:	ldp	x22, x21, [sp], #0x30
1004aff74:	ret
1004aff78:	stp	x22, x21, [sp, #-0x30]!
1004aff7c:	stp	x20, x19, [sp, #0x10]
1004aff80:	stp	x29, x30, [sp, #0x20]
1004aff84:	add	x29, sp, #0x20
1004aff88:	adrp	x8, 7846 ; 0x102355000
1004aff8c:	ldr	x8, [x8, #0x78]
1004aff90:	ldrb	w9, [x20, x8]
1004aff94:	strb	wzr, [x20, x8]
1004aff98:	cmp	w9, #0x1
1004aff9c:	b.ne	0x1004affd4
1004affa0:	adrp	x8, 7846 ; 0x102355000
1004affa4:	ldr	x21, [x8, #0x80]
1004affa8:	ldr	x19, [x20, x21]
1004affac:	mov	x0, x19
1004affb0:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1004affb4:	bl	0x1004adb6c
1004affb8:	mov	x0, x19
1004affbc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004affc0:	ldr	x0, [x20, x21]
1004affc4:	adrp	x8, 7712 ; 0x1022cf000
1004affc8:	ldr	x8, [x8, #0x4a8] ; literal pool symbol address: __swiftEmptyArrayStorage
1004affcc:	str	x8, [x20, x21]
1004affd0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1004affd4:	mov	x0, x20
1004affd8:	bl	0x101acbde0 ; selector bounds
1004affdc:	mov	x0, x20
1004affe0:	bl	0x101ad3820 ; selector setNeedsDisplayInRect:
1004affe4:	adrp	x8, 7799 ; 0x102326000
1004affe8:	ldr	x0, [x8, #0xa00] ; Objc class ref: _OBJC_CLASS_$_NSNotificationCenter
1004affec:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1004afff0:	bl	0x101acce80 ; selector defaultCenter
1004afff4:	mov	x29, x29
1004afff8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1004afffc:	mov	x19, x0
