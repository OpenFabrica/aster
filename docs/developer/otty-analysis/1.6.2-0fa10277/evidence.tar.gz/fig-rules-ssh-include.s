
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101479f48 <__ZN15otty_ssh_config4load15resolve_include17h5b4ceee53b87a305E>:
101479f48: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
101479f4c: a90157f6    	stp	x22, x21, [sp, #0x10]
101479f50: a9024ff4    	stp	x20, x19, [sp, #0x20]
101479f54: a9037bfd    	stp	x29, x30, [sp, #0x30]
101479f58: 9100c3fd    	add	x29, sp, #0x30
101479f5c: aa0103f3    	mov	x19, x1
101479f60: b40001a1    	cbz	x1, 0x101479f94 <__ZN15otty_ssh_config4load15resolve_include17h5b4ceee53b87a305E+0x4c>
101479f64: f100067f    	cmp	x19, #0x1
101479f68: 54000241    	b.ne	0x101479fb0 <__ZN15otty_ssh_config4load15resolve_include17h5b4ceee53b87a305E+0x68>
101479f6c: 39400009    	ldrb	w9, [x0]
101479f70: 7101f93f    	cmp	w9, #0x7e
101479f74: 54000101    	b.ne	0x101479f94 <__ZN15otty_ssh_config4load15resolve_include17h5b4ceee53b87a305E+0x4c>
101479f78: aa0203e0    	mov	x0, x2
101479f7c: aa0303e1    	mov	x1, x3
101479f80: a9437bfd    	ldp	x29, x30, [sp, #0x30]
101479f84: a9424ff4    	ldp	x20, x19, [sp, #0x20]
101479f88: a94157f6    	ldp	x22, x21, [sp, #0x10]
101479f8c: a8c45ff8    	ldp	x24, x23, [sp], #0x40
101479f90: 140d260d    	b	0x1017c37c4 <__ZN3std4path4Path11to_path_buf17h78bffc49f7c5d7e1E>
101479f94: d280000a    	mov	x10, #0x0               ; =0
101479f98: b40001ca    	cbz	x10, 0x101479fd0 <__ZN15otty_ssh_config4load15resolve_include17h5b4ceee53b87a305E+0x88>
101479f9c: aa0203e0    	mov	x0, x2
101479fa0: aa0303e1    	mov	x1, x3
101479fa4: aa0a03e2    	mov	x2, x10
101479fa8: aa0903e3    	mov	x3, x9
101479fac: 1400001f    	b	0x10147a028 <__ZN15otty_ssh_config4load15resolve_include17h5b4ceee53b87a305E+0xe0>
101479fb0: aa0003ea    	mov	x10, x0
101479fb4: 78402549    	ldrh	w9, [x10], #0x2
101479fb8: 5ac0092b    	rev	w11, w9
101479fbc: d1000a69    	sub	x9, x19, #0x2
101479fc0: 528fc5ec    	mov	w12, #0x7e2f            ; =32303
101479fc4: 6b4b419f    	cmp	w12, w11, lsr #16
101479fc8: 9a9f014a    	csel	x10, x10, xzr, eq
101479fcc: b5fffe8a    	cbnz	x10, 0x101479f9c <__ZN15otty_ssh_config4load15resolve_include17h5b4ceee53b87a305E+0x54>
101479fd0: aa0403f7    	mov	x23, x4
101479fd4: aa0503f6    	mov	x22, x5
101479fd8: aa0803f4    	mov	x20, x8
101479fdc: aa0003f5    	mov	x21, x0
101479fe0: aa1303e1    	mov	x1, x19
101479fe4: 940d25f1    	bl	0x1017c37a8 <__ZN3std4path4Path11is_absolute17hfb29e0a39a1869d7E>
101479fe8: 36000160    	tbz	w0, #0x0, 0x10147a014 <__ZN15otty_ssh_config4load15resolve_include17h5b4ceee53b87a305E+0xcc>
101479fec: b4000293    	cbz	x19, 0x10147a03c <__ZN15otty_ssh_config4load15resolve_include17h5b4ceee53b87a305E+0xf4>
101479ff0: 97d891c0    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101479ff4: aa1303e0    	mov	x0, x19
101479ff8: 52800021    	mov	w1, #0x1                ; =1
101479ffc: 97d891b7    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147a000: aa0003f6    	mov	x22, x0
10147a004: b50001e0    	cbnz	x0, 0x10147a040 <__ZN15otty_ssh_config4load15resolve_include17h5b4ceee53b87a305E+0xf8>
10147a008: 52800020    	mov	w0, #0x1                ; =1
10147a00c: aa1303e1    	mov	x1, x19
10147a010: 941924d9    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10147a014: aa1403e8    	mov	x8, x20
10147a018: aa1703e0    	mov	x0, x23
10147a01c: aa1603e1    	mov	x1, x22
10147a020: aa1503e2    	mov	x2, x21
10147a024: aa1303e3    	mov	x3, x19
10147a028: a9437bfd    	ldp	x29, x30, [sp, #0x30]
10147a02c: a9424ff4    	ldp	x20, x19, [sp, #0x20]
10147a030: a94157f6    	ldp	x22, x21, [sp, #0x10]
10147a034: a8c45ff8    	ldp	x24, x23, [sp], #0x40
10147a038: 140d2899    	b	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
10147a03c: 52800036    	mov	w22, #0x1               ; =1
10147a040: aa1603e0    	mov	x0, x22
10147a044: aa1503e1    	mov	x1, x21
10147a048: aa1303e2    	mov	x2, x19
10147a04c: 94193ef7    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147a050: a9005a93    	stp	x19, x22, [x20]
10147a054: f9000a93    	str	x19, [x20, #0x10]
10147a058: a9437bfd    	ldp	x29, x30, [sp, #0x30]
10147a05c: a9424ff4    	ldp	x20, x19, [sp, #0x20]
10147a060: a94157f6    	ldp	x22, x21, [sp, #0x10]
10147a064: a8c45ff8    	ldp	x24, x23, [sp], #0x40
10147a068: d65f03c0    	ret

000000010147a06c <__ZN15otty_ssh_config4load17hc1a443bac5749e8eE>:
10147a06c: d10203ff    	sub	sp, sp, #0x80
10147a070: a90557f6    	stp	x22, x21, [sp, #0x50]
10147a074: a9064ff4    	stp	x20, x19, [sp, #0x60]
10147a078: a9077bfd    	stp	x29, x30, [sp, #0x70]
10147a07c: 9101c3fd    	add	x29, sp, #0x70
10147a080: aa0803f3    	mov	x19, x8
10147a084: 910003e8    	mov	x8, sp
10147a088: 9400015f    	bl	0x10147a604 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E>
10147a08c: 910003e0    	mov	x0, sp
10147a090: aa1303e8    	mov	x8, x19
10147a094: 94000209    	bl	0x10147a8b8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E>
10147a098: f94003e1    	ldr	x1, [sp]
10147a09c: b4000081    	cbz	x1, 0x10147a0ac <__ZN15otty_ssh_config4load17hc1a443bac5749e8eE+0x40>
10147a0a0: f94007e0    	ldr	x0, [sp, #0x8]
10147a0a4: 52800022    	mov	w2, #0x1                ; =1
10147a0a8: 97d8918d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a0ac: f9400fe1    	ldr	x1, [sp, #0x18]
10147a0b0: b4000081    	cbz	x1, 0x10147a0c0 <__ZN15otty_ssh_config4load17hc1a443bac5749e8eE+0x54>
10147a0b4: f94013e0    	ldr	x0, [sp, #0x20]
10147a0b8: 52800022    	mov	w2, #0x1                ; =1
10147a0bc: 97d89188    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a0c0: a943d3f3    	ldp	x19, x20, [sp, #0x38]
10147a0c4: b4000194    	cbz	x20, 0x10147a0f4 <__ZN15otty_ssh_config4load17hc1a443bac5749e8eE+0x88>
10147a0c8: 91002275    	add	x21, x19, #0x8
10147a0cc: 14000004    	b	0x10147a0dc <__ZN15otty_ssh_config4load17hc1a443bac5749e8eE+0x70>
10147a0d0: 910082b5    	add	x21, x21, #0x20
10147a0d4: f1000694    	subs	x20, x20, #0x1
10147a0d8: 540000e0    	b.eq	0x10147a0f4 <__ZN15otty_ssh_config4load17hc1a443bac5749e8eE+0x88>
10147a0dc: f85f82a1    	ldur	x1, [x21, #-0x8]
10147a0e0: b4ffff81    	cbz	x1, 0x10147a0d0 <__ZN15otty_ssh_config4load17hc1a443bac5749e8eE+0x64>
10147a0e4: f94002a0    	ldr	x0, [x21]
10147a0e8: 52800022    	mov	w2, #0x1                ; =1
10147a0ec: 97d8917c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a0f0: 17fffff8    	b	0x10147a0d0 <__ZN15otty_ssh_config4load17hc1a443bac5749e8eE+0x64>
10147a0f4: f9401be8    	ldr	x8, [sp, #0x30]
10147a0f8: b4000128    	cbz	x8, 0x10147a11c <__ZN15otty_ssh_config4load17hc1a443bac5749e8eE+0xb0>
10147a0fc: d37be901    	lsl	x1, x8, #5
10147a100: aa1303e0    	mov	x0, x19
10147a104: 52800102    	mov	w2, #0x8                ; =8
10147a108: a9477bfd    	ldp	x29, x30, [sp, #0x70]
10147a10c: a9464ff4    	ldp	x20, x19, [sp, #0x60]
10147a110: a94557f6    	ldp	x22, x21, [sp, #0x50]
10147a114: 910203ff    	add	sp, sp, #0x80
10147a118: 17d89171    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a11c: a9477bfd    	ldp	x29, x30, [sp, #0x70]
10147a120: a9464ff4    	ldp	x20, x19, [sp, #0x60]
10147a124: a94557f6    	ldp	x22, x21, [sp, #0x50]
10147a128: 910203ff    	add	sp, sp, #0x80
10147a12c: d65f03c0    	ret
10147a130: aa0003f3    	mov	x19, x0
10147a134: 910003e0    	mov	x0, sp
10147a138: 97d3036d    	bl	0x10093aeec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x27ec4>
10147a13c: aa1303e0    	mov	x0, x19
10147a140: 94193d25    	bl	0x101ac95d4 <_writev+0x101ac95d4>

000000010147a144 <__ZN15otty_ssh_config4load6Loader15resolve_include17h0614d86c9adfc7baE>:
10147a144: aa0203e9    	mov	x9, x2
10147a148: a9408c02    	ldp	x2, x3, [x0, #0x8]
10147a14c: a9421404    	ldp	x4, x5, [x0, #0x20]
10147a150: aa0103e0    	mov	x0, x1
10147a154: aa0903e1    	mov	x1, x9
10147a158: 17ffff7c    	b	0x101479f48 <__ZN15otty_ssh_config4load15resolve_include17h5b4ceee53b87a305E>

000000010147a15c <__ZN15otty_ssh_config4load6Loader15ssh_config_only17h4c508a3576e2129aE>:
10147a15c: d10243ff    	sub	sp, sp, #0x90
10147a160: a9055ff8    	stp	x24, x23, [sp, #0x50]
10147a164: a90657f6    	stp	x22, x21, [sp, #0x60]
10147a168: a9074ff4    	stp	x20, x19, [sp, #0x70]
10147a16c: a9087bfd    	stp	x29, x30, [sp, #0x80]
10147a170: 910203fd    	add	x29, sp, #0x80
10147a174: aa0803f3    	mov	x19, x8
10147a178: 910003e8    	mov	x8, sp
10147a17c: 94000122    	bl	0x10147a604 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E>
10147a180: f94023f4    	ldr	x20, [sp, #0x40]
10147a184: b4000354    	cbz	x20, 0x10147a1ec <__ZN15otty_ssh_config4load6Loader15ssh_config_only17h4c508a3576e2129aE+0x90>
10147a188: d2800017    	mov	x23, #0x0               ; =0
10147a18c: f9401fe8    	ldr	x8, [sp, #0x38]
10147a190: d1000695    	sub	x21, x20, #0x1
10147a194: d37bea89    	lsl	x9, x20, #5
10147a198: 8b170116    	add	x22, x8, x23
10147a19c: 394062ca    	ldrb	w10, [x22, #0x18]
10147a1a0: 350000ea    	cbnz	w10, 0x10147a1bc <__ZN15otty_ssh_config4load6Loader15ssh_config_only17h4c508a3576e2129aE+0x60>
10147a1a4: d10006b5    	sub	x21, x21, #0x1
10147a1a8: 910082f7    	add	x23, x23, #0x20
10147a1ac: eb17013f    	cmp	x9, x23
10147a1b0: 54ffff41    	b.ne	0x10147a198 <__ZN15otty_ssh_config4load6Loader15ssh_config_only17h4c508a3576e2129aE+0x3c>
10147a1b4: d2800017    	mov	x23, #0x0               ; =0
10147a1b8: 1400000b    	b	0x10147a1e4 <__ZN15otty_ssh_config4load6Loader15ssh_config_only17h4c508a3576e2129aE+0x88>
10147a1bc: f84206c1    	ldr	x1, [x22], #0x20
10147a1c0: d1008138    	sub	x24, x9, #0x20
10147a1c4: b40000a1    	cbz	x1, 0x10147a1d8 <__ZN15otty_ssh_config4load6Loader15ssh_config_only17h4c508a3576e2129aE+0x7c>
10147a1c8: 8b170108    	add	x8, x8, x23
10147a1cc: f9400500    	ldr	x0, [x8, #0x8]
10147a1d0: 52800022    	mov	w2, #0x1                ; =1
10147a1d4: 97d89142    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a1d8: eb17031f    	cmp	x24, x23
10147a1dc: 54000201    	b.ne	0x10147a21c <__ZN15otty_ssh_config4load6Loader15ssh_config_only17h4c508a3576e2129aE+0xc0>
10147a1e0: 52800037    	mov	w23, #0x1               ; =1
10147a1e4: cb170288    	sub	x8, x20, x23
10147a1e8: f90023e8    	str	x8, [sp, #0x40]
10147a1ec: ad4107e0    	ldp	q0, q1, [sp, #0x20]
10147a1f0: ad010660    	stp	q0, q1, [x19, #0x20]
10147a1f4: 3dc013e0    	ldr	q0, [sp, #0x40]
10147a1f8: 3d801260    	str	q0, [x19, #0x40]
10147a1fc: ad4003e1    	ldp	q1, q0, [sp]
10147a200: ad000261    	stp	q1, q0, [x19]
10147a204: a9487bfd    	ldp	x29, x30, [sp, #0x80]
10147a208: a9474ff4    	ldp	x20, x19, [sp, #0x70]
10147a20c: a94657f6    	ldp	x22, x21, [sp, #0x60]
10147a210: a9455ff8    	ldp	x24, x23, [sp, #0x50]
10147a214: 910243ff    	add	sp, sp, #0x90
10147a218: d65f03c0    	ret
10147a21c: 52800037    	mov	w23, #0x1               ; =1
10147a220: 14000007    	b	0x10147a23c <__ZN15otty_ssh_config4load6Loader15ssh_config_only17h4c508a3576e2129aE+0xe0>
10147a224: ad4006c0    	ldp	q0, q1, [x22]
10147a228: cb1716c8    	sub	x8, x22, x23, lsl #5
10147a22c: ad000500    	stp	q0, q1, [x8]
10147a230: 910082d6    	add	x22, x22, #0x20
10147a234: f10006b5    	subs	x21, x21, #0x1
10147a238: 54fffd60    	b.eq	0x10147a1e4 <__ZN15otty_ssh_config4load6Loader15ssh_config_only17h4c508a3576e2129aE+0x88>
10147a23c: 394062c8    	ldrb	w8, [x22, #0x18]
10147a240: 34ffff28    	cbz	w8, 0x10147a224 <__ZN15otty_ssh_config4load6Loader15ssh_config_only17h4c508a3576e2129aE+0xc8>
10147a244: 910006f7    	add	x23, x23, #0x1
10147a248: f94002c1    	ldr	x1, [x22]
10147a24c: b4ffff21    	cbz	x1, 0x10147a230 <__ZN15otty_ssh_config4load6Loader15ssh_config_only17h4c508a3576e2129aE+0xd4>
10147a250: f94006c0    	ldr	x0, [x22, #0x8]
10147a254: 52800022    	mov	w2, #0x1                ; =1
10147a258: 97d89121    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a25c: 17fffff5    	b	0x10147a230 <__ZN15otty_ssh_config4load6Loader15ssh_config_only17h4c508a3576e2129aE+0xd4>

000000010147a260 <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E>:
10147a260: d10203ff    	sub	sp, sp, #0x80
10147a264: a9026ffc    	stp	x28, x27, [sp, #0x20]
10147a268: a90367fa    	stp	x26, x25, [sp, #0x30]
10147a26c: a9045ff8    	stp	x24, x23, [sp, #0x40]
10147a270: a90557f6    	stp	x22, x21, [sp, #0x50]
10147a274: a9064ff4    	stp	x20, x19, [sp, #0x60]
10147a278: a9077bfd    	stp	x29, x30, [sp, #0x70]
10147a27c: 9101c3fd    	add	x29, sp, #0x70
10147a280: aa0203f5    	mov	x21, x2
10147a284: aa0103f6    	mov	x22, x1
10147a288: aa0003f3    	mov	x19, x0
10147a28c: aa0803f4    	mov	x20, x8
10147a290: aa0103e0    	mov	x0, x1
10147a294: aa0203e1    	mov	x1, x2
10147a298: 940d28d4    	bl	0x1017c45e8 <__ZN3std4path4Path6parent17h81615573672c555dE>
10147a29c: b40001a0    	cbz	x0, 0x10147a2d0 <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0x70>
10147a2a0: 910023e8    	add	x8, sp, #0x8
10147a2a4: 940d2548    	bl	0x1017c37c4 <__ZN3std4path4Path11to_path_buf17h78bffc49f7c5d7e1E>
10147a2a8: aa1303f7    	mov	x23, x19
10147a2ac: f8418ee1    	ldr	x1, [x23, #0x18]!
10147a2b0: b4000081    	cbz	x1, 0x10147a2c0 <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0x60>
10147a2b4: f9401260    	ldr	x0, [x19, #0x20]
10147a2b8: 52800022    	mov	w2, #0x1                ; =1
10147a2bc: 97d89108    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a2c0: 3cc083e0    	ldur	q0, [sp, #0x8]
10147a2c4: 3d8002e0    	str	q0, [x23]
10147a2c8: f9400fe8    	ldr	x8, [sp, #0x18]
10147a2cc: f9000ae8    	str	x8, [x23, #0x10]
10147a2d0: f9402277    	ldr	x23, [x19, #0x40]
10147a2d4: b4000357    	cbz	x23, 0x10147a33c <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0xdc>
10147a2d8: d280001a    	mov	x26, #0x0               ; =0
10147a2dc: f9401e68    	ldr	x8, [x19, #0x38]
10147a2e0: d10006f8    	sub	x24, x23, #0x1
10147a2e4: d37beae9    	lsl	x9, x23, #5
10147a2e8: 8b1a0119    	add	x25, x8, x26
10147a2ec: 3940632a    	ldrb	w10, [x25, #0x18]
10147a2f0: 340000ea    	cbz	w10, 0x10147a30c <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0xac>
10147a2f4: d1000718    	sub	x24, x24, #0x1
10147a2f8: 9100835a    	add	x26, x26, #0x20
10147a2fc: eb1a013f    	cmp	x9, x26
10147a300: 54ffff41    	b.ne	0x10147a2e8 <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0x88>
10147a304: d280001a    	mov	x26, #0x0               ; =0
10147a308: 1400000b    	b	0x10147a334 <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0xd4>
10147a30c: f8420721    	ldr	x1, [x25], #0x20
10147a310: d100813b    	sub	x27, x9, #0x20
10147a314: b40000a1    	cbz	x1, 0x10147a328 <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0xc8>
10147a318: 8b1a0108    	add	x8, x8, x26
10147a31c: f9400500    	ldr	x0, [x8, #0x8]
10147a320: 52800022    	mov	w2, #0x1                ; =1
10147a324: 97d890ee    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a328: eb1a037f    	cmp	x27, x26
10147a32c: 54000481    	b.ne	0x10147a3bc <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0x15c>
10147a330: 5280003a    	mov	w26, #0x1               ; =1
10147a334: cb1a02f7    	sub	x23, x23, x26
10147a338: f9002277    	str	x23, [x19, #0x40]
10147a33c: 910023e8    	add	x8, sp, #0x8
10147a340: aa1603e0    	mov	x0, x22
10147a344: aa1503e1    	mov	x1, x21
10147a348: 940d251f    	bl	0x1017c37c4 <__ZN3std4path4Path11to_path_buf17h78bffc49f7c5d7e1E>
10147a34c: a940dbf5    	ldp	x21, x22, [sp, #0x8]
10147a350: f9400ff8    	ldr	x24, [sp, #0x18]
10147a354: f8430268    	ldur	x8, [x19, #0x30]
10147a358: eb0802ff    	cmp	x23, x8
10147a35c: 54000061    	b.ne	0x10147a368 <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0x108>
10147a360: 9100c260    	add	x0, x19, #0x30
10147a364: 94185a64    	bl	0x101a90cf4 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h30a0c46a7e759a54E>
10147a368: f9401e68    	ldr	x8, [x19, #0x38]
10147a36c: 8b171508    	add	x8, x8, x23, lsl #5
10147a370: a9005915    	stp	x21, x22, [x8]
10147a374: f9000918    	str	x24, [x8, #0x10]
10147a378: 3900611f    	strb	wzr, [x8, #0x18]
10147a37c: 910006e8    	add	x8, x23, #0x1
10147a380: f9002268    	str	x8, [x19, #0x40]
10147a384: ad410660    	ldp	q0, q1, [x19, #0x20]
10147a388: ad010680    	stp	q0, q1, [x20, #0x20]
10147a38c: ad400261    	ldp	q1, q0, [x19]
10147a390: ad000281    	stp	q1, q0, [x20]
10147a394: 3dc01260    	ldr	q0, [x19, #0x40]
10147a398: 3d801280    	str	q0, [x20, #0x40]
10147a39c: a9477bfd    	ldp	x29, x30, [sp, #0x70]
10147a3a0: a9464ff4    	ldp	x20, x19, [sp, #0x60]
10147a3a4: a94557f6    	ldp	x22, x21, [sp, #0x50]
10147a3a8: a9445ff8    	ldp	x24, x23, [sp, #0x40]
10147a3ac: a94367fa    	ldp	x26, x25, [sp, #0x30]
10147a3b0: a9426ffc    	ldp	x28, x27, [sp, #0x20]
10147a3b4: 910203ff    	add	sp, sp, #0x80
10147a3b8: d65f03c0    	ret
10147a3bc: 5280003a    	mov	w26, #0x1               ; =1
10147a3c0: 14000007    	b	0x10147a3dc <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0x17c>
10147a3c4: ad400720    	ldp	q0, q1, [x25]
10147a3c8: cb1a1728    	sub	x8, x25, x26, lsl #5
10147a3cc: ad000500    	stp	q0, q1, [x8]
10147a3d0: 91008339    	add	x25, x25, #0x20
10147a3d4: f1000718    	subs	x24, x24, #0x1
10147a3d8: 54fffae0    	b.eq	0x10147a334 <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0xd4>
10147a3dc: 39406328    	ldrb	w8, [x25, #0x18]
10147a3e0: 35ffff28    	cbnz	w8, 0x10147a3c4 <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0x164>
10147a3e4: 9100075a    	add	x26, x26, #0x1
10147a3e8: f9400321    	ldr	x1, [x25]
10147a3ec: b4ffff21    	cbz	x1, 0x10147a3d0 <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0x170>
10147a3f0: f9400720    	ldr	x0, [x25, #0x8]
10147a3f4: 52800022    	mov	w2, #0x1                ; =1
10147a3f8: 97d890b9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a3fc: 17fffff5    	b	0x10147a3d0 <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0x170>
10147a400: aa0003f4    	mov	x20, x0
10147a404: b4000155    	cbz	x21, 0x10147a42c <__ZN15otty_ssh_config4load6Loader15with_ssh_config17h0e9b2e58593eb815E+0x1cc>
10147a408: aa1603e0    	mov	x0, x22
10147a40c: aa1503e1    	mov	x1, x21
10147a410: 52800022    	mov	w2, #0x1                ; =1
10147a414: 97d890b2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a418: aa1303e0    	mov	x0, x19
10147a41c: 97d302b4    	bl	0x10093aeec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x27ec4>
10147a420: aa1403e0    	mov	x0, x20
10147a424: 94193c6c    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147a428: aa0003f4    	mov	x20, x0
10147a42c: aa1303e0    	mov	x0, x19
10147a430: 97d302af    	bl	0x10093aeec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x27ec4>
10147a434: aa1403e0    	mov	x0, x20
10147a438: 94193c67    	bl	0x101ac95d4 <_writev+0x101ac95d4>

000000010147a43c <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E>:
10147a43c: d10203ff    	sub	sp, sp, #0x80
10147a440: a9026ffc    	stp	x28, x27, [sp, #0x20]
10147a444: a90367fa    	stp	x26, x25, [sp, #0x30]
10147a448: a9045ff8    	stp	x24, x23, [sp, #0x40]
10147a44c: a90557f6    	stp	x22, x21, [sp, #0x50]
10147a450: a9064ff4    	stp	x20, x19, [sp, #0x60]
10147a454: a9077bfd    	stp	x29, x30, [sp, #0x70]
10147a458: 9101c3fd    	add	x29, sp, #0x70
10147a45c: aa0203f5    	mov	x21, x2
10147a460: aa0103f6    	mov	x22, x1
10147a464: aa0003f3    	mov	x19, x0
10147a468: aa0803f4    	mov	x20, x8
10147a46c: f9402017    	ldr	x23, [x0, #0x40]
10147a470: b40001f7    	cbz	x23, 0x10147a4ac <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0x70>
10147a474: d280001a    	mov	x26, #0x0               ; =0
10147a478: f9401e68    	ldr	x8, [x19, #0x38]
10147a47c: d10006f8    	sub	x24, x23, #0x1
10147a480: d37beae9    	lsl	x9, x23, #5
10147a484: 8b1a0119    	add	x25, x8, x26
10147a488: 3940632a    	ldrb	w10, [x25, #0x18]
10147a48c: 7100055f    	cmp	w10, #0x1
10147a490: 54000140    	b.eq	0x10147a4b8 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0x7c>
10147a494: d1000718    	sub	x24, x24, #0x1
10147a498: 9100835a    	add	x26, x26, #0x20
10147a49c: eb1a013f    	cmp	x9, x26
10147a4a0: 54ffff21    	b.ne	0x10147a484 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0x48>
10147a4a4: d280001a    	mov	x26, #0x0               ; =0
10147a4a8: 1400000e    	b	0x10147a4e0 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0xa4>
10147a4ac: d2800018    	mov	x24, #0x0               ; =0
10147a4b0: b50001f6    	cbnz	x22, 0x10147a4ec <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0xb0>
10147a4b4: 14000025    	b	0x10147a548 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0x10c>
10147a4b8: f8420721    	ldr	x1, [x25], #0x20
10147a4bc: d100813b    	sub	x27, x9, #0x20
10147a4c0: b40000a1    	cbz	x1, 0x10147a4d4 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0x98>
10147a4c4: 8b1a0108    	add	x8, x8, x26
10147a4c8: f9400500    	ldr	x0, [x8, #0x8]
10147a4cc: 52800022    	mov	w2, #0x1                ; =1
10147a4d0: 97d89083    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a4d4: eb1a037f    	cmp	x27, x26
10147a4d8: 54000541    	b.ne	0x10147a580 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0x144>
10147a4dc: 5280003a    	mov	w26, #0x1               ; =1
10147a4e0: cb1a02f8    	sub	x24, x23, x26
10147a4e4: f9002278    	str	x24, [x19, #0x40]
10147a4e8: b4000316    	cbz	x22, 0x10147a548 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0x10c>
10147a4ec: 910023e8    	add	x8, sp, #0x8
10147a4f0: aa1603e0    	mov	x0, x22
10147a4f4: aa1503e1    	mov	x1, x21
10147a4f8: 940d24b3    	bl	0x1017c37c4 <__ZN3std4path4Path11to_path_buf17h78bffc49f7c5d7e1E>
10147a4fc: a940dbf5    	ldp	x21, x22, [sp, #0x8]
10147a500: f9400ff9    	ldr	x25, [sp, #0x18]
10147a504: f8430268    	ldur	x8, [x19, #0x30]
10147a508: eb08031f    	cmp	x24, x8
10147a50c: 54000061    	b.ne	0x10147a518 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0xdc>
10147a510: 9100c260    	add	x0, x19, #0x30
10147a514: 941859f8    	bl	0x101a90cf4 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h30a0c46a7e759a54E>
10147a518: f9401e77    	ldr	x23, [x19, #0x38]
10147a51c: b40000b8    	cbz	x24, 0x10147a530 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0xf4>
10147a520: d37beb02    	lsl	x2, x24, #5
10147a524: 910082e0    	add	x0, x23, #0x20
10147a528: aa1703e1    	mov	x1, x23
10147a52c: 94193dc5    	bl	0x101ac9c40 <_writev+0x101ac9c40>
10147a530: a9005af5    	stp	x21, x22, [x23]
10147a534: f9000af9    	str	x25, [x23, #0x10]
10147a538: 52800028    	mov	w8, #0x1                ; =1
10147a53c: 390062e8    	strb	w8, [x23, #0x18]
10147a540: 91000708    	add	x8, x24, #0x1
10147a544: f9002268    	str	x8, [x19, #0x40]
10147a548: ad410660    	ldp	q0, q1, [x19, #0x20]
10147a54c: ad010680    	stp	q0, q1, [x20, #0x20]
10147a550: 3dc01260    	ldr	q0, [x19, #0x40]
10147a554: 3d801280    	str	q0, [x20, #0x40]
10147a558: ad400261    	ldp	q1, q0, [x19]
10147a55c: ad000281    	stp	q1, q0, [x20]
10147a560: a9477bfd    	ldp	x29, x30, [sp, #0x70]
10147a564: a9464ff4    	ldp	x20, x19, [sp, #0x60]
10147a568: a94557f6    	ldp	x22, x21, [sp, #0x50]
10147a56c: a9445ff8    	ldp	x24, x23, [sp, #0x40]
10147a570: a94367fa    	ldp	x26, x25, [sp, #0x30]
10147a574: a9426ffc    	ldp	x28, x27, [sp, #0x20]
10147a578: 910203ff    	add	sp, sp, #0x80
10147a57c: d65f03c0    	ret
10147a580: 5280003a    	mov	w26, #0x1               ; =1
10147a584: 14000007    	b	0x10147a5a0 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0x164>
10147a588: ad400720    	ldp	q0, q1, [x25]
10147a58c: cb1a1728    	sub	x8, x25, x26, lsl #5
10147a590: ad000500    	stp	q0, q1, [x8]
10147a594: 91008339    	add	x25, x25, #0x20
10147a598: f1000718    	subs	x24, x24, #0x1
10147a59c: 54fffa20    	b.eq	0x10147a4e0 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0xa4>
10147a5a0: 39406328    	ldrb	w8, [x25, #0x18]
10147a5a4: 7100051f    	cmp	w8, #0x1
10147a5a8: 54ffff01    	b.ne	0x10147a588 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0x14c>
10147a5ac: 9100075a    	add	x26, x26, #0x1
10147a5b0: f9400321    	ldr	x1, [x25]
10147a5b4: b4ffff01    	cbz	x1, 0x10147a594 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0x158>
10147a5b8: f9400720    	ldr	x0, [x25, #0x8]
10147a5bc: 52800022    	mov	w2, #0x1                ; =1
10147a5c0: 97d89047    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a5c4: 17fffff4    	b	0x10147a594 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0x158>
10147a5c8: aa0003f4    	mov	x20, x0
10147a5cc: b4000155    	cbz	x21, 0x10147a5f4 <__ZN15otty_ssh_config4load6Loader16with_otty_config17h4be2061472845458E+0x1b8>
10147a5d0: aa1603e0    	mov	x0, x22
10147a5d4: aa1503e1    	mov	x1, x21
10147a5d8: 52800022    	mov	w2, #0x1                ; =1
10147a5dc: 97d89040    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a5e0: aa1303e0    	mov	x0, x19
10147a5e4: 97d30242    	bl	0x10093aeec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x27ec4>
10147a5e8: aa1403e0    	mov	x0, x20
10147a5ec: 94193bfa    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147a5f0: aa0003f4    	mov	x20, x0
10147a5f4: aa1303e0    	mov	x0, x19
10147a5f8: 97d3023d    	bl	0x10093aeec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x27ec4>
10147a5fc: aa1403e0    	mov	x0, x20
10147a600: 94193bf5    	bl	0x101ac95d4 <_writev+0x101ac95d4>

000000010147a604 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E>:
10147a604: d10343ff    	sub	sp, sp, #0xd0
10147a608: a90867fa    	stp	x26, x25, [sp, #0x80]
10147a60c: a9095ff8    	stp	x24, x23, [sp, #0x90]
10147a610: a90a57f6    	stp	x22, x21, [sp, #0xa0]
10147a614: a90b4ff4    	stp	x20, x19, [sp, #0xb0]
10147a618: a90c7bfd    	stp	x29, x30, [sp, #0xc0]
10147a61c: 910303fd    	add	x29, sp, #0xc0
10147a620: aa0103f3    	mov	x19, x1
10147a624: aa0003f5    	mov	x21, x0
10147a628: aa0803f6    	mov	x22, x8
10147a62c: 90003522    	adrp	x2, 0x101b1e000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x17014>
10147a630: 9111f042    	add	x2, x2, #0x47c
10147a634: 910023e8    	add	x8, sp, #0x8
10147a638: 52800083    	mov	w3, #0x4                ; =4
10147a63c: 940d2718    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
10147a640: 910083e8    	add	x8, sp, #0x20
10147a644: aa1503e0    	mov	x0, x21
10147a648: aa1303e1    	mov	x1, x19
10147a64c: 940d245e    	bl	0x1017c37c4 <__ZN3std4path4Path11to_path_buf17h78bffc49f7c5d7e1E>
10147a650: 97d89028    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147a654: 52800800    	mov	w0, #0x40               ; =64
10147a658: 52800101    	mov	w1, #0x8                ; =8
10147a65c: 97d8901f    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147a660: b4000960    	cbz	x0, 0x10147a78c <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x188>
10147a664: aa0003f4    	mov	x20, x0
10147a668: b0004342    	adrp	x2, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147a66c: 910d3842    	add	x2, x2, #0x34e
10147a670: 910143e8    	add	x8, sp, #0x50
10147a674: aa1503e0    	mov	x0, x21
10147a678: aa1303e1    	mov	x1, x19
10147a67c: 528000e3    	mov	w3, #0x7                ; =7
10147a680: 940d2707    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
10147a684: a94587f3    	ldp	x19, x1, [sp, #0x58]
10147a688: 90003522    	adrp	x2, 0x101b1e000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x17014>
10147a68c: 9110b042    	add	x2, x2, #0x42c
10147a690: 9100e3e8    	add	x8, sp, #0x38
10147a694: aa1303e0    	mov	x0, x19
10147a698: 52800083    	mov	w3, #0x4                ; =4
10147a69c: 940d2700    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
10147a6a0: a94407f5    	ldp	x21, x1, [sp, #0x40]
10147a6a4: b0004342    	adrp	x2, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147a6a8: 910d5442    	add	x2, x2, #0x355
10147a6ac: d10163a8    	sub	x8, x29, #0x58
10147a6b0: aa1503e0    	mov	x0, x21
10147a6b4: 52800143    	mov	w3, #0xa                ; =10
10147a6b8: 940d26f9    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
10147a6bc: a97ae3b7    	ldp	x23, x24, [x29, #-0x58]
10147a6c0: f85b83b9    	ldur	x25, [x29, #-0x48]
10147a6c4: a94107e0    	ldp	x0, x1, [sp, #0x10]
10147a6c8: b0004342    	adrp	x2, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10147a6cc: 910d7c42    	add	x2, x2, #0x35f
10147a6d0: d10163a8    	sub	x8, x29, #0x58
10147a6d4: 528000c3    	mov	w3, #0x6                ; =6
10147a6d8: 940d26f1    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
10147a6dc: 3cda83a0    	ldur	q0, [x29, #-0x58]
10147a6e0: 3d800a80    	str	q0, [x20, #0x20]
10147a6e4: f85b83a8    	ldur	x8, [x29, #-0x48]
10147a6e8: f9001a88    	str	x8, [x20, #0x30]
10147a6ec: a9006297    	stp	x23, x24, [x20]
10147a6f0: f9000a99    	str	x25, [x20, #0x10]
10147a6f4: 52800028    	mov	w8, #0x1                ; =1
10147a6f8: 39006288    	strb	w8, [x20, #0x18]
10147a6fc: 3900e29f    	strb	wzr, [x20, #0x38]
10147a700: 3cc083e0    	ldur	q0, [sp, #0x8]
10147a704: 3c8182c0    	stur	q0, [x22, #0x18]
10147a708: f9400fe8    	ldr	x8, [sp, #0x18]
10147a70c: 3dc00be0    	ldr	q0, [sp, #0x20]
10147a710: 3d8002c0    	str	q0, [x22]
10147a714: a94307e9    	ldp	x9, x1, [sp, #0x30]
10147a718: f9000ac9    	str	x9, [x22, #0x10]
10147a71c: 52800049    	mov	w9, #0x2                ; =2
10147a720: a902a6c8    	stp	x8, x9, [x22, #0x28]
10147a724: f9001ed4    	str	x20, [x22, #0x38]
10147a728: b0003468    	adrp	x8, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
10147a72c: 3dc35500    	ldr	q0, [x8, #0xd50]
10147a730: 3d8012c0    	str	q0, [x22, #0x40]
10147a734: b4000081    	cbz	x1, 0x10147a744 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x140>
10147a738: aa1503e0    	mov	x0, x21
10147a73c: 52800022    	mov	w2, #0x1                ; =1
10147a740: 97d88fe7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a744: f9402be1    	ldr	x1, [sp, #0x50]
10147a748: b4000141    	cbz	x1, 0x10147a770 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x16c>
10147a74c: aa1303e0    	mov	x0, x19
10147a750: 52800022    	mov	w2, #0x1                ; =1
10147a754: a94c7bfd    	ldp	x29, x30, [sp, #0xc0]
10147a758: a94b4ff4    	ldp	x20, x19, [sp, #0xb0]
10147a75c: a94a57f6    	ldp	x22, x21, [sp, #0xa0]
10147a760: a9495ff8    	ldp	x24, x23, [sp, #0x90]
10147a764: a94867fa    	ldp	x26, x25, [sp, #0x80]
10147a768: 910343ff    	add	sp, sp, #0xd0
10147a76c: 17d88fdc    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a770: a94c7bfd    	ldp	x29, x30, [sp, #0xc0]
10147a774: a94b4ff4    	ldp	x20, x19, [sp, #0xb0]
10147a778: a94a57f6    	ldp	x22, x21, [sp, #0xa0]
10147a77c: a9495ff8    	ldp	x24, x23, [sp, #0x90]
10147a780: a94867fa    	ldp	x26, x25, [sp, #0x80]
10147a784: 910343ff    	add	sp, sp, #0xd0
10147a788: d65f03c0    	ret
10147a78c: 52800100    	mov	w0, #0x8                ; =8
10147a790: 52800801    	mov	w1, #0x40               ; =64
10147a794: 941922ea    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
10147a798: d4200020    	brk	#0x1
10147a79c: aa0003f6    	mov	x22, x0
10147a7a0: b40000f7    	cbz	x23, 0x10147a7bc <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x1b8>
10147a7a4: aa1803e0    	mov	x0, x24
10147a7a8: aa1703e1    	mov	x1, x23
10147a7ac: 52800022    	mov	w2, #0x1                ; =1
10147a7b0: 97d88fcb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a7b4: 14000002    	b	0x10147a7bc <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x1b8>
10147a7b8: aa0003f6    	mov	x22, x0
10147a7bc: aa1403e0    	mov	x0, x20
10147a7c0: 52800801    	mov	w1, #0x40               ; =64
10147a7c4: 52800102    	mov	w2, #0x8                ; =8
10147a7c8: 97d88fc5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a7cc: f94013e1    	ldr	x1, [sp, #0x20]
10147a7d0: b50000c1    	cbnz	x1, 0x10147a7e8 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x1e4>
10147a7d4: f94007e1    	ldr	x1, [sp, #0x8]
10147a7d8: b5000121    	cbnz	x1, 0x10147a7fc <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x1f8>
10147a7dc: f9401fe1    	ldr	x1, [sp, #0x38]
10147a7e0: b5000181    	cbnz	x1, 0x10147a810 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x20c>
10147a7e4: 1400001c    	b	0x10147a854 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x250>
10147a7e8: f94017e0    	ldr	x0, [sp, #0x28]
10147a7ec: 52800022    	mov	w2, #0x1                ; =1
10147a7f0: 97d88fbb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a7f4: f94007e1    	ldr	x1, [sp, #0x8]
10147a7f8: b4ffff21    	cbz	x1, 0x10147a7dc <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x1d8>
10147a7fc: f9400be0    	ldr	x0, [sp, #0x10]
10147a800: 52800022    	mov	w2, #0x1                ; =1
10147a804: 97d88fb6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a808: f9401fe1    	ldr	x1, [sp, #0x38]
10147a80c: b4000241    	cbz	x1, 0x10147a854 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x250>
10147a810: aa1503e0    	mov	x0, x21
10147a814: 1400000e    	b	0x10147a84c <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x248>
10147a818: aa0003f6    	mov	x22, x0
10147a81c: aa1403e0    	mov	x0, x20
10147a820: 52800801    	mov	w1, #0x40               ; =64
10147a824: 52800102    	mov	w2, #0x8                ; =8
10147a828: 97d88fad    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a82c: f94013e1    	ldr	x1, [sp, #0x20]
10147a830: b4000081    	cbz	x1, 0x10147a840 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x23c>
10147a834: f94017e0    	ldr	x0, [sp, #0x28]
10147a838: 52800022    	mov	w2, #0x1                ; =1
10147a83c: 97d88fa8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a840: f94007e1    	ldr	x1, [sp, #0x8]
10147a844: b4000081    	cbz	x1, 0x10147a854 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x250>
10147a848: f9400be0    	ldr	x0, [sp, #0x10]
10147a84c: 52800022    	mov	w2, #0x1                ; =1
10147a850: 97d88fa3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a854: f9402be1    	ldr	x1, [sp, #0x50]
10147a858: b40002c1    	cbz	x1, 0x10147a8b0 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x2ac>
10147a85c: aa1303e0    	mov	x0, x19
10147a860: 14000012    	b	0x10147a8a8 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x2a4>
10147a864: aa0003f6    	mov	x22, x0
10147a868: aa1403e0    	mov	x0, x20
10147a86c: 52800801    	mov	w1, #0x40               ; =64
10147a870: 52800102    	mov	w2, #0x8                ; =8
10147a874: 97d88f9a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a878: 14000004    	b	0x10147a888 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x284>
10147a87c: aa0003f6    	mov	x22, x0
10147a880: 14000007    	b	0x10147a89c <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x298>
10147a884: aa0003f6    	mov	x22, x0
10147a888: f94013e1    	ldr	x1, [sp, #0x20]
10147a88c: b4000081    	cbz	x1, 0x10147a89c <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x298>
10147a890: f94017e0    	ldr	x0, [sp, #0x28]
10147a894: 52800022    	mov	w2, #0x1                ; =1
10147a898: 97d88f91    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a89c: f94007e1    	ldr	x1, [sp, #0x8]
10147a8a0: b4000081    	cbz	x1, 0x10147a8b0 <__ZN15otty_ssh_config4load6Loader3new17hd5cad8c6a11ed332E+0x2ac>
10147a8a4: f9400be0    	ldr	x0, [sp, #0x10]
10147a8a8: 52800022    	mov	w2, #0x1                ; =1
10147a8ac: 97d88f8c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147a8b0: aa1603e0    	mov	x0, x22
10147a8b4: 94193b48    	bl	0x101ac95d4 <_writev+0x101ac95d4>
