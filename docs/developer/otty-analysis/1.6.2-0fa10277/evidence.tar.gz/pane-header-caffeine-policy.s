10066aa10:     	stp	x26, x25, [sp, #-0x50]!
10066aa14:     	stp	x24, x23, [sp, #0x10]
10066aa18:     	stp	x22, x21, [sp, #0x20]
10066aa1c:     	stp	x20, x19, [sp, #0x30]
10066aa20:     	stp	x29, x30, [sp, #0x40]
10066aa24:     	add	x29, sp, #0x40
10066aa28:     	ldr	x20, [x20, #0x18]
10066aa2c:     	ldr	x8, [x20]
10066aa30:     	ldr	x8, [x8, #0x90]
10066aa34:     	blr	x8
10066aa38:     	mov	x19, x0
10066aa3c:     	mov	x22, x0
10066aa40:     	ldr	x8, [x22, #0x40]!
10066aa44:     	ldrb	w9, [x0, #0x20]
10066aa48:     	and	x10, x9, #0x3f
10066aa4c:     	mov	w11, #0x1               ; =1
10066aa50:     	lsl	x9, x11, x9
10066aa54:     	mov	x11, #-0x1              ; =-1
10066aa58:     	lsl	x12, x11, x9
10066aa5c:     	cmp	w10, #0x6
10066aa60:     	csinv	x10, x11, x12, hs
10066aa64:     	and	x25, x10, x8
10066aa68:     	add	x8, x9, #0x3f
10066aa6c:     	lsr	x23, x8, #6
10066aa70:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10066aa74:     	mov	x24, #0x0               ; =0
10066aa78:     	cbnz	x25, 0x10066aa94
10066aa7c:     	adds	x24, x24, #0x1
10066aa80:     	b.vs	0x10066ab30
10066aa84:     	cmp	x24, x23
10066aa88:     	b.ge	0x10066ab00
10066aa8c:     	ldr	x25, [x22, x24, lsl #3]
10066aa90:     	cbz	x25, 0x10066aa7c
10066aa94:     	rbit	x8, x25
10066aa98:     	clz	x8, x8
10066aa9c:     	sub	x9, x25, #0x1
10066aaa0:     	and	x25, x9, x25
10066aaa4:     	orr	x20, x8, x24, lsl #6
10066aaa8:     	ldr	x21, [x19, #0x38]
10066aaac:     	mov	x0, #0x0                ; =0
10066aab0:     	bl	0x10068c794
10066aab4:     	mov	x1, x0
10066aab8:     	ldur	x8, [x0, #-0x8]
10066aabc:     	ldr	x8, [x8, #0x48]
10066aac0:     	madd	x20, x8, x20, x21
10066aac4:     	mov	x0, x20
10066aac8:     	bl	0x101aca78c ; symbol _swift_getEnumCaseMultiPayload
10066aacc:     	cbnz	w0, 0x10066aa78
10066aad0:     	ldr	x20, [x20]
10066aad4:     	ldr	x8, [x20]
10066aad8:     	ldr	x21, [x8, #0x7b0]
10066aadc:     	mov	x0, x20
10066aae0:     	bl	0x101aca978 ; symbol _swift_retain
10066aae4:     	blr	x21
10066aae8:     	mov	x21, x0
10066aaec:     	mov	x0, x20
10066aaf0:     	bl	0x101aca960 ; symbol _swift_release
10066aaf4:     	tbz	w21, #0x0, 0x10066aa78
10066aaf8:     	mov	w20, #0x1               ; =1
10066aafc:     	b	0x10066ab04
10066ab00:     	mov	w20, #0x0               ; =0
10066ab04:     	mov	x0, x19
10066ab08:     	bl	0x101aca960 ; symbol _swift_release
10066ab0c:     	mov	x0, x19
10066ab10:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10066ab14:     	mov	x0, x20
10066ab18:     	ldp	x29, x30, [sp, #0x40]
10066ab1c:     	ldp	x20, x19, [sp, #0x30]
10066ab20:     	ldp	x22, x21, [sp, #0x20]
10066ab24:     	ldp	x24, x23, [sp, #0x10]
10066ab28:     	ldp	x26, x25, [sp], #0x50
10066ab2c:     	ret
10066ab30:     	brk	#0x1
10066ab34:     	sub	sp, sp, #0x40
10066ab38:     	stp	x20, x19, [sp, #0x20]
10066ab3c:     	stp	x29, x30, [sp, #0x30]
10066ab40:     	add	x29, sp, #0x30
10066ab44:     	adrp	x8, 0x1023da000
10066ab48:     	ldr	x19, [x8, #0x3b8]
10066ab4c:     	add	x0, x20, x19
10066ab50:     	add	x1, sp, #0x8
10066ab54:     	mov	x2, #0x0                ; =0
10066ab58:     	mov	x3, #0x0                ; =0
10066ab5c:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066ab60:     	ldrb	w0, [x20, x19]
10066ab64:     	ldp	x29, x30, [sp, #0x30]
10066ab68:     	ldp	x20, x19, [sp, #0x20]
10066ab6c:     	add	sp, sp, #0x40
10066ab70:     	ret
10066ab74:     	sub	sp, sp, #0x50
10066ab78:     	stp	x22, x21, [sp, #0x20]
10066ab7c:     	stp	x20, x19, [sp, #0x30]
10066ab80:     	stp	x29, x30, [sp, #0x40]
10066ab84:     	add	x29, sp, #0x40
10066ab88:     	mov	x19, x0
10066ab8c:     	adrp	x8, 0x1023da000
10066ab90:     	ldr	x21, [x8, #0x3b8]
10066ab94:     	add	x0, x20, x21
10066ab98:     	add	x1, sp, #0x8
10066ab9c:     	mov	w2, #0x1                ; =1
10066aba0:     	mov	x3, #0x0                ; =0
10066aba4:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066aba8:     	strb	w19, [x20, x21]
10066abac:     	ldp	x29, x30, [sp, #0x40]
10066abb0:     	ldp	x20, x19, [sp, #0x30]
10066abb4:     	ldp	x22, x21, [sp, #0x20]
10066abb8:     	add	sp, sp, #0x50
10066abbc:     	ret
10066abc0:     	stp	x20, x19, [sp, #-0x20]!
10066abc4:     	stp	x29, x30, [sp, #0x10]
10066abc8:     	add	x29, sp, #0x10
10066abcc:     	mov	x1, x0
10066abd0:     	adrp	x8, 0x1023da000
10066abd4:     	ldr	x19, [x8, #0x3b8]
10066abd8:     	add	x0, x20, x19
10066abdc:     	mov	w2, #0x21               ; =33
10066abe0:     	mov	x3, #0x0                ; =0
10066abe4:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066abe8:     	adrp	x0, 0x10002d000
10066abec:     	add	x0, x0, #0xd0c
10066abf0:     	add	x1, x20, x19
10066abf4:     	ldp	x29, x30, [sp, #0x10]
10066abf8:     	ldp	x20, x19, [sp], #0x20
10066abfc:     	ret
10066ac00:     	stp	x22, x21, [sp, #-0x30]!
10066ac04:     	stp	x20, x19, [sp, #0x10]
10066ac08:     	stp	x29, x30, [sp, #0x20]
10066ac0c:     	add	x29, sp, #0x20
10066ac10:     	mov	x19, x2
10066ac14:     	mov	x21, x1
10066ac18:     	mov	x22, x0
10066ac1c:     	ldr	w1, [x20, #0x30]
10066ac20:     	ldrh	w2, [x20, #0x34]
10066ac24:     	mov	x0, x20
10066ac28:     	bl	0x101aca588 ; symbol _swift_allocObject
10066ac2c:     	mov	x20, x0
10066ac30:     	mov	x0, x22
10066ac34:     	mov	x1, x21
10066ac38:     	mov	x2, x19
10066ac3c:     	bl	0x10066ac54
10066ac40:     	mov	x0, x20
10066ac44:     	ldp	x29, x30, [sp, #0x20]
10066ac48:     	ldp	x20, x19, [sp, #0x10]
10066ac4c:     	ldp	x22, x21, [sp], #0x30
10066ac50:     	ret
10066ac54:     	stp	x28, x27, [sp, #-0x60]!
10066ac58:     	stp	x26, x25, [sp, #0x10]
10066ac5c:     	stp	x24, x23, [sp, #0x20]
10066ac60:     	stp	x22, x21, [sp, #0x30]
10066ac64:     	stp	x20, x19, [sp, #0x40]
10066ac68:     	stp	x29, x30, [sp, #0x50]
10066ac6c:     	add	x29, sp, #0x50
10066ac70:     	sub	sp, sp, #0x1f0
10066ac74:     	mov	x19, x20
10066ac78:     	mov	x21, x2
10066ac7c:     	mov	x22, x1
10066ac80:     	mov	x23, x0
10066ac84:     	adrp	x8, 0x1023da000
10066ac88:     	ldr	x8, [x8, #0x2e0]
10066ac8c:     	add	x25, sp, #0x58
10066ac90:     	add	x8, x20, x8
10066ac94:     	bl	0x101ac4fcc ; symbol _$s10Foundation4DateVACycfC
10066ac98:     	adrp	x8, 0x1023a8000
10066ac9c:     	ldr	x20, [x8, #0x2c8]
10066aca0:     	mov	x0, #0x0                ; =0
10066aca4:     	bl	0x101ac4fd8 ; symbol _$s10Foundation4DateVMa
10066aca8:     	mov	x3, x0
10066acac:     	ldur	x8, [x0, #-0x8]
10066acb0:     	ldr	x8, [x8, #0x38]
10066acb4:     	mov	w24, #0x1               ; =1
10066acb8:     	add	x0, x19, x20
10066acbc:     	mov	w1, #0x1                ; =1
10066acc0:     	mov	w2, #0x1                ; =1
10066acc4:     	blr	x8
10066acc8:     	adrp	x8, 0x1023da000
10066accc:     	ldr	x8, [x8, #0x2e8]
10066acd0:     	add	x8, x19, x8
10066acd4:     	bl	0x101ac4fcc ; symbol _$s10Foundation4DateVACycfC
10066acd8:     	adrp	x8, 0x1023da000
10066acdc:     	ldr	x8, [x8, #0x2f0]
10066ace0:     	strb	wzr, [x19, x8]
10066ace4:     	adrp	x8, 0x1023da000
10066ace8:     	ldr	x8, [x8, #0x2f8]
10066acec:     	add	x26, x19, x8
10066acf0:     	mov	x0, #0x0                ; =0
10066acf4:     	bl	0x10064d3c8
10066acf8:     	mov	x20, x0
10066acfc:     	bl	0x1006472d0
10066ad00:     	stp	x0, x1, [x26]
10066ad04:     	adrp	x8, 0x1023da000
10066ad08:     	ldr	x8, [x8, #0x300]
10066ad0c:     	mov	w9, #0x5                ; =5
10066ad10:     	strb	w9, [x19, x8]
10066ad14:     	adrp	x8, 0x1023da000
10066ad18:     	ldr	x8, [x8, #0x308]
10066ad1c:     	add	x8, x19, x8
10066ad20:     	stp	xzr, xzr, [x8]
10066ad24:     	adrp	x8, 0x1023da000
10066ad28:     	ldr	x8, [x8, #0x310]
10066ad2c:     	add	x8, x19, x8
10066ad30:     	str	xzr, [x8]
10066ad34:     	strb	w24, [x8, #0x8]
10066ad38:     	adrp	x8, 0x1023da000
10066ad3c:     	ldr	x8, [x8, #0x318]
10066ad40:     	add	x20, x19, x8
10066ad44:     	add	x0, sp, #0x58
10066ad48:     	bl	0x1002a3178
10066ad4c:     	ldp	q0, q1, [x25, #0x90]
10066ad50:     	ldp	q3, q2, [x25, #0x70]
10066ad54:     	stp	q2, q0, [x20, #0x80]
10066ad58:     	str	q1, [x20, #0xa0]
10066ad5c:     	ldp	q0, q1, [x25, #0x50]
10066ad60:     	ldp	q4, q2, [x25, #0x30]
10066ad64:     	stp	q2, q0, [x20, #0x40]
10066ad68:     	ldr	x8, [sp, #0x108]
10066ad6c:     	str	x8, [x20, #0xb0]
10066ad70:     	stp	q1, q3, [x20, #0x60]
10066ad74:     	ldur	q0, [sp, #0x58]
10066ad78:     	ldur	q1, [sp, #0x68]
10066ad7c:     	stp	q0, q1, [x20]
10066ad80:     	ldur	q0, [sp, #0x78]
10066ad84:     	stp	q0, q4, [x20, #0x20]
10066ad88:     	adrp	x8, 0x1023da000
10066ad8c:     	ldr	x20, [x8, #0x320]
10066ad90:     	adrp	x0, 0x1022cf000
10066ad94:     	ldr	x0, [x0, #0x4a8]
10066ad98:     	bl	0x10068b73c
10066ad9c:     	str	x0, [x19, x20]
10066ada0:     	adrp	x8, 0x1023da000
10066ada4:     	ldr	x8, [x8, #0x328]
10066ada8:     	mov	w9, #0x7                ; =7
10066adac:     	strb	w9, [x19, x8]
10066adb0:     	adrp	x8, 0x1023da000
10066adb4:     	ldr	x8, [x8, #0x330]
10066adb8:     	str	xzr, [x19, x8]
10066adbc:     	adrp	x8, 0x1023da000
10066adc0:     	ldr	x8, [x8, #0x338]
10066adc4:     	strb	w9, [x19, x8]
10066adc8:     	adrp	x8, 0x1023da000
10066adcc:     	ldr	x8, [x8, #0x340]
10066add0:     	strb	wzr, [x19, x8]
10066add4:     	adrp	x8, 0x1023da000
10066add8:     	ldr	x8, [x8, #0x348]
10066addc:     	strb	w9, [x19, x8]
10066ade0:     	adrp	x8, 0x1023da000
10066ade4:     	ldr	x8, [x8, #0x350]
10066ade8:     	strb	wzr, [x19, x8]
10066adec:     	adrp	x8, 0x1023da000
10066adf0:     	ldr	x8, [x8, #0x358]
10066adf4:     	strb	wzr, [x19, x8]
10066adf8:     	adrp	x8, 0x1023da000
10066adfc:     	ldr	x8, [x8, #0x368]
10066ae00:     	add	x8, x19, x8
10066ae04:     	stp	xzr, xzr, [x8]
10066ae08:     	adrp	x8, 0x1023da000
10066ae0c:     	ldr	x8, [x8, #0x370]
10066ae10:     	strb	wzr, [x19, x8]
10066ae14:     	adrp	x8, 0x1023da000
10066ae18:     	ldr	x8, [x8, #0x378]
10066ae1c:     	add	x20, x19, x8
10066ae20:     	bl	0x100454b2c
10066ae24:     	ldp	q0, q1, [x0, #0x20]
10066ae28:     	ldp	q3, q2, [x0]
10066ae2c:     	stp	q0, q1, [sp, #0x130]
10066ae30:     	stp	q3, q2, [sp, #0x110]
10066ae34:     	ldp	q0, q1, [x0]
10066ae38:     	ldp	q2, q3, [x0, #0x20]
10066ae3c:     	stp	q2, q3, [x20, #0x20]
10066ae40:     	stp	q0, q1, [x20]
10066ae44:     	adrp	x8, 0x1023da000
10066ae48:     	ldr	x8, [x8, #0x380]
10066ae4c:     	add	x20, x19, x8
10066ae50:     	sub	x0, x29, #0xe8
10066ae54:     	bl	0x10068bf94
10066ae58:     	ldp	q0, q1, [x25, #0x160]
10066ae5c:     	stp	q0, q1, [x20, #0x60]
10066ae60:     	ldr	q0, [x25, #0x180]
10066ae64:     	str	q0, [x20, #0x80]
10066ae68:     	ldur	x8, [x29, #-0x58]
10066ae6c:     	str	x8, [x20, #0x90]
10066ae70:     	ldp	q0, q1, [x25, #0x120]
10066ae74:     	stp	q0, q1, [x20, #0x20]
10066ae78:     	ldp	q0, q1, [x25, #0x140]
10066ae7c:     	stp	q0, q1, [x20, #0x40]
10066ae80:     	ldp	q0, q1, [x25, #0x100]
10066ae84:     	stp	q0, q1, [x20]
10066ae88:     	adrp	x8, 0x1023da000
10066ae8c:     	ldr	x8, [x8, #0x388]
10066ae90:     	mov	x9, #-0x1               ; =-1
10066ae94:     	str	x9, [x19, x8]
10066ae98:     	adrp	x8, 0x1023a8000
10066ae9c:     	ldr	x8, [x8, #0x2d8]
10066aea0:     	str	xzr, [x19, x8]
10066aea4:     	adrp	x8, 0x1023a8000
10066aea8:     	ldr	x8, [x8, #0x2e0]
10066aeac:     	str	xzr, [x19, x8]
10066aeb0:     	adrp	x8, 0x1023a8000
10066aeb4:     	ldr	x8, [x8, #0x2e8]
10066aeb8:     	str	xzr, [x19, x8]
10066aebc:     	adrp	x8, 0x1023a8000
10066aec0:     	ldr	x8, [x8, #0x2f0]
10066aec4:     	adrp	x9, 0x1022cf000
10066aec8:     	ldr	x9, [x9, #0x4b8]
10066aecc:     	str	x9, [x19, x8]
10066aed0:     	adrp	x8, 0x1023a8000
10066aed4:     	ldr	x8, [x8, #0x2d0]
10066aed8:     	str	xzr, [x19, x8]
10066aedc:     	adrp	x8, 0x1023da000
10066aee0:     	ldr	x8, [x8, #0x390]
10066aee4:     	add	x8, x19, x8
10066aee8:     	movi.2d	v0, #0000000000000000
10066aeec:     	stp	q0, q0, [x8]
10066aef0:     	stp	q0, q0, [x8, #0x20]
10066aef4:     	str	q0, [x8, #0x40]
10066aef8:     	strb	wzr, [x8, #0x50]
10066aefc:     	adrp	x25, 0x1023da000
10066af00:     	ldr	x8, [x25, #0x398]
10066af04:     	strb	wzr, [x19, x8]
10066af08:     	adrp	x8, 0x1023da000
10066af0c:     	ldr	x8, [x8, #0x3a0]
10066af10:     	strb	wzr, [x19, x8]
10066af14:     	adrp	x20, 0x1023da000
10066af18:     	ldr	x8, [x20, #0x3a8]
10066af1c:     	strb	wzr, [x19, x8]
10066af20:     	adrp	x8, 0x1023a8000
10066af24:     	ldr	x8, [x8, #0x2f8]
10066af28:     	str	wzr, [x19, x8]
10066af2c:     	adrp	x8, 0x1023a8000
10066af30:     	ldr	x8, [x8, #0x300]
10066af34:     	str	wzr, [x19, x8]
10066af38:     	adrp	x8, 0x1023da000
10066af3c:     	ldr	x8, [x8, #0x3b0]
10066af40:     	strb	wzr, [x19, x8]
10066af44:     	adrp	x8, 0x1023da000
10066af48:     	ldr	x8, [x8, #0x3b8]
10066af4c:     	strb	wzr, [x19, x8]
10066af50:     	adrp	x8, 0x1023da000
10066af54:     	ldr	x8, [x8, #0x3c0]
10066af58:     	strb	wzr, [x19, x8]
10066af5c:     	adrp	x8, 0x1023da000
10066af60:     	ldr	x8, [x8, #0x3c8]
10066af64:     	add	x8, x19, x8
10066af68:     	mov	x9, #-0x2000000000000000 ; =-2305843009213693952
10066af6c:     	stp	xzr, x9, [x8]
10066af70:     	adrp	x8, 0x1023da000
10066af74:     	ldr	x8, [x8, #0x3d0]
10066af78:     	add	x8, x19, x8
10066af7c:     	stp	xzr, x9, [x8]
10066af80:     	adrp	x8, 0x1023da000
10066af84:     	ldr	x8, [x8, #0x3d8]
10066af88:     	add	x8, x19, x8
10066af8c:     	stp	xzr, x9, [x8]
10066af90:     	stp	x23, x22, [x19, #0x10]
10066af94:     	adrp	x8, 0x1023da000
10066af98:     	ldr	x8, [x8, #0x360]
10066af9c:     	str	x21, [x19, x8]
10066afa0:     	add	x0, sp, #0x110
10066afa4:     	add	x1, sp, #0x18
10066afa8:     	bl	0x10068bf58
10066afac:     	bl	0x10061d8dc
10066afb0:     	tbz	w0, #0x0, 0x10066afec
10066afb4:     	ldr	x21, [x25, #0x398]
10066afb8:     	add	x0, x19, x21
10066afbc:     	add	x1, sp, #0x18
10066afc0:     	mov	w2, #0x1                ; =1
10066afc4:     	mov	x3, #0x0                ; =0
10066afc8:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066afcc:     	strb	w24, [x19, x21]
10066afd0:     	ldr	x20, [x20, #0x3a8]
10066afd4:     	add	x0, x19, x20
10066afd8:     	mov	x1, sp
10066afdc:     	mov	w2, #0x1                ; =1
10066afe0:     	mov	x3, #0x0                ; =0
10066afe4:     	bl	0x101aca600 ; symbol _swift_beginAccess
10066afe8:     	strb	w24, [x19, x20]
10066afec:     	mov	x0, x19
10066aff0:     	add	sp, sp, #0x1f0
10066aff4:     	ldp	x29, x30, [sp, #0x50]
10066aff8:     	ldp	x20, x19, [sp, #0x40]
10066affc:     	ldp	x22, x21, [sp, #0x30]
10066b000:     	ldp	x24, x23, [sp, #0x20]
10066b004:     	ldp	x26, x25, [sp, #0x10]
10066b008:     	ldp	x28, x27, [sp], #0x60
10066b00c:     	ret
