10058bd3c:     	stp	x22, x21, [sp, #-0x30]!
10058bd40:     	stp	x20, x19, [sp, #0x10]
10058bd44:     	stp	x29, x30, [sp, #0x20]
10058bd48:     	add	x29, sp, #0x20
10058bd4c:     	ldp	x19, x21, [x20, #0x10]
10058bd50:     	ldp	x22, x20, [x20, #0x20]
10058bd54:     	mov	x0, #0x0                ; =0
10058bd58:     	bl	0x10058ff54
10058bd5c:     	mov	x4, x0
10058bd60:     	mov	x0, x19
10058bd64:     	mov	x1, x21
10058bd68:     	mov	x2, x22
10058bd6c:     	mov	x3, x20
10058bd70:     	mov	x20, x4
10058bd74:     	bl	0x10058cefc
10058bd78:     	ldp	x29, x30, [sp, #0x20]
10058bd7c:     	ldp	x20, x19, [sp, #0x10]
10058bd80:     	ldp	x22, x21, [sp], #0x30
10058bd84:     	ret
10058bd88:     	b	0x100588744
10058bd8c:     	b	0x100588744
10058bd90:     	b	0x10058829c
10058bd94:     	b	0x10058829c
10058bd98:     	b	0x10058829c
10058bd9c:     	b	0x10058829c
10058bda0:     	b	0x10058829c
10058bda4:     	b	0x10058829c
10058bda8:     	b	0x10058829c
10058bdac:     	b	0x10058829c
10058bdb0:     	b	0x10058829c
10058bdb4:     	b	0x10058829c
10058bdb8:     	b	0x10058829c
10058bdbc:     	b	0x10058829c
10058bdc0:     	b	0x10058829c
10058bdc4:     	b	0x10058829c
10058bdc8:     	b	0x1005882b0
10058bdcc:     	b	0x1005882b0
10058bdd0:     	b	0x1005882b0
10058bdd4:     	b	0x1005882b0
10058bdd8:     	b	0x1005882b0
10058bddc:     	b	0x1005882b0
10058bde0:     	b	0x1005882b0
10058bde4:     	b	0x1005882b0
10058bde8:     	b	0x1005882b0
10058bdec:     	b	0x1005882b0
10058bdf0:     	b	0x1005882b0
10058bdf4:     	b	0x1005882b0
10058bdf8:     	b	0x1005882b0
10058bdfc:     	b	0x1005882b0
10058be00:     	b	0x10058ab68
