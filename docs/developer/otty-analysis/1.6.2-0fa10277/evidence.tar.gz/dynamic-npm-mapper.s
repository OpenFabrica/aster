
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001013fdd28 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE>:
1013fe924: d10243ff    	sub	sp, sp, #0x90
1013fe928: a9055ff8    	stp	x24, x23, [sp, #0x50]
1013fe92c: a90657f6    	stp	x22, x21, [sp, #0x60]
1013fe930: a9074ff4    	stp	x20, x19, [sp, #0x70]
1013fe934: a9087bfd    	stp	x29, x30, [sp, #0x80]
1013fe938: 910203fd    	add	x29, sp, #0x80
1013fe93c: aa0103f5    	mov	x21, x1
1013fe940: aa0003f3    	mov	x19, x0
1013fe944: f9402436    	ldr	x22, [x1, #0x48]
1013fe948: aa0103e0    	mov	x0, x1
1013fe94c: 94000907    	bl	0x101400d68 <__ZN107_$LT$otty_autocomplete..fix..rules..CdCorrectionRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h8900cf03849afe93E+0x1108>
1013fe950: b40003a0    	cbz	x0, 0x1013fe9c4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xc9c>
1013fe954: aa0003f8    	mov	x24, x0
1013fe958: 14000005    	b	0x1013fe96c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xc44>
1013fe95c: aa1503e0    	mov	x0, x21
1013fe960: 94000902    	bl	0x101400d68 <__ZN107_$LT$otty_autocomplete..fix..rules..CdCorrectionRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h8900cf03849afe93E+0x1108>
1013fe964: aa0003f8    	mov	x24, x0
1013fe968: b40002e0    	cbz	x0, 0x1013fe9c4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xc9c>
1013fe96c: 39400028    	ldrb	w8, [x1]
1013fe970: 71000d1f    	cmp	w8, #0x3
1013fe974: 54ffff41    	b.ne	0x1013fe95c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xc34>
1013fe978: a9415037    	ldp	x23, x20, [x1, #0x10]
1013fe97c: a9408b01    	ldp	x1, x2, [x24, #0x8]
1013fe980: aa1603e0    	mov	x0, x22
1013fe984: 940040b2    	bl	0x10140ec4c <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E>
1013fe988: 3607fea0    	tbz	w0, #0x0, 0x1013fe95c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xc34>
1013fe98c: 910023e8    	add	x8, sp, #0x8
1013fe990: aa1803e0    	mov	x0, x24
1013fe994: 9410420e    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1013fe998: b40001d4    	cbz	x20, 0x1013fe9d0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xca8>
1013fe99c: 97da7f55    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1013fe9a0: aa1403e0    	mov	x0, x20
1013fe9a4: 52800021    	mov	w1, #0x1                ; =1
1013fe9a8: 97da7f4c    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1013fe9ac: aa0003f5    	mov	x21, x0
1013fe9b0: b5000120    	cbnz	x0, 0x1013fe9d4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xcac>
1013fe9b4: 52800020    	mov	w0, #0x1                ; =1
1013fe9b8: aa1403e1    	mov	x1, x20
1013fe9bc: 941b126e    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1013fe9c0: d4200020    	brk	#0x1
1013fe9c4: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013fe9c8: f9000268    	str	x8, [x19]
1013fe9cc: 1400001a    	b	0x1013fea34 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xd0c>
1013fe9d0: 52800035    	mov	w21, #0x1               ; =1
1013fe9d4: aa1503e0    	mov	x0, x21
1013fe9d8: aa1703e1    	mov	x1, x23
1013fe9dc: aa1403e2    	mov	x2, x20
1013fe9e0: 941b2c92    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1013fe9e4: 3cc083e0    	ldur	q0, [sp, #0x8]
1013fe9e8: 3d800be0    	str	q0, [sp, #0x20]
1013fe9ec: f9400fe8    	ldr	x8, [sp, #0x18]
1013fe9f0: f9001be8    	str	x8, [sp, #0x30]
1013fe9f4: 9100e3e8    	add	x8, sp, #0x38
1013fe9f8: 910083e0    	add	x0, sp, #0x20
1013fe9fc: 941041f4    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1013fea00: 3cc083e0    	ldur	q0, [sp, #0x8]
1013fea04: 3c818260    	stur	q0, [x19, #0x18]
1013fea08: f94027e8    	ldr	x8, [sp, #0x48]
1013fea0c: f9000a68    	str	x8, [x19, #0x10]
1013fea10: f9400fe8    	ldr	x8, [sp, #0x18]
1013fea14: 3cc383e0    	ldur	q0, [sp, #0x38]
1013fea18: 3d800260    	str	q0, [x19]
1013fea1c: a902d268    	stp	x8, x20, [x19, #0x28]
1013fea20: a903d275    	stp	x21, x20, [x19, #0x38]
1013fea24: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013fea28: f9002668    	str	x8, [x19, #0x48]
1013fea2c: 52804008    	mov	w8, #0x200              ; =512
1013fea30: 7900c268    	strh	w8, [x19, #0x60]
1013fea34: a9487bfd    	ldp	x29, x30, [sp, #0x80]
1013fea38: a9474ff4    	ldp	x20, x19, [sp, #0x70]
1013fea3c: a94657f6    	ldp	x22, x21, [sp, #0x60]
1013fea40: a9455ff8    	ldp	x24, x23, [sp, #0x50]
1013fea44: 910243ff    	add	sp, sp, #0x90
1013fea48: d65f03c0    	ret
1013fea4c: aa0003f3    	mov	x19, x0
1013fea50: f94007e1    	ldr	x1, [sp, #0x8]
1013fea54: b40001e1    	cbz	x1, 0x1013fea90 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xd68>
1013fea58: f9400be0    	ldr	x0, [sp, #0x10]
1013fea5c: 1400000b    	b	0x1013fea88 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xd60>
1013fea60: aa0003f3    	mov	x19, x0
1013fea64: f94013e1    	ldr	x1, [sp, #0x20]
1013fea68: b4000081    	cbz	x1, 0x1013fea78 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xd50>
1013fea6c: f94017e0    	ldr	x0, [sp, #0x28]
1013fea70: 52800022    	mov	w2, #0x1                ; =1
1013fea74: 97da7f1a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fea78: f240fa9f    	tst	x20, #0x7fffffffffffffff
1013fea7c: 540000a0    	b.eq	0x1013fea90 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xd68>
1013fea80: aa1503e0    	mov	x0, x21
1013fea84: aa1403e1    	mov	x1, x20
1013fea88: 52800022    	mov	w2, #0x1                ; =1
1013fea8c: 97da7f14    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013fea90: aa1303e0    	mov	x0, x19
1013fea94: 941b2ad0    	bl	0x101ac95d4 <_writev+0x101ac95d4>
