
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001013fdd28 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE>:
1013ff0fc: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
1013ff100: a90167fa    	stp	x26, x25, [sp, #0x10]
1013ff104: a9025ff8    	stp	x24, x23, [sp, #0x20]
1013ff108: a90357f6    	stp	x22, x21, [sp, #0x30]
1013ff10c: a9044ff4    	stp	x20, x19, [sp, #0x40]
1013ff110: a9057bfd    	stp	x29, x30, [sp, #0x50]
1013ff114: 910143fd    	add	x29, sp, #0x50
1013ff118: d132c3ff    	sub	sp, sp, #0xcb0
1013ff11c: f90003ff    	str	xzr, [sp]
1013ff120: f9443028    	ldr	x8, [x1, #0x860]
1013ff124: b4001aa8    	cbz	x8, 0x1013ff478 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1750>
1013ff128: aa0103f5    	mov	x21, x1
1013ff12c: 39616028    	ldrb	w8, [x1, #0x858]
1013ff130: 7100091f    	cmp	w8, #0x2
1013ff134: 54001a20    	b.eq	0x1013ff478 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1750>
1013ff138: f94436a8    	ldr	x8, [x21, #0x868]
1013ff13c: a90023e0    	stp	x0, x8, [sp]
1013ff140: 912142b6    	add	x22, x21, #0x850
1013ff144: 910043e8    	add	x8, sp, #0x10
1013ff148: aa1603e0    	mov	x0, x22
1013ff14c: 940faa91    	bl	0x1017e9b90 <__ZN75_$LT$std..fs..ReadDir$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h8142713fd293396eE>
1013ff150: b94013e8    	ldr	w8, [sp, #0x10]
1013ff154: 7100051f    	cmp	w8, #0x1
1013ff158: 54001741    	b.ne	0x1013ff440 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1718>
1013ff15c: 14000008    	b	0x1013ff17c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1454>
1013ff160: eb1802ff    	cmp	x23, x24
1013ff164: 540019e1    	b.ne	0x1013ff4a0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1778>
1013ff168: 910043e8    	add	x8, sp, #0x10
1013ff16c: aa1603e0    	mov	x0, x22
1013ff170: 940faa88    	bl	0x1017e9b90 <__ZN75_$LT$std..fs..ReadDir$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h8142713fd293396eE>
1013ff174: b94013e8    	ldr	w8, [sp, #0x10]
1013ff178: 36001648    	tbz	w8, #0x0, 0x1013ff440 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1718>
1013ff17c: a941dff8    	ldp	x24, x23, [sp, #0x18]
1013ff180: b40005b8    	cbz	x24, 0x1013ff234 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x150c>
1013ff184: f90223f7    	str	x23, [sp, #0x440]
1013ff188: 9110e3e8    	add	x8, sp, #0x438
1013ff18c: 91004100    	add	x0, x8, #0x10
1013ff190: 910043f9    	add	x25, sp, #0x10
1013ff194: 91006321    	add	x1, x25, #0x18
1013ff198: 52808202    	mov	w2, #0x410              ; =1040
1013ff19c: 941b2aa3    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1013ff1a0: f9021fff    	str	xzr, [sp, #0x438]
1013ff1a4: f90433f7    	str	x23, [sp, #0x860]
1013ff1a8: 912163e8    	add	x8, sp, #0x858
1013ff1ac: 91004100    	add	x0, x8, #0x10
1013ff1b0: 91006321    	add	x1, x25, #0x18
1013ff1b4: 52808202    	mov	w2, #0x410              ; =1040
1013ff1b8: 941b2a9c    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1013ff1bc: f94432a8    	ldr	x8, [x21, #0x860]
1013ff1c0: d1000508    	sub	x8, x8, #0x1
1013ff1c4: f90432a8    	str	x8, [x21, #0x860]
1013ff1c8: f9042ff8    	str	x24, [sp, #0x858]
1013ff1cc: d10223a8    	sub	x8, x29, #0x88
1013ff1d0: 912163e0    	add	x0, sp, #0x858
1013ff1d4: 940ec8f8    	bl	0x1017b15b4 <__ZN3std2fs8DirEntry9file_name17h6382942abec15980E>
1013ff1d8: a977e7b8    	ldp	x24, x25, [x29, #-0x88]
1013ff1dc: f85883bb    	ldur	x27, [x29, #-0x78]
1013ff1e0: d101c3a8    	sub	x8, x29, #0x70
1013ff1e4: aa1903e0    	mov	x0, x25
1013ff1e8: aa1b03e1    	mov	x1, x27
1013ff1ec: 941096b3    	bl	0x101824cb8 <__ZN4core3str8converts9from_utf817ha54c467cc832e2ffE>
1013ff1f0: b85903a8    	ldur	w8, [x29, #-0x70]
1013ff1f4: 360000e8    	tbz	w8, #0x0, 0x1013ff210 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x14e8>
1013ff1f8: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013ff1fc: eb08031f    	cmp	x24, x8
1013ff200: 54000401    	b.ne	0x1013ff280 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1558>
1013ff204: aa1903f8    	mov	x24, x25
1013ff208: aa1b03f9    	mov	x25, x27
1013ff20c: f85983bb    	ldur	x27, [x29, #-0x68]
1013ff210: f9442fe8    	ldr	x8, [sp, #0x858]
1013ff214: 92800009    	mov	x9, #-0x1               ; =-1
1013ff218: f8690108    	ldaddl	x9, x8, [x8]
1013ff21c: f100051f    	cmp	x8, #0x1
1013ff220: 54000461    	b.ne	0x1013ff2ac <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1584>
1013ff224: d50339bf    	dmb	ishld
1013ff228: 912163e0    	add	x0, sp, #0x858
1013ff22c: 940f7558    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013ff230: 1400001f    	b	0x1013ff2ac <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1584>
1013ff234: 924006e8    	and	x8, x23, #0x3
1013ff238: f100051f    	cmp	x8, #0x1
1013ff23c: 54fff961    	b.ne	0x1013ff168 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1440>
1013ff240: f85ffef8    	ldr	x24, [x23, #-0x1]!
1013ff244: f94006f9    	ldr	x25, [x23, #0x8]
1013ff248: f9400328    	ldr	x8, [x25]
1013ff24c: b4000068    	cbz	x8, 0x1013ff258 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1530>
1013ff250: aa1803e0    	mov	x0, x24
1013ff254: d63f0100    	blr	x8
1013ff258: f9400721    	ldr	x1, [x25, #0x8]
1013ff25c: b4000081    	cbz	x1, 0x1013ff26c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1544>
1013ff260: f9400b22    	ldr	x2, [x25, #0x10]
1013ff264: aa1803e0    	mov	x0, x24
1013ff268: 97da7d1d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff26c: aa1703e0    	mov	x0, x23
1013ff270: 52800301    	mov	w1, #0x18               ; =24
1013ff274: 52800102    	mov	w2, #0x8                ; =8
1013ff278: 97da7d19    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff27c: 17ffffbb    	b	0x1013ff168 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1440>
1013ff280: b40000b8    	cbz	x24, 0x1013ff294 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x156c>
1013ff284: aa1903e0    	mov	x0, x25
1013ff288: aa1803e1    	mov	x1, x24
1013ff28c: 52800022    	mov	w2, #0x1                ; =1
1013ff290: 97da7d13    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff294: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
1013ff298: f9442fe8    	ldr	x8, [sp, #0x858]
1013ff29c: 92800009    	mov	x9, #-0x1               ; =-1
1013ff2a0: f8690108    	ldaddl	x9, x8, [x8]
1013ff2a4: f100051f    	cmp	x8, #0x1
1013ff2a8: 54fffbe0    	b.eq	0x1013ff224 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x14fc>
1013ff2ac: d2f0001a    	mov	x26, #-0x8000000000000000 ; =-9223372036854775808
1013ff2b0: eb1a031f    	cmp	x24, x26
1013ff2b4: 540006e0    	b.eq	0x1013ff390 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1668>
1013ff2b8: b400015b    	cbz	x27, 0x1013ff2e0 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x15b8>
1013ff2bc: 39400328    	ldrb	w8, [x25]
1013ff2c0: 7100b91f    	cmp	w8, #0x2e
1013ff2c4: 540001c1    	b.ne	0x1013ff2fc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x15d4>
1013ff2c8: b4000658    	cbz	x24, 0x1013ff390 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1668>
1013ff2cc: aa1903e0    	mov	x0, x25
1013ff2d0: aa1803e1    	mov	x1, x24
1013ff2d4: 52800022    	mov	w2, #0x1                ; =1
1013ff2d8: 97da7d01    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff2dc: 1400002d    	b	0x1013ff390 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1668>
1013ff2e0: d2800009    	mov	x9, #0x0                ; =0
1013ff2e4: 92800048    	mov	x8, #-0x3               ; =-3
1013ff2e8: f100013f    	cmp	x9, #0x0
1013ff2ec: 9a89033a    	csel	x26, x25, x9, eq
1013ff2f0: 9a88037c    	csel	x28, x27, x8, eq
1013ff2f4: b500013c    	cbnz	x28, 0x1013ff318 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x15f0>
1013ff2f8: 1400004b    	b	0x1013ff424 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x16fc>
1013ff2fc: f1000f68    	subs	x8, x27, #0x3
1013ff300: 54000722    	b.hs	0x1013ff3e4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x16bc>
1013ff304: d2800009    	mov	x9, #0x0                ; =0
1013ff308: f100013f    	cmp	x9, #0x0
1013ff30c: 9a89033a    	csel	x26, x25, x9, eq
1013ff310: 9a88037c    	csel	x28, x27, x8, eq
1013ff314: b400089c    	cbz	x28, 0x1013ff424 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x16fc>
1013ff318: 97da7cf6    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1013ff31c: aa1c03e0    	mov	x0, x28
1013ff320: 52800021    	mov	w1, #0x1                ; =1
1013ff324: 97da7ced    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1013ff328: aa0003f7    	mov	x23, x0
1013ff32c: b4001020    	cbz	x0, 0x1013ff530 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1808>
1013ff330: aa1703e0    	mov	x0, x23
1013ff334: aa1a03e1    	mov	x1, x26
1013ff338: aa1c03e2    	mov	x2, x28
1013ff33c: 941b2a3b    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1013ff340: b40000b8    	cbz	x24, 0x1013ff354 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x162c>
1013ff344: aa1903e0    	mov	x0, x25
1013ff348: aa1803e1    	mov	x1, x24
1013ff34c: 52800022    	mov	w2, #0x1                ; =1
1013ff350: 97da7ce3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff354: f94007e0    	ldr	x0, [sp, #0x8]
1013ff358: aa1703e1    	mov	x1, x23
1013ff35c: aa1c03e2    	mov	x2, x28
1013ff360: 94003e3b    	bl	0x10140ec4c <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E>
1013ff364: f100039f    	cmp	x28, #0x0
1013ff368: 1a9f1408    	csinc	w8, w0, wzr, ne
1013ff36c: 7100001f    	cmp	w0, #0x0
1013ff370: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1013ff374: 9a89139a    	csel	x26, x28, x9, ne
1013ff378: 370000c8    	tbnz	w8, #0x0, 0x1013ff390 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1668>
1013ff37c: aa1703e0    	mov	x0, x23
1013ff380: aa1c03e1    	mov	x1, x28
1013ff384: 52800022    	mov	w2, #0x1                ; =1
1013ff388: 97da7cd5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff38c: d2f0001a    	mov	x26, #-0x8000000000000000 ; =-9223372036854775808
1013ff390: f94432a8    	ldr	x8, [x21, #0x860]
1013ff394: f100011f    	cmp	x8, #0x0
1013ff398: 1a9f07e8    	cset	w8, ne
1013ff39c: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1013ff3a0: eb09035f    	cmp	x26, x9
1013ff3a4: 1a9f17e9    	cset	w9, eq
1013ff3a8: 6a08013f    	tst	w9, w8
1013ff3ac: 9a9c1273    	csel	x19, x19, x28, ne
1013ff3b0: 9a971294    	csel	x20, x20, x23, ne
1013ff3b4: b24107f8    	mov	x24, #-0x7fffffffffffffff ; =-9223372036854775807
1013ff3b8: 9a9a1317    	csel	x23, x24, x26, ne
1013ff3bc: f9421fe8    	ldr	x8, [sp, #0x438]
1013ff3c0: b4ffed08    	cbz	x8, 0x1013ff160 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1438>
1013ff3c4: 92800009    	mov	x9, #-0x1               ; =-1
1013ff3c8: f8690108    	ldaddl	x9, x8, [x8]
1013ff3cc: f100051f    	cmp	x8, #0x1
1013ff3d0: 54ffec81    	b.ne	0x1013ff160 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1438>
1013ff3d4: d50339bf    	dmb	ishld
1013ff3d8: 9110e3e0    	add	x0, sp, #0x438
1013ff3dc: 940f74ec    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013ff3e0: 17ffff60    	b	0x1013ff160 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1438>
1013ff3e4: 8b080329    	add	x9, x25, x8
1013ff3e8: 3940092a    	ldrb	w10, [x9, #0x2]
1013ff3ec: 79400129    	ldrh	w9, [x9]
1013ff3f0: 2a0a4129    	orr	w9, w9, w10, lsl #16
1013ff3f4: 5ac00929    	rev	w9, w9
1013ff3f8: 528e600a    	mov	w10, #0x7300            ; =29440
1013ff3fc: 72a5ce4a    	movk	w10, #0x2e72, lsl #16
1013ff400: 6b09015f    	cmp	w10, w9
1013ff404: 1a9f97e9    	cset	w9, hi
1013ff408: 5a9f2129    	csinv	w9, w9, wzr, hs
1013ff40c: 7100013f    	cmp	w9, #0x0
1013ff410: 9a9f0329    	csel	x9, x25, xzr, eq
1013ff414: f100013f    	cmp	x9, #0x0
1013ff418: 9a89033a    	csel	x26, x25, x9, eq
1013ff41c: 9a88037c    	csel	x28, x27, x8, eq
1013ff420: b5fff7dc    	cbnz	x28, 0x1013ff318 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x15f0>
1013ff424: 52800037    	mov	w23, #0x1               ; =1
1013ff428: aa1703e0    	mov	x0, x23
1013ff42c: aa1a03e1    	mov	x1, x26
1013ff430: aa1c03e2    	mov	x2, x28
1013ff434: 941b29fd    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1013ff438: b5fff878    	cbnz	x24, 0x1013ff344 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x161c>
1013ff43c: 17ffffc6    	b	0x1013ff354 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x162c>
1013ff440: 396162a8    	ldrb	w8, [x21, #0x858]
1013ff444: 7100091f    	cmp	w8, #0x2
1013ff448: 54000120    	b.eq	0x1013ff46c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1744>
1013ff44c: f94002c8    	ldr	x8, [x22]
1013ff450: 92800009    	mov	x9, #-0x1               ; =-1
1013ff454: f8690108    	ldaddl	x9, x8, [x8]
1013ff458: f100051f    	cmp	x8, #0x1
1013ff45c: 54000081    	b.ne	0x1013ff46c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1744>
1013ff460: d50339bf    	dmb	ishld
1013ff464: aa1603e0    	mov	x0, x22
1013ff468: 940f74c9    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013ff46c: 52800048    	mov	w8, #0x2                ; =2
1013ff470: 392162a8    	strb	w8, [x21, #0x858]
1013ff474: f94003e0    	ldr	x0, [sp]
1013ff478: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013ff47c: f9000008    	str	x8, [x0]
1013ff480: 9132c3ff    	add	sp, sp, #0xcb0
1013ff484: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1013ff488: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1013ff48c: a94357f6    	ldp	x22, x21, [sp, #0x30]
1013ff490: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1013ff494: a94167fa    	ldp	x26, x25, [sp, #0x10]
1013ff498: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1013ff49c: d65f03c0    	ret
1013ff4a0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013ff4a4: eb0802ff    	cmp	x23, x8
1013ff4a8: f94003e0    	ldr	x0, [sp]
1013ff4ac: 54fffe60    	b.eq	0x1013ff478 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1750>
1013ff4b0: aa0003f6    	mov	x22, x0
1013ff4b4: 97da7c8f    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1013ff4b8: 528000e0    	mov	w0, #0x7                ; =7
1013ff4bc: 52800021    	mov	w1, #0x1                ; =1
1013ff4c0: 97da7c86    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1013ff4c4: b40003e0    	cbz	x0, 0x1013ff540 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1818>
1013ff4c8: aa0003f5    	mov	x21, x0
1013ff4cc: 528e0da8    	mov	w8, #0x706d             ; =28781
1013ff4d0: 72acad88    	movk	w8, #0x656c, lsl #16
1013ff4d4: b8003008    	stur	w8, [x0, #0x3]
1013ff4d8: 528f0ca8    	mov	w8, #0x7865             ; =30821
1013ff4dc: 72adac28    	movk	w8, #0x6d61, lsl #16
1013ff4e0: b9000008    	str	w8, [x0]
1013ff4e4: f9042ffa    	str	x26, [sp, #0x858]
1013ff4e8: f90433f4    	str	x20, [sp, #0x860]
1013ff4ec: f90437f3    	str	x19, [sp, #0x868]
1013ff4f0: 910043e8    	add	x8, sp, #0x10
1013ff4f4: 912163e0    	add	x0, sp, #0x858
1013ff4f8: 94103f35    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1013ff4fc: 3dc007e0    	ldr	q0, [sp, #0x10]
1013ff500: f94013e8    	ldr	x8, [sp, #0x20]
1013ff504: 3d8002c0    	str	q0, [x22]
1013ff508: a9016ac8    	stp	x8, x26, [x22, #0x10]
1013ff50c: a9024ed4    	stp	x20, x19, [x22, #0x20]
1013ff510: 528000e8    	mov	w8, #0x7                ; =7
1013ff514: a90356c8    	stp	x8, x21, [x22, #0x30]
1013ff518: 90004708    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1013ff51c: 3dc0d900    	ldr	q0, [x8, #0x360]
1013ff520: 3d8012c0    	str	q0, [x22, #0x40]
1013ff524: 52804008    	mov	w8, #0x200              ; =512
1013ff528: 7900c2c8    	strh	w8, [x22, #0x60]
1013ff52c: 17ffffd5    	b	0x1013ff480 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1758>
1013ff530: 52800020    	mov	w0, #0x1                ; =1
1013ff534: aa1c03e1    	mov	x1, x28
1013ff538: 941b0f8f    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1013ff53c: 14000004    	b	0x1013ff54c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1824>
1013ff540: 52800020    	mov	w0, #0x1                ; =1
1013ff544: 528000e1    	mov	w1, #0x7                ; =7
1013ff548: 941b0f8b    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1013ff54c: d4200020    	brk	#0x1
1013ff550: aa0003f3    	mov	x19, x0
1013ff554: b40000ba    	cbz	x26, 0x1013ff568 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1840>
1013ff558: aa1403e0    	mov	x0, x20
1013ff55c: aa1a03e1    	mov	x1, x26
1013ff560: 52800022    	mov	w2, #0x1                ; =1
1013ff564: 97da7c5e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff568: aa1503e0    	mov	x0, x21
1013ff56c: 528000e1    	mov	w1, #0x7                ; =7
1013ff570: 52800022    	mov	w2, #0x1                ; =1
1013ff574: 97da7c5a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff578: aa1303e0    	mov	x0, x19
1013ff57c: 941b2816    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013ff580: aa0003f3    	mov	x19, x0
1013ff584: b40007ba    	cbz	x26, 0x1013ff678 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1950>
1013ff588: aa1403e0    	mov	x0, x20
1013ff58c: aa1a03e1    	mov	x1, x26
1013ff590: 52800022    	mov	w2, #0x1                ; =1
1013ff594: 97da7c52    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff598: aa1303e0    	mov	x0, x19
1013ff59c: 941b280e    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013ff5a0: 52800048    	mov	w8, #0x2                ; =2
1013ff5a4: 392162a8    	strb	w8, [x21, #0x858]
1013ff5a8: 941b280b    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013ff5ac: aa0003f3    	mov	x19, x0
1013ff5b0: f9400721    	ldr	x1, [x25, #0x8]
1013ff5b4: b4000081    	cbz	x1, 0x1013ff5c4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x189c>
1013ff5b8: f9400b22    	ldr	x2, [x25, #0x10]
1013ff5bc: aa1803e0    	mov	x0, x24
1013ff5c0: 97da7c47    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff5c4: aa1703e0    	mov	x0, x23
1013ff5c8: 52800301    	mov	w1, #0x18               ; =24
1013ff5cc: 52800102    	mov	w2, #0x8                ; =8
1013ff5d0: 97da7c43    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff5d4: aa1303e0    	mov	x0, x19
1013ff5d8: 941b27ff    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013ff5dc: aa0003f3    	mov	x19, x0
1013ff5e0: b40003b8    	cbz	x24, 0x1013ff654 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x192c>
1013ff5e4: aa1903e0    	mov	x0, x25
1013ff5e8: aa1803e1    	mov	x1, x24
1013ff5ec: 14000005    	b	0x1013ff600 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x18d8>
1013ff5f0: aa0003f3    	mov	x19, x0
1013ff5f4: b400031c    	cbz	x28, 0x1013ff654 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x192c>
1013ff5f8: aa1703e0    	mov	x0, x23
1013ff5fc: aa1c03e1    	mov	x1, x28
1013ff600: 52800022    	mov	w2, #0x1                ; =1
1013ff604: 97da7c36    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff608: 14000013    	b	0x1013ff654 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x192c>
1013ff60c: aa0003f3    	mov	x19, x0
1013ff610: 14000011    	b	0x1013ff654 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x192c>
1013ff614: aa0003f3    	mov	x19, x0
1013ff618: b40000f8    	cbz	x24, 0x1013ff634 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x190c>
1013ff61c: aa1903e0    	mov	x0, x25
1013ff620: aa1803e1    	mov	x1, x24
1013ff624: 52800022    	mov	w2, #0x1                ; =1
1013ff628: 97da7c2d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff62c: 14000002    	b	0x1013ff634 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x190c>
1013ff630: aa0003f3    	mov	x19, x0
1013ff634: f9442fe8    	ldr	x8, [sp, #0x858]
1013ff638: 92800009    	mov	x9, #-0x1               ; =-1
1013ff63c: f8690108    	ldaddl	x9, x8, [x8]
1013ff640: f100051f    	cmp	x8, #0x1
1013ff644: 54000081    	b.ne	0x1013ff654 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x192c>
1013ff648: d50339bf    	dmb	ishld
1013ff64c: 912163e0    	add	x0, sp, #0x858
1013ff650: 940f744f    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013ff654: f9421fe8    	ldr	x8, [sp, #0x438]
1013ff658: b4000108    	cbz	x8, 0x1013ff678 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1950>
1013ff65c: 92800009    	mov	x9, #-0x1               ; =-1
1013ff660: f8690108    	ldaddl	x9, x8, [x8]
1013ff664: f100051f    	cmp	x8, #0x1
1013ff668: 54000081    	b.ne	0x1013ff678 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1950>
1013ff66c: d50339bf    	dmb	ishld
1013ff670: 9110e3e0    	add	x0, sp, #0x438
1013ff674: 940f7446    	bl	0x1017dc78c <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17h9408959318c88c03E>
1013ff678: aa1303e0    	mov	x0, x19
1013ff67c: 941b27d6    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013ff680: 941b11a9    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1013ff684: 941b11a8    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1013ff688: d10243ff    	sub	sp, sp, #0x90
1013ff68c: a9036ffc    	stp	x28, x27, [sp, #0x30]
1013ff690: a90467fa    	stp	x26, x25, [sp, #0x40]
1013ff694: a9055ff8    	stp	x24, x23, [sp, #0x50]
1013ff698: a90657f6    	stp	x22, x21, [sp, #0x60]
1013ff69c: a9074ff4    	stp	x20, x19, [sp, #0x70]
1013ff6a0: a9087bfd    	stp	x29, x30, [sp, #0x80]
1013ff6a4: 910203fd    	add	x29, sp, #0x80
1013ff6a8: aa0003f4    	mov	x20, x0
1013ff6ac: f9400c39    	ldr	x25, [x1, #0x18]
1013ff6b0: f940043a    	ldr	x26, [x1, #0x8]
1013ff6b4: eb19035f    	cmp	x26, x25
1013ff6b8: 54000300    	b.eq	0x1013ff718 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19f0>
1013ff6bc: aa0103f7    	mov	x23, x1
1013ff6c0: f9401038    	ldr	x24, [x1, #0x20]
1013ff6c4: d2f0001b    	mov	x27, #-0x8000000000000000 ; =-9223372036854775808
1013ff6c8: 14000005    	b	0x1013ff6dc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19b4>
1013ff6cc: eb1b027f    	cmp	x19, x27
1013ff6d0: 540002a1    	b.ne	0x1013ff724 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19fc>
1013ff6d4: eb19035f    	cmp	x26, x25
1013ff6d8: 54000200    	b.eq	0x1013ff718 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19f0>
1013ff6dc: a9405753    	ldp	x19, x21, [x26]
1013ff6e0: f9400b56    	ldr	x22, [x26, #0x10]
1013ff6e4: 9100635a    	add	x26, x26, #0x18
1013ff6e8: f90006fa    	str	x26, [x23, #0x8]
1013ff6ec: aa1803e0    	mov	x0, x24
1013ff6f0: aa1503e1    	mov	x1, x21
1013ff6f4: aa1603e2    	mov	x2, x22
1013ff6f8: 94003d55    	bl	0x10140ec4c <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E>
1013ff6fc: 3707fe80    	tbnz	w0, #0x0, 0x1013ff6cc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19a4>
1013ff700: b4fffeb3    	cbz	x19, 0x1013ff6d4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19ac>
1013ff704: aa1503e0    	mov	x0, x21
1013ff708: aa1303e1    	mov	x1, x19
1013ff70c: 52800022    	mov	w2, #0x1                ; =1
1013ff710: 97da7bf3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff714: 17fffff0    	b	0x1013ff6d4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x19ac>
1013ff718: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013ff71c: f9000288    	str	x8, [x20]
1013ff720: 1400001d    	b	0x1013ff794 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1a6c>
1013ff724: 97da7bf3    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1013ff728: 528000c0    	mov	w0, #0x6                ; =6
1013ff72c: 52800021    	mov	w1, #0x1                ; =1
1013ff730: 97da7bea    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1013ff734: b4000400    	cbz	x0, 0x1013ff7b4 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1a8c>
1013ff738: aa0003f7    	mov	x23, x0
1013ff73c: 528e8ca8    	mov	w8, #0x7465             ; =29797
1013ff740: 79000808    	strh	w8, [x0, #0x4]
1013ff744: 528c2e88    	mov	w8, #0x6174             ; =24948
1013ff748: 72acee48    	movk	w8, #0x6772, lsl #16
1013ff74c: b9000008    	str	w8, [x0]
1013ff750: a90057f3    	stp	x19, x21, [sp]
1013ff754: f9000bf6    	str	x22, [sp, #0x10]
1013ff758: 910063e8    	add	x8, sp, #0x18
1013ff75c: 910003e0    	mov	x0, sp
1013ff760: 94103e9b    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1013ff764: 3cc183e0    	ldur	q0, [sp, #0x18]
1013ff768: f94017e8    	ldr	x8, [sp, #0x28]
1013ff76c: 3d800280    	str	q0, [x20]
1013ff770: a9014e88    	stp	x8, x19, [x20, #0x10]
1013ff774: a9025a95    	stp	x21, x22, [x20, #0x20]
1013ff778: 528000c8    	mov	w8, #0x6                ; =6
1013ff77c: a9035e88    	stp	x8, x23, [x20, #0x30]
1013ff780: f00043e8    	adrp	x8, 0x101c7e000 <__ZN16curve25519_dalek9constants23X25519_LOW_ORDER_POINTS17h489881f202cbb08bE+0x48>
1013ff784: 3dc23100    	ldr	q0, [x8, #0x8c0]
1013ff788: 3d801280    	str	q0, [x20, #0x40]
1013ff78c: 52804008    	mov	w8, #0x200              ; =512
1013ff790: 7900c288    	strh	w8, [x20, #0x60]
1013ff794: a9487bfd    	ldp	x29, x30, [sp, #0x80]
1013ff798: a9474ff4    	ldp	x20, x19, [sp, #0x70]
1013ff79c: a94657f6    	ldp	x22, x21, [sp, #0x60]
1013ff7a0: a9455ff8    	ldp	x24, x23, [sp, #0x50]
1013ff7a4: a94467fa    	ldp	x26, x25, [sp, #0x40]
1013ff7a8: a9436ffc    	ldp	x28, x27, [sp, #0x30]
1013ff7ac: 910243ff    	add	sp, sp, #0x90
1013ff7b0: d65f03c0    	ret
1013ff7b4: 52800020    	mov	w0, #0x1                ; =1
1013ff7b8: 528000c1    	mov	w1, #0x6                ; =6
1013ff7bc: 941b0eee    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1013ff7c0: d4200020    	brk	#0x1
1013ff7c4: aa0003f4    	mov	x20, x0
1013ff7c8: b40000b3    	cbz	x19, 0x1013ff7dc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1ab4>
1013ff7cc: aa1503e0    	mov	x0, x21
1013ff7d0: aa1303e1    	mov	x1, x19
1013ff7d4: 52800022    	mov	w2, #0x1                ; =1
1013ff7d8: 97da7bc1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff7dc: aa1703e0    	mov	x0, x23
1013ff7e0: 528000c1    	mov	w1, #0x6                ; =6
1013ff7e4: 14000006    	b	0x1013ff7fc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1ad4>
1013ff7e8: 14000001    	b	0x1013ff7ec <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1ac4>
1013ff7ec: aa0003f4    	mov	x20, x0
1013ff7f0: b40000b3    	cbz	x19, 0x1013ff804 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1adc>
1013ff7f4: aa1503e0    	mov	x0, x21
1013ff7f8: aa1303e1    	mov	x1, x19
1013ff7fc: 52800022    	mov	w2, #0x1                ; =1
1013ff800: 97da7bb7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1013ff804: aa1403e0    	mov	x0, x20
1013ff808: 941b2773    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1013ff80c: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
1013ff810: a90167fa    	stp	x26, x25, [sp, #0x10]
1013ff814: a9025ff8    	stp	x24, x23, [sp, #0x20]
1013ff818: a90357f6    	stp	x22, x21, [sp, #0x30]
1013ff81c: a9044ff4    	stp	x20, x19, [sp, #0x40]
1013ff820: a9057bfd    	stp	x29, x30, [sp, #0x50]
1013ff824: 910143fd    	add	x29, sp, #0x50
1013ff828: aa0103f4    	mov	x20, x1
1013ff82c: aa0003f3    	mov	x19, x0
1013ff830: a9415428    	ldp	x8, x21, [x1, #0x10]
1013ff834: f900083f    	str	xzr, [x1, #0x10]
1013ff838: b4000228    	cbz	x8, 0x1013ff87c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1b54>
1013ff83c: d1000509    	sub	x9, x8, #0x1
1013ff840: a9405a8a    	ldp	x10, x22, [x20]
1013ff844: cb0a02cb    	sub	x11, x22, x10
1013ff848: d343fd6b    	lsr	x11, x11, #3
1013ff84c: b201f3ec    	mov	x12, #-0x5555555555555556 ; =-6148914691236517206
1013ff850: f295556c    	movk	x12, #0xaaab
1013ff854: 9b0c7d6b    	mul	x11, x11, x12
1013ff858: 5280030c    	mov	w12, #0x18              ; =24
1013ff85c: 9b0c2908    	madd	x8, x8, x12, x10
1013ff860: eb0b013f    	cmp	x9, x11
1013ff864: 9a963109    	csel	x9, x8, x22, lo
1013ff868: f9000289    	str	x9, [x20]
1013ff86c: 54000702    	b.hs	0x1013ff94c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1c24>
1013ff870: eb16011f    	cmp	x8, x22
1013ff874: 540000a1    	b.ne	0x1013ff888 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1b60>
1013ff878: 14000035    	b	0x1013ff94c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1c24>
1013ff87c: a9405a88    	ldp	x8, x22, [x20]
1013ff880: eb16011f    	cmp	x8, x22
1013ff884: 54000640    	b.eq	0x1013ff94c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1c24>
1013ff888: 91006117    	add	x23, x8, #0x18
1013ff88c: d285a5b8    	mov	x24, #0x2d2d            ; =11565
1013ff890: f2ae4c78    	movk	x24, #0x7263, lsl #16
1013ff894: f2cc2cb8    	movk	x24, #0x6165, lsl #32
1013ff898: f2ecae98    	movk	x24, #0x6574, lsl #48
1013ff89c: 528c45b9    	mov	w25, #0x622d            ; =25133
1013ff8a0: 528845ba    	mov	w26, #0x422d            ; =16941
1013ff8a4: 528c65bb    	mov	w27, #0x632d            ; =25389
1013ff8a8: 14000005    	b	0x1013ff8bc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1b94>
1013ff8ac: 910062e8    	add	x8, x23, #0x18
1013ff8b0: eb1602ff    	cmp	x23, x22
1013ff8b4: aa0803f7    	mov	x23, x8
1013ff8b8: 54000460    	b.eq	0x1013ff944 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1c1c>
1013ff8bc: a97f0ae0    	ldp	x0, x2, [x23, #-0x10]
1013ff8c0: f100205f    	cmp	x2, #0x8
1013ff8c4: 540001a0    	b.eq	0x1013ff8f8 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1bd0>
1013ff8c8: f100085f    	cmp	x2, #0x2
1013ff8cc: 540001c1    	b.ne	0x1013ff904 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1bdc>
1013ff8d0: 79400008    	ldrh	w8, [x0]
1013ff8d4: 6b19011f    	cmp	w8, w25
1013ff8d8: 54fffea0    	b.eq	0x1013ff8ac <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1b84>
1013ff8dc: 79400008    	ldrh	w8, [x0]
1013ff8e0: 6b1a011f    	cmp	w8, w26
1013ff8e4: 54fffe40    	b.eq	0x1013ff8ac <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1b84>
1013ff8e8: 79400008    	ldrh	w8, [x0]
1013ff8ec: 6b1b011f    	cmp	w8, w27
1013ff8f0: 540000a1    	b.ne	0x1013ff904 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1bdc>
1013ff8f4: 17ffffee    	b	0x1013ff8ac <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1b84>
1013ff8f8: f9400008    	ldr	x8, [x0]
1013ff8fc: eb18011f    	cmp	x8, x24
1013ff900: 54fffd60    	b.eq	0x1013ff8ac <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1b84>
1013ff904: f9400aa8    	ldr	x8, [x21, #0x10]
1013ff908: eb08005f    	cmp	x2, x8
1013ff90c: 54000081    	b.ne	0x1013ff91c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1bf4>
1013ff910: f94006a1    	ldr	x1, [x21, #0x8]
1013ff914: 941b28c2    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
1013ff918: 34fffca0    	cbz	w0, 0x1013ff8ac <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1b84>
1013ff91c: f9000297    	str	x23, [x20]
1013ff920: d10062e0    	sub	x0, x23, #0x18
1013ff924: aa1303e8    	mov	x8, x19
1013ff928: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1013ff92c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1013ff930: a94357f6    	ldp	x22, x21, [sp, #0x30]
1013ff934: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1013ff938: a94167fa    	ldp	x26, x25, [sp, #0x10]
1013ff93c: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1013ff940: 14103e23    	b	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1013ff944: d1006108    	sub	x8, x8, #0x18
1013ff948: f9000288    	str	x8, [x20]
1013ff94c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1013ff950: f9000268    	str	x8, [x19]
1013ff954: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1013ff958: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1013ff95c: a94357f6    	ldp	x22, x21, [sp, #0x30]
1013ff960: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1013ff964: a94167fa    	ldp	x26, x25, [sp, #0x10]
1013ff968: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1013ff96c: d65f03c0    	ret
1013ff970: 90004700    	adrp	x0, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1013ff974: 9113a400    	add	x0, x0, #0x4e9
1013ff978: 528001a1    	mov	w1, #0xd                ; =13
1013ff97c: d65f03c0    	ret
