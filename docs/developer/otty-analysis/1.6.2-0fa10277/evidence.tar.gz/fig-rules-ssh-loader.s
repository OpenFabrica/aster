
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010147a8b8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E>:
10147a8b8: d10503ff    	sub	sp, sp, #0x140
10147a8bc: a90f6ffc    	stp	x28, x27, [sp, #0xf0]
10147a8c0: a9105ff8    	stp	x24, x23, [sp, #0x100]
10147a8c4: a91157f6    	stp	x22, x21, [sp, #0x110]
10147a8c8: a9124ff4    	stp	x20, x19, [sp, #0x120]
10147a8cc: a9137bfd    	stp	x29, x30, [sp, #0x130]
10147a8d0: 9104c3fd    	add	x29, sp, #0x130
10147a8d4: aa0003f4    	mov	x20, x0
10147a8d8: aa0803f3    	mov	x19, x8
10147a8dc: 52800108    	mov	w8, #0x8                ; =8
10147a8e0: a93aa3bf    	stp	xzr, x8, [x29, #-0x58]
10147a8e4: f81b83bf    	stur	xzr, [x29, #-0x48]
10147a8e8: a93723bf    	stp	xzr, x8, [x29, #-0x90]
10147a8ec: f81803bf    	stur	xzr, [x29, #-0x80]
10147a8f0: d0007800    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
10147a8f4: 9131a000    	add	x0, x0, #0xc68
10147a8f8: f9400008    	ldr	x8, [x0]
10147a8fc: d63f0100    	blr	x8
10147a900: aa0003f5    	mov	x21, x0
10147a904: 39404008    	ldrb	w8, [x0, #0x10]
10147a908: 7100051f    	cmp	w8, #0x1
10147a90c: 54001361    	b.ne	0x10147ab78 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x2c0>
10147a910: a94006a0    	ldp	x0, x1, [x21]
10147a914: 91000408    	add	x8, x0, #0x1
10147a918: 3cda83a0    	ldur	q0, [x29, #-0x58]
10147a91c: 3d8003e0    	str	q0, [sp]
10147a920: f85b83a9    	ldur	x9, [x29, #-0x48]
10147a924: f9000be9    	str	x9, [sp, #0x10]
10147a928: 3cd703a0    	ldur	q0, [x29, #-0x90]
10147a92c: 3c8183e0    	stur	q0, [sp, #0x18]
10147a930: 90006f89    	adrp	x9, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
10147a934: 91250129    	add	x9, x9, #0x940
10147a938: ad400520    	ldp	q0, q1, [x9]
10147a93c: f85803a9    	ldur	x9, [x29, #-0x80]
10147a940: 3c8683e0    	stur	q0, [sp, #0x68]
10147a944: 3c8783e1    	stur	q1, [sp, #0x78]
10147a948: a90887e0    	stp	x0, x1, [sp, #0x88]
10147a94c: a902ffe9    	stp	x9, xzr, [sp, #0x28]
10147a950: 52800109    	mov	w9, #0x8                ; =8
10147a954: f9001fe9    	str	x9, [sp, #0x38]
10147a958: b0003469    	adrp	x9, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
10147a95c: 3dc2f922    	ldr	q2, [x9, #0xbe0]
10147a960: 3d8013e2    	str	q2, [sp, #0x40]
10147a964: 91000809    	add	x9, x0, #0x2
10147a968: f90002a9    	str	x9, [x21]
10147a96c: ad3b87a0    	stp	q0, q1, [x29, #-0x90]
10147a970: a93907a8    	stp	x8, x1, [x29, #-0x70]
10147a974: f9402288    	ldr	x8, [x20, #0x40]
10147a978: b40001e8    	cbz	x8, 0x10147a9b4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xfc>
10147a97c: f9401e89    	ldr	x9, [x20, #0x38]
10147a980: d37be915    	lsl	x21, x8, #5
10147a984: 91006136    	add	x22, x9, #0x18
10147a988: a97f0ac1    	ldp	x1, x2, [x22, #-0x10]
10147a98c: 384206c3    	ldrb	w3, [x22], #0x20
10147a990: d10243a5    	sub	x5, x29, #0x90
10147a994: 910003e6    	mov	x6, sp
10147a998: aa1403e0    	mov	x0, x20
10147a99c: d2800004    	mov	x4, #0x0                ; =0
10147a9a0: 9400009c    	bl	0x10147ac10 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x358>
10147a9a4: f10082b5    	subs	x21, x21, #0x20
10147a9a8: 54ffff01    	b.ne	0x10147a988 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xd0>
10147a9ac: f85783b4    	ldur	x20, [x29, #-0x88]
10147a9b0: 14000002    	b	0x10147a9b8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x100>
10147a9b4: d2800014    	mov	x20, #0x0               ; =0
10147a9b8: 910003e8    	mov	x8, sp
10147a9bc: 3dc003e0    	ldr	q0, [sp]
10147a9c0: 3d800260    	str	q0, [x19]
10147a9c4: f9400be9    	ldr	x9, [sp, #0x10]
10147a9c8: f9000a69    	str	x9, [x19, #0x10]
10147a9cc: 3cc18100    	ldur	q0, [x8, #0x18]
10147a9d0: 3c818260    	stur	q0, [x19, #0x18]
10147a9d4: f8428108    	ldur	x8, [x8, #0x28]
10147a9d8: f9001668    	str	x8, [x19, #0x28]
10147a9dc: b4000554    	cbz	x20, 0x10147aa84 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1cc>
10147a9e0: f85883b3    	ldur	x19, [x29, #-0x78]
10147a9e4: b40003d3    	cbz	x19, 0x10147aa5c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a4>
10147a9e8: f85703b5    	ldur	x21, [x29, #-0x90]
10147a9ec: aa1503f6    	mov	x22, x21
10147a9f0: fc4086c0    	ldr	d0, [x22], #0x8
10147a9f4: 2e208800    	cmge.8b	v0, v0, #0
10147a9f8: 9e660008    	fmov	x8, d0
10147a9fc: 9201c118    	and	x24, x8, #0x8080808080808080
10147aa00: 52800317    	mov	w23, #0x18              ; =24
10147aa04: 14000005    	b	0x10147aa18 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x160>
10147aa08: d1000708    	sub	x8, x24, #0x1
10147aa0c: 8a180118    	and	x24, x8, x24
10147aa10: d1000673    	sub	x19, x19, #0x1
10147aa14: b4000253    	cbz	x19, 0x10147aa5c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a4>
10147aa18: b50000f8    	cbnz	x24, 0x10147aa34 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x17c>
10147aa1c: fc4086c0    	ldr	d0, [x22], #0x8
10147aa20: 2e208800    	cmge.8b	v0, v0, #0
10147aa24: 9e660008    	fmov	x8, d0
10147aa28: d10302b5    	sub	x21, x21, #0xc0
10147aa2c: 9201c118    	and	x24, x8, #0x8080808080808080
10147aa30: b4ffff78    	cbz	x24, 0x10147aa1c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x164>
10147aa34: dac00308    	rbit	x8, x24
10147aa38: dac01108    	clz	x8, x8
10147aa3c: cb480fe8    	neg	x8, x8, lsr #3
10147aa40: 9b375508    	smaddl	x8, w8, w23, x21
10147aa44: f85e8101    	ldur	x1, [x8, #-0x18]
10147aa48: b4fffe01    	cbz	x1, 0x10147aa08 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x150>
10147aa4c: f85f0100    	ldur	x0, [x8, #-0x10]
10147aa50: 52800022    	mov	w2, #0x1                ; =1
10147aa54: 97d88f22    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147aa58: 17ffffec    	b	0x10147aa08 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x150>
10147aa5c: 8b140688    	add	x8, x20, x20, lsl #1
10147aa60: d37df108    	lsl	x8, x8, #3
10147aa64: 8b140109    	add	x9, x8, x20
10147aa68: b1008521    	adds	x1, x9, #0x21
10147aa6c: 540000c0    	b.eq	0x10147aa84 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1cc>
10147aa70: f85703a9    	ldur	x9, [x29, #-0x90]
10147aa74: cb080128    	sub	x8, x9, x8
10147aa78: d1006100    	sub	x0, x8, #0x18
10147aa7c: 52800102    	mov	w2, #0x8                ; =8
10147aa80: 97d88f17    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147aa84: f9403bf3    	ldr	x19, [sp, #0x70]
10147aa88: b4000533    	cbz	x19, 0x10147ab2c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x274>
10147aa8c: f94043f4    	ldr	x20, [sp, #0x80]
10147aa90: b40003d4    	cbz	x20, 0x10147ab08 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x250>
10147aa94: f94037f5    	ldr	x21, [sp, #0x68]
10147aa98: aa1503f6    	mov	x22, x21
10147aa9c: fc4086c0    	ldr	d0, [x22], #0x8
10147aaa0: 2e208800    	cmge.8b	v0, v0, #0
10147aaa4: 9e660008    	fmov	x8, d0
10147aaa8: 9201c117    	and	x23, x8, #0x8080808080808080
10147aaac: 14000005    	b	0x10147aac0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x208>
10147aab0: d10006e8    	sub	x8, x23, #0x1
10147aab4: 8a170117    	and	x23, x8, x23
10147aab8: d1000694    	sub	x20, x20, #0x1
10147aabc: b4000274    	cbz	x20, 0x10147ab08 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x250>
10147aac0: b50000f7    	cbnz	x23, 0x10147aadc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x224>
10147aac4: fc4086c0    	ldr	d0, [x22], #0x8
10147aac8: 2e208800    	cmge.8b	v0, v0, #0
10147aacc: 9e660008    	fmov	x8, d0
10147aad0: d10402b5    	sub	x21, x21, #0x100
10147aad4: 9201c117    	and	x23, x8, #0x8080808080808080
10147aad8: b4ffff77    	cbz	x23, 0x10147aac4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x20c>
10147aadc: dac002e8    	rbit	x8, x23
10147aae0: dac01108    	clz	x8, x8
10147aae4: d37ef508    	lsl	x8, x8, #2
10147aae8: 927b0d08    	and	x8, x8, #0x1e0
10147aaec: cb0802a8    	sub	x8, x21, x8
10147aaf0: f85e0101    	ldur	x1, [x8, #-0x20]
10147aaf4: b4fffde1    	cbz	x1, 0x10147aab0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1f8>
10147aaf8: f85e8100    	ldur	x0, [x8, #-0x18]
10147aafc: 52800022    	mov	w2, #0x1                ; =1
10147ab00: 97d88ef7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147ab04: 17ffffeb    	b	0x10147aab0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1f8>
10147ab08: d37bea68    	lsl	x8, x19, #5
10147ab0c: 8b130109    	add	x9, x8, x19
10147ab10: b100a521    	adds	x1, x9, #0x29
10147ab14: 540000c0    	b.eq	0x10147ab2c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x274>
10147ab18: f94037e9    	ldr	x9, [sp, #0x68]
10147ab1c: cb080128    	sub	x8, x9, x8
10147ab20: d1008100    	sub	x0, x8, #0x20
10147ab24: 52800102    	mov	w2, #0x8                ; =8
10147ab28: 97d88eed    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147ab2c: f9401be8    	ldr	x8, [sp, #0x30]
10147ab30: b40000a8    	cbz	x8, 0x10147ab44 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x28c>
10147ab34: f9401fe0    	ldr	x0, [sp, #0x38]
10147ab38: d37df101    	lsl	x1, x8, #3
10147ab3c: 52800102    	mov	w2, #0x8                ; =8
10147ab40: 97d88ee7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147ab44: f94027e1    	ldr	x1, [sp, #0x48]
10147ab48: f240f83f    	tst	x1, #0x7fffffffffffffff
10147ab4c: 54000080    	b.eq	0x10147ab5c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x2a4>
10147ab50: f9402be0    	ldr	x0, [sp, #0x50]
10147ab54: 52800022    	mov	w2, #0x1                ; =1
10147ab58: 97d88ee1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147ab5c: a9537bfd    	ldp	x29, x30, [sp, #0x130]
10147ab60: a9524ff4    	ldp	x20, x19, [sp, #0x120]
10147ab64: a95157f6    	ldp	x22, x21, [sp, #0x110]
10147ab68: a9505ff8    	ldp	x24, x23, [sp, #0x100]
10147ab6c: a94f6ffc    	ldp	x28, x27, [sp, #0xf0]
10147ab70: 910503ff    	add	sp, sp, #0x140
10147ab74: d65f03c0    	ret
10147ab78: 940d1384    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
10147ab7c: f90006a1    	str	x1, [x21, #0x8]
10147ab80: 52800028    	mov	w8, #0x1                ; =1
10147ab84: 390042a8    	strb	w8, [x21, #0x10]
10147ab88: 17ffff63    	b	0x10147a914 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x5c>
10147ab8c: aa0003f3    	mov	x19, x0
10147ab90: d10243a0    	sub	x0, x29, #0x90
10147ab94: 97d31fde    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10147ab98: d10163a0    	sub	x0, x29, #0x58
10147ab9c: 94003e9b    	bl	0x10148a608 <__ZN3std2io5error5Error3new17h519eec155b6ed967E+0x658>
10147aba0: aa1303e0    	mov	x0, x19
10147aba4: 94193a8c    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147aba8: aa0003f3    	mov	x19, x0
10147abac: d10243a0    	sub	x0, x29, #0x90
10147abb0: 97d337ab    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
10147abb4: 910003f4    	mov	x20, sp
10147abb8: 910003e0    	mov	x0, sp
10147abbc: 94003e93    	bl	0x10148a608 <__ZN3std2io5error5Error3new17h519eec155b6ed967E+0x658>
10147abc0: 91006280    	add	x0, x20, #0x18
10147abc4: 97d31fd2    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10147abc8: 9101a280    	add	x0, x20, #0x68
10147abcc: 97d2d675    	bl	0x1009305a0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1d578>
10147abd0: f9401be8    	ldr	x8, [sp, #0x30]
10147abd4: b40000a8    	cbz	x8, 0x10147abe8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x330>
10147abd8: f9401fe0    	ldr	x0, [sp, #0x38]
10147abdc: d37df101    	lsl	x1, x8, #3
10147abe0: 52800102    	mov	w2, #0x8                ; =8
10147abe4: 97d88ebe    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147abe8: f94027e1    	ldr	x1, [sp, #0x48]
10147abec: f240f83f    	tst	x1, #0x7fffffffffffffff
10147abf0: 54000061    	b.ne	0x10147abfc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x344>
10147abf4: aa1303e0    	mov	x0, x19
10147abf8: 94193a77    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147abfc: f9402be0    	ldr	x0, [sp, #0x50]
10147ac00: 52800022    	mov	w2, #0x1                ; =1
10147ac04: 97d88eb6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147ac08: aa1303e0    	mov	x0, x19
10147ac0c: 94193a72    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10147ac10: 6db923e9    	stp	d9, d8, [sp, #-0x70]!
10147ac14: a9016ffc    	stp	x28, x27, [sp, #0x10]
10147ac18: a90267fa    	stp	x26, x25, [sp, #0x20]
10147ac1c: a9035ff8    	stp	x24, x23, [sp, #0x30]
10147ac20: a90457f6    	stp	x22, x21, [sp, #0x40]
10147ac24: a9054ff4    	stp	x20, x19, [sp, #0x50]
10147ac28: a9067bfd    	stp	x29, x30, [sp, #0x60]
10147ac2c: 910183fd    	add	x29, sp, #0x60
10147ac30: d10cc3ff    	sub	sp, sp, #0x330
10147ac34: a90f17e0    	stp	x0, x5, [sp, #0xf0]
10147ac38: b90107e3    	str	w3, [sp, #0x104]
10147ac3c: f9402408    	ldr	x8, [x0, #0x48]
10147ac40: f90077e4    	str	x4, [sp, #0xe8]
10147ac44: eb08009f    	cmp	x4, x8
10147ac48: 5400bd02    	b.hs	0x10147c3e8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1b30>
10147ac4c: aa0603f8    	mov	x24, x6
10147ac50: aa0203f4    	mov	x20, x2
10147ac54: 910783e8    	add	x8, sp, #0x1e0
10147ac58: aa0103e0    	mov	x0, x1
10147ac5c: aa0103f5    	mov	x21, x1
10147ac60: aa0203e1    	mov	x1, x2
10147ac64: 940cf984    	bl	0x1017b9274 <__ZN3std3sys2fs12canonicalize17ha8066aa351562951E>
10147ac68: f940f3e8    	ldr	x8, [sp, #0x1e0]
10147ac6c: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10147ac70: eb09011f    	cmp	x8, x9
10147ac74: 540001e1    	b.ne	0x10147acb0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x3f8>
10147ac78: f940f7f3    	ldr	x19, [sp, #0x1e8]
10147ac7c: 910443e8    	add	x8, sp, #0x110
10147ac80: aa1503f7    	mov	x23, x21
10147ac84: aa1503e0    	mov	x0, x21
10147ac88: aa1403e1    	mov	x1, x20
10147ac8c: 940d22ce    	bl	0x1017c37c4 <__ZN3std4path4Path11to_path_buf17h78bffc49f7c5d7e1E>
10147ac90: 92400668    	and	x8, x19, #0x3
10147ac94: f100051f    	cmp	x8, #0x1
10147ac98: 5400b7e0    	b.eq	0x10147c394 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1adc>
10147ac9c: 910443e1    	add	x1, sp, #0x110
10147aca0: f9407fe0    	ldr	x0, [sp, #0xf8]
10147aca4: 94004c7d    	bl	0x10148de98 <__ZN4core5slice4sort6stable9quicksort9quicksort17h1ad04638c7ce3510E+0x1f00>
10147aca8: 36000160    	tbz	w0, #0x0, 0x10147acd4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x41c>
10147acac: 140005cf    	b	0x10147c3e8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1b30>
10147acb0: aa1503f7    	mov	x23, x21
10147acb4: 3dc07be0    	ldr	q0, [sp, #0x1e0]
10147acb8: 3d8047e0    	str	q0, [sp, #0x110]
10147acbc: f940fbe8    	ldr	x8, [sp, #0x1f0]
10147acc0: f90093e8    	str	x8, [sp, #0x120]
10147acc4: 910443e1    	add	x1, sp, #0x110
10147acc8: f9407fe0    	ldr	x0, [sp, #0xf8]
10147accc: 94004c73    	bl	0x10148de98 <__ZN4core5slice4sort6stable9quicksort9quicksort17h1ad04638c7ce3510E+0x1f00>
10147acd0: 3700b8c0    	tbnz	w0, #0x0, 0x10147c3e8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1b30>
10147acd4: aa1703f5    	mov	x21, x23
10147acd8: 910783e8    	add	x8, sp, #0x1e0
10147acdc: aa1703e0    	mov	x0, x23
10147ace0: aa1403e1    	mov	x1, x20
10147ace4: 940cd682    	bl	0x1017b06ec <__ZN3std2fs14read_to_string5inner17h33327e834bd59c04E>
10147ace8: a95e07e9    	ldp	x9, x1, [sp, #0x1e0]
10147acec: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10147acf0: eb08013f    	cmp	x9, x8
10147acf4: 54000081    	b.ne	0x10147ad04 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x44c>
10147acf8: d2f00000    	mov	x0, #-0x8000000000000000 ; =-9223372036854775808
10147acfc: 94003eb5    	bl	0x10148a7d0 <__ZN3std2io5error5Error3new17h519eec155b6ed967E+0x820>
10147ad00: 140005ba    	b	0x10147c3e8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1b30>
10147ad04: f9000be9    	str	x9, [sp, #0x10]
10147ad08: a903d7e1    	stp	x1, x21, [sp, #0x38]
10147ad0c: f940fbf3    	ldr	x19, [sp, #0x1f0]
10147ad10: 910783e8    	add	x8, sp, #0x1e0
10147ad14: aa1503e0    	mov	x0, x21
10147ad18: f90027f4    	str	x20, [sp, #0x48]
10147ad1c: aa1403e1    	mov	x1, x20
10147ad20: 940d22a9    	bl	0x1017c37c4 <__ZN3std4path4Path11to_path_buf17h78bffc49f7c5d7e1E>
10147ad24: aa1803e0    	mov	x0, x24
10147ad28: f8418c08    	ldr	x8, [x0, #0x18]!
10147ad2c: f9400814    	ldr	x20, [x0, #0x10]
10147ad30: eb08029f    	cmp	x20, x8
10147ad34: 54000041    	b.ne	0x10147ad3c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x484>
10147ad38: 9418583d    	bl	0x101a90e2c <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h84a0093f42692274E>
10147ad3c: f9401308    	ldr	x8, [x24, #0x20]
10147ad40: 52800309    	mov	w9, #0x18               ; =24
10147ad44: 9b092288    	madd	x8, x20, x9, x8
10147ad48: 3dc07be0    	ldr	q0, [sp, #0x1e0]
10147ad4c: 3d800100    	str	q0, [x8]
10147ad50: f940fbe9    	ldr	x9, [sp, #0x1f0]
10147ad54: f9000909    	str	x9, [x8, #0x10]
10147ad58: 91000688    	add	x8, x20, #0x1
10147ad5c: f9001708    	str	x8, [x24, #0x28]
10147ad60: 910783e8    	add	x8, sp, #0x1e0
10147ad64: f9401fe0    	ldr	x0, [sp, #0x38]
10147ad68: aa1303e1    	mov	x1, x19
10147ad6c: 9400078f    	bl	0x10147cba8 <__ZN15otty_ssh_config5parse16parse_directives17h16dfcd5e0a1b4e03E>
10147ad70: a95e53eb    	ldp	x11, x20, [sp, #0x1e0]
10147ad74: f940fbe8    	ldr	x8, [sp, #0x1f0]
10147ad78: 52800709    	mov	w9, #0x38               ; =56
10147ad7c: 9b095109    	madd	x9, x8, x9, x20
10147ad80: a912d3f4    	stp	x20, x20, [sp, #0x128]
10147ad84: f90007eb    	str	x11, [sp, #0x8]
10147ad88: a913a7eb    	stp	x11, x9, [sp, #0x138]
10147ad8c: f90047e9    	str	x9, [sp, #0x88]
10147ad90: f90013f4    	str	x20, [sp, #0x20]
10147ad94: b400aca8    	cbz	x8, 0x10147c328 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a70>
10147ad98: f9407be8    	ldr	x8, [sp, #0xf0]
10147ad9c: a940a50a    	ldp	x10, x9, [x8, #0x8]
10147ada0: a90b2be9    	stp	x9, x10, [sp, #0xb0]
10147ada4: a9422109    	ldp	x9, x8, [x8, #0x20]
10147ada8: a90a27e8    	stp	x8, x9, [sp, #0xa0]
10147adac: 5280003b    	mov	w27, #0x1               ; =1
10147adb0: f94013e8    	ldr	x8, [sp, #0x20]
10147adb4: f90087f8    	str	x24, [sp, #0x108]
10147adb8: 14000009    	b	0x10147addc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x524>
10147adbc: f900231f    	str	xzr, [x24, #0x40]
10147adc0: 910523e0    	add	x0, sp, #0x148
10147adc4: 97d30c2d    	bl	0x10093de78 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2ae50>
10147adc8: f9404fea    	ldr	x10, [sp, #0x98]
10147adcc: aa0a03e8    	mov	x8, x10
10147add0: f94047e9    	ldr	x9, [sp, #0x88]
10147add4: eb09015f    	cmp	x10, x9
10147add8: 5400ac40    	b.eq	0x10147c360 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1aa8>
10147addc: 9100e114    	add	x20, x8, #0x38
10147ade0: f9009bf4    	str	x20, [sp, #0x130]
10147ade4: aa0803e9    	mov	x9, x8
10147ade8: f8408537    	ldr	x23, [x9], #0x8
10147adec: b2410bea    	mov	x10, #-0x7ffffffffffffffd ; =-9223372036854775805
10147adf0: eb0a02ff    	cmp	x23, x10
10147adf4: 5400a9a0    	b.eq	0x10147c328 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a70>
10147adf8: f9004ff4    	str	x20, [sp, #0x98]
10147adfc: f900a7f7    	str	x23, [sp, #0x148]
10147ae00: ad400520    	ldp	q0, q1, [x9]
10147ae04: 910523ea    	add	x10, sp, #0x148
10147ae08: 3c808140    	stur	q0, [x10, #0x8]
10147ae0c: 3c818141    	stur	q1, [x10, #0x18]
10147ae10: 3dc00920    	ldr	q0, [x9, #0x20]
10147ae14: 3c828140    	stur	q0, [x10, #0x28]
10147ae18: d24102ea    	eor	x10, x23, #0x8000000000000000
10147ae1c: f10002ff    	cmp	x23, #0x0
10147ae20: 5280006b    	mov	w11, #0x3               ; =3
10147ae24: 9a8bb154    	csel	x20, x10, x11, lt
10147ae28: f100069f    	cmp	x20, #0x1
10147ae2c: 5400366c    	b.gt	0x10147b4f8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xc40>
10147ae30: b5fffc74    	cbnz	x20, 0x10147adbc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x504>
10147ae34: f9004bf4    	str	x20, [sp, #0x90]
10147ae38: 3dc00120    	ldr	q0, [x9]
10147ae3c: 3d8063e0    	str	q0, [sp, #0x180]
10147ae40: f9400928    	ldr	x8, [x9, #0x10]
10147ae44: f900cbe8    	str	x8, [sp, #0x190]
10147ae48: b9416be8    	ldr	w8, [sp, #0x168]
10147ae4c: b900dbe8    	str	w8, [sp, #0xd8]
10147ae50: 910783e8    	add	x8, sp, #0x1e0
10147ae54: a94407e0    	ldp	x0, x1, [sp, #0x40]
10147ae58: 940d225b    	bl	0x1017c37c4 <__ZN3std4path4Path11to_path_buf17h78bffc49f7c5d7e1E>
10147ae5c: a95e23e9    	ldp	x9, x8, [sp, #0x1e0]
10147ae60: f90037e9    	str	x9, [sp, #0x68]
10147ae64: f90073e8    	str	x8, [sp, #0xe0]
10147ae68: f940fbf3    	ldr	x19, [sp, #0x1f0]
10147ae6c: f900231f    	str	xzr, [x24, #0x40]
10147ae70: a9585fea    	ldp	x10, x23, [sp, #0x180]
10147ae74: f940cbe9    	ldr	x9, [sp, #0x190]
10147ae78: 52800308    	mov	w8, #0x18               ; =24
10147ae7c: 9b085d28    	madd	x8, x9, x8, x23
10147ae80: a91a5ff7    	stp	x23, x23, [sp, #0x1a0]
10147ae84: a905abf7    	stp	x23, x10, [sp, #0x58]
10147ae88: a91b23ea    	stp	x10, x8, [sp, #0x1b0]
10147ae8c: f90063e8    	str	x8, [sp, #0xc0]
10147ae90: aa1703e8    	mov	x8, x23
10147ae94: b50002e9    	cbnz	x9, 0x10147aef0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x638>
10147ae98: f94063e8    	ldr	x8, [sp, #0xc0]
10147ae9c: eb170108    	subs	x8, x8, x23
10147aea0: 54004640    	b.eq	0x10147b768 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xeb0>
10147aea4: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
10147aea8: f2955569    	movk	x9, #0xaaab
10147aeac: 9bc97d08    	umulh	x8, x8, x9
10147aeb0: d344fd13    	lsr	x19, x8, #4
10147aeb4: 910022f4    	add	x20, x23, #0x8
10147aeb8: 14000004    	b	0x10147aec8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x610>
10147aebc: 91006294    	add	x20, x20, #0x18
10147aec0: f1000673    	subs	x19, x19, #0x1
10147aec4: 54004520    	b.eq	0x10147b768 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xeb0>
10147aec8: f85f8281    	ldur	x1, [x20, #-0x8]
10147aecc: b4ffff81    	cbz	x1, 0x10147aebc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x604>
10147aed0: f9400280    	ldr	x0, [x20]
10147aed4: 52800022    	mov	w2, #0x1                ; =1
10147aed8: 97d88e01    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147aedc: 17fffff8    	b	0x10147aebc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x604>
10147aee0: aa1703e8    	mov	x8, x23
10147aee4: f94063e9    	ldr	x9, [sp, #0xc0]
10147aee8: eb0902ff    	cmp	x23, x9
10147aeec: 540043e0    	b.eq	0x10147b768 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xeb0>
10147aef0: aa0803f7    	mov	x23, x8
10147aef4: f84186f9    	ldr	x25, [x23], #0x18
10147aef8: f900d7f7    	str	x23, [sp, #0x1a8]
10147aefc: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10147af00: eb09033f    	cmp	x25, x9
10147af04: 54fffca0    	b.eq	0x10147ae98 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x5e0>
10147af08: f900e7f9    	str	x25, [sp, #0x1c8]
10147af0c: 3cc08100    	ldur	q0, [x8, #0x8]
10147af10: 910723e8    	add	x8, sp, #0x1c8
10147af14: 3c808100    	stur	q0, [x8, #0x8]
10147af18: f9404308    	ldr	x8, [x24, #0x80]
10147af1c: b4000608    	cbz	x8, 0x10147afdc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x724>
10147af20: a9488700    	ldp	x0, x1, [x24, #0x88]
10147af24: 910723e2    	add	x2, sp, #0x1c8
10147af28: 97d34a55    	bl	0x10094d87c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a854>
10147af2c: d2800009    	mov	x9, #0x0                ; =0
10147af30: d379fc08    	lsr	x8, x0, #57
10147af34: a946ef1c    	ldp	x28, x27, [x24, #0x68]
10147af38: 0e010d08    	dup.8b	v8, w8
10147af3c: a95d53fa    	ldp	x26, x20, [sp, #0x1d0]
10147af40: 8a1b0015    	and	x21, x0, x27
10147af44: fc756b89    	ldr	d9, [x28, x21]
10147af48: 2e288d20    	cmeq.8b	v0, v9, v8
10147af4c: 9e660008    	fmov	x8, d0
10147af50: f201c116    	ands	x22, x8, #0x8080808080808080
10147af54: 54000280    	b.eq	0x10147afa4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x6ec>
10147af58: f9006be9    	str	x9, [sp, #0xd0]
10147af5c: dac002c8    	rbit	x8, x22
10147af60: dac01108    	clz	x8, x8
10147af64: 8b480ea8    	add	x8, x21, x8, lsr #3
10147af68: 8a1b0108    	and	x8, x8, x27
10147af6c: cb081798    	sub	x24, x28, x8, lsl #5
10147af70: f85f0308    	ldur	x8, [x24, #-0x10]
10147af74: eb08029f    	cmp	x20, x8
10147af78: 540000c1    	b.ne	0x10147af90 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x6d8>
10147af7c: f85e8301    	ldur	x1, [x24, #-0x18]
10147af80: aa1a03e0    	mov	x0, x26
10147af84: aa1403e2    	mov	x2, x20
10147af88: 94193b25    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10147af8c: 34000480    	cbz	w0, 0x10147b01c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x764>
10147af90: d10006c8    	sub	x8, x22, #0x1
10147af94: ea160116    	ands	x22, x8, x22
10147af98: f94087f8    	ldr	x24, [sp, #0x108]
10147af9c: f9406be9    	ldr	x9, [sp, #0xd0]
10147afa0: 54fffde1    	b.ne	0x10147af5c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x6a4>
10147afa4: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
10147afa8: 2e208d20    	cmeq.8b	v0, v9, v0
10147afac: 2e30a800    	umaxv.8b	b0, v0
10147afb0: 1e260008    	fmov	w8, s0
10147afb4: 37000148    	tbnz	w8, #0x0, 0x10147afdc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x724>
10147afb8: 91002129    	add	x9, x9, #0x8
10147afbc: 8b0902a0    	add	x0, x21, x9
10147afc0: 8a1b0015    	and	x21, x0, x27
10147afc4: fc756b89    	ldr	d9, [x28, x21]
10147afc8: 2e288d20    	cmeq.8b	v0, v9, v8
10147afcc: 9e660008    	fmov	x8, d0
10147afd0: f201c116    	ands	x22, x8, #0x8080808080808080
10147afd4: 54fffc21    	b.ne	0x10147af58 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x6a0>
10147afd8: 17fffff3    	b	0x10147afa4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x6ec>
10147afdc: f9400b1c    	ldr	x28, [x24, #0x10]
10147afe0: d10203a8    	sub	x8, x29, #0x80
10147afe4: 910723e0    	add	x0, sp, #0x1c8
10147afe8: f90067f9    	str	x25, [sp, #0xc8]
10147afec: 940e5078    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10147aff0: 52800035    	mov	w21, #0x1               ; =1
10147aff4: d2c08056    	mov	x22, #0x40200000000     ; =4406636445696
10147aff8: f2f00016    	movk	x22, #0x8000, lsl #48
10147affc: b4000793    	cbz	x19, 0x10147b0ec <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x834>
10147b000: 97d88dbc    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147b004: aa1303e0    	mov	x0, x19
10147b008: 52800021    	mov	w1, #0x1                ; =1
10147b00c: 97d88db3    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147b010: aa0003f4    	mov	x20, x0
10147b014: b50006e0    	cbnz	x0, 0x10147b0f0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x838>
10147b018: 1400050d    	b	0x10147c44c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1b94>
10147b01c: f85f831c    	ldur	x28, [x24, #-0x8]
10147b020: f94087e8    	ldr	x8, [sp, #0x108]
10147b024: f9400901    	ldr	x1, [x8, #0x10]
10147b028: eb01039f    	cmp	x28, x1
10147b02c: 5400a042    	b.hs	0x10147c434 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1b7c>
10147b030: b94107e8    	ldr	w8, [sp, #0x104]
10147b034: 72001d1f    	tst	w8, #0xff
10147b038: 5280003b    	mov	w27, #0x1               ; =1
10147b03c: 540004a1    	b.ne	0x10147b0d0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x818>
10147b040: f94087e8    	ldr	x8, [sp, #0x108]
10147b044: f9400508    	ldr	x8, [x8, #0x8]
10147b048: 52802509    	mov	w9, #0x128              ; =296
10147b04c: 9b092395    	madd	x21, x28, x9, x8
10147b050: 394132a8    	ldrb	w8, [x21, #0x4c]
10147b054: 7100051f    	cmp	w8, #0x1
10147b058: 540003c1    	b.ne	0x10147b0d0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x818>
10147b05c: b4002233    	cbz	x19, 0x10147b4a0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xbe8>
10147b060: 97d88da4    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147b064: aa1303e0    	mov	x0, x19
10147b068: 52800021    	mov	w1, #0x1                ; =1
10147b06c: 97d88d9b    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147b070: aa0003f4    	mov	x20, x0
10147b074: b4009fe0    	cbz	x0, 0x10147c470 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1bb8>
10147b078: aa1403e0    	mov	x0, x20
10147b07c: f94073e1    	ldr	x1, [sp, #0xe0]
10147b080: aa1303e2    	mov	x2, x19
10147b084: 94193ae9    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147b088: f84302a1    	ldur	x1, [x21, #0x30]
10147b08c: b4000081    	cbz	x1, 0x10147b09c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x7e4>
10147b090: f84382a0    	ldur	x0, [x21, #0x38]
10147b094: 52800022    	mov	w2, #0x1                ; =1
10147b098: 97d88d91    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147b09c: a90352b3    	stp	x19, x20, [x21, #0x30]
10147b0a0: f80402b3    	stur	x19, [x21, #0x40]
10147b0a4: b940dbe8    	ldr	w8, [sp, #0xd8]
10147b0a8: b80482a8    	stur	w8, [x21, #0x48]
10147b0ac: 3804c2bf    	sturb	wzr, [x21, #0x4c]
10147b0b0: 52800036    	mov	w22, #0x1               ; =1
10147b0b4: f85f831c    	ldur	x28, [x24, #-0x8]
10147b0b8: f94087f8    	ldr	x24, [sp, #0x108]
10147b0bc: f9402314    	ldr	x20, [x24, #0x40]
10147b0c0: f9401b08    	ldr	x8, [x24, #0x30]
10147b0c4: eb08029f    	cmp	x20, x8
10147b0c8: 540019e0    	b.eq	0x10147b404 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xb4c>
10147b0cc: 140000d0    	b	0x10147b40c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xb54>
10147b0d0: 52800036    	mov	w22, #0x1               ; =1
10147b0d4: f94087f8    	ldr	x24, [sp, #0x108]
10147b0d8: f9402314    	ldr	x20, [x24, #0x40]
10147b0dc: f9401b08    	ldr	x8, [x24, #0x30]
10147b0e0: eb08029f    	cmp	x20, x8
10147b0e4: 54001900    	b.eq	0x10147b404 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xb4c>
10147b0e8: 140000c9    	b	0x10147b40c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xb54>
10147b0ec: 52800034    	mov	w20, #0x1               ; =1
10147b0f0: aa1403e0    	mov	x0, x20
10147b0f4: f94073e1    	ldr	x1, [sp, #0xe0]
10147b0f8: aa1303e2    	mov	x2, x19
10147b0fc: 94193acb    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147b100: a978a3aa    	ldp	x10, x8, [x29, #-0x78]
10147b104: 8b080148    	add	x8, x10, x8
10147b108: 1400000a    	b	0x10147b130 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x878>
10147b10c: 9100092a    	add	x10, x9, #0x2
10147b110: 331a116d    	bfi	w13, w11, #6, #5
10147b114: aa0d03eb    	mov	x11, x13
10147b118: 2a0b03ec    	mov	w12, w11
10147b11c: 7100fd7f    	cmp	w11, #0x3f
10147b120: 9acc22ab    	lsl	x11, x21, x12
10147b124: 8a16016b    	and	x11, x11, x22
10147b128: fa409964    	ccmp	x11, #0x0, #0x4, ls
10147b12c: 54000361    	b.ne	0x10147b198 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x8e0>
10147b130: aa0a03e9    	mov	x9, x10
10147b134: eb08015f    	cmp	x10, x8
10147b138: 54000300    	b.eq	0x10147b198 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x8e0>
10147b13c: aa0903ea    	mov	x10, x9
10147b140: 38c0154c    	ldrsb	w12, [x10], #0x1
10147b144: 12001d8b    	and	w11, w12, #0xff
10147b148: 36fffe8c    	tbz	w12, #0x1f, 0x10147b118 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x860>
10147b14c: 3940052a    	ldrb	w10, [x9, #0x1]
10147b150: 1200154d    	and	w13, w10, #0x3f
10147b154: 7103817f    	cmp	w11, #0xe0
10147b158: 54fffda3    	b.lo	0x10147b10c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x854>
10147b15c: 1200116c    	and	w12, w11, #0x1f
10147b160: 3940092a    	ldrb	w10, [x9, #0x2]
10147b164: 1200154a    	and	w10, w10, #0x3f
10147b168: 2a0d194d    	orr	w13, w10, w13, lsl #6
10147b16c: 7103c17f    	cmp	w11, #0xf0
10147b170: 540000e3    	b.lo	0x10147b18c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x8d4>
10147b174: 9100112a    	add	x10, x9, #0x4
10147b178: 39400d2b    	ldrb	w11, [x9, #0x3]
10147b17c: 1200156b    	and	w11, w11, #0x3f
10147b180: 2a0d196b    	orr	w11, w11, w13, lsl #6
10147b184: 330e098b    	bfi	w11, w12, #18, #3
10147b188: 17ffffe4    	b	0x10147b118 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x860>
10147b18c: 91000d2a    	add	x10, x9, #0x3
10147b190: 2a0c31ab    	orr	w11, w13, w12, lsl #12
10147b194: 17ffffe1    	b	0x10147b118 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x860>
10147b198: eb08013f    	cmp	x9, x8
10147b19c: 3cd803a0    	ldur	q0, [x29, #-0x80]
10147b1a0: 1a9f07e8    	cset	w8, ne
10147b1a4: 3d807be0    	str	q0, [sp, #0x1e0]
10147b1a8: f85903a9    	ldur	x9, [x29, #-0x70]
10147b1ac: d2f0000a    	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
10147b1b0: f9011bea    	str	x10, [sp, #0x230]
10147b1b4: f90127ea    	str	x10, [sp, #0x248]
10147b1b8: 7905f3ff    	strh	wzr, [sp, #0x2f8]
10147b1bc: a91f7fe9    	stp	x9, xzr, [sp, #0x1f0]
10147b1c0: 52800109    	mov	w9, #0x8                ; =8
10147b1c4: f90103e9    	str	x9, [sp, #0x200]
10147b1c8: f90107ff    	str	xzr, [sp, #0x208]
10147b1cc: 52804049    	mov	w9, #0x202              ; =514
10147b1d0: 790603e9    	strh	w9, [sp, #0x300]
10147b1d4: f90133ea    	str	x10, [sp, #0x260]
10147b1d8: f9013fea    	str	x10, [sp, #0x278]
10147b1dc: f9014bea    	str	x10, [sp, #0x290]
10147b1e0: f9015bea    	str	x10, [sp, #0x2b0]
10147b1e4: 390bf3ff    	strb	wzr, [sp, #0x2fc]
10147b1e8: f90167ea    	str	x10, [sp, #0x2c8]
10147b1ec: f90173ea    	str	x10, [sp, #0x2e0]
10147b1f0: 528000e9    	mov	w9, #0x7                ; =7
10147b1f4: 390c0be9    	strb	w9, [sp, #0x302]
10147b1f8: 910783e9    	add	x9, sp, #0x1e0
10147b1fc: 91047529    	add	x9, x9, #0x11d
10147b200: 7900013f    	strh	wzr, [x9]
10147b204: f9010bf3    	str	x19, [sp, #0x210]
10147b208: f9010ff4    	str	x20, [sp, #0x218]
10147b20c: f90113f3    	str	x19, [sp, #0x220]
10147b210: b940dbe9    	ldr	w9, [sp, #0xd8]
10147b214: b9022be9    	str	w9, [sp, #0x228]
10147b218: b94107e9    	ldr	w9, [sp, #0x104]
10147b21c: 3908b3e9    	strb	w9, [sp, #0x22c]
10147b220: 390bffe8    	strb	w8, [sp, #0x2ff]
10147b224: f9400b14    	ldr	x20, [x24, #0x10]
10147b228: f9400308    	ldr	x8, [x24]
10147b22c: eb08029f    	cmp	x20, x8
10147b230: 54000061    	b.ne	0x10147b23c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x984>
10147b234: aa1803e0    	mov	x0, x24
10147b238: 9418574b    	bl	0x101a90f64 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hd7dc784ff2def722E>
10147b23c: f9400708    	ldr	x8, [x24, #0x8]
10147b240: 52802509    	mov	w9, #0x128              ; =296
10147b244: 9b092280    	madd	x0, x20, x9, x8
10147b248: 910783e1    	add	x1, sp, #0x1e0
10147b24c: 52802502    	mov	w2, #0x128              ; =296
10147b250: 94193a76    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147b254: 91000688    	add	x8, x20, #0x1
10147b258: f9000b08    	str	x8, [x24, #0x10]
10147b25c: a95d67e8    	ldp	x8, x25, [sp, #0x1d0]
10147b260: f9006be8    	str	x8, [sp, #0xd0]
10147b264: a9488700    	ldp	x0, x1, [x24, #0x88]
10147b268: 910723e2    	add	x2, sp, #0x1c8
10147b26c: 97d34984    	bl	0x10094d87c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a854>
10147b270: aa0003f6    	mov	x22, x0
10147b274: f9403f08    	ldr	x8, [x24, #0x78]
10147b278: b4001248    	cbz	x8, 0x10147b4c0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xc08>
10147b27c: d280000c    	mov	x12, #0x0               ; =0
10147b280: d2800009    	mov	x9, #0x0                ; =0
10147b284: a946d31b    	ldp	x27, x20, [x24, #0x68]
10147b288: d379fed8    	lsr	x24, x22, #57
10147b28c: 0e010f08    	dup.8b	v8, w24
10147b290: aa1903ea    	mov	x10, x25
10147b294: 8a1402d6    	and	x22, x22, x20
10147b298: fc766b69    	ldr	d9, [x27, x22]
10147b29c: 2e288d20    	cmeq.8b	v0, v9, v8
10147b2a0: 9e660008    	fmov	x8, d0
10147b2a4: f201c115    	ands	x21, x8, #0x8080808080808080
10147b2a8: 54000280    	b.eq	0x10147b2f8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xa40>
10147b2ac: a907a7ec    	stp	x12, x9, [sp, #0x78]
10147b2b0: dac002a8    	rbit	x8, x21
10147b2b4: dac01108    	clz	x8, x8
10147b2b8: 8b480ec8    	add	x8, x22, x8, lsr #3
10147b2bc: 8a140108    	and	x8, x8, x20
10147b2c0: cb08177a    	sub	x26, x27, x8, lsl #5
10147b2c4: f85f0348    	ldur	x8, [x26, #-0x10]
10147b2c8: eb08015f    	cmp	x10, x8
10147b2cc: 540000e1    	b.ne	0x10147b2e8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xa30>
10147b2d0: f85e8341    	ldur	x1, [x26, #-0x18]
10147b2d4: f9406be0    	ldr	x0, [sp, #0xd0]
10147b2d8: aa1903e2    	mov	x2, x25
10147b2dc: 94193a50    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10147b2e0: aa1903ea    	mov	x10, x25
10147b2e4: 34000420    	cbz	w0, 0x10147b368 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xab0>
10147b2e8: d10006a8    	sub	x8, x21, #0x1
10147b2ec: ea150115    	ands	x21, x8, x21
10147b2f0: a947a7ec    	ldp	x12, x9, [sp, #0x78]
10147b2f4: 54fffde1    	b.ne	0x10147b2b0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x9f8>
10147b2f8: f100059f    	cmp	x12, #0x1
10147b2fc: f9403beb    	ldr	x11, [sp, #0x70]
10147b300: 54000100    	b.eq	0x10147b320 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xa68>
10147b304: 0e20a920    	cmlt.8b	v0, v9, #0
10147b308: 9e660008    	fmov	x8, d0
10147b30c: b4000188    	cbz	x8, 0x10147b33c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xa84>
10147b310: dac00108    	rbit	x8, x8
10147b314: dac01108    	clz	x8, x8
10147b318: 8b480ec8    	add	x8, x22, x8, lsr #3
10147b31c: 8a14010b    	and	x11, x8, x20
10147b320: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
10147b324: 2e208d20    	cmeq.8b	v0, v9, v0
10147b328: 2e30a800    	umaxv.8b	b0, v0
10147b32c: 1e260008    	fmov	w8, s0
10147b330: 370003a8    	tbnz	w8, #0x0, 0x10147b3a4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xaec>
10147b334: 5280002c    	mov	w12, #0x1               ; =1
10147b338: 14000002    	b	0x10147b340 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xa88>
10147b33c: d280000c    	mov	x12, #0x0               ; =0
10147b340: f9003beb    	str	x11, [sp, #0x70]
10147b344: 91002129    	add	x9, x9, #0x8
10147b348: 8b160136    	add	x22, x9, x22
10147b34c: 8a1402d6    	and	x22, x22, x20
10147b350: fc766b69    	ldr	d9, [x27, x22]
10147b354: 2e288d20    	cmeq.8b	v0, v9, v8
10147b358: 9e660008    	fmov	x8, d0
10147b35c: f201c115    	ands	x21, x8, #0x8080808080808080
10147b360: 54fffa61    	b.ne	0x10147b2ac <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x9f4>
10147b364: 17ffffe5    	b	0x10147b2f8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xa40>
10147b368: f81f835c    	stur	x28, [x26, #-0x8]
10147b36c: f94067f9    	ldr	x25, [sp, #0xc8]
10147b370: b40000b9    	cbz	x25, 0x10147b384 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xacc>
10147b374: f9406be0    	ldr	x0, [sp, #0xd0]
10147b378: aa1903e1    	mov	x1, x25
10147b37c: 52800022    	mov	w2, #0x1                ; =1
10147b380: 97d88cd7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147b384: 52800016    	mov	w22, #0x0               ; =0
10147b388: f94087f8    	ldr	x24, [sp, #0x108]
10147b38c: 5280003b    	mov	w27, #0x1               ; =1
10147b390: f9402314    	ldr	x20, [x24, #0x40]
10147b394: f9401b08    	ldr	x8, [x24, #0x30]
10147b398: eb08029f    	cmp	x20, x8
10147b39c: 54000340    	b.eq	0x10147b404 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xb4c>
10147b3a0: 1400001b    	b	0x10147b40c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xb54>
10147b3a4: 38eb6b68    	ldrsb	w8, [x27, x11]
10147b3a8: 36f80988    	tbz	w8, #0x1f, 0x10147b4d8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xc20>
10147b3ac: 52800016    	mov	w22, #0x0               ; =0
10147b3b0: d1002169    	sub	x9, x11, #0x8
10147b3b4: 8a140129    	and	x9, x9, x20
10147b3b8: 92400108    	and	x8, x8, #0x1
10147b3bc: 382b6b78    	strb	w24, [x27, x11]
10147b3c0: 8b090369    	add	x9, x27, x9
10147b3c4: 39002138    	strb	w24, [x9, #0x8]
10147b3c8: f94087f8    	ldr	x24, [sp, #0x108]
10147b3cc: 3cc78300    	ldur	q0, [x24, #0x78]
10147b3d0: 6f07e7e1    	movi.2d	v1, #0xffffffffffffffff
10147b3d4: 4e081d01    	mov.d	v1[0], x8
10147b3d8: 6ee18400    	sub.2d	v0, v0, v1
10147b3dc: 3c878300    	stur	q0, [x24, #0x78]
10147b3e0: cb0b1768    	sub	x8, x27, x11, lsl #5
10147b3e4: a94ca7f9    	ldp	x25, x9, [sp, #0xc8]
10147b3e8: a93e2519    	stp	x25, x9, [x8, #-0x20]
10147b3ec: a93f710a    	stp	x10, x28, [x8, #-0x10]
10147b3f0: 5280003b    	mov	w27, #0x1               ; =1
10147b3f4: f9402314    	ldr	x20, [x24, #0x40]
10147b3f8: f9401b08    	ldr	x8, [x24, #0x30]
10147b3fc: eb08029f    	cmp	x20, x8
10147b400: 54000061    	b.ne	0x10147b40c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xb54>
10147b404: 9100c300    	add	x0, x24, #0x30
10147b408: 9418566f    	bl	0x101a90dc4 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h70c473af1edb3d44E>
10147b40c: f9401f08    	ldr	x8, [x24, #0x38]
10147b410: f834791c    	str	x28, [x8, x20, lsl #3]
10147b414: 91000688    	add	x8, x20, #0x1
10147b418: f9002308    	str	x8, [x24, #0x40]
10147b41c: b4000113    	cbz	x19, 0x10147b43c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xb84>
10147b420: 97d88cb4    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147b424: aa1303e0    	mov	x0, x19
10147b428: 52800021    	mov	w1, #0x1                ; =1
10147b42c: 97d88cab    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147b430: aa0003f4    	mov	x20, x0
10147b434: b5000060    	cbnz	x0, 0x10147b440 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xb88>
10147b438: 140003fa    	b	0x10147c420 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1b68>
10147b43c: 52800034    	mov	w20, #0x1               ; =1
10147b440: aa1403e0    	mov	x0, x20
10147b444: f94073e1    	ldr	x1, [sp, #0xe0]
10147b448: aa1303e2    	mov	x2, x19
10147b44c: 941939f7    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147b450: f9402701    	ldr	x1, [x24, #0x48]
10147b454: f240f83f    	tst	x1, #0x7fffffffffffffff
10147b458: 54000080    	b.eq	0x10147b468 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xbb0>
10147b45c: f9402b00    	ldr	x0, [x24, #0x50]
10147b460: 52800022    	mov	w2, #0x1                ; =1
10147b464: 97d88c9e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147b468: a904d313    	stp	x19, x20, [x24, #0x48]
10147b46c: f9002f13    	str	x19, [x24, #0x58]
10147b470: b940dbe8    	ldr	w8, [sp, #0xd8]
10147b474: b9006308    	str	w8, [x24, #0x60]
10147b478: f100033f    	cmp	x25, #0x0
10147b47c: 1a9603e8    	csel	w8, wzr, w22, eq
10147b480: b94107e9    	ldr	w9, [sp, #0x104]
10147b484: 39019309    	strb	w9, [x24, #0x64]
10147b488: 3607d2c8    	tbz	w8, #0x0, 0x10147aee0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x628>
10147b48c: f940ebe0    	ldr	x0, [sp, #0x1d0]
10147b490: aa1903e1    	mov	x1, x25
10147b494: 52800022    	mov	w2, #0x1                ; =1
10147b498: 97d88c91    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147b49c: 17fffe91    	b	0x10147aee0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x628>
10147b4a0: 52800034    	mov	w20, #0x1               ; =1
10147b4a4: aa1403e0    	mov	x0, x20
10147b4a8: f94073e1    	ldr	x1, [sp, #0xe0]
10147b4ac: aa1303e2    	mov	x2, x19
10147b4b0: 941939de    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147b4b4: f84302a1    	ldur	x1, [x21, #0x30]
10147b4b8: b5ffdec1    	cbnz	x1, 0x10147b090 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x7d8>
10147b4bc: 17fffef8    	b	0x10147b09c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x7e4>
10147b4c0: 9101a300    	add	x0, x24, #0x68
10147b4c4: 91022302    	add	x2, x24, #0x88
10147b4c8: 52800021    	mov	w1, #0x1                ; =1
10147b4cc: 52800023    	mov	w3, #0x1                ; =1
10147b4d0: 941856bf    	bl	0x101a90fcc <__ZN9hashbrown3raw21RawTable$LT$T$C$A$GT$14reserve_rehash17h2b70fbf93365d567E>
10147b4d4: 17ffff6a    	b	0x10147b27c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x9c4>
10147b4d8: fd400360    	ldr	d0, [x27]
10147b4dc: 0e20a800    	cmlt.8b	v0, v0, #0
10147b4e0: 9e660008    	fmov	x8, d0
10147b4e4: dac00108    	rbit	x8, x8
10147b4e8: dac01108    	clz	x8, x8
10147b4ec: d343fd0b    	lsr	x11, x8, #3
10147b4f0: 386b6b68    	ldrb	w8, [x27, x11]
10147b4f4: 17ffffae    	b	0x10147b3ac <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xaf4>
10147b4f8: f1000a9f    	cmp	x20, #0x2
10147b4fc: 54000f01    	b.ne	0x10147b6dc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xe24>
10147b500: f9004bf4    	str	x20, [sp, #0x90]
10147b504: a9556fea    	ldp	x10, x27, [sp, #0x150]
10147b508: f940b3e9    	ldr	x9, [sp, #0x160]
10147b50c: 52800308    	mov	w8, #0x18               ; =24
10147b510: 9b086d28    	madd	x8, x9, x8, x27
10147b514: a91a6ffb    	stp	x27, x27, [sp, #0x1a0]
10147b518: a90d23ea    	stp	x10, x8, [sp, #0xd0]
10147b51c: a91b23ea    	stp	x10, x8, [sp, #0x1b0]
10147b520: aa1b03e8    	mov	x8, x27
10147b524: f90067fb    	str	x27, [sp, #0xc8]
10147b528: b50002e9    	cbnz	x9, 0x10147b584 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xccc>
10147b52c: f9406fe8    	ldr	x8, [sp, #0xd8]
10147b530: eb1b0108    	subs	x8, x8, x27
10147b534: 54001320    	b.eq	0x10147b798 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xee0>
10147b538: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
10147b53c: f2955569    	movk	x9, #0xaaab
10147b540: 9bc97d08    	umulh	x8, x8, x9
10147b544: d344fd13    	lsr	x19, x8, #4
10147b548: 91002374    	add	x20, x27, #0x8
10147b54c: 14000004    	b	0x10147b55c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xca4>
10147b550: 91006294    	add	x20, x20, #0x18
10147b554: f1000673    	subs	x19, x19, #0x1
10147b558: 54001200    	b.eq	0x10147b798 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xee0>
10147b55c: f85f8281    	ldur	x1, [x20, #-0x8]
10147b560: b4ffff81    	cbz	x1, 0x10147b550 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xc98>
10147b564: f9400280    	ldr	x0, [x20]
10147b568: 52800022    	mov	w2, #0x1                ; =1
10147b56c: 97d88c5c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147b570: 17fffff8    	b	0x10147b550 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xc98>
10147b574: aa1b03e8    	mov	x8, x27
10147b578: f9406fe9    	ldr	x9, [sp, #0xd8]
10147b57c: eb09037f    	cmp	x27, x9
10147b580: 540010c0    	b.eq	0x10147b798 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xee0>
10147b584: 9100611b    	add	x27, x8, #0x18
10147b588: f900d7fb    	str	x27, [sp, #0x1a8]
10147b58c: f9400114    	ldr	x20, [x8]
10147b590: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10147b594: eb09029f    	cmp	x20, x9
10147b598: 54fffca0    	b.eq	0x10147b52c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xc74>
10147b59c: a9408513    	ldp	x19, x1, [x8, #0x8]
10147b5a0: d10203a8    	sub	x8, x29, #0x80
10147b5a4: aa1303e0    	mov	x0, x19
10147b5a8: a94b0be3    	ldp	x3, x2, [sp, #0xb0]
10147b5ac: a94a13e5    	ldp	x5, x4, [sp, #0xa0]
10147b5b0: f90073f3    	str	x19, [sp, #0xe0]
10147b5b4: 97fffa65    	bl	0x101479f48 <__ZN15otty_ssh_config4load15resolve_include17h5b4ceee53b87a305E>
10147b5b8: a9788bbc    	ldp	x28, x2, [x29, #-0x78]
10147b5bc: 910783e0    	add	x0, sp, #0x1e0
10147b5c0: aa1c03e1    	mov	x1, x28
10147b5c4: 97fff687    	bl	0x101478fe0 <__ZN15otty_ssh_config4glob10glob_match17h8c0e78a5c1c3a426E+0x18c>
10147b5c8: a95e67f8    	ldp	x24, x25, [sp, #0x1e0]
10147b5cc: f940fbe8    	ldr	x8, [sp, #0x1f0]
10147b5d0: 52800309    	mov	w9, #0x18               ; =24
10147b5d4: 9b096515    	madd	x21, x8, x9, x25
10147b5d8: f900f3f9    	str	x25, [sp, #0x1e0]
10147b5dc: a91f57f8    	stp	x24, x21, [sp, #0x1f0]
10147b5e0: aa1903f7    	mov	x23, x25
10147b5e4: b4000348    	cbz	x8, 0x10147b64c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xd94>
10147b5e8: 91006337    	add	x23, x25, #0x18
10147b5ec: 14000005    	b	0x10147b600 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xd48>
10147b5f0: 910062f7    	add	x23, x23, #0x18
10147b5f4: 91006348    	add	x8, x26, #0x18
10147b5f8: eb15011f    	cmp	x8, x21
10147b5fc: 540004c0    	b.eq	0x10147b694 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xddc>
10147b600: aa1703fa    	mov	x26, x23
10147b604: f85e8f56    	ldr	x22, [x26, #-0x18]!
10147b608: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10147b60c: eb0802df    	cmp	x22, x8
10147b610: 540001e0    	b.eq	0x10147b64c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xd94>
10147b614: a9408b53    	ldp	x19, x2, [x26, #0x8]
10147b618: a94e83e8    	ldp	x8, x0, [sp, #0xe8]
10147b61c: 91000504    	add	x4, x8, #0x1
10147b620: aa1303e1    	mov	x1, x19
10147b624: b94107e3    	ldr	w3, [sp, #0x104]
10147b628: f9407fe5    	ldr	x5, [sp, #0xf8]
10147b62c: f94087e6    	ldr	x6, [sp, #0x108]
10147b630: 97fffd78    	bl	0x10147ac10 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x358>
10147b634: b4fffdf6    	cbz	x22, 0x10147b5f0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xd38>
10147b638: aa1303e0    	mov	x0, x19
10147b63c: aa1603e1    	mov	x1, x22
10147b640: 52800022    	mov	w2, #0x1                ; =1
10147b644: 97d88c26    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147b648: 17ffffea    	b	0x10147b5f0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xd38>
10147b64c: f900f7f7    	str	x23, [sp, #0x1e8]
10147b650: eb1702a8    	subs	x8, x21, x23
10147b654: 54000200    	b.eq	0x10147b694 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xddc>
10147b658: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
10147b65c: f2955569    	movk	x9, #0xaaab
10147b660: 9bc97d08    	umulh	x8, x8, x9
10147b664: d344fd13    	lsr	x19, x8, #4
10147b668: 910022f5    	add	x21, x23, #0x8
10147b66c: 14000004    	b	0x10147b67c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xdc4>
10147b670: 910062b5    	add	x21, x21, #0x18
10147b674: f1000673    	subs	x19, x19, #0x1
10147b678: 540000e0    	b.eq	0x10147b694 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xddc>
10147b67c: f85f82a1    	ldur	x1, [x21, #-0x8]
10147b680: b4ffff81    	cbz	x1, 0x10147b670 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xdb8>
10147b684: f94002a0    	ldr	x0, [x21]
10147b688: 52800022    	mov	w2, #0x1                ; =1
10147b68c: 97d88c14    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147b690: 17fffff8    	b	0x10147b670 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xdb8>
10147b694: b40000d8    	cbz	x24, 0x10147b6ac <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xdf4>
10147b698: 8b180708    	add	x8, x24, x24, lsl #1
10147b69c: d37df101    	lsl	x1, x8, #3
10147b6a0: aa1903e0    	mov	x0, x25
10147b6a4: 52800102    	mov	w2, #0x8                ; =8
10147b6a8: 97d88c0d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147b6ac: f85803a1    	ldur	x1, [x29, #-0x80]
10147b6b0: b4000081    	cbz	x1, 0x10147b6c0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xe08>
10147b6b4: aa1c03e0    	mov	x0, x28
10147b6b8: 52800022    	mov	w2, #0x1                ; =1
10147b6bc: 97d88c08    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147b6c0: f94087f8    	ldr	x24, [sp, #0x108]
10147b6c4: b4fff594    	cbz	x20, 0x10147b574 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xcbc>
10147b6c8: f94073e0    	ldr	x0, [sp, #0xe0]
10147b6cc: aa1403e1    	mov	x1, x20
10147b6d0: 52800022    	mov	w2, #0x1                ; =1
10147b6d4: 97d88c02    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147b6d8: 17ffffa7    	b	0x10147b574 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xcbc>
10147b6dc: a9556bfc    	ldp	x28, x26, [sp, #0x150]
10147b6e0: 3cc18100    	ldur	q0, [x8, #0x18]
10147b6e4: 3d806be0    	str	q0, [sp, #0x1a0]
10147b6e8: f9401519    	ldr	x25, [x8, #0x28]
10147b6ec: f900dbf9    	str	x25, [sp, #0x1b0]
10147b6f0: f940d7f5    	ldr	x21, [sp, #0x1a8]
10147b6f4: b4005fd9    	cbz	x25, 0x10147c2ec <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a34>
10147b6f8: 52800016    	mov	w22, #0x0               ; =0
10147b6fc: f100375f    	cmp	x26, #0xd
10147b700: f9004bf4    	str	x20, [sp, #0x90]
10147b704: f90063f5    	str	x21, [sp, #0xc0]
10147b708: 540005cd    	b.le	0x10147b7c0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xf08>
10147b70c: f1003b5f    	cmp	x26, #0xe
10147b710: 54000780    	b.eq	0x10147b800 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xf48>
10147b714: f100535f    	cmp	x26, #0x14
10147b718: 540008c0    	b.eq	0x10147b830 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xf78>
10147b71c: f100635f    	cmp	x26, #0x18
10147b720: 54000be1    	b.ne	0x10147b89c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xfe4>
10147b724: a9402788    	ldp	x8, x9, [x28]
10147b728: f9400b8a    	ldr	x10, [x28, #0x10]
10147b72c: d28e4e0b    	mov	x11, #0x7270            ; =29296
10147b730: f2acccab    	movk	x11, #0x6665, lsl #16
10147b734: f2ce4cab    	movk	x11, #0x7265, lsl #32
10147b738: f2ecae4b    	movk	x11, #0x6572, lsl #48
10147b73c: eb0b011f    	cmp	x8, x11
10147b740: d28c2c88    	mov	x8, #0x6164             ; =24932
10147b744: f2ae8ea8    	movk	x8, #0x7475, lsl #16
10147b748: f2ccad08    	movk	x8, #0x6568, lsl #32
10147b74c: f2ee8dc8    	movk	x8, #0x746e, lsl #48
10147b750: fa480120    	ccmp	x9, x8, #0x0, eq
10147b754: d28c6d28    	mov	x8, #0x6369             ; =25449
10147b758: f2ae8c28    	movk	x8, #0x7461, lsl #16
10147b75c: f2cded28    	movk	x8, #0x6f69, lsl #32
10147b760: f2ee6dc8    	movk	x8, #0x736e, lsl #48
10147b764: 14000041    	b	0x10147b868 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xfb0>
10147b768: f94033e8    	ldr	x8, [sp, #0x60]
10147b76c: b40000c8    	cbz	x8, 0x10147b784 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xecc>
10147b770: 8b080508    	add	x8, x8, x8, lsl #1
10147b774: d37df101    	lsl	x1, x8, #3
10147b778: f9402fe0    	ldr	x0, [sp, #0x58]
10147b77c: 52800102    	mov	w2, #0x8                ; =8
10147b780: 97d88bd7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147b784: f9404bf4    	ldr	x20, [sp, #0x90]
10147b788: f94037e1    	ldr	x1, [sp, #0x68]
10147b78c: b4005c81    	cbz	x1, 0x10147c31c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a64>
10147b790: f94073e0    	ldr	x0, [sp, #0xe0]
10147b794: 140002e0    	b	0x10147c314 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a5c>
10147b798: 5280003b    	mov	w27, #0x1               ; =1
10147b79c: f9406be8    	ldr	x8, [sp, #0xd0]
10147b7a0: b40000c8    	cbz	x8, 0x10147b7b8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xf00>
10147b7a4: 8b080508    	add	x8, x8, x8, lsl #1
10147b7a8: d37df101    	lsl	x1, x8, #3
10147b7ac: f94067e0    	ldr	x0, [sp, #0xc8]
10147b7b0: 52800102    	mov	w2, #0x8                ; =8
10147b7b4: 97d88bca    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147b7b8: f9404bf4    	ldr	x20, [sp, #0x90]
10147b7bc: 140002d8    	b	0x10147c31c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a64>
10147b7c0: f100335f    	cmp	x26, #0xc
10147b7c4: 54000560    	b.eq	0x10147b870 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xfb8>
10147b7c8: f100375f    	cmp	x26, #0xd
10147b7cc: 54000681    	b.ne	0x10147b89c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xfe4>
10147b7d0: f9400388    	ldr	x8, [x28]
10147b7d4: f8405389    	ldur	x9, [x28, #0x5]
10147b7d8: d28c8d2a    	mov	x10, #0x6469            ; =25705
10147b7dc: f2adccaa    	movk	x10, #0x6e65, lsl #16
10147b7e0: f2cd2e8a    	movk	x10, #0x6974, lsl #32
10147b7e4: f2ef2e8a    	movk	x10, #0x7974, lsl #48
10147b7e8: eb0a011f    	cmp	x8, x10
10147b7ec: d28e8d28    	mov	x8, #0x7469             ; =29801
10147b7f0: f2ac2f28    	movk	x8, #0x6179, lsl #16
10147b7f4: f2ccace8    	movk	x8, #0x6567, lsl #32
10147b7f8: f2ee8dc8    	movk	x8, #0x746e, lsl #48
10147b7fc: 14000026    	b	0x10147b894 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xfdc>
10147b800: f9400388    	ldr	x8, [x28]
10147b804: f8406389    	ldur	x9, [x28, #0x6]
10147b808: d28c8d2a    	mov	x10, #0x6469            ; =25705
10147b80c: f2adccaa    	movk	x10, #0x6e65, lsl #16
10147b810: f2cd2e8a    	movk	x10, #0x6974, lsl #32
10147b814: f2ed2e8a    	movk	x10, #0x6974, lsl #48
10147b818: eb0a011f    	cmp	x8, x10
10147b81c: d28d2e88    	mov	x8, #0x6974             ; =26996
10147b820: f2ae6ca8    	movk	x8, #0x7365, lsl #16
10147b824: f2cdcde8    	movk	x8, #0x6e6f, lsl #32
10147b828: f2ef2d88    	movk	x8, #0x796c, lsl #48
10147b82c: 1400001a    	b	0x10147b894 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xfdc>
10147b830: a9402788    	ldp	x8, x9, [x28]
10147b834: b940138a    	ldr	w10, [x28, #0x10]
10147b838: d28eae0b    	mov	x11, #0x7570            ; =30064
10147b83c: f2ad6c4b    	movk	x11, #0x6b62, lsl #16
10147b840: f2cf2cab    	movk	x11, #0x7965, lsl #32
10147b844: f2eeac2b    	movk	x11, #0x7561, lsl #48
10147b848: eb0b011f    	cmp	x8, x11
10147b84c: d28d0e88    	mov	x8, #0x6874             ; =26740
10147b850: f2adcca8    	movk	x8, #0x6e65, lsl #16
10147b854: f2cd2e88    	movk	x8, #0x6974, lsl #32
10147b858: f2ec2c68    	movk	x8, #0x6163, lsl #48
10147b85c: fa480120    	ccmp	x9, x8, #0x0, eq
10147b860: 528d2e88    	mov	w8, #0x6974             ; =26996
10147b864: 72adcde8    	movk	w8, #0x6e6f, lsl #16
10147b868: fa480140    	ccmp	x10, x8, #0x0, eq
10147b86c: 1400000b    	b	0x10147b898 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0xfe0>
10147b870: f9400388    	ldr	x8, [x28]
10147b874: b9400b89    	ldr	w9, [x28, #0x8]
10147b878: d28c8d2a    	mov	x10, #0x6469            ; =25705
10147b87c: f2adccaa    	movk	x10, #0x6e65, lsl #16
10147b880: f2cd2e8a    	movk	x10, #0x6974, lsl #32
10147b884: f2ef2e8a    	movk	x10, #0x7974, lsl #48
10147b888: eb0a011f    	cmp	x8, x10
10147b88c: 528d2cc8    	mov	w8, #0x6966             ; =26982
10147b890: 72acad88    	movk	w8, #0x656c, lsl #16
10147b894: fa480120    	ccmp	x9, x8, #0x0, eq
10147b898: 1a9f17f6    	cset	w22, eq
10147b89c: f9402308    	ldr	x8, [x24, #0x40]
10147b8a0: b40050c8    	cbz	x8, 0x10147c2b8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a00>
10147b8a4: f9401f14    	ldr	x20, [x24, #0x38]
10147b8a8: 8b080e8a    	add	x10, x20, x8, lsl #3
10147b8ac: 91002288    	add	x8, x20, #0x8
10147b8b0: a940d709    	ldp	x9, x21, [x24, #0x8]
10147b8b4: a90da7ea    	stp	x10, x9, [sp, #0xd8]
10147b8b8: 39419309    	ldrb	w9, [x24, #0x64]
10147b8bc: b9007be9    	str	w9, [sp, #0x78]
10147b8c0: a944a70a    	ldp	x10, x9, [x24, #0x48]
10147b8c4: f90043ea    	str	x10, [sp, #0x80]
10147b8c8: a90527fc    	stp	x28, x9, [sp, #0x50]
10147b8cc: f9402f09    	ldr	x9, [x24, #0x58]
10147b8d0: f9006be9    	str	x9, [sp, #0xd0]
10147b8d4: b9406309    	ldr	w9, [x24, #0x60]
10147b8d8: b90073e9    	str	w9, [sp, #0x70]
10147b8dc: 52800309    	mov	w9, #0x18               ; =24
10147b8e0: f94063ea    	ldr	x10, [sp, #0xc0]
10147b8e4: 9b092b29    	madd	x9, x25, x9, x10
10147b8e8: f9000fe9    	str	x9, [sp, #0x18]
10147b8ec: f90017f7    	str	x23, [sp, #0x28]
10147b8f0: b90063f6    	str	w22, [sp, #0x60]
10147b8f4: f90037f5    	str	x21, [sp, #0x68]
10147b8f8: 1400000f    	b	0x10147b934 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x107c>
10147b8fc: 5280003c    	mov	w28, #0x1               ; =1
10147b900: aa1c03e0    	mov	x0, x28
10147b904: aa1603e2    	mov	x2, x22
10147b908: 941938c8    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147b90c: a9087276    	stp	x22, x28, [x19, #0x80]
10147b910: f9004a76    	str	x22, [x19, #0x90]
10147b914: f9402bfc    	ldr	x28, [sp, #0x50]
10147b918: b94063f6    	ldr	w22, [sp, #0x60]
10147b91c: f9406fe8    	ldr	x8, [sp, #0xd8]
10147b920: eb08029f    	cmp	x20, x8
10147b924: 52800108    	mov	w8, #0x8                ; =8
10147b928: 9a8803e8    	csel	x8, xzr, x8, eq
10147b92c: 8b080288    	add	x8, x20, x8
10147b930: 54004c40    	b.eq	0x10147c2b8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a00>
10147b934: f9400280    	ldr	x0, [x20]
10147b938: eb15001f    	cmp	x0, x21
10147b93c: 54005682    	b.hs	0x10147c40c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1b54>
10147b940: aa0803f4    	mov	x20, x8
10147b944: 52802508    	mov	w8, #0x128              ; =296
10147b948: f94073e9    	ldr	x9, [sp, #0xe0]
10147b94c: 9b082413    	madd	x19, x0, x8, x9
10147b950: 360004b6    	tbz	w22, #0x0, 0x10147b9e4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x112c>
10147b954: f9405a68    	ldr	x8, [x19, #0xb0]
10147b958: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10147b95c: eb09011f    	cmp	x8, x9
10147b960: 54000421    	b.ne	0x10147b9e4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x112c>
10147b964: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10147b968: f94043e9    	ldr	x9, [sp, #0x80]
10147b96c: eb08013f    	cmp	x9, x8
10147b970: 540002c0    	b.eq	0x10147b9c8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1110>
10147b974: f9406bf5    	ldr	x21, [sp, #0xd0]
10147b978: b40000f5    	cbz	x21, 0x10147b994 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x10dc>
10147b97c: 97d88b5d    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147b980: aa1503e0    	mov	x0, x21
10147b984: 52800021    	mov	w1, #0x1                ; =1
10147b988: 97d88b54    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147b98c: b5000060    	cbnz	x0, 0x10147b998 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x10e0>
10147b990: 140002b4    	b	0x10147c460 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1ba8>
10147b994: 52800020    	mov	w0, #0x1                ; =1
10147b998: f90067e0    	str	x0, [sp, #0xc8]
10147b99c: f9402fe1    	ldr	x1, [sp, #0x58]
10147b9a0: aa1503e2    	mov	x2, x21
10147b9a4: 941938a1    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147b9a8: f9405a61    	ldr	x1, [x19, #0xb0]
10147b9ac: f240f83f    	tst	x1, #0x7fffffffffffffff
10147b9b0: 54000080    	b.eq	0x10147b9c0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1108>
10147b9b4: f9405e60    	ldr	x0, [x19, #0xb8]
10147b9b8: 52800022    	mov	w2, #0x1                ; =1
10147b9bc: 97d88b48    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147b9c0: aa1503e8    	mov	x8, x21
10147b9c4: f94037f5    	ldr	x21, [sp, #0x68]
10147b9c8: f9005a68    	str	x8, [x19, #0xb0]
10147b9cc: a94ca3e9    	ldp	x9, x8, [sp, #0xc8]
10147b9d0: a90ba269    	stp	x9, x8, [x19, #0xb8]
10147b9d4: b94073e8    	ldr	w8, [sp, #0x70]
10147b9d8: b900ca68    	str	w8, [x19, #0xc8]
10147b9dc: b9407be8    	ldr	w8, [sp, #0x78]
10147b9e0: 39033268    	strb	w8, [x19, #0xcc]
10147b9e4: f100335f    	cmp	x26, #0xc
10147b9e8: 540003cc    	b.gt	0x10147ba60 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x11a8>
10147b9ec: f100235f    	cmp	x26, #0x8
10147b9f0: 54000a6c    	b.gt	0x10147bb3c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1284>
10147b9f4: f100135f    	cmp	x26, #0x4
10147b9f8: 54001760    	b.eq	0x10147bce4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x142c>
10147b9fc: f100235f    	cmp	x26, #0x8
10147ba00: 54fff8e1    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147ba04: f9400388    	ldr	x8, [x28]
10147ba08: d28ded09    	mov	x9, #0x6f68             ; =28520
10147ba0c: f2ae8e69    	movk	x9, #0x7473, lsl #16
10147ba10: f2cc2dc9    	movk	x9, #0x616e, lsl #32
10147ba14: f2ecada9    	movk	x9, #0x656d, lsl #48
10147ba18: eb09011f    	cmp	x8, x9
10147ba1c: 54fff801    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147ba20: f9402a68    	ldr	x8, [x19, #0x50]
10147ba24: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10147ba28: eb09011f    	cmp	x8, x9
10147ba2c: 54fff781    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147ba30: f94063e8    	ldr	x8, [sp, #0xc0]
10147ba34: a940d901    	ldp	x1, x22, [x8, #0x8]
10147ba38: b40037f6    	cbz	x22, 0x10147c134 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x187c>
10147ba3c: aa0103fc    	mov	x28, x1
10147ba40: 97d88b2c    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147ba44: aa1603e0    	mov	x0, x22
10147ba48: 52800021    	mov	w1, #0x1                ; =1
10147ba4c: 97d88b23    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147ba50: aa1c03e1    	mov	x1, x28
10147ba54: aa0003fc    	mov	x28, x0
10147ba58: b5003700    	cbnz	x0, 0x10147c138 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1880>
10147ba5c: 14000280    	b	0x10147c45c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1ba4>
10147ba60: f1004f5f    	cmp	x26, #0x13
10147ba64: 54000f4c    	b.gt	0x10147bc4c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1394>
10147ba68: f100375f    	cmp	x26, #0xd
10147ba6c: 54001700    	b.eq	0x10147bd4c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1494>
10147ba70: f1003b5f    	cmp	x26, #0xe
10147ba74: 54fff541    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147ba78: f9400388    	ldr	x8, [x28]
10147ba7c: f8406389    	ldur	x9, [x28, #0x6]
10147ba80: d28c8d2a    	mov	x10, #0x6469            ; =25705
10147ba84: f2adccaa    	movk	x10, #0x6e65, lsl #16
10147ba88: f2cd2e8a    	movk	x10, #0x6974, lsl #32
10147ba8c: f2ed2e8a    	movk	x10, #0x6974, lsl #48
10147ba90: eb0a011f    	cmp	x8, x10
10147ba94: d28d2e88    	mov	x8, #0x6974             ; =26996
10147ba98: f2ae6ca8    	movk	x8, #0x7365, lsl #16
10147ba9c: f2cdcde8    	movk	x8, #0x6e6f, lsl #32
10147baa0: f2ef2d88    	movk	x8, #0x796c, lsl #48
10147baa4: fa480120    	ccmp	x9, x8, #0x0, eq
10147baa8: 54fff3a1    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147baac: 39448268    	ldrb	w8, [x19, #0x120]
10147bab0: 7100091f    	cmp	w8, #0x2
10147bab4: 54fff341    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bab8: f94063e9    	ldr	x9, [sp, #0xc0]
10147babc: a940a528    	ldp	x8, x9, [x9, #0x8]
10147bac0: f100093f    	cmp	x9, #0x2
10147bac4: 540037a0    	b.eq	0x10147c1b8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1900>
10147bac8: f1000d3f    	cmp	x9, #0x3
10147bacc: 54fff281    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bad0: 39400109    	ldrb	w9, [x8]
10147bad4: 5101052a    	sub	w10, w9, #0x41
10147bad8: 7100695f    	cmp	w10, #0x1a
10147badc: 5280040a    	mov	w10, #0x20              ; =32
10147bae0: 1a9f314a    	csel	w10, w10, wzr, lo
10147bae4: 2a090149    	orr	w9, w10, w9
10147bae8: 7101e53f    	cmp	w9, #0x79
10147baec: 54fff181    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147baf0: 39400509    	ldrb	w9, [x8, #0x1]
10147baf4: 5101052a    	sub	w10, w9, #0x41
10147baf8: 7100695f    	cmp	w10, #0x1a
10147bafc: 5280040a    	mov	w10, #0x20              ; =32
10147bb00: 1a9f314a    	csel	w10, w10, wzr, lo
10147bb04: 2a090149    	orr	w9, w10, w9
10147bb08: 7101953f    	cmp	w9, #0x65
10147bb0c: 54fff081    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bb10: 39400908    	ldrb	w8, [x8, #0x2]
10147bb14: 51010509    	sub	w9, w8, #0x41
10147bb18: 7100693f    	cmp	w9, #0x1a
10147bb1c: 52800409    	mov	w9, #0x20               ; =32
10147bb20: 1a9f3129    	csel	w9, w9, wzr, lo
10147bb24: 2a080128    	orr	w8, w9, w8
10147bb28: 7101cd1f    	cmp	w8, #0x73
10147bb2c: 54ffef81    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bb30: 52800029    	mov	w9, #0x1                ; =1
10147bb34: 39048269    	strb	w9, [x19, #0x120]
10147bb38: 17ffff79    	b	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bb3c: f100275f    	cmp	x26, #0x9
10147bb40: 54001400    	b.eq	0x10147bdc0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1508>
10147bb44: f100335f    	cmp	x26, #0xc
10147bb48: 54ffeea1    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bb4c: f9400388    	ldr	x8, [x28]
10147bb50: b9400b89    	ldr	w9, [x28, #0x8]
10147bb54: d28c8d2a    	mov	x10, #0x6469            ; =25705
10147bb58: f2adccaa    	movk	x10, #0x6e65, lsl #16
10147bb5c: f2cd2e8a    	movk	x10, #0x6974, lsl #32
10147bb60: f2ef2e8a    	movk	x10, #0x7974, lsl #48
10147bb64: eb0a011f    	cmp	x8, x10
10147bb68: 528d2cc8    	mov	w8, #0x6966             ; =26982
10147bb6c: 72acad88    	movk	w8, #0x656c, lsl #16
10147bb70: fa480120    	ccmp	x9, x8, #0x0, eq
10147bb74: 54002380    	b.eq	0x10147bfe4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x172c>
10147bb78: f9400388    	ldr	x8, [x28]
10147bb7c: b9400b89    	ldr	w9, [x28, #0x8]
10147bb80: d28e4e0a    	mov	x10, #0x7270            ; =29296
10147bb84: f2af0dea    	movk	x10, #0x786f, lsl #16
10147bb88: f2cc6f2a    	movk	x10, #0x6379, lsl #32
10147bb8c: f2edadea    	movk	x10, #0x6d6f, lsl #48
10147bb90: eb0a011f    	cmp	x8, x10
10147bb94: 528c2da8    	mov	w8, #0x616d             ; =24941
10147bb98: 72ac8dc8    	movk	w8, #0x646e, lsl #16
10147bb9c: 7a480120    	ccmp	w9, w8, #0x0, eq
10147bba0: 54ffebe1    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bba4: 39447668    	ldrb	w8, [x19, #0x11d]
10147bba8: 3707eba8    	tbnz	w8, #0x0, 0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bbac: 3904767b    	strb	w27, [x19, #0x11d]
10147bbb0: f94063e0    	ldr	x0, [sp, #0xc0]
10147bbb4: f9400808    	ldr	x8, [x0, #0x10]
10147bbb8: f100111f    	cmp	x8, #0x4
10147bbbc: 54002621    	b.ne	0x10147c080 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x17c8>
10147bbc0: f9400408    	ldr	x8, [x0, #0x8]
10147bbc4: 39400109    	ldrb	w9, [x8]
10147bbc8: 5101052a    	sub	w10, w9, #0x41
10147bbcc: 7100695f    	cmp	w10, #0x1a
10147bbd0: 5280040a    	mov	w10, #0x20              ; =32
10147bbd4: 1a9f314a    	csel	w10, w10, wzr, lo
10147bbd8: 2a090149    	orr	w9, w10, w9
10147bbdc: 7101b93f    	cmp	w9, #0x6e
10147bbe0: 54002501    	b.ne	0x10147c080 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x17c8>
10147bbe4: 39400509    	ldrb	w9, [x8, #0x1]
10147bbe8: 5101052a    	sub	w10, w9, #0x41
10147bbec: 7100695f    	cmp	w10, #0x1a
10147bbf0: 5280040a    	mov	w10, #0x20              ; =32
10147bbf4: 1a9f314a    	csel	w10, w10, wzr, lo
10147bbf8: 2a090149    	orr	w9, w10, w9
10147bbfc: 7101bd3f    	cmp	w9, #0x6f
10147bc00: 54002401    	b.ne	0x10147c080 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x17c8>
10147bc04: 39400909    	ldrb	w9, [x8, #0x2]
10147bc08: 5101052a    	sub	w10, w9, #0x41
10147bc0c: 7100695f    	cmp	w10, #0x1a
10147bc10: 5280040a    	mov	w10, #0x20              ; =32
10147bc14: 1a9f314a    	csel	w10, w10, wzr, lo
10147bc18: 2a090149    	orr	w9, w10, w9
10147bc1c: 7101b93f    	cmp	w9, #0x6e
10147bc20: 54002301    	b.ne	0x10147c080 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x17c8>
10147bc24: 39400d08    	ldrb	w8, [x8, #0x3]
10147bc28: 51010509    	sub	w9, w8, #0x41
10147bc2c: 7100693f    	cmp	w9, #0x1a
10147bc30: 52800409    	mov	w9, #0x20               ; =32
10147bc34: 1a9f3129    	csel	w9, w9, wzr, lo
10147bc38: 2a080128    	orr	w8, w9, w8
10147bc3c: 7101951f    	cmp	w8, #0x65
10147bc40: 54002201    	b.ne	0x10147c080 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x17c8>
10147bc44: 3904727f    	strb	wzr, [x19, #0x11c]
10147bc48: 17ffff35    	b	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bc4c: f100535f    	cmp	x26, #0x14
10147bc50: 54001420    	b.eq	0x10147bed4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x161c>
10147bc54: f100635f    	cmp	x26, #0x18
10147bc58: 54ffe621    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bc5c: a9402788    	ldp	x8, x9, [x28]
10147bc60: f9400b8a    	ldr	x10, [x28, #0x10]
10147bc64: d28e4e0b    	mov	x11, #0x7270            ; =29296
10147bc68: f2acccab    	movk	x11, #0x6665, lsl #16
10147bc6c: f2ce4cab    	movk	x11, #0x7265, lsl #32
10147bc70: f2ecae4b    	movk	x11, #0x6572, lsl #48
10147bc74: eb0b011f    	cmp	x8, x11
10147bc78: d28c2c88    	mov	x8, #0x6164             ; =24932
10147bc7c: f2ae8ea8    	movk	x8, #0x7475, lsl #16
10147bc80: f2ccad08    	movk	x8, #0x6568, lsl #32
10147bc84: f2ee8dc8    	movk	x8, #0x746e, lsl #48
10147bc88: fa480120    	ccmp	x9, x8, #0x0, eq
10147bc8c: d28c6d28    	mov	x8, #0x6369             ; =25449
10147bc90: f2ae8c28    	movk	x8, #0x7461, lsl #16
10147bc94: f2cded28    	movk	x8, #0x6f69, lsl #32
10147bc98: f2ee6dc8    	movk	x8, #0x736e, lsl #48
10147bc9c: fa480140    	ccmp	x10, x8, #0x0, eq
10147bca0: 54ffe3e1    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bca4: f9404e68    	ldr	x8, [x19, #0x98]
10147bca8: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10147bcac: eb09011f    	cmp	x8, x9
10147bcb0: 54ffe361    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bcb4: f94063e8    	ldr	x8, [sp, #0xc0]
10147bcb8: a940d901    	ldp	x1, x22, [x8, #0x8]
10147bcbc: b40024b6    	cbz	x22, 0x10147c150 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1898>
10147bcc0: aa0103fc    	mov	x28, x1
10147bcc4: 97d88a8b    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147bcc8: aa1603e0    	mov	x0, x22
10147bccc: 52800021    	mov	w1, #0x1                ; =1
10147bcd0: 97d88a82    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147bcd4: aa1c03e1    	mov	x1, x28
10147bcd8: aa0003fc    	mov	x28, x0
10147bcdc: b50023c0    	cbnz	x0, 0x10147c154 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x189c>
10147bce0: 140001df    	b	0x10147c45c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1ba4>
10147bce4: b9400388    	ldr	w8, [x28]
10147bce8: 528e6ea9    	mov	w9, #0x7375             ; =29557
10147bcec: 72ae4ca9    	movk	w9, #0x7265, lsl #16
10147bcf0: 6b09011f    	cmp	w8, w9
10147bcf4: 54001580    	b.eq	0x10147bfa4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x16ec>
10147bcf8: b9400388    	ldr	w8, [x28]
10147bcfc: 528dee09    	mov	w9, #0x6f70             ; =28528
10147bd00: 72ae8e49    	movk	w9, #0x7472, lsl #16
10147bd04: 6b09011f    	cmp	w8, w9
10147bd08: 54ffe0a1    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bd0c: 79423268    	ldrh	w8, [x19, #0x118]
10147bd10: 3707e068    	tbnz	w8, #0x0, 0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bd14: f94063e8    	ldr	x8, [sp, #0xc0]
10147bd18: f940090a    	ldr	x10, [x8, #0x10]
10147bd1c: b400274a    	cbz	x10, 0x10147c204 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x194c>
10147bd20: f9400509    	ldr	x9, [x8, #0x8]
10147bd24: f100055f    	cmp	x10, #0x1
10147bd28: 54002781    	b.ne	0x10147c218 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1960>
10147bd2c: 52800008    	mov	w8, #0x0                ; =0
10147bd30: 3940012c    	ldrb	w12, [x9]
10147bd34: 5280000b    	mov	w11, #0x0               ; =0
10147bd38: 7100ad9f    	cmp	w12, #0x2b
10147bd3c: 54002680    	b.eq	0x10147c20c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1954>
10147bd40: 7100b59f    	cmp	w12, #0x2d
10147bd44: 54002640    	b.eq	0x10147c20c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1954>
10147bd48: 14000135    	b	0x10147c21c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1964>
10147bd4c: f9400388    	ldr	x8, [x28]
10147bd50: f8405389    	ldur	x9, [x28, #0x5]
10147bd54: d28c8d2a    	mov	x10, #0x6469            ; =25705
10147bd58: f2adccaa    	movk	x10, #0x6e65, lsl #16
10147bd5c: f2cd2e8a    	movk	x10, #0x6974, lsl #32
10147bd60: f2ef2e8a    	movk	x10, #0x7974, lsl #48
10147bd64: eb0a011f    	cmp	x8, x10
10147bd68: d28e8d28    	mov	x8, #0x7469             ; =29801
10147bd6c: f2ac2f28    	movk	x8, #0x6179, lsl #16
10147bd70: f2ccace8    	movk	x8, #0x6567, lsl #32
10147bd74: f2ee8dc8    	movk	x8, #0x746e, lsl #48
10147bd78: fa480120    	ccmp	x9, x8, #0x0, eq
10147bd7c: 54ffdd01    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bd80: f9404268    	ldr	x8, [x19, #0x80]
10147bd84: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10147bd88: eb09011f    	cmp	x8, x9
10147bd8c: 54ffdc81    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bd90: f94063e8    	ldr	x8, [sp, #0xc0]
10147bd94: a940d901    	ldp	x1, x22, [x8, #0x8]
10147bd98: b4ffdb36    	cbz	x22, 0x10147b8fc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1044>
10147bd9c: aa0103fc    	mov	x28, x1
10147bda0: 97d88a54    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147bda4: aa1603e0    	mov	x0, x22
10147bda8: 52800021    	mov	w1, #0x1                ; =1
10147bdac: 97d88a4b    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147bdb0: aa1c03e1    	mov	x1, x28
10147bdb4: aa0003fc    	mov	x28, x0
10147bdb8: b5ffda40    	cbnz	x0, 0x10147b900 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1048>
10147bdbc: 140001a8    	b	0x10147c45c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1ba4>
10147bdc0: f9400388    	ldr	x8, [x28]
10147bdc4: 39402389    	ldrb	w9, [x28, #0x8]
10147bdc8: d28e4e0a    	mov	x10, #0x7270            ; =29296
10147bdcc: f2af0dea    	movk	x10, #0x786f, lsl #16
10147bdd0: f2cd4f2a    	movk	x10, #0x6a79, lsl #32
10147bdd4: f2edaeaa    	movk	x10, #0x6d75, lsl #48
10147bdd8: eb0a011f    	cmp	x8, x10
10147bddc: 52800e08    	mov	w8, #0x70               ; =112
10147bde0: 7a480120    	ccmp	w9, w8, #0x0, eq
10147bde4: 54ffd9c1    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bde8: 39447a68    	ldrb	w8, [x19, #0x11e]
10147bdec: 3707d988    	tbnz	w8, #0x0, 0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bdf0: 39447668    	ldrb	w8, [x19, #0x11d]
10147bdf4: 3707d948    	tbnz	w8, #0x0, 0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bdf8: 39047a7b    	strb	w27, [x19, #0x11e]
10147bdfc: f94063e8    	ldr	x8, [sp, #0xc0]
10147be00: f9400908    	ldr	x8, [x8, #0x10]
10147be04: f100111f    	cmp	x8, #0x4
10147be08: 54000461    	b.ne	0x10147be94 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x15dc>
10147be0c: f94063e8    	ldr	x8, [sp, #0xc0]
10147be10: f9400508    	ldr	x8, [x8, #0x8]
10147be14: 39400109    	ldrb	w9, [x8]
10147be18: 5101052a    	sub	w10, w9, #0x41
10147be1c: 7100695f    	cmp	w10, #0x1a
10147be20: 5280040a    	mov	w10, #0x20              ; =32
10147be24: 1a9f314a    	csel	w10, w10, wzr, lo
10147be28: 2a090149    	orr	w9, w10, w9
10147be2c: 7101b93f    	cmp	w9, #0x6e
10147be30: 54000321    	b.ne	0x10147be94 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x15dc>
10147be34: 39400509    	ldrb	w9, [x8, #0x1]
10147be38: 5101052a    	sub	w10, w9, #0x41
10147be3c: 7100695f    	cmp	w10, #0x1a
10147be40: 5280040a    	mov	w10, #0x20              ; =32
10147be44: 1a9f314a    	csel	w10, w10, wzr, lo
10147be48: 2a090149    	orr	w9, w10, w9
10147be4c: 7101bd3f    	cmp	w9, #0x6f
10147be50: 54000221    	b.ne	0x10147be94 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x15dc>
10147be54: 39400909    	ldrb	w9, [x8, #0x2]
10147be58: 5101052a    	sub	w10, w9, #0x41
10147be5c: 7100695f    	cmp	w10, #0x1a
10147be60: 5280040a    	mov	w10, #0x20              ; =32
10147be64: 1a9f314a    	csel	w10, w10, wzr, lo
10147be68: 2a090149    	orr	w9, w10, w9
10147be6c: 7101b93f    	cmp	w9, #0x6e
10147be70: 54000121    	b.ne	0x10147be94 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x15dc>
10147be74: 39400d08    	ldrb	w8, [x8, #0x3]
10147be78: 51010509    	sub	w9, w8, #0x41
10147be7c: 7100693f    	cmp	w9, #0x1a
10147be80: 52800409    	mov	w9, #0x20               ; =32
10147be84: 1a9f3129    	csel	w9, w9, wzr, lo
10147be88: 2a080128    	orr	w8, w9, w8
10147be8c: 7101951f    	cmp	w8, #0x65
10147be90: 54ffd460    	b.eq	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147be94: 910783e8    	add	x8, sp, #0x1e0
10147be98: f94063e0    	ldr	x0, [sp, #0xc0]
10147be9c: 940e4ccc    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10147bea0: aa1303f5    	mov	x21, x19
10147bea4: f84d0ea1    	ldr	x1, [x21, #0xd0]!
10147bea8: f240f83f    	tst	x1, #0x7fffffffffffffff
10147beac: 54000080    	b.eq	0x10147bebc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1604>
10147beb0: f9406e60    	ldr	x0, [x19, #0xd8]
10147beb4: 52800022    	mov	w2, #0x1                ; =1
10147beb8: 97d88a09    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147bebc: 3dc07be0    	ldr	q0, [sp, #0x1e0]
10147bec0: 3d8002a0    	str	q0, [x21]
10147bec4: f940fbe8    	ldr	x8, [sp, #0x1f0]
10147bec8: f9000aa8    	str	x8, [x21, #0x10]
10147becc: 3904767b    	strb	w27, [x19, #0x11d]
10147bed0: 1400008f    	b	0x10147c10c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1854>
10147bed4: a9402788    	ldp	x8, x9, [x28]
10147bed8: b940138a    	ldr	w10, [x28, #0x10]
10147bedc: d28eae0b    	mov	x11, #0x7570            ; =30064
10147bee0: f2ad6c4b    	movk	x11, #0x6b62, lsl #16
10147bee4: f2cf2cab    	movk	x11, #0x7965, lsl #32
10147bee8: f2eeac2b    	movk	x11, #0x7561, lsl #48
10147beec: eb0b011f    	cmp	x8, x11
10147bef0: d28d0e88    	mov	x8, #0x6874             ; =26740
10147bef4: f2adcca8    	movk	x8, #0x6e65, lsl #16
10147bef8: f2cd2e88    	movk	x8, #0x6974, lsl #32
10147befc: f2ec2c68    	movk	x8, #0x6163, lsl #48
10147bf00: fa480120    	ccmp	x9, x8, #0x0, eq
10147bf04: 528d2e88    	mov	w8, #0x6974             ; =26996
10147bf08: 72adcde8    	movk	w8, #0x6e6f, lsl #16
10147bf0c: fa480140    	ccmp	x10, x8, #0x0, eq
10147bf10: 54ffd061    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bf14: 39448668    	ldrb	w8, [x19, #0x121]
10147bf18: 7100091f    	cmp	w8, #0x2
10147bf1c: 54ffd001    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bf20: f94063e9    	ldr	x9, [sp, #0xc0]
10147bf24: a940a528    	ldp	x8, x9, [x9, #0x8]
10147bf28: f100093f    	cmp	x9, #0x2
10147bf2c: 54001200    	b.eq	0x10147c16c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x18b4>
10147bf30: f1000d3f    	cmp	x9, #0x3
10147bf34: 54ffcf41    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bf38: 39400109    	ldrb	w9, [x8]
10147bf3c: 5101052a    	sub	w10, w9, #0x41
10147bf40: 7100695f    	cmp	w10, #0x1a
10147bf44: 5280040a    	mov	w10, #0x20              ; =32
10147bf48: 1a9f314a    	csel	w10, w10, wzr, lo
10147bf4c: 2a090149    	orr	w9, w10, w9
10147bf50: 7101e53f    	cmp	w9, #0x79
10147bf54: 54ffce41    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bf58: 39400509    	ldrb	w9, [x8, #0x1]
10147bf5c: 5101052a    	sub	w10, w9, #0x41
10147bf60: 7100695f    	cmp	w10, #0x1a
10147bf64: 5280040a    	mov	w10, #0x20              ; =32
10147bf68: 1a9f314a    	csel	w10, w10, wzr, lo
10147bf6c: 2a090149    	orr	w9, w10, w9
10147bf70: 7101953f    	cmp	w9, #0x65
10147bf74: 54ffcd41    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bf78: 39400908    	ldrb	w8, [x8, #0x2]
10147bf7c: 51010509    	sub	w9, w8, #0x41
10147bf80: 7100693f    	cmp	w9, #0x1a
10147bf84: 52800409    	mov	w9, #0x20               ; =32
10147bf88: 1a9f3129    	csel	w9, w9, wzr, lo
10147bf8c: 2a080128    	orr	w8, w9, w8
10147bf90: 7101cd1f    	cmp	w8, #0x73
10147bf94: 54ffcc41    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bf98: 52800029    	mov	w9, #0x1                ; =1
10147bf9c: 39048669    	strb	w9, [x19, #0x121]
10147bfa0: 17fffe5f    	b	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bfa4: f9403668    	ldr	x8, [x19, #0x68]
10147bfa8: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10147bfac: eb09011f    	cmp	x8, x9
10147bfb0: 54ffcb61    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147bfb4: f94063e8    	ldr	x8, [sp, #0xc0]
10147bfb8: a940d901    	ldp	x1, x22, [x8, #0x8]
10147bfbc: b4000af6    	cbz	x22, 0x10147c118 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1860>
10147bfc0: aa0103fc    	mov	x28, x1
10147bfc4: 97d889cb    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10147bfc8: aa1603e0    	mov	x0, x22
10147bfcc: 52800021    	mov	w1, #0x1                ; =1
10147bfd0: 97d889c2    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10147bfd4: aa1c03e1    	mov	x1, x28
10147bfd8: aa0003fc    	mov	x28, x0
10147bfdc: b5000a00    	cbnz	x0, 0x10147c11c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1864>
10147bfe0: 1400011f    	b	0x10147c45c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1ba4>
10147bfe4: f94063f5    	ldr	x21, [sp, #0xc0]
10147bfe8: f9400ffb    	ldr	x27, [sp, #0x18]
10147bfec: aa1503e8    	mov	x8, x21
10147bff0: eb1b011f    	cmp	x8, x27
10147bff4: 540008a0    	b.eq	0x10147c108 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1850>
10147bff8: 91006115    	add	x21, x8, #0x18
10147bffc: f9400909    	ldr	x9, [x8, #0x10]
10147c000: aa1503e8    	mov	x8, x21
10147c004: b4ffff69    	cbz	x9, 0x10147bff0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1738>
10147c008: d10062a0    	sub	x0, x21, #0x18
10147c00c: 910783e8    	add	x8, sp, #0x1e0
10147c010: 940e4c6f    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10147c014: f940f3f6    	ldr	x22, [sp, #0x1e0]
10147c018: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10147c01c: eb0802df    	cmp	x22, x8
10147c020: 54000740    	b.eq	0x10147c108 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1850>
10147c024: a95edfe8    	ldp	x8, x23, [sp, #0x1e8]
10147c028: f9001be8    	str	x8, [sp, #0x30]
10147c02c: f940167c    	ldr	x28, [x19, #0x28]
10147c030: f9400e68    	ldr	x8, [x19, #0x18]
10147c034: eb08039f    	cmp	x28, x8
10147c038: 540000e1    	b.ne	0x10147c054 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x179c>
10147c03c: 91006260    	add	x0, x19, #0x18
10147c040: aa1c03e1    	mov	x1, x28
10147c044: 52800022    	mov	w2, #0x1                ; =1
10147c048: 52800103    	mov	w3, #0x8                ; =8
10147c04c: 52800304    	mov	w4, #0x18               ; =24
10147c050: 9416b200    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10147c054: f9401268    	ldr	x8, [x19, #0x20]
10147c058: 52800309    	mov	w9, #0x18               ; =24
10147c05c: 9b092388    	madd	x8, x28, x9, x8
10147c060: f9401be9    	ldr	x9, [sp, #0x30]
10147c064: a9002516    	stp	x22, x9, [x8]
10147c068: f9000917    	str	x23, [x8, #0x10]
10147c06c: 91000788    	add	x8, x28, #0x1
10147c070: f9001668    	str	x8, [x19, #0x28]
10147c074: f94017f7    	ldr	x23, [sp, #0x28]
10147c078: f9402bfc    	ldr	x28, [sp, #0x50]
10147c07c: 17ffffdc    	b	0x10147bfec <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1734>
10147c080: 3904727b    	strb	w27, [x19, #0x11c]
10147c084: 910783e8    	add	x8, sp, #0x1e0
10147c088: aa1903e1    	mov	x1, x25
10147c08c: 97fff665    	bl	0x101479a20 <__ZN15otty_ssh_config4load13managed_proxy17had9160ed5674a0a7E>
10147c090: f940f3e8    	ldr	x8, [sp, #0x1e0]
10147c094: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10147c098: eb09011f    	cmp	x8, x9
10147c09c: 54ffc400    	b.eq	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147c0a0: 3947e3e8    	ldrb	w8, [sp, #0x1f8]
10147c0a4: f94103f5    	ldr	x21, [sp, #0x200]
10147c0a8: f94107f6    	ldr	x22, [sp, #0x208]
10147c0ac: f9410bf7    	ldr	x23, [sp, #0x210]
10147c0b0: aa1303f8    	mov	x24, x19
10147c0b4: f84e8f01    	ldr	x1, [x24, #0xe8]!
10147c0b8: 3900eb08    	strb	w8, [x24, #0x3a]
10147c0bc: f240f83f    	tst	x1, #0x7fffffffffffffff
10147c0c0: 54000080    	b.eq	0x10147c0d0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1818>
10147c0c4: f9407a60    	ldr	x0, [x19, #0xf0]
10147c0c8: 52800022    	mov	w2, #0x1                ; =1
10147c0cc: 97d88984    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c0d0: 3dc07be0    	ldr	q0, [sp, #0x1e0]
10147c0d4: 3d800300    	str	q0, [x24]
10147c0d8: f940fbe8    	ldr	x8, [sp, #0x1f0]
10147c0dc: f9000b08    	str	x8, [x24, #0x10]
10147c0e0: f9408261    	ldr	x1, [x19, #0x100]
10147c0e4: f240f83f    	tst	x1, #0x7fffffffffffffff
10147c0e8: 54000080    	b.eq	0x10147c0f8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1840>
10147c0ec: f9408660    	ldr	x0, [x19, #0x108]
10147c0f0: 52800022    	mov	w2, #0x1                ; =1
10147c0f4: 97d8897a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c0f8: a9105a75    	stp	x21, x22, [x19, #0x100]
10147c0fc: f9008a77    	str	x23, [x19, #0x110]
10147c100: f94087f8    	ldr	x24, [sp, #0x108]
10147c104: f94017f7    	ldr	x23, [sp, #0x28]
10147c108: 5280003b    	mov	w27, #0x1               ; =1
10147c10c: b94063f6    	ldr	w22, [sp, #0x60]
10147c110: f94037f5    	ldr	x21, [sp, #0x68]
10147c114: 17fffe02    	b	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147c118: 5280003c    	mov	w28, #0x1               ; =1
10147c11c: aa1c03e0    	mov	x0, x28
10147c120: aa1603e2    	mov	x2, x22
10147c124: 941936c1    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147c128: a906f276    	stp	x22, x28, [x19, #0x68]
10147c12c: f9003e76    	str	x22, [x19, #0x78]
10147c130: 17fffdf9    	b	0x10147b914 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x105c>
10147c134: 5280003c    	mov	w28, #0x1               ; =1
10147c138: aa1c03e0    	mov	x0, x28
10147c13c: aa1603e2    	mov	x2, x22
10147c140: 941936ba    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147c144: a9057276    	stp	x22, x28, [x19, #0x50]
10147c148: f9003276    	str	x22, [x19, #0x60]
10147c14c: 17fffdf2    	b	0x10147b914 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x105c>
10147c150: 5280003c    	mov	w28, #0x1               ; =1
10147c154: aa1c03e0    	mov	x0, x28
10147c158: aa1603e2    	mov	x2, x22
10147c15c: 941936b3    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10147c160: a909f276    	stp	x22, x28, [x19, #0x98]
10147c164: f9005676    	str	x22, [x19, #0xa8]
10147c168: 17fffdeb    	b	0x10147b914 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x105c>
10147c16c: 39400109    	ldrb	w9, [x8]
10147c170: 5101052a    	sub	w10, w9, #0x41
10147c174: 7100695f    	cmp	w10, #0x1a
10147c178: 5280040a    	mov	w10, #0x20              ; =32
10147c17c: 1a9f314a    	csel	w10, w10, wzr, lo
10147c180: 2a090149    	orr	w9, w10, w9
10147c184: 7101b93f    	cmp	w9, #0x6e
10147c188: 54ffbca1    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147c18c: 52800009    	mov	w9, #0x0                ; =0
10147c190: 39400508    	ldrb	w8, [x8, #0x1]
10147c194: 5101050a    	sub	w10, w8, #0x41
10147c198: 7100695f    	cmp	w10, #0x1a
10147c19c: 5280040a    	mov	w10, #0x20              ; =32
10147c1a0: 1a9f314a    	csel	w10, w10, wzr, lo
10147c1a4: 2a080148    	orr	w8, w10, w8
10147c1a8: 7101bd1f    	cmp	w8, #0x6f
10147c1ac: 54ffbb81    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147c1b0: 39048669    	strb	w9, [x19, #0x121]
10147c1b4: 17fffdda    	b	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147c1b8: 39400109    	ldrb	w9, [x8]
10147c1bc: 5101052a    	sub	w10, w9, #0x41
10147c1c0: 7100695f    	cmp	w10, #0x1a
10147c1c4: 5280040a    	mov	w10, #0x20              ; =32
10147c1c8: 1a9f314a    	csel	w10, w10, wzr, lo
10147c1cc: 2a090149    	orr	w9, w10, w9
10147c1d0: 7101b93f    	cmp	w9, #0x6e
10147c1d4: 54ffba41    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147c1d8: 52800009    	mov	w9, #0x0                ; =0
10147c1dc: 39400508    	ldrb	w8, [x8, #0x1]
10147c1e0: 5101050a    	sub	w10, w8, #0x41
10147c1e4: 7100695f    	cmp	w10, #0x1a
10147c1e8: 5280040a    	mov	w10, #0x20              ; =32
10147c1ec: 1a9f314a    	csel	w10, w10, wzr, lo
10147c1f0: 2a080148    	orr	w8, w10, w8
10147c1f4: 7101bd1f    	cmp	w8, #0x6f
10147c1f8: 54ffb921    	b.ne	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147c1fc: 39048269    	strb	w9, [x19, #0x120]
10147c200: 17fffdc7    	b	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147c204: 52800008    	mov	w8, #0x0                ; =0
10147c208: 5280000b    	mov	w11, #0x0               ; =0
10147c20c: 79023268    	strh	w8, [x19, #0x118]
10147c210: 7902366b    	strh	w11, [x19, #0x11a]
10147c214: 17fffdc2    	b	0x10147b91c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1064>
10147c218: 3940012c    	ldrb	w12, [x9]
10147c21c: 7100ad9f    	cmp	w12, #0x2b
10147c220: 1a9f17e8    	cset	w8, eq
10147c224: 9a891529    	cinc	x9, x9, eq
10147c228: cb08014a    	sub	x10, x10, x8
10147c22c: f100155f    	cmp	x10, #0x5
10147c230: 540001c2    	b.hs	0x10147c268 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x19b0>
10147c234: 5280000b    	mov	w11, #0x0               ; =0
10147c238: b40003ca    	cbz	x10, 0x10147c2b0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x19f8>
10147c23c: 38401528    	ldrb	w8, [x9], #0x1
10147c240: 5100c10c    	sub	w12, w8, #0x30
10147c244: 7100299f    	cmp	w12, #0xa
10147c248: 1a9f27e8    	cset	w8, lo
10147c24c: 7100259f    	cmp	w12, #0x9
10147c250: 54fffdc8    	b.hi	0x10147c208 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1950>
10147c254: 5280014d    	mov	w13, #0xa               ; =10
10147c258: 1b0d316b    	madd	w11, w11, w13, w12
10147c25c: f100054a    	subs	x10, x10, #0x1
10147c260: 54fffee1    	b.ne	0x10147c23c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1984>
10147c264: 17ffffea    	b	0x10147c20c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1954>
10147c268: 5280000b    	mov	w11, #0x0               ; =0
10147c26c: f100015f    	cmp	x10, #0x0
10147c270: 1a9f17e8    	cset	w8, eq
10147c274: b4fffcca    	cbz	x10, 0x10147c20c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1954>
10147c278: 12003d6c    	and	w12, w11, #0xffff
10147c27c: 0b2b298b    	add	w11, w12, w11, uxth #2
10147c280: 531f796c    	lsl	w12, w11, #1
10147c284: 72100d8d    	ands	w13, w12, #0xf0000
10147c288: 3840152b    	ldrb	w11, [x9], #0x1
10147c28c: 5100c16b    	sub	w11, w11, #0x30
10147c290: 710001bf    	cmp	w13, #0x0
10147c294: 7a490962    	ccmp	w11, #0x9, #0x2, eq
10147c298: 54fffb88    	b.hi	0x10147c208 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1950>
10147c29c: 12003d8c    	and	w12, w12, #0xffff
10147c2a0: d100054a    	sub	x10, x10, #0x1
10147c2a4: 0b2b218b    	add	w11, w12, w11, uxth
10147c2a8: 3687fe2b    	tbz	w11, #0x10, 0x10147c26c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x19b4>
10147c2ac: 17ffffd7    	b	0x10147c208 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1950>
10147c2b0: 52800028    	mov	w8, #0x1                ; =1
10147c2b4: 17ffffd6    	b	0x10147c20c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1954>
10147c2b8: f94063f5    	ldr	x21, [sp, #0xc0]
10147c2bc: 910022b3    	add	x19, x21, #0x8
10147c2c0: f9404bf4    	ldr	x20, [sp, #0x90]
10147c2c4: 14000004    	b	0x10147c2d4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a1c>
10147c2c8: 91006273    	add	x19, x19, #0x18
10147c2cc: f1000739    	subs	x25, x25, #0x1
10147c2d0: 540000e0    	b.eq	0x10147c2ec <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a34>
10147c2d4: f85f8261    	ldur	x1, [x19, #-0x8]
10147c2d8: b4ffff81    	cbz	x1, 0x10147c2c8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a10>
10147c2dc: f9400260    	ldr	x0, [x19]
10147c2e0: 52800022    	mov	w2, #0x1                ; =1
10147c2e4: 97d888fe    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c2e8: 17fffff8    	b	0x10147c2c8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a10>
10147c2ec: f940d3e8    	ldr	x8, [sp, #0x1a0]
10147c2f0: b40000c8    	cbz	x8, 0x10147c308 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a50>
10147c2f4: 8b080508    	add	x8, x8, x8, lsl #1
10147c2f8: d37df101    	lsl	x1, x8, #3
10147c2fc: aa1503e0    	mov	x0, x21
10147c300: 52800102    	mov	w2, #0x8                ; =8
10147c304: 97d888f6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c308: b40000b7    	cbz	x23, 0x10147c31c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a64>
10147c30c: aa1c03e0    	mov	x0, x28
10147c310: aa1703e1    	mov	x1, x23
10147c314: 52800022    	mov	w2, #0x1                ; =1
10147c318: 97d888f1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c31c: f100069f    	cmp	x20, #0x1
10147c320: 54ff5500    	b.eq	0x10147adc0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x508>
10147c324: 17fffaa9    	b	0x10147adc8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x510>
10147c328: f94047e8    	ldr	x8, [sp, #0x88]
10147c32c: eb140108    	subs	x8, x8, x20
10147c330: 54000180    	b.eq	0x10147c360 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1aa8>
10147c334: d343fd08    	lsr	x8, x8, #3
10147c338: d2849269    	mov	x9, #0x2493             ; =9363
10147c33c: f2b24929    	movk	x9, #0x9249, lsl #16
10147c340: f2c92489    	movk	x9, #0x4924, lsl #32
10147c344: f2e49249    	movk	x9, #0x2492, lsl #48
10147c348: 9bc97d13    	umulh	x19, x8, x9
10147c34c: aa1403e0    	mov	x0, x20
10147c350: 97d306ca    	bl	0x10093de78 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2ae50>
10147c354: 9100e294    	add	x20, x20, #0x38
10147c358: f1000673    	subs	x19, x19, #0x1
10147c35c: 54ffff81    	b.ne	0x10147c34c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1a94>
10147c360: f94007e9    	ldr	x9, [sp, #0x8]
10147c364: b40000c9    	cbz	x9, 0x10147c37c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1ac4>
10147c368: d37ae528    	lsl	x8, x9, #6
10147c36c: cb090d01    	sub	x1, x8, x9, lsl #3
10147c370: f94013e0    	ldr	x0, [sp, #0x20]
10147c374: 52800102    	mov	w2, #0x8                ; =8
10147c378: 97d888d9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c37c: f9400be1    	ldr	x1, [sp, #0x10]
10147c380: b4000341    	cbz	x1, 0x10147c3e8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1b30>
10147c384: f9401fe0    	ldr	x0, [sp, #0x38]
10147c388: 52800022    	mov	w2, #0x1                ; =1
10147c38c: 97d888d4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c390: 14000016    	b	0x10147c3e8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1b30>
10147c394: aa1403f5    	mov	x21, x20
10147c398: f85ffe74    	ldr	x20, [x19, #-0x1]!
10147c39c: f9400676    	ldr	x22, [x19, #0x8]
10147c3a0: f94002c8    	ldr	x8, [x22]
10147c3a4: b4000068    	cbz	x8, 0x10147c3b0 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1af8>
10147c3a8: aa1403e0    	mov	x0, x20
10147c3ac: d63f0100    	blr	x8
10147c3b0: f94006c1    	ldr	x1, [x22, #0x8]
10147c3b4: b4000081    	cbz	x1, 0x10147c3c4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1b0c>
10147c3b8: f9400ac2    	ldr	x2, [x22, #0x10]
10147c3bc: aa1403e0    	mov	x0, x20
10147c3c0: 97d888c7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c3c4: aa1303e0    	mov	x0, x19
10147c3c8: 52800301    	mov	w1, #0x18               ; =24
10147c3cc: 52800102    	mov	w2, #0x8                ; =8
10147c3d0: 97d888c3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c3d4: aa1503f4    	mov	x20, x21
10147c3d8: 910443e1    	add	x1, sp, #0x110
10147c3dc: f9407fe0    	ldr	x0, [sp, #0xf8]
10147c3e0: 940046ae    	bl	0x10148de98 <__ZN4core5slice4sort6stable9quicksort9quicksort17h1ad04638c7ce3510E+0x1f00>
10147c3e4: 36074780    	tbz	w0, #0x0, 0x10147acd4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x41c>
10147c3e8: 910cc3ff    	add	sp, sp, #0x330
10147c3ec: a9467bfd    	ldp	x29, x30, [sp, #0x60]
10147c3f0: a9454ff4    	ldp	x20, x19, [sp, #0x50]
10147c3f4: a94457f6    	ldp	x22, x21, [sp, #0x40]
10147c3f8: a9435ff8    	ldp	x24, x23, [sp, #0x30]
10147c3fc: a94267fa    	ldp	x26, x25, [sp, #0x20]
10147c400: a9416ffc    	ldp	x28, x27, [sp, #0x10]
10147c404: 6cc723e9    	ldp	d9, d8, [sp], #0x70
10147c408: d65f03c0    	ret
10147c40c: d0006f62    	adrp	x2, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
10147c410: 91258042    	add	x2, x2, #0x960
10147c414: aa1503e1    	mov	x1, x21
10147c418: 94191e49    	bl	0x101ac3d3c <__ZN4core9panicking18panic_bounds_check17hd6142ed38f8c399dE>
10147c41c: 14000019    	b	0x10147c480 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1bc8>
10147c420: f90067f9    	str	x25, [sp, #0xc8]
10147c424: 52800020    	mov	w0, #0x1                ; =1
10147c428: aa1303e1    	mov	x1, x19
10147c42c: 94191bd2    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10147c430: 14000014    	b	0x10147c480 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1bc8>
10147c434: f90067f9    	str	x25, [sp, #0xc8]
10147c438: d0006f62    	adrp	x2, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
10147c43c: 9125e042    	add	x2, x2, #0x978
10147c440: aa1c03e0    	mov	x0, x28
10147c444: 94191e3e    	bl	0x101ac3d3c <__ZN4core9panicking18panic_bounds_check17hd6142ed38f8c399dE>
10147c448: 1400000e    	b	0x10147c480 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1bc8>
10147c44c: 52800020    	mov	w0, #0x1                ; =1
10147c450: aa1303e1    	mov	x1, x19
10147c454: 94191bc8    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10147c458: 1400000a    	b	0x10147c480 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1bc8>
10147c45c: f9006bf6    	str	x22, [sp, #0xd0]
10147c460: 52800020    	mov	w0, #0x1                ; =1
10147c464: f9406be1    	ldr	x1, [sp, #0xd0]
10147c468: 94191bc3    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10147c46c: 14000005    	b	0x10147c480 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1bc8>
10147c470: f90067f9    	str	x25, [sp, #0xc8]
10147c474: 52800020    	mov	w0, #0x1                ; =1
10147c478: aa1303e1    	mov	x1, x19
10147c47c: 94191bbe    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10147c480: d4200020    	brk	#0x1
10147c484: aa0003f5    	mov	x21, x0
10147c488: f94067e8    	ldr	x8, [sp, #0xc8]
10147c48c: b50007a8    	cbnz	x8, 0x10147c580 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1cc8>
10147c490: 1400003f    	b	0x10147c58c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1cd4>
10147c494: aa0003f5    	mov	x21, x0
10147c498: f94006c1    	ldr	x1, [x22, #0x8]
10147c49c: b4000081    	cbz	x1, 0x10147c4ac <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1bf4>
10147c4a0: f9400ac2    	ldr	x2, [x22, #0x10]
10147c4a4: aa1403e0    	mov	x0, x20
10147c4a8: 97d8888d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c4ac: aa1303e0    	mov	x0, x19
10147c4b0: 52800301    	mov	w1, #0x18               ; =24
10147c4b4: 52800102    	mov	w2, #0x8                ; =8
10147c4b8: 1400006e    	b	0x10147c670 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1db8>
10147c4bc: aa0003f5    	mov	x21, x0
10147c4c0: f940f3e1    	ldr	x1, [sp, #0x1e0]
10147c4c4: b4000cc1    	cbz	x1, 0x10147c65c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1da4>
10147c4c8: f940f7e0    	ldr	x0, [sp, #0x1e8]
10147c4cc: 52800022    	mov	w2, #0x1                ; =1
10147c4d0: 97d88883    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c4d4: 14000062    	b	0x10147c65c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1da4>
10147c4d8: aa0003f5    	mov	x21, x0
10147c4dc: b4000716    	cbz	x22, 0x10147c5bc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d04>
10147c4e0: f9401be0    	ldr	x0, [sp, #0x30]
10147c4e4: aa1603e1    	mov	x1, x22
10147c4e8: 52800022    	mov	w2, #0x1                ; =1
10147c4ec: 97d8887c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c4f0: 14000033    	b	0x10147c5bc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d04>
10147c4f4: 14000031    	b	0x10147c5b8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d00>
10147c4f8: 14000030    	b	0x10147c5b8 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d00>
10147c4fc: aa0003f5    	mov	x21, x0
10147c500: 14000057    	b	0x10147c65c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1da4>
10147c504: aa0003f5    	mov	x21, x0
10147c508: aa1303e0    	mov	x0, x19
10147c50c: 940036e3    	bl	0x10148a098 <__ZN3std2io5error5Error3new17h519eec155b6ed967E+0xe8>
10147c510: 14000059    	b	0x10147c674 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1dbc>
10147c514: 94191e04    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
10147c518: aa0003f5    	mov	x21, x0
10147c51c: 910603e0    	add	x0, sp, #0x180
10147c520: 97d3197b    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10147c524: 1400004c    	b	0x10147c654 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d9c>
10147c528: aa0003f5    	mov	x21, x0
10147c52c: 910783e0    	add	x0, sp, #0x1e0
10147c530: 94003705    	bl	0x10148a144 <__ZN3std2io5error5Error3new17h519eec155b6ed967E+0x194>
10147c534: 1400000f    	b	0x10147c570 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1cb8>
10147c538: aa0003f5    	mov	x21, x0
10147c53c: f85803a1    	ldur	x1, [x29, #-0x80]
10147c540: b4000181    	cbz	x1, 0x10147c570 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1cb8>
10147c544: f85883a0    	ldur	x0, [x29, #-0x78]
10147c548: 52800022    	mov	w2, #0x1                ; =1
10147c54c: 97d88864    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c550: 14000008    	b	0x10147c570 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1cb8>
10147c554: 14000003    	b	0x10147c560 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1ca8>
10147c558: f90067f9    	str	x25, [sp, #0xc8]
10147c55c: 14000003    	b	0x10147c568 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1cb0>
10147c560: aa0003f5    	mov	x21, x0
10147c564: 14000003    	b	0x10147c570 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1cb8>
10147c568: aa0003f5    	mov	x21, x0
10147c56c: 36000116    	tbz	w22, #0x0, 0x10147c58c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1cd4>
10147c570: f94067e8    	ldr	x8, [sp, #0xc8]
10147c574: b40000c8    	cbz	x8, 0x10147c58c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1cd4>
10147c578: f940ebe8    	ldr	x8, [sp, #0x1d0]
10147c57c: f9006be8    	str	x8, [sp, #0xd0]
10147c580: a94c83e1    	ldp	x1, x0, [sp, #0xc8]
10147c584: 52800022    	mov	w2, #0x1                ; =1
10147c588: 97d88855    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c58c: 910683e0    	add	x0, sp, #0x1a0
10147c590: 97d2d29e    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
10147c594: f94037e8    	ldr	x8, [sp, #0x68]
10147c598: b40004e8    	cbz	x8, 0x10147c634 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d7c>
10147c59c: f94073e0    	ldr	x0, [sp, #0xe0]
10147c5a0: f94037e1    	ldr	x1, [sp, #0x68]
10147c5a4: 1400000c    	b	0x10147c5d4 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d1c>
10147c5a8: aa0003f5    	mov	x21, x0
10147c5ac: 1400001b    	b	0x10147c618 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d60>
10147c5b0: aa0003f5    	mov	x21, x0
10147c5b4: 14000014    	b	0x10147c604 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d4c>
10147c5b8: aa0003f5    	mov	x21, x0
10147c5bc: 910683e0    	add	x0, sp, #0x1a0
10147c5c0: 97d31953    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10147c5c4: f94017e8    	ldr	x8, [sp, #0x28]
10147c5c8: b4000468    	cbz	x8, 0x10147c654 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d9c>
10147c5cc: f9402be0    	ldr	x0, [sp, #0x50]
10147c5d0: f94017e1    	ldr	x1, [sp, #0x28]
10147c5d4: 52800022    	mov	w2, #0x1                ; =1
10147c5d8: 97d88841    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c5dc: 14000016    	b	0x10147c634 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d7c>
10147c5e0: aa0003f5    	mov	x21, x0
10147c5e4: f900f7f7    	str	x23, [sp, #0x1e8]
10147c5e8: b40000b6    	cbz	x22, 0x10147c5fc <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d44>
10147c5ec: aa1303e0    	mov	x0, x19
10147c5f0: aa1603e1    	mov	x1, x22
10147c5f4: 52800022    	mov	w2, #0x1                ; =1
10147c5f8: 97d88839    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c5fc: 910783e0    	add	x0, sp, #0x1e0
10147c600: 97d2d282    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
10147c604: f85803a1    	ldur	x1, [x29, #-0x80]
10147c608: b4000081    	cbz	x1, 0x10147c618 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d60>
10147c60c: aa1c03e0    	mov	x0, x28
10147c610: 52800022    	mov	w2, #0x1                ; =1
10147c614: 97d88832    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c618: b40000b4    	cbz	x20, 0x10147c62c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d74>
10147c61c: f94073e0    	ldr	x0, [sp, #0xe0]
10147c620: aa1403e1    	mov	x1, x20
10147c624: 52800022    	mov	w2, #0x1                ; =1
10147c628: 97d8882d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c62c: 910683e0    	add	x0, sp, #0x1a0
10147c630: 97d2d276    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
10147c634: f9404be8    	ldr	x8, [sp, #0x90]
10147c638: f1000d1f    	cmp	x8, #0x3
10147c63c: 54000088    	b.hi	0x10147c64c <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d94>
10147c640: f9404be8    	ldr	x8, [sp, #0x90]
10147c644: f100051f    	cmp	x8, #0x1
10147c648: 54000061    	b.ne	0x10147c654 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1d9c>
10147c64c: 910523e0    	add	x0, sp, #0x148
10147c650: 97d3060a    	bl	0x10093de78 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2ae50>
10147c654: 9104a3e0    	add	x0, sp, #0x128
10147c658: 97d33c14    	bl	0x10094b6a8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x38680>
10147c65c: f9400be8    	ldr	x8, [sp, #0x10]
10147c660: b40000a8    	cbz	x8, 0x10147c674 <__ZN15otty_ssh_config4load6Loader4load17h496148d1577f8587E+0x1dbc>
10147c664: f9401fe0    	ldr	x0, [sp, #0x38]
10147c668: f9400be1    	ldr	x1, [sp, #0x10]
10147c66c: 52800022    	mov	w2, #0x1                ; =1
10147c670: 97d8881b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10147c674: aa1503e0    	mov	x0, x21
10147c678: 941933d7    	bl	0x101ac95d4 <_writev+0x101ac95d4>
