1005852f8:     	mov	x4, #0x656d             ; =25965
1005852fc:     	movk	x4, #0x6772, lsl #16
100585300:     	movk	x4, #0x65, lsl #32
100585304:     	mov	x5, #-0x1b00000000000000 ; =-1945555039024054272
100585308:     	b	0x100585320
10058530c:     	mov	x4, #0x6572             ; =25970
100585310:     	movk	x4, #0x6162, lsl #16
100585314:     	movk	x4, #0x6573, lsl #32
100585318:     	mov	x5, #-0x1a00000000000000 ; =-1873497444986126336
10058531c:     	b	0x100585320
100585320:     	sub	sp, sp, #0x80
100585324:     	stp	x26, x25, [sp, #0x30]
100585328:     	stp	x24, x23, [sp, #0x40]
10058532c:     	stp	x22, x21, [sp, #0x50]
100585330:     	stp	x20, x19, [sp, #0x60]
100585334:     	stp	x29, x30, [sp, #0x70]
100585338:     	add	x29, sp, #0x70
10058533c:     	mov	x21, x5
100585340:     	mov	x22, x4
100585344:     	mov	x23, x3
100585348:     	mov	x24, x2
10058534c:     	mov	x25, x1
100585350:     	mov	x26, x0
100585354:     	mov	x19, x8
100585358:     	adrp	x0, 0x102341000
10058535c:     	add	x0, x0, #0x6d0
100585360:     	adrp	x1, 0x101ae1000
100585364:     	add	x1, x1, #0x7e0 ; possible literal '\n14'
100585368:     	bl	0x100003c4c
10058536c:     	mov	w1, #0x70               ; =112
100585370:     	mov	w2, #0x7                ; =7
100585374:     	bl	0x101aca588 ; symbol _swift_allocObject
100585378:     	mov	x20, x0
10058537c:     	adrp	x8, 0x101ae1000
100585380:     	ldr	q0, [x8, #0xc10]
100585384:     	str	q0, [x0, #0x10]
100585388:     	mov	w8, #0x6967             ; =26983
10058538c:     	movk	w8, #0x74, lsl #16
100585390:     	mov	x9, #-0x1d00000000000000 ; =-2089670227099910144
100585394:     	stp	x8, x9, [x0, #0x20]
100585398:     	mov	w8, #0x432d             ; =17197
10058539c:     	mov	x9, #-0x1e00000000000000 ; =-2161727821137838080
1005853a0:     	stp	x8, x9, [x0, #0x30]
1005853a4:     	stp	x26, x25, [x0, #0x40]
1005853a8:     	stp	x22, x21, [x0, #0x50]
1005853ac:     	stp	x24, x23, [x0, #0x60]
1005853b0:     	adrp	x8, 0x102326000
1005853b4:     	ldr	x0, [x8, #0xa50]
1005853b8:     	bl	0x101ac9d24 ; symbol _objc_opt_self
1005853bc:     	mov	x21, x0
1005853c0:     	mov	x0, x25
1005853c4:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
1005853c8:     	mov	x0, x23
1005853cc:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
1005853d0:     	mov	x0, x21
1005853d4:     	bl	0x101ad04e0 ; selector processInfo
1005853d8:     	mov	x29, x29
1005853dc:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
1005853e0:     	mov	x21, x0
1005853e4:     	bl	0x101acd780 ; selector environment
1005853e8:     	mov	x29, x29
1005853ec:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
1005853f0:     	mov	x22, x0
1005853f4:     	mov	x0, x21
1005853f8:     	bl	0x101ac9d30 ; symbol _objc_release
1005853fc:     	adrp	x1, 0x1022ce000
100585400:     	ldr	x1, [x1, #0x38]
100585404:     	adrp	x3, 0x1022ce000
100585408:     	ldr	x3, [x3, #0x48]
10058540c:     	mov	x0, x22
100585410:     	mov	x2, x1
100585414:     	bl	0x101ac5ef0 ; symbol _$sSD10FoundationE36_unconditionallyBridgeFromObjectiveCySDyxq_GSo12NSDictionaryCSgFZ
100585418:     	mov	x21, x0
10058541c:     	mov	x0, x22
100585420:     	bl	0x101ac9d30 ; symbol _objc_release
100585424:     	add	x8, sp, #0x8
100585428:     	mov	x0, x20
10058542c:     	mov	x1, x21
100585430:     	mov	x2, #0x0                ; =0
100585434:     	mov	w3, #0x1                ; =1
100585438:     	mov	x4, #0x0                ; =0
10058543c:     	mov	x5, #-0x1000000000000000 ; =-1152921504606846976
100585440:     	bl	0x100069800
100585444:     	ldp	x22, x23, [sp, #0x8]
100585448:     	ldp	x24, x25, [sp, #0x18]
10058544c:     	ldr	w26, [sp, #0x28]
100585450:     	mov	x0, x20
100585454:     	bl	0x101aca960 ; symbol _swift_release
100585458:     	mov	x0, x21
10058545c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
100585460:     	cmp	w26, #0x0
100585464:     	cset	w0, eq
100585468:     	add	x8, sp, #0x8
10058546c:     	mov	x1, x22
100585470:     	mov	x2, x23
100585474:     	mov	x3, x24
100585478:     	mov	x4, x25
10058547c:     	bl	0x1001e86ec
100585480:     	ldur	q0, [sp, #0x8]
100585484:     	ldur	q1, [sp, #0x18]
100585488:     	stp	q0, q1, [x19]
10058548c:     	ldr	x8, [sp, #0x28]
100585490:     	str	x8, [x19, #0x20]
100585494:     	ldp	x29, x30, [sp, #0x70]
100585498:     	ldp	x20, x19, [sp, #0x60]
10058549c:     	ldp	x22, x21, [sp, #0x50]
1005854a0:     	ldp	x24, x23, [sp, #0x40]
1005854a4:     	ldp	x26, x25, [sp, #0x30]
1005854a8:     	add	sp, sp, #0x80
1005854ac:     	ret
