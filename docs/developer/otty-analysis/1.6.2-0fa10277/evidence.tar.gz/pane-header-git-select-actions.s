10058ab70:     	sub	sp, sp, #0x50
10058ab74:     	stp	x20, x19, [sp, #0x30]
10058ab78:     	stp	x29, x30, [sp, #0x40]
10058ab7c:     	add	x29, sp, #0x40
10058ab80:     	mov	x3, x1
10058ab84:     	mov	x2, x0
10058ab88:     	mov	x19, x8
10058ab8c:     	ldp	x0, x1, [x20, #0x10]
10058ab90:     	add	x8, sp, #0x8
10058ab94:     	bl	0x1005852f8
10058ab98:     	ldur	q0, [sp, #0x8]
10058ab9c:     	ldur	q1, [sp, #0x18]
10058aba0:     	stp	q0, q1, [x19]
10058aba4:     	ldr	x8, [sp, #0x28]
10058aba8:     	str	x8, [x19, #0x20]
10058abac:     	ldp	x29, x30, [sp, #0x40]
10058abb0:     	ldp	x20, x19, [sp, #0x30]
10058abb4:     	add	sp, sp, #0x50
10058abb8:     	ret
10058abbc:     	b	0x10058ac10
10058abc0:     	b	0x10058ac5c
10058abc4:     	sub	sp, sp, #0x50
10058abc8:     	stp	x20, x19, [sp, #0x30]
10058abcc:     	stp	x29, x30, [sp, #0x40]
10058abd0:     	add	x29, sp, #0x40
10058abd4:     	mov	x3, x1
10058abd8:     	mov	x2, x0
10058abdc:     	mov	x19, x8
10058abe0:     	ldp	x0, x1, [x20, #0x10]
10058abe4:     	add	x8, sp, #0x8
10058abe8:     	bl	0x10058530c
10058abec:     	ldur	q0, [sp, #0x8]
10058abf0:     	ldur	q1, [sp, #0x18]
10058abf4:     	stp	q0, q1, [x19]
10058abf8:     	ldr	x8, [sp, #0x28]
10058abfc:     	str	x8, [x19, #0x20]
10058ac00:     	ldp	x29, x30, [sp, #0x40]
10058ac04:     	ldp	x20, x19, [sp, #0x30]
10058ac08:     	add	sp, sp, #0x50
10058ac0c:     	ret
10058ac10:     	stp	x29, x30, [sp, #-0x10]!
10058ac14:     	mov	x29, sp
10058ac18:     	ldr	x0, [x20, #0x18]
10058ac1c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058ac20:     	ldr	x0, [x20, #0x28]
10058ac24:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058ac28:     	ldr	x0, [x20, #0x38]
10058ac2c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058ac30:     	ldr	x0, [x20, #0x48]
10058ac34:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058ac38:     	ldr	x0, [x20, #0x50]
10058ac3c:     	bl	0x101aca960 ; symbol _swift_release
10058ac40:     	ldr	x0, [x20, #0x60]
10058ac44:     	bl	0x101aca960 ; symbol _swift_release
10058ac48:     	mov	x0, x20
10058ac4c:     	mov	w1, #0x68               ; =104
10058ac50:     	mov	w2, #0x7                ; =7
10058ac54:     	ldp	x29, x30, [sp], #0x10
10058ac58:     	b	0x101aca6a8 ; symbol _swift_deallocObject
10058ac5c:     	sub	sp, sp, #0x30
10058ac60:     	stp	x29, x30, [sp, #0x20]
10058ac64:     	add	x29, sp, #0x20
10058ac68:     	ldp	x0, x1, [x20, #0x10]
10058ac6c:     	ldp	x2, x3, [x20, #0x20]
10058ac70:     	ldp	x4, x5, [x20, #0x30]
10058ac74:     	ldp	x6, x7, [x20, #0x40]
10058ac78:     	ldr	q0, [x20, #0x50]
10058ac7c:     	ldr	x8, [x20, #0x60]
10058ac80:     	str	x8, [sp, #0x10]
10058ac84:     	str	q0, [sp]
10058ac88:     	bl	0x1005894d8
10058ac8c:     	ldp	x29, x30, [sp, #0x20]
10058ac90:     	add	sp, sp, #0x30
10058ac94:     	ret
10058ac98:     	sub	sp, sp, #0x70
10058ac9c:     	stp	x24, x23, [sp, #0x30]
10058aca0:     	stp	x22, x21, [sp, #0x40]
10058aca4:     	stp	x20, x19, [sp, #0x50]
10058aca8:     	stp	x29, x30, [sp, #0x60]
10058acac:     	add	x29, sp, #0x60
10058acb0:     	mov	x21, x3
10058acb4:     	mov	x22, x2
10058acb8:     	mov	x20, x1
10058acbc:     	mov	x23, x0
10058acc0:     	adrp	x8, 0x102326000
10058acc4:     	ldr	x0, [x8, #0xaa8]
10058acc8:     	bl	0x101ac9cb8 ; symbol _objc_allocWithZone
10058accc:     	bl	0x101ace2c0 ; selector init
10058acd0:     	mov	x19, x0
10058acd4:     	mov	x2, #0x0                ; =0
10058acd8:     	bl	0x101ad1800 ; selector setAlertStyle:
10058acdc:     	stp	x23, x20, [sp]
10058ace0:     	mov	x0, x20
10058ace4:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10058ace8:     	mov	x0, #0x4620             ; =17952
10058acec:     	movk	x0, #0x6961, lsl #16
10058acf0:     	movk	x0, #0x656c, lsl #32
10058acf4:     	movk	x0, #0x64, lsl #48
10058acf8:     	mov	x20, sp
10058acfc:     	mov	x1, #-0x1900000000000000 ; =-1801439850948198400
10058ad00:     	bl	0x101ac649c ; symbol _$sSS6appendyySSF
10058ad04:     	ldp	x0, x20, [sp]
10058ad08:     	mov	x1, x20
10058ad0c:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
10058ad10:     	mov	x23, x0
10058ad14:     	mov	x0, x20
10058ad18:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10058ad1c:     	mov	x0, x19
10058ad20:     	mov	x2, x23
10058ad24:     	bl	0x101ad3660 ; selector setMessageText:
10058ad28:     	mov	x0, x23
10058ad2c:     	bl	0x101ac9d30 ; symbol _objc_release
