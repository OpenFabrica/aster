10057edcc:     	stp	x28, x27, [sp, #-0x60]!
10057edd0:     	stp	x26, x25, [sp, #0x10]
10057edd4:     	stp	x24, x23, [sp, #0x20]
10057edd8:     	stp	x22, x21, [sp, #0x30]
10057eddc:     	stp	x20, x19, [sp, #0x40]
10057ede0:     	stp	x29, x30, [sp, #0x50]
10057ede4:     	add	x29, sp, #0x50
10057ede8:     	sub	sp, sp, #0x10
10057edec:     	mov	x24, x3
10057edf0:     	mov	x25, x2
10057edf4:     	mov	x22, x1
10057edf8:     	stur	x0, [x29, #-0x58]
10057edfc:     	mov	x26, #0x616d            ; =24941
10057ee00:     	movk	x26, #0x646e, lsl #16
10057ee04:     	movk	x26, #0x3a, lsl #32
10057ee08:     	movk	x26, #0xed00, lsl #48
10057ee0c:     	mov	x27, #0x746f            ; =29807
10057ee10:     	movk	x27, #0x7974, lsl #16
10057ee14:     	movk	x27, #0x632d, lsl #32
10057ee18:     	movk	x27, #0x6d6f, lsl #48
10057ee1c:     	mov	x0, #0x0                ; =0
10057ee20:     	bl	0x101ac4e28 ; symbol _$s10Foundation3URLVMa
10057ee24:     	mov	x28, x0
10057ee28:     	ldur	x19, [x0, #-0x8]
10057ee2c:     	ldr	x8, [x19, #0x40]
10057ee30:     	mov	x9, x8
10057ee34:     	adrp	x16, 0x1022cb000
10057ee38:     	ldr	x16, [x16, #0x398]
10057ee3c:     	blr	x16
10057ee40:     	mov	x9, sp
10057ee44:     	add	x10, x8, #0xf
10057ee48:     	and	x12, x10, #0xfffffffffffffff0
10057ee4c:     	sub	x23, x9, x12
10057ee50:     	mov	sp, x23
10057ee54:     	mov	x9, x8
10057ee58:     	adrp	x16, 0x1022cb000
10057ee5c:     	ldr	x16, [x16, #0x398]
10057ee60:     	blr	x16
10057ee64:     	mov	x8, sp
10057ee68:     	sub	x20, x8, x12
10057ee6c:     	mov	sp, x20
10057ee70:     	mov	x0, x27
10057ee74:     	mov	x1, x26
10057ee78:     	mov	x2, x25
10057ee7c:     	mov	x3, x24
10057ee80:     	bl	0x101ac658c ; symbol _$sSS9hasPrefixySbSSF
10057ee84:     	tbz	w0, #0x0, 0x10057ef44
10057ee88:     	stur	x28, [x29, #-0x60]
10057ee8c:     	mov	x0, x24
10057ee90:     	bl	0x101aca624 ; symbol _swift_bridgeObjectRetain
10057ee94:     	mov	x0, x27
10057ee98:     	mov	x1, x26
10057ee9c:     	bl	0x101ac6430 ; symbol _$sSS5countSivg
10057eea0:     	mov	x1, x25
10057eea4:     	mov	x2, x24
10057eea8:     	bl	0x1000252e8
10057eeac:     	mov	x26, x0
10057eeb0:     	mov	x27, x1
10057eeb4:     	mov	x28, x2
10057eeb8:     	mov	x21, x3
10057eebc:     	mov	x0, x24
10057eec0:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10057eec4:     	mov	x0, x26
10057eec8:     	mov	x1, x27
10057eecc:     	mov	x2, x28
10057eed0:     	mov	x3, x21
10057eed4:     	bl	0x101ac6340 ; symbol _$sSS14_fromSubstringySSSshFZ
10057eed8:     	mov	x27, x0
10057eedc:     	mov	x26, x1
10057eee0:     	mov	x0, x21
10057eee4:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10057eee8:     	and	x8, x27, #0xffffffffffff
10057eeec:     	ubfx	x9, x26, #56, #4
10057eef0:     	tst	x26, #0x2000000000000000
10057eef4:     	csel	x8, x8, x9, eq
10057eef8:     	cbz	x8, 0x10057ef38
10057eefc:     	mov	x0, x27
10057ef00:     	mov	x1, x26
10057ef04:     	ldur	x2, [x29, #-0x58]
10057ef08:     	mov	x3, x22
10057ef0c:     	mov	w4, #0x1                ; =1
10057ef10:     	bl	0x10057eb30
10057ef14:     	mov	x0, x26
10057ef18:     	sub	sp, x29, #0x50
10057ef1c:     	ldp	x29, x30, [sp, #0x50]
10057ef20:     	ldp	x20, x19, [sp, #0x40]
10057ef24:     	ldp	x22, x21, [sp, #0x30]
10057ef28:     	ldp	x24, x23, [sp, #0x20]
10057ef2c:     	ldp	x26, x25, [sp, #0x10]
10057ef30:     	ldp	x28, x27, [sp], #0x60
10057ef34:     	b	0x101aca60c ; symbol _swift_bridgeObjectRelease
10057ef38:     	mov	x0, x26
10057ef3c:     	bl	0x101aca60c ; symbol _swift_bridgeObjectRelease
10057ef40:     	ldur	x28, [x29, #-0x60]
10057ef44:     	adrp	x8, 0x102326000
10057ef48:     	ldr	x0, [x8, #0xa10]
10057ef4c:     	bl	0x101ac9d24 ; symbol _objc_opt_self
10057ef50:     	mov	x26, x0
10057ef54:     	bl	0x101ad4ec0 ; selector sharedWorkspace
10057ef58:     	mov	x29, x29
10057ef5c:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
10057ef60:     	mov	x21, x0
10057ef64:     	mov	x0, x25
10057ef68:     	mov	x1, x24
10057ef6c:     	bl	0x101ac6238 ; symbol _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
10057ef70:     	mov	x25, x0
10057ef74:     	mov	x0, x21
10057ef78:     	mov	x2, x25
10057ef7c:     	bl	0x101acae60 ; selector URLForApplicationWithBundleIdentifier:
10057ef80:     	mov	x29, x29
10057ef84:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
10057ef88:     	mov	x24, x0
10057ef8c:     	mov	x0, x21
10057ef90:     	bl	0x101ac9d30 ; symbol _objc_release
10057ef94:     	mov	x0, x25
10057ef98:     	bl	0x101ac9d30 ; symbol _objc_release
10057ef9c:     	cbz	x24, 0x10057f0a8
10057efa0:     	mov	x8, x23
10057efa4:     	mov	x0, x24
10057efa8:     	bl	0x101ac4de0
10057efac:     	mov	x0, x24
10057efb0:     	bl	0x101ac9d30 ; symbol _objc_release
10057efb4:     	ldr	x8, [x19, #0x20]
10057efb8:     	mov	x0, x20
10057efbc:     	mov	x1, x23
10057efc0:     	mov	x2, x28
10057efc4:     	blr	x8
10057efc8:     	adrp	x8, 0x102326000
10057efcc:     	ldr	x0, [x8, #0xa98]
10057efd0:     	bl	0x101ac9cb8 ; symbol _objc_allocWithZone
10057efd4:     	bl	0x101ace2c0 ; selector init
10057efd8:     	mov	x23, x0
10057efdc:     	mov	x0, x26
10057efe0:     	bl	0x101ad4ec0 ; selector sharedWorkspace
10057efe4:     	mov	x29, x29
10057efe8:     	bl	0x101ac9d54 ; symbol _objc_retainAutoreleasedReturnValue
10057efec:     	mov	x21, x0
10057eff0:     	adrp	x0, 0x102363000
10057eff4:     	add	x0, x0, #0xa00
10057eff8:     	adrp	x1, 0x101aed000
10057effc:     	add	x1, x1, #0x9e0 ; possible literal '�v3'
10057f000:     	bl	0x100003c4c
10057f004:     	ldr	x8, [x19, #0x48]
10057f008:     	ldrb	w9, [x19, #0x50]
10057f00c:     	add	x10, x9, #0x20
10057f010:     	bic	x25, x10, x9
10057f014:     	add	x1, x25, x8
10057f018:     	orr	x2, x9, #0x7
10057f01c:     	bl	0x101aca588 ; symbol _swift_allocObject
10057f020:     	mov	x24, x0
10057f024:     	adrp	x8, 0x101ae1000
10057f028:     	ldr	q0, [x8, #0x130]
10057f02c:     	str	q0, [x0, #0x10]
10057f030:     	add	x8, x0, x25
10057f034:     	ldur	x0, [x29, #-0x58]
10057f038:     	mov	x1, x22
10057f03c:     	bl	0x101ac4d68 ; symbol _$s10Foundation3URLV15fileURLWithPathACSSh_tcfC
10057f040:     	mov	x0, x24
10057f044:     	mov	x1, x28
10057f048:     	bl	0x101ac6754 ; symbol _$sSa10FoundationE19_bridgeToObjectiveCSo7NSArrayCyF
10057f04c:     	mov	x22, x0
10057f050:     	mov	x0, x24
10057f054:     	bl	0x101aca960 ; symbol _swift_release
10057f058:     	bl	0x101ac4d8c ; symbol _$s10Foundation3URLV19_bridgeToObjectiveCSo5NSURLCyF
10057f05c:     	mov	x24, x0
10057f060:     	mov	x0, x21
10057f064:     	mov	x2, x22
10057f068:     	mov	x3, x24
10057f06c:     	mov	x4, x23
10057f070:     	mov	x5, #0x0                ; =0
10057f074:     	bl	0x101acfde0 ; selector openURLs:withApplicationAtURL:configuration:completionHandler:
10057f078:     	mov	x0, x21
10057f07c:     	bl	0x101ac9d30 ; symbol _objc_release
10057f080:     	mov	x0, x22
10057f084:     	bl	0x101ac9d30 ; symbol _objc_release
10057f088:     	mov	x0, x24
10057f08c:     	bl	0x101ac9d30 ; symbol _objc_release
10057f090:     	mov	x0, x23
10057f094:     	bl	0x101ac9d30 ; symbol _objc_release
10057f098:     	ldr	x8, [x19, #0x8]
10057f09c:     	mov	x0, x20
10057f0a0:     	mov	x1, x28
10057f0a4:     	blr	x8
10057f0a8:     	sub	sp, x29, #0x50
10057f0ac:     	ldp	x29, x30, [sp, #0x50]
10057f0b0:     	ldp	x20, x19, [sp, #0x40]
10057f0b4:     	ldp	x22, x21, [sp, #0x30]
10057f0b8:     	ldp	x24, x23, [sp, #0x20]
10057f0bc:     	ldp	x26, x25, [sp, #0x10]
10057f0c0:     	ldp	x28, x27, [sp], #0x60
10057f0c4:     	ret
