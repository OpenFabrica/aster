
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010006243c <_$s18OrderedCollections0A10DictionaryV8ElementsV11SubSequenceV8IteratorV4_endSivg>:
10006ad84: d10283ff    	sub	sp, sp, #0xa0
10006ad88: a90567fa    	stp	x26, x25, [sp, #0x50]
10006ad8c: a9065ff8    	stp	x24, x23, [sp, #0x60]
10006ad90: a90757f6    	stp	x22, x21, [sp, #0x70]
10006ad94: a9084ff4    	stp	x20, x19, [sp, #0x80]
10006ad98: a9097bfd    	stp	x29, x30, [sp, #0x90]
10006ad9c: 910243fd    	add	x29, sp, #0x90
10006ada0: d2fc0016    	mov	x22, #-0x2000000000000000 ; =-2305843009213693952
10006ada4: a9045bff    	stp	xzr, x22, [sp, #0x40]
10006ada8: 9240bc08    	and	x8, x0, #0xffffffffffff
10006adac: d378ec29    	ubfx	x9, x1, #56, #4
10006adb0: f243003f    	tst	x1, #0x2000000000000000
10006adb4: 9a890108    	csel	x8, x8, x9, eq
10006adb8: a90207e0    	stp	x0, x1, [sp, #0x20]
10006adbc: a90323ff    	stp	xzr, x8, [sp, #0x30]
10006adc0: aa0103e0    	mov	x0, x1
10006adc4: 94697e18    	bl	0x101aca624 <_writev+0x101aca624>
10006adc8: 910083f4    	add	x20, sp, #0x20
10006adcc: 94696dc6    	bl	0x101ac64e4 <_writev+0x101ac64e4>
10006add0: aa0103f3    	mov	x19, x1
10006add4: b4000701    	cbz	x1, 0x10006aeb4 <_$s18OrderedCollections0A10DictionaryV8ElementsV11SubSequenceV8IteratorV4_endSivg+0x8a78>
10006add8: aa0003f5    	mov	x21, x0
10006addc: f000eaa8    	adrp	x8, 0x101dc1000 <_writev+0x101dc1000>
10006ade0: 91240108    	add	x8, x8, #0x900
10006ade4: d1008108    	sub	x8, x8, #0x20
10006ade8: b2410117    	orr	x23, x8, #0x8000000000000000
10006adec: d378ed09    	ubfx	x9, x8, #56, #4
10006adf0: f243011f    	tst	x8, #0x2000000000000000
10006adf4: 52800328    	mov	w8, #0x19               ; =25
10006adf8: 9a890118    	csel	x24, x8, x9, eq
10006adfc: d2800339    	mov	x25, #0x19              ; =25
10006ae00: f2fa0019    	movk	x25, #0xd000, lsl #48
10006ae04: 1400000e    	b	0x10006ae3c <_$s18OrderedCollections0A10DictionaryV8ElementsV11SubSequenceV8IteratorV4_endSivg+0x8a00>
10006ae08: f94007e0    	ldr	x0, [sp, #0x8]
10006ae0c: 94697e00    	bl	0x101aca60c <_writev+0x101aca60c>
10006ae10: 910103f4    	add	x20, sp, #0x40
10006ae14: aa1503e0    	mov	x0, x21
10006ae18: aa1303e1    	mov	x1, x19
10006ae1c: 94696d9d    	bl	0x101ac6490 <_writev+0x101ac6490>
10006ae20: aa1303e0    	mov	x0, x19
10006ae24: 94697dfa    	bl	0x101aca60c <_writev+0x101aca60c>
10006ae28: 910083f4    	add	x20, sp, #0x20
10006ae2c: 94696dae    	bl	0x101ac64e4 <_writev+0x101ac64e4>
10006ae30: aa0003f5    	mov	x21, x0
10006ae34: aa0103f3    	mov	x19, x1
10006ae38: b40003c1    	cbz	x1, 0x10006aeb0 <_$s18OrderedCollections0A10DictionaryV8ElementsV11SubSequenceV8IteratorV4_endSivg+0x8a74>
10006ae3c: a9005ff9    	stp	x25, x23, [sp]
10006ae40: a90163ff    	stp	xzr, x24, [sp, #0x10]
10006ae44: 1400000a    	b	0x10006ae6c <_$s18OrderedCollections0A10DictionaryV8ElementsV11SubSequenceV8IteratorV4_endSivg+0x8a30>
10006ae48: aa1403e1    	mov	x1, x20
10006ae4c: aa1503e2    	mov	x2, x21
10006ae50: aa1303e3    	mov	x3, x19
10006ae54: 52800004    	mov	w4, #0x0                ; =0
10006ae58: 9469738e    	bl	0x101ac7c90 <_writev+0x101ac7c90>
10006ae5c: aa0003f6    	mov	x22, x0
10006ae60: aa1403e0    	mov	x0, x20
10006ae64: 94697dea    	bl	0x101aca60c <_writev+0x101aca60c>
10006ae68: 37000176    	tbnz	w22, #0x0, 0x10006ae94 <_$s18OrderedCollections0A10DictionaryV8ElementsV11SubSequenceV8IteratorV4_endSivg+0x8a58>
10006ae6c: 910003f4    	mov	x20, sp
10006ae70: 94696d9d    	bl	0x101ac64e4 <_writev+0x101ac64e4>
10006ae74: b4fffca1    	cbz	x1, 0x10006ae08 <_$s18OrderedCollections0A10DictionaryV8ElementsV11SubSequenceV8IteratorV4_endSivg+0x89cc>
10006ae78: aa0103f4    	mov	x20, x1
10006ae7c: eb15001f    	cmp	x0, x21
10006ae80: 54fffe41    	b.ne	0x10006ae48 <_$s18OrderedCollections0A10DictionaryV8ElementsV11SubSequenceV8IteratorV4_endSivg+0x8a0c>
10006ae84: eb13029f    	cmp	x20, x19
10006ae88: 54fffe01    	b.ne	0x10006ae48 <_$s18OrderedCollections0A10DictionaryV8ElementsV11SubSequenceV8IteratorV4_endSivg+0x8a0c>
10006ae8c: aa1403e0    	mov	x0, x20
10006ae90: 94697ddf    	bl	0x101aca60c <_writev+0x101aca60c>
10006ae94: f94007e0    	ldr	x0, [sp, #0x8]
10006ae98: 94697ddd    	bl	0x101aca60c <_writev+0x101aca60c>
10006ae9c: 910103f4    	add	x20, sp, #0x40
10006aea0: 52800b80    	mov	w0, #0x5c               ; =92
10006aea4: d2fc2001    	mov	x1, #-0x1f00000000000000 ; =-2233785415175766016
10006aea8: 94696d7d    	bl	0x101ac649c <_writev+0x101ac649c>
10006aeac: 17ffffd9    	b	0x10006ae10 <_$s18OrderedCollections0A10DictionaryV8ElementsV11SubSequenceV8IteratorV4_endSivg+0x89d4>
10006aeb0: a9445bf3    	ldp	x19, x22, [sp, #0x40]
10006aeb4: f94017e0    	ldr	x0, [sp, #0x28]
10006aeb8: 94697dd5    	bl	0x101aca60c <_writev+0x101aca60c>
10006aebc: aa1303e0    	mov	x0, x19
10006aec0: aa1603e1    	mov	x1, x22
10006aec4: a9497bfd    	ldp	x29, x30, [sp, #0x90]
10006aec8: a9484ff4    	ldp	x20, x19, [sp, #0x80]
10006aecc: a94757f6    	ldp	x22, x21, [sp, #0x70]
10006aed0: a9465ff8    	ldp	x24, x23, [sp, #0x60]
10006aed4: a94567fa    	ldp	x26, x25, [sp, #0x50]
10006aed8: 910283ff    	add	sp, sp, #0xa0
10006aedc: d65f03c0    	ret
