
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101440430 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE>:
101440430: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
101440434: a90167fa    	stp	x26, x25, [sp, #0x10]
101440438: a9025ff8    	stp	x24, x23, [sp, #0x20]
10144043c: a90357f6    	stp	x22, x21, [sp, #0x30]
101440440: a9044ff4    	stp	x20, x19, [sp, #0x40]
101440444: a9057bfd    	stp	x29, x30, [sp, #0x50]
101440448: 910143fd    	add	x29, sp, #0x50
10144044c: d10683ff    	sub	sp, sp, #0x1a0
101440450: aa0803f3    	mov	x19, x8
101440454: a9030be1    	stp	x1, x2, [sp, #0x30]
101440458: b4000e22    	cbz	x2, 0x10144061c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x1ec>
10144045c: aa0403f4    	mov	x20, x4
101440460: b4000de4    	cbz	x4, 0x10144061c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x1ec>
101440464: aa0003f6    	mov	x22, x0
101440468: f84b0ec8    	ldr	x8, [x22, #0xb0]!
10144046c: b50034c8    	cbnz	x8, 0x101440b04 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x6d4>
101440470: aa0303f5    	mov	x21, x3
101440474: 92800008    	mov	x8, #-0x1               ; =-1
101440478: f9005808    	str	x8, [x0, #0xb0]
10144047c: d0004502    	adrp	x2, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
101440480: 910e1842    	add	x2, x2, #0x386
101440484: 910223e8    	add	x8, sp, #0x88
101440488: 9102e000    	add	x0, x0, #0xb8
10144048c: aa1603e1    	mov	x1, x22
101440490: 528010c3    	mov	w3, #0x86               ; =134
101440494: 52800004    	mov	w4, #0x0                ; =0
101440498: 94017f5b    	bl	0x1014a0204 <__ZN8rusqlite16inner_connection15InnerConnection7prepare17h05de24fc7a518314E>
10144049c: f94002c8    	ldr	x8, [x22]
1014404a0: 91000508    	add	x8, x8, #0x1
1014404a4: f90002c8    	str	x8, [x22]
1014404a8: f94047e8    	ldr	x8, [sp, #0x88]
1014404ac: b4000b28    	cbz	x8, 0x101440610 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x1e0>
1014404b0: f9000ff3    	str	x19, [sp, #0x18]
1014404b4: 910223e8    	add	x8, sp, #0x88
1014404b8: 3cca83e0    	ldur	q0, [sp, #0xa8]
1014404bc: 3dc00d01    	ldr	q1, [x8, #0x30]
1014404c0: ad0307e0    	stp	q0, q1, [sp, #0x60]
1014404c4: f94067e8    	ldr	x8, [sp, #0xc8]
1014404c8: f90043e8    	str	x8, [sp, #0x80]
1014404cc: 3cc983e0    	ldur	q0, [sp, #0x98]
1014404d0: 3cc883e1    	ldur	q1, [sp, #0x88]
1014404d4: ad0203e1    	stp	q1, q0, [sp, #0x40]
1014404d8: 910223f3    	add	x19, sp, #0x88
1014404dc: 910223e0    	add	x0, sp, #0x88
1014404e0: aa1503e1    	mov	x1, x21
1014404e4: aa1403e2    	mov	x2, x20
1014404e8: 97fff677    	bl	0x10143dec4 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x15ac>
1014404ec: f0000148    	adrp	x8, 0x10146b000 <__ZN4core5slice4sort8unstable8heapsort8heapsort17h14b311923aeea277E+0x3bbc>
1014404f0: 913b4108    	add	x8, x8, #0xed0
1014404f4: a90f23f3    	stp	x19, x8, [sp, #0xf0]
1014404f8: d0004e60    	adrp	x0, 0x101e0e000 <_writev+0x101e0e000>
1014404fc: 910ac000    	add	x0, x0, #0x2b0
101440500: d102a3a8    	sub	x8, x29, #0xa8
101440504: 9103c3e1    	add	x1, sp, #0xf0
101440508: 940f2c1e    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
10144050c: f94047e1    	ldr	x1, [sp, #0x88]
101440510: b4000081    	cbz	x1, 0x101440520 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0xf0>
101440514: f9404be0    	ldr	x0, [sp, #0x90]
101440518: 52800022    	mov	w2, #0x1                ; =1
10144051c: 97d97870    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101440520: 910223e8    	add	x8, sp, #0x88
101440524: 3dc03100    	ldr	q0, [x8, #0xc0]
101440528: 3d8037e0    	str	q0, [sp, #0xd0]
10144052c: f85683a8    	ldur	x8, [x29, #-0x98]
101440530: f90073e8    	str	x8, [sp, #0xe0]
101440534: 940e179b    	bl	0x1017c63a0 <__ZN3std4time10SystemTime3now17h1f829e3f63b2f4c0E>
101440538: f81583a0    	stur	x0, [x29, #-0xa8]
10144053c: b81603a1    	stur	w1, [x29, #-0xa0]
101440540: 910223e8    	add	x8, sp, #0x88
101440544: d102a3a0    	sub	x0, x29, #0xa8
101440548: d2800001    	mov	x1, #0x0                ; =0
10144054c: 52800002    	mov	w2, #0x0                ; =0
101440550: 940e1780    	bl	0x1017c6350 <__ZN3std4time10SystemTime14duration_since17hb8d41322e5a737d4E>
101440554: b9408be8    	ldr	w8, [sp, #0x88]
101440558: f9404be9    	ldr	x9, [sp, #0x90]
10144055c: 7100011f    	cmp	w8, #0x0
101440560: 9a8913e8    	csel	x8, xzr, x9, ne
101440564: f90077e8    	str	x8, [sp, #0xe8]
101440568: 9100c3e8    	add	x8, sp, #0x30
10144056c: 90007149    	adrp	x9, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101440570: 9126c129    	add	x9, x9, #0x9b0
101440574: a908a7e8    	stp	x8, x9, [sp, #0x88]
101440578: 910343e8    	add	x8, sp, #0xd0
10144057c: 90007149    	adrp	x9, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101440580: 91290129    	add	x9, x9, #0xa40
101440584: a909a7e8    	stp	x8, x9, [sp, #0x98]
101440588: f00044e8    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
10144058c: 910c6108    	add	x8, x8, #0x318
101440590: 90007149    	adrp	x9, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101440594: 9127c129    	add	x9, x9, #0x9f0
101440598: a90aa7e8    	stp	x8, x9, [sp, #0xa8]
10144059c: f94023e3    	ldr	x3, [sp, #0x40]
1014405a0: f9403fe4    	ldr	x4, [sp, #0x78]
1014405a4: d102a3a0    	sub	x0, x29, #0xa8
1014405a8: 910223e1    	add	x1, sp, #0x88
1014405ac: 52800062    	mov	w2, #0x3                ; =3
1014405b0: 97fef4da    	bl	0x1013fd918 <__ZN7bincode6config3int17cast_u64_to_usize17hdd90f9a911882862E+0xa4>
1014405b4: f85583a8    	ldur	x8, [x29, #-0xa8]
1014405b8: d2800269    	mov	x9, #0x13               ; =19
1014405bc: f2f00009    	movk	x9, #0x8000, lsl #48
1014405c0: eb09011f    	cmp	x8, x9
1014405c4: 54000341    	b.ne	0x10144062c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x1fc>
1014405c8: 9103a3e8    	add	x8, sp, #0xe8
1014405cc: d10363b9    	sub	x25, x29, #0xd8
1014405d0: 910103e9    	add	x9, sp, #0x40
1014405d4: a932a7a8    	stp	x8, x9, [x29, #-0xd8]
1014405d8: f81383bf    	stur	xzr, [x29, #-0xc8]
1014405dc: d102a3a0    	sub	x0, x29, #0xa8
1014405e0: d10363a1    	sub	x1, x29, #0xd8
1014405e4: 97ff3480    	bl	0x10140d7e4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2498>
1014405e8: f85583b7    	ldur	x23, [x29, #-0xa8]
1014405ec: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014405f0: eb0802ff    	cmp	x23, x8
1014405f4: 54000361    	b.ne	0x101440660 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x230>
1014405f8: 91002320    	add	x0, x25, #0x8
1014405fc: 94004a60    	bl	0x101452f7c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5af4>
101440600: d2800008    	mov	x8, #0x0                ; =0
101440604: d2800017    	mov	x23, #0x0               ; =0
101440608: 52800109    	mov	w9, #0x8                ; =8
10144060c: 1400004d    	b	0x101440740 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x310>
101440610: 910223e8    	add	x8, sp, #0x88
101440614: 91002100    	add	x0, x8, #0x8
101440618: 94004bc7    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
10144061c: 52800108    	mov	w8, #0x8                ; =8
101440620: a900227f    	stp	xzr, x8, [x19]
101440624: f9000a7f    	str	xzr, [x19, #0x10]
101440628: 140000d1    	b	0x10144096c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x53c>
10144062c: a9772ba9    	ldp	x9, x10, [x29, #-0x90]
101440630: 910223eb    	add	x11, sp, #0x88
101440634: 3ccc8160    	ldur	q0, [x11, #0xc8]
101440638: 3c870160    	stur	q0, [x11, #0x70]
10144063c: f9007be8    	str	x8, [sp, #0xf0]
101440640: a910abe9    	stp	x9, x10, [sp, #0x108]
101440644: 52800108    	mov	w8, #0x8                ; =8
101440648: a93423bf    	stp	xzr, x8, [x29, #-0xc0]
10144064c: f81503bf    	stur	xzr, [x29, #-0xb0]
101440650: 9103c3e0    	add	x0, sp, #0xf0
101440654: 94004bb8    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
101440658: 5280011a    	mov	w26, #0x8               ; =8
10144065c: 1400004d    	b	0x101440790 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x360>
101440660: f85603b8    	ldur	x24, [x29, #-0xa0]
101440664: 97d97823    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101440668: 52801400    	mov	w0, #0xa0               ; =160
10144066c: 52800101    	mov	w1, #0x8                ; =8
101440670: 97d9781a    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101440674: b4003100    	cbz	x0, 0x101440c94 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x864>
101440678: aa0003f6    	mov	x22, x0
10144067c: d280001a    	mov	x26, #0x0               ; =0
101440680: 910223e9    	add	x9, sp, #0x88
101440684: 3dc03520    	ldr	q0, [x9, #0xd0]
101440688: 3d800400    	str	q0, [x0, #0x10]
10144068c: f85783a8    	ldur	x8, [x29, #-0x88]
101440690: f9001008    	str	x8, [x0, #0x20]
101440694: a9006017    	stp	x23, x24, [x0]
101440698: 52800088    	mov	w8, #0x4                ; =4
10144069c: a93403a8    	stp	x8, x0, [x29, #-0xc0]
1014406a0: 52800037    	mov	w23, #0x1               ; =1
1014406a4: f81503b7    	stur	x23, [x29, #-0xb0]
1014406a8: 3dc02520    	ldr	q0, [x9, #0x90]
1014406ac: f85383a8    	ldur	x8, [x29, #-0xc8]
1014406b0: f81903a8    	stur	x8, [x29, #-0x70]
1014406b4: d102a3bb    	sub	x27, x29, #0xa8
1014406b8: d2f00013    	mov	x19, #-0x8000000000000000 ; =-9223372036854775808
1014406bc: 3c9803a0    	stur	q0, [x29, #-0x80]
1014406c0: 1400000a    	b	0x1014406e8 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x2b8>
1014406c4: 8b1a02c8    	add	x8, x22, x26
1014406c8: a902e518    	stp	x24, x25, [x8, #0x28]
1014406cc: 3cc10360    	ldur	q0, [x27, #0x10]
1014406d0: f8420369    	ldur	x9, [x27, #0x20]
1014406d4: f9002509    	str	x9, [x8, #0x48]
1014406d8: 3c838100    	stur	q0, [x8, #0x38]
1014406dc: 910006f7    	add	x23, x23, #0x1
1014406e0: f81503b7    	stur	x23, [x29, #-0xb0]
1014406e4: 9100a35a    	add	x26, x26, #0x28
1014406e8: d102a3a0    	sub	x0, x29, #0xa8
1014406ec: d10203a1    	sub	x1, x29, #0x80
1014406f0: 97ff343d    	bl	0x10140d7e4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2498>
1014406f4: f85583b8    	ldur	x24, [x29, #-0xa8]
1014406f8: eb13031f    	cmp	x24, x19
1014406fc: 540001a0    	b.eq	0x101440730 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x300>
101440700: f85603b9    	ldur	x25, [x29, #-0xa0]
101440704: f85403a8    	ldur	x8, [x29, #-0xc0]
101440708: eb0802ff    	cmp	x23, x8
10144070c: 54fffdc1    	b.ne	0x1014406c4 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x294>
101440710: d10303a0    	sub	x0, x29, #0xc0
101440714: aa1703e1    	mov	x1, x23
101440718: 52800022    	mov	w2, #0x1                ; =1
10144071c: 52800103    	mov	w3, #0x8                ; =8
101440720: 52800504    	mov	w4, #0x28               ; =40
101440724: 9417a04b    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101440728: f85483b6    	ldur	x22, [x29, #-0xb8]
10144072c: 17ffffe6    	b	0x1014406c4 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x294>
101440730: d10203a8    	sub	x8, x29, #0x80
101440734: b27d0100    	orr	x0, x8, #0x8
101440738: 94004a11    	bl	0x101452f7c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5af4>
10144073c: a97427a8    	ldp	x8, x9, [x29, #-0xc0]
101440740: a90fa7e8    	stp	x8, x9, [sp, #0xf8]
101440744: 910223e8    	add	x8, sp, #0x88
101440748: 3cc70100    	ldur	q0, [x8, #0x70]
10144074c: 3c9403a0    	stur	q0, [x29, #-0xc0]
101440750: f81503b7    	stur	x23, [x29, #-0xb0]
101440754: f85483ba    	ldur	x26, [x29, #-0xb8]
101440758: f1000aff    	cmp	x23, #0x2
10144075c: 54001da2    	b.hs	0x101440b10 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x6e0>
101440760: b4000197    	cbz	x23, 0x101440790 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x360>
101440764: 52800037    	mov	w23, #0x1               ; =1
101440768: f9400b48    	ldr	x8, [x26, #0x10]
10144076c: eb14011f    	cmp	x8, x20
101440770: 540010e1    	b.ne	0x10144098c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x55c>
101440774: f9400740    	ldr	x0, [x26, #0x8]
101440778: aa1503e1    	mov	x1, x21
10144077c: aa1403e2    	mov	x2, x20
101440780: 941a2527    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101440784: 7100001f    	cmp	w0, #0x0
101440788: 1a9f07e8    	cset	w8, ne
10144078c: 14000081    	b	0x101440990 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x560>
101440790: d2800019    	mov	x25, #0x0               ; =0
101440794: 52800009    	mov	w9, #0x0                ; =0
101440798: d2800008    	mov	x8, #0x0                ; =0
10144079c: f85403bb    	ldur	x27, [x29, #-0xc0]
1014407a0: 52800118    	mov	w24, #0x8               ; =8
1014407a4: aa1a03f3    	mov	x19, x26
1014407a8: a93863a8    	stp	x8, x24, [x29, #-0x80]
1014407ac: a908ebfa    	stp	x26, x26, [sp, #0x88]
1014407b0: a909cffb    	stp	x27, x19, [sp, #0x98]
1014407b4: f90003fa    	str	x26, [sp]
1014407b8: f9000bfb    	str	x27, [sp, #0x10]
1014407bc: b4000559    	cbz	x25, 0x101440864 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x434>
1014407c0: b9000fe9    	str	w9, [sp, #0xc]
1014407c4: a9405754    	ldp	x20, x21, [x26]
1014407c8: 9100a35c    	add	x28, x26, #0x28
1014407cc: f9400b56    	ldr	x22, [x26, #0x10]
1014407d0: 97d977c8    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014407d4: 528000e0    	mov	w0, #0x7                ; =7
1014407d8: 52800021    	mov	w1, #0x1                ; =1
1014407dc: 97d977bf    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014407e0: b4002440    	cbz	x0, 0x101440c68 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x838>
1014407e4: aa0003f7    	mov	x23, x0
1014407e8: 528dee88    	mov	w8, #0x6f74             ; =28532
1014407ec: 72af2e48    	movk	w8, #0x7972, lsl #16
1014407f0: b8003008    	stur	w8, [x0, #0x3]
1014407f4: 528d2d08    	mov	w8, #0x6968             ; =26984
1014407f8: 72ae8e68    	movk	w8, #0x7473, lsl #16
1014407fc: b9000008    	str	w8, [x0]
101440800: a90f57f4    	stp	x20, x21, [sp, #0xf0]
101440804: f90083f6    	str	x22, [sp, #0x100]
101440808: d102a3a8    	sub	x8, x29, #0xa8
10144080c: 9103c3e0    	add	x0, sp, #0xf0
101440810: 940f3a6f    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101440814: 910223e8    	add	x8, sp, #0x88
101440818: 3dc03100    	ldr	q0, [x8, #0xc0]
10144081c: f85683a8    	ldur	x8, [x29, #-0x98]
101440820: 3d800300    	str	q0, [x24]
101440824: a9015308    	stp	x8, x20, [x24, #0x10]
101440828: a9025b15    	stp	x21, x22, [x24, #0x20]
10144082c: 528000e8    	mov	w8, #0x7                ; =7
101440830: a9035f08    	stp	x8, x23, [x24, #0x30]
101440834: f00044e8    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101440838: 3dc0d900    	ldr	q0, [x8, #0x360]
10144083c: 3d800be0    	str	q0, [sp, #0x20]
101440840: 3d801300    	str	q0, [x24, #0x40]
101440844: b9400fe8    	ldr	w8, [sp, #0xc]
101440848: 39018308    	strb	w8, [x24, #0x60]
10144084c: 52800128    	mov	w8, #0x9                ; =9
101440850: 39018708    	strb	w8, [x24, #0x61]
101440854: f100073f    	cmp	x25, #0x1
101440858: 540000a1    	b.ne	0x10144086c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x43c>
10144085c: 52800038    	mov	w24, #0x1               ; =1
101440860: 1400002f    	b	0x10144091c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x4ec>
101440864: d2800018    	mov	x24, #0x0               ; =0
101440868: 1400002d    	b	0x10144091c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x4ec>
10144086c: 91032719    	add	x25, x24, #0xc9
101440870: 9101435c    	add	x28, x26, #0x50
101440874: 52800038    	mov	w24, #0x1               ; =1
101440878: 52812016    	mov	w22, #0x900             ; =2304
10144087c: aa1c03fa    	mov	x26, x28
101440880: a9fdd754    	ldp	x20, x21, [x26, #-0x28]!
101440884: f9400b5b    	ldr	x27, [x26, #0x10]
101440888: 97d9779a    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10144088c: 528000e0    	mov	w0, #0x7                ; =7
101440890: 52800021    	mov	w1, #0x1                ; =1
101440894: 97d97791    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101440898: b4001ea0    	cbz	x0, 0x101440c6c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x83c>
10144089c: aa0003f7    	mov	x23, x0
1014408a0: 528dee88    	mov	w8, #0x6f74             ; =28532
1014408a4: 72af2e48    	movk	w8, #0x7972, lsl #16
1014408a8: b8003008    	stur	w8, [x0, #0x3]
1014408ac: 528d2d08    	mov	w8, #0x6968             ; =26984
1014408b0: 72ae8e68    	movk	w8, #0x7473, lsl #16
1014408b4: b9000008    	str	w8, [x0]
1014408b8: a90f57f4    	stp	x20, x21, [sp, #0xf0]
1014408bc: f90083fb    	str	x27, [sp, #0x100]
1014408c0: d102a3a8    	sub	x8, x29, #0xa8
1014408c4: 9103c3e0    	add	x0, sp, #0xf0
1014408c8: 940f3a41    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1014408cc: 9101435c    	add	x28, x26, #0x50
1014408d0: 910223e8    	add	x8, sp, #0x88
1014408d4: 3dc03100    	ldr	q0, [x8, #0xc0]
1014408d8: f85683a8    	ldur	x8, [x29, #-0x98]
1014408dc: 3c99f320    	stur	q0, [x25, #-0x61]
1014408e0: f81af328    	stur	x8, [x25, #-0x51]
1014408e4: f81b7334    	stur	x20, [x25, #-0x49]
1014408e8: f81bf335    	stur	x21, [x25, #-0x41]
1014408ec: f81c733b    	stur	x27, [x25, #-0x39]
1014408f0: 528000e8    	mov	w8, #0x7                ; =7
1014408f4: f81cf328    	stur	x8, [x25, #-0x31]
1014408f8: f81d7337    	stur	x23, [x25, #-0x29]
1014408fc: 3dc00be0    	ldr	q0, [sp, #0x20]
101440900: 3c9df320    	stur	q0, [x25, #-0x21]
101440904: 91000718    	add	x24, x24, #0x1
101440908: 781ff336    	sturh	w22, [x25, #-0x1]
10144090c: 9101a339    	add	x25, x25, #0x68
101440910: 9100a348    	add	x8, x26, #0x28
101440914: eb13011f    	cmp	x8, x19
101440918: 54fffb21    	b.ne	0x10144087c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x44c>
10144091c: f81903b8    	stur	x24, [x29, #-0x70]
101440920: f9400be8    	ldr	x8, [sp, #0x10]
101440924: b40000c8    	cbz	x8, 0x10144093c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x50c>
101440928: 8b080908    	add	x8, x8, x8, lsl #2
10144092c: d37df101    	lsl	x1, x8, #3
101440930: f94003e0    	ldr	x0, [sp]
101440934: 52800102    	mov	w2, #0x8                ; =8
101440938: 97d97769    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10144093c: 3cd803a0    	ldur	q0, [x29, #-0x80]
101440940: f9400fe9    	ldr	x9, [sp, #0x18]
101440944: 3d800120    	str	q0, [x9]
101440948: f85903a8    	ldur	x8, [x29, #-0x70]
10144094c: f9000928    	str	x8, [x9, #0x10]
101440950: f9406be1    	ldr	x1, [sp, #0xd0]
101440954: b4000081    	cbz	x1, 0x101440964 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x534>
101440958: f9406fe0    	ldr	x0, [sp, #0xd8]
10144095c: 52800022    	mov	w2, #0x1                ; =1
101440960: 97d9775f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101440964: 910103e0    	add	x0, sp, #0x40
101440968: 94004bdc    	bl	0x1014538d8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6450>
10144096c: 910683ff    	add	sp, sp, #0x1a0
101440970: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101440974: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101440978: a94357f6    	ldp	x22, x21, [sp, #0x30]
10144097c: a9425ff8    	ldp	x24, x23, [sp, #0x20]
101440980: a94167fa    	ldp	x26, x25, [sp, #0x10]
101440984: a8c66ffc    	ldp	x28, x27, [sp], #0x60
101440988: d65f03c0    	ret
10144098c: 52800028    	mov	w8, #0x1                ; =1
101440990: b9000fe8    	str	w8, [sp, #0xc]
101440994: d2800016    	mov	x22, #0x0               ; =0
101440998: 52800028    	mov	w8, #0x1                ; =1
10144099c: cb170113    	sub	x19, x8, x23
1014409a0: 14000005    	b	0x1014409b4 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x584>
1014409a4: 9100a2d6    	add	x22, x22, #0x28
1014409a8: 91000673    	add	x19, x19, #0x1
1014409ac: f100067f    	cmp	x19, #0x1
1014409b0: 540005e0    	b.eq	0x101440a6c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x63c>
1014409b4: 8b160348    	add	x8, x26, x22
1014409b8: f9400909    	ldr	x9, [x8, #0x10]
1014409bc: eb14013f    	cmp	x9, x20
1014409c0: 54ffff21    	b.ne	0x1014409a4 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x574>
1014409c4: f9400518    	ldr	x24, [x8, #0x8]
1014409c8: aa1803e0    	mov	x0, x24
1014409cc: aa1503e1    	mov	x1, x21
1014409d0: aa1403e2    	mov	x2, x20
1014409d4: 941a2492    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
1014409d8: 35fffe60    	cbnz	w0, 0x1014409a4 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x574>
1014409dc: 8b160359    	add	x25, x26, x22
1014409e0: f8428721    	ldr	x1, [x25], #0x28
1014409e4: b4000081    	cbz	x1, 0x1014409f4 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x5c4>
1014409e8: aa1803e0    	mov	x0, x24
1014409ec: 52800022    	mov	w2, #0x1                ; =1
1014409f0: 97d9773b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014409f4: aa1a03f6    	mov	x22, x26
1014409f8: b40007b3    	cbz	x19, 0x101440aec <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x6bc>
1014409fc: cb1303fb    	neg	x27, x19
101440a00: 5280003a    	mov	w26, #0x1               ; =1
101440a04: 928004fc    	mov	x28, #-0x28             ; =-40
101440a08: 14000009    	b	0x101440a2c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x5fc>
101440a0c: 9b1c6748    	madd	x8, x26, x28, x25
101440a10: ad400720    	ldp	q0, q1, [x25]
101440a14: f9401329    	ldr	x9, [x25, #0x20]
101440a18: f9001109    	str	x9, [x8, #0x20]
101440a1c: ad000500    	stp	q0, q1, [x8]
101440a20: 9100a339    	add	x25, x25, #0x28
101440a24: f100077b    	subs	x27, x27, #0x1
101440a28: 54000260    	b.eq	0x101440a74 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x644>
101440a2c: f9400b28    	ldr	x8, [x25, #0x10]
101440a30: eb14011f    	cmp	x8, x20
101440a34: 54fffec1    	b.ne	0x101440a0c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x5dc>
101440a38: f9400738    	ldr	x24, [x25, #0x8]
101440a3c: aa1803e0    	mov	x0, x24
101440a40: aa1503e1    	mov	x1, x21
101440a44: aa1403e2    	mov	x2, x20
101440a48: 941a2475    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101440a4c: 35fffe00    	cbnz	w0, 0x101440a0c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x5dc>
101440a50: 9100075a    	add	x26, x26, #0x1
101440a54: f9400321    	ldr	x1, [x25]
101440a58: b4fffe41    	cbz	x1, 0x101440a20 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x5f0>
101440a5c: aa1803e0    	mov	x0, x24
101440a60: 52800022    	mov	w2, #0x1                ; =1
101440a64: 97d9771e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101440a68: 17ffffee    	b	0x101440a20 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x5f0>
101440a6c: aa1a03f6    	mov	x22, x26
101440a70: d280001a    	mov	x26, #0x0               ; =0
101440a74: d2962768    	mov	x8, #0xb13b             ; =45371
101440a78: f2a76268    	movk	x8, #0x3b13, lsl #16
101440a7c: f2c27628    	movk	x8, #0x13b1, lsl #32
101440a80: f2e02768    	movk	x8, #0x13b, lsl #48
101440a84: cb1a02f9    	sub	x25, x23, x26
101440a88: eb08033f    	cmp	x25, x8
101440a8c: f81503b9    	stur	x25, [x29, #-0xb0]
101440a90: f85403bb    	ldur	x27, [x29, #-0xc0]
101440a94: 52800d08    	mov	w8, #0x68               ; =104
101440a98: 9b087f34    	mul	x20, x25, x8
101440a9c: 540000c9    	b.ls	0x101440ab4 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x684>
101440aa0: d2800000    	mov	x0, #0x0                ; =0
101440aa4: aa1603fa    	mov	x26, x22
101440aa8: aa1403e1    	mov	x1, x20
101440aac: 941a0a32    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101440ab0: 1400007c    	b	0x101440ca0 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x870>
101440ab4: 52800508    	mov	w8, #0x28               ; =40
101440ab8: aa1603fa    	mov	x26, x22
101440abc: 9b085b33    	madd	x19, x25, x8, x22
101440ac0: b40001b4    	cbz	x20, 0x101440af4 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x6c4>
101440ac4: 97d9770b    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101440ac8: aa1403e0    	mov	x0, x20
101440acc: 52800101    	mov	w1, #0x8                ; =8
101440ad0: 97d97702    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101440ad4: aa0003f8    	mov	x24, x0
101440ad8: 52800100    	mov	w0, #0x8                ; =8
101440adc: b9400fe9    	ldr	w9, [sp, #0xc]
101440ae0: b4fffe58    	cbz	x24, 0x101440aa8 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x678>
101440ae4: aa1903e8    	mov	x8, x25
101440ae8: 17ffff30    	b	0x1014407a8 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x378>
101440aec: 5280003a    	mov	w26, #0x1               ; =1
101440af0: 17ffffe1    	b	0x101440a74 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x644>
101440af4: d2800008    	mov	x8, #0x0                ; =0
101440af8: 52800118    	mov	w24, #0x8               ; =8
101440afc: b9400fe9    	ldr	w9, [sp, #0xc]
101440b00: 17ffff2a    	b	0x1014407a8 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x378>
101440b04: d0007140    	adrp	x0, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
101440b08: 91154000    	add	x0, x0, #0x550
101440b0c: 941a0ad0    	bl	0x101ac364c <__ZN4core4cell22panic_already_borrowed17h323724f51fff7f07E>
101440b10: f10056ff    	cmp	x23, #0x15
101440b14: 54000b62    	b.hs	0x101440c80 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x850>
101440b18: aa1a03e0    	mov	x0, x26
101440b1c: aa1703e1    	mov	x1, x23
101440b20: 94006171    	bl	0x1014590e4 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbc5c>
101440b24: 52800508    	mov	w8, #0x28               ; =40
101440b28: f9401358    	ldr	x24, [x26, #0x20]
101440b2c: 928004e9    	mov	x9, #-0x28              ; =-40
101440b30: 9b0826e9    	madd	x9, x23, x8, x9
101440b34: b202e7e8    	mov	x8, #-0x3333333333333334 ; =-3689348814741910324
101440b38: f29999a8    	movk	x8, #0xcccd
101440b3c: 9bc87d28    	umulh	x8, x9, x8
101440b40: d345fd08    	lsr	x8, x8, #5
101440b44: f102813f    	cmp	x9, #0xa0
101440b48: 54000062    	b.hs	0x101440b54 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x724>
101440b4c: d2800009    	mov	x9, #0x0                ; =0
101440b50: 1400001f    	b	0x101440bcc <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x79c>
101440b54: 9101234a    	add	x10, x26, #0x48
101440b58: 927ee109    	and	x9, x8, #0x7fffffffffffffc
101440b5c: 9100a14a    	add	x10, x10, #0x28
101440b60: aa0903ed    	mov	x13, x9
101440b64: aa1803ee    	mov	x14, x24
101440b68: aa1803ec    	mov	x12, x24
101440b6c: aa1803eb    	mov	x11, x24
101440b70: f85d814f    	ldur	x15, [x10, #-0x28]
101440b74: f9400150    	ldr	x16, [x10]
101440b78: f9401551    	ldr	x17, [x10, #0x28]
101440b7c: eb0f031f    	cmp	x24, x15
101440b80: 9a8fc318    	csel	x24, x24, x15, gt
101440b84: eb1001df    	cmp	x14, x16
101440b88: 9a90c1ce    	csel	x14, x14, x16, gt
101440b8c: eb11019f    	cmp	x12, x17
101440b90: 9a91c18c    	csel	x12, x12, x17, gt
101440b94: f940294f    	ldr	x15, [x10, #0x50]
101440b98: eb0f017f    	cmp	x11, x15
101440b9c: 9a8fc16b    	csel	x11, x11, x15, gt
101440ba0: 9102814a    	add	x10, x10, #0xa0
101440ba4: f10011ad    	subs	x13, x13, #0x4
101440ba8: 54fffe41    	b.ne	0x101440b70 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x740>
101440bac: eb0e031f    	cmp	x24, x14
101440bb0: 9a8ec30a    	csel	x10, x24, x14, gt
101440bb4: eb0c015f    	cmp	x10, x12
101440bb8: 9a8cc14a    	csel	x10, x10, x12, gt
101440bbc: eb0b015f    	cmp	x10, x11
101440bc0: 9a8bc158    	csel	x24, x10, x11, gt
101440bc4: eb09011f    	cmp	x8, x9
101440bc8: 54000140    	b.eq	0x101440bf0 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x7c0>
101440bcc: cb090108    	sub	x8, x8, x9
101440bd0: 5280050a    	mov	w10, #0x28              ; =40
101440bd4: 9b0a6929    	madd	x9, x9, x10, x26
101440bd8: 91012129    	add	x9, x9, #0x48
101440bdc: f842852a    	ldr	x10, [x9], #0x28
101440be0: eb0a031f    	cmp	x24, x10
101440be4: 9a8ac318    	csel	x24, x24, x10, gt
101440be8: f1000508    	subs	x8, x8, #0x1
101440bec: 54ffff81    	b.ne	0x101440bdc <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x7ac>
101440bf0: f10052f3    	subs	x19, x23, #0x14
101440bf4: 54000243    	b.lo	0x101440c3c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x80c>
101440bf8: 52800297    	mov	w23, #0x14              ; =20
101440bfc: f81503b7    	stur	x23, [x29, #-0xb0]
101440c00: 540001e0    	b.eq	0x101440c3c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x80c>
101440c04: aa1a03f9    	mov	x25, x26
101440c08: 910ca356    	add	x22, x26, #0x328
101440c0c: 52800297    	mov	w23, #0x14              ; =20
101440c10: 14000004    	b	0x101440c20 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x7f0>
101440c14: 9100a2d6    	add	x22, x22, #0x28
101440c18: f1000673    	subs	x19, x19, #0x1
101440c1c: 540000e0    	b.eq	0x101440c38 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x808>
101440c20: f85f82c1    	ldur	x1, [x22, #-0x8]
101440c24: b4ffff81    	cbz	x1, 0x101440c14 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x7e4>
101440c28: f94002c0    	ldr	x0, [x22]
101440c2c: 52800022    	mov	w2, #0x1                ; =1
101440c30: 97d976ab    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101440c34: 17fffff8    	b	0x101440c14 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x7e4>
101440c38: aa1903fa    	mov	x26, x25
101440c3c: fd400f40    	ldr	d0, [x26, #0x18]
101440c40: fd402341    	ldr	d1, [x26, #0x40]
101440c44: 1e6c1002    	fmov	d2, #0.50000000
101440c48: 1e622821    	fadd	d1, d1, d2
101440c4c: 1e612000    	fcmp	d0, d1
101440c50: 5400008b    	b.lt	0x101440c60 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x830>
101440c54: f9401348    	ldr	x8, [x26, #0x20]
101440c58: eb18011f    	cmp	x8, x24
101440c5c: 54ffd860    	b.eq	0x101440768 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x338>
101440c60: b9000fff    	str	wzr, [sp, #0xc]
101440c64: 17ffff4c    	b	0x101440994 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x564>
101440c68: d2800018    	mov	x24, #0x0               ; =0
101440c6c: f9004bfc    	str	x28, [sp, #0x90]
101440c70: 52800020    	mov	w0, #0x1                ; =1
101440c74: 528000e1    	mov	w1, #0x7                ; =7
101440c78: 941a09bf    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101440c7c: 14000009    	b	0x101440ca0 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x870>
101440c80: 910223e2    	add	x2, sp, #0x88
101440c84: aa1a03e0    	mov	x0, x26
101440c88: aa1703e1    	mov	x1, x23
101440c8c: 9400647d    	bl	0x101459e80 <__ZN4core5slice4sort6stable14driftsort_main17h860c457949416f3eE>
101440c90: 17ffffa5    	b	0x101440b24 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x6f4>
101440c94: 52800100    	mov	w0, #0x8                ; =8
101440c98: 52801401    	mov	w1, #0xa0               ; =160
101440c9c: 941a09b6    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101440ca0: d4200020    	brk	#0x1
101440ca4: 14000001    	b	0x101440ca8 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x878>
101440ca8: aa0003f3    	mov	x19, x0
101440cac: 14000032    	b	0x101440d74 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x944>
101440cb0: aa0003f3    	mov	x19, x0
101440cb4: b4000157    	cbz	x23, 0x101440cdc <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x8ac>
101440cb8: aa1803e0    	mov	x0, x24
101440cbc: aa1703e1    	mov	x1, x23
101440cc0: 52800022    	mov	w2, #0x1                ; =1
101440cc4: 97d97686    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101440cc8: 14000005    	b	0x101440cdc <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x8ac>
101440ccc: aa0003f3    	mov	x19, x0
101440cd0: d2800018    	mov	x24, #0x0               ; =0
101440cd4: 1400001b    	b	0x101440d40 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x910>
101440cd8: aa0003f3    	mov	x19, x0
101440cdc: 91002320    	add	x0, x25, #0x8
101440ce0: 940048a7    	bl	0x101452f7c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5af4>
101440ce4: 1400003c    	b	0x101440dd4 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x9a4>
101440ce8: 941a0c0f    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101440cec: aa0003f3    	mov	x19, x0
101440cf0: f94047e1    	ldr	x1, [sp, #0x88]
101440cf4: b40007a1    	cbz	x1, 0x101440de8 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x9b8>
101440cf8: f9404be0    	ldr	x0, [sp, #0x90]
101440cfc: 14000039    	b	0x101440de0 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x9b0>
101440d00: aa0003f3    	mov	x19, x0
101440d04: 14000039    	b	0x101440de8 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x9b8>
101440d08: f94002c8    	ldr	x8, [x22]
101440d0c: 91000508    	add	x8, x8, #0x1
101440d10: f90002c8    	str	x8, [x22]
101440d14: 941a2230    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101440d18: aa0003f3    	mov	x19, x0
101440d1c: 1400002e    	b	0x101440dd4 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x9a4>
101440d20: aa0003f3    	mov	x19, x0
101440d24: b4000238    	cbz	x24, 0x101440d68 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x938>
101440d28: aa1903e0    	mov	x0, x25
101440d2c: aa1803e1    	mov	x1, x24
101440d30: 52800022    	mov	w2, #0x1                ; =1
101440d34: 97d9766a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101440d38: 1400000c    	b	0x101440d68 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x938>
101440d3c: aa0003f3    	mov	x19, x0
101440d40: f9004bfc    	str	x28, [sp, #0x90]
101440d44: b40000b4    	cbz	x20, 0x101440d58 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x928>
101440d48: aa1503e0    	mov	x0, x21
101440d4c: aa1403e1    	mov	x1, x20
101440d50: 52800022    	mov	w2, #0x1                ; =1
101440d54: 97d97662    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101440d58: aa1703e0    	mov	x0, x23
101440d5c: 528000e1    	mov	w1, #0x7                ; =7
101440d60: 1400000d    	b	0x101440d94 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x964>
101440d64: aa0003f3    	mov	x19, x0
101440d68: d10203a8    	sub	x8, x29, #0x80
101440d6c: b27d0100    	orr	x0, x8, #0x8
101440d70: 94004883    	bl	0x101452f7c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5af4>
101440d74: d10303a0    	sub	x0, x29, #0xc0
101440d78: 97d3e94a    	bl	0x10093b2a0 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x28278>
101440d7c: 14000016    	b	0x101440dd4 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x9a4>
101440d80: 941a0be9    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101440d84: aa0003f3    	mov	x19, x0
101440d88: b40000b4    	cbz	x20, 0x101440d9c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x96c>
101440d8c: aa1503e0    	mov	x0, x21
101440d90: aa1403e1    	mov	x1, x20
101440d94: 52800022    	mov	w2, #0x1                ; =1
101440d98: 97d97651    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101440d9c: f81903b8    	stur	x24, [x29, #-0x70]
101440da0: 910223e0    	add	x0, sp, #0x88
101440da4: 97d3d3c5    	bl	0x100935cb8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x22c90>
101440da8: d10203a0    	sub	x0, x29, #0x80
101440dac: 9400542e    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101440db0: 14000009    	b	0x101440dd4 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x9a4>
101440db4: aa0003f3    	mov	x19, x0
101440db8: b5000219    	cbnz	x25, 0x101440df8 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x9c8>
101440dbc: b40000db    	cbz	x27, 0x101440dd4 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x9a4>
101440dc0: 8b1b0b68    	add	x8, x27, x27, lsl #2
101440dc4: d37df101    	lsl	x1, x8, #3
101440dc8: aa1a03e0    	mov	x0, x26
101440dcc: 52800102    	mov	w2, #0x8                ; =8
101440dd0: 97d97643    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101440dd4: f9406be1    	ldr	x1, [sp, #0xd0]
101440dd8: b4000081    	cbz	x1, 0x101440de8 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x9b8>
101440ddc: f9406fe0    	ldr	x0, [sp, #0xd8]
101440de0: 52800022    	mov	w2, #0x1                ; =1
101440de4: 97d9763e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101440de8: 910103e0    	add	x0, sp, #0x40
101440dec: 94004abb    	bl	0x1014538d8 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6450>
101440df0: aa1303e0    	mov	x0, x19
101440df4: 941a21f8    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101440df8: 91002354    	add	x20, x26, #0x8
101440dfc: 14000004    	b	0x101440e0c <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x9dc>
101440e00: 9100a294    	add	x20, x20, #0x28
101440e04: f1000739    	subs	x25, x25, #0x1
101440e08: 54fffda0    	b.eq	0x101440dbc <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x98c>
101440e0c: f85f8281    	ldur	x1, [x20, #-0x8]
101440e10: b4ffff81    	cbz	x1, 0x101440e00 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x9d0>
101440e14: f9400280    	ldr	x0, [x20]
101440e18: 52800022    	mov	w2, #0x1                ; =1
101440e1c: 97d97630    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101440e20: 17fffff8    	b	0x101440e00 <__ZN17otty_autocomplete7history14CommandHistory21full_line_completions17hb7762b23bfcb92ecE+0x9d0>
101440e24: 941a0bc0    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
