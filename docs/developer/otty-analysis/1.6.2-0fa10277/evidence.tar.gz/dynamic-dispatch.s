
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010140e9d0 <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE>:
10140e9d0: d101c3ff    	sub	sp, sp, #0x70
10140e9d4: a9035ff8    	stp	x24, x23, [sp, #0x30]
10140e9d8: a90457f6    	stp	x22, x21, [sp, #0x40]
10140e9dc: a9054ff4    	stp	x20, x19, [sp, #0x50]
10140e9e0: a9067bfd    	stp	x29, x30, [sp, #0x60]
10140e9e4: 910183fd    	add	x29, sp, #0x60
10140e9e8: aa0403f8    	mov	x24, x4
10140e9ec: aa0303f7    	mov	x23, x3
10140e9f0: aa0203f4    	mov	x20, x2
10140e9f4: aa0103f5    	mov	x21, x1
10140e9f8: aa0003f6    	mov	x22, x0
10140e9fc: aa0803f3    	mov	x19, x8
10140ea00: 910063e0    	add	x0, sp, #0x18
10140ea04: aa1603e1    	mov	x1, x22
10140ea08: aa1503e2    	mov	x2, x21
10140ea0c: aa1403e3    	mov	x3, x20
10140ea10: 9400056e    	bl	0x10140ffc8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x360>
10140ea14: f9400fe8    	ldr	x8, [sp, #0x18]
10140ea18: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10140ea1c: eb09011f    	cmp	x8, x9
10140ea20: 540003c1    	b.ne	0x10140ea98 <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0xc8>
10140ea24: f9401709    	ldr	x9, [x24, #0x28]
10140ea28: f10012bf    	cmp	x21, #0x4
10140ea2c: 54000101    	b.ne	0x10140ea4c <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0x7c>
10140ea30: f9401688    	ldr	x8, [x20, #0x28]
10140ea34: b94002ca    	ldr	w10, [x22]
10140ea38: 528e8deb    	mov	w11, #0x746f            ; =29807
10140ea3c: 72af2e8b    	movk	w11, #0x7974, lsl #16
10140ea40: 6b0b015f    	cmp	w10, w11
10140ea44: fa400904    	ccmp	x8, #0x0, #0x4, eq
10140ea48: 54000861    	b.ne	0x10140eb54 <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0x184>
10140ea4c: 910063e8    	add	x8, sp, #0x18
10140ea50: aa1703e0    	mov	x0, x23
10140ea54: aa1603e1    	mov	x1, x22
10140ea58: aa1503e2    	mov	x2, x21
10140ea5c: d63f0120    	blr	x9
10140ea60: f9400fe8    	ldr	x8, [sp, #0x18]
10140ea64: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10140ea68: eb09011f    	cmp	x8, x9
10140ea6c: 54000201    	b.ne	0x10140eaac <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0xdc>
10140ea70: b4000295    	cbz	x21, 0x10140eac0 <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0xf0>
10140ea74: 97da3f1f    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140ea78: aa1503e0    	mov	x0, x21
10140ea7c: 52800021    	mov	w1, #0x1                ; =1
10140ea80: 97da3f16    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140ea84: aa0003f7    	mov	x23, x0
10140ea88: b50001e0    	cbnz	x0, 0x10140eac4 <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0xf4>
10140ea8c: 52800020    	mov	w0, #0x1                ; =1
10140ea90: aa1503e1    	mov	x1, x21
10140ea94: 941ad238    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140ea98: 3cc183e0    	ldur	q0, [sp, #0x18]
10140ea9c: 3d800260    	str	q0, [x19]
10140eaa0: f94017e8    	ldr	x8, [sp, #0x28]
10140eaa4: f9000a68    	str	x8, [x19, #0x10]
10140eaa8: 14000025    	b	0x10140eb3c <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0x16c>
10140eaac: 3cc183e0    	ldur	q0, [sp, #0x18]
10140eab0: 3d8003e0    	str	q0, [sp]
10140eab4: f94017e8    	ldr	x8, [sp, #0x28]
10140eab8: f9000be8    	str	x8, [sp, #0x10]
10140eabc: 14000008    	b	0x10140eadc <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0x10c>
10140eac0: 52800037    	mov	w23, #0x1               ; =1
10140eac4: aa1703e0    	mov	x0, x23
10140eac8: aa1603e1    	mov	x1, x22
10140eacc: aa1503e2    	mov	x2, x21
10140ead0: 941aec56    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10140ead4: a9005ff5    	stp	x21, x23, [sp]
10140ead8: f9000bf5    	str	x21, [sp, #0x10]
10140eadc: a9408bf5    	ldp	x21, x2, [sp, #0x8]
10140eae0: 910063e0    	add	x0, sp, #0x18
10140eae4: aa1503e1    	mov	x1, x21
10140eae8: aa1403e3    	mov	x3, x20
10140eaec: 94000537    	bl	0x10140ffc8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x360>
10140eaf0: f9400fe8    	ldr	x8, [sp, #0x18]
10140eaf4: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10140eaf8: eb09011f    	cmp	x8, x9
10140eafc: 540000e1    	b.ne	0x10140eb18 <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0x148>
10140eb00: 52800108    	mov	w8, #0x8                ; =8
10140eb04: a900227f    	stp	xzr, x8, [x19]
10140eb08: f9000a7f    	str	xzr, [x19, #0x10]
10140eb0c: f94003e1    	ldr	x1, [sp]
10140eb10: b5000101    	cbnz	x1, 0x10140eb30 <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0x160>
10140eb14: 1400000a    	b	0x10140eb3c <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0x16c>
10140eb18: 3cc183e0    	ldur	q0, [sp, #0x18]
10140eb1c: 3d800260    	str	q0, [x19]
10140eb20: f94017e8    	ldr	x8, [sp, #0x28]
10140eb24: f9000a68    	str	x8, [x19, #0x10]
10140eb28: f94003e1    	ldr	x1, [sp]
10140eb2c: b4000081    	cbz	x1, 0x10140eb3c <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0x16c>
10140eb30: aa1503e0    	mov	x0, x21
10140eb34: 52800022    	mov	w2, #0x1                ; =1
10140eb38: 97da3ee9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140eb3c: a9467bfd    	ldp	x29, x30, [sp, #0x60]
10140eb40: a9454ff4    	ldp	x20, x19, [sp, #0x50]
10140eb44: a94457f6    	ldp	x22, x21, [sp, #0x40]
10140eb48: a9435ff8    	ldp	x24, x23, [sp, #0x30]
10140eb4c: 9101c3ff    	add	sp, sp, #0x70
10140eb50: d65f03c0    	ret
10140eb54: f940128a    	ldr	x10, [x20, #0x20]
10140eb58: 9100614a    	add	x10, x10, #0x18
10140eb5c: 5280030b    	mov	w11, #0x18              ; =24
10140eb60: 928002ec    	mov	x12, #-0x18             ; =-24
10140eb64: 9b0b3108    	madd	x8, x8, x11, x12
10140eb68: b4fff728    	cbz	x8, 0x10140ea4c <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0x7c>
10140eb6c: aa0a03e0    	mov	x0, x10
10140eb70: f940094a    	ldr	x10, [x10, #0x10]
10140eb74: b40000ea    	cbz	x10, 0x10140eb90 <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0x1c0>
10140eb78: f940040a    	ldr	x10, [x0, #0x8]
10140eb7c: 3940014b    	ldrb	w11, [x10]
10140eb80: 9100600a    	add	x10, x0, #0x18
10140eb84: d1006108    	sub	x8, x8, #0x18
10140eb88: 7100b57f    	cmp	w11, #0x2d
10140eb8c: 54fffee0    	b.eq	0x10140eb68 <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0x198>
10140eb90: 910003e8    	mov	x8, sp
10140eb94: 9410018e    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10140eb98: 17ffffd1    	b	0x10140eadc <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0x10c>
10140eb9c: aa0003f3    	mov	x19, x0
10140eba0: f94003e1    	ldr	x1, [sp]
10140eba4: b4000081    	cbz	x1, 0x10140ebb4 <__ZN17otty_autocomplete10generators15completions_for17h3bf13dc17fc5968eE+0x1e4>
10140eba8: aa1503e0    	mov	x0, x21
10140ebac: 52800022    	mov	w2, #0x1                ; =1
10140ebb0: 97da3ecb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140ebb4: aa1303e0    	mov	x0, x19
10140ebb8: 941aea87    	bl	0x101ac95d4 <_writev+0x101ac95d4>

000000010140ebbc <__ZN17otty_autocomplete10generators16GeneratorContext12arg_position17h9ee0b5921704ff27E>:
10140ebbc: aa0003e8    	mov	x8, x0
10140ebc0: d2800000    	mov	x0, #0x0                ; =0
10140ebc4: f9400d0c    	ldr	x12, [x8, #0x18]
10140ebc8: f9401d0a    	ldr	x10, [x8, #0x38]
10140ebcc: f9401509    	ldr	x9, [x8, #0x28]
10140ebd0: f100052b    	subs	x11, x9, #0x1
10140ebd4: 9a8b33eb    	csel	x11, xzr, x11, lo
10140ebd8: f100015f    	cmp	x10, #0x0
10140ebdc: 9a8b012a    	csel	x10, x9, x11, eq
10140ebe0: 9100058b    	add	x11, x12, #0x1
10140ebe4: eb0a017f    	cmp	x11, x10
10140ebe8: 54000302    	b.hs	0x10140ec48 <__ZN17otty_autocomplete10generators16GeneratorContext12arg_position17h9ee0b5921704ff27E+0x8c>
10140ebec: d2800000    	mov	x0, #0x0                ; =0
10140ebf0: f9401108    	ldr	x8, [x8, #0x20]
10140ebf4: 5280030d    	mov	w13, #0x18              ; =24
10140ebf8: 9b0d2188    	madd	x8, x12, x13, x8
10140ebfc: 9100a108    	add	x8, x8, #0x28
10140ec00: 14000007    	b	0x10140ec1c <__ZN17otty_autocomplete10generators16GeneratorContext12arg_position17h9ee0b5921704ff27E+0x60>
10140ec04: d280000c    	mov	x12, #0x0               ; =0
10140ec08: 9100056b    	add	x11, x11, #0x1
10140ec0c: 8b000180    	add	x0, x12, x0
10140ec10: 91006108    	add	x8, x8, #0x18
10140ec14: eb0b015f    	cmp	x10, x11
10140ec18: 54000180    	b.eq	0x10140ec48 <__ZN17otty_autocomplete10generators16GeneratorContext12arg_position17h9ee0b5921704ff27E+0x8c>
10140ec1c: eb09017f    	cmp	x11, x9
10140ec20: 54ffff22    	b.hs	0x10140ec04 <__ZN17otty_autocomplete10generators16GeneratorContext12arg_position17h9ee0b5921704ff27E+0x48>
10140ec24: f940010c    	ldr	x12, [x8]
10140ec28: b40000cc    	cbz	x12, 0x10140ec40 <__ZN17otty_autocomplete10generators16GeneratorContext12arg_position17h9ee0b5921704ff27E+0x84>
10140ec2c: f85f810c    	ldur	x12, [x8, #-0x8]
10140ec30: 3940018c    	ldrb	w12, [x12]
10140ec34: 7100b59f    	cmp	w12, #0x2d
10140ec38: 1a9f07ec    	cset	w12, ne
10140ec3c: 17fffff3    	b	0x10140ec08 <__ZN17otty_autocomplete10generators16GeneratorContext12arg_position17h9ee0b5921704ff27E+0x4c>
10140ec40: 5280002c    	mov	w12, #0x1               ; =1
10140ec44: 17fffff1    	b	0x10140ec08 <__ZN17otty_autocomplete10generators16GeneratorContext12arg_position17h9ee0b5921704ff27E+0x4c>
10140ec48: d65f03c0    	ret

000000010140ec4c <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E>:
10140ec4c: d10183ff    	sub	sp, sp, #0x60
10140ec50: a90357f6    	stp	x22, x21, [sp, #0x30]
10140ec54: a9044ff4    	stp	x20, x19, [sp, #0x40]
10140ec58: a9057bfd    	stp	x29, x30, [sp, #0x50]
10140ec5c: 910143fd    	add	x29, sp, #0x50
10140ec60: f9401c14    	ldr	x20, [x0, #0x38]
10140ec64: b4000254    	cbz	x20, 0x10140ecac <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E+0x60>
10140ec68: aa0003f5    	mov	x21, x0
10140ec6c: 910003e8    	mov	x8, sp
10140ec70: aa0103e0    	mov	x0, x1
10140ec74: aa0203e1    	mov	x1, x2
10140ec78: 940ff2af    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
10140ec7c: a940dbf3    	ldp	x19, x22, [sp, #0x8]
10140ec80: f9401aa0    	ldr	x0, [x21, #0x30]
10140ec84: 910063e8    	add	x8, sp, #0x18
10140ec88: aa1403e1    	mov	x1, x20
10140ec8c: 940ff2aa    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
10140ec90: a9420bf5    	ldp	x21, x2, [sp, #0x20]
10140ec94: eb0202df    	cmp	x22, x2
10140ec98: 540000e2    	b.hs	0x10140ecb4 <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E+0x68>
10140ec9c: 52800014    	mov	w20, #0x0               ; =0
10140eca0: f9400fe1    	ldr	x1, [sp, #0x18]
10140eca4: b5000161    	cbnz	x1, 0x10140ecd0 <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E+0x84>
10140eca8: 1400000d    	b	0x10140ecdc <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E+0x90>
10140ecac: 52800034    	mov	w20, #0x1               ; =1
10140ecb0: 14000010    	b	0x10140ecf0 <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E+0xa4>
10140ecb4: aa1503e0    	mov	x0, x21
10140ecb8: aa1303e1    	mov	x1, x19
10140ecbc: 941aebd8    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10140ecc0: 7100001f    	cmp	w0, #0x0
10140ecc4: 1a9f17f4    	cset	w20, eq
10140ecc8: f9400fe1    	ldr	x1, [sp, #0x18]
10140eccc: b4000081    	cbz	x1, 0x10140ecdc <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E+0x90>
10140ecd0: aa1503e0    	mov	x0, x21
10140ecd4: 52800022    	mov	w2, #0x1                ; =1
10140ecd8: 97da3e81    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140ecdc: f94003e1    	ldr	x1, [sp]
10140ece0: b4000081    	cbz	x1, 0x10140ecf0 <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E+0xa4>
10140ece4: aa1303e0    	mov	x0, x19
10140ece8: 52800022    	mov	w2, #0x1                ; =1
10140ecec: 97da3e7c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140ecf0: aa1403e0    	mov	x0, x20
10140ecf4: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10140ecf8: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10140ecfc: a94357f6    	ldp	x22, x21, [sp, #0x30]
10140ed00: 910183ff    	add	sp, sp, #0x60
10140ed04: d65f03c0    	ret
10140ed08: aa0003f4    	mov	x20, x0
10140ed0c: f94003e1    	ldr	x1, [sp]
10140ed10: b4000081    	cbz	x1, 0x10140ed20 <__ZN17otty_autocomplete10generators16GeneratorContext7matches17h6e6fdcd2da430508E+0xd4>
10140ed14: aa1303e0    	mov	x0, x19
10140ed18: 52800022    	mov	w2, #0x1                ; =1
10140ed1c: 97da3e70    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140ed20: aa1403e0    	mov	x0, x20
10140ed24: 941aea2c    	bl	0x101ac95d4 <_writev+0x101ac95d4>

000000010140ed28 <__ZN17otty_autocomplete10generators16GeneratorContext8has_flag17hfe88895f58e09f66E>:
10140ed28: f9401408    	ldr	x8, [x0, #0x28]
10140ed2c: b40004e8    	cbz	x8, 0x10140edc8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_flag17hfe88895f58e09f66E+0xa0>
10140ed30: b40004c2    	cbz	x2, 0x10140edc8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_flag17hfe88895f58e09f66E+0xa0>
10140ed34: a9bb67fa    	stp	x26, x25, [sp, #-0x50]!
10140ed38: a9015ff8    	stp	x24, x23, [sp, #0x10]
10140ed3c: a90257f6    	stp	x22, x21, [sp, #0x20]
10140ed40: a9034ff4    	stp	x20, x19, [sp, #0x30]
10140ed44: a9047bfd    	stp	x29, x30, [sp, #0x40]
10140ed48: 910103fd    	add	x29, sp, #0x40
10140ed4c: f9401017    	ldr	x23, [x0, #0x20]
10140ed50: 52800309    	mov	w9, #0x18               ; =24
10140ed54: 9b095d15    	madd	x21, x8, x9, x23
10140ed58: d37cec56    	lsl	x22, x2, #4
10140ed5c: 91002038    	add	x24, x1, #0x8
10140ed60: 14000003    	b	0x10140ed6c <__ZN17otty_autocomplete10generators16GeneratorContext8has_flag17hfe88895f58e09f66E+0x44>
10140ed64: eb1502ff    	cmp	x23, x21
10140ed68: 54000340    	b.eq	0x10140edd0 <__ZN17otty_autocomplete10generators16GeneratorContext8has_flag17hfe88895f58e09f66E+0xa8>
10140ed6c: a940d2f3    	ldp	x19, x20, [x23, #0x8]
10140ed70: 910062f7    	add	x23, x23, #0x18
10140ed74: aa1603f9    	mov	x25, x22
10140ed78: aa1803fa    	mov	x26, x24
10140ed7c: 14000004    	b	0x10140ed8c <__ZN17otty_autocomplete10generators16GeneratorContext8has_flag17hfe88895f58e09f66E+0x64>
10140ed80: 9100435a    	add	x26, x26, #0x10
10140ed84: f1004339    	subs	x25, x25, #0x10
10140ed88: 54fffee0    	b.eq	0x10140ed64 <__ZN17otty_autocomplete10generators16GeneratorContext8has_flag17hfe88895f58e09f66E+0x3c>
10140ed8c: f9400348    	ldr	x8, [x26]
10140ed90: eb14011f    	cmp	x8, x20
10140ed94: 54ffff61    	b.ne	0x10140ed80 <__ZN17otty_autocomplete10generators16GeneratorContext8has_flag17hfe88895f58e09f66E+0x58>
10140ed98: f85f8340    	ldur	x0, [x26, #-0x8]
10140ed9c: aa1303e1    	mov	x1, x19
10140eda0: aa1403e2    	mov	x2, x20
10140eda4: 941aeb9e    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10140eda8: 35fffec0    	cbnz	w0, 0x10140ed80 <__ZN17otty_autocomplete10generators16GeneratorContext8has_flag17hfe88895f58e09f66E+0x58>
10140edac: 52800020    	mov	w0, #0x1                ; =1
10140edb0: a9447bfd    	ldp	x29, x30, [sp, #0x40]
10140edb4: a9434ff4    	ldp	x20, x19, [sp, #0x30]
10140edb8: a94257f6    	ldp	x22, x21, [sp, #0x20]
10140edbc: a9415ff8    	ldp	x24, x23, [sp, #0x10]
10140edc0: a8c567fa    	ldp	x26, x25, [sp], #0x50
10140edc4: d65f03c0    	ret
10140edc8: 52800000    	mov	w0, #0x0                ; =0
10140edcc: d65f03c0    	ret
10140edd0: 52800000    	mov	w0, #0x0                ; =0
10140edd4: 17fffff7    	b	0x10140edb0 <__ZN17otty_autocomplete10generators16GeneratorContext8has_flag17hfe88895f58e09f66E+0x88>

000000010140edd8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E>:
10140edd8: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
10140eddc: a9017bfd    	stp	x29, x30, [sp, #0x10]
10140ede0: 910043fd    	add	x29, sp, #0x10
10140ede4: aa0003f3    	mov	x19, x0
10140ede8: 940eddb1    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
10140edec: f9403a68    	ldr	x8, [x19, #0x70]
10140edf0: eb08001f    	cmp	x0, x8
10140edf4: 1a9fa7e0    	cset	w0, lt
10140edf8: 54000081    	b.ne	0x10140ee08 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x30>
10140edfc: b9407a68    	ldr	w8, [x19, #0x78]
10140ee00: 6b08003f    	cmp	w1, w8
10140ee04: 1a9f27e0    	cset	w0, lo
10140ee08: a9417bfd    	ldp	x29, x30, [sp, #0x10]
10140ee0c: a8c24ff4    	ldp	x20, x19, [sp], #0x20
10140ee10: d65f03c0    	ret
10140ee14: d10783ff    	sub	sp, sp, #0x1e0
10140ee18: a9196ffc    	stp	x28, x27, [sp, #0x190]
10140ee1c: a91a5ff8    	stp	x24, x23, [sp, #0x1a0]
10140ee20: a91b57f6    	stp	x22, x21, [sp, #0x1b0]
10140ee24: a91c4ff4    	stp	x20, x19, [sp, #0x1c0]
10140ee28: a91d7bfd    	stp	x29, x30, [sp, #0x1d0]
10140ee2c: 910743fd    	add	x29, sp, #0x1d0
10140ee30: aa0803f3    	mov	x19, x8
10140ee34: a9007fe2    	stp	x2, xzr, [sp]
10140ee38: a90103e1    	stp	x1, x0, [sp, #0x10]
10140ee3c: a9027fe1    	stp	x1, xzr, [sp, #0x20]
10140ee40: f9001be1    	str	x1, [sp, #0x30]
10140ee44: 0f000540    	movi.2s	v0, #0xa
10140ee48: fd001fe0    	str	d0, [sp, #0x38]
10140ee4c: 52800028    	mov	w8, #0x1                ; =1
10140ee50: 390103e8    	strb	w8, [sp, #0x40]
10140ee54: 790093ff    	strh	wzr, [sp, #0x48]
10140ee58: 9101a3e0    	add	x0, sp, #0x68
10140ee5c: 910003e1    	mov	x1, sp
10140ee60: 97ffbf6c    	bl	0x1013fec10 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xee8>
10140ee64: f94037e8    	ldr	x8, [sp, #0x68]
10140ee68: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10140ee6c: eb09011f    	cmp	x8, x9
10140ee70: 540000a1    	b.ne	0x10140ee84 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xac>
10140ee74: 52800108    	mov	w8, #0x8                ; =8
10140ee78: a900227f    	stp	xzr, x8, [x19]
10140ee7c: f9000a7f    	str	xzr, [x19, #0x10]
10140ee80: 14000041    	b	0x10140ef84 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x1ac>
10140ee84: 97da3e1b    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140ee88: 52803400    	mov	w0, #0x1a0              ; =416
10140ee8c: 52800101    	mov	w1, #0x8                ; =8
10140ee90: 97da3e12    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140ee94: b4000860    	cbz	x0, 0x10140efa0 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x1c8>
10140ee98: aa0003f4    	mov	x20, x0
10140ee9c: 9101a3f6    	add	x22, sp, #0x68
10140eea0: ad4206c0    	ldp	q0, q1, [x22, #0x40]
10140eea4: ad020400    	stp	q0, q1, [x0, #0x40]
10140eea8: f94067e8    	ldr	x8, [sp, #0xc8]
10140eeac: f9003008    	str	x8, [x0, #0x60]
10140eeb0: 3cc683e0    	ldur	q0, [sp, #0x68]
10140eeb4: 3cc783e1    	ldur	q1, [sp, #0x78]
10140eeb8: ad000400    	stp	q0, q1, [x0]
10140eebc: ad4102c1    	ldp	q1, q0, [x22, #0x20]
10140eec0: ad010001    	stp	q1, q0, [x0, #0x20]
10140eec4: 52800088    	mov	w8, #0x4                ; =4
10140eec8: a90503e8    	stp	x8, x0, [sp, #0x50]
10140eecc: 52800035    	mov	w21, #0x1               ; =1
10140eed0: f90033f5    	str	x21, [sp, #0x60]
10140eed4: ad4107e0    	ldp	q0, q1, [sp, #0x20]
10140eed8: ad0787e0    	stp	q0, q1, [sp, #0xf0]
10140eedc: 3dc013e0    	ldr	q0, [sp, #0x40]
10140eee0: 3d8047e0    	str	q0, [sp, #0x110]
10140eee4: ad4003e1    	ldp	q1, q0, [sp]
10140eee8: 52800d17    	mov	w23, #0x68              ; =104
10140eeec: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
10140eef0: ad0683e1    	stp	q1, q0, [sp, #0xd0]
10140eef4: 1400000f    	b	0x10140ef30 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x158>
10140eef8: 8b170288    	add	x8, x20, x23
10140eefc: ad4606c0    	ldp	q0, q1, [x22, #0xc0]
