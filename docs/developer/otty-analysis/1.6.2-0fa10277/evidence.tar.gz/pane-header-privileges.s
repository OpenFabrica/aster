1006dfbf0:	mov	x1, x26
1006dfbf4:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006dfbf8:	mov	x19, x0
1006dfbfc:	mov	x0, #0x0
1006dfc00:	mov	x1, #-0x2000000000000000
1006dfc04:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006dfc08:	mov	x22, x0
1006dfc0c:	mov	x0, x21
1006dfc10:	mov	x2, x19
1006dfc14:	mov	x3, x27
1006dfc18:	mov	x4, x22
1006dfc1c:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006dfc20:	mov	x21, x0
1006dfc24:	mov	x0, x19
1006dfc28:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006dfc2c:	mov	x0, x22
1006dfc30:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006dfc34:	tbz	w20, #0x0, 0x1006dfc44
1006dfc38:	mov	x0, x21
1006dfc3c:	ldr	x2, [sp, #0x58]
1006dfc40:	bl	0x101ad45e0 ; selector setTarget:
1006dfc44:	adrp	x8, 7234 ; 0x102321000
1006dfc48:	ldr	x8, [x8, #0xd58] ; Objc selector ref: branchSplitUp
1006dfc4c:	ands	w27, w20, #0x1
1006dfc50:	csel	x28, x8, xzr, ne
1006dfc54:	mov	x0, x21
1006dfc58:	mov	x2, x27
1006dfc5c:	bl	0x101ad2920 ; selector setEnabled:
1006dfc60:	ldr	x0, [sp, #0x80]
1006dfc64:	mov	x2, x21
1006dfc68:	bl	0x101acb2c0 ; selector addItem:
1006dfc6c:	mov	x0, x26
1006dfc70:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006dfc74:	mov	x0, x21
1006dfc78:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006dfc7c:	ldr	x19, [sp, #0x40]
1006dfc80:	mov	x0, x19
1006dfc84:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1006dfc88:	orr	x1, x24, #0x8000000000000000
1006dfc8c:	mov	x0, #0x13
1006dfc90:	movk	x0, #0xd000, lsl #48
1006dfc94:	bl	0x100063df0
1006dfc98:	mov	x21, x0
1006dfc9c:	mov	x22, x1
1006dfca0:	ldr	x0, [sp, #0x70]
1006dfca4:	mov	w1, #0x70
1006dfca8:	mov	w2, #0x7
1006dfcac:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1006dfcb0:	mov	x26, x0
1006dfcb4:	ldr	q0, [sp, #0x60]
1006dfcb8:	str	q0, [x0, #0x10]
1006dfcbc:	adrp	x9, 7151 ; 0x1022ce000
1006dfcc0:	ldr	x9, [x9, #0x38] ; literal pool symbol address: _$sSSN
1006dfcc4:	stp	x9, x25, [x0, #0x38]
1006dfcc8:	ldr	x8, [sp, #0x78]
1006dfccc:	stp	x8, x23, [x0, #0x20]
1006dfcd0:	stp	x9, x25, [x0, #0x60]
1006dfcd4:	ldr	x8, [sp, #0x20]
1006dfcd8:	stp	x8, x19, [x0, #0x48]
1006dfcdc:	mov	x0, x23
1006dfce0:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1006dfce4:	mov	x0, x21
1006dfce8:	mov	x1, x22
1006dfcec:	mov	x2, x26
1006dfcf0:	bl	0x101ac6280 ; symbol stub for: _$sSS10FoundationE6format_S2Sh_s7CVarArg_pdtcfC
1006dfcf4:	mov	x21, x0
1006dfcf8:	mov	x26, x1
1006dfcfc:	mov	x0, x22
1006dfd00:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006dfd04:	adrp	x8, 7239 ; 0x102326000
1006dfd08:	ldr	x0, [x8, #0xac8] ; Objc class ref: _OBJC_CLASS_$_NSMenuItem
1006dfd0c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006dfd10:	mov	x22, x0
1006dfd14:	mov	x0, x21
1006dfd18:	mov	x1, x26
1006dfd1c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006dfd20:	mov	x21, x0
1006dfd24:	mov	x0, #0x0
1006dfd28:	mov	x1, #-0x2000000000000000
1006dfd2c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006dfd30:	mov	x19, x0
1006dfd34:	mov	x0, x22
1006dfd38:	mov	x2, x21
1006dfd3c:	mov	x3, x28
1006dfd40:	mov	x4, x19
1006dfd44:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006dfd48:	mov	x28, x0
1006dfd4c:	mov	x0, x21
1006dfd50:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006dfd54:	mov	x0, x19
1006dfd58:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006dfd5c:	tbz	w20, #0x0, 0x1006dfd6c
1006dfd60:	mov	x0, x28
1006dfd64:	ldr	x2, [sp, #0x58]
1006dfd68:	bl	0x101ad45e0 ; selector setTarget:
1006dfd6c:	mov	x0, x28
1006dfd70:	mov	x2, x27
1006dfd74:	bl	0x101ad2920 ; selector setEnabled:
1006dfd78:	ldr	x21, [sp, #0x80]
1006dfd7c:	mov	x0, x21
1006dfd80:	mov	x2, x28
1006dfd84:	bl	0x101acb2c0 ; selector addItem:
1006dfd88:	ldr	x0, [sp, #0x40]
1006dfd8c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006dfd90:	ldr	x0, [sp, #0x48]
1006dfd94:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006dfd98:	ldr	x0, [sp, #0x50]
1006dfd9c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006dfda0:	ldr	x0, [sp, #0x28]
1006dfda4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006dfda8:	mov	x0, x26
1006dfdac:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006dfdb0:	mov	x0, x28
1006dfdb4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006dfdb8:	ldr	x0, [sp, #0x30]
1006dfdbc:	bl	0x101ad1620 ; selector separatorItem
1006dfdc0:	mov	x29, x29
1006dfdc4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006dfdc8:	mov	x19, x0
1006dfdcc:	mov	x0, x21
1006dfdd0:	mov	x2, x19
1006dfdd4:	bl	0x101acb2c0 ; selector addItem:
1006dfdd8:	mov	x0, x19
1006dfddc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006dfde0:	orr	x1, x24, #0x8000000000000000
1006dfde4:	mov	x0, #0x13
1006dfde8:	movk	x0, #0xd000, lsl #48
1006dfdec:	bl	0x100063df0
1006dfdf0:	mov	x19, x0
1006dfdf4:	mov	x22, x1
1006dfdf8:	ldr	x0, [sp, #0x70]
1006dfdfc:	mov	w1, #0x70
1006dfe00:	mov	w2, #0x7
1006dfe04:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1006dfe08:	mov	x26, x0
1006dfe0c:	ldr	q0, [sp, #0x60]
1006dfe10:	str	q0, [x0, #0x10]
1006dfe14:	adrp	x21, 7151 ; 0x1022ce000
1006dfe18:	ldr	x21, [x21, #0x38] ; literal pool symbol address: _$sSSN
1006dfe1c:	stp	x21, x25, [x0, #0x38]
1006dfe20:	ldr	x8, [sp, #0x78]
1006dfe24:	stp	x8, x23, [x0, #0x20]
1006dfe28:	mov	x0, x23
1006dfe2c:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1006dfe30:	mov	x0, #0x656d
1006dfe34:	movk	x0, #0x756e, lsl #16
1006dfe38:	movk	x0, #0x6e2e, lsl #32
1006dfe3c:	movk	x0, #0x7765, lsl #48
1006dfe40:	mov	x1, #0x745f
1006dfe44:	movk	x1, #0x6261, lsl #16
1006dfe48:	movk	x1, #0xec00, lsl #48
1006dfe4c:	bl	0x100063df0
1006dfe50:	stp	x21, x25, [x26, #0x60]
1006dfe54:	stp	x0, x1, [x26, #0x48]
1006dfe58:	mov	x0, x19
1006dfe5c:	mov	x1, x22
1006dfe60:	mov	x2, x26
1006dfe64:	bl	0x101ac6280 ; symbol stub for: _$sSS10FoundationE6format_S2Sh_s7CVarArg_pdtcfC
1006dfe68:	mov	x19, x0
1006dfe6c:	mov	x26, x1
1006dfe70:	mov	x0, x22
1006dfe74:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006dfe78:	ands	w27, w20, #0x1
1006dfe7c:	adrp	x8, 7234 ; 0x102321000
1006dfe80:	ldr	x8, [x8, #0xd60] ; Objc selector ref: branchNewTab
1006dfe84:	adrp	x9, 7239 ; 0x102326000
1006dfe88:	ldr	x0, [x9, #0xac8] ; Objc class ref: _OBJC_CLASS_$_NSMenuItem
1006dfe8c:	csel	x22, x8, xzr, ne
1006dfe90:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006dfe94:	mov	x28, x0
1006dfe98:	mov	x0, x19
1006dfe9c:	mov	x1, x26
1006dfea0:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006dfea4:	mov	x19, x0
1006dfea8:	mov	x0, #0x0
1006dfeac:	mov	x1, #-0x2000000000000000
1006dfeb0:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006dfeb4:	mov	x21, x0
1006dfeb8:	mov	x0, x28
1006dfebc:	mov	x2, x19
1006dfec0:	mov	x3, x22
1006dfec4:	mov	x4, x21
1006dfec8:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006dfecc:	mov	x28, x0
1006dfed0:	mov	x0, x19
1006dfed4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006dfed8:	mov	x0, x21
1006dfedc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006dfee0:	tbz	w20, #0x0, 0x1006dfef0
1006dfee4:	mov	x0, x28
1006dfee8:	ldr	x2, [sp, #0x58]
1006dfeec:	bl	0x101ad45e0 ; selector setTarget:
1006dfef0:	mov	x0, x28
1006dfef4:	mov	x2, x27
1006dfef8:	bl	0x101ad2920 ; selector setEnabled:
1006dfefc:	ldr	x27, [sp, #0x80]
1006dff00:	mov	x0, x27
1006dff04:	mov	x2, x28
1006dff08:	bl	0x101acb2c0 ; selector addItem:
1006dff0c:	mov	x0, x26
1006dff10:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006dff14:	mov	x0, x28
1006dff18:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006dff1c:	orr	x1, x24, #0x8000000000000000
1006dff20:	mov	x0, #0x13
1006dff24:	movk	x0, #0xd000, lsl #48
1006dff28:	bl	0x100063df0
1006dff2c:	mov	x19, x0
1006dff30:	mov	x22, x1
1006dff34:	ldr	x0, [sp, #0x70]
1006dff38:	mov	w1, #0x70
1006dff3c:	mov	w2, #0x7
1006dff40:	bl	0x101aca588 ; symbol stub for: _swift_allocObject
1006dff44:	mov	x21, x0
1006dff48:	ldr	q0, [sp, #0x60]
1006dff4c:	str	q0, [x0, #0x10]
1006dff50:	adrp	x24, 7151 ; 0x1022ce000
1006dff54:	ldr	x24, [x24, #0x38] ; literal pool symbol address: _$sSSN
1006dff58:	stp	x24, x25, [x0, #0x38]
1006dff5c:	ldr	x8, [sp, #0x78]
1006dff60:	stp	x8, x23, [x0, #0x20]
1006dff64:	mov	x1, #0x775f
1006dff68:	movk	x1, #0x6e69, lsl #16
1006dff6c:	movk	x1, #0x6f64, lsl #32
1006dff70:	movk	x1, #0xef77, lsl #48
1006dff74:	mov	x0, #0x656d
1006dff78:	movk	x0, #0x756e, lsl #16
1006dff7c:	movk	x0, #0x6e2e, lsl #32
1006dff80:	movk	x0, #0x7765, lsl #48
1006dff84:	bl	0x100063df0
1006dff88:	stp	x24, x25, [x21, #0x60]
1006dff8c:	stp	x0, x1, [x21, #0x48]
1006dff90:	mov	x0, x19
1006dff94:	mov	x1, x22
1006dff98:	mov	x2, x21
1006dff9c:	bl	0x101ac6280 ; symbol stub for: _$sSS10FoundationE6format_S2Sh_s7CVarArg_pdtcfC
1006dffa0:	mov	x19, x0
1006dffa4:	mov	x21, x1
1006dffa8:	mov	x0, x22
1006dffac:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006dffb0:	tst	w20, #0x1
1006dffb4:	adrp	x8, 7234 ; 0x102321000
1006dffb8:	ldr	x8, [x8, #0xd68] ; Objc selector ref: branchNewWindow
1006dffbc:	adrp	x9, 7239 ; 0x102326000
1006dffc0:	ldr	x0, [x9, #0xac8] ; Objc class ref: _OBJC_CLASS_$_NSMenuItem
1006dffc4:	csel	x22, x8, xzr, ne
1006dffc8:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006dffcc:	mov	x23, x0
1006dffd0:	mov	x0, x19
1006dffd4:	mov	x1, x21
1006dffd8:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006dffdc:	mov	x19, x0
1006dffe0:	mov	x0, #0x0
1006dffe4:	mov	x1, #-0x2000000000000000
1006dffe8:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006dffec:	mov	x24, x0
1006dfff0:	mov	x0, x23
1006dfff4:	mov	x2, x19
1006dfff8:	mov	x3, x22
1006dfffc:	mov	x4, x24
1006e0000:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e0004:	mov	x22, x0
1006e0008:	mov	x0, x19
1006e000c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0010:	mov	x0, x24
1006e0014:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0018:	tbz	w20, #0x0, 0x1006e0028
1006e001c:	mov	x0, x22
1006e0020:	ldr	x2, [sp, #0x58]
1006e0024:	bl	0x101ad45e0 ; selector setTarget:
1006e0028:	and	w2, w20, #0x1
1006e002c:	mov	x0, x22
1006e0030:	bl	0x101ad2920 ; selector setEnabled:
1006e0034:	mov	x0, x27
1006e0038:	mov	x2, x22
1006e003c:	bl	0x101acb2c0 ; selector addItem:
1006e0040:	mov	x0, x21
1006e0044:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0048:	mov	x0, x22
1006e004c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0050:	add	x0, sp, #0x88
1006e0054:	bl	0x10002d8d4
1006e0058:	add	sp, sp, #0x1b0
1006e005c:	ldp	x29, x30, [sp, #0x50]
1006e0060:	ldp	x20, x19, [sp, #0x40]
1006e0064:	ldp	x22, x21, [sp, #0x30]
1006e0068:	ldp	x24, x23, [sp, #0x20]
1006e006c:	ldp	x26, x25, [sp, #0x10]
1006e0070:	ldp	x28, x27, [sp], #0x60
1006e0074:	ret
1006e0078:	stp	x22, x21, [sp, #-0x30]!
1006e007c:	stp	x20, x19, [sp, #0x10]
1006e0080:	stp	x29, x30, [sp, #0x20]
1006e0084:	add	x29, sp, #0x20
1006e0088:	mov	x19, x0
1006e008c:	mov	x0, x2
1006e0090:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e0094:	mov	x21, x0
1006e0098:	mov	x0, x19
1006e009c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e00a0:	mov	x20, x0
1006e00a4:	mov	x0, x21
1006e00a8:	bl	0x1006df1b4
1006e00ac:	mov	x0, x21
1006e00b0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e00b4:	mov	x0, x20
1006e00b8:	ldp	x29, x30, [sp, #0x20]
1006e00bc:	ldp	x20, x19, [sp, #0x10]
1006e00c0:	ldp	x22, x21, [sp], #0x30
1006e00c4:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e00c8:	sub	sp, sp, #0x110
1006e00cc:	stp	x26, x25, [sp, #0xc0]
1006e00d0:	stp	x24, x23, [sp, #0xd0]
1006e00d4:	stp	x22, x21, [sp, #0xe0]
1006e00d8:	stp	x20, x19, [sp, #0xf0]
1006e00dc:	stp	x29, x30, [sp, #0x100]
1006e00e0:	add	x29, sp, #0x100
1006e00e4:	bl	0x10060388c
1006e00e8:	mov	x25, x0
1006e00ec:	add	x8, sp, #0x80
1006e00f0:	bl	0x1004fa378
1006e00f4:	ldrb	w23, [sp, #0x80]
1006e00f8:	ldp	x22, x19, [sp, #0x88]
1006e00fc:	ldr	x21, [sp, #0xa0]
1006e0100:	ldr	x24, [sp, #0xb0]
1006e0104:	mov	x0, x25
1006e0108:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e010c:	cbnz	x19, 0x1006e0168
1006e0110:	adrp	x8, 7298 ; 0x102362000
1006e0114:	ldr	x8, [x8, #0xd60]
1006e0118:	add	x8, x20, x8
1006e011c:	ldp	q1, q0, [x8]
1006e0120:	stp	q1, q0, [sp, #0x40]
1006e0124:	ldr	q0, [x8, #0x20]
1006e0128:	str	q0, [sp, #0x60]
1006e012c:	ldur	q0, [x8, #0x29]
1006e0130:	stur	q0, [sp, #0x69]
1006e0134:	ldr	x19, [sp, #0x50]
1006e0138:	cbz	x19, 0x1006e01b0
1006e013c:	ldr	x24, [sp, #0x70]
1006e0140:	ldr	x21, [sp, #0x60]
1006e0144:	ldr	x22, [sp, #0x48]
1006e0148:	ldrb	w23, [sp, #0x40]
1006e014c:	adrp	x2, 7265 ; 0x102341000
1006e0150:	add	x2, x2, #0x170
1006e0154:	adrp	x3, 5142 ; 0x101af6000
1006e0158:	add	x3, x3, #0x950
1006e015c:	add	x0, sp, #0x40
1006e0160:	mov	x1, sp
1006e0164:	bl	0x10002d8f4
1006e0168:	and	x8, x22, #0xffffffffffff
1006e016c:	ubfx	x9, x19, #56, #4
1006e0170:	tst	x19, #0x2000000000000000
1006e0174:	csel	x8, x8, x9, eq
1006e0178:	cbz	x8, 0x1006e0190
1006e017c:	mov	x0, x22
1006e0180:	mov	x1, x19
1006e0184:	mov	x2, #0x0
1006e0188:	bl	0x1005ffef8
1006e018c:	b	0x1006e0198
1006e0190:	mov	x0, x23
1006e0194:	bl	0x1004f6710
1006e0198:	mov	x0, x21
1006e019c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e01a0:	mov	x0, x19
1006e01a4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e01a8:	mov	x0, x24
1006e01ac:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e01b0:	ldp	x29, x30, [sp, #0x100]
1006e01b4:	ldp	x20, x19, [sp, #0xf0]
1006e01b8:	ldp	x22, x21, [sp, #0xe0]
1006e01bc:	ldp	x24, x23, [sp, #0xd0]
1006e01c0:	ldp	x26, x25, [sp, #0xc0]
1006e01c4:	add	sp, sp, #0x110
1006e01c8:	ret
1006e01cc:	stp	x20, x19, [sp, #-0x20]!
1006e01d0:	stp	x29, x30, [sp, #0x10]
1006e01d4:	add	x29, sp, #0x10
1006e01d8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e01dc:	mov	x20, x0
1006e01e0:	bl	0x1006e00c8
1006e01e4:	mov	x0, x20
1006e01e8:	ldp	x29, x30, [sp, #0x10]
1006e01ec:	ldp	x20, x19, [sp], #0x20
1006e01f0:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e01f4:	sub	sp, sp, #0x140
1006e01f8:	stp	x28, x27, [sp, #0xe0]
1006e01fc:	stp	x26, x25, [sp, #0xf0]
1006e0200:	stp	x24, x23, [sp, #0x100]
1006e0204:	stp	x22, x21, [sp, #0x110]
1006e0208:	stp	x20, x19, [sp, #0x120]
1006e020c:	stp	x29, x30, [sp, #0x130]
1006e0210:	add	x29, sp, #0x130
1006e0214:	str	x20, [sp, #0x8]
1006e0218:	bl	0x10060388c
1006e021c:	mov	x19, x0
1006e0220:	add	x8, sp, #0x50
1006e0224:	bl	0x1004fa378
1006e0228:	ldrb	w23, [sp, #0x50]
1006e022c:	ldr	w21, [sp, #0x54]
1006e0230:	ldp	x28, x22, [sp, #0x58]
1006e0234:	ldp	x27, x26, [sp, #0x68]
1006e0238:	ldp	x25, x24, [sp, #0x78]
1006e023c:	ldrb	w20, [sp, #0x88]
1006e0240:	mov	x0, x19
1006e0244:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e0248:	cbz	x22, 0x1006e0254
1006e024c:	add	x19, sp, #0x90
1006e0250:	b	0x1006e02c0
1006e0254:	adrp	x8, 7298 ; 0x102362000
1006e0258:	ldr	x8, [x8, #0xd60]
1006e025c:	ldr	x9, [sp, #0x8]
1006e0260:	add	x8, x9, x8
1006e0264:	ldp	q1, q0, [x8]
1006e0268:	stp	q1, q0, [sp, #0x90]
1006e026c:	ldr	q0, [x8, #0x20]
1006e0270:	str	q0, [sp, #0xb0]
1006e0274:	ldur	q0, [x8, #0x29]
1006e0278:	add	x8, sp, #0x90
1006e027c:	stur	q0, [x8, #0x29]
1006e0280:	ldr	x22, [sp, #0xa0]
1006e0284:	add	x19, sp, #0x90
1006e0288:	cbz	x22, 0x1006e0304
1006e028c:	ldrb	w20, [sp, #0xc8]
1006e0290:	ldp	x25, x24, [sp, #0xb8]
1006e0294:	ldp	x27, x26, [sp, #0xa8]
1006e0298:	ldr	x28, [sp, #0x98]
1006e029c:	ldr	w21, [sp, #0x94]
1006e02a0:	ldrb	w23, [sp, #0x90]
1006e02a4:	adrp	x2, 7265 ; 0x102341000
1006e02a8:	add	x2, x2, #0x170
1006e02ac:	adrp	x3, 5142 ; 0x101af6000
1006e02b0:	add	x3, x3, #0x950
1006e02b4:	add	x0, sp, #0x90
1006e02b8:	add	x1, sp, #0x10
1006e02bc:	bl	0x10002d8f4
1006e02c0:	strb	w23, [sp, #0x10]
1006e02c4:	str	w21, [sp, #0x14]
1006e02c8:	stp	x28, x22, [sp, #0x18]
1006e02cc:	stp	x27, x26, [sp, #0x28]
1006e02d0:	stp	x25, x24, [sp, #0x38]
1006e02d4:	and	w8, w20, #0x1
1006e02d8:	strb	w8, [sp, #0x48]
1006e02dc:	ldp	q0, q1, [sp, #0x10]
1006e02e0:	stp	q0, q1, [sp, #0x90]
1006e02e4:	ldr	q0, [sp, #0x30]
1006e02e8:	str	q0, [sp, #0xb0]
1006e02ec:	ldur	q0, [sp, #0x39]
1006e02f0:	stur	q0, [x19, #0x29]
1006e02f4:	add	x0, sp, #0x90
1006e02f8:	bl	0x1004f6410
1006e02fc:	add	x0, sp, #0x10
1006e0300:	bl	0x100220418
1006e0304:	ldp	x29, x30, [sp, #0x130]
1006e0308:	ldp	x20, x19, [sp, #0x120]
1006e030c:	ldp	x22, x21, [sp, #0x110]
1006e0310:	ldp	x24, x23, [sp, #0x100]
1006e0314:	ldp	x26, x25, [sp, #0xf0]
1006e0318:	ldp	x28, x27, [sp, #0xe0]
1006e031c:	add	sp, sp, #0x140
1006e0320:	ret
1006e0324:	sub	sp, sp, #0x140
1006e0328:	stp	x28, x27, [sp, #0xe0]
1006e032c:	stp	x26, x25, [sp, #0xf0]
1006e0330:	stp	x24, x23, [sp, #0x100]
1006e0334:	stp	x22, x21, [sp, #0x110]
1006e0338:	stp	x20, x19, [sp, #0x120]
1006e033c:	stp	x29, x30, [sp, #0x130]
1006e0340:	add	x29, sp, #0x130
1006e0344:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e0348:	mov	x28, x0
1006e034c:	bl	0x10060388c
1006e0350:	mov	x20, x0
1006e0354:	add	x8, sp, #0x50
1006e0358:	bl	0x1004fa378
1006e035c:	ldrb	w8, [sp, #0x50]
1006e0360:	str	w8, [sp, #0xc]
1006e0364:	ldr	w19, [sp, #0x54]
1006e0368:	ldp	x21, x22, [sp, #0x58]
1006e036c:	ldp	x27, x26, [sp, #0x68]
1006e0370:	ldp	x25, x24, [sp, #0x78]
1006e0374:	ldrb	w23, [sp, #0x88]
1006e0378:	mov	x0, x20
1006e037c:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e0380:	cbz	x22, 0x1006e0398
1006e0384:	mov	x20, x28
1006e0388:	mov	x28, x21
1006e038c:	mov	x21, x19
1006e0390:	ldr	w19, [sp, #0xc]
1006e0394:	b	0x1006e0400
1006e0398:	adrp	x8, 7298 ; 0x102362000
1006e039c:	ldr	x8, [x8, #0xd60]
1006e03a0:	add	x8, x28, x8
1006e03a4:	ldp	q3, q0, [x8, #0x10]
1006e03a8:	ldur	q1, [x8, #0x29]
1006e03ac:	ldr	q2, [x8]
1006e03b0:	stp	q2, q3, [sp, #0x90]
1006e03b4:	add	x8, sp, #0x90
1006e03b8:	stur	q1, [x8, #0x29]
1006e03bc:	str	q0, [sp, #0xb0]
1006e03c0:	ldr	x22, [sp, #0xa0]
1006e03c4:	mov	x20, x28
1006e03c8:	cbz	x22, 0x1006e0470
1006e03cc:	ldrb	w23, [sp, #0xc8]
1006e03d0:	ldp	x25, x24, [sp, #0xb8]
1006e03d4:	ldp	x27, x26, [sp, #0xa8]
1006e03d8:	ldr	x28, [sp, #0x98]
1006e03dc:	ldr	w21, [sp, #0x94]
1006e03e0:	ldrb	w19, [sp, #0x90]
1006e03e4:	adrp	x2, 7265 ; 0x102341000
1006e03e8:	add	x2, x2, #0x170
1006e03ec:	adrp	x3, 5142 ; 0x101af6000
1006e03f0:	add	x3, x3, #0x950
1006e03f4:	add	x0, sp, #0x90
1006e03f8:	add	x1, sp, #0x10
1006e03fc:	bl	0x10002d8f4
1006e0400:	strb	w19, [sp, #0x10]
1006e0404:	str	w21, [sp, #0x14]
1006e0408:	stp	x28, x22, [sp, #0x18]
1006e040c:	stp	x27, x26, [sp, #0x28]
1006e0410:	stp	x25, x24, [sp, #0x38]
1006e0414:	and	w8, w23, #0x1
1006e0418:	strb	w8, [sp, #0x48]
1006e041c:	ldp	q0, q1, [sp, #0x10]
1006e0420:	stp	q0, q1, [sp, #0x90]
1006e0424:	ldr	q0, [sp, #0x30]
1006e0428:	str	q0, [sp, #0xb0]
1006e042c:	ldur	q0, [sp, #0x39]
1006e0430:	add	x8, sp, #0x90
1006e0434:	stur	q0, [x8, #0x29]
1006e0438:	add	x0, sp, #0x90
1006e043c:	bl	0x1004f6410
1006e0440:	mov	x0, x20
1006e0444:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0448:	add	x0, sp, #0x10
1006e044c:	bl	0x100220418
1006e0450:	ldp	x29, x30, [sp, #0x130]
1006e0454:	ldp	x20, x19, [sp, #0x120]
1006e0458:	ldp	x22, x21, [sp, #0x110]
1006e045c:	ldp	x24, x23, [sp, #0x100]
1006e0460:	ldp	x26, x25, [sp, #0xf0]
1006e0464:	ldp	x28, x27, [sp, #0xe0]
1006e0468:	add	sp, sp, #0x140
1006e046c:	ret
1006e0470:	mov	x0, x20
1006e0474:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0478:	b	0x1006e0450
1006e047c:	adrp	x0, -490 ; 0x1004f6000
1006e0480:	add	x0, x0, #0x778
1006e0484:	b	0x1006e04bc
1006e0488:	stp	x20, x19, [sp, #-0x20]!
1006e048c:	stp	x29, x30, [sp, #0x10]
1006e0490:	add	x29, sp, #0x10
1006e0494:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e0498:	mov	x20, x0
1006e049c:	bl	0x1006e047c
1006e04a0:	mov	x0, x20
1006e04a4:	ldp	x29, x30, [sp, #0x10]
1006e04a8:	ldp	x20, x19, [sp], #0x20
1006e04ac:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e04b0:	adrp	x0, -490 ; 0x1004f6000
1006e04b4:	add	x0, x0, #0x964
1006e04b8:	b	0x1006e04bc
1006e04bc:	sub	sp, sp, #0x150
1006e04c0:	stp	x28, x27, [sp, #0xf0]
1006e04c4:	stp	x26, x25, [sp, #0x100]
1006e04c8:	stp	x24, x23, [sp, #0x110]
1006e04cc:	stp	x22, x21, [sp, #0x120]
1006e04d0:	stp	x20, x19, [sp, #0x130]
1006e04d4:	stp	x29, x30, [sp, #0x140]
1006e04d8:	add	x29, sp, #0x140
1006e04dc:	mov	x19, x0
1006e04e0:	bl	0x10060388c
1006e04e4:	mov	x27, x0
1006e04e8:	add	x8, sp, #0x88
1006e04ec:	bl	0x1004fa378
1006e04f0:	ldrb	w25, [sp, #0x88]
1006e04f4:	ldp	x24, x22, [sp, #0x90]
1006e04f8:	ldp	x26, x23, [sp, #0xa0]
1006e04fc:	ldr	x21, [sp, #0xb8]
1006e0500:	mov	x0, x27
1006e0504:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e0508:	cbnz	x22, 0x1006e0564
1006e050c:	adrp	x8, 7298 ; 0x102362000
1006e0510:	ldr	x8, [x8, #0xd60]
1006e0514:	add	x8, x20, x8
1006e0518:	ldp	q1, q0, [x8]
1006e051c:	stp	q1, q0, [sp, #0x40]
1006e0520:	ldr	q0, [x8, #0x20]
1006e0524:	str	q0, [sp, #0x60]
1006e0528:	ldur	q0, [x8, #0x29]
1006e052c:	stur	q0, [sp, #0x69]
1006e0530:	ldr	x22, [sp, #0x50]
1006e0534:	cbz	x22, 0x1006e0658
1006e0538:	ldr	x21, [sp, #0x70]
1006e053c:	ldp	x26, x23, [sp, #0x58]
1006e0540:	ldr	x24, [sp, #0x48]
1006e0544:	ldrb	w25, [sp, #0x40]
1006e0548:	adrp	x2, 7265 ; 0x102341000
1006e054c:	add	x2, x2, #0x170
1006e0550:	adrp	x3, 5142 ; 0x101af6000
1006e0554:	add	x3, x3, #0x950
1006e0558:	add	x0, sp, #0x40
1006e055c:	mov	x1, sp
1006e0560:	bl	0x10002d8f4
1006e0564:	and	x8, x24, #0xffffffffffff
1006e0568:	ubfx	x9, x22, #56, #4
1006e056c:	tst	x22, #0x2000000000000000
1006e0570:	csel	x8, x8, x9, eq
1006e0574:	cbz	x8, 0x1006e0614
1006e0578:	add	x8, sp, #0x40
1006e057c:	mov	x0, x25
1006e0580:	bl	0x1004f4c0c
1006e0584:	ldp	x25, x27, [sp, #0x58]
1006e0588:	add	x0, sp, #0x40
1006e058c:	mov	x1, x25
1006e0590:	bl	0x10002d8b0
1006e0594:	mov	x20, x0
1006e0598:	ldr	x9, [x27, #0x58]
1006e059c:	sub	x8, x29, #0x78
1006e05a0:	mov	x0, x24
1006e05a4:	mov	x1, x22
1006e05a8:	mov	x2, x26
1006e05ac:	mov	x3, x23
1006e05b0:	mov	x4, x25
1006e05b4:	mov	x5, x27
1006e05b8:	blr	x9
1006e05bc:	ldurb	w8, [x29, #-0x58]
1006e05c0:	cmp	w8, #0xff
1006e05c4:	b.eq	0x1006e0638
1006e05c8:	sub	x9, x29, #0x78
1006e05cc:	ldp	q0, q1, [x9]
1006e05d0:	stp	q0, q1, [sp]
1006e05d4:	strb	w8, [sp, #0x20]
1006e05d8:	mov	x0, sp
1006e05dc:	blr	x19
1006e05e0:	mov	x0, x23
1006e05e4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e05e8:	mov	x0, x22
1006e05ec:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e05f0:	mov	x0, x21
1006e05f4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e05f8:	adrp	x1, 7264 ; 0x102340000
1006e05fc:	add	x1, x1, #0xc60
1006e0600:	adrp	x2, 5141 ; 0x101af5000
1006e0604:	add	x2, x2, #0xe80
1006e0608:	sub	x0, x29, #0x78
1006e060c:	bl	0x10002d870
1006e0610:	b	0x1006e0650
1006e0614:	mov	x0, x25
1006e0618:	bl	0x1004f6710
1006e061c:	mov	x0, x23
1006e0620:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0624:	mov	x0, x22
1006e0628:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e062c:	mov	x0, x21
1006e0630:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0634:	b	0x1006e0658
1006e0638:	mov	x0, x23
1006e063c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0640:	mov	x0, x22
1006e0644:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0648:	mov	x0, x21
1006e064c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0650:	add	x0, sp, #0x40
1006e0654:	bl	0x10002d8d4
1006e0658:	ldp	x29, x30, [sp, #0x140]
1006e065c:	ldp	x20, x19, [sp, #0x130]
1006e0660:	ldp	x22, x21, [sp, #0x120]
1006e0664:	ldp	x24, x23, [sp, #0x110]
1006e0668:	ldp	x26, x25, [sp, #0x100]
1006e066c:	ldp	x28, x27, [sp, #0xf0]
1006e0670:	add	sp, sp, #0x150
1006e0674:	ret
1006e0678:	stp	x20, x19, [sp, #-0x20]!
1006e067c:	stp	x29, x30, [sp, #0x10]
1006e0680:	add	x29, sp, #0x10
1006e0684:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e0688:	mov	x20, x0
1006e068c:	bl	0x1006e04b0
1006e0690:	mov	x0, x20
1006e0694:	ldp	x29, x30, [sp, #0x10]
1006e0698:	ldp	x20, x19, [sp], #0x20
1006e069c:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e06a0:	mov	w0, #0x0
1006e06a4:	mov	w1, #0x0
1006e06a8:	b	0x1006e097c
1006e06ac:	stp	x20, x19, [sp, #-0x20]!
1006e06b0:	stp	x29, x30, [sp, #0x10]
1006e06b4:	add	x29, sp, #0x10
1006e06b8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e06bc:	mov	x20, x0
1006e06c0:	mov	w0, #0x0
1006e06c4:	mov	w1, #0x0
1006e06c8:	bl	0x1006e097c
1006e06cc:	mov	x0, x20
1006e06d0:	ldp	x29, x30, [sp, #0x10]
1006e06d4:	ldp	x20, x19, [sp], #0x20
1006e06d8:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e06dc:	mov	w0, #0x0
1006e06e0:	mov	w1, #0x1
1006e06e4:	b	0x1006e097c
1006e06e8:	stp	x20, x19, [sp, #-0x20]!
1006e06ec:	stp	x29, x30, [sp, #0x10]
1006e06f0:	add	x29, sp, #0x10
1006e06f4:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e06f8:	mov	x20, x0
1006e06fc:	mov	w0, #0x0
1006e0700:	mov	w1, #0x1
1006e0704:	bl	0x1006e097c
1006e0708:	mov	x0, x20
1006e070c:	ldp	x29, x30, [sp, #0x10]
1006e0710:	ldp	x20, x19, [sp], #0x20
1006e0714:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e0718:	mov	w0, #0x1
1006e071c:	mov	w1, #0x0
1006e0720:	b	0x1006e097c
1006e0724:	stp	x20, x19, [sp, #-0x20]!
1006e0728:	stp	x29, x30, [sp, #0x10]
1006e072c:	add	x29, sp, #0x10
1006e0730:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e0734:	mov	x20, x0
1006e0738:	mov	w0, #0x1
1006e073c:	mov	w1, #0x0
1006e0740:	bl	0x1006e097c
1006e0744:	mov	x0, x20
1006e0748:	ldp	x29, x30, [sp, #0x10]
1006e074c:	ldp	x20, x19, [sp], #0x20
1006e0750:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e0754:	mov	w0, #0x1
1006e0758:	mov	w1, #0x1
1006e075c:	b	0x1006e097c
1006e0760:	stp	x20, x19, [sp, #-0x20]!
1006e0764:	stp	x29, x30, [sp, #0x10]
1006e0768:	add	x29, sp, #0x10
1006e076c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e0770:	mov	x20, x0
1006e0774:	mov	w0, #0x1
1006e0778:	mov	w1, #0x1
1006e077c:	bl	0x1006e097c
1006e0780:	mov	x0, x20
1006e0784:	ldp	x29, x30, [sp, #0x10]
1006e0788:	ldp	x20, x19, [sp], #0x20
1006e078c:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e0790:	adrp	x0, -491 ; 0x1004f5000
1006e0794:	add	x0, x0, #0x454
1006e0798:	b	0x1006e07d0
1006e079c:	stp	x20, x19, [sp, #-0x20]!
1006e07a0:	stp	x29, x30, [sp, #0x10]
1006e07a4:	add	x29, sp, #0x10
1006e07a8:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e07ac:	mov	x20, x0
1006e07b0:	bl	0x1006e0790
1006e07b4:	mov	x0, x20
1006e07b8:	ldp	x29, x30, [sp, #0x10]
1006e07bc:	ldp	x20, x19, [sp], #0x20
1006e07c0:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e07c4:	adrp	x0, -491 ; 0x1004f5000
1006e07c8:	add	x0, x0, #0x5e8
1006e07cc:	b	0x1006e07d0
1006e07d0:	sub	sp, sp, #0x140
1006e07d4:	stp	x28, x27, [sp, #0xe0]
1006e07d8:	stp	x26, x25, [sp, #0xf0]
1006e07dc:	stp	x24, x23, [sp, #0x100]
1006e07e0:	stp	x22, x21, [sp, #0x110]
1006e07e4:	stp	x20, x19, [sp, #0x120]
1006e07e8:	stp	x29, x30, [sp, #0x130]
1006e07ec:	add	x29, sp, #0x130
1006e07f0:	str	x0, [sp]
1006e07f4:	bl	0x10060388c
1006e07f8:	mov	x22, x0
1006e07fc:	add	x8, sp, #0x50
1006e0800:	bl	0x1004fa378
1006e0804:	ldrb	w21, [sp, #0x50]
1006e0808:	ldr	w26, [sp, #0x54]
1006e080c:	ldp	x25, x24, [sp, #0x58]
1006e0810:	ldp	x19, x23, [sp, #0x68]
1006e0814:	ldp	x28, x27, [sp, #0x78]
1006e0818:	ldrb	w8, [sp, #0x88]
1006e081c:	str	w8, [sp, #0xc]
1006e0820:	mov	x0, x22
1006e0824:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e0828:	cbz	x24, 0x1006e0834
1006e082c:	add	x22, sp, #0x90
1006e0830:	b	0x1006e08a0
1006e0834:	adrp	x8, 7298 ; 0x102362000
1006e0838:	ldr	x8, [x8, #0xd60]
1006e083c:	add	x8, x20, x8
1006e0840:	ldp	q1, q0, [x8]
1006e0844:	stp	q1, q0, [sp, #0x90]
1006e0848:	ldr	q0, [x8, #0x20]
1006e084c:	str	q0, [sp, #0xb0]
1006e0850:	ldur	q0, [x8, #0x29]
1006e0854:	add	x8, sp, #0x90
1006e0858:	stur	q0, [x8, #0x29]
1006e085c:	ldr	x24, [sp, #0xa0]
1006e0860:	add	x22, sp, #0x90
1006e0864:	cbz	x24, 0x1006e0934
1006e0868:	ldrb	w8, [sp, #0xc8]
1006e086c:	str	w8, [sp, #0xc]
1006e0870:	ldp	x28, x27, [sp, #0xb8]
1006e0874:	ldp	x19, x23, [sp, #0xa8]
1006e0878:	ldr	x25, [sp, #0x98]
1006e087c:	ldr	w26, [sp, #0x94]
1006e0880:	ldrb	w21, [sp, #0x90]
1006e0884:	adrp	x2, 7265 ; 0x102341000
1006e0888:	add	x2, x2, #0x170
1006e088c:	adrp	x3, 5142 ; 0x101af6000
1006e0890:	add	x3, x3, #0x950
1006e0894:	add	x0, sp, #0x90
1006e0898:	add	x1, sp, #0x10
1006e089c:	bl	0x10002d8f4
1006e08a0:	strb	w21, [sp, #0x10]
1006e08a4:	str	w26, [sp, #0x14]
1006e08a8:	stp	x25, x24, [sp, #0x18]
1006e08ac:	stp	x19, x23, [sp, #0x28]
1006e08b0:	stp	x28, x27, [sp, #0x38]
1006e08b4:	ldr	w8, [sp, #0xc]
1006e08b8:	and	w8, w8, #0x1
1006e08bc:	strb	w8, [sp, #0x48]
1006e08c0:	ldp	q0, q1, [sp, #0x10]
1006e08c4:	stp	q0, q1, [sp, #0x90]
1006e08c8:	ldr	q0, [sp, #0x30]
1006e08cc:	str	q0, [sp, #0xb0]
1006e08d0:	and	x8, x25, #0xffffffffffff
1006e08d4:	ldur	q0, [sp, #0x39]
1006e08d8:	ubfx	x9, x24, #56, #4
1006e08dc:	tst	x24, #0x2000000000000000
1006e08e0:	csel	x8, x8, x9, eq
1006e08e4:	stur	q0, [x22, #0x29]
1006e08e8:	cbz	x8, 0x1006e0924
1006e08ec:	adrp	x8, 7298 ; 0x102362000
1006e08f0:	ldr	x8, [x8, #0xd68]
1006e08f4:	add	x8, x20, x8
1006e08f8:	ldp	x20, x21, [x8]
1006e08fc:	mov	x0, x21
1006e0900:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1006e0904:	add	x0, sp, #0x90
1006e0908:	mov	x1, x20
1006e090c:	mov	x2, x21
1006e0910:	ldr	x8, [sp]
1006e0914:	blr	x8
1006e0918:	mov	x0, x21
1006e091c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0920:	b	0x1006e092c
1006e0924:	mov	x0, x21
1006e0928:	bl	0x1004f6710
1006e092c:	add	x0, sp, #0x10
1006e0930:	bl	0x100220418
1006e0934:	ldp	x29, x30, [sp, #0x130]
1006e0938:	ldp	x20, x19, [sp, #0x120]
1006e093c:	ldp	x22, x21, [sp, #0x110]
1006e0940:	ldp	x24, x23, [sp, #0x100]
1006e0944:	ldp	x26, x25, [sp, #0xf0]
1006e0948:	ldp	x28, x27, [sp, #0xe0]
1006e094c:	add	sp, sp, #0x140
1006e0950:	ret
1006e0954:	stp	x20, x19, [sp, #-0x20]!
1006e0958:	stp	x29, x30, [sp, #0x10]
1006e095c:	add	x29, sp, #0x10
1006e0960:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e0964:	mov	x20, x0
1006e0968:	bl	0x1006e07c4
1006e096c:	mov	x0, x20
1006e0970:	ldp	x29, x30, [sp, #0x10]
1006e0974:	ldp	x20, x19, [sp], #0x20
1006e0978:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e097c:	sub	sp, sp, #0x140
1006e0980:	stp	x28, x27, [sp, #0xe0]
1006e0984:	stp	x26, x25, [sp, #0xf0]
1006e0988:	stp	x24, x23, [sp, #0x100]
1006e098c:	stp	x22, x21, [sp, #0x110]
1006e0990:	stp	x20, x19, [sp, #0x120]
1006e0994:	stp	x29, x30, [sp, #0x130]
1006e0998:	add	x29, sp, #0x130
1006e099c:	stp	w1, w0, [sp, #0x4]
1006e09a0:	bl	0x10060388c
1006e09a4:	mov	x23, x0
1006e09a8:	add	x8, sp, #0x50
1006e09ac:	bl	0x1004fa378
1006e09b0:	ldrb	w22, [sp, #0x50]
1006e09b4:	ldr	w27, [sp, #0x54]
1006e09b8:	ldp	x26, x25, [sp, #0x58]
1006e09bc:	ldp	x21, x19, [sp, #0x68]
1006e09c0:	ldp	x24, x28, [sp, #0x78]
1006e09c4:	ldrb	w8, [sp, #0x88]
1006e09c8:	str	w8, [sp, #0xc]
1006e09cc:	mov	x0, x23
1006e09d0:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e09d4:	cbz	x25, 0x1006e09e0
1006e09d8:	add	x23, sp, #0x90
1006e09dc:	b	0x1006e0a4c
1006e09e0:	adrp	x8, 7298 ; 0x102362000
1006e09e4:	ldr	x8, [x8, #0xd60]
1006e09e8:	add	x8, x20, x8
1006e09ec:	ldp	q1, q0, [x8]
1006e09f0:	stp	q1, q0, [sp, #0x90]
1006e09f4:	ldr	q0, [x8, #0x20]
1006e09f8:	str	q0, [sp, #0xb0]
1006e09fc:	ldur	q0, [x8, #0x29]
1006e0a00:	add	x8, sp, #0x90
1006e0a04:	stur	q0, [x8, #0x29]
1006e0a08:	ldr	x25, [sp, #0xa0]
1006e0a0c:	add	x23, sp, #0x90
1006e0a10:	cbz	x25, 0x1006e0ae4
1006e0a14:	ldrb	w8, [sp, #0xc8]
1006e0a18:	str	w8, [sp, #0xc]
1006e0a1c:	ldp	x24, x28, [sp, #0xb8]
1006e0a20:	ldp	x21, x19, [sp, #0xa8]
1006e0a24:	ldr	x26, [sp, #0x98]
1006e0a28:	ldr	w27, [sp, #0x94]
1006e0a2c:	ldrb	w22, [sp, #0x90]
1006e0a30:	adrp	x2, 7265 ; 0x102341000
1006e0a34:	add	x2, x2, #0x170
1006e0a38:	adrp	x3, 5142 ; 0x101af6000
1006e0a3c:	add	x3, x3, #0x950
1006e0a40:	add	x0, sp, #0x90
1006e0a44:	add	x1, sp, #0x10
1006e0a48:	bl	0x10002d8f4
1006e0a4c:	strb	w22, [sp, #0x10]
1006e0a50:	str	w27, [sp, #0x14]
1006e0a54:	stp	x26, x25, [sp, #0x18]
1006e0a58:	stp	x21, x19, [sp, #0x28]
1006e0a5c:	stp	x24, x28, [sp, #0x38]
1006e0a60:	ldr	w8, [sp, #0xc]
1006e0a64:	and	w8, w8, #0x1
1006e0a68:	strb	w8, [sp, #0x48]
1006e0a6c:	ldp	q0, q1, [sp, #0x10]
1006e0a70:	stp	q0, q1, [sp, #0x90]
1006e0a74:	ldr	q0, [sp, #0x30]
1006e0a78:	str	q0, [sp, #0xb0]
1006e0a7c:	and	x8, x26, #0xffffffffffff
1006e0a80:	ldur	q0, [sp, #0x39]
1006e0a84:	ubfx	x9, x25, #56, #4
1006e0a88:	tst	x25, #0x2000000000000000
1006e0a8c:	csel	x8, x8, x9, eq
1006e0a90:	stur	q0, [x23, #0x29]
1006e0a94:	cbz	x8, 0x1006e0ad4
1006e0a98:	adrp	x8, 7298 ; 0x102362000
1006e0a9c:	ldr	x8, [x8, #0xd68]
1006e0aa0:	add	x8, x20, x8
1006e0aa4:	ldp	x20, x22, [x8]
1006e0aa8:	mov	x0, x22
1006e0aac:	bl	0x101aca624 ; symbol stub for: _swift_bridgeObjectRetain
1006e0ab0:	add	x0, sp, #0x90
1006e0ab4:	ldp	w8, w3, [sp, #0x4]
1006e0ab8:	and	w4, w8, #0x1
1006e0abc:	mov	x1, x20
1006e0ac0:	mov	x2, x22
1006e0ac4:	bl	0x1004f52d4
1006e0ac8:	mov	x0, x22
1006e0acc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0ad0:	b	0x1006e0adc
1006e0ad4:	mov	x0, x22
1006e0ad8:	bl	0x1004f6710
1006e0adc:	add	x0, sp, #0x10
1006e0ae0:	bl	0x100220418
1006e0ae4:	ldp	x29, x30, [sp, #0x130]
1006e0ae8:	ldp	x20, x19, [sp, #0x120]
1006e0aec:	ldp	x22, x21, [sp, #0x110]
1006e0af0:	ldp	x24, x23, [sp, #0x100]
1006e0af4:	ldp	x26, x25, [sp, #0xf0]
1006e0af8:	ldp	x28, x27, [sp, #0xe0]
1006e0afc:	add	sp, sp, #0x140
1006e0b00:	ret
1006e0b04:	sub	sp, sp, #0x20
1006e0b08:	stp	x29, x30, [sp, #0x10]
1006e0b0c:	add	x29, sp, #0x10
1006e0b10:	adrp	x8, 7298 ; 0x102362000
1006e0b14:	ldr	x8, [x8, #0xd60]
1006e0b18:	add	x8, x20, x8
1006e0b1c:	movi.2d	v0, #0000000000000000
1006e0b20:	stp	q0, q0, [x8]
1006e0b24:	str	q0, [x8, #0x20]
1006e0b28:	stur	q0, [x8, #0x29]
1006e0b2c:	adrp	x8, 7298 ; 0x102362000
1006e0b30:	ldr	x8, [x8, #0xd68]
1006e0b34:	add	x8, x20, x8
1006e0b38:	mov	x9, #-0x2000000000000000
1006e0b3c:	stp	xzr, x9, [x8]
1006e0b40:	bl	0x1006e419c
1006e0b44:	stp	x20, x0, [sp]
1006e0b48:	adrp	x8, 7234 ; 0x102322000
1006e0b4c:	ldr	x1, [x8, #0xf98] ; Objc selector ref: init
1006e0b50:	mov	x0, sp
1006e0b54:	bl	0x101ac9d0c ; Objc message: -[[x0 super] init]
1006e0b58:	ldp	x29, x30, [sp, #0x10]
1006e0b5c:	add	sp, sp, #0x20
1006e0b60:	ret
1006e0b64:	sub	sp, sp, #0x30
1006e0b68:	stp	x20, x19, [sp, #0x10]
1006e0b6c:	stp	x29, x30, [sp, #0x20]
1006e0b70:	add	x29, sp, #0x20
1006e0b74:	mov	x19, x0
1006e0b78:	adrp	x8, 7298 ; 0x102362000
1006e0b7c:	ldr	x8, [x8, #0xd60]
1006e0b80:	add	x8, x0, x8
1006e0b84:	movi.2d	v0, #0000000000000000
1006e0b88:	stp	q0, q0, [x8]
1006e0b8c:	str	q0, [x8, #0x20]
1006e0b90:	stur	q0, [x8, #0x29]
1006e0b94:	adrp	x8, 7298 ; 0x102362000
1006e0b98:	ldr	x8, [x8, #0xd68]
1006e0b9c:	add	x8, x0, x8
1006e0ba0:	mov	x9, #-0x2000000000000000
1006e0ba4:	stp	xzr, x9, [x8]
1006e0ba8:	bl	0x1006e419c
1006e0bac:	stp	x19, x0, [sp]
1006e0bb0:	adrp	x8, 7234 ; 0x102322000
1006e0bb4:	ldr	x1, [x8, #0xf98] ; Objc selector ref: init
1006e0bb8:	mov	x0, sp
1006e0bbc:	bl	0x101ac9d0c ; Objc message: -[[x0 super] init]
1006e0bc0:	ldp	x29, x30, [sp, #0x20]
1006e0bc4:	ldp	x20, x19, [sp, #0x10]
1006e0bc8:	add	sp, sp, #0x30
1006e0bcc:	ret
1006e0bd0:	adrp	x0, 4 ; 0x1006e4000
1006e0bd4:	add	x0, x0, #0x19c
1006e0bd8:	b	0x10019a3f0
1006e0bdc:	stp	x20, x19, [sp, #-0x20]!
1006e0be0:	stp	x29, x30, [sp, #0x10]
1006e0be4:	add	x29, sp, #0x10
1006e0be8:	mov	x19, x0
1006e0bec:	adrp	x8, 7298 ; 0x102362000
1006e0bf0:	ldr	x8, [x8, #0xd60]
1006e0bf4:	add	x8, x0, x8
1006e0bf8:	ldp	x0, x1, [x8]
1006e0bfc:	ldp	x2, x3, [x8, #0x10]
1006e0c00:	ldp	x4, x5, [x8, #0x20]
1006e0c04:	ldr	x6, [x8, #0x30]
1006e0c08:	ldrb	w7, [x8, #0x38]
1006e0c0c:	bl	0x1006e4160
1006e0c10:	adrp	x8, 7298 ; 0x102362000
1006e0c14:	ldr	x8, [x8, #0xd68]
1006e0c18:	add	x8, x19, x8
1006e0c1c:	ldr	x0, [x8, #0x8]
1006e0c20:	ldp	x29, x30, [sp, #0x10]
1006e0c24:	ldp	x20, x19, [sp], #0x20
1006e0c28:	b	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0c2c:	adrp	x1, 4 ; 0x1006e4000
1006e0c30:	add	x1, x1, #0xed0
1006e0c34:	adrp	x2, 7418 ; 0x1023da000
1006e0c38:	add	x2, x2, #0x468
1006e0c3c:	b	0x1000785b0
1006e0c40:	adrp	x0, 7372 ; 0x1023ac000
1006e0c44:	add	x0, x0, #0xca0
1006e0c48:	adrp	x1, 7418 ; 0x1023da000
1006e0c4c:	add	x1, x1, #0x468
1006e0c50:	adrp	x2, 0 ; 0x1006e0000
1006e0c54:	add	x2, x2, #0xc2c
1006e0c58:	b	0x100068c08
1006e0c5c:	mov	w0, #0x0
1006e0c60:	ret
1006e0c64:	sub	sp, sp, #0x110
1006e0c68:	stp	x28, x27, [sp, #0xb0]
1006e0c6c:	stp	x26, x25, [sp, #0xc0]
1006e0c70:	stp	x24, x23, [sp, #0xd0]
1006e0c74:	stp	x22, x21, [sp, #0xe0]
1006e0c78:	stp	x20, x19, [sp, #0xf0]
1006e0c7c:	stp	x29, x30, [sp, #0x100]
1006e0c80:	add	x29, sp, #0x100
1006e0c84:	mov	x21, x20
1006e0c88:	mov	x19, x0
1006e0c8c:	mov	x22, #0x18
1006e0c90:	movk	x22, #0xd000, lsl #48
1006e0c94:	bl	0x101ad0920 ; selector removeAllItems
1006e0c98:	bl	0x10060388c
1006e0c9c:	cbz	x0, 0x1006e1844
1006e0ca0:	ldr	x8, [x0]
1006e0ca4:	ldr	x8, [x8, #0x260]
1006e0ca8:	mov	x20, x0
1006e0cac:	mov	x23, x0
1006e0cb0:	blr	x8
1006e0cb4:	mov	x20, x0
1006e0cb8:	mov	x0, x23
1006e0cbc:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e0cc0:	cbz	x20, 0x1006e1844
1006e0cc4:	stur	x21, [x29, #-0x68]
1006e0cc8:	ldr	x8, [x20]
1006e0ccc:	ldr	x8, [x8, #0x370]
1006e0cd0:	blr	x8
1006e0cd4:	mov	x23, x0
1006e0cd8:	ldr	x8, [x20]
1006e0cdc:	ldr	x8, [x8, #0x420]
1006e0ce0:	str	x20, [sp, #0x70]
1006e0ce4:	blr	x8
1006e0ce8:	mov	x25, x1
1006e0cec:	cbz	x1, 0x1006e0cf8
1006e0cf0:	mov	x0, x25
1006e0cf4:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0cf8:	adrp	x8, 5895 ; 0x101de7000
1006e0cfc:	add	x8, x8, #0x50 ; literal pool for: "priv.group_this_pane"
1006e0d00:	sub	x8, x8, #0x20
1006e0d04:	sub	x0, x22, #0x4
1006e0d08:	stur	x0, [x29, #-0x78]
1006e0d0c:	orr	x1, x8, #0x8000000000000000
1006e0d10:	bl	0x100063df0
1006e0d14:	mov	x20, x1
1006e0d18:	bl	0x1006e41bc
1006e0d1c:	mov	x21, x0
1006e0d20:	mov	x0, x20
1006e0d24:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0d28:	mov	x0, x19
1006e0d2c:	mov	x2, x21
1006e0d30:	bl	0x101acb2c0 ; selector addItem:
1006e0d34:	mov	x0, x21
1006e0d38:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0d3c:	adrp	x1, 7267 ; 0x102343000
1006e0d40:	add	x1, x1, #0x360
1006e0d44:	adrp	x2, 7238 ; 0x102326000
1006e0d48:	add	x2, x2, #0xac8 ; Objc class ref: _OBJC_CLASS_$_NSMenuItem
1006e0d4c:	mov	x0, #0x0
1006e0d50:	mov	x26, x2
1006e0d54:	bl	0x10002d97c
1006e0d58:	mov	x20, x0
1006e0d5c:	stur	x0, [x29, #-0x70]
1006e0d60:	adrp	x8, 5895 ; 0x101de7000
1006e0d64:	add	x8, x8, #0x70 ; literal pool for: "priv.section_sound"
1006e0d68:	sub	x8, x8, #0x20
1006e0d6c:	sub	x24, x22, #0x6
1006e0d70:	orr	x1, x8, #0x8000000000000000
1006e0d74:	mov	x0, x24
1006e0d78:	bl	0x100063df0
1006e0d7c:	mov	x21, x1
1006e0d80:	bl	0x101ac6c10 ; symbol stub for: _$sSo10NSMenuItemC6AppKitE13sectionHeader5titleABSS_tFZ
1006e0d84:	mov	x20, x0
1006e0d88:	mov	x0, x21
1006e0d8c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0d90:	mov	x0, x19
1006e0d94:	mov	x2, x20
1006e0d98:	bl	0x101acb2c0 ; selector addItem:
1006e0d9c:	mov	x0, x20
1006e0da0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0da4:	mov	x0, #0x7270
1006e0da8:	movk	x0, #0x7669, lsl #16
1006e0dac:	movk	x0, #0x6d2e, lsl #32
1006e0db0:	movk	x0, #0x7475, lsl #48
1006e0db4:	mov	x1, #0x65
1006e0db8:	movk	x1, #0xe900, lsl #48
1006e0dbc:	bl	0x100063df0
1006e0dc0:	mov	x28, x0
1006e0dc4:	str	x25, [sp, #0x80]
1006e0dc8:	mov	x25, x1
1006e0dcc:	ldr	x8, [x23]
1006e0dd0:	ldr	x8, [x8, #0x2b0]
1006e0dd4:	mov	x20, x23
1006e0dd8:	blr	x8
1006e0ddc:	mov	x20, x0
1006e0de0:	adrp	x8, 7233 ; 0x102321000
1006e0de4:	ldr	x27, [x8, #0xd88] ; Objc selector ref: handle:
1006e0de8:	ldr	x0, [x26]
1006e0dec:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e0df0:	mov	x26, x0
1006e0df4:	mov	x0, x28
1006e0df8:	mov	x1, x25
1006e0dfc:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e0e00:	mov	x28, x0
1006e0e04:	mov	x0, #0x0
1006e0e08:	mov	x1, #-0x2000000000000000
1006e0e0c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e0e10:	mov	x21, x0
1006e0e14:	mov	x0, x26
1006e0e18:	mov	x2, x28
1006e0e1c:	mov	x3, x27
1006e0e20:	mov	x4, x21
1006e0e24:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e0e28:	mov	x26, x0
1006e0e2c:	mov	x0, x28
1006e0e30:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0e34:	mov	x0, x21
1006e0e38:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0e3c:	mov	x0, x26
1006e0e40:	mov	x22, x23
1006e0e44:	ldur	x23, [x29, #-0x68]
1006e0e48:	mov	x2, x23
1006e0e4c:	bl	0x101ad45e0 ; selector setTarget:
1006e0e50:	mov	x0, x26
1006e0e54:	mov	w2, #0x1
1006e0e58:	bl	0x101ad45a0 ; selector setTag:
1006e0e5c:	and	x2, x20, #0x1
1006e0e60:	mov	x0, x26
1006e0e64:	bl	0x101ad4360 ; selector setState:
1006e0e68:	mov	x0, x19
1006e0e6c:	mov	x2, x26
1006e0e70:	bl	0x101acb2c0 ; selector addItem:
1006e0e74:	mov	x0, x25
1006e0e78:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0e7c:	mov	x0, x26
1006e0e80:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0e84:	adrp	x8, 5895 ; 0x101de7000
1006e0e88:	add	x8, x8, #0x90 ; literal pool for: "priv.beep_on_error"
1006e0e8c:	sub	x8, x8, #0x20
1006e0e90:	orr	x1, x8, #0x8000000000000000
1006e0e94:	str	x24, [sp, #0x68]
1006e0e98:	mov	x0, x24
1006e0e9c:	bl	0x100063df0
1006e0ea0:	mov	x21, x0
1006e0ea4:	mov	x25, x1
1006e0ea8:	ldr	x8, [x22]
1006e0eac:	ldr	x8, [x8, #0xe8]
1006e0eb0:	mov	x20, x22
1006e0eb4:	blr	x8
1006e0eb8:	mov	x20, x0
1006e0ebc:	adrp	x24, 7238 ; 0x102326000
1006e0ec0:	add	x24, x24, #0xac8 ; Objc class ref: _OBJC_CLASS_$_NSMenuItem
1006e0ec4:	ldr	x0, [x24]
1006e0ec8:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e0ecc:	mov	x26, x0
1006e0ed0:	mov	x0, x21
1006e0ed4:	mov	x1, x25
1006e0ed8:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e0edc:	mov	x21, x0
1006e0ee0:	mov	x0, #0x0
1006e0ee4:	mov	x1, #-0x2000000000000000
1006e0ee8:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e0eec:	mov	x28, x0
1006e0ef0:	mov	x0, x26
1006e0ef4:	mov	x2, x21
1006e0ef8:	mov	x3, x27
1006e0efc:	mov	x4, x28
1006e0f00:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e0f04:	mov	x26, x0
1006e0f08:	mov	x0, x21
1006e0f0c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0f10:	mov	x0, x28
1006e0f14:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0f18:	mov	x0, x26
1006e0f1c:	mov	x2, x23
1006e0f20:	bl	0x101ad45e0 ; selector setTarget:
1006e0f24:	mov	x0, x26
1006e0f28:	mov	w2, #0x2
1006e0f2c:	bl	0x101ad45a0 ; selector setTag:
1006e0f30:	and	x2, x20, #0x1
1006e0f34:	mov	x0, x26
1006e0f38:	bl	0x101ad4360 ; selector setState:
1006e0f3c:	mov	x0, x19
1006e0f40:	mov	x2, x26
1006e0f44:	bl	0x101acb2c0 ; selector addItem:
1006e0f48:	mov	x0, x25
1006e0f4c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e0f50:	mov	x0, x26
1006e0f54:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0f58:	adrp	x8, 5895 ; 0x101de7000
1006e0f5c:	add	x8, x8, #0xb0 ; literal pool for: "priv.allow_terminal_bell"
1006e0f60:	sub	x8, x8, #0x20
1006e0f64:	orr	x1, x8, #0x8000000000000000
1006e0f68:	mov	x0, #0x18
1006e0f6c:	movk	x0, #0xd000, lsl #48
1006e0f70:	bl	0x100063df0
1006e0f74:	mov	x21, x0
1006e0f78:	mov	x25, x1
1006e0f7c:	ldr	x8, [x22]
1006e0f80:	ldr	x8, [x8, #0x100]
1006e0f84:	mov	x20, x22
1006e0f88:	blr	x8
1006e0f8c:	mov	x20, x0
1006e0f90:	ldr	x0, [x24]
1006e0f94:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e0f98:	mov	x26, x0
1006e0f9c:	mov	x0, x21
1006e0fa0:	mov	x1, x25
1006e0fa4:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e0fa8:	mov	x21, x0
1006e0fac:	mov	x0, #0x0
1006e0fb0:	mov	x1, #-0x2000000000000000
1006e0fb4:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e0fb8:	mov	x28, x0
1006e0fbc:	mov	x0, x26
1006e0fc0:	mov	x2, x21
1006e0fc4:	mov	x3, x27
1006e0fc8:	mov	x4, x28
1006e0fcc:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e0fd0:	mov	x26, x0
1006e0fd4:	mov	x0, x21
1006e0fd8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0fdc:	mov	x0, x28
1006e0fe0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e0fe4:	mov	x0, x26
1006e0fe8:	mov	x2, x23
1006e0fec:	bl	0x101ad45e0 ; selector setTarget:
1006e0ff0:	mov	x0, x26
1006e0ff4:	mov	w2, #0x3
1006e0ff8:	bl	0x101ad45a0 ; selector setTag:
1006e0ffc:	and	x2, x20, #0x1
1006e1000:	mov	x0, x26
1006e1004:	bl	0x101ad4360 ; selector setState:
1006e1008:	mov	x0, x19
1006e100c:	mov	x2, x26
1006e1010:	bl	0x101acb2c0 ; selector addItem:
1006e1014:	mov	x0, x25
1006e1018:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e101c:	mov	x0, x26
1006e1020:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1024:	ldr	x0, [x24]
1006e1028:	bl	0x101ac9d24 ; symbol stub for: _objc_opt_self
1006e102c:	stur	x0, [x29, #-0x60]
1006e1030:	bl	0x101ad1620 ; selector separatorItem
1006e1034:	mov	x29, x29
1006e1038:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006e103c:	mov	x20, x0
1006e1040:	mov	x0, x19
1006e1044:	mov	x2, x20
1006e1048:	bl	0x101acb2c0 ; selector addItem:
1006e104c:	mov	x0, x20
1006e1050:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1054:	adrp	x8, 5894 ; 0x101de7000
1006e1058:	add	x8, x8, #0xd0 ; literal pool for: "priv.section_notification"
1006e105c:	sub	x9, x8, #0x20
1006e1060:	mov	x8, #0x18
1006e1064:	movk	x8, #0xd000, lsl #48
1006e1068:	add	x0, x8, #0x1
1006e106c:	str	x9, [sp, #0x60]
1006e1070:	orr	x1, x9, #0x8000000000000000
1006e1074:	bl	0x100063df0
1006e1078:	mov	x21, x1
1006e107c:	ldur	x20, [x29, #-0x70]
1006e1080:	bl	0x101ac6c10 ; symbol stub for: _$sSo10NSMenuItemC6AppKitE13sectionHeader5titleABSS_tFZ
1006e1084:	mov	x20, x0
1006e1088:	mov	x0, x21
1006e108c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1090:	mov	x0, x19
1006e1094:	mov	x2, x20
1006e1098:	bl	0x101acb2c0 ; selector addItem:
1006e109c:	mov	x0, x20
1006e10a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e10a4:	mov	x0, #0x7270
1006e10a8:	movk	x0, #0x7669, lsl #16
1006e10ac:	movk	x0, #0x6d2e, lsl #32
1006e10b0:	movk	x0, #0x7475, lsl #48
1006e10b4:	mov	x1, #0x65
1006e10b8:	movk	x1, #0xe900, lsl #48
1006e10bc:	bl	0x100063df0
1006e10c0:	mov	x25, x0
1006e10c4:	mov	x21, x1
1006e10c8:	ldr	x8, [x22]
1006e10cc:	ldr	x8, [x8, #0x2b8]
1006e10d0:	mov	x20, x22
1006e10d4:	blr	x8
1006e10d8:	mov	x20, x0
1006e10dc:	ldr	x0, [x24]
1006e10e0:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e10e4:	mov	x26, x0
1006e10e8:	mov	x0, x25
1006e10ec:	mov	x1, x21
1006e10f0:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e10f4:	mov	x25, x0
1006e10f8:	mov	x0, #0x0
1006e10fc:	mov	x1, #-0x2000000000000000
1006e1100:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1104:	mov	x28, x0
1006e1108:	mov	x0, x26
1006e110c:	mov	x2, x25
1006e1110:	mov	x3, x27
1006e1114:	mov	x4, x28
1006e1118:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e111c:	mov	x26, x0
1006e1120:	mov	x0, x25
1006e1124:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1128:	mov	x0, x28
1006e112c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1130:	mov	x0, x26
1006e1134:	mov	x2, x23
1006e1138:	bl	0x101ad45e0 ; selector setTarget:
1006e113c:	mov	x0, x26
1006e1140:	mov	w2, #0x4
1006e1144:	bl	0x101ad45a0 ; selector setTag:
1006e1148:	and	x2, x20, #0x1
1006e114c:	mov	x0, x26
1006e1150:	bl	0x101ad4360 ; selector setState:
1006e1154:	mov	x0, x19
1006e1158:	mov	x2, x26
1006e115c:	bl	0x101acb2c0 ; selector addItem:
1006e1160:	mov	x0, x21
1006e1164:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1168:	mov	x0, x26
1006e116c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1170:	adrp	x8, 5894 ; 0x101de7000
1006e1174:	add	x8, x8, #0xf0 ; literal pool for: "priv.notify_on_finish"
1006e1178:	sub	x8, x8, #0x20
1006e117c:	mov	x9, #0x18
1006e1180:	movk	x9, #0xd000, lsl #48
1006e1184:	sub	x0, x9, #0x3
1006e1188:	orr	x1, x8, #0x8000000000000000
1006e118c:	str	x0, [sp, #0x50]
1006e1190:	bl	0x100063df0
1006e1194:	mov	x26, x0
1006e1198:	mov	x25, x1
1006e119c:	ldr	x8, [x22]
1006e11a0:	ldr	x8, [x8, #0x118]
1006e11a4:	mov	x20, x22
1006e11a8:	blr	x8
1006e11ac:	mov	x20, x0
1006e11b0:	ldr	x0, [x24]
1006e11b4:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e11b8:	mov	x28, x0
1006e11bc:	mov	x0, x26
1006e11c0:	mov	x1, x25
1006e11c4:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e11c8:	mov	x26, x0
1006e11cc:	mov	x0, #0x0
1006e11d0:	mov	x1, #-0x2000000000000000
1006e11d4:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e11d8:	mov	x21, x0
1006e11dc:	mov	x0, x28
1006e11e0:	mov	x2, x26
1006e11e4:	mov	x3, x27
1006e11e8:	mov	x4, x21
1006e11ec:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e11f0:	mov	x28, x0
1006e11f4:	mov	x0, x26
1006e11f8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e11fc:	mov	x0, x21
1006e1200:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1204:	mov	x0, x28
1006e1208:	mov	x2, x23
1006e120c:	bl	0x101ad45e0 ; selector setTarget:
1006e1210:	mov	x0, x28
1006e1214:	mov	w2, #0x5
1006e1218:	bl	0x101ad45a0 ; selector setTag:
1006e121c:	and	x2, x20, #0x1
1006e1220:	mov	x0, x28
1006e1224:	bl	0x101ad4360 ; selector setState:
1006e1228:	mov	x0, x19
1006e122c:	mov	x2, x28
1006e1230:	bl	0x101acb2c0 ; selector addItem:
1006e1234:	mov	x0, x25
1006e1238:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e123c:	mov	x0, x28
1006e1240:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1244:	adrp	x8, 5894 ; 0x101de7000
1006e1248:	add	x8, x8, #0x110 ; literal pool for: "priv.notify_on_error"
1006e124c:	sub	x8, x8, #0x20
1006e1250:	orr	x1, x8, #0x8000000000000000
1006e1254:	ldur	x0, [x29, #-0x78]
1006e1258:	bl	0x100063df0
1006e125c:	mov	x21, x0
1006e1260:	mov	x25, x1
1006e1264:	ldr	x8, [x22]
1006e1268:	ldr	x8, [x8, #0x130]
1006e126c:	mov	x20, x22
1006e1270:	blr	x8
1006e1274:	mov	x20, x0
1006e1278:	ldr	x0, [x24]
1006e127c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e1280:	mov	x26, x0
1006e1284:	mov	x0, x21
1006e1288:	mov	x1, x25
1006e128c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1290:	mov	x21, x0
1006e1294:	mov	x0, #0x0
1006e1298:	mov	x1, #-0x2000000000000000
1006e129c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e12a0:	mov	x28, x0
1006e12a4:	mov	x0, x26
1006e12a8:	mov	x2, x21
1006e12ac:	mov	x3, x27
1006e12b0:	mov	x4, x28
1006e12b4:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e12b8:	mov	x26, x0
1006e12bc:	mov	x0, x21
1006e12c0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e12c4:	mov	x0, x28
1006e12c8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e12cc:	mov	x0, x26
1006e12d0:	mov	x2, x23
1006e12d4:	bl	0x101ad45e0 ; selector setTarget:
1006e12d8:	mov	x0, x26
1006e12dc:	mov	w2, #0x6
1006e12e0:	bl	0x101ad45a0 ; selector setTag:
1006e12e4:	and	x2, x20, #0x1
1006e12e8:	mov	x0, x26
1006e12ec:	bl	0x101ad4360 ; selector setState:
1006e12f0:	mov	x0, x19
1006e12f4:	mov	x2, x26
1006e12f8:	bl	0x101acb2c0 ; selector addItem:
1006e12fc:	mov	x0, x25
1006e1300:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1304:	mov	x0, x26
1006e1308:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e130c:	adrp	x8, 5894 ; 0x101de7000
1006e1310:	add	x8, x8, #0x130 ; literal pool for: "priv.notify_on_watch_finish"
1006e1314:	sub	x8, x8, #0x20
1006e1318:	mov	x9, #0x18
1006e131c:	movk	x9, #0xd000, lsl #48
1006e1320:	add	x0, x9, #0x3
1006e1324:	orr	x1, x8, #0x8000000000000000
1006e1328:	bl	0x100063df0
1006e132c:	mov	x21, x0
1006e1330:	mov	x25, x1
1006e1334:	ldr	x8, [x22]
1006e1338:	ldr	x8, [x8, #0x148]
1006e133c:	mov	x20, x22
1006e1340:	blr	x8
1006e1344:	mov	x20, x0
1006e1348:	ldr	x0, [x24]
1006e134c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e1350:	mov	x26, x0
1006e1354:	mov	x0, x21
1006e1358:	mov	x1, x25
1006e135c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1360:	mov	x21, x0
1006e1364:	mov	x0, #0x0
1006e1368:	mov	x1, #-0x2000000000000000
1006e136c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1370:	mov	x28, x0
1006e1374:	mov	x0, x26
1006e1378:	mov	x2, x21
1006e137c:	mov	x3, x27
1006e1380:	mov	x4, x28
1006e1384:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e1388:	mov	x26, x0
1006e138c:	mov	x0, x21
1006e1390:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1394:	mov	x0, x28
1006e1398:	mov	x21, #0x18
1006e139c:	movk	x21, #0xd000, lsl #48
1006e13a0:	mov	x28, x27
1006e13a4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e13a8:	mov	x0, x26
1006e13ac:	mov	x2, x23
1006e13b0:	bl	0x101ad45e0 ; selector setTarget:
1006e13b4:	mov	x0, x26
1006e13b8:	mov	w2, #0x7
1006e13bc:	bl	0x101ad45a0 ; selector setTag:
1006e13c0:	and	x2, x20, #0x1
1006e13c4:	mov	x0, x26
1006e13c8:	bl	0x101ad4360 ; selector setState:
1006e13cc:	mov	x0, x19
1006e13d0:	mov	x2, x26
1006e13d4:	bl	0x101acb2c0 ; selector addItem:
1006e13d8:	mov	x0, x25
1006e13dc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e13e0:	mov	x0, x26
1006e13e4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e13e8:	adrp	x8, 5894 ; 0x101de7000
1006e13ec:	add	x8, x8, #0x150 ; literal pool for: "priv.allow_app_notifications"
1006e13f0:	sub	x8, x8, #0x20
1006e13f4:	add	x0, x21, #0x4
1006e13f8:	orr	x1, x8, #0x8000000000000000
1006e13fc:	bl	0x100063df0
1006e1400:	mov	x21, x0
1006e1404:	mov	x25, x1
1006e1408:	ldr	x8, [x22]
1006e140c:	ldr	x8, [x8, #0x160]
1006e1410:	mov	x20, x22
1006e1414:	blr	x8
1006e1418:	mov	x20, x0
1006e141c:	ldr	x0, [x24]
1006e1420:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e1424:	mov	x26, x0
1006e1428:	mov	x0, x21
1006e142c:	mov	x1, x25
1006e1430:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1434:	mov	x21, x0
1006e1438:	mov	x0, #0x0
1006e143c:	mov	x1, #-0x2000000000000000
1006e1440:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1444:	mov	x27, x0
1006e1448:	mov	x0, x26
1006e144c:	mov	x2, x21
1006e1450:	mov	x3, x28
1006e1454:	mov	x4, x27
1006e1458:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e145c:	mov	x26, x0
1006e1460:	mov	x0, x21
1006e1464:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1468:	mov	x0, x27
1006e146c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1470:	mov	x0, x26
1006e1474:	mov	x24, x23
1006e1478:	mov	x2, x23
1006e147c:	bl	0x101ad45e0 ; selector setTarget:
1006e1480:	mov	x0, x26
1006e1484:	mov	w2, #0x8
1006e1488:	bl	0x101ad45a0 ; selector setTag:
1006e148c:	and	x2, x20, #0x1
1006e1490:	mov	x0, x26
1006e1494:	bl	0x101ad4360 ; selector setState:
1006e1498:	mov	x0, x19
1006e149c:	mov	x2, x26
1006e14a0:	bl	0x101acb2c0 ; selector addItem:
1006e14a4:	mov	x0, x25
1006e14a8:	ldr	x25, [sp, #0x80]
1006e14ac:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e14b0:	mov	x0, x26
1006e14b4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e14b8:	adrp	x26, 7237 ; 0x102326000
1006e14bc:	cbz	x25, 0x1006e166c
1006e14c0:	adrp	x8, 5894 ; 0x101de7000
1006e14c4:	add	x8, x8, #0x170 ; literal pool for: "priv.notify_agent_task_complete"
1006e14c8:	sub	x8, x8, #0x20
1006e14cc:	mov	x9, #0x18
1006e14d0:	movk	x9, #0xd000, lsl #48
1006e14d4:	add	x0, x9, #0x7
1006e14d8:	orr	x1, x8, #0x8000000000000000
1006e14dc:	bl	0x100063df0
1006e14e0:	mov	x21, x0
1006e14e4:	mov	x25, x1
1006e14e8:	ldr	x8, [x22]
1006e14ec:	ldr	x8, [x8, #0x1f0]
1006e14f0:	mov	x20, x22
1006e14f4:	blr	x8
1006e14f8:	mov	x20, x0
1006e14fc:	ldr	x0, [x26, #0xac8]
1006e1500:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e1504:	mov	x26, x0
1006e1508:	mov	x0, x21
1006e150c:	mov	x1, x25
1006e1510:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1514:	mov	x21, x0
1006e1518:	mov	x0, #0x0
1006e151c:	mov	x1, #-0x2000000000000000
1006e1520:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1524:	mov	x27, x0
1006e1528:	mov	x0, x26
1006e152c:	mov	x2, x21
1006e1530:	mov	x3, x28
1006e1534:	mov	x4, x27
1006e1538:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e153c:	mov	x26, x0
1006e1540:	mov	x0, x21
1006e1544:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1548:	mov	x0, x27
1006e154c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1550:	mov	x0, x26
1006e1554:	mov	x2, x24
1006e1558:	bl	0x101ad45e0 ; selector setTarget:
1006e155c:	mov	x0, x26
1006e1560:	mov	w2, #0x9
1006e1564:	bl	0x101ad45a0 ; selector setTag:
1006e1568:	and	x2, x20, #0x1
1006e156c:	mov	x0, x26
1006e1570:	bl	0x101ad4360 ; selector setState:
1006e1574:	mov	x0, x19
1006e1578:	mov	x2, x26
1006e157c:	bl	0x101acb2c0 ; selector addItem:
1006e1580:	mov	x0, x25
1006e1584:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1588:	mov	x0, x26
1006e158c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1590:	adrp	x8, 5894 ; 0x101de7000
1006e1594:	add	x8, x8, #0x190 ; literal pool for: "priv.notify_agent_awaiting_input"
1006e1598:	sub	x8, x8, #0x20
1006e159c:	mov	x9, #0x18
1006e15a0:	movk	x9, #0xd000, lsl #48
1006e15a4:	add	x0, x9, #0x8
1006e15a8:	orr	x1, x8, #0x8000000000000000
1006e15ac:	bl	0x100063df0
1006e15b0:	mov	x21, x0
1006e15b4:	mov	x25, x1
1006e15b8:	ldr	x8, [x22]
1006e15bc:	ldr	x8, [x8, #0x208]
1006e15c0:	mov	x20, x22
1006e15c4:	blr	x8
1006e15c8:	mov	x20, x0
1006e15cc:	adrp	x8, 7237 ; 0x102326000
1006e15d0:	ldr	x0, [x8, #0xac8] ; Objc class ref: _OBJC_CLASS_$_NSMenuItem
1006e15d4:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e15d8:	mov	x26, x0
1006e15dc:	mov	x0, x21
1006e15e0:	mov	x1, x25
1006e15e4:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e15e8:	mov	x21, x0
1006e15ec:	mov	x0, #0x0
1006e15f0:	mov	x1, #-0x2000000000000000
1006e15f4:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e15f8:	mov	x27, x0
1006e15fc:	mov	x0, x26
1006e1600:	mov	x2, x21
1006e1604:	mov	x3, x28
1006e1608:	mov	x4, x27
1006e160c:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e1610:	mov	x26, x0
1006e1614:	mov	x0, x21
1006e1618:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e161c:	mov	x0, x27
1006e1620:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1624:	mov	x0, x26
1006e1628:	mov	x2, x24
1006e162c:	bl	0x101ad45e0 ; selector setTarget:
1006e1630:	mov	x0, x26
1006e1634:	mov	w2, #0xa
1006e1638:	bl	0x101ad45a0 ; selector setTag:
1006e163c:	and	x2, x20, #0x1
1006e1640:	mov	x0, x26
1006e1644:	bl	0x101ad4360 ; selector setState:
1006e1648:	mov	x0, x19
1006e164c:	mov	x2, x26
1006e1650:	bl	0x101acb2c0 ; selector addItem:
1006e1654:	mov	x0, x25
1006e1658:	ldr	x25, [sp, #0x80]
1006e165c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1660:	mov	x0, x26
1006e1664:	adrp	x26, 7237 ; 0x102326000
1006e1668:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e166c:	ldur	x0, [x29, #-0x60]
1006e1670:	bl	0x101ad1620 ; selector separatorItem
1006e1674:	mov	x29, x29
1006e1678:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006e167c:	mov	x20, x0
1006e1680:	mov	x0, x19
1006e1684:	mov	x2, x20
1006e1688:	bl	0x101acb2c0 ; selector addItem:
1006e168c:	mov	x0, x20
1006e1690:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1694:	adrp	x8, 5894 ; 0x101de7000
1006e1698:	add	x8, x8, #0x1c0 ; literal pool for: "priv.section_tab_badge"
1006e169c:	sub	x8, x8, #0x20
1006e16a0:	mov	x23, #0x18
1006e16a4:	movk	x23, #0xd000, lsl #48
1006e16a8:	sub	x0, x23, #0x2
1006e16ac:	orr	x1, x8, #0x8000000000000000
1006e16b0:	bl	0x100063df0
1006e16b4:	mov	x21, x1
1006e16b8:	ldur	x20, [x29, #-0x70]
1006e16bc:	bl	0x101ac6c10 ; symbol stub for: _$sSo10NSMenuItemC6AppKitE13sectionHeader5titleABSS_tFZ
1006e16c0:	mov	x20, x0
1006e16c4:	mov	x0, x21
1006e16c8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e16cc:	mov	x0, x19
1006e16d0:	mov	x2, x20
1006e16d4:	bl	0x101acb2c0 ; selector addItem:
1006e16d8:	mov	x0, x20
1006e16dc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e16e0:	sub	x21, x23, #0x1
1006e16e4:	str	x21, [sp, #0x80]
1006e16e8:	str	x28, [sp, #0x58]
1006e16ec:	cbz	x25, 0x1006e18e0
1006e16f0:	adrp	x8, 5894 ; 0x101de7000
1006e16f4:	add	x8, x8, #0x1e0 ; literal pool for: "priv.while_processing"
1006e16f8:	sub	x8, x8, #0x20
1006e16fc:	orr	x1, x8, #0x8000000000000000
1006e1700:	ldr	x0, [sp, #0x50]
1006e1704:	bl	0x100063df0
1006e1708:	mov	x25, x0
1006e170c:	mov	x21, x1
1006e1710:	ldr	x8, [x22]
1006e1714:	ldr	x8, [x8, #0x1a8]
1006e1718:	mov	x20, x22
1006e171c:	blr	x8
1006e1720:	mov	x23, x0
1006e1724:	ldr	x0, [x26, #0xac8]
1006e1728:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e172c:	mov	x20, x28
1006e1730:	mov	x28, x26
1006e1734:	mov	x26, x0
1006e1738:	mov	x0, x25
1006e173c:	mov	x1, x21
1006e1740:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1744:	mov	x25, x0
1006e1748:	mov	x0, #0x0
1006e174c:	mov	x1, #-0x2000000000000000
1006e1750:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1754:	mov	x27, x0
1006e1758:	mov	x0, x26
1006e175c:	mov	x2, x25
1006e1760:	mov	x3, x20
1006e1764:	mov	x4, x27
1006e1768:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e176c:	mov	x26, x0
1006e1770:	mov	x0, x25
1006e1774:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1778:	mov	x0, x27
1006e177c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1780:	mov	x0, x26
1006e1784:	ldur	x24, [x29, #-0x68]
1006e1788:	mov	x2, x24
1006e178c:	bl	0x101ad45e0 ; selector setTarget:
1006e1790:	mov	x0, x26
1006e1794:	mov	w2, #0xb
1006e1798:	bl	0x101ad45a0 ; selector setTag:
1006e179c:	and	x2, x23, #0x1
1006e17a0:	mov	x0, x26
1006e17a4:	bl	0x101ad4360 ; selector setState:
1006e17a8:	mov	x0, x19
1006e17ac:	mov	x2, x26
1006e17b0:	bl	0x101acb2c0 ; selector addItem:
1006e17b4:	mov	x0, x21
1006e17b8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e17bc:	mov	x0, x26
1006e17c0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e17c4:	adrp	x8, 5894 ; 0x101de7000
1006e17c8:	add	x8, x8, #0x220 ; literal pool for: "priv.when_awaiting_input"
1006e17cc:	sub	x10, x8, #0x20
1006e17d0:	adrp	x8, 5894 ; 0x101de7000
1006e17d4:	add	x8, x8, #0x200 ; literal pool for: "priv.when_task_completes"
1006e17d8:	adrp	x9, 5894 ; 0x101de7000
1006e17dc:	add	x9, x9, #0x260 ; literal pool for: "priv.prevent_sleep_while_processing"
1006e17e0:	sub	x8, x8, #0x20
1006e17e4:	sub	x11, x9, #0x20
1006e17e8:	mov	x9, #0x18
1006e17ec:	movk	x9, #0xd000, lsl #48
1006e17f0:	add	x9, x9, #0xb
1006e17f4:	stp	x22, x9, [sp, #0x28]
1006e17f8:	mov	w9, #0xd
1006e17fc:	str	x9, [sp, #0x50]
1006e1800:	mov	w9, #0x1d8
1006e1804:	stp	x9, x10, [sp, #0x18]
1006e1808:	mov	w9, #0xc
1006e180c:	str	x9, [sp, #0x10]
1006e1810:	mov	w27, #0x1c0
1006e1814:	mov	w9, #0x220
1006e1818:	stp	x9, x11, [sp, #0x38]
1006e181c:	mov	w9, #0x10
1006e1820:	str	x9, [sp, #0x48]
1006e1824:	mov	x20, x22
1006e1828:	mov	x0, #0x18
1006e182c:	movk	x0, #0xd000, lsl #48
1006e1830:	mov	x9, #0x18
1006e1834:	movk	x9, #0xd000, lsl #48
1006e1838:	str	x9, [sp, #0x8]
1006e183c:	mov	x23, x24
1006e1840:	b	0x1006e195c
1006e1844:	adrp	x8, 5894 ; 0x101de7000
1006e1848:	add	x8, x8, #0x30 ; literal pool for: "menu.no_active_tab"
1006e184c:	sub	x8, x8, #0x20
1006e1850:	sub	x0, x22, #0x6
1006e1854:	orr	x1, x8, #0x8000000000000000
1006e1858:	bl	0x100063df0
1006e185c:	mov	x20, x0
1006e1860:	mov	x21, x1
1006e1864:	adrp	x8, 7237 ; 0x102326000
1006e1868:	ldr	x0, [x8, #0xac8] ; Objc class ref: _OBJC_CLASS_$_NSMenuItem
1006e186c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e1870:	mov	x22, x0
1006e1874:	mov	x0, x20
1006e1878:	mov	x1, x21
1006e187c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1880:	mov	x20, x0
1006e1884:	mov	x0, x21
1006e1888:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e188c:	mov	x0, #0x0
1006e1890:	mov	x1, #-0x2000000000000000
1006e1894:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1898:	mov	x23, x0
1006e189c:	mov	x0, x22
1006e18a0:	mov	x2, x20
1006e18a4:	mov	x3, #0x0
1006e18a8:	mov	x4, x23
1006e18ac:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e18b0:	mov	x21, x0
1006e18b4:	mov	x0, x20
1006e18b8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e18bc:	mov	x0, x23
1006e18c0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e18c4:	mov	x0, x21
1006e18c8:	mov	w2, #0x0
1006e18cc:	bl	0x101ad2920 ; selector setEnabled:
1006e18d0:	mov	x0, x19
1006e18d4:	mov	x2, x21
1006e18d8:	bl	0x101acb2c0 ; selector addItem:
1006e18dc:	b	0x1006e1ff4
1006e18e0:	adrp	x8, 5894 ; 0x101de7000
1006e18e4:	add	x8, x8, #0x370 ; literal pool for: "priv.when_command_fails"
1006e18e8:	sub	x10, x8, #0x20
1006e18ec:	adrp	x8, 5894 ; 0x101de7000
1006e18f0:	add	x8, x8, #0x350 ; literal pool for: "priv.when_command_finishes"
1006e18f4:	adrp	x9, 5894 ; 0x101de7000
1006e18f8:	add	x9, x9, #0x330 ; literal pool for: "priv.keep_awake_task"
1006e18fc:	sub	x8, x8, #0x20
1006e1900:	sub	x11, x9, #0x20
1006e1904:	mov	x9, #0x18
1006e1908:	movk	x9, #0xd000, lsl #48
1006e190c:	add	x0, x9, #0x2
1006e1910:	mov	w9, #0xf
1006e1914:	str	x9, [sp, #0x50]
1006e1918:	mov	w9, #0x190
1006e191c:	stp	x9, x10, [sp, #0x18]
1006e1920:	mov	w9, #0xe
1006e1924:	str	x9, [sp, #0x10]
1006e1928:	mov	w27, #0x178
1006e192c:	mov	w9, #0x500
1006e1930:	stp	x9, x11, [sp, #0x38]
1006e1934:	mov	w9, #0x11
1006e1938:	str	x9, [sp, #0x48]
1006e193c:	ldr	x9, [sp, #0x70]
1006e1940:	str	x9, [sp, #0x28]
1006e1944:	ldur	x9, [x29, #-0x78]
1006e1948:	str	x9, [sp, #0x30]
1006e194c:	str	x21, [sp, #0x8]
1006e1950:	ldur	x23, [x29, #-0x68]
1006e1954:	mov	x28, x26
1006e1958:	mov	x20, x22
1006e195c:	orr	x1, x8, #0x8000000000000000
1006e1960:	bl	0x100063df0
1006e1964:	mov	x25, x0
1006e1968:	mov	x26, x1
1006e196c:	ldr	x8, [x20]
1006e1970:	ldr	x8, [x8, x27]
1006e1974:	blr	x8
1006e1978:	mov	x21, x0
1006e197c:	ldr	x0, [x28, #0xac8]
1006e1980:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e1984:	mov	x24, x0
1006e1988:	mov	x0, x25
1006e198c:	mov	x1, x26
1006e1990:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1994:	mov	x25, x0
1006e1998:	mov	x0, #0x0
1006e199c:	mov	x1, #-0x2000000000000000
1006e19a0:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e19a4:	mov	x22, x0
1006e19a8:	mov	x0, x24
1006e19ac:	mov	x2, x25
1006e19b0:	ldr	x27, [sp, #0x58]
1006e19b4:	mov	x3, x27
1006e19b8:	mov	x4, x22
1006e19bc:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e19c0:	mov	x24, x0
1006e19c4:	mov	x0, x25
1006e19c8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e19cc:	mov	x0, x22
1006e19d0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e19d4:	mov	x0, x24
1006e19d8:	mov	x2, x23
1006e19dc:	bl	0x101ad45e0 ; selector setTarget:
1006e19e0:	mov	x0, x24
1006e19e4:	ldr	x2, [sp, #0x10]
1006e19e8:	bl	0x101ad45a0 ; selector setTag:
1006e19ec:	and	x2, x21, #0x1
1006e19f0:	mov	x0, x24
1006e19f4:	bl	0x101ad4360 ; selector setState:
1006e19f8:	mov	x0, x19
1006e19fc:	mov	x2, x24
1006e1a00:	bl	0x101acb2c0 ; selector addItem:
1006e1a04:	mov	x0, x26
1006e1a08:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1a0c:	mov	x0, x24
1006e1a10:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1a14:	ldr	x8, [sp, #0x20]
1006e1a18:	orr	x1, x8, #0x8000000000000000
1006e1a1c:	ldr	x0, [sp, #0x8]
1006e1a20:	bl	0x100063df0
1006e1a24:	mov	x22, x0
1006e1a28:	mov	x21, x1
1006e1a2c:	str	x20, [sp, #0x78]
1006e1a30:	ldr	x8, [x20]
1006e1a34:	ldr	x9, [sp, #0x18]
1006e1a38:	ldr	x8, [x8, x9]
1006e1a3c:	blr	x8
1006e1a40:	mov	x20, x0
1006e1a44:	ldr	x0, [x28, #0xac8]
1006e1a48:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e1a4c:	mov	x24, x0
1006e1a50:	mov	x0, x22
1006e1a54:	mov	x1, x21
1006e1a58:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1a5c:	mov	x22, x0
1006e1a60:	mov	x0, #0x0
1006e1a64:	mov	x1, #-0x2000000000000000
1006e1a68:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1a6c:	mov	x25, x0
1006e1a70:	mov	x0, x24
1006e1a74:	mov	x2, x22
1006e1a78:	mov	x3, x27
1006e1a7c:	mov	x4, x25
1006e1a80:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e1a84:	mov	x24, x0
1006e1a88:	mov	x0, x22
1006e1a8c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1a90:	mov	x0, x25
1006e1a94:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1a98:	mov	x0, x24
1006e1a9c:	mov	x2, x23
1006e1aa0:	bl	0x101ad45e0 ; selector setTarget:
1006e1aa4:	mov	x0, x24
1006e1aa8:	ldr	x2, [sp, #0x50]
1006e1aac:	bl	0x101ad45a0 ; selector setTag:
1006e1ab0:	and	x2, x20, #0x1
1006e1ab4:	mov	x0, x24
1006e1ab8:	bl	0x101ad4360 ; selector setState:
1006e1abc:	mov	x0, x19
1006e1ac0:	mov	x2, x24
1006e1ac4:	bl	0x101acb2c0 ; selector addItem:
1006e1ac8:	mov	x0, x21
1006e1acc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1ad0:	mov	x0, x24
1006e1ad4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1ad8:	ldur	x23, [x29, #-0x60]
1006e1adc:	mov	x0, x23
1006e1ae0:	bl	0x101ad1620 ; selector separatorItem
1006e1ae4:	mov	x29, x29
1006e1ae8:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006e1aec:	mov	x20, x0
1006e1af0:	mov	x0, x19
1006e1af4:	mov	x2, x20
1006e1af8:	bl	0x101acb2c0 ; selector addItem:
1006e1afc:	mov	x0, x20
1006e1b00:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1b04:	adrp	x8, 5894 ; 0x101de7000
1006e1b08:	add	x8, x8, #0x240 ; literal pool for: "priv.section_caffeinate"
1006e1b0c:	sub	x8, x8, #0x20
1006e1b10:	str	x8, [sp, #0x50]
1006e1b14:	orr	x1, x8, #0x8000000000000000
1006e1b18:	ldr	x0, [sp, #0x80]
1006e1b1c:	bl	0x100063df0
1006e1b20:	mov	x21, x1
1006e1b24:	ldur	x26, [x29, #-0x70]
1006e1b28:	mov	x20, x26
1006e1b2c:	bl	0x101ac6c10 ; symbol stub for: _$sSo10NSMenuItemC6AppKitE13sectionHeader5titleABSS_tFZ
1006e1b30:	mov	x20, x0
1006e1b34:	mov	x0, x21
1006e1b38:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1b3c:	mov	x0, x19
1006e1b40:	mov	x2, x20
1006e1b44:	bl	0x101acb2c0 ; selector addItem:
1006e1b48:	mov	x0, x20
1006e1b4c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1b50:	ldr	x8, [sp, #0x40]
1006e1b54:	orr	x1, x8, #0x8000000000000000
1006e1b58:	ldr	x0, [sp, #0x30]
1006e1b5c:	bl	0x100063df0
1006e1b60:	mov	x22, x0
1006e1b64:	mov	x21, x1
1006e1b68:	ldr	x20, [sp, #0x28]
1006e1b6c:	ldr	x8, [x20]
1006e1b70:	ldr	x9, [sp, #0x38]
1006e1b74:	ldr	x8, [x8, x9]
1006e1b78:	blr	x8
1006e1b7c:	mov	x20, x0
1006e1b80:	ldr	x0, [x28, #0xac8]
1006e1b84:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e1b88:	mov	x24, x0
1006e1b8c:	mov	x0, x22
1006e1b90:	mov	x1, x21
1006e1b94:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1b98:	mov	x22, x0
1006e1b9c:	mov	x0, #0x0
1006e1ba0:	mov	x1, #-0x2000000000000000
1006e1ba4:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1ba8:	mov	x25, x0
1006e1bac:	mov	x0, x24
1006e1bb0:	mov	x2, x22
1006e1bb4:	mov	x3, x27
1006e1bb8:	mov	x28, x27
1006e1bbc:	mov	x4, x25
1006e1bc0:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e1bc4:	mov	x24, x0
1006e1bc8:	mov	x0, x22
1006e1bcc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1bd0:	mov	x0, x25
1006e1bd4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1bd8:	mov	x0, x24
1006e1bdc:	ldur	x27, [x29, #-0x68]
1006e1be0:	mov	x2, x27
1006e1be4:	bl	0x101ad45e0 ; selector setTarget:
1006e1be8:	mov	x0, x24
1006e1bec:	ldr	x2, [sp, #0x48]
1006e1bf0:	bl	0x101ad45a0 ; selector setTag:
1006e1bf4:	and	x2, x20, #0x1
1006e1bf8:	mov	x0, x24
1006e1bfc:	bl	0x101ad4360 ; selector setState:
1006e1c00:	mov	x0, x19
1006e1c04:	mov	x2, x24
1006e1c08:	bl	0x101acb2c0 ; selector addItem:
1006e1c0c:	mov	x0, x21
1006e1c10:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1c14:	mov	x0, x24
1006e1c18:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1c1c:	mov	x0, x23
1006e1c20:	bl	0x101ad1620 ; selector separatorItem
1006e1c24:	mov	x29, x29
1006e1c28:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006e1c2c:	mov	x20, x0
1006e1c30:	mov	x0, x19
1006e1c34:	mov	x2, x20
1006e1c38:	bl	0x101acb2c0 ; selector addItem:
1006e1c3c:	mov	x0, x20
1006e1c40:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1c44:	adrp	x8, 5894 ; 0x101de7000
1006e1c48:	add	x8, x8, #0x290 ; literal pool for: "priv.section_mouse"
1006e1c4c:	sub	x8, x8, #0x20
1006e1c50:	orr	x1, x8, #0x8000000000000000
1006e1c54:	ldr	x0, [sp, #0x68]
1006e1c58:	bl	0x100063df0
1006e1c5c:	mov	x21, x1
1006e1c60:	mov	x20, x26
1006e1c64:	bl	0x101ac6c10 ; symbol stub for: _$sSo10NSMenuItemC6AppKitE13sectionHeader5titleABSS_tFZ
1006e1c68:	mov	x20, x0
1006e1c6c:	mov	x0, x21
1006e1c70:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1c74:	mov	x0, x19
1006e1c78:	mov	x2, x20
1006e1c7c:	bl	0x101acb2c0 ; selector addItem:
1006e1c80:	mov	x0, x20
1006e1c84:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1c88:	adrp	x8, 5894 ; 0x101de7000
1006e1c8c:	add	x8, x8, #0x2b0 ; literal pool for: "priv.allow_mouse_capture"
1006e1c90:	sub	x8, x8, #0x20
1006e1c94:	orr	x1, x8, #0x8000000000000000
1006e1c98:	mov	x0, #0x18
1006e1c9c:	movk	x0, #0xd000, lsl #48
1006e1ca0:	bl	0x100063df0
1006e1ca4:	mov	x22, x0
1006e1ca8:	mov	x21, x1
1006e1cac:	ldr	x20, [sp, #0x78]
1006e1cb0:	ldr	x8, [x20]
1006e1cb4:	ldr	x8, [x8, #0x250]
1006e1cb8:	blr	x8
1006e1cbc:	mov	x20, x0
1006e1cc0:	adrp	x23, 7237 ; 0x102326000
1006e1cc4:	ldr	x0, [x23, #0xac8] ; Objc class ref: _OBJC_CLASS_$_NSMenuItem
1006e1cc8:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e1ccc:	mov	x24, x0
1006e1cd0:	mov	x0, x22
1006e1cd4:	mov	x1, x21
1006e1cd8:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1cdc:	mov	x22, x0
1006e1ce0:	mov	x0, #0x0
1006e1ce4:	mov	x1, #-0x2000000000000000
1006e1ce8:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1cec:	mov	x25, x0
1006e1cf0:	mov	x0, x24
1006e1cf4:	mov	x2, x22
1006e1cf8:	mov	x3, x28
1006e1cfc:	mov	x4, x25
1006e1d00:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e1d04:	mov	x24, x0
1006e1d08:	mov	x0, x22
1006e1d0c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1d10:	mov	x0, x25
1006e1d14:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1d18:	mov	x0, x24
1006e1d1c:	mov	x2, x27
1006e1d20:	bl	0x101ad45e0 ; selector setTarget:
1006e1d24:	mov	x0, x24
1006e1d28:	mov	w2, #0x14
1006e1d2c:	bl	0x101ad45a0 ; selector setTag:
1006e1d30:	and	x2, x20, #0x1
1006e1d34:	mov	x0, x24
1006e1d38:	bl	0x101ad4360 ; selector setState:
1006e1d3c:	mov	x0, x19
1006e1d40:	mov	x2, x24
1006e1d44:	bl	0x101acb2c0 ; selector addItem:
1006e1d48:	mov	x0, x21
1006e1d4c:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1d50:	mov	x0, x24
1006e1d54:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1d58:	ldur	x0, [x29, #-0x60]
1006e1d5c:	bl	0x101ad1620 ; selector separatorItem
1006e1d60:	mov	x29, x29
1006e1d64:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006e1d68:	mov	x20, x0
1006e1d6c:	mov	x0, x19
1006e1d70:	mov	x2, x20
1006e1d74:	bl	0x101acb2c0 ; selector addItem:
1006e1d78:	mov	x0, x20
1006e1d7c:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1d80:	adrp	x8, 5894 ; 0x101de7000
1006e1d84:	add	x8, x8, #0x2d0 ; literal pool for: "priv.group_all_panes"
1006e1d88:	sub	x8, x8, #0x20
1006e1d8c:	orr	x1, x8, #0x8000000000000000
1006e1d90:	ldur	x0, [x29, #-0x78]
1006e1d94:	bl	0x100063df0
1006e1d98:	mov	x20, x1
1006e1d9c:	bl	0x1006e41bc
1006e1da0:	mov	x21, x0
1006e1da4:	mov	x0, x20
1006e1da8:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1dac:	mov	x0, x19
1006e1db0:	mov	x2, x21
1006e1db4:	bl	0x101acb2c0 ; selector addItem:
1006e1db8:	mov	x0, x21
1006e1dbc:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1dc0:	mov	x22, #0x18
1006e1dc4:	movk	x22, #0xd000, lsl #48
1006e1dc8:	add	x0, x22, #0x1
1006e1dcc:	ldr	x8, [sp, #0x60]
1006e1dd0:	orr	x1, x8, #0x8000000000000000
1006e1dd4:	bl	0x100063df0
1006e1dd8:	mov	x21, x1
1006e1ddc:	mov	x20, x26
1006e1de0:	bl	0x101ac6c10 ; symbol stub for: _$sSo10NSMenuItemC6AppKitE13sectionHeader5titleABSS_tFZ
1006e1de4:	mov	x20, x0
1006e1de8:	mov	x0, x21
1006e1dec:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1df0:	mov	x0, x19
1006e1df4:	mov	x2, x20
1006e1df8:	bl	0x101acb2c0 ; selector addItem:
1006e1dfc:	mov	x0, x20
1006e1e00:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1e04:	adrp	x8, 5894 ; 0x101de7000
1006e1e08:	add	x8, x8, #0x2f0 ; literal pool for: "priv.notify_when_all_idle"
1006e1e0c:	sub	x8, x8, #0x20
1006e1e10:	add	x0, x22, #0x1
1006e1e14:	orr	x1, x8, #0x8000000000000000
1006e1e18:	bl	0x100063df0
1006e1e1c:	mov	x21, x0
1006e1e20:	mov	x20, x1
1006e1e24:	bl	0x10061d6d4
1006e1e28:	mov	x22, x0
1006e1e2c:	ldr	x0, [x23, #0xac8]
1006e1e30:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e1e34:	mov	x24, x0
1006e1e38:	mov	x0, x21
1006e1e3c:	mov	x1, x20
1006e1e40:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1e44:	mov	x21, x0
1006e1e48:	mov	x0, #0x0
1006e1e4c:	mov	x1, #-0x2000000000000000
1006e1e50:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1e54:	mov	x25, x0
1006e1e58:	mov	x0, x24
1006e1e5c:	mov	x2, x21
1006e1e60:	mov	x27, x28
1006e1e64:	mov	x3, x28
1006e1e68:	mov	x4, x25
1006e1e6c:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e1e70:	mov	x24, x0
1006e1e74:	mov	x0, x21
1006e1e78:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1e7c:	mov	x0, x25
1006e1e80:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1e84:	mov	x0, x24
1006e1e88:	ldur	x28, [x29, #-0x68]
1006e1e8c:	mov	x2, x28
1006e1e90:	bl	0x101ad45e0 ; selector setTarget:
1006e1e94:	mov	x0, x24
1006e1e98:	mov	w2, #0x12
1006e1e9c:	bl	0x101ad45a0 ; selector setTag:
1006e1ea0:	and	x2, x22, #0x1
1006e1ea4:	mov	x0, x24
1006e1ea8:	bl	0x101ad4360 ; selector setState:
1006e1eac:	mov	x0, x19
1006e1eb0:	mov	x2, x24
1006e1eb4:	bl	0x101acb2c0 ; selector addItem:
1006e1eb8:	mov	x0, x20
1006e1ebc:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1ec0:	mov	x0, x24
1006e1ec4:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1ec8:	ldur	x0, [x29, #-0x60]
1006e1ecc:	bl	0x101ad1620 ; selector separatorItem
1006e1ed0:	mov	x29, x29
1006e1ed4:	bl	0x101ac9d54 ; symbol stub for: _objc_retainAutoreleasedReturnValue
1006e1ed8:	mov	x20, x0
1006e1edc:	mov	x0, x19
1006e1ee0:	mov	x2, x20
1006e1ee4:	bl	0x101acb2c0 ; selector addItem:
1006e1ee8:	mov	x0, x20
1006e1eec:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1ef0:	ldr	x8, [sp, #0x50]
1006e1ef4:	orr	x1, x8, #0x8000000000000000
1006e1ef8:	ldr	x0, [sp, #0x80]
1006e1efc:	bl	0x100063df0
1006e1f00:	mov	x21, x1
1006e1f04:	mov	x20, x26
1006e1f08:	bl	0x101ac6c10 ; symbol stub for: _$sSo10NSMenuItemC6AppKitE13sectionHeader5titleABSS_tFZ
1006e1f0c:	mov	x20, x0
1006e1f10:	mov	x0, x21
1006e1f14:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1f18:	mov	x0, x19
1006e1f1c:	mov	x2, x20
1006e1f20:	bl	0x101acb2c0 ; selector addItem:
1006e1f24:	mov	x0, x20
1006e1f28:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1f2c:	adrp	x8, 5894 ; 0x101de7000
1006e1f30:	add	x8, x8, #0x310 ; literal pool for: "priv.keep_awake_any_task"
1006e1f34:	sub	x8, x8, #0x20
1006e1f38:	orr	x1, x8, #0x8000000000000000
1006e1f3c:	mov	x0, #0x18
1006e1f40:	movk	x0, #0xd000, lsl #48
1006e1f44:	bl	0x100063df0
1006e1f48:	mov	x21, x0
1006e1f4c:	mov	x20, x1
1006e1f50:	bl	0x10061d8dc
1006e1f54:	mov	x22, x0
1006e1f58:	ldr	x0, [x23, #0xac8]
1006e1f5c:	bl	0x101ac9cb8 ; symbol stub for: _objc_allocWithZone
1006e1f60:	mov	x24, x0
1006e1f64:	mov	x0, x21
1006e1f68:	mov	x1, x20
1006e1f6c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1f70:	mov	x25, x0
1006e1f74:	mov	x0, #0x0
1006e1f78:	mov	x1, #-0x2000000000000000
1006e1f7c:	bl	0x101ac6238 ; symbol stub for: _$sSS10FoundationE19_bridgeToObjectiveCSo8NSStringCyF
1006e1f80:	mov	x26, x0
1006e1f84:	mov	x0, x24
1006e1f88:	mov	x2, x25
1006e1f8c:	mov	x3, x27
1006e1f90:	mov	x4, x26
1006e1f94:	bl	0x101ace960 ; selector initWithTitle:action:keyEquivalent:
1006e1f98:	mov	x21, x0
1006e1f9c:	mov	x0, x25
1006e1fa0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1fa4:	mov	x0, x26
1006e1fa8:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e1fac:	mov	x0, x21
1006e1fb0:	mov	x2, x28
1006e1fb4:	bl	0x101ad45e0 ; selector setTarget:
1006e1fb8:	mov	x0, x21
1006e1fbc:	mov	w2, #0x13
1006e1fc0:	bl	0x101ad45a0 ; selector setTag:
1006e1fc4:	and	x2, x22, #0x1
1006e1fc8:	mov	x0, x21
1006e1fcc:	bl	0x101ad4360 ; selector setState:
1006e1fd0:	mov	x0, x19
1006e1fd4:	mov	x2, x21
1006e1fd8:	bl	0x101acb2c0 ; selector addItem:
1006e1fdc:	ldr	x0, [sp, #0x70]
1006e1fe0:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e1fe4:	ldr	x0, [sp, #0x78]
1006e1fe8:	bl	0x101aca960 ; symbol stub for: _swift_release
1006e1fec:	mov	x0, x20
1006e1ff0:	bl	0x101aca60c ; symbol stub for: _swift_bridgeObjectRelease
1006e1ff4:	mov	x0, x21
1006e1ff8:	ldp	x29, x30, [sp, #0x100]
1006e1ffc:	ldp	x20, x19, [sp, #0xf0]
1006e2000:	ldp	x22, x21, [sp, #0xe0]
1006e2004:	ldp	x24, x23, [sp, #0xd0]
1006e2008:	ldp	x26, x25, [sp, #0xc0]
1006e200c:	ldp	x28, x27, [sp, #0xb0]
1006e2010:	add	sp, sp, #0x110
1006e2014:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e2018:	stp	x22, x21, [sp, #-0x30]!
1006e201c:	stp	x20, x19, [sp, #0x10]
1006e2020:	stp	x29, x30, [sp, #0x20]
1006e2024:	add	x29, sp, #0x20
1006e2028:	mov	x19, x0
1006e202c:	mov	x0, x2
1006e2030:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e2034:	mov	x21, x0
1006e2038:	mov	x0, x19
1006e203c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e2040:	mov	x20, x0
1006e2044:	mov	x0, x21
1006e2048:	bl	0x1006e0c64
1006e204c:	mov	x0, x21
1006e2050:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e2054:	mov	x0, x20
1006e2058:	ldp	x29, x30, [sp, #0x20]
1006e205c:	ldp	x20, x19, [sp, #0x10]
1006e2060:	ldp	x22, x21, [sp], #0x30
1006e2064:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e2068:	b	0x1006e46fc
1006e206c:	stp	x20, x19, [sp, #-0x20]!
1006e2070:	stp	x29, x30, [sp, #0x10]
1006e2074:	add	x29, sp, #0x10
1006e2078:	mov	x19, x0
1006e207c:	mov	x0, x2
1006e2080:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e2084:	mov	x20, x0
1006e2088:	mov	x0, x19
1006e208c:	bl	0x101ac9d3c ; symbol stub for: _objc_retain
1006e2090:	mov	x19, x0
1006e2094:	mov	x0, x20
1006e2098:	bl	0x1006e46fc
1006e209c:	mov	x0, x20
1006e20a0:	bl	0x101ac9d30 ; symbol stub for: _objc_release
1006e20a4:	mov	x0, x19
1006e20a8:	ldp	x29, x30, [sp, #0x10]
1006e20ac:	ldp	x20, x19, [sp], #0x20
1006e20b0:	b	0x101ac9d30 ; symbol stub for: _objc_release
1006e20b4:	adrp	x0, 2 ; 0x1006e4000
1006e20b8:	add	x0, x0, #0xed0
1006e20bc:	b	0x1006e2e08
1006e20c0:	adrp	x2, 2 ; 0x1006e4000
1006e20c4:	add	x2, x2, #0xed0
1006e20c8:	b	0x1006e2e44
1006e20cc:	adrp	x0, 2 ; 0x1006e4000
1006e20d0:	add	x0, x0, #0xed0
1006e20d4:	b	0x10019a3f0
