
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101432d54 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE>:
101432d54: d10383ff    	sub	sp, sp, #0xe0
101432d58: a9086ffc    	stp	x28, x27, [sp, #0x80]
101432d5c: a90967fa    	stp	x26, x25, [sp, #0x90]
101432d60: a90a5ff8    	stp	x24, x23, [sp, #0xa0]
101432d64: a90b57f6    	stp	x22, x21, [sp, #0xb0]
101432d68: a90c4ff4    	stp	x20, x19, [sp, #0xc0]
101432d6c: a90d7bfd    	stp	x29, x30, [sp, #0xd0]
101432d70: 910343fd    	add	x29, sp, #0xd0
101432d74: aa0103f4    	mov	x20, x1
101432d78: aa0003f5    	mov	x21, x0
101432d7c: 52800013    	mov	w19, #0x0               ; =0
101432d80: d2800017    	mov	x23, #0x0               ; =0
101432d84: 910003e8    	mov	x8, sp
101432d88: 91004118    	add	x24, x8, #0x10
101432d8c: d0003da8    	adrp	x8, 0x101be8000 <__ZN10serde_yaml5value5index87_$LT$impl$u20$core..ops..index..Index$LT$I$GT$$u20$for$u20$serde_yaml..value..Value$GT$5index4NULL17hd677ace243696f4dE+0x9070>
101432d90: 3dc2bd00    	ldr	q0, [x8, #0xaf0]
101432d94: 3d8007e0    	str	q0, [sp, #0x10]
101432d98: 52800208    	mov	w8, #0x10               ; =16
101432d9c: b90023e8    	str	w8, [sp, #0x20]
101432da0: 910163f6    	add	x22, sp, #0x58
101432da4: 9100c3fb    	add	x27, sp, #0x30
101432da8: d2f0001c    	mov	x28, #-0x8000000000000000 ; =-9223372036854775808
101432dac: aa1703f9    	mov	x25, x23
101432db0: 91000737    	add	x23, x25, #0x1
101432db4: b8797b1a    	ldr	w26, [x24, x25, lsl #2]
101432db8: 6a14035f    	tst	w26, w20
101432dbc: 540000a1    	b.ne	0x101432dd0 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x7c>
101432dc0: aa1703f9    	mov	x25, x23
101432dc4: f10016ff    	cmp	x23, #0x5
101432dc8: 54ffff41    	b.ne	0x101432db0 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x5c>
101432dcc: 14000062    	b	0x101432f54 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x200>
101432dd0: 71000f5f    	cmp	w26, #0x3
101432dd4: 540004ad    	b.le	0x101432e68 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x114>
101432dd8: 7100135f    	cmp	w26, #0x4
101432ddc: 540007a0    	b.eq	0x101432ed0 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x17c>
101432de0: 7100235f    	cmp	w26, #0x8
101432de4: 54000820    	b.eq	0x101432ee8 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x194>
101432de8: 7100435f    	cmp	w26, #0x10
101432dec: 54000841    	b.ne	0x101432ef4 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x1a0>
101432df0: f9406ea8    	ldr	x8, [x21, #0xd8]
101432df4: eb1c011f    	cmp	x8, x28
101432df8: 54000a80    	b.eq	0x101432f48 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x1f4>
101432dfc: 910163e0    	add	x0, sp, #0x58
101432e00: 910422a1    	add	x1, x21, #0x108
101432e04: d0004562    	adrp	x2, 0x101ce0000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x5c8c>
101432e08: 912f7c42    	add	x2, x2, #0xbdf
101432e0c: 52800503    	mov	w3, #0x28               ; =40
101432e10: 94010256    	bl	0x101473768 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x63d8>
101432e14: f9402fe8    	ldr	x8, [sp, #0x58]
101432e18: d2800269    	mov	x9, #0x13               ; =19
101432e1c: f2f00009    	movk	x9, #0x8000, lsl #48
101432e20: eb09011f    	cmp	x8, x9
101432e24: 54000461    	b.ne	0x101432eb0 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x15c>
101432e28: 9105c2a0    	add	x0, x21, #0x170
101432e2c: 9401119b    	bl	0x101477498 <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0x182c>
101432e30: a94feea8    	ldp	x8, x27, [x21, #0xf8]
101432e34: f90082bf    	str	xzr, [x21, #0x100]
101432e38: b400085b    	cbz	x27, 0x101432f40 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x1ec>
101432e3c: 91002116    	add	x22, x8, #0x8
101432e40: 14000004    	b	0x101432e50 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0xfc>
101432e44: 910062d6    	add	x22, x22, #0x18
101432e48: f100077b    	subs	x27, x27, #0x1
101432e4c: 540007a0    	b.eq	0x101432f40 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x1ec>
101432e50: f85f82c1    	ldur	x1, [x22, #-0x8]
101432e54: b4ffff81    	cbz	x1, 0x101432e44 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0xf0>
101432e58: f94002c0    	ldr	x0, [x22]
101432e5c: 52800022    	mov	w2, #0x1                ; =1
101432e60: 97d9ae1f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101432e64: 17fffff8    	b	0x101432e44 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0xf0>
101432e68: 7100075f    	cmp	w26, #0x1
101432e6c: 540004a0    	b.eq	0x101432f00 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x1ac>
101432e70: 71000b5f    	cmp	w26, #0x2
101432e74: 54000401    	b.ne	0x101432ef4 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x1a0>
101432e78: f940d2a8    	ldr	x8, [x21, #0x1a0]
101432e7c: eb1c011f    	cmp	x8, x28
101432e80: 54000640    	b.eq	0x101432f48 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x1f4>
101432e84: 910163e0    	add	x0, sp, #0x58
101432e88: 910942a1    	add	x1, x21, #0x250
101432e8c: 90004582    	adrp	x2, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
101432e90: 91024c42    	add	x2, x2, #0x93
101432e94: 52800403    	mov	w3, #0x20               ; =32
101432e98: 94010234    	bl	0x101473768 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x63d8>
101432e9c: f9402fe8    	ldr	x8, [sp, #0x58]
101432ea0: d2800269    	mov	x9, #0x13               ; =19
101432ea4: f2f00009    	movk	x9, #0x8000, lsl #48
101432ea8: eb09011f    	cmp	x8, x9
101432eac: 540004e0    	b.eq	0x101432f48 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x1f4>
101432eb0: f94033e9    	ldr	x9, [sp, #0x60]
101432eb4: 3cc102c0    	ldur	q0, [x22, #0x10]
101432eb8: 3c810360    	stur	q0, [x27, #0x10]
101432ebc: f84202ca    	ldur	x10, [x22, #0x20]
101432ec0: f802036a    	stur	x10, [x27, #0x20]
101432ec4: a90327e8    	stp	x8, x9, [sp, #0x30]
101432ec8: 9100c3e0    	add	x0, sp, #0x30
101432ecc: 14000019    	b	0x101432f30 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x1dc>
101432ed0: 910dc2a0    	add	x0, x21, #0x370
101432ed4: 97ffa74d    	bl	0x10141cc08 <__ZN17otty_autocomplete10help_probe9HelpProbe21clear_all_cached_help17h0afc1fac63c803f9E>
101432ed8: 2a130353    	orr	w19, w26, w19
101432edc: f100133f    	cmp	x25, #0x4
101432ee0: 54fff661    	b.ne	0x101432dac <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x58>
101432ee4: 1400001c    	b	0x101432f54 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x200>
101432ee8: aa1503e0    	mov	x0, x21
101432eec: 94004d8d    	bl	0x101446520 <__ZN17otty_autocomplete7learned15LearnedCommands9clear_all17hddb282057904bbd6E>
101432ef0: 370002c0    	tbnz	w0, #0x0, 0x101432f48 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x1f4>
101432ef4: f100133f    	cmp	x25, #0x4
101432ef8: 54fff5a1    	b.ne	0x101432dac <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x58>
101432efc: 14000016    	b	0x101432f54 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x200>
101432f00: f940d2a8    	ldr	x8, [x21, #0x1a0]
101432f04: eb1c011f    	cmp	x8, x28
101432f08: 54000200    	b.eq	0x101432f48 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x1f4>
101432f0c: 910163e8    	add	x8, sp, #0x58
101432f10: 910682a0    	add	x0, x21, #0x1a0
101432f14: 94003383    	bl	0x10143fd20 <__ZN17otty_autocomplete7history14CommandHistory19clear_token_history17h4bcd67037a71a5ddE>
101432f18: f9402fe8    	ldr	x8, [sp, #0x58]
101432f1c: d2800269    	mov	x9, #0x13               ; =19
101432f20: f2f00009    	movk	x9, #0x8000, lsl #48
101432f24: eb09011f    	cmp	x8, x9
101432f28: 54000100    	b.eq	0x101432f48 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x1f4>
101432f2c: 910163e0    	add	x0, sp, #0x58
101432f30: 94008181    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
101432f34: f100133f    	cmp	x25, #0x4
101432f38: 54fff3a1    	b.ne	0x101432dac <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x58>
101432f3c: 14000006    	b	0x101432f54 <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x200>
101432f40: 910163f6    	add	x22, sp, #0x58
101432f44: 9100c3fb    	add	x27, sp, #0x30
101432f48: 2a130353    	orr	w19, w26, w19
101432f4c: f100133f    	cmp	x25, #0x4
101432f50: 54fff2e1    	b.ne	0x101432dac <__ZN17otty_autocomplete6engine6Engine10clear_data17h2d8de0c134235ffeE+0x58>
101432f54: aa1303e0    	mov	x0, x19
101432f58: a94d7bfd    	ldp	x29, x30, [sp, #0xd0]
101432f5c: a94c4ff4    	ldp	x20, x19, [sp, #0xc0]
101432f60: a94b57f6    	ldp	x22, x21, [sp, #0xb0]
101432f64: a94a5ff8    	ldp	x24, x23, [sp, #0xa0]
101432f68: a94967fa    	ldp	x26, x25, [sp, #0x90]
101432f6c: a9486ffc    	ldp	x28, x27, [sp, #0x80]
101432f70: 910383ff    	add	sp, sp, #0xe0
101432f74: d65f03c0    	ret

0000000101432f78 <__ZN17otty_autocomplete6engine6Engine11known_flags17hf02d40176fa4b1ccE>:
101432f78: d10203ff    	sub	sp, sp, #0x80
101432f7c: a9045ff8    	stp	x24, x23, [sp, #0x40]
101432f80: a90557f6    	stp	x22, x21, [sp, #0x50]
101432f84: a9064ff4    	stp	x20, x19, [sp, #0x60]
101432f88: a9077bfd    	stp	x29, x30, [sp, #0x70]
101432f8c: 9101c3fd    	add	x29, sp, #0x70
101432f90: aa0003f4    	mov	x20, x0
101432f94: aa0803f3    	mov	x19, x8
101432f98: d0007a40    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101432f9c: 9131a000    	add	x0, x0, #0xc68
101432fa0: f9400008    	ldr	x8, [x0]
101432fa4: d63f0100    	blr	x8
101432fa8: 39404008    	ldrb	w8, [x0, #0x10]
101432fac: 7100051f    	cmp	w8, #0x1
101432fb0: 540004c1    	b.ne	0x101433048 <__ZN17otty_autocomplete6engine6Engine11known_flags17hf02d40176fa4b1ccE+0xd0>
101432fb4: a9402408    	ldp	x8, x9, [x0]
101432fb8: 9100050a    	add	x10, x8, #0x1
101432fbc: f900000a    	str	x10, [x0]
101432fc0: d00071aa    	adrp	x10, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101432fc4: 9116614a    	add	x10, x10, #0x598
101432fc8: ad400540    	ldp	q0, q1, [x10]
101432fcc: ad0007e0    	stp	q0, q1, [sp]
101432fd0: a90227e8    	stp	x8, x9, [sp, #0x20]
101432fd4: f84d8e88    	ldr	x8, [x20, #0xd8]!
101432fd8: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101432fdc: eb09011f    	cmp	x8, x9
101432fe0: 54000200    	b.eq	0x101433020 <__ZN17otty_autocomplete6engine6Engine11known_flags17hf02d40176fa4b1ccE+0xa8>
101432fe4: aa1403e0    	mov	x0, x20
101432fe8: 97ffb411    	bl	0x10142002c <__ZN17otty_autocomplete2db13CompletionsDb11lookup_spec17h895ef0a520e673c6E>
101432fec: aa0003f4    	mov	x20, x0
101432ff0: b4000180    	cbz	x0, 0x101433020 <__ZN17otty_autocomplete6engine6Engine11known_flags17hf02d40176fa4b1ccE+0xa8>
101432ff4: f9001ff4    	str	x20, [sp, #0x38]
101432ff8: 91004280    	add	x0, x20, #0x10
101432ffc: 910003e1    	mov	x1, sp
