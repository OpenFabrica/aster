
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010143c918 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E>:
10143e418: d10403ff    	sub	sp, sp, #0x100
10143e41c: 6d0923e9    	stp	d9, d8, [sp, #0x90]
10143e420: a90a6ffc    	stp	x28, x27, [sp, #0xa0]
10143e424: a90b67fa    	stp	x26, x25, [sp, #0xb0]
10143e428: a90c5ff8    	stp	x24, x23, [sp, #0xc0]
10143e42c: a90d57f6    	stp	x22, x21, [sp, #0xd0]
10143e430: a90e4ff4    	stp	x20, x19, [sp, #0xe0]
10143e434: a90f7bfd    	stp	x29, x30, [sp, #0xf0]
10143e438: 9103c3fd    	add	x29, sp, #0xf0
10143e43c: aa0003f3    	mov	x19, x0
10143e440: a9000be1    	stp	x1, x2, [sp]
10143e444: a90113e3    	stp	x3, x4, [sp, #0x10]
10143e448: d0007148    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
10143e44c: 9126c108    	add	x8, x8, #0x9b0
10143e450: 910003e9    	mov	x9, sp
10143e454: a904a3e9    	stp	x9, x8, [sp, #0x48]
10143e458: 910043e9    	add	x9, sp, #0x10
10143e45c: a905a3e9    	stp	x9, x8, [sp, #0x58]
10143e460: 90004522    	adrp	x2, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10143e464: 91007442    	add	x2, x2, #0x1d
10143e468: 910083e0    	add	x0, sp, #0x20
10143e46c: 9102c261    	add	x1, x19, #0xb0
10143e470: 910123e4    	add	x4, sp, #0x48
10143e474: 528007c3    	mov	w3, #0x3e               ; =62
10143e478: 52800045    	mov	w5, #0x2                ; =2
10143e47c: 9400d5bd    	bl	0x101473b70 <__ZN83_$LT$otty_autocomplete..help_probe..HelpProbe$u20$as$u20$core..default..Default$GT$7default17h369ecdb8ed473e73E+0x67e0>
10143e480: f94013e8    	ldr	x8, [sp, #0x20]
10143e484: d2800269    	mov	x9, #0x13               ; =19
10143e488: f2f00009    	movk	x9, #0x8000, lsl #48
10143e48c: eb09011f    	cmp	x8, x9
10143e490: 54000060    	b.eq	0x10143e49c <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1b84>
10143e494: 910083e0    	add	x0, sp, #0x20
10143e498: 94005427    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
10143e49c: a94027e8    	ldp	x8, x9, [sp]
10143e4a0: a9412fea    	ldp	x10, x11, [sp, #0x10]
10143e4a4: a906a7e8    	stp	x8, x9, [sp, #0x68]
10143e4a8: a907afea    	stp	x10, x11, [sp, #0x78]
10143e4ac: b0000088    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
10143e4b0: 91117108    	add	x8, x8, #0x45c
10143e4b4: 9101a3e9    	add	x9, sp, #0x68
10143e4b8: a90223e9    	stp	x9, x8, [sp, #0x20]
10143e4bc: 9101e3e9    	add	x9, sp, #0x78
10143e4c0: a90323e9    	stp	x9, x8, [sp, #0x30]
10143e4c4: 90004e80    	adrp	x0, 0x101e0e000 <_writev+0x101e0e000>
10143e4c8: 9110f000    	add	x0, x0, #0x43c
10143e4cc: 910123e8    	add	x8, sp, #0x48
10143e4d0: 910083e1    	add	x1, sp, #0x20
10143e4d4: 940f342b    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
10143e4d8: a9538660    	ldp	x0, x1, [x19, #0x138]
10143e4dc: 910123e2    	add	x2, sp, #0x48
10143e4e0: 97d43ce7    	bl	0x10094d87c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a854>
10143e4e4: d2800017    	mov	x23, #0x0               ; =0
10143e4e8: a94557f4    	ldp	x20, x21, [sp, #0x50]
10143e4ec: d379fc08    	lsr	x8, x0, #57
10143e4f0: a951e276    	ldp	x22, x24, [x19, #0x118]
10143e4f4: 0e010d08    	dup.8b	v8, w8
10143e4f8: 6f07e7e1    	movi.2d	v1, #0xffffffffffffffff
10143e4fc: 52800309    	mov	w9, #0x18               ; =24
10143e500: 8a18001b    	and	x27, x0, x24
10143e504: fc7b6ac9    	ldr	d9, [x22, x27]
10143e508: 2e288d20    	cmeq.8b	v0, v9, v8
10143e50c: 9e660008    	fmov	x8, d0
10143e510: f201c11c    	ands	x28, x8, #0x8080808080808080
10143e514: 54000280    	b.eq	0x10143e564 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1c4c>
10143e518: dac00388    	rbit	x8, x28
10143e51c: dac01108    	clz	x8, x8
10143e520: 8b480f68    	add	x8, x27, x8, lsr #3
10143e524: 8a18011a    	and	x26, x8, x24
10143e528: 9b09ff48    	mneg	x8, x26, x9
10143e52c: 8b0802d9    	add	x25, x22, x8
10143e530: f85f8328    	ldur	x8, [x25, #-0x8]
10143e534: eb0802bf    	cmp	x21, x8
10143e538: 540000c1    	b.ne	0x10143e550 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1c38>
10143e53c: f85f0321    	ldur	x1, [x25, #-0x10]
10143e540: aa1403e0    	mov	x0, x20
10143e544: aa1503e2    	mov	x2, x21
10143e548: 941a2db5    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10143e54c: 34000260    	cbz	w0, 0x10143e598 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1c80>
10143e550: d1000788    	sub	x8, x28, #0x1
10143e554: ea1c011c    	ands	x28, x8, x28
10143e558: 6f07e7e1    	movi.2d	v1, #0xffffffffffffffff
10143e55c: 52800309    	mov	w9, #0x18               ; =24
10143e560: 54fffdc1    	b.ne	0x10143e518 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1c00>
10143e564: 2e218d20    	cmeq.8b	v0, v9, v1
10143e568: 2e30a800    	umaxv.8b	b0, v0
10143e56c: 1e260008    	fmov	w8, s0
10143e570: 370005c8    	tbnz	w8, #0x0, 0x10143e628 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1d10>
10143e574: 910022f7    	add	x23, x23, #0x8
10143e578: 8b170360    	add	x0, x27, x23
10143e57c: 8a18001b    	and	x27, x0, x24
10143e580: fc7b6ac9    	ldr	d9, [x22, x27]
10143e584: 2e288d20    	cmeq.8b	v0, v9, v8
10143e588: 9e660008    	fmov	x8, d0
10143e58c: f201c11c    	ands	x28, x8, #0x8080808080808080
10143e590: 54fffc41    	b.ne	0x10143e518 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1c00>
10143e594: 17fffff4    	b	0x10143e564 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1c4c>
10143e598: 8b1a0748    	add	x8, x26, x26, lsl #1
10143e59c: 9340f108    	sbfx	x8, x8, #0, #61
10143e5a0: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
10143e5a4: f2955569    	movk	x9, #0xaaab
10143e5a8: 9b097d08    	mul	x8, x8, x9
10143e5ac: d1002109    	sub	x9, x8, #0x8
10143e5b0: 8a180129    	and	x9, x9, x24
10143e5b4: 8b0902c9    	add	x9, x22, x9
10143e5b8: fd400120    	ldr	d0, [x9]
10143e5bc: 6f07e7e1    	movi.2d	v1, #0xffffffffffffffff
10143e5c0: 2e218c00    	cmeq.8b	v0, v0, v1
10143e5c4: 9e66000a    	fmov	x10, d0
10143e5c8: fc686ac0    	ldr	d0, [x22, x8]
10143e5cc: 2e218c00    	cmeq.8b	v0, v0, v1
10143e5d0: 9e66000b    	fmov	x11, d0
10143e5d4: dac0114a    	clz	x10, x10
10143e5d8: dac0016b    	rbit	x11, x11
10143e5dc: dac0116b    	clz	x11, x11
10143e5e0: d343fd6b    	lsr	x11, x11, #3
10143e5e4: 8b4a0d6a    	add	x10, x11, x10, lsr #3
10143e5e8: f1001d5f    	cmp	x10, #0x7
10143e5ec: 54000069    	b.ls	0x10143e5f8 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1ce0>
10143e5f0: 5280100a    	mov	w10, #0x80              ; =128
10143e5f4: 14000005    	b	0x10143e608 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1cf0>
10143e5f8: f940966a    	ldr	x10, [x19, #0x128]
10143e5fc: 9100054a    	add	x10, x10, #0x1
10143e600: f900966a    	str	x10, [x19, #0x128]
10143e604: 52801fea    	mov	w10, #0xff              ; =255
10143e608: 38286aca    	strb	w10, [x22, x8]
10143e60c: 3900212a    	strb	w10, [x9, #0x8]
10143e610: f9409a68    	ldr	x8, [x19, #0x130]
10143e614: d1000508    	sub	x8, x8, #0x1
10143e618: f9009a68    	str	x8, [x19, #0x130]
10143e61c: f85e8321    	ldur	x1, [x25, #-0x18]
10143e620: f240f83f    	tst	x1, #0x7fffffffffffffff
10143e624: 540001e1    	b.ne	0x10143e660 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1d48>
10143e628: f94027e1    	ldr	x1, [sp, #0x48]
10143e62c: b4000081    	cbz	x1, 0x10143e63c <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1d24>
10143e630: aa1403e0    	mov	x0, x20
10143e634: 52800022    	mov	w2, #0x1                ; =1
10143e638: 97d98029    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143e63c: a94f7bfd    	ldp	x29, x30, [sp, #0xf0]
10143e640: a94e4ff4    	ldp	x20, x19, [sp, #0xe0]
10143e644: a94d57f6    	ldp	x22, x21, [sp, #0xd0]
10143e648: a94c5ff8    	ldp	x24, x23, [sp, #0xc0]
10143e64c: a94b67fa    	ldp	x26, x25, [sp, #0xb0]
10143e650: a94a6ffc    	ldp	x28, x27, [sp, #0xa0]
10143e654: 6d4923e9    	ldp	d9, d8, [sp, #0x90]
10143e658: 910403ff    	add	sp, sp, #0x100
10143e65c: d65f03c0    	ret
10143e660: f85f0320    	ldur	x0, [x25, #-0x10]
10143e664: 52800022    	mov	w2, #0x1                ; =1
10143e668: 97d9801d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10143e66c: f94027e1    	ldr	x1, [sp, #0x48]
10143e670: b5fffe01    	cbnz	x1, 0x10143e630 <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1d18>
10143e674: 17fffff2    	b	0x10143e63c <__ZN17otty_autocomplete6readme14ReadmeCommands3new17h1a81336af418e649E+0x1d24>
