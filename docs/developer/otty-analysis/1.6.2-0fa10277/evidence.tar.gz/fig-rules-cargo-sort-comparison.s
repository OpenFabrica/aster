
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010145a6d4 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE>:
10145d2b0: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10145d2b4: a90167fa    	stp	x26, x25, [sp, #0x10]
10145d2b8: a9025ff8    	stp	x24, x23, [sp, #0x20]
10145d2bc: a90357f6    	stp	x22, x21, [sp, #0x30]
10145d2c0: a9044ff4    	stp	x20, x19, [sp, #0x40]
10145d2c4: a9057bfd    	stp	x29, x30, [sp, #0x50]
10145d2c8: 910143fd    	add	x29, sp, #0x50
10145d2cc: d10bc3ff    	sub	sp, sp, #0x2f0
10145d2d0: b90027e4    	str	w4, [sp, #0x24]
10145d2d4: f90047e2    	str	x2, [sp, #0x88]
10145d2d8: f90033e0    	str	x0, [sp, #0x60]
10145d2dc: f100083f    	cmp	x1, #0x2
10145d2e0: 54003043    	b.lo	0x10145d8e8 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x3214>
10145d2e4: aa0503f4    	mov	x20, x5
10145d2e8: aa0103f5    	mov	x21, x1
10145d2ec: d2e80008    	mov	x8, #0x4000000000000000 ; =4611686018427387904
10145d2f0: 9ac10909    	udiv	x9, x8, x1
10145d2f4: 9b017d2a    	mul	x10, x9, x1
10145d2f8: eb08015f    	cmp	x10, x8
10145d2fc: 9a890528    	cinc	x8, x9, ne
10145d300: f9001be8    	str	x8, [sp, #0x30]
10145d304: f140043f    	cmp	x1, #0x1, lsl #12       ; =0x1000
10145d308: f90043e3    	str	x3, [sp, #0x80]
10145d30c: 540000e8    	b.hi	0x10145d328 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2c54>
10145d310: cb5506a8    	sub	x8, x21, x21, lsr #1
10145d314: 52800809    	mov	w9, #0x40               ; =64
10145d318: f101011f    	cmp	x8, #0x40
10145d31c: 9a893108    	csel	x8, x8, x9, lo
10145d320: f90023e8    	str	x8, [sp, #0x40]
10145d324: 14000005    	b	0x10145d338 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2c64>
10145d328: aa1503e0    	mov	x0, x21
10145d32c: 940f1fce    	bl	0x101825264 <__ZN4core5slice4sort6stable5drift11sqrt_approx17h153f8df5fefebe3fE>
10145d330: f94043e3    	ldr	x3, [sp, #0x80]
10145d334: f90023e0    	str	x0, [sp, #0x40]
10145d338: d2800019    	mov	x25, #0x0               ; =0
10145d33c: f94033e8    	ldr	x8, [sp, #0x60]
10145d340: 9103810a    	add	x10, x8, #0xe0
10145d344: 9100c109    	add	x9, x8, #0x30
10145d348: a9012be9    	stp	x9, x10, [sp, #0x10]
10145d34c: d2800009    	mov	x9, #0x0                ; =0
10145d350: d100a10a    	sub	x10, x8, #0x28
10145d354: f90007ea    	str	x10, [sp, #0x8]
10145d358: d101a108    	sub	x8, x8, #0x68
10145d35c: f90017e8    	str	x8, [sp, #0x28]
10145d360: 52800d13    	mov	w19, #0x68              ; =104
10145d364: 52800038    	mov	w24, #0x1               ; =1
10145d368: f9001ff5    	str	x21, [sp, #0x38]
10145d36c: f9002ff4    	str	x20, [sp, #0x58]
10145d370: eb1902b6    	subs	x22, x21, x25
10145d374: 540000e9    	b.ls	0x10145d390 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2cbc>
10145d378: 1400000b    	b	0x10145d3a4 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2cd0>
10145d37c: 91000529    	add	x9, x9, #0x1
10145d380: 8b4b0739    	add	x25, x25, x11, lsr #1
10145d384: aa0b03f8    	mov	x24, x11
10145d388: eb1902b6    	subs	x22, x21, x25
10145d38c: 540000c8    	b.hi	0x10145d3a4 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2cd0>
10145d390: 5280000c    	mov	w12, #0x0               ; =0
10145d394: 5280002b    	mov	w11, #0x1               ; =1
10145d398: f100093f    	cmp	x9, #0x2
10145d39c: 540013c2    	b.hs	0x10145d614 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2f40>
10145d3a0: 14000141    	b	0x10145d8a4 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x31d0>
10145d3a4: f94033e8    	ldr	x8, [sp, #0x60]
10145d3a8: 9b13233a    	madd	x26, x25, x19, x8
10145d3ac: f94023e8    	ldr	x8, [sp, #0x40]
10145d3b0: eb0802df    	cmp	x22, x8
10145d3b4: f9003fe9    	str	x9, [sp, #0x78]
10145d3b8: 54000222    	b.hs	0x10145d3fc <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2d28>
10145d3bc: b94027e8    	ldr	w8, [sp, #0x24]
10145d3c0: 360004a8    	tbz	w8, #0x0, 0x10145d454 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2d80>
10145d3c4: f10082df    	cmp	x22, #0x20
10145d3c8: 52800408    	mov	w8, #0x20               ; =32
10145d3cc: 9a8832db    	csel	x27, x22, x8, lo
10145d3d0: aa1a03e0    	mov	x0, x26
10145d3d4: aa1b03e1    	mov	x1, x27
10145d3d8: a9480be3    	ldp	x3, x2, [sp, #0x80]
10145d3dc: 52800004    	mov	w4, #0x0                ; =0
10145d3e0: d2800005    	mov	x5, #0x0                ; =0
10145d3e4: aa1403e6    	mov	x6, x20
10145d3e8: 94001ca9    	bl	0x10146468c <__ZN4core5slice4sort6stable9quicksort9quicksort17h95c964e95501b39aE>
10145d3ec: f94043e3    	ldr	x3, [sp, #0x80]
10145d3f0: 52800028    	mov	w8, #0x1                ; =1
10145d3f4: aa1b050b    	orr	x11, x8, x27, lsl #1
10145d3f8: 1400007c    	b	0x10145d5e8 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2f14>
10145d3fc: f1000adf    	cmp	x22, #0x2
10145d400: 54000f03    	b.lo	0x10145d5e0 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2f0c>
10145d404: f90037f9    	str	x25, [sp, #0x68]
10145d408: a9476740    	ldp	x0, x25, [x26, #0x70]
10145d40c: a940a341    	ldp	x1, x8, [x26, #0x8]
10145d410: eb080335    	subs	x21, x25, x8
10145d414: 9a883322    	csel	x2, x25, x8, lo
10145d418: aa0003fb    	mov	x27, x0
10145d41c: 9419b200    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10145d420: 93407c08    	sxtw	x8, w0
10145d424: 7100001f    	cmp	w0, #0x0
10145d428: 9a8802a8    	csel	x8, x21, x8, eq
10145d42c: b7f801e8    	tbnz	x8, #0x3f, 0x10145d468 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2d94>
10145d430: f1000adf    	cmp	x22, #0x2
10145d434: 540002e1    	b.ne	0x10145d490 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2dbc>
10145d438: a943a3f5    	ldp	x21, x8, [sp, #0x38]
10145d43c: f100091f    	cmp	x8, #0x2
10145d440: f94043e3    	ldr	x3, [sp, #0x80]
10145d444: f94037f9    	ldr	x25, [sp, #0x68]
10145d448: 54fffba8    	b.hi	0x10145d3bc <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2ce8>
10145d44c: 52800056    	mov	w22, #0x2               ; =2
10145d450: 14000064    	b	0x10145d5e0 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2f0c>
10145d454: f94023e8    	ldr	x8, [sp, #0x40]
10145d458: eb0802df    	cmp	x22, x8
10145d45c: 9a8832c8    	csel	x8, x22, x8, lo
10145d460: d37ff90b    	lsl	x11, x8, #1
10145d464: 14000061    	b	0x10145d5e8 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2f14>
10145d468: f1000adf    	cmp	x22, #0x2
10145d46c: 54000401    	b.ne	0x10145d4ec <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2e18>
10145d470: a943a3f5    	ldp	x21, x8, [sp, #0x38]
10145d474: f100091f    	cmp	x8, #0x2
10145d478: f94043e3    	ldr	x3, [sp, #0x80]
10145d47c: f94037f9    	ldr	x25, [sp, #0x68]
10145d480: 54fff9e8    	b.hi	0x10145d3bc <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2ce8>
10145d484: 52800028    	mov	w8, #0x1                ; =1
10145d488: 52800057    	mov	w23, #0x2               ; =2
10145d48c: 1400003b    	b	0x10145d578 <__ZN4core5slice4sort6stable14driftsort_main17hf3faacebe428fbafE+0x2ea4>
10145d490: f9002be8    	str	x8, [sp, #0x50]
10145d494: f9003bfa    	str	x26, [sp, #0x70]
10145d498: f94037e8    	ldr	x8, [sp, #0x68]
10145d49c: f9400fe9    	ldr	x9, [sp, #0x18]
10145d4a0: 9b13251c    	madd	x28, x8, x19, x9
10145d4a4: 52800057    	mov	w23, #0x2               ; =2
10145d4a8: aa1b03e1    	mov	x1, x27
10145d4ac: a97fd79b    	ldp	x27, x21, [x28, #-0x8]
