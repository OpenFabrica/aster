
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010144a5b8 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E>:
10144aa00: 5200037b    	eor	w27, w27, #0x1
10144aa04: 17ffff0f    	b	0x10144a640 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x88>
10144aa08: 12800fec    	mov	w12, #-0x80             ; =-128
10144aa0c: 53127eed    	lsr	w13, w23, #18
10144aa10: 321c6dad    	orr	w13, w13, #0xfffffff0
10144aa14: 3900012d    	strb	w13, [x9]
10144aa18: 330c46ec    	bfxil	w12, w23, #12, #6
10144aa1c: 3900052c    	strb	w12, [x9, #0x1]
10144aa20: 3900092b    	strb	w11, [x9, #0x2]
10144aa24: 39000d2a    	strb	w10, [x9, #0x3]
10144aa28: 17ffff01    	b	0x10144a62c <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x74>
10144aa2c: d2800016    	mov	x22, #0x0               ; =0
10144aa30: 5280001a    	mov	w26, #0x0               ; =0
10144aa34: b9000fff    	str	wzr, [sp, #0xc]
10144aa38: 5280001b    	mov	w27, #0x0               ; =0
10144aa3c: 17ffff01    	b	0x10144a640 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x88>
10144aa40: 9100a3e0    	add	x0, sp, #0x28
10144aa44: aa1503e1    	mov	x1, x21
10144aa48: aa1603e2    	mov	x2, x22
10144aa4c: 52800023    	mov	w3, #0x1                ; =1
10144aa50: 52800024    	mov	w4, #0x1                ; =1
10144aa54: 9417777f    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10144aa58: a94327e8    	ldp	x8, x9, [sp, #0x30]
10144aa5c: 8b090109    	add	x9, x8, x9
10144aa60: 3707de5a    	tbnz	w26, #0x0, 0x10144a628 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x70>
10144aa64: 17ffffd0    	b	0x10144a9a4 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x3ec>
10144aa68: f94003f7    	ldr	x23, [sp]
10144aa6c: b40000f5    	cbz	x21, 0x10144aa88 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x4d0>
10144aa70: a942dbf4    	ldp	x20, x22, [sp, #0x28]
10144aa74: f94013f3    	ldr	x19, [sp, #0x20]
10144aa78: f9400be8    	ldr	x8, [sp, #0x10]
10144aa7c: eb08027f    	cmp	x19, x8
10144aa80: 540002e0    	b.eq	0x10144aadc <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x524>
10144aa84: 14000018    	b	0x10144aae4 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x52c>
10144aa88: 3dc007e0    	ldr	q0, [sp, #0x10]
10144aa8c: 3d8002e0    	str	q0, [x23]
10144aa90: a94207e8    	ldp	x8, x1, [sp, #0x20]
10144aa94: f9000ae8    	str	x8, [x23, #0x10]
10144aa98: b40003a1    	cbz	x1, 0x10144ab0c <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x554>
10144aa9c: f9401be0    	ldr	x0, [sp, #0x30]
10144aaa0: 52800022    	mov	w2, #0x1                ; =1
10144aaa4: a9497bfd    	ldp	x29, x30, [sp, #0x90]
10144aaa8: a9484ff4    	ldp	x20, x19, [sp, #0x80]
10144aaac: a94757f6    	ldp	x22, x21, [sp, #0x70]
10144aab0: a9465ff8    	ldp	x24, x23, [sp, #0x60]
10144aab4: a94567fa    	ldp	x26, x25, [sp, #0x50]
10144aab8: a9446ffc    	ldp	x28, x27, [sp, #0x40]
10144aabc: 910283ff    	add	sp, sp, #0xa0
10144aac0: 17d94f07    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10144aac4: f94003f7    	ldr	x23, [sp]
10144aac8: a942dbf4    	ldp	x20, x22, [sp, #0x28]
10144aacc: f94013f3    	ldr	x19, [sp, #0x20]
10144aad0: f9400be8    	ldr	x8, [sp, #0x10]
10144aad4: eb08027f    	cmp	x19, x8
10144aad8: 54000061    	b.ne	0x10144aae4 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x52c>
10144aadc: 910043e0    	add	x0, sp, #0x10
10144aae0: 941914cd    	bl	0x101a8fe14 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hed155317132a177cE>
10144aae4: f9400fe8    	ldr	x8, [sp, #0x18]
10144aae8: 52800309    	mov	w9, #0x18               ; =24
10144aaec: 9b092268    	madd	x8, x19, x9, x8
10144aaf0: a9005914    	stp	x20, x22, [x8]
10144aaf4: f9000915    	str	x21, [x8, #0x10]
10144aaf8: 91000668    	add	x8, x19, #0x1
10144aafc: f90013e8    	str	x8, [sp, #0x20]
10144ab00: 3dc007e0    	ldr	q0, [sp, #0x10]
10144ab04: 3d8002e0    	str	q0, [x23]
10144ab08: f9000ae8    	str	x8, [x23, #0x10]
10144ab0c: a9497bfd    	ldp	x29, x30, [sp, #0x90]
10144ab10: a9484ff4    	ldp	x20, x19, [sp, #0x80]
10144ab14: a94757f6    	ldp	x22, x21, [sp, #0x70]
10144ab18: a9465ff8    	ldp	x24, x23, [sp, #0x60]
10144ab1c: a94567fa    	ldp	x26, x25, [sp, #0x50]
10144ab20: a9446ffc    	ldp	x28, x27, [sp, #0x40]
10144ab24: 910283ff    	add	sp, sp, #0xa0
10144ab28: d65f03c0    	ret
10144ab2c: 14000001    	b	0x10144ab30 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x578>
10144ab30: aa0003f3    	mov	x19, x0
10144ab34: 1400000c    	b	0x10144ab64 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x5ac>
10144ab38: aa0003f3    	mov	x19, x0
10144ab3c: b40001f4    	cbz	x20, 0x10144ab78 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x5c0>
10144ab40: aa1603e0    	mov	x0, x22
10144ab44: aa1403e1    	mov	x1, x20
10144ab48: 1400000a    	b	0x10144ab70 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x5b8>
10144ab4c: aa0003f3    	mov	x19, x0
10144ab50: b40000b7    	cbz	x23, 0x10144ab64 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x5ac>
10144ab54: aa1803e0    	mov	x0, x24
10144ab58: aa1703e1    	mov	x1, x23
10144ab5c: 52800022    	mov	w2, #0x1                ; =1
10144ab60: 97d94edf    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10144ab64: f94017e1    	ldr	x1, [sp, #0x28]
10144ab68: b4000081    	cbz	x1, 0x10144ab78 <__ZN17otty_autocomplete8tokenize8tokenize17h5c8493fd443a63a8E+0x5c0>
10144ab6c: f9401be0    	ldr	x0, [sp, #0x30]
10144ab70: 52800022    	mov	w2, #0x1                ; =1
10144ab74: 97d94eda    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10144ab78: 910043e0    	add	x0, sp, #0x10
10144ab7c: 97d3dfe4    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10144ab80: aa1303e0    	mov	x0, x19
10144ab84: 9419fa94    	bl	0x101ac95d4 <_writev+0x101ac95d4>

000000010144ab88 <__ZN185_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecArg$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h81fc6b2718aeaf21E>:
10144ab88: aa0103e0    	mov	x0, x1
10144ab8c: 900044c1    	adrp	x1, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10144ab90: 9122d021    	add	x1, x1, #0x8b4
10144ab94: 528001c2    	mov	w2, #0xe                ; =14
10144ab98: 140f43d3    	b	0x10181bae4 <__ZN57_$LT$core..fmt..Formatter$u20$as$u20$core..fmt..Write$GT$9write_str17h22cb7bac9af9c35eE>

000000010144ab9c <__ZN188_$LT$otty_autocomplete..db.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..db..RecoveryUpdate$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h9bcd06a48c5d8409E>:
10144ab9c: aa0103e0    	mov	x0, x1
10144aba0: 900044c1    	adrp	x1, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10144aba4: 91238021    	add	x1, x1, #0x8e0
10144aba8: 528002a2    	mov	w2, #0x15               ; =21
10144abac: 140f43ce    	b	0x10181bae4 <__ZN57_$LT$core..fmt..Formatter$u20$as$u20$core..fmt..Write$GT$9write_str17h22cb7bac9af9c35eE>

000000010144abb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E>:
10144abb0: aa0103e0    	mov	x0, x1
10144abb4: 900044c1    	adrp	x1, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10144abb8: 9123d421    	add	x1, x1, #0x8f5
10144abbc: 52800222    	mov	w2, #0x11               ; =17
10144abc0: 140f43c9    	b	0x10181bae4 <__ZN57_$LT$core..fmt..Formatter$u20$as$u20$core..fmt..Write$GT$9write_str17h22cb7bac9af9c35eE>
10144abc4: f1002c5f    	cmp	x2, #0xb
10144abc8: 54000620    	b.eq	0x10144ac8c <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0xdc>
10144abcc: f100205f    	cmp	x2, #0x8
10144abd0: 54000260    	b.eq	0x10144ac1c <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x6c>
10144abd4: f100105f    	cmp	x2, #0x4
10144abd8: 54000ec1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144abdc: 39400028    	ldrb	w8, [x1]
10144abe0: 7101b91f    	cmp	w8, #0x6e
10144abe4: 54000e61    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144abe8: 39400428    	ldrb	w8, [x1, #0x1]
10144abec: 7101851f    	cmp	w8, #0x61
10144abf0: 54000e01    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144abf4: 39400828    	ldrb	w8, [x1, #0x2]
10144abf8: 7101b51f    	cmp	w8, #0x6d
10144abfc: 54000da1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ac00: 39400c28    	ldrb	w8, [x1, #0x3]
10144ac04: 7101951f    	cmp	w8, #0x65
10144ac08: 54000d41    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ac0c: 52800008    	mov	w8, #0x0                ; =0
10144ac10: 39000408    	strb	w8, [x0, #0x1]
10144ac14: 3900001f    	strb	wzr, [x0]
10144ac18: d65f03c0    	ret
10144ac1c: 39400028    	ldrb	w8, [x1]
10144ac20: 7101d11f    	cmp	w8, #0x74
10144ac24: 54000c61    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ac28: 39400428    	ldrb	w8, [x1, #0x1]
10144ac2c: 7101951f    	cmp	w8, #0x65
10144ac30: 54000c01    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ac34: 39400828    	ldrb	w8, [x1, #0x2]
10144ac38: 7101b51f    	cmp	w8, #0x6d
10144ac3c: 54000ba1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ac40: 39400c28    	ldrb	w8, [x1, #0x3]
10144ac44: 7101c11f    	cmp	w8, #0x70
10144ac48: 54000b41    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ac4c: 39401028    	ldrb	w8, [x1, #0x4]
10144ac50: 7101b11f    	cmp	w8, #0x6c
10144ac54: 54000ae1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ac58: 39401428    	ldrb	w8, [x1, #0x5]
10144ac5c: 7101851f    	cmp	w8, #0x61
10144ac60: 54000a81    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ac64: 39401828    	ldrb	w8, [x1, #0x6]
10144ac68: 7101d11f    	cmp	w8, #0x74
10144ac6c: 54000a21    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ac70: 39401c28    	ldrb	w8, [x1, #0x7]
10144ac74: 7101951f    	cmp	w8, #0x65
10144ac78: 540009c1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ac7c: 52800048    	mov	w8, #0x2                ; =2
10144ac80: 39000408    	strb	w8, [x0, #0x1]
10144ac84: 3900001f    	strb	wzr, [x0]
10144ac88: d65f03c0    	ret
10144ac8c: 39400028    	ldrb	w8, [x1]
10144ac90: 7101911f    	cmp	w8, #0x64
10144ac94: 540004a0    	b.eq	0x10144ad28 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x178>
10144ac98: 7101cd1f    	cmp	w8, #0x73
10144ac9c: 540008a1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144aca0: 39400428    	ldrb	w8, [x1, #0x1]
10144aca4: 7101d51f    	cmp	w8, #0x75
10144aca8: 54000841    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144acac: 39400828    	ldrb	w8, [x1, #0x2]
10144acb0: 71019d1f    	cmp	w8, #0x67
10144acb4: 540007e1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144acb8: 39400c28    	ldrb	w8, [x1, #0x3]
10144acbc: 71019d1f    	cmp	w8, #0x67
10144acc0: 54000781    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144acc4: 39401028    	ldrb	w8, [x1, #0x4]
10144acc8: 7101951f    	cmp	w8, #0x65
10144accc: 54000721    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144acd0: 39401428    	ldrb	w8, [x1, #0x5]
10144acd4: 7101cd1f    	cmp	w8, #0x73
10144acd8: 540006c1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144acdc: 39401828    	ldrb	w8, [x1, #0x6]
10144ace0: 7101d11f    	cmp	w8, #0x74
10144ace4: 54000661    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ace8: 39401c28    	ldrb	w8, [x1, #0x7]
10144acec: 7101a51f    	cmp	w8, #0x69
10144acf0: 54000601    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144acf4: 39402028    	ldrb	w8, [x1, #0x8]
10144acf8: 7101bd1f    	cmp	w8, #0x6f
10144acfc: 540005a1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ad00: 39402428    	ldrb	w8, [x1, #0x9]
10144ad04: 7101b91f    	cmp	w8, #0x6e
10144ad08: 54000541    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ad0c: 39402828    	ldrb	w8, [x1, #0xa]
10144ad10: 7101cd1f    	cmp	w8, #0x73
10144ad14: 540004e1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ad18: 52800068    	mov	w8, #0x3                ; =3
10144ad1c: 39000408    	strb	w8, [x0, #0x1]
10144ad20: 3900001f    	strb	wzr, [x0]
10144ad24: d65f03c0    	ret
10144ad28: 39400428    	ldrb	w8, [x1, #0x1]
10144ad2c: 7101951f    	cmp	w8, #0x65
10144ad30: 54000401    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ad34: 39400828    	ldrb	w8, [x1, #0x2]
10144ad38: 7101cd1f    	cmp	w8, #0x73
10144ad3c: 540003a1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ad40: 39400c28    	ldrb	w8, [x1, #0x3]
10144ad44: 71018d1f    	cmp	w8, #0x63
10144ad48: 54000341    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ad4c: 39401028    	ldrb	w8, [x1, #0x4]
10144ad50: 7101c91f    	cmp	w8, #0x72
10144ad54: 540002e1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ad58: 39401428    	ldrb	w8, [x1, #0x5]
10144ad5c: 7101a51f    	cmp	w8, #0x69
10144ad60: 54000281    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ad64: 39401828    	ldrb	w8, [x1, #0x6]
10144ad68: 7101c11f    	cmp	w8, #0x70
10144ad6c: 54000221    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ad70: 39401c28    	ldrb	w8, [x1, #0x7]
10144ad74: 7101d11f    	cmp	w8, #0x74
10144ad78: 540001c1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ad7c: 39402028    	ldrb	w8, [x1, #0x8]
10144ad80: 7101a51f    	cmp	w8, #0x69
10144ad84: 54000161    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ad88: 39402428    	ldrb	w8, [x1, #0x9]
10144ad8c: 7101bd1f    	cmp	w8, #0x6f
10144ad90: 54000101    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ad94: 39402828    	ldrb	w8, [x1, #0xa]
10144ad98: 7101b91f    	cmp	w8, #0x6e
10144ad9c: 540000a1    	b.ne	0x10144adb0 <__ZN188_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..SpecOption$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hd16e99f1d5d3ced3E+0x200>
10144ada0: 52800028    	mov	w8, #0x1                ; =1
10144ada4: 39000408    	strb	w8, [x0, #0x1]
10144ada8: 3900001f    	strb	wzr, [x0]
10144adac: d65f03c0    	ret
10144adb0: 52800088    	mov	w8, #0x4                ; =4
10144adb4: 39000408    	strb	w8, [x0, #0x1]
10144adb8: 3900001f    	strb	wzr, [x0]
10144adbc: d65f03c0    	ret

000000010144adc0 <__ZN210_$LT$otty_autocomplete..help_parse.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..help_parse..ProbeSubcommand$GT$..deserialize..__FieldVisitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17ha0f0b7f4a9f1103cE>:
10144adc0: aa0103e0    	mov	x0, x1
10144adc4: f0003721    	adrp	x1, 0x101b31000 <__ZN4jiff4span4Span22has_fractional_seconds9SUBSECOND17hdf4148a953a76d03E+0x115e4>
10144adc8: 9104c021    	add	x1, x1, #0x130
10144adcc: 52800202    	mov	w2, #0x10               ; =16
10144add0: 140f4345    	b	0x10181bae4 <__ZN57_$LT$core..fmt..Formatter$u20$as$u20$core..fmt..Write$GT$9write_str17h22cb7bac9af9c35eE>

000000010144add4 <__ZN192_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionItem$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hb172e826c5ae7a4aE>:
10144add4: aa0103e0    	mov	x0, x1
10144add8: 900044c1    	adrp	x1, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10144addc: 91249c21    	add	x1, x1, #0x927
10144ade0: 528002a2    	mov	w2, #0x15               ; =21
10144ade4: 140f4340    	b	0x10181bae4 <__ZN57_$LT$core..fmt..Formatter$u20$as$u20$core..fmt..Write$GT$9write_str17h22cb7bac9af9c35eE>

000000010144ade8 <__ZN192_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionKind$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hf0664041c5324ba5E>:
10144ade8: aa0103e0    	mov	x0, x1
10144adec: 900044c1    	adrp	x1, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10144adf0: 9124f021    	add	x1, x1, #0x93c
10144adf4: 52800262    	mov	w2, #0x13               ; =19
10144adf8: 140f433b    	b	0x10181bae4 <__ZN57_$LT$core..fmt..Formatter$u20$as$u20$core..fmt..Write$GT$9write_str17h22cb7bac9af9c35eE>

000000010144adfc <__ZN192_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..CompletionSpec$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hccbcb631bba9c19aE>:
10144adfc: aa0103e0    	mov	x0, x1
10144ae00: 900044c1    	adrp	x1, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10144ae04: 91253c21    	add	x1, x1, #0x94f
10144ae08: 528002a2    	mov	w2, #0x15               ; =21
10144ae0c: 140f4336    	b	0x10181bae4 <__ZN57_$LT$core..fmt..Formatter$u20$as$u20$core..fmt..Write$GT$9write_str17h22cb7bac9af9c35eE>

000000010144ae10 <__ZN194_$LT$otty_autocomplete..engine.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..engine..EngineConfig$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h006c2d2bc5b1e175E>:
10144ae10: aa0103e0    	mov	x0, x1
10144ae14: 900044c1    	adrp	x1, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10144ae18: 91262421    	add	x1, x1, #0x989
10144ae1c: 52800262    	mov	w2, #0x13               ; =19
10144ae20: 140f4331    	b	0x10181bae4 <__ZN57_$LT$core..fmt..Formatter$u20$as$u20$core..fmt..Write$GT$9write_str17h22cb7bac9af9c35eE>

000000010144ae24 <__ZN196_$LT$otty_autocomplete..spec.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..spec..StringOrSuggestion$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h0328b27467b9d0c3E>:
10144ae24: aa0103e0    	mov	x0, x1
10144ae28: 900044c1    	adrp	x1, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10144ae2c: 91267021    	add	x1, x1, #0x99c
10144ae30: 528004c2    	mov	w2, #0x26               ; =38
10144ae34: 140f432c    	b	0x10181bae4 <__ZN57_$LT$core..fmt..Formatter$u20$as$u20$core..fmt..Write$GT$9write_str17h22cb7bac9af9c35eE>

000000010144ae38 <__ZN197_$LT$otty_autocomplete..item.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_autocomplete..item..CompletionKind$GT$..deserialize..__FieldVisitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17h04becca310550952E>:
10144ae38: aa0103e0    	mov	x0, x1
10144ae3c: 900044c1    	adrp	x1, 0x101ce2000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x75e>
10144ae40: 91270821    	add	x1, x1, #0x9c2
10144ae44: 52800242    	mov	w2, #0x12               ; =18
10144ae48: 140f4327    	b	0x10181bae4 <__ZN57_$LT$core..fmt..Formatter$u20$as$u20$core..fmt..Write$GT$9write_str17h22cb7bac9af9c35eE>
