
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101447674 <__ZN17otty_autocomplete7process4exec17h82ed0cc7a8ed723eE>:
101447674: d10283ff    	sub	sp, sp, #0xa0
101447678: a90757f6    	stp	x22, x21, [sp, #0x70]
10144767c: a9084ff4    	stp	x20, x19, [sp, #0x80]
101447680: a9097bfd    	stp	x29, x30, [sp, #0x90]
101447684: 910243fd    	add	x29, sp, #0x90
101447688: aa0503e6    	mov	x6, x5
10144768c: aa0403e5    	mov	x5, x4
101447690: aa0303e4    	mov	x4, x3
101447694: aa0203e3    	mov	x3, x2
101447698: aa0103e2    	mov	x2, x1
10144769c: aa0003e1    	mov	x1, x0
1014476a0: aa0803f3    	mov	x19, x8
1014476a4: 9100e3e0    	add	x0, sp, #0x38
1014476a8: 52800007    	mov	w7, #0x0                ; =0
1014476ac: 97fffc6d    	bl	0x101446860 <__ZN17otty_autocomplete7process16exec_with_stderr17h3b702ef780167790E+0x3c>
1014476b0: f9401fe9    	ldr	x9, [sp, #0x38]
1014476b4: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014476b8: eb08013f    	cmp	x9, x8
1014476bc: 54000061    	b.ne	0x1014476c8 <__ZN17otty_autocomplete7process4exec17h82ed0cc7a8ed723eE+0x54>
1014476c0: f9000268    	str	x8, [x19]
1014476c4: 14000028    	b	0x101447764 <__ZN17otty_autocomplete7process4exec17h82ed0cc7a8ed723eE+0xf0>
1014476c8: 3cc383e0    	ldur	q0, [sp, #0x38]
1014476cc: 3cc483e1    	ldur	q1, [sp, #0x48]
1014476d0: ad0007e0    	stp	q0, q1, [sp]
1014476d4: 3cc583e0    	ldur	q0, [sp, #0x58]
1014476d8: 3d800be0    	str	q0, [sp, #0x20]
1014476dc: f94037e8    	ldr	x8, [sp, #0x68]
1014476e0: f9001be8    	str	x8, [sp, #0x30]
1014476e4: 36000208    	tbz	w8, #0x0, 0x101447724 <__ZN17otty_autocomplete7process4exec17h82ed0cc7a8ed723eE+0xb0>
1014476e8: a94087e0    	ldp	x0, x1, [sp, #0x8]
1014476ec: 97d4149e    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
1014476f0: aa0003f5    	mov	x21, x0
1014476f4: aa0103f4    	mov	x20, x1
1014476f8: b4000401    	cbz	x1, 0x101447778 <__ZN17otty_autocomplete7process4exec17h82ed0cc7a8ed723eE+0x104>
1014476fc: 97d95bfd    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101447700: aa1403e0    	mov	x0, x20
101447704: 52800021    	mov	w1, #0x1                ; =1
101447708: 97d95bf4    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10144770c: aa0003f6    	mov	x22, x0
101447710: b5000360    	cbnz	x0, 0x10144777c <__ZN17otty_autocomplete7process4exec17h82ed0cc7a8ed723eE+0x108>
101447714: 52800020    	mov	w0, #0x1                ; =1
101447718: aa1403e1    	mov	x1, x20
10144771c: 9419ef16    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101447720: d4200020    	brk	#0x1
101447724: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101447728: f9000268    	str	x8, [x19]
10144772c: f94003e1    	ldr	x1, [sp]
101447730: b4000081    	cbz	x1, 0x101447740 <__ZN17otty_autocomplete7process4exec17h82ed0cc7a8ed723eE+0xcc>
101447734: f94007e0    	ldr	x0, [sp, #0x8]
101447738: 52800022    	mov	w2, #0x1                ; =1
10144773c: 97d95be8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101447740: f9400fe1    	ldr	x1, [sp, #0x18]
101447744: b4000101    	cbz	x1, 0x101447764 <__ZN17otty_autocomplete7process4exec17h82ed0cc7a8ed723eE+0xf0>
101447748: f94013e0    	ldr	x0, [sp, #0x20]
10144774c: 52800022    	mov	w2, #0x1                ; =1
101447750: a9497bfd    	ldp	x29, x30, [sp, #0x90]
101447754: a9484ff4    	ldp	x20, x19, [sp, #0x80]
101447758: a94757f6    	ldp	x22, x21, [sp, #0x70]
10144775c: 910283ff    	add	sp, sp, #0xa0
101447760: 17d95bdf    	b	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101447764: a9497bfd    	ldp	x29, x30, [sp, #0x90]
101447768: a9484ff4    	ldp	x20, x19, [sp, #0x80]
10144776c: a94757f6    	ldp	x22, x21, [sp, #0x70]
101447770: 910283ff    	add	sp, sp, #0xa0
101447774: d65f03c0    	ret
101447778: 52800036    	mov	w22, #0x1               ; =1
10144777c: aa1603e0    	mov	x0, x22
101447780: aa1503e1    	mov	x1, x21
101447784: aa1403e2    	mov	x2, x20
101447788: 941a0928    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10144778c: a9005a74    	stp	x20, x22, [x19]
101447790: f9000a74    	str	x20, [x19, #0x10]
101447794: f94003e1    	ldr	x1, [sp]
101447798: b5fffce1    	cbnz	x1, 0x101447734 <__ZN17otty_autocomplete7process4exec17h82ed0cc7a8ed723eE+0xc0>
10144779c: 17ffffe9    	b	0x101447740 <__ZN17otty_autocomplete7process4exec17h82ed0cc7a8ed723eE+0xcc>
1014477a0: aa0003f3    	mov	x19, x0
1014477a4: 910003e0    	mov	x0, sp
1014477a8: 97d396a1    	bl	0x10092d22c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1a204>
1014477ac: aa1303e0    	mov	x0, x19
1014477b0: 941a0789    	bl	0x101ac95d4 <_writev+0x101ac95d4>

00000001014477b4 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E>:
1014477b4: d10643ff    	sub	sp, sp, #0x190
1014477b8: 6d112beb    	stp	d11, d10, [sp, #0x110]
1014477bc: 6d1223e9    	stp	d9, d8, [sp, #0x120]
1014477c0: a9136ffc    	stp	x28, x27, [sp, #0x130]
1014477c4: a91467fa    	stp	x26, x25, [sp, #0x140]
1014477c8: a9155ff8    	stp	x24, x23, [sp, #0x150]
1014477cc: a91657f6    	stp	x22, x21, [sp, #0x160]
1014477d0: a9174ff4    	stp	x20, x19, [sp, #0x170]
1014477d4: a9187bfd    	stp	x29, x30, [sp, #0x180]
1014477d8: 910603fd    	add	x29, sp, #0x180
1014477dc: aa0803f7    	mov	x23, x8
1014477e0: d00044c0    	adrp	x0, 0x101ce1000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x6c8c>
1014477e4: 91105c00    	add	x0, x0, #0x417
1014477e8: 910183e8    	add	x8, sp, #0x60
1014477ec: 528000e1    	mov	w1, #0x7                ; =7
1014477f0: 97ffa8ec    	bl	0x101431ba0 <__ZN17otty_autocomplete5paths15shell_dump_file17hc7f94dc49010b61aE>
1014477f4: a94687f4    	ldp	x20, x1, [sp, #0x68]
1014477f8: d102a3a8    	sub	x8, x29, #0xa8
1014477fc: aa1403e0    	mov	x0, x20
101447800: 940da3bb    	bl	0x1017b06ec <__ZN3std2fs14read_to_string5inner17h33327e834bd59c04E>
101447804: f94033e1    	ldr	x1, [sp, #0x60]
101447808: b4000081    	cbz	x1, 0x101447818 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x64>
10144780c: aa1403e0    	mov	x0, x20
101447810: 52800022    	mov	w2, #0x1                ; =1
101447814: 97d95bb2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101447818: f85583b4    	ldur	x20, [x29, #-0xa8]
10144781c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101447820: eb08029f    	cmp	x20, x8
101447824: 54000481    	b.ne	0x1014478b4 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x100>
101447828: f85603b4    	ldur	x20, [x29, #-0xa0]
10144782c: 92400688    	and	x8, x20, #0x3
101447830: f100051f    	cmp	x8, #0x1
101447834: 54000201    	b.ne	0x101447874 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0xc0>
101447838: f85ffe95    	ldr	x21, [x20, #-0x1]!
10144783c: f9400696    	ldr	x22, [x20, #0x8]
101447840: f94002c8    	ldr	x8, [x22]
101447844: b4000068    	cbz	x8, 0x101447850 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x9c>
101447848: aa1503e0    	mov	x0, x21
10144784c: d63f0100    	blr	x8
101447850: f94006c1    	ldr	x1, [x22, #0x8]
101447854: b4000081    	cbz	x1, 0x101447864 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0xb0>
101447858: f9400ac2    	ldr	x2, [x22, #0x10]
10144785c: aa1503e0    	mov	x0, x21
101447860: 97d95b9f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101447864: aa1403e0    	mov	x0, x20
101447868: 52800301    	mov	w1, #0x18               ; =24
10144786c: 52800102    	mov	w2, #0x8                ; =8
101447870: 97d95b9b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101447874: b00079a0    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101447878: 9131a000    	add	x0, x0, #0xc68
10144787c: f9400008    	ldr	x8, [x0]
101447880: d63f0100    	blr	x8
101447884: 39404008    	ldrb	w8, [x0, #0x10]
101447888: 7100051f    	cmp	w8, #0x1
10144788c: 54002721    	b.ne	0x101447d70 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x5bc>
101447890: a9400408    	ldp	x8, x1, [x0]
101447894: 91000509    	add	x9, x8, #0x1
101447898: f9000009    	str	x9, [x0]
10144789c: b0007109    	adrp	x9, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
1014478a0: 91166129    	add	x9, x9, #0x598
1014478a4: ad400520    	ldp	q0, q1, [x9]
1014478a8: ad0006e0    	stp	q0, q1, [x23]
1014478ac: a90206e8    	stp	x8, x1, [x23, #0x20]
1014478b0: 14000121    	b	0x101447d34 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x580>
1014478b4: a9764fb5    	ldp	x21, x19, [x29, #-0xa0]
1014478b8: b00079a0    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
1014478bc: 9131a000    	add	x0, x0, #0xc68
1014478c0: f9400008    	ldr	x8, [x0]
1014478c4: d63f0100    	blr	x8
1014478c8: aa0003f6    	mov	x22, x0
1014478cc: 39404008    	ldrb	w8, [x0, #0x10]
1014478d0: 7100051f    	cmp	w8, #0x1
1014478d4: a900d3f7    	stp	x23, x20, [sp, #0x8]
1014478d8: f90003f5    	str	x21, [sp]
1014478dc: 54002401    	b.ne	0x101447d5c <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x5a8>
1014478e0: a94006c0    	ldp	x0, x1, [x22]
1014478e4: 91000408    	add	x8, x0, #0x1
1014478e8: b0007109    	adrp	x9, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
1014478ec: 91166129    	add	x9, x9, #0x598
1014478f0: f90002c8    	str	x8, [x22]
1014478f4: ad400520    	ldp	q0, q1, [x9]
1014478f8: ad0187e0    	stp	q0, q1, [sp, #0x30]
1014478fc: a90507e0    	stp	x0, x1, [sp, #0x50]
101447900: a9064fff    	stp	xzr, x19, [sp, #0x60]
101447904: 910183fc    	add	x28, sp, #0x60
101447908: a9074ff5    	stp	x21, x19, [sp, #0x70]
10144790c: a9084fff    	stp	xzr, x19, [sp, #0x80]
101447910: 0f000540    	movi.2s	v0, #0xa
101447914: fd004be0    	str	d0, [sp, #0x90]
101447918: 52800034    	mov	w20, #0x1               ; =1
10144791c: 390263f4    	strb	w20, [sp, #0x98]
101447920: 0f0107a8    	movi.2s	v8, #0x3d
101447924: 790143ff    	strh	wzr, [sp, #0xa0]
101447928: 1400005b    	b	0x101447a94 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x2e0>
10144792c: 8a13035a    	and	x26, x26, x19
101447930: fc7a6b6a    	ldr	d10, [x27, x26]
101447934: 2e298d40    	cmeq.8b	v0, v10, v9
101447938: 9e660008    	fmov	x8, d0
10144793c: f201c115    	ands	x21, x8, #0x8080808080808080
101447940: 540002c0    	b.eq	0x101447998 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x1e4>
101447944: a90227eb    	stp	x11, x9, [sp, #0x20]
101447948: dac002a8    	rbit	x8, x21
10144794c: dac01108    	clz	x8, x8
101447950: 8b480f48    	add	x8, x26, x8, lsr #3
101447954: 8a130108    	and	x8, x8, x19
101447958: 52800609    	mov	w9, #0x30               ; =48
10144795c: 9b09fd08    	mneg	x8, x8, x9
101447960: 8b08037c    	add	x28, x27, x8
101447964: f85e0388    	ldur	x8, [x28, #-0x20]
101447968: eb0802df    	cmp	x22, x8
10144796c: 540000c1    	b.ne	0x101447984 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x1d0>
101447970: f85d8381    	ldur	x1, [x28, #-0x28]
101447974: aa1803e0    	mov	x0, x24
101447978: aa1603e2    	mov	x2, x22
10144797c: 941a08a8    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101447980: 34000380    	cbz	w0, 0x1014479f0 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x23c>
101447984: d10006a8    	sub	x8, x21, #0x1
101447988: ea150115    	ands	x21, x8, x21
10144798c: 910183fc    	add	x28, sp, #0x60
101447990: a94227eb    	ldp	x11, x9, [sp, #0x20]
101447994: 54fffda1    	b.ne	0x101447948 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x194>
101447998: f100057f    	cmp	x11, #0x1
10144799c: f9400fea    	ldr	x10, [sp, #0x18]
1014479a0: 54000100    	b.eq	0x1014479c0 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x20c>
1014479a4: 0e20a940    	cmlt.8b	v0, v10, #0
1014479a8: 9e660008    	fmov	x8, d0
1014479ac: b4000188    	cbz	x8, 0x1014479dc <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x228>
1014479b0: dac00108    	rbit	x8, x8
1014479b4: dac01108    	clz	x8, x8
1014479b8: 8b480f48    	add	x8, x26, x8, lsr #3
1014479bc: 8a13010a    	and	x10, x8, x19
1014479c0: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
1014479c4: 2e208d40    	cmeq.8b	v0, v10, v0
1014479c8: 2e30a800    	umaxv.8b	b0, v0
1014479cc: 1e260008    	fmov	w8, s0
1014479d0: 37000328    	tbnz	w8, #0x0, 0x101447a34 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x280>
1014479d4: 5280002b    	mov	w11, #0x1               ; =1
1014479d8: 14000002    	b	0x1014479e0 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x22c>
1014479dc: d280000b    	mov	x11, #0x0               ; =0
1014479e0: f9000fea    	str	x10, [sp, #0x18]
1014479e4: 91002129    	add	x9, x9, #0x8
1014479e8: 8b1a013a    	add	x26, x9, x26
1014479ec: 17ffffd0    	b	0x10144792c <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x178>
1014479f0: a97eef9a    	ldp	x26, x27, [x28, #-0x18]
1014479f4: a93ee797    	stp	x23, x25, [x28, #-0x18]
1014479f8: f81f8397    	stur	x23, [x28, #-0x8]
1014479fc: b40000b6    	cbz	x22, 0x101447a10 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x25c>
101447a00: aa1803e0    	mov	x0, x24
101447a04: aa1603e1    	mov	x1, x22
101447a08: 52800022    	mov	w2, #0x1                ; =1
101447a0c: 97d95b34    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101447a10: f240fb5f    	tst	x26, #0x7fffffffffffffff
101447a14: 910183fc    	add	x28, sp, #0x60
101447a18: 52800034    	mov	w20, #0x1               ; =1
101447a1c: 54000380    	b.eq	0x101447a8c <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x2d8>
101447a20: aa1b03e0    	mov	x0, x27
101447a24: aa1a03e1    	mov	x1, x26
101447a28: 52800022    	mov	w2, #0x1                ; =1
101447a2c: 97d95b2c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101447a30: 14000017    	b	0x101447a8c <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x2d8>
101447a34: 38ea6b68    	ldrsb	w8, [x27, x10]
101447a38: 36f815c8    	tbz	w8, #0x1f, 0x101447cf0 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x53c>
101447a3c: 92400108    	and	x8, x8, #0x1
101447a40: d1002149    	sub	x9, x10, #0x8
101447a44: 382a6b74    	strb	w20, [x27, x10]
101447a48: 8a130129    	and	x9, x9, x19
101447a4c: 8b090369    	add	x9, x27, x9
101447a50: 39002134    	strb	w20, [x9, #0x8]
101447a54: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
101447a58: 4e081d00    	mov.d	v0[0], x8
101447a5c: 3dc013e1    	ldr	q1, [sp, #0x40]
101447a60: 6ee08420    	sub.2d	v0, v1, v0
101447a64: 3d8013e0    	str	q0, [sp, #0x40]
101447a68: 52800608    	mov	w8, #0x30               ; =48
101447a6c: 9b08fd48    	mneg	x8, x10, x8
101447a70: 8b080368    	add	x8, x27, x8
101447a74: 3cca83e0    	ldur	q0, [sp, #0xa8]
101447a78: 3c9d0100    	stur	q0, [x8, #-0x30]
101447a7c: f9405fe9    	ldr	x9, [sp, #0xb8]
101447a80: a93e5d09    	stp	x9, x23, [x8, #-0x20]
101447a84: a93f5d19    	stp	x25, x23, [x8, #-0x10]
101447a88: 52800034    	mov	w20, #0x1               ; =1
101447a8c: 394287e8    	ldrb	w8, [sp, #0xa1]
101447a90: 37001408    	tbnz	w8, #0x0, 0x101447d10 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x55c>
101447a94: f9403bf3    	ldr	x19, [sp, #0x70]
101447a98: d102a3a0    	sub	x0, x29, #0xa8
101447a9c: 91004381    	add	x1, x28, #0x10
101447aa0: 9400950f    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101447aa4: b85583a8    	ldur	w8, [x29, #-0xa8]
101447aa8: 7100051f    	cmp	w8, #0x1
101447aac: 54000101    	b.ne	0x101447acc <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x318>
101447ab0: f85683aa    	ldur	x10, [x29, #-0x98]
101447ab4: f94033e8    	ldr	x8, [sp, #0x60]
101447ab8: cb080149    	sub	x9, x10, x8
101447abc: 8b080268    	add	x8, x19, x8
101447ac0: f90033ea    	str	x10, [sp, #0x60]
101447ac4: b50001c9    	cbnz	x9, 0x101447afc <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x348>
101447ac8: 1400001c    	b	0x101447b38 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x384>
101447acc: 394287e8    	ldrb	w8, [sp, #0xa1]
101447ad0: 37001208    	tbnz	w8, #0x0, 0x101447d10 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x55c>
101447ad4: 390287f4    	strb	w20, [sp, #0xa1]
101447ad8: 394283ea    	ldrb	w10, [sp, #0xa0]
101447adc: a94627e8    	ldp	x8, x9, [sp, #0x60]
101447ae0: 3700006a    	tbnz	w10, #0x0, 0x101447aec <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x338>
101447ae4: eb08013f    	cmp	x9, x8
101447ae8: 54001140    	b.eq	0x101447d10 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x55c>
101447aec: f9403bea    	ldr	x10, [sp, #0x70]
101447af0: cb080129    	sub	x9, x9, x8
101447af4: 8b080148    	add	x8, x10, x8
101447af8: b4000209    	cbz	x9, 0x101447b38 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x384>
101447afc: d100052a    	sub	x10, x9, #0x1
101447b00: 386a690b    	ldrb	w11, [x8, x10]
101447b04: 7100297f    	cmp	w11, #0xa
101447b08: 54000181    	b.ne	0x101447b38 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x384>
101447b0c: d1000929    	sub	x9, x9, #0x2
101447b10: b40000ca    	cbz	x10, 0x101447b28 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x374>
101447b14: 3869690b    	ldrb	w11, [x8, x9]
101447b18: 12001d6b    	and	w11, w11, #0xff
101447b1c: 7100357f    	cmp	w11, #0xd
101447b20: 9a9f010b    	csel	x11, x8, xzr, eq
101447b24: 14000002    	b	0x101447b2c <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x378>
101447b28: d280000b    	mov	x11, #0x0               ; =0
101447b2c: f100017f    	cmp	x11, #0x0
101447b30: 9a890149    	csel	x9, x10, x9, eq
101447b34: 9a8b0108    	csel	x8, x8, x11, eq
101447b38: f100192a    	subs	x10, x9, #0x6
101447b3c: 54000062    	b.hs	0x101447b48 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x394>
101447b40: d280000b    	mov	x11, #0x0               ; =0
101447b44: 1400000e    	b	0x101447b7c <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x3c8>
101447b48: 7940090b    	ldrh	w11, [x8, #0x4]
101447b4c: b940010c    	ldr	w12, [x8]
101447b50: aa0b818b    	orr	x11, x12, x11, lsl #32
101447b54: dac00d6b    	rev	x11, x11
101447b58: d2ae640c    	mov	x12, #0x73200000        ; =1931476992
101447b5c: f2cd2c2c    	movk	x12, #0x6961, lsl #32
101447b60: f2ec2d8c    	movk	x12, #0x616c, lsl #48
101447b64: eb0b019f    	cmp	x12, x11
101447b68: 1a9f97eb    	cset	w11, hi
101447b6c: 5a9f216b    	csinv	w11, w11, wzr, hs
101447b70: 9100190c    	add	x12, x8, #0x6
101447b74: 7100017f    	cmp	w11, #0x0
101447b78: 9a9f018b    	csel	x11, x12, xzr, eq
101447b7c: f100017f    	cmp	x11, #0x0
101447b80: 9a8a0133    	csel	x19, x9, x10, eq
101447b84: 9a8b0119    	csel	x25, x8, x11, eq
101447b88: a935cfb9    	stp	x25, x19, [x29, #-0xa8]
101447b8c: a936cfbf    	stp	xzr, x19, [x29, #-0x98]
101447b90: 381803b4    	sturb	w20, [x29, #-0x80]
101447b94: fc1783a8    	stur	d8, [x29, #-0x88]
101447b98: 910303e0    	add	x0, sp, #0xc0
101447b9c: d102a3a1    	sub	x1, x29, #0xa8
101447ba0: 940094cf    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101447ba4: b940c3e8    	ldr	w8, [sp, #0xc0]
101447ba8: 3607f728    	tbz	w8, #0x0, 0x101447a8c <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x2d8>
101447bac: b4fff719    	cbz	x25, 0x101447a8c <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x2d8>
101447bb0: a94ca3f6    	ldp	x22, x8, [sp, #0xc8]
101447bb4: cb080261    	sub	x1, x19, x8
101447bb8: 8b080320    	add	x0, x25, x8
101447bbc: 97d4136a    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
101447bc0: b40001c1    	cbz	x1, 0x101447bf8 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x444>
101447bc4: aa0003e8    	mov	x8, x0
101447bc8: 38401509    	ldrb	w9, [x8], #0x1
101447bcc: 12001d29    	and	w9, w9, #0xff
101447bd0: 7100893f    	cmp	w9, #0x22
101447bd4: 540006a0    	b.eq	0x101447ca8 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x4f4>
101447bd8: 71009d3f    	cmp	w9, #0x27
101447bdc: 540000e1    	b.ne	0x101447bf8 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x444>
101447be0: f100043f    	cmp	x1, #0x1
101447be4: 540000a0    	b.eq	0x101447bf8 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x444>
101447be8: d1000829    	sub	x9, x1, #0x2
101447bec: 3869690a    	ldrb	w10, [x8, x9]
101447bf0: 71009d5f    	cmp	w10, #0x27
101447bf4: 54000040    	b.eq	0x101447bfc <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x448>
101447bf8: d2800008    	mov	x8, #0x0                ; =0
101447bfc: f100011f    	cmp	x8, #0x0
101447c00: 9a890037    	csel	x23, x1, x9, eq
101447c04: 9a88001a    	csel	x26, x0, x8, eq
101447c08: b4000116    	cbz	x22, 0x101447c28 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x474>
101447c0c: 97d95ab9    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101447c10: aa1603e0    	mov	x0, x22
101447c14: 52800021    	mov	w1, #0x1                ; =1
101447c18: 97d95ab0    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101447c1c: aa0003f8    	mov	x24, x0
101447c20: b5000060    	cbnz	x0, 0x101447c2c <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x478>
101447c24: 1400005b    	b	0x101447d90 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x5dc>
101447c28: 52800038    	mov	w24, #0x1               ; =1
101447c2c: aa1803e0    	mov	x0, x24
101447c30: aa1903e1    	mov	x1, x25
101447c34: aa1603e2    	mov	x2, x22
101447c38: 941a07fc    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101447c3c: a90ae3f6    	stp	x22, x24, [sp, #0xa8]
101447c40: f9005ff6    	str	x22, [sp, #0xb8]
101447c44: b4000117    	cbz	x23, 0x101447c64 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x4b0>
101447c48: 97d95aaa    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101447c4c: aa1703e0    	mov	x0, x23
101447c50: 52800021    	mov	w1, #0x1                ; =1
101447c54: 97d95aa1    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101447c58: aa0003f9    	mov	x25, x0
101447c5c: b5000060    	cbnz	x0, 0x101447c68 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x4b4>
101447c60: 14000050    	b	0x101447da0 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x5ec>
101447c64: 52800039    	mov	w25, #0x1               ; =1
101447c68: aa1903e0    	mov	x0, x25
101447c6c: aa1a03e1    	mov	x1, x26
101447c70: aa1703e2    	mov	x2, x23
101447c74: 941a07ed    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101447c78: a94507e0    	ldp	x0, x1, [sp, #0x50]
101447c7c: 9102a3e2    	add	x2, sp, #0xa8
101447c80: 97d416ff    	bl	0x10094d87c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a854>
101447c84: aa0003fa    	mov	x26, x0
101447c88: f94023e8    	ldr	x8, [sp, #0x40]
101447c8c: b4000248    	cbz	x8, 0x101447cd4 <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x520>
101447c90: d280000b    	mov	x11, #0x0               ; =0
101447c94: d2800009    	mov	x9, #0x0                ; =0
101447c98: a9434ffb    	ldp	x27, x19, [sp, #0x30]
101447c9c: d379ff54    	lsr	x20, x26, #57
101447ca0: 0e010e89    	dup.8b	v9, w20
101447ca4: 17ffff22    	b	0x10144792c <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x178>
101447ca8: f100043f    	cmp	x1, #0x1
101447cac: 54000081    	b.ne	0x101447cbc <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x508>
101447cb0: d2800008    	mov	x8, #0x0                ; =0
101447cb4: 92800009    	mov	x9, #-0x1               ; =-1
101447cb8: 17ffffd1    	b	0x101447bfc <__ZN17otty_autocomplete7sources13shell_aliases17hbc7d33db04143553E+0x448>
101447cbc: d1000829    	sub	x9, x1, #0x2
101447cc0: 3869690a    	ldrb	w10, [x8, x9]
101447cc4: 12001d4a    	and	w10, w10, #0xff
101447cc8: 7100895f    	cmp	w10, #0x22
