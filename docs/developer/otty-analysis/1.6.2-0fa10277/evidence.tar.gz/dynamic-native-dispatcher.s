
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010140fc68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E>:
10140ffc8: 6db82beb    	stp	d11, d10, [sp, #-0x80]!
10140ffcc: 6d0123e9    	stp	d9, d8, [sp, #0x10]
10140ffd0: a9026ffc    	stp	x28, x27, [sp, #0x20]
10140ffd4: a90367fa    	stp	x26, x25, [sp, #0x30]
10140ffd8: a9045ff8    	stp	x24, x23, [sp, #0x40]
10140ffdc: a90557f6    	stp	x22, x21, [sp, #0x50]
10140ffe0: a9064ff4    	stp	x20, x19, [sp, #0x60]
10140ffe4: a9077bfd    	stp	x29, x30, [sp, #0x70]
10140ffe8: 9101c3fd    	add	x29, sp, #0x70
10140ffec: d14007ff    	sub	sp, sp, #0x1, lsl #12   ; =0x1000
10140fff0: f90003ff    	str	xzr, [sp]
10140fff4: d10f03ff    	sub	sp, sp, #0x3c0
10140fff8: aa0303f9    	mov	x25, x3
10140fffc: aa0003f7    	mov	x23, x0
101410000: f100145f    	cmp	x2, #0x5
101410004: 5400040c    	b.gt	0x101410084 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x41c>
101410008: f1000c5f    	cmp	x2, #0x3
10141000c: 54000640    	b.eq	0x1014100d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x46c>
101410010: f100105f    	cmp	x2, #0x4
101410014: 54000d60    	b.eq	0x1014101c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x558>
101410018: f100145f    	cmp	x2, #0x5
10141001c: 54001521    	b.ne	0x1014102c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x658>
101410020: b9400028    	ldr	w8, [x1]
101410024: 39401029    	ldrb	w9, [x1, #0x4]
101410028: 528c2c6a    	mov	w10, #0x6163            ; =24931
10141002c: 72acee4a    	movk	w10, #0x6772, lsl #16
101410030: 6b0a011f    	cmp	w8, w10
101410034: 52800de8    	mov	w8, #0x6f               ; =111
101410038: 7a480120    	ccmp	w9, w8, #0x0, eq
10141003c: 54002980    	b.eq	0x10141056c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x904>
101410040: b9400028    	ldr	w8, [x1]
101410044: 39401029    	ldrb	w9, [x1, #0x4]
101410048: 528dacea    	mov	w10, #0x6d67            ; =28007
10141004c: 72ad6c2a    	movk	w10, #0x6b61, lsl #16
101410050: 6b0a011f    	cmp	w8, w10
101410054: 52800ca8    	mov	w8, #0x65               ; =101
101410058: 7a480120    	ccmp	w9, w8, #0x0, eq
10141005c: 540029a0    	b.eq	0x101410590 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x928>
101410060: b9400028    	ldr	w8, [x1]
101410064: 39401029    	ldrb	w9, [x1, #0x4]
101410068: 528d0eea    	mov	w10, #0x6877            ; =26743
10141006c: 72ac6d2a    	movk	w10, #0x6369, lsl #16
101410070: 6b0a011f    	cmp	w8, w10
101410074: 52800d08    	mov	w8, #0x68               ; =104
101410078: 7a480120    	ccmp	w9, w8, #0x0, eq
10141007c: 54001221    	b.ne	0x1014102c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x658>
101410080: 14000093    	b	0x1014102cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x664>
101410084: f100185f    	cmp	x2, #0x6
101410088: 540007a0    	b.eq	0x10141017c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x514>
10141008c: f1001c5f    	cmp	x2, #0x7
101410090: 54001060    	b.eq	0x10141029c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x634>
101410094: f100385f    	cmp	x2, #0xe
101410098: 54001141    	b.ne	0x1014102c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x658>
10141009c: f9400028    	ldr	x8, [x1]
1014100a0: f8406029    	ldur	x9, [x1, #0x6]
1014100a4: d28dec8a    	mov	x10, #0x6f64            ; =28516
1014100a8: f2ad6c6a    	movk	x10, #0x6b63, lsl #16
1014100ac: f2ce4caa    	movk	x10, #0x7265, lsl #32
1014100b0: f2ec65aa    	movk	x10, #0x632d, lsl #48
1014100b4: eb0a011f    	cmp	x8, x10
1014100b8: d28c65a8    	mov	x8, #0x632d             ; =25389
1014100bc: f2adade8    	movk	x8, #0x6d6f, lsl #16
1014100c0: f2cdee08    	movk	x8, #0x6f70, lsl #32
1014100c4: f2ecae68    	movk	x8, #0x6573, lsl #48
1014100c8: fa480120    	ccmp	x9, x8, #0x0, eq
1014100cc: 54000fa1    	b.ne	0x1014102c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x658>
1014100d0: 14000087    	b	0x1014102ec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x684>
1014100d4: 79400028    	ldrh	w8, [x1]
1014100d8: 39400829    	ldrb	w9, [x1, #0x2]
1014100dc: 528d2cea    	mov	w10, #0x6967            ; =26983
1014100e0: 6b0a011f    	cmp	w8, w10
1014100e4: 52800e88    	mov	w8, #0x74               ; =116
1014100e8: 7a480120    	ccmp	w9, w8, #0x0, eq
1014100ec: 54001940    	b.eq	0x101410414 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ac>
1014100f0: 79400029    	ldrh	w9, [x1]
1014100f4: 3940082a    	ldrb	w10, [x1, #0x2]
1014100f8: 528e0dc8    	mov	w8, #0x706e             ; =28782
1014100fc: 6b08013f    	cmp	w9, w8
101410100: 52800da9    	mov	w9, #0x6d               ; =109
101410104: 7a490140    	ccmp	w10, w9, #0x0, eq
101410108: 54000ba0    	b.eq	0x10141027c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x614>
10141010c: 79400029    	ldrh	w9, [x1]
101410110: 3940082a    	ldrb	w10, [x1, #0x2]
101410114: 6b08013f    	cmp	w9, w8
101410118: 52800f08    	mov	w8, #0x78               ; =120
10141011c: 7a480140    	ccmp	w10, w8, #0x0, eq
101410120: 54000ae0    	b.eq	0x10141027c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x614>
101410124: 79400028    	ldrh	w8, [x1]
101410128: 39400829    	ldrb	w9, [x1, #0x2]
10141012c: 528eac4a    	mov	w10, #0x7562            ; =30050
101410130: 6b0a011f    	cmp	w8, w10
101410134: 52800dc8    	mov	w8, #0x6e               ; =110
101410138: 7a480120    	ccmp	w9, w8, #0x0, eq
10141013c: 54000a00    	b.eq	0x10141027c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x614>
101410140: 79400028    	ldrh	w8, [x1]
101410144: 39400829    	ldrb	w9, [x1, #0x2]
101410148: 528e6e6a    	mov	w10, #0x7373            ; =29555
10141014c: 6b0a011f    	cmp	w8, w10
101410150: 52800d08    	mov	w8, #0x68               ; =104
101410154: 7a480120    	ccmp	w9, w8, #0x0, eq
101410158: 540045c0    	b.eq	0x101410a10 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xda8>
10141015c: 79400028    	ldrh	w8, [x1]
101410160: 39400829    	ldrb	w9, [x1, #0x2]
101410164: 528c6e6a    	mov	w10, #0x6373            ; =25459
101410168: 6b0a011f    	cmp	w8, w10
10141016c: 52800e08    	mov	w8, #0x70               ; =112
101410170: 7a480120    	ccmp	w9, w8, #0x0, eq
101410174: 54000a61    	b.ne	0x1014102c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x658>
101410178: 14000226    	b	0x101410a10 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xda8>
10141017c: b9400028    	ldr	w8, [x1]
101410180: 79400829    	ldrh	w9, [x1, #0x4]
101410184: 528dec8a    	mov	w10, #0x6f64            ; =28516
101410188: 72ad6c6a    	movk	w10, #0x6b63, lsl #16
10141018c: 6b0a011f    	cmp	w8, w10
101410190: 528e4ca8    	mov	w8, #0x7265             ; =29285
101410194: 7a480120    	ccmp	w9, w8, #0x0, eq
101410198: 54000aa0    	b.eq	0x1014102ec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x684>
10141019c: b9400028    	ldr	w8, [x1]
1014101a0: 79400829    	ldrh	w9, [x1, #0x4]
1014101a4: 528d0eea    	mov	w10, #0x6877            ; =26743
1014101a8: 72adccaa    	movk	w10, #0x6e65, lsl #16
1014101ac: 6b0a011f    	cmp	w8, w10
1014101b0: 528cac68    	mov	w8, #0x6563             ; =25955
1014101b4: 7a480120    	ccmp	w9, w8, #0x0, eq
1014101b8: 54000841    	b.ne	0x1014102c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x658>
1014101bc: 14000044    	b	0x1014102cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x664>
1014101c0: b9400028    	ldr	w8, [x1]
1014101c4: 528dce09    	mov	w9, #0x6e70             ; =28272
1014101c8: 72adae09    	movk	w9, #0x6d70, lsl #16
1014101cc: 6b09011f    	cmp	w8, w9
1014101d0: 54000560    	b.eq	0x10141027c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x614>
1014101d4: b9400028    	ldr	w8, [x1]
1014101d8: 528c2f29    	mov	w9, #0x6179             ; =24953
1014101dc: 72adce49    	movk	w9, #0x6e72, lsl #16
1014101e0: 6b09011f    	cmp	w8, w9
1014101e4: 540004c0    	b.eq	0x10141027c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x614>
1014101e8: b9400028    	ldr	w8, [x1]
1014101ec: 528eac49    	mov	w9, #0x7562             ; =30050
1014101f0: 72af0dc9    	movk	w9, #0x786e, lsl #16
1014101f4: 6b09011f    	cmp	w8, w9
1014101f8: 54000420    	b.eq	0x10141027c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x614>
1014101fc: b9400028    	ldr	w8, [x1]
101410200: 528c2da9    	mov	w9, #0x616d             ; =24941
101410204: 72acad69    	movk	w9, #0x656b, lsl #16
101410208: 6b09011f    	cmp	w8, w9
10141020c: 54001c20    	b.eq	0x101410590 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x928>
101410210: b9400028    	ldr	w8, [x1]
101410214: 528cce69    	mov	w9, #0x6673             ; =26227
101410218: 72ae0e89    	movk	w9, #0x7074, lsl #16
10141021c: 6b09011f    	cmp	w8, w9
101410220: 54003f80    	b.eq	0x101410a10 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xda8>
101410224: b9400028    	ldr	w8, [x1]
101410228: 528f2e89    	mov	w9, #0x7974             ; =31092
10141022c: 72acae09    	movk	w9, #0x6570, lsl #16
101410230: 6b09011f    	cmp	w8, w9
101410234: 540004c0    	b.eq	0x1014102cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x664>
101410238: b9400028    	ldr	w8, [x1]
10141023c: 528dec69    	mov	w9, #0x6f63             ; =28515
101410240: 72ae0da9    	movk	w9, #0x706d, lsl #16
101410244: 11181d29    	add	w9, w9, #0x607
101410248: 6b09011f    	cmp	w8, w9
10141024c: 540003a1    	b.ne	0x1014102c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x658>
101410250: f9401f35    	ldr	x21, [x25, #0x38]
101410254: b400fbb5    	cbz	x21, 0x1014121c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2560>
101410258: 940ed895    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
10141025c: f9403b28    	ldr	x8, [x25, #0x70]
101410260: eb08001f    	cmp	x0, x8
101410264: 5400f281    	b.ne	0x1014120b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x244c>
101410268: aa0803fb    	mov	x27, x8
10141026c: b9407b28    	ldr	w8, [x25, #0x78]
101410270: 6b08003f    	cmp	w1, w8
101410274: 5400f263    	b.lo	0x1014120c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2458>
101410278: 140007d4    	b	0x1014121c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2560>
10141027c: 940ed88c    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101410280: f9403b3a    	ldr	x26, [x25, #0x70]
101410284: eb1a001f    	cmp	x0, x26
101410288: 54000421    	b.ne	0x10141030c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6a4>
10141028c: b9407b28    	ldr	w8, [x25, #0x78]
101410290: 6b08003f    	cmp	w1, w8
101410294: 54000403    	b.lo	0x101410314 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6ac>
101410298: 140008aa    	b	0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
10141029c: b9400028    	ldr	w8, [x1]
1014102a0: b8403029    	ldur	w9, [x1, #0x3]
1014102a4: 528dec6a    	mov	w10, #0x6f63            ; =28515
1014102a8: 72adadaa    	movk	w10, #0x6d6d, lsl #16
1014102ac: 6b0a011f    	cmp	w8, w10
1014102b0: 528c2da8    	mov	w8, #0x616d             ; =24941
1014102b4: 72ac8dc8    	movk	w8, #0x646e, lsl #16
1014102b8: 7a480120    	ccmp	w9, w8, #0x0, eq
1014102bc: 54000080    	b.eq	0x1014102cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x664>
1014102c0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014102c4: f90002e8    	str	x8, [x23]
1014102c8: 1400197f    	b	0x1014168c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c5c>
1014102cc: 940ed878    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
1014102d0: f9403b28    	ldr	x8, [x25, #0x70]
1014102d4: eb08001f    	cmp	x0, x8
1014102d8: 54000581    	b.ne	0x101410388 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x720>
1014102dc: b9407b28    	ldr	w8, [x25, #0x78]
1014102e0: 6b08003f    	cmp	w1, w8
1014102e4: 54000563    	b.lo	0x101410390 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x728>
1014102e8: 140000b4    	b	0x1014105b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x950>
1014102ec: 940ed870    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
1014102f0: f9403b28    	ldr	x8, [x25, #0x70]
1014102f4: eb08001f    	cmp	x0, x8
1014102f8: 54000a41    	b.ne	0x101410440 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d8>
1014102fc: b9407b28    	ldr	w8, [x25, #0x78]
101410300: 6b08003f    	cmp	w1, w8
101410304: 54000a23    	b.lo	0x101410448 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e0>
101410308: 14000397    	b	0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
10141030c: eb1a001f    	cmp	x0, x26
101410310: 5401118a    	b.ge	0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
101410314: f9401728    	ldr	x8, [x25, #0x28]
101410318: b4011148    	cbz	x8, 0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
10141031c: f940132b    	ldr	x11, [x25, #0x20]
101410320: a940a969    	ldp	x9, x10, [x11, #0x8]
101410324: f100115f    	cmp	x10, #0x4
101410328: 540038a0    	b.eq	0x101410a3c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xdd4>
10141032c: f1000d5f    	cmp	x10, #0x3
101410330: 54011081    	b.ne	0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
101410334: 7940012a    	ldrh	w10, [x9]
101410338: 3940092b    	ldrb	w11, [x9, #0x2]
10141033c: 528e0dc8    	mov	w8, #0x706e             ; =28782
101410340: 6b08015f    	cmp	w10, w8
101410344: 52800f0a    	mov	w10, #0x78              ; =120
101410348: 7a4a0160    	ccmp	w11, w10, #0x0, eq
10141034c: 5400f540    	b.eq	0x1014121f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x258c>
101410350: 7940012a    	ldrh	w10, [x9]
101410354: 3940092b    	ldrb	w11, [x9, #0x2]
101410358: 6b08015f    	cmp	w10, w8
10141035c: 52800da8    	mov	w8, #0x6d               ; =109
101410360: 7a480160    	ccmp	w11, w8, #0x0, eq
101410364: 540038a0    	b.eq	0x101410a78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xe10>
101410368: 79400128    	ldrh	w8, [x9]
10141036c: 39400929    	ldrb	w9, [x9, #0x2]
101410370: 528eac4a    	mov	w10, #0x7562            ; =30050
101410374: 6b0a011f    	cmp	w8, w10
101410378: 52800dc8    	mov	w8, #0x6e               ; =110
10141037c: 7a480120    	ccmp	w9, w8, #0x0, eq
101410380: 54010e01    	b.ne	0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
101410384: 140001bd    	b	0x101410a78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xe10>
101410388: eb08001f    	cmp	x0, x8
10141038c: 5400116a    	b.ge	0x1014105b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x950>
101410390: f9400f2c    	ldr	x12, [x25, #0x18]
101410394: f9401f21    	ldr	x1, [x25, #0x38]
101410398: f9401728    	ldr	x8, [x25, #0x28]
10141039c: f1000509    	subs	x9, x8, #0x1
1014103a0: 9a8933e9    	csel	x9, xzr, x9, lo
1014103a4: f100003f    	cmp	x1, #0x0
1014103a8: 9a890109    	csel	x9, x8, x9, eq
1014103ac: 9100058a    	add	x10, x12, #0x1
1014103b0: eb09015f    	cmp	x10, x9
1014103b4: 540010e2    	b.hs	0x1014105d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x968>
1014103b8: d280000b    	mov	x11, #0x0               ; =0
1014103bc: f940132d    	ldr	x13, [x25, #0x20]
1014103c0: 5280030e    	mov	w14, #0x18              ; =24
1014103c4: 9b0e358c    	madd	x12, x12, x14, x13
1014103c8: 9100a18c    	add	x12, x12, #0x28
1014103cc: 14000007    	b	0x1014103e8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x780>
1014103d0: d280000d    	mov	x13, #0x0               ; =0
1014103d4: 9100054a    	add	x10, x10, #0x1
1014103d8: 8b0b01ab    	add	x11, x13, x11
1014103dc: 9100618c    	add	x12, x12, #0x18
1014103e0: eb0a013f    	cmp	x9, x10
1014103e4: 54000e80    	b.eq	0x1014105b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x94c>
1014103e8: eb08015f    	cmp	x10, x8
1014103ec: 54ffff22    	b.hs	0x1014103d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x768>
1014103f0: f940018d    	ldr	x13, [x12]
1014103f4: b40000cd    	cbz	x13, 0x10141040c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7a4>
1014103f8: f85f818d    	ldur	x13, [x12, #-0x8]
1014103fc: 394001ad    	ldrb	w13, [x13]
101410400: 7100b5bf    	cmp	w13, #0x2d
101410404: 1a9f07ed    	cset	w13, ne
101410408: 17fffff3    	b	0x1014103d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x76c>
10141040c: 5280002d    	mov	w13, #0x1               ; =1
101410410: 17fffff1    	b	0x1014103d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x76c>
101410414: 940ed826    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101410418: f9403b38    	ldr	x24, [x25, #0x70]
10141041c: eb18001f    	cmp	x0, x24
101410420: 54001581    	b.ne	0x1014106d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xa68>
101410424: b9407b28    	ldr	w8, [x25, #0x78]
101410428: 6b08003f    	cmp	w1, w8
10141042c: 54001563    	b.lo	0x1014106d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xa70>
101410430: d280001a    	mov	x26, #0x0               ; =0
101410434: d2800008    	mov	x8, #0x0                ; =0
101410438: 52800109    	mov	w9, #0x8                ; =8
10141043c: 14000f30    	b	0x1014140fc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4494>
101410440: eb08001f    	cmp	x0, x8
101410444: 5400690a    	b.ge	0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
101410448: f9401728    	ldr	x8, [x25, #0x28]
10141044c: b40068c8    	cbz	x8, 0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
101410450: f9401329    	ldr	x9, [x25, #0x20]
101410454: a940a528    	ldp	x8, x9, [x9, #0x8]
101410458: f100193f    	cmp	x9, #0x6
10141045c: 54006740    	b.eq	0x101411144 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14dc>
101410460: f100393f    	cmp	x9, #0xe
101410464: 54006801    	b.ne	0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
101410468: f9400109    	ldr	x9, [x8]
10141046c: f8406108    	ldur	x8, [x8, #0x6]
101410470: d28dec8a    	mov	x10, #0x6f64            ; =28516
101410474: f2ad6c6a    	movk	x10, #0x6b63, lsl #16
101410478: f2ce4caa    	movk	x10, #0x7265, lsl #32
10141047c: f2ec65aa    	movk	x10, #0x632d, lsl #48
101410480: eb0a013f    	cmp	x9, x10
101410484: d28c65a9    	mov	x9, #0x632d             ; =25389
101410488: f2adade9    	movk	x9, #0x6d6f, lsl #16
10141048c: f2cdee09    	movk	x9, #0x6f70, lsl #32
101410490: f2ecae69    	movk	x9, #0x6573, lsl #48
101410494: fa490100    	ccmp	x8, x9, #0x0, eq
101410498: 54006661    	b.ne	0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
10141049c: a9412329    	ldp	x9, x8, [x25, #0x10]
1014104a0: b4006628    	cbz	x8, 0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
1014104a4: d2800013    	mov	x19, #0x0               ; =0
1014104a8: a940a528    	ldp	x8, x9, [x9, #0x8]
1014104ac: 52800114    	mov	w20, #0x8               ; =8
1014104b0: f100113f    	cmp	x9, #0x4
1014104b4: 5400db2c    	b.gt	0x101412018 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x23b0>
1014104b8: f100093f    	cmp	x9, #0x2
1014104bc: 54012e80    	b.eq	0x101412a8c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2e24>
1014104c0: f1000d3f    	cmp	x9, #0x3
1014104c4: 540132c0    	b.eq	0x101412b1c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2eb4>
1014104c8: aa1703f6    	mov	x22, x23
1014104cc: aa1303f7    	mov	x23, x19
1014104d0: f100113f    	cmp	x9, #0x4
1014104d4: 54006501    	b.ne	0x101411174 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x150c>
1014104d8: b9400109    	ldr	w9, [x8]
1014104dc: 528e8e6a    	mov	w10, #0x7473            ; =29811
1014104e0: 72ae0dea    	movk	w10, #0x706f, lsl #16
1014104e4: 6b0a013f    	cmp	w9, w10
1014104e8: aa1603f7    	mov	x23, x22
1014104ec: 54013420    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
1014104f0: 528eae09    	mov	w9, #0x7570             ; =30064
1014104f4: 72ad8d89    	movk	w9, #0x6c6c, lsl #16
1014104f8: b940010a    	ldr	w10, [x8]
1014104fc: 5130152b    	sub	w11, w9, #0xc05
101410500: 6b0a017f    	cmp	w11, w10
101410504: 54013360    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101410508: b940010a    	ldr	w10, [x8]
10141050c: 528ded8b    	mov	w11, #0x6f6c            ; =28524
101410510: 72ae6ceb    	movk	w11, #0x7367, lsl #16
101410514: 6b0b015f    	cmp	w10, w11
101410518: 540132c0    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
10141051c: b940010a    	ldr	w10, [x8]
101410520: 528f0cab    	mov	w11, #0x7865            ; =30821
101410524: 72ac6cab    	movk	w11, #0x6365, lsl #16
101410528: 6b0b015f    	cmp	w10, w11
10141052c: 54013220    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101410530: b940010a    	ldr	w10, [x8]
101410534: 6b0a013f    	cmp	w9, w10
101410538: 540131c0    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
10141053c: b9400109    	ldr	w9, [x8]
101410540: 528eae0a    	mov	w10, #0x7570            ; =30064
101410544: 72ad0e6a    	movk	w10, #0x6873, lsl #16
101410548: 6b0a013f    	cmp	w9, w10
10141054c: 54013120    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101410550: b9400108    	ldr	w8, [x8]
101410554: 528c2e89    	mov	w9, #0x6174             ; =24948
101410558: 72ae8e49    	movk	w9, #0x7472, lsl #16
10141055c: 1137f129    	add	w9, w9, #0xdfc
101410560: 6b08013f    	cmp	w9, w8
101410564: 54006021    	b.ne	0x101411168 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1500>
101410568: 14000982    	b	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
10141056c: aa1703fc    	mov	x28, x23
101410570: 940ed7cf    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101410574: f9403b3a    	ldr	x26, [x25, #0x70]
101410578: eb1a001f    	cmp	x0, x26
10141057c: 54000f61    	b.ne	0x101410768 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xb00>
101410580: b9407b28    	ldr	w8, [x25, #0x78]
101410584: 6b08003f    	cmp	w1, w8
101410588: 54000f43    	b.lo	0x101410770 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xb08>
10141058c: 14000fcd    	b	0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
101410590: 940ed7c7    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101410594: f9403b28    	ldr	x8, [x25, #0x70]
101410598: eb08001f    	cmp	x0, x8
10141059c: f90037f7    	str	x23, [sp, #0x68]
1014105a0: 54001281    	b.ne	0x1014107f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xb88>
1014105a4: b9407b28    	ldr	w8, [x25, #0x78]
1014105a8: 6b08003f    	cmp	w1, w8
1014105ac: 54001263    	b.lo	0x1014107f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xb90>
1014105b0: 14000111    	b	0x1014109f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xd8c>
1014105b4: b40000eb    	cbz	x11, 0x1014105d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x968>
1014105b8: d2800015    	mov	x21, #0x0               ; =0
1014105bc: d2800018    	mov	x24, #0x0               ; =0
1014105c0: 52800113    	mov	w19, #0x8               ; =8
1014105c4: a9004ef8    	stp	x24, x19, [x23]
1014105c8: f9000af5    	str	x21, [x23, #0x10]
1014105cc: 140018be    	b	0x1014168c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c5c>
1014105d0: f90037f7    	str	x23, [sp, #0x68]
1014105d4: b40028e1    	cbz	x1, 0x101410af0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xe88>
1014105d8: f9401b20    	ldr	x0, [x25, #0x30]
1014105dc: d10363b3    	sub	x19, x29, #0xd8
1014105e0: d10363a8    	sub	x8, x29, #0xd8
1014105e4: 940fec54    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
1014105e8: a9442320    	ldp	x0, x8, [x25, #0x40]
1014105ec: f9401509    	ldr	x9, [x8, #0x28]
1014105f0: 912783e8    	add	x8, sp, #0x9e0
1014105f4: d63f0120    	blr	x9
1014105f8: f944f3ea    	ldr	x10, [sp, #0x9e0]
1014105fc: f944f7f4    	ldr	x20, [sp, #0x9e8]
101410600: f944fbe8    	ldr	x8, [sp, #0x9f0]
101410604: 52800309    	mov	w9, #0x18               ; =24
101410608: 9b09511a    	madd	x26, x8, x9, x20
10141060c: f904f3f4    	str	x20, [sp, #0x9e0]
101410610: f9005fea    	str	x10, [sp, #0xb8]
101410614: f904fbea    	str	x10, [sp, #0x9f0]
101410618: f904fffa    	str	x26, [sp, #0x9f8]
10141061c: f90503f3    	str	x19, [sp, #0xa00]
101410620: aa1403f5    	mov	x21, x20
101410624: b4000ba8    	cbz	x8, 0x101410798 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xb30>
101410628: 9100629b    	add	x27, x20, #0x18
10141062c: aa1403f5    	mov	x21, x20
101410630: 14000008    	b	0x101410650 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x9e8>
101410634: a9005ab3    	stp	x19, x22, [x21]
101410638: f9000ab7    	str	x23, [x21, #0x10]
10141063c: 910062b5    	add	x21, x21, #0x18
101410640: 9100637b    	add	x27, x27, #0x18
101410644: 91006388    	add	x8, x28, #0x18
101410648: eb1a011f    	cmp	x8, x26
10141064c: 54000a60    	b.eq	0x101410798 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xb30>
101410650: aa1b03fc    	mov	x28, x27
101410654: a9fedb93    	ldp	x19, x22, [x28, #-0x18]!
101410658: f9400b97    	ldr	x23, [x28, #0x10]
10141065c: 910403e8    	add	x8, sp, #0x100
101410660: aa1603e0    	mov	x0, x22
101410664: aa1703e1    	mov	x1, x23
101410668: 940fec33    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
10141066c: a950a3f8    	ldp	x24, x8, [sp, #0x108]
101410670: f85383a2    	ldur	x2, [x29, #-0xc8]
101410674: eb02011f    	cmp	x8, x2
101410678: 540000a2    	b.hs	0x10141068c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xa24>
10141067c: 52800019    	mov	w25, #0x0               ; =0
101410680: f94083e1    	ldr	x1, [sp, #0x100]
101410684: b5000121    	cbnz	x1, 0x1014106a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xa40>
101410688: 1400000b    	b	0x1014106b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xa4c>
10141068c: f85303a0    	ldur	x0, [x29, #-0xd0]
101410690: aa1803e1    	mov	x1, x24
101410694: 941ae562    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101410698: 7100001f    	cmp	w0, #0x0
10141069c: 1a9f17f9    	cset	w25, eq
1014106a0: f94083e1    	ldr	x1, [sp, #0x100]
1014106a4: b4000081    	cbz	x1, 0x1014106b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xa4c>
1014106a8: aa1803e0    	mov	x0, x24
1014106ac: 52800022    	mov	w2, #0x1                ; =1
1014106b0: 97da380b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014106b4: 3707fc19    	tbnz	w25, #0x0, 0x101410634 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x9cc>
1014106b8: b4fffc53    	cbz	x19, 0x101410640 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x9d8>
1014106bc: aa1603e0    	mov	x0, x22
1014106c0: aa1303e1    	mov	x1, x19
1014106c4: 52800022    	mov	w2, #0x1                ; =1
1014106c8: 97da3805    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014106cc: 17ffffdd    	b	0x101410640 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x9d8>
1014106d0: eb18001f    	cmp	x0, x24
1014106d4: 54ffeaea    	b.ge	0x101410430 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c8>
1014106d8: 52800108    	mov	w8, #0x8                ; =8
1014106dc: a90c23ff    	stp	xzr, x8, [sp, #0xc0]
1014106e0: f9006bff    	str	xzr, [sp, #0xd0]
1014106e4: f9400f22    	ldr	x2, [x25, #0x18]
1014106e8: b400aac2    	cbz	x2, 0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
1014106ec: f9400b21    	ldr	x1, [x25, #0x10]
1014106f0: a940a428    	ldp	x8, x9, [x1, #0x8]
1014106f4: f100153f    	cmp	x9, #0x5
1014106f8: 5400664d    	b.le	0x1014113c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1758>
1014106fc: f1001d3f    	cmp	x9, #0x7
101410700: 5400934c    	b.gt	0x101411968 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1d00>
101410704: f100193f    	cmp	x9, #0x6
101410708: 5400a440    	b.eq	0x101411b90 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1f28>
10141070c: f1001d3f    	cmp	x9, #0x7
101410710: 5400a981    	b.ne	0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
101410714: b9400109    	ldr	w9, [x8]
101410718: b8403108    	ldur	w8, [x8, #0x3]
10141071c: 528cae4a    	mov	w10, #0x6572            ; =25970
101410720: 72ae8e6a    	movk	w10, #0x7473, lsl #16
101410724: 6b0a013f    	cmp	w9, w10
101410728: 528dee89    	mov	w9, #0x6f74             ; =28532
10141072c: 72acae49    	movk	w9, #0x6572, lsl #16
101410730: 7a490100    	ccmp	w8, w9, #0x0, eq
101410734: 5400a861    	b.ne	0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
101410738: f9401728    	ldr	x8, [x25, #0x28]
10141073c: b400fe48    	cbz	x8, 0x101412704 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2a9c>
101410740: 8b080508    	add	x8, x8, x8, lsl #1
101410744: f940132a    	ldr	x10, [x25, #0x20]
101410748: d37df108    	lsl	x8, x8, #3
10141074c: d285a5a9    	mov	x9, #0x2d2d             ; =11565
101410750: f2ae8e69    	movk	x9, #0x7473, lsl #16
101410754: f2ccec29    	movk	x9, #0x6761, lsl #32
101410758: f2ec8ca9    	movk	x9, #0x6465, lsl #48
10141075c: 9100414a    	add	x10, x10, #0x10
101410760: 528a65ab    	mov	w11, #0x532d            ; =21293
101410764: 140004c5    	b	0x101411a78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1e10>
101410768: eb1a001f    	cmp	x0, x26
10141076c: 5401eaaa    	b.ge	0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
101410770: f9400336    	ldr	x22, [x25]
101410774: b401ea76    	cbz	x22, 0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
101410778: f9400737    	ldr	x23, [x25, #0x8]
10141077c: f9401f29    	ldr	x9, [x25, #0x38]
101410780: f9401728    	ldr	x8, [x25, #0x28]
101410784: b4007489    	cbz	x9, 0x101411614 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x19ac>
101410788: f100091f    	cmp	x8, #0x2
10141078c: 5401e9a3    	b.lo	0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
101410790: 92800029    	mov	x9, #-0x2               ; =-2
101410794: 140003a2    	b	0x10141161c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x19b4>
101410798: cb1402b3    	sub	x19, x21, x20
10141079c: d343fe68    	lsr	x8, x19, #3
1014107a0: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
1014107a4: f2955569    	movk	x9, #0xaaab
1014107a8: 9b097d15    	mul	x21, x8, x9
1014107ac: f9405ff9    	ldr	x25, [sp, #0xb8]
1014107b0: a93453b9    	stp	x25, x20, [x29, #-0xc0]
1014107b4: f81503b5    	stur	x21, [x29, #-0xb0]
1014107b8: f100c27f    	cmp	x19, #0x30
1014107bc: 54023782    	b.hs	0x101414eac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5244>
1014107c0: 52800d08    	mov	w8, #0x68               ; =104
1014107c4: 9b087eb6    	mul	x22, x21, x8
1014107c8: 8b130297    	add	x23, x20, x19
1014107cc: b4005356    	cbz	x22, 0x101411234 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x15cc>
1014107d0: 97da37c8    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014107d4: aa1603e0    	mov	x0, x22
1014107d8: 52800101    	mov	w1, #0x8                ; =8
1014107dc: 97da37bf    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014107e0: b40317c0    	cbz	x0, 0x101416ad8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6e70>
1014107e4: aa0003f3    	mov	x19, x0
1014107e8: aa1503f8    	mov	x24, x21
1014107ec: 14000294    	b	0x10141123c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x15d4>
1014107f0: eb08001f    	cmp	x0, x8
1014107f4: 5400100a    	b.ge	0x1014109f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xd8c>
1014107f8: f9400333    	ldr	x19, [x25]
1014107fc: b4000ff3    	cbz	x19, 0x1014109f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xd90>
101410800: f9400734    	ldr	x20, [x25, #0x8]
101410804: f0004662    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101410808: 9120f442    	add	x2, x2, #0x83d
10141080c: 912783e8    	add	x8, sp, #0x9e0
101410810: aa1303e0    	mov	x0, x19
101410814: aa1403e1    	mov	x1, x20
101410818: 52800163    	mov	w3, #0xb                ; =11
10141081c: 940ecea0    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101410820: f944f7f5    	ldr	x21, [sp, #0x9e8]
101410824: f944fbe1    	ldr	x1, [sp, #0x9f0]
101410828: 910403e8    	add	x8, sp, #0x100
10141082c: aa1503e0    	mov	x0, x21
101410830: 940e7faf    	bl	0x1017b06ec <__ZN3std2fs14read_to_string5inner17h33327e834bd59c04E>
101410834: f944f3e1    	ldr	x1, [sp, #0x9e0]
101410838: b4000081    	cbz	x1, 0x101410848 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xbe0>
10141083c: aa1503e0    	mov	x0, x21
101410840: 52800022    	mov	w2, #0x1                ; =1
101410844: 97da37a6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101410848: f94083f5    	ldr	x21, [sp, #0x100]
10141084c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101410850: eb0802bf    	cmp	x21, x8
101410854: 54001761    	b.ne	0x101410b40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xed8>
101410858: f94087f5    	ldr	x21, [sp, #0x108]
10141085c: 924006a8    	and	x8, x21, #0x3
101410860: f100051f    	cmp	x8, #0x1
101410864: 54000241    	b.ne	0x1014108ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xc44>
101410868: aa1703f8    	mov	x24, x23
10141086c: f85ffeb6    	ldr	x22, [x21, #-0x1]!
101410870: f94006b7    	ldr	x23, [x21, #0x8]
101410874: f94002e8    	ldr	x8, [x23]
101410878: b4000068    	cbz	x8, 0x101410884 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xc1c>
10141087c: aa1603e0    	mov	x0, x22
101410880: d63f0100    	blr	x8
101410884: f94006e1    	ldr	x1, [x23, #0x8]
101410888: b4000081    	cbz	x1, 0x101410898 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xc30>
10141088c: f9400ae2    	ldr	x2, [x23, #0x10]
101410890: aa1603e0    	mov	x0, x22
101410894: 97da3792    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101410898: aa1503e0    	mov	x0, x21
10141089c: 52800301    	mov	w1, #0x18               ; =24
1014108a0: 52800102    	mov	w2, #0x8                ; =8
1014108a4: 97da378e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014108a8: aa1803f7    	mov	x23, x24
1014108ac: f0004662    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014108b0: 910b2042    	add	x2, x2, #0x2c8
1014108b4: 912783e8    	add	x8, sp, #0x9e0
1014108b8: aa1303e0    	mov	x0, x19
1014108bc: aa1403e1    	mov	x1, x20
1014108c0: 52800103    	mov	w3, #0x8                ; =8
1014108c4: 940ece76    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
1014108c8: f944f7f5    	ldr	x21, [sp, #0x9e8]
1014108cc: f944fbe1    	ldr	x1, [sp, #0x9f0]
1014108d0: 910403e8    	add	x8, sp, #0x100
1014108d4: aa1503e0    	mov	x0, x21
1014108d8: 940e7f85    	bl	0x1017b06ec <__ZN3std2fs14read_to_string5inner17h33327e834bd59c04E>
1014108dc: f944f3e1    	ldr	x1, [sp, #0x9e0]
1014108e0: b4000081    	cbz	x1, 0x1014108f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xc88>
1014108e4: aa1503e0    	mov	x0, x21
1014108e8: 52800022    	mov	w2, #0x1                ; =1
1014108ec: 97da377c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014108f0: f94083f5    	ldr	x21, [sp, #0x100]
1014108f4: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014108f8: eb0802bf    	cmp	x21, x8
1014108fc: 54001221    	b.ne	0x101410b40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xed8>
101410900: f94087f5    	ldr	x21, [sp, #0x108]
101410904: 924006a8    	and	x8, x21, #0x3
101410908: f100051f    	cmp	x8, #0x1
10141090c: 54000241    	b.ne	0x101410954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xcec>
101410910: aa1703f8    	mov	x24, x23
101410914: f85ffeb6    	ldr	x22, [x21, #-0x1]!
101410918: f94006b7    	ldr	x23, [x21, #0x8]
10141091c: f94002e8    	ldr	x8, [x23]
101410920: b4000068    	cbz	x8, 0x10141092c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xcc4>
101410924: aa1603e0    	mov	x0, x22
101410928: d63f0100    	blr	x8
10141092c: f94006e1    	ldr	x1, [x23, #0x8]
101410930: b4000081    	cbz	x1, 0x101410940 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xcd8>
101410934: f9400ae2    	ldr	x2, [x23, #0x10]
101410938: aa1603e0    	mov	x0, x22
10141093c: 97da3768    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101410940: aa1503e0    	mov	x0, x21
101410944: 52800301    	mov	w1, #0x18               ; =24
101410948: 52800102    	mov	w2, #0x8                ; =8
10141094c: 97da3764    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101410950: aa1803f7    	mov	x23, x24
101410954: f0004662    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101410958: 910b4042    	add	x2, x2, #0x2d0
10141095c: 912783e8    	add	x8, sp, #0x9e0
101410960: aa1303e0    	mov	x0, x19
101410964: aa1403e1    	mov	x1, x20
101410968: 52800103    	mov	w3, #0x8                ; =8
10141096c: 940ece4c    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101410970: f944f7f5    	ldr	x21, [sp, #0x9e8]
101410974: f944fbe1    	ldr	x1, [sp, #0x9f0]
101410978: 910403e8    	add	x8, sp, #0x100
10141097c: aa1503e0    	mov	x0, x21
101410980: 940e7f5b    	bl	0x1017b06ec <__ZN3std2fs14read_to_string5inner17h33327e834bd59c04E>
101410984: f944f3e1    	ldr	x1, [sp, #0x9e0]
101410988: b4000081    	cbz	x1, 0x101410998 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xd30>
10141098c: aa1503e0    	mov	x0, x21
101410990: 52800022    	mov	w2, #0x1                ; =1
101410994: 97da3752    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101410998: f94083f5    	ldr	x21, [sp, #0x100]
10141099c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014109a0: eb0802bf    	cmp	x21, x8
1014109a4: 54000ce1    	b.ne	0x101410b40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xed8>
1014109a8: f94087f5    	ldr	x21, [sp, #0x108]
1014109ac: 924006a8    	and	x8, x21, #0x3
1014109b0: f100051f    	cmp	x8, #0x1
1014109b4: 54000201    	b.ne	0x1014109f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xd8c>
1014109b8: f85ffeb6    	ldr	x22, [x21, #-0x1]!
1014109bc: f94006b7    	ldr	x23, [x21, #0x8]
1014109c0: f94002e8    	ldr	x8, [x23]
1014109c4: b4000068    	cbz	x8, 0x1014109d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xd68>
1014109c8: aa1603e0    	mov	x0, x22
1014109cc: d63f0100    	blr	x8
1014109d0: f94006e1    	ldr	x1, [x23, #0x8]
1014109d4: b4000081    	cbz	x1, 0x1014109e4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xd7c>
1014109d8: f9400ae2    	ldr	x2, [x23, #0x10]
1014109dc: aa1603e0    	mov	x0, x22
1014109e0: 97da373f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014109e4: aa1503e0    	mov	x0, x21
1014109e8: 52800301    	mov	w1, #0x18               ; =24
1014109ec: 52800102    	mov	w2, #0x8                ; =8
1014109f0: 97da373b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014109f4: d2800013    	mov	x19, #0x0               ; =0
1014109f8: d2800017    	mov	x23, #0x0               ; =0
1014109fc: 52800114    	mov	w20, #0x8               ; =8
101410a00: f94037e8    	ldr	x8, [sp, #0x68]
101410a04: a9005117    	stp	x23, x20, [x8]
101410a08: f9000913    	str	x19, [x8, #0x10]
101410a0c: 140017ae    	b	0x1014168c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c5c>
101410a10: 940ed6a7    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101410a14: f9403b28    	ldr	x8, [x25, #0x70]
101410a18: eb08001f    	cmp	x0, x8
101410a1c: 54003b21    	b.ne	0x101411180 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1518>
101410a20: b9407b28    	ldr	w8, [x25, #0x78]
101410a24: 6b08003f    	cmp	w1, w8
101410a28: 54003b03    	b.lo	0x101411188 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1520>
101410a2c: d2800014    	mov	x20, #0x0               ; =0
101410a30: d2800015    	mov	x21, #0x0               ; =0
101410a34: 52800113    	mov	w19, #0x8               ; =8
101410a38: 140017a1    	b	0x1014168bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c54>
101410a3c: b940012a    	ldr	w10, [x9]
101410a40: 528eac4c    	mov	w12, #0x7562            ; =30050
101410a44: 72af0dcc    	movk	w12, #0x786e, lsl #16
101410a48: 6b0c015f    	cmp	w10, w12
101410a4c: 5400bd40    	b.eq	0x1014121f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x258c>
101410a50: b940012a    	ldr	w10, [x9]
101410a54: 528c2f2c    	mov	w12, #0x6179            ; =24953
101410a58: 72adce4c    	movk	w12, #0x6e72, lsl #16
101410a5c: 6b0c015f    	cmp	w10, w12
101410a60: 540079c0    	b.eq	0x101411998 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1d30>
101410a64: b9400128    	ldr	w8, [x9]
101410a68: 528dce09    	mov	w9, #0x6e70             ; =28272
101410a6c: 72adae09    	movk	w9, #0x6d70, lsl #16
101410a70: 6b09011f    	cmp	w8, w9
101410a74: 5400d661    	b.ne	0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
101410a78: aa1703fc    	mov	x28, x23
101410a7c: f9400f28    	ldr	x8, [x25, #0x18]
101410a80: b400d628    	cbz	x8, 0x101412544 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28dc>
101410a84: d2800018    	mov	x24, #0x0               ; =0
101410a88: f9400b29    	ldr	x9, [x25, #0x10]
101410a8c: a940a528    	ldp	x8, x9, [x9, #0x8]
101410a90: 52800117    	mov	w23, #0x8               ; =8
101410a94: f1000d3f    	cmp	x9, #0x3
101410a98: 5400802c    	b.gt	0x101411a9c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1e34>
101410a9c: f100053f    	cmp	x9, #0x1
101410aa0: 5400af60    	b.eq	0x10141208c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2424>
101410aa4: aa1803fb    	mov	x27, x24
101410aa8: f1000d3f    	cmp	x9, #0x3
101410aac: 5400d521    	b.ne	0x101412550 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28e8>
101410ab0: 79400109    	ldrh	w9, [x8]
101410ab4: 3940090a    	ldrb	w10, [x8, #0x2]
101410ab8: 528eae4b    	mov	w11, #0x7572            ; =30066
101410abc: 6b0b013f    	cmp	w9, w11
101410ac0: 52800dc9    	mov	w9, #0x6e               ; =110
101410ac4: 7a490140    	ccmp	w10, w9, #0x0, eq
101410ac8: aa1c03f7    	mov	x23, x28
101410acc: 5400d480    	b.eq	0x10141255c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28f4>
101410ad0: 79400109    	ldrh	w9, [x8]
101410ad4: 39400908    	ldrb	w8, [x8, #0x2]
101410ad8: 528d8c8a    	mov	w10, #0x6c64            ; =27748
101410adc: 6b0a013f    	cmp	w9, w10
101410ae0: 52800f09    	mov	w9, #0x78               ; =120
101410ae4: 7a490100    	ccmp	w8, w9, #0x0, eq
101410ae8: 5400d2e1    	b.ne	0x101412544 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28dc>
101410aec: 140005c2    	b	0x1014121f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x258c>
101410af0: a9462320    	ldp	x0, x8, [x25, #0x60]
101410af4: f9401509    	ldr	x9, [x8, #0x28]
101410af8: 912783e8    	add	x8, sp, #0x9e0
101410afc: 52800021    	mov	w1, #0x1                ; =1
101410b00: d2800002    	mov	x2, #0x0                ; =0
101410b04: 52800023    	mov	w3, #0x1                ; =1
101410b08: d2800004    	mov	x4, #0x0                ; =0
101410b0c: d63f0120    	blr	x9
101410b10: f944f3f9    	ldr	x25, [sp, #0x9e0]
101410b14: f944f7f4    	ldr	x20, [sp, #0x9e8]
101410b18: f944fbf5    	ldr	x21, [sp, #0x9f0]
101410b1c: b4005c35    	cbz	x21, 0x1014116a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1a38>
101410b20: 97da36f4    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101410b24: 52800d00    	mov	w0, #0x68               ; =104
101410b28: 52800101    	mov	w1, #0x8                ; =8
101410b2c: 97da36eb    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101410b30: b402f5a0    	cbz	x0, 0x1014169e4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6d7c>
101410b34: aa0003f3    	mov	x19, x0
101410b38: 52800038    	mov	w24, #0x1               ; =1
101410b3c: 140002db    	b	0x1014116a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1a40>
101410b40: a950d3e9    	ldp	x9, x20, [sp, #0x108]
101410b44: 52800108    	mov	w8, #0x8                ; =8
101410b48: a90c23ff    	stp	xzr, x8, [sp, #0xc0]
101410b4c: f9006bff    	str	xzr, [sp, #0xd0]
101410b50: 90007b60    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101410b54: 9131a000    	add	x0, x0, #0xc68
101410b58: f9400008    	ldr	x8, [x0]
101410b5c: d63f0100    	blr	x8
101410b60: aa0003f3    	mov	x19, x0
101410b64: 39404008    	ldrb	w8, [x0, #0x10]
101410b68: 7100051f    	cmp	w8, #0x1
101410b6c: f9001ff9    	str	x25, [sp, #0x38]
101410b70: f9005fe9    	str	x9, [sp, #0xb8]
101410b74: 540275a1    	b.ne	0x101415a28 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dc0>
101410b78: a9400660    	ldp	x0, x1, [x19]
101410b7c: 91000408    	add	x8, x0, #0x1
101410b80: f9000268    	str	x8, [x19]
101410b84: 900072c8    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101410b88: 91166108    	add	x8, x8, #0x598
101410b8c: ad400500    	ldp	q0, q1, [x8]
101410b90: 3d8497e0    	str	q0, [sp, #0x1250]
101410b94: 3d849be1    	str	q1, [sp, #0x1260]
101410b98: f9093be0    	str	x0, [sp, #0x1270]
101410b9c: f9093fe1    	str	x1, [sp, #0x1278]
101410ba0: a91053ff    	stp	xzr, x20, [sp, #0x100]
101410ba4: 910403f8    	add	x24, sp, #0x100
101410ba8: a91153e9    	stp	x9, x20, [sp, #0x110]
101410bac: a91253ff    	stp	xzr, x20, [sp, #0x120]
101410bb0: 0f000540    	movi.2s	v0, #0xa
101410bb4: fd009be0    	str	d0, [sp, #0x130]
101410bb8: 52800039    	mov	w25, #0x1               ; =1
101410bbc: 912783fa    	add	x26, sp, #0x9e0
101410bc0: d280401b    	mov	x27, #0x200             ; =512
101410bc4: f2c0013b    	movk	x27, #0x9, lsl #32
101410bc8: 3904e3f9    	strb	w25, [sp, #0x138]
101410bcc: 0f010748    	movi.2s	v8, #0x3a
101410bd0: 0f010409    	movi.2s	v9, #0x20
101410bd4: d2a9cb3c    	mov	x28, #0x4e590000        ; =1314455552
101410bd8: f2c909fc    	movk	x28, #0x484f, lsl #32
101410bdc: f2e5ca1c    	movk	x28, #0x2e50, lsl #48
101410be0: 790283ff    	strh	wzr, [sp, #0x140]
101410be4: 14000003    	b	0x101410bf0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf88>
101410be8: 394507e8    	ldrb	w8, [sp, #0x141]
101410bec: 37002668    	tbnz	w8, #0x0, 0x1014110b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1450>
101410bf0: f9408bf3    	ldr	x19, [sp, #0x110]
101410bf4: 912783e0    	add	x0, sp, #0x9e0
101410bf8: 91004301    	add	x1, x24, #0x10
101410bfc: 940170b8    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101410c00: b949e3e8    	ldr	w8, [sp, #0x9e0]
101410c04: 7100051f    	cmp	w8, #0x1
101410c08: 54000101    	b.ne	0x101410c28 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xfc0>
101410c0c: f944fbe9    	ldr	x9, [sp, #0x9f0]
101410c10: f94083ea    	ldr	x10, [sp, #0x100]
101410c14: cb0a0128    	sub	x8, x9, x10
101410c18: 8b0a0273    	add	x19, x19, x10
101410c1c: f90083e9    	str	x9, [sp, #0x100]
101410c20: b50001c8    	cbnz	x8, 0x101410c58 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xff0>
101410c24: 1400001c    	b	0x101410c94 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x102c>
101410c28: 394507e8    	ldrb	w8, [sp, #0x141]
101410c2c: 37002468    	tbnz	w8, #0x0, 0x1014110b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1450>
101410c30: 390507f9    	strb	w25, [sp, #0x141]
101410c34: 394503ea    	ldrb	w10, [sp, #0x140]
101410c38: a95023e9    	ldp	x9, x8, [sp, #0x100]
101410c3c: 3700006a    	tbnz	w10, #0x0, 0x101410c48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xfe0>
101410c40: eb09011f    	cmp	x8, x9
101410c44: 540023a0    	b.eq	0x1014110b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1450>
101410c48: f9408bea    	ldr	x10, [sp, #0x110]
101410c4c: cb090108    	sub	x8, x8, x9
101410c50: 8b090153    	add	x19, x10, x9
101410c54: b4000208    	cbz	x8, 0x101410c94 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x102c>
101410c58: d1000509    	sub	x9, x8, #0x1
101410c5c: 38696a6a    	ldrb	w10, [x19, x9]
101410c60: 7100295f    	cmp	w10, #0xa
101410c64: 54000181    	b.ne	0x101410c94 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x102c>
101410c68: d1000908    	sub	x8, x8, #0x2
101410c6c: b40000c9    	cbz	x9, 0x101410c84 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x101c>
101410c70: 38686a6a    	ldrb	w10, [x19, x8]
101410c74: 12001d4a    	and	w10, w10, #0xff
101410c78: 7100355f    	cmp	w10, #0xd
101410c7c: 9a9f026a    	csel	x10, x19, xzr, eq
101410c80: 14000002    	b	0x101410c88 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1020>
101410c84: d280000a    	mov	x10, #0x0               ; =0
101410c88: f100015f    	cmp	x10, #0x0
101410c8c: 9a880128    	csel	x8, x9, x8, eq
101410c90: 9a8a0273    	csel	x19, x19, x10, eq
101410c94: b4fffaa8    	cbz	x8, 0x101410be8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf80>
101410c98: 39400269    	ldrb	w9, [x19]
101410c9c: 71008d3f    	cmp	w9, #0x23
101410ca0: 9ac9232a    	lsl	x10, x25, x9
101410ca4: 8a1b014a    	and	x10, x10, x27
101410ca8: fa409944    	ccmp	x10, #0x0, #0x4, ls
101410cac: 54fff9e1    	b.ne	0x101410be8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf80>
101410cb0: f1001914    	subs	x20, x8, #0x6
101410cb4: 54000123    	b.lo	0x101410cd8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1070>
101410cb8: 79400a6a    	ldrh	w10, [x19, #0x4]
101410cbc: b940026b    	ldr	w11, [x19]
101410cc0: aa0a816a    	orr	x10, x11, x10, lsl #32
101410cc4: dac00d4a    	rev	x10, x10
101410cc8: eb0a039f    	cmp	x28, x10
101410ccc: 1a9f97ea    	cset	w10, hi
101410cd0: 5a9f214a    	csinv	w10, w10, wzr, hs
101410cd4: 3400034a    	cbz	w10, 0x101410d3c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x10d4>
101410cd8: 7100b93f    	cmp	w9, #0x2e
101410cdc: 54fff860    	b.eq	0x101410be8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf80>
101410ce0: f904f3f3    	str	x19, [sp, #0x9e0]
101410ce4: f904f7e8    	str	x8, [sp, #0x9e8]
101410ce8: f904fbff    	str	xzr, [sp, #0x9f0]
101410cec: f904ffe8    	str	x8, [sp, #0x9f8]
101410cf0: 392823f9    	strb	w25, [sp, #0xa08]
101410cf4: fd0503e8    	str	d8, [sp, #0xa00]
101410cf8: 9125c3e0    	add	x0, sp, #0x970
101410cfc: 912783e1    	add	x1, sp, #0x9e0
101410d00: 94017077    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101410d04: b94973e8    	ldr	w8, [sp, #0x970]
101410d08: 3607f708    	tbz	w8, #0x0, 0x101410be8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf80>
101410d0c: f944bff4    	ldr	x20, [sp, #0x978]
101410d10: f1003e9f    	cmp	x20, #0xf
101410d14: 54000e28    	b.hi	0x101410ed8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1270>
101410d18: aa1303e8    	mov	x8, x19
101410d1c: aa1403e9    	mov	x9, x20
101410d20: b4000e94    	cbz	x20, 0x101410ef0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1288>
101410d24: 3840150a    	ldrb	w10, [x8], #0x1
101410d28: 7100f55f    	cmp	w10, #0x3d
101410d2c: 54fff5e0    	b.eq	0x101410be8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf80>
101410d30: f1000529    	subs	x9, x9, #0x1
101410d34: 54ffff81    	b.ne	0x101410d24 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x10bc>
101410d38: 1400006e    	b	0x101410ef0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1288>
101410d3c: 91001a73    	add	x19, x19, #0x6
101410d40: f904f3f3    	str	x19, [sp, #0x9e0]
101410d44: f904f7f4    	str	x20, [sp, #0x9e8]
101410d48: f904fbff    	str	xzr, [sp, #0x9f0]
101410d4c: f904fff4    	str	x20, [sp, #0x9f8]
101410d50: 392823f9    	strb	w25, [sp, #0xa08]
101410d54: fd0503e8    	str	d8, [sp, #0xa00]
101410d58: 9125c3e0    	add	x0, sp, #0x970
101410d5c: 912783e1    	add	x1, sp, #0x9e0
101410d60: 9401705f    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101410d64: b94973e8    	ldr	w8, [sp, #0x970]
101410d68: 7100051f    	cmp	w8, #0x1
101410d6c: 54fff3e1    	b.ne	0x101410be8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf80>
101410d70: f944c3e8    	ldr	x8, [sp, #0x980]
101410d74: cb080281    	sub	x1, x20, x8
101410d78: 8b080260    	add	x0, x19, x8
101410d7c: 97d4eefa    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
101410d80: f904f3ff    	str	xzr, [sp, #0x9e0]
101410d84: f904f7e1    	str	x1, [sp, #0x9e8]
101410d88: f904fbe0    	str	x0, [sp, #0x9f0]
101410d8c: f904ffe1    	str	x1, [sp, #0x9f8]
101410d90: f90503ff    	str	xzr, [sp, #0xa00]
101410d94: f90507e1    	str	x1, [sp, #0xa08]
101410d98: fd050be9    	str	d9, [sp, #0xa10]
101410d9c: 392863f9    	strb	w25, [sp, #0xa18]
101410da0: 791443f9    	strh	w25, [sp, #0xa20]
101410da4: 1400000b    	b	0x101410dd0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1168>
101410da8: f94067e8    	ldr	x8, [sp, #0xc8]
101410dac: 52800309    	mov	w9, #0x18               ; =24
101410db0: 9b092268    	madd	x8, x19, x9, x8
101410db4: a9005d14    	stp	x20, x23, [x8]
101410db8: f9000914    	str	x20, [x8, #0x10]
101410dbc: 91000668    	add	x8, x19, #0x1
101410dc0: f9006be8    	str	x8, [sp, #0xd0]
101410dc4: aa1603f7    	mov	x23, x22
101410dc8: 396887e8    	ldrb	w8, [sp, #0xa21]
101410dcc: 3707f0e8    	tbnz	w8, #0x0, 0x101410be8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf80>
101410dd0: f944fbf3    	ldr	x19, [sp, #0x9f0]
101410dd4: 9125c3e0    	add	x0, sp, #0x970
101410dd8: 91004341    	add	x1, x26, #0x10
101410ddc: 94017040    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101410de0: b94973e8    	ldr	w8, [sp, #0x970]
101410de4: 7100051f    	cmp	w8, #0x1
101410de8: 54000121    	b.ne	0x101410e0c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x11a4>
101410dec: f944bfe9    	ldr	x9, [sp, #0x978]
101410df0: f944c3ea    	ldr	x10, [sp, #0x980]
101410df4: f944f3e8    	ldr	x8, [sp, #0x9e0]
101410df8: f904f3ea    	str	x10, [sp, #0x9e0]
101410dfc: cb080134    	sub	x20, x9, x8
101410e00: b4fffe54    	cbz	x20, 0x101410dc8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1160>
101410e04: 8b080273    	add	x19, x19, x8
101410e08: 1400000e    	b	0x101410e40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x11d8>
101410e0c: 396887e8    	ldrb	w8, [sp, #0xa21]
101410e10: 3707eec8    	tbnz	w8, #0x0, 0x101410be8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf80>
101410e14: 392887f9    	strb	w25, [sp, #0xa21]
101410e18: 396883ea    	ldrb	w10, [sp, #0xa20]
101410e1c: f944f3e8    	ldr	x8, [sp, #0x9e0]
101410e20: f944f7e9    	ldr	x9, [sp, #0x9e8]
101410e24: 3700006a    	tbnz	w10, #0x0, 0x101410e30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x11c8>
101410e28: eb08013f    	cmp	x9, x8
101410e2c: 54ffede0    	b.eq	0x101410be8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf80>
101410e30: cb080134    	sub	x20, x9, x8
101410e34: b4fffcb4    	cbz	x20, 0x101410dc8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1160>
101410e38: f944fbe9    	ldr	x9, [sp, #0x9f0]
101410e3c: 8b080133    	add	x19, x9, x8
101410e40: 39400268    	ldrb	w8, [x19]
101410e44: 7100b91f    	cmp	w8, #0x2e
101410e48: 54fffc00    	b.eq	0x101410dc8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1160>
101410e4c: aa1703f6    	mov	x22, x23
101410e50: 97da3628    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101410e54: aa1403e0    	mov	x0, x20
101410e58: 52800021    	mov	w1, #0x1                ; =1
101410e5c: 97da361f    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101410e60: b402d900    	cbz	x0, 0x101416980 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6d18>
101410e64: aa0003f7    	mov	x23, x0
101410e68: aa1303e1    	mov	x1, x19
101410e6c: aa1403e2    	mov	x2, x20
101410e70: 941ae36e    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101410e74: f904bbf4    	str	x20, [sp, #0x970]
101410e78: f904bff7    	str	x23, [sp, #0x978]
101410e7c: f904c3f4    	str	x20, [sp, #0x980]
101410e80: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101410e84: 91094000    	add	x0, x0, #0x250
101410e88: 9125c3e1    	add	x1, sp, #0x970
101410e8c: 94019730    	bl	0x101476b4c <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xee0>
101410e90: aa1603f7    	mov	x23, x22
101410e94: 3707f9a0    	tbnz	w0, #0x0, 0x101410dc8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1160>
101410e98: 97da3616    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101410e9c: aa1403e0    	mov	x0, x20
101410ea0: 52800021    	mov	w1, #0x1                ; =1
101410ea4: 97da360d    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101410ea8: b402d6c0    	cbz	x0, 0x101416980 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6d18>
101410eac: aa0003f7    	mov	x23, x0
101410eb0: aa1303e1    	mov	x1, x19
101410eb4: aa1403e2    	mov	x2, x20
101410eb8: 941ae35c    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101410ebc: f9406bf3    	ldr	x19, [sp, #0xd0]
101410ec0: f94063e8    	ldr	x8, [sp, #0xc0]
101410ec4: eb08027f    	cmp	x19, x8
101410ec8: 54fff701    	b.ne	0x101410da8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1140>
101410ecc: 910303e0    	add	x0, sp, #0xc0
101410ed0: 941ac728    	bl	0x101ac2b70 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hb575521872840d8cE>
101410ed4: 17ffffb5    	b	0x101410da8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1140>
101410ed8: 528007a0    	mov	w0, #0x3d               ; =61
101410edc: aa1303e1    	mov	x1, x19
101410ee0: aa1403e2    	mov	x2, x20
101410ee4: 94105117    	bl	0x101825340 <__ZN4core5slice6memchr14memchr_aligned17hb4aaf9792c60d219E>
101410ee8: f100041f    	cmp	x0, #0x1
101410eec: 54ffe7e0    	b.eq	0x101410be8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf80>
101410ef0: f904f3ff    	str	xzr, [sp, #0x9e0]
101410ef4: f904f7f4    	str	x20, [sp, #0x9e8]
101410ef8: f904fbf3    	str	x19, [sp, #0x9f0]
101410efc: f904fff4    	str	x20, [sp, #0x9f8]
101410f00: f90503ff    	str	xzr, [sp, #0xa00]
101410f04: f90507f4    	str	x20, [sp, #0xa08]
101410f08: fd050be9    	str	d9, [sp, #0xa10]
101410f0c: 392863f9    	strb	w25, [sp, #0xa18]
101410f10: 791443f9    	strh	w25, [sp, #0xa20]
101410f14: 1400000b    	b	0x101410f40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x12d8>
101410f18: f94067e8    	ldr	x8, [sp, #0xc8]
101410f1c: 52800309    	mov	w9, #0x18               ; =24
101410f20: 9b092268    	madd	x8, x19, x9, x8
101410f24: a9005d14    	stp	x20, x23, [x8]
101410f28: f9000914    	str	x20, [x8, #0x10]
101410f2c: 91000668    	add	x8, x19, #0x1
101410f30: f9006be8    	str	x8, [sp, #0xd0]
101410f34: aa1603f7    	mov	x23, x22
101410f38: 396887e8    	ldrb	w8, [sp, #0xa21]
101410f3c: 3707e568    	tbnz	w8, #0x0, 0x101410be8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf80>
101410f40: f944fbf3    	ldr	x19, [sp, #0x9f0]
101410f44: 9125c3e0    	add	x0, sp, #0x970
101410f48: 91004341    	add	x1, x26, #0x10
101410f4c: 94016fe4    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101410f50: b94973e8    	ldr	w8, [sp, #0x970]
101410f54: 7100051f    	cmp	w8, #0x1
101410f58: 54000101    	b.ne	0x101410f78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1310>
101410f5c: f944bfe8    	ldr	x8, [sp, #0x978]
101410f60: f944c3e9    	ldr	x9, [sp, #0x980]
101410f64: f944f3ea    	ldr	x10, [sp, #0x9e0]
101410f68: cb0a0101    	sub	x1, x8, x10
101410f6c: 8b0a0260    	add	x0, x19, x10
101410f70: f904f3e9    	str	x9, [sp, #0x9e0]
101410f74: 1400000d    	b	0x101410fa8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1340>
101410f78: 396887e8    	ldrb	w8, [sp, #0xa21]
101410f7c: 3707e368    	tbnz	w8, #0x0, 0x101410be8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf80>
101410f80: 392887f9    	strb	w25, [sp, #0xa21]
101410f84: 396883ea    	ldrb	w10, [sp, #0xa20]
101410f88: f944f3e8    	ldr	x8, [sp, #0x9e0]
101410f8c: f944f7e9    	ldr	x9, [sp, #0x9e8]
101410f90: 3700006a    	tbnz	w10, #0x0, 0x101410f9c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1334>
101410f94: eb08013f    	cmp	x9, x8
101410f98: 54ffe280    	b.eq	0x101410be8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf80>
101410f9c: f944fbea    	ldr	x10, [sp, #0x9f0]
101410fa0: cb080121    	sub	x1, x9, x8
101410fa4: 8b080140    	add	x0, x10, x8
101410fa8: 97d4ee6f    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
101410fac: b4fffc61    	cbz	x1, 0x101410f38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x12d0>
101410fb0: aa0003f3    	mov	x19, x0
101410fb4: aa0103f4    	mov	x20, x1
101410fb8: f1003c3f    	cmp	x1, #0xf
101410fbc: 54000208    	b.hi	0x101410ffc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1394>
101410fc0: d2800008    	mov	x8, #0x0                ; =0
101410fc4: 38686a69    	ldrb	w9, [x19, x8]
101410fc8: 7100953f    	cmp	w9, #0x25
101410fcc: 54fffb60    	b.eq	0x101410f38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x12d0>
101410fd0: 91000508    	add	x8, x8, #0x1
101410fd4: eb08029f    	cmp	x20, x8
101410fd8: 54ffff61    	b.ne	0x101410fc4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x135c>
101410fdc: aa1303e8    	mov	x8, x19
101410fe0: aa1403e9    	mov	x9, x20
101410fe4: 3840150a    	ldrb	w10, [x8], #0x1
101410fe8: 7100915f    	cmp	w10, #0x24
101410fec: 54fffa60    	b.eq	0x101410f38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x12d0>
101410ff0: f1000529    	subs	x9, x9, #0x1
101410ff4: 54ffff81    	b.ne	0x101410fe4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x137c>
101410ff8: 1400000d    	b	0x10141102c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x13c4>
101410ffc: 528004a0    	mov	w0, #0x25               ; =37
101411000: aa1303e1    	mov	x1, x19
101411004: aa1403e2    	mov	x2, x20
101411008: 941050ce    	bl	0x101825340 <__ZN4core5slice6memchr14memchr_aligned17hb4aaf9792c60d219E>
10141100c: f100041f    	cmp	x0, #0x1
101411010: 54fff940    	b.eq	0x101410f38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x12d0>
101411014: 52800480    	mov	w0, #0x24               ; =36
101411018: aa1303e1    	mov	x1, x19
10141101c: aa1403e2    	mov	x2, x20
101411020: 941050c8    	bl	0x101825340 <__ZN4core5slice6memchr14memchr_aligned17hb4aaf9792c60d219E>
101411024: f100041f    	cmp	x0, #0x1
101411028: 54fff880    	b.eq	0x101410f38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x12d0>
10141102c: aa1703f6    	mov	x22, x23
101411030: 97da35b0    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101411034: aa1403e0    	mov	x0, x20
101411038: 52800021    	mov	w1, #0x1                ; =1
10141103c: 97da35a7    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101411040: b402ca00    	cbz	x0, 0x101416980 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6d18>
101411044: aa0003f7    	mov	x23, x0
101411048: aa1303e1    	mov	x1, x19
10141104c: aa1403e2    	mov	x2, x20
101411050: 941ae2f6    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101411054: f904bbf4    	str	x20, [sp, #0x970]
101411058: f904bff7    	str	x23, [sp, #0x978]
10141105c: f904c3f4    	str	x20, [sp, #0x980]
101411060: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101411064: 91094000    	add	x0, x0, #0x250
101411068: 9125c3e1    	add	x1, sp, #0x970
10141106c: 940196b8    	bl	0x101476b4c <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xee0>
101411070: aa1603f7    	mov	x23, x22
101411074: 3707f620    	tbnz	w0, #0x0, 0x101410f38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x12d0>
101411078: 97da359e    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10141107c: aa1403e0    	mov	x0, x20
101411080: 52800021    	mov	w1, #0x1                ; =1
101411084: 97da3595    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101411088: b402c7c0    	cbz	x0, 0x101416980 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6d18>
10141108c: aa0003f7    	mov	x23, x0
101411090: aa1303e1    	mov	x1, x19
101411094: aa1403e2    	mov	x2, x20
101411098: 941ae2e4    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10141109c: f9406bf3    	ldr	x19, [sp, #0xd0]
1014110a0: f94063e8    	ldr	x8, [sp, #0xc0]
1014110a4: eb08027f    	cmp	x19, x8
1014110a8: 54fff381    	b.ne	0x101410f18 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x12b0>
1014110ac: 910303e0    	add	x0, sp, #0xc0
1014110b0: 941ac6b0    	bl	0x101ac2b70 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hb575521872840d8cE>
1014110b4: 17ffff99    	b	0x101410f18 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x12b0>
1014110b8: a94c53f3    	ldp	x19, x20, [sp, #0xc0]
1014110bc: f9406bf7    	ldr	x23, [sp, #0xd0]
1014110c0: f9492ff8    	ldr	x24, [sp, #0x1258]
1014110c4: b4001398    	cbz	x24, 0x101411334 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x16cc>
1014110c8: f94937f9    	ldr	x25, [sp, #0x1268]
1014110cc: b4001219    	cbz	x25, 0x10141130c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x16a4>
1014110d0: f9492bfa    	ldr	x26, [sp, #0x1250]
1014110d4: aa1a03fb    	mov	x27, x26
1014110d8: fc408760    	ldr	d0, [x27], #0x8
1014110dc: 2e208800    	cmge.8b	v0, v0, #0
1014110e0: 9e660008    	fmov	x8, d0
1014110e4: 9201c116    	and	x22, x8, #0x8080808080808080
1014110e8: 5280031c    	mov	w28, #0x18              ; =24
1014110ec: 14000005    	b	0x101411100 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1498>
1014110f0: d10006c8    	sub	x8, x22, #0x1
1014110f4: 8a160116    	and	x22, x8, x22
1014110f8: d1000739    	sub	x25, x25, #0x1
1014110fc: b4001099    	cbz	x25, 0x10141130c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x16a4>
101411100: b50000f6    	cbnz	x22, 0x10141111c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14b4>
101411104: fc408760    	ldr	d0, [x27], #0x8
101411108: 2e208800    	cmge.8b	v0, v0, #0
10141110c: 9e660008    	fmov	x8, d0
101411110: d103035a    	sub	x26, x26, #0xc0
101411114: 9201c116    	and	x22, x8, #0x8080808080808080
101411118: b4ffff76    	cbz	x22, 0x101411104 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x149c>
10141111c: dac002c8    	rbit	x8, x22
101411120: dac01108    	clz	x8, x8
101411124: cb480fe8    	neg	x8, x8, lsr #3
101411128: 9b3c6908    	smaddl	x8, w8, w28, x26
10141112c: f85e8101    	ldur	x1, [x8, #-0x18]
101411130: b4fffe01    	cbz	x1, 0x1014110f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1488>
101411134: f85f0100    	ldur	x0, [x8, #-0x10]
101411138: 52800022    	mov	w2, #0x1                ; =1
10141113c: 97da3568    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411140: 17ffffec    	b	0x1014110f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1488>
101411144: b9400109    	ldr	w9, [x8]
101411148: 79400908    	ldrh	w8, [x8, #0x4]
10141114c: 528dec8a    	mov	w10, #0x6f64            ; =28516
101411150: 72ad6c6a    	movk	w10, #0x6b63, lsl #16
101411154: 6b0a013f    	cmp	w9, w10
101411158: 528e4ca9    	mov	w9, #0x7265             ; =29285
10141115c: 7a490100    	ccmp	w8, w9, #0x0, eq
101411160: 540044a0    	b.eq	0x1014119f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1d8c>
101411164: aa1703f6    	mov	x22, x23
101411168: d2800013    	mov	x19, #0x0               ; =0
10141116c: d2800017    	mov	x23, #0x0               ; =0
101411170: 52800114    	mov	w20, #0x8               ; =8
101411174: a90052d7    	stp	x23, x20, [x22]
101411178: f9000ad3    	str	x19, [x22, #0x10]
10141117c: 140015d2    	b	0x1014168c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c5c>
101411180: eb08001f    	cmp	x0, x8
101411184: 54ffc54a    	b.ge	0x101410a2c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xdc4>
101411188: f90037f7    	str	x23, [sp, #0x68]
10141118c: f9401f3e    	ldr	x30, [x25, #0x38]
101411190: f9001ff9    	str	x25, [sp, #0x38]
101411194: f9401729    	ldr	x9, [x25, #0x28]
101411198: f1000528    	subs	x8, x9, #0x1
10141119c: 9a8833e8    	csel	x8, xzr, x8, lo
1014111a0: f10003df    	cmp	x30, #0x0
1014111a4: f9005fe9    	str	x9, [sp, #0xb8]
1014111a8: 9a880128    	csel	x8, x9, x8, eq
1014111ac: f100091f    	cmp	x8, #0x2
1014111b0: 54003062    	b.hs	0x1014117bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1b54>
1014111b4: f9401ff5    	ldr	x21, [sp, #0x38]
1014111b8: f9401ab6    	ldr	x22, [x21, #0x30]
1014111bc: f904f3f6    	str	x22, [sp, #0x9e0]
1014111c0: f904f7fe    	str	x30, [sp, #0x9e8]
1014111c4: f904fbff    	str	xzr, [sp, #0x9f0]
1014111c8: f9004bfe    	str	x30, [sp, #0x90]
1014111cc: f904fffe    	str	x30, [sp, #0x9f8]
1014111d0: 52800033    	mov	w19, #0x1               ; =1
1014111d4: 392823f3    	strb	w19, [sp, #0xa08]
1014111d8: 0f020400    	movi.2s	v0, #0x40
1014111dc: fd0503e0    	str	d0, [sp, #0xa00]
1014111e0: 910403e0    	add	x0, sp, #0x100
1014111e4: 912783e1    	add	x1, sp, #0x9e0
1014111e8: 94016f3d    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
1014111ec: b94103e8    	ldr	w8, [sp, #0x100]
1014111f0: 7100051f    	cmp	w8, #0x1
1014111f4: 54004321    	b.ne	0x101411a58 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1df0>
1014111f8: f94087e8    	ldr	x8, [sp, #0x108]
1014111fc: b100051f    	cmn	x8, #0x1
101411200: 540279c0    	b.eq	0x101416138 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x64d0>
101411204: 91000503    	add	x3, x8, #0x1
101411208: f9404be1    	ldr	x1, [sp, #0x90]
10141120c: eb030028    	subs	x8, x1, x3
101411210: 540056a9    	b.ls	0x101411ce4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x207c>
101411214: 38e36ac9    	ldrsb	w9, [x22, x3]
101411218: 3101053f    	cmn	w9, #0x41
10141121c: 5400566c    	b.gt	0x101411ce8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2080>
101411220: f00072a4    	adrp	x4, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101411224: 9120a084    	add	x4, x4, #0x828
101411228: aa1603e0    	mov	x0, x22
10141122c: d2800002    	mov	x2, #0x0                ; =0
101411230: 941ac8f6    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
101411234: d2800018    	mov	x24, #0x0               ; =0
101411238: 52800113    	mov	w19, #0x8               ; =8
10141123c: a9364fb8    	stp	x24, x19, [x29, #-0xa0]
101411240: f90083f4    	str	x20, [sp, #0x100]
101411244: a9115ff9    	stp	x25, x23, [sp, #0x110]
101411248: b4000475    	cbz	x21, 0x1014112d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x166c>
10141124c: d2800015    	mov	x21, #0x0               ; =0
101411250: 91018676    	add	x22, x19, #0x61
101411254: d2f0001a    	mov	x26, #-0x8000000000000000 ; =-9223372036854775808
101411258: 5280401b    	mov	w27, #0x200             ; =512
10141125c: aa1403e8    	mov	x8, x20
101411260: 3dc00100    	ldr	q0, [x8]
101411264: 3d8033e0    	str	q0, [sp, #0xc0]
101411268: f9400909    	ldr	x9, [x8, #0x10]
10141126c: f9006be9    	str	x9, [sp, #0xd0]
101411270: 9100611c    	add	x28, x8, #0x18
101411274: 3dc00100    	ldr	q0, [x8]
101411278: f9400908    	ldr	x8, [x8, #0x10]
10141127c: f904c3e8    	str	x8, [sp, #0x980]
101411280: 3d825fe0    	str	q0, [sp, #0x970]
101411284: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
101411288: 91094108    	add	x8, x8, #0x250
10141128c: 9125c3e0    	add	x0, sp, #0x970
101411290: 940ff7cf    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101411294: 3dc497e0    	ldr	q0, [sp, #0x1250]
101411298: f94933e8    	ldr	x8, [sp, #0x1260]
10141129c: 3c99f2c0    	stur	q0, [x22, #-0x61]
1014112a0: f81af2c8    	stur	x8, [x22, #-0x51]
1014112a4: 3dc033e0    	ldr	q0, [sp, #0xc0]
1014112a8: f9406be8    	ldr	x8, [sp, #0xd0]
1014112ac: f81c72c8    	stur	x8, [x22, #-0x39]
1014112b0: 3c9b72c0    	stur	q0, [x22, #-0x49]
1014112b4: f81cf2da    	stur	x26, [x22, #-0x31]
1014112b8: f81e72da    	stur	x26, [x22, #-0x19]
1014112bc: 781ff2db    	sturh	w27, [x22, #-0x1]
1014112c0: 910006b5    	add	x21, x21, #0x1
1014112c4: 9101a2d6    	add	x22, x22, #0x68
1014112c8: aa1c03e8    	mov	x8, x28
1014112cc: eb17039f    	cmp	x28, x23
1014112d0: 54fffc81    	b.ne	0x101411260 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x15f8>
1014112d4: f9405fe8    	ldr	x8, [sp, #0xb8]
1014112d8: b40000c8    	cbz	x8, 0x1014112f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1688>
1014112dc: 8b080508    	add	x8, x8, x8, lsl #1
1014112e0: d37df101    	lsl	x1, x8, #3
1014112e4: aa1403e0    	mov	x0, x20
1014112e8: 52800102    	mov	w2, #0x8                ; =8
1014112ec: 97da34fc    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014112f0: f85283a1    	ldur	x1, [x29, #-0xd8]
1014112f4: f94037f7    	ldr	x23, [sp, #0x68]
1014112f8: b4ff9661    	cbz	x1, 0x1014105c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x95c>
1014112fc: f85303a0    	ldur	x0, [x29, #-0xd0]
101411300: 52800022    	mov	w2, #0x1                ; =1
101411304: 97da34f6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411308: 17fffcaf    	b	0x1014105c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x95c>
10141130c: 8b180708    	add	x8, x24, x24, lsl #1
101411310: d37df108    	lsl	x8, x8, #3
101411314: 8b180109    	add	x9, x8, x24
101411318: b1008521    	adds	x1, x9, #0x21
10141131c: 540000c0    	b.eq	0x101411334 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x16cc>
101411320: f9492be9    	ldr	x9, [sp, #0x1250]
101411324: cb080128    	sub	x8, x9, x8
101411328: d1006100    	sub	x0, x8, #0x18
10141132c: 52800102    	mov	w2, #0x8                ; =8
101411330: 97da34eb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411334: 52800308    	mov	w8, #0x18               ; =24
101411338: f904bbf4    	str	x20, [sp, #0x970]
10141133c: f904bff4    	str	x20, [sp, #0x978]
101411340: 9b0852e8    	madd	x8, x23, x8, x20
101411344: f904c3f3    	str	x19, [sp, #0x980]
101411348: f904c7e8    	str	x8, [sp, #0x988]
10141134c: f9401fe8    	ldr	x8, [sp, #0x38]
101411350: f904cbe8    	str	x8, [sp, #0x990]
101411354: 910403e0    	add	x0, sp, #0x100
101411358: 9125c3e1    	add	x1, sp, #0x970
10141135c: 97ffb8cb    	bl	0x1013ff688 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1960>
101411360: f94083e8    	ldr	x8, [sp, #0x100]
101411364: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101411368: eb09011f    	cmp	x8, x9
10141136c: f9405ff9    	ldr	x25, [sp, #0xb8]
101411370: 540008a1    	b.ne	0x101411484 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x181c>
101411374: f944bfe8    	ldr	x8, [sp, #0x978]
101411378: f944c7e9    	ldr	x9, [sp, #0x988]
10141137c: eb080129    	subs	x9, x9, x8
101411380: 54000fc0    	b.eq	0x101411578 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1910>
101411384: b201f3ea    	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
101411388: f295556a    	movk	x10, #0xaaab
10141138c: 9bca7d29    	umulh	x9, x9, x10
101411390: d344fd33    	lsr	x19, x9, #4
101411394: 91002114    	add	x20, x8, #0x8
101411398: 14000004    	b	0x1014113a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1740>
10141139c: 91006294    	add	x20, x20, #0x18
1014113a0: f1000673    	subs	x19, x19, #0x1
1014113a4: 54000ea0    	b.eq	0x101411578 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1910>
1014113a8: f85f8281    	ldur	x1, [x20, #-0x8]
1014113ac: b4ffff81    	cbz	x1, 0x10141139c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1734>
1014113b0: f9400280    	ldr	x0, [x20]
1014113b4: 52800022    	mov	w2, #0x1                ; =1
1014113b8: 97da34c9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014113bc: 17fffff8    	b	0x10141139c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1734>
1014113c0: f1000d3f    	cmp	x9, #0x3
1014113c4: 54003a00    	b.eq	0x101411b04 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1e9c>
1014113c8: f100113f    	cmp	x9, #0x4
1014113cc: 54004520    	b.eq	0x101411c70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2008>
1014113d0: f100153f    	cmp	x9, #0x5
1014113d4: 54004361    	b.ne	0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
1014113d8: b9400109    	ldr	w9, [x8]
1014113dc: 528c2c6a    	mov	w10, #0x6163            ; =24931
1014113e0: 72acee4a    	movk	w10, #0x6772, lsl #16
1014113e4: 1110294a    	add	w10, w10, #0x40a
1014113e8: 3940110b    	ldrb	w11, [x8, #0x4]
1014113ec: 6b0a013f    	cmp	w9, w10
1014113f0: 52800ca9    	mov	w9, #0x65               ; =101
1014113f4: 7a490160    	ccmp	w11, w9, #0x0, eq
1014113f8: 54004280    	b.eq	0x101411c48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fe0>
1014113fc: b9400109    	ldr	w9, [x8]
101411400: 3940110a    	ldrb	w10, [x8, #0x4]
101411404: 528caccb    	mov	w11, #0x6566            ; =25958
101411408: 72ac6e8b    	movk	w11, #0x6374, lsl #16
10141140c: 6b0b013f    	cmp	w9, w11
101411410: 52800d09    	mov	w9, #0x68               ; =104
101411414: 7a490140    	ccmp	w10, w9, #0x0, eq
101411418: 54005700    	b.eq	0x101411ef8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2290>
10141141c: b940010a    	ldr	w10, [x8]
101411420: 3940110b    	ldrb	w11, [x8, #0x4]
101411424: 528e8e6c    	mov	w12, #0x7473            ; =29811
101411428: 72ae6c2c    	movk	w12, #0x7361, lsl #16
10141142c: 6b0c015f    	cmp	w10, w12
101411430: 7a490160    	ccmp	w11, w9, #0x0, eq
101411434: 54011600    	b.eq	0x1014136f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3a8c>
101411438: b9400109    	ldr	w9, [x8]
10141143c: 39401108    	ldrb	w8, [x8, #0x4]
101411440: 528cae4a    	mov	w10, #0x6572            ; =25970
101411444: 72acae6a    	movk	w10, #0x6573, lsl #16
101411448: 6b0a013f    	cmp	w9, w10
10141144c: 52800e89    	mov	w9, #0x74               ; =116
101411450: 7a490100    	ccmp	w8, w9, #0x0, eq
101411454: 54003f61    	b.ne	0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
101411458: 97da34a6    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10141145c: 52800053    	mov	w19, #0x2               ; =2
101411460: 52800040    	mov	w0, #0x2                ; =2
101411464: 52800021    	mov	w1, #0x1                ; =1
101411468: 97da349c    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10141146c: b4022ea0    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
101411470: aa0003e9    	mov	x9, x0
101411474: 528000c8    	mov	w8, #0x6                ; =6
101411478: 79000008    	strh	w8, [x0]
10141147c: 52800048    	mov	w8, #0x2                ; =2
101411480: 14000903    	b	0x10141388c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3c24>
101411484: 97da349b    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101411488: 52803400    	mov	w0, #0x1a0              ; =416
10141148c: 52800101    	mov	w1, #0x8                ; =8
101411490: 97da3492    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101411494: b402ac80    	cbz	x0, 0x101416a24 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6dbc>
101411498: aa0003f4    	mov	x20, x0
10141149c: ad4a07e0    	ldp	q0, q1, [sp, #0x140]
1014114a0: ad020400    	stp	q0, q1, [x0, #0x40]
1014114a4: f940b3e8    	ldr	x8, [sp, #0x160]
1014114a8: f9003008    	str	x8, [x0, #0x60]
1014114ac: ad4807e0    	ldp	q0, q1, [sp, #0x100]
1014114b0: ad000400    	stp	q0, q1, [x0]
1014114b4: ad4903e1    	ldp	q1, q0, [sp, #0x120]
1014114b8: ad010001    	stp	q1, q0, [x0, #0x20]
1014114bc: 52800088    	mov	w8, #0x4                ; =4
1014114c0: a90c03e8    	stp	x8, x0, [sp, #0xc0]
1014114c4: 52800033    	mov	w19, #0x1               ; =1
1014114c8: f9006bf3    	str	x19, [sp, #0xd0]
1014114cc: 3dc25fe0    	ldr	q0, [sp, #0x970]
1014114d0: 3dc263e1    	ldr	q1, [sp, #0x980]
1014114d4: f944cbe8    	ldr	x8, [sp, #0x990]
1014114d8: f9093be8    	str	x8, [sp, #0x1270]
1014114dc: 52800d17    	mov	w23, #0x68              ; =104
1014114e0: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
1014114e4: 3d8497e0    	str	q0, [sp, #0x1250]
1014114e8: 3d849be1    	str	q1, [sp, #0x1260]
1014114ec: 14000011    	b	0x101411530 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x18c8>
1014114f0: 8b170288    	add	x8, x20, x23
1014114f4: 3dc27be0    	ldr	q0, [sp, #0x9e0]
1014114f8: 3dc27fe1    	ldr	q1, [sp, #0x9f0]
1014114fc: 3dc283e2    	ldr	q2, [sp, #0xa00]
101411500: ad008901    	stp	q1, q2, [x8, #0x10]
101411504: 3d800100    	str	q0, [x8]
101411508: 3dc287e0    	ldr	q0, [sp, #0xa10]
10141150c: 3dc28be1    	ldr	q1, [sp, #0xa20]
101411510: 3dc28fe2    	ldr	q2, [sp, #0xa30]
101411514: f94523e9    	ldr	x9, [sp, #0xa40]
101411518: f9003109    	str	x9, [x8, #0x60]
10141151c: ad020901    	stp	q1, q2, [x8, #0x40]
101411520: 3d800d00    	str	q0, [x8, #0x30]
101411524: 91000673    	add	x19, x19, #0x1
101411528: f9006bf3    	str	x19, [sp, #0xd0]
10141152c: 9101a2f7    	add	x23, x23, #0x68
101411530: 912783e0    	add	x0, sp, #0x9e0
101411534: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
101411538: 91094021    	add	x1, x1, #0x250
10141153c: 97ffb853    	bl	0x1013ff688 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x1960>
101411540: f944f3e8    	ldr	x8, [sp, #0x9e0]
101411544: eb18011f    	cmp	x8, x24
101411548: 540002e0    	b.eq	0x1014115a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x193c>
10141154c: f94063e8    	ldr	x8, [sp, #0xc0]
101411550: eb08027f    	cmp	x19, x8
101411554: 54fffce1    	b.ne	0x1014114f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1888>
101411558: 910303e0    	add	x0, sp, #0xc0
10141155c: aa1303e1    	mov	x1, x19
101411560: 52800022    	mov	w2, #0x1                ; =1
101411564: 52800103    	mov	w3, #0x8                ; =8
101411568: 52800d04    	mov	w4, #0x68               ; =104
10141156c: 94185cb9    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101411570: f94067f4    	ldr	x20, [sp, #0xc8]
101411574: 17ffffdf    	b	0x1014114f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1888>
101411578: f944c3e8    	ldr	x8, [sp, #0x980]
10141157c: b4002b28    	cbz	x8, 0x101411ae0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1e78>
101411580: f944bbe0    	ldr	x0, [sp, #0x970]
101411584: 8b080508    	add	x8, x8, x8, lsl #1
101411588: d37df101    	lsl	x1, x8, #3
10141158c: 52800114    	mov	w20, #0x8               ; =8
101411590: 52800102    	mov	w2, #0x8                ; =8
101411594: 97da3452    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411598: d2800013    	mov	x19, #0x0               ; =0
10141159c: d2800017    	mov	x23, #0x0               ; =0
1014115a0: 14000153    	b	0x101411aec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1e84>
1014115a4: f9492fe8    	ldr	x8, [sp, #0x1258]
1014115a8: f94937e9    	ldr	x9, [sp, #0x1268]
1014115ac: eb080129    	subs	x9, x9, x8
1014115b0: 54000200    	b.eq	0x1014115f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1988>
1014115b4: b201f3ea    	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
1014115b8: f295556a    	movk	x10, #0xaaab
1014115bc: 9bca7d29    	umulh	x9, x9, x10
1014115c0: d344fd36    	lsr	x22, x9, #4
1014115c4: 91002117    	add	x23, x8, #0x8
1014115c8: 14000004    	b	0x1014115d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1970>
1014115cc: 910062f7    	add	x23, x23, #0x18
1014115d0: f10006d6    	subs	x22, x22, #0x1
1014115d4: 540000e0    	b.eq	0x1014115f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1988>
1014115d8: f85f82e1    	ldur	x1, [x23, #-0x8]
1014115dc: b4ffff81    	cbz	x1, 0x1014115cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1964>
1014115e0: f94002e0    	ldr	x0, [x23]
1014115e4: 52800022    	mov	w2, #0x1                ; =1
1014115e8: 97da343d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014115ec: 17fffff8    	b	0x1014115cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1964>
1014115f0: f94933e8    	ldr	x8, [sp, #0x1260]
1014115f4: b40000c8    	cbz	x8, 0x10141160c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x19a4>
1014115f8: f9492be0    	ldr	x0, [sp, #0x1250]
1014115fc: 8b080508    	add	x8, x8, x8, lsl #1
101411600: d37df101    	lsl	x1, x8, #3
101411604: 52800102    	mov	w2, #0x8                ; =8
101411608: 97da3435    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141160c: f94063f7    	ldr	x23, [sp, #0xc0]
101411610: 14000137    	b	0x101411aec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1e84>
101411614: b4017568    	cbz	x8, 0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
101411618: 92800009    	mov	x9, #-0x1               ; =-1
10141161c: ab080128    	adds	x8, x9, x8
101411620: 54017503    	b.lo	0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
101411624: f9401329    	ldr	x9, [x25, #0x20]
101411628: 5280030a    	mov	w10, #0x18              ; =24
10141162c: 9b0a2508    	madd	x8, x8, x10, x9
101411630: f9400909    	ldr	x9, [x8, #0x10]
101411634: b4017469    	cbz	x9, 0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
101411638: f9400508    	ldr	x8, [x8, #0x8]
10141163c: 3940010a    	ldrb	w10, [x8]
101411640: 7100b55f    	cmp	w10, #0x2d
101411644: 540173e1    	b.ne	0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
101411648: d2800013    	mov	x19, #0x0               ; =0
10141164c: 52800114    	mov	w20, #0x8               ; =8
101411650: f100193f    	cmp	x9, #0x6
101411654: 540083ad    	b.le	0x1014126c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2a60>
101411658: f1001d3f    	cmp	x9, #0x7
10141165c: 54010b00    	b.eq	0x1014137bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b54>
101411660: f100253f    	cmp	x9, #0x9
101411664: 54010c20    	b.eq	0x1014137e8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b80>
101411668: aa1303f5    	mov	x21, x19
10141166c: f100293f    	cmp	x9, #0xa
101411670: 540172e1    	b.ne	0x1014144cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4864>
101411674: f9400109    	ldr	x9, [x8]
101411678: 79401108    	ldrh	w8, [x8, #0x8]
10141167c: d285a5aa    	mov	x10, #0x2d2d            ; =11565
101411680: f2acacca    	movk	x10, #0x6566, lsl #16
101411684: f2ce8c2a    	movk	x10, #0x7461, lsl #32
101411688: f2ee4eaa    	movk	x10, #0x7275, lsl #48
10141168c: eb0a013f    	cmp	x9, x10
101411690: 528e6ca9    	mov	w9, #0x7365             ; =29541
101411694: 7a490100    	ccmp	w8, w9, #0x0, eq
101411698: 54017141    	b.ne	0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
10141169c: 14000aa4    	b	0x10141412c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44c4>
1014116a0: d2800018    	mov	x24, #0x0               ; =0
1014116a4: 52800113    	mov	w19, #0x8               ; =8
1014116a8: 52800308    	mov	w8, #0x18               ; =24
1014116ac: f904bbf8    	str	x24, [sp, #0x970]
1014116b0: f904bff3    	str	x19, [sp, #0x978]
1014116b4: 9b0852ba    	madd	x26, x21, x8, x20
1014116b8: f904f3f4    	str	x20, [sp, #0x9e0]
1014116bc: f904fbf9    	str	x25, [sp, #0x9f0]
1014116c0: f904fffa    	str	x26, [sp, #0x9f8]
1014116c4: b4000495    	cbz	x21, 0x101411754 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1aec>
1014116c8: a9405a95    	ldp	x21, x22, [x20]
1014116cc: 9100629b    	add	x27, x20, #0x18
1014116d0: f9400a9c    	ldr	x28, [x20, #0x10]
1014116d4: 97da3407    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014116d8: 528000c0    	mov	w0, #0x6                ; =6
1014116dc: 52800021    	mov	w1, #0x1                ; =1
1014116e0: 97da33fe    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014116e4: b4029880    	cbz	x0, 0x1014169f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6d8c>
1014116e8: aa0003f7    	mov	x23, x0
1014116ec: 528e8dc8    	mov	w8, #0x746e             ; =29806
1014116f0: 79000808    	strh	w8, [x0, #0x4]
1014116f4: 528cae48    	mov	w8, #0x6572             ; =25970
1014116f8: 72acac68    	movk	w8, #0x6563, lsl #16
1014116fc: b9000008    	str	w8, [x0]
101411700: f9092bf5    	str	x21, [sp, #0x1250]
101411704: f9092ff6    	str	x22, [sp, #0x1258]
101411708: f90933fc    	str	x28, [sp, #0x1260]
10141170c: 910403e8    	add	x8, sp, #0x100
101411710: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101411714: 91094000    	add	x0, x0, #0x250
101411718: 940ff6ad    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10141171c: 3dc043e0    	ldr	q0, [sp, #0x100]
101411720: f9408be8    	ldr	x8, [sp, #0x110]
101411724: 3d800260    	str	q0, [x19]
101411728: a9015668    	stp	x8, x21, [x19, #0x10]
10141172c: a9027276    	stp	x22, x28, [x19, #0x20]
101411730: 528000c8    	mov	w8, #0x6                ; =6
101411734: a9035e68    	stp	x8, x23, [x19, #0x30]
101411738: b0004368    	adrp	x8, 0x101c7e000 <__ZN16curve25519_dalek9constants23X25519_LOW_ORDER_POINTS17h489881f202cbb08bE+0x48>
10141173c: 3dc23100    	ldr	q0, [x8, #0x8c0]
101411740: 3d801260    	str	q0, [x19, #0x40]
101411744: 52804008    	mov	w8, #0x200              ; =512
101411748: 52800035    	mov	w21, #0x1               ; =1
10141174c: 7900c268    	strh	w8, [x19, #0x60]
101411750: 14000002    	b	0x101411758 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1af0>
101411754: aa1403fb    	mov	x27, x20
101411758: eb1b0348    	subs	x8, x26, x27
10141175c: 54000200    	b.eq	0x10141179c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1b34>
101411760: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
101411764: f2955569    	movk	x9, #0xaaab
101411768: 9bc97d08    	umulh	x8, x8, x9
10141176c: d344fd16    	lsr	x22, x8, #4
101411770: 91002377    	add	x23, x27, #0x8
101411774: 14000004    	b	0x101411784 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1b1c>
101411778: 910062f7    	add	x23, x23, #0x18
10141177c: f10006d6    	subs	x22, x22, #0x1
101411780: 540000e0    	b.eq	0x10141179c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1b34>
101411784: f85f82e1    	ldur	x1, [x23, #-0x8]
101411788: b4ffff81    	cbz	x1, 0x101411778 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1b10>
10141178c: f94002e0    	ldr	x0, [x23]
101411790: 52800022    	mov	w2, #0x1                ; =1
101411794: 97da33d2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411798: 17fffff8    	b	0x101411778 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1b10>
10141179c: b40000d9    	cbz	x25, 0x1014117b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1b4c>
1014117a0: 8b190728    	add	x8, x25, x25, lsl #1
1014117a4: d37df101    	lsl	x1, x8, #3
1014117a8: aa1403e0    	mov	x0, x20
1014117ac: 52800102    	mov	w2, #0x8                ; =8
1014117b0: 97da33cb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014117b4: f94037f7    	ldr	x23, [sp, #0x68]
1014117b8: 17fffb83    	b	0x1014105c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x95c>
1014117bc: 52800020    	mov	w0, #0x1                ; =1
1014117c0: 52800309    	mov	w9, #0x18               ; =24
1014117c4: f9401fea    	ldr	x10, [sp, #0x38]
1014117c8: f940114a    	ldr	x10, [x10, #0x20]
1014117cc: 52800113    	mov	w19, #0x8               ; =8
1014117d0: 528c45ab    	mov	w11, #0x622d            ; =25133
1014117d4: 528c65ac    	mov	w12, #0x632d            ; =25389
1014117d8: 528885ad    	mov	w13, #0x442d            ; =17453
1014117dc: 5288a5ae    	mov	w14, #0x452d            ; =17709
1014117e0: 528ca5af    	mov	w15, #0x652d            ; =25901
1014117e4: 5288c5b0    	mov	w16, #0x462d            ; =17965
1014117e8: 528925b1    	mov	w17, #0x492d            ; =18733
1014117ec: 528d25a1    	mov	w1, #0x692d             ; =26925
1014117f0: 528945a2    	mov	w2, #0x4a2d             ; =18989
1014117f4: 528985a3    	mov	w3, #0x4c2d             ; =19501
1014117f8: 528d85a4    	mov	w4, #0x6c2d             ; =27693
1014117fc: 528da5a5    	mov	w5, #0x6d2d             ; =27949
101411800: 5289e5a6    	mov	w6, #0x4f2d             ; =20269
101411804: 528de5a7    	mov	w7, #0x6f2d             ; =28461
101411808: 528e05b4    	mov	w20, #0x702d            ; =28717
10141180c: 528a25b7    	mov	w23, #0x512d            ; =20781
101411810: 528a45b8    	mov	w24, #0x522d            ; =21037
101411814: 528a65b9    	mov	w25, #0x532d            ; =21293
101411818: 528ae5ba    	mov	w26, #0x572d            ; =22317
10141181c: 528ee5bb    	mov	w27, #0x772d            ; =30509
101411820: 14000005    	b	0x101411834 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1bcc>
101411824: 52800035    	mov	w21, #0x1               ; =1
101411828: 8b0002a0    	add	x0, x21, x0
10141182c: eb08001f    	cmp	x0, x8
101411830: 54ffcc22    	b.hs	0x1014111b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x154c>
101411834: f9405ff5    	ldr	x21, [sp, #0xb8]
101411838: eb15001f    	cmp	x0, x21
10141183c: 540289a2    	b.hs	0x101416970 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6d08>
101411840: 9b092815    	madd	x21, x0, x9, x10
101411844: f9400ab6    	ldr	x22, [x21, #0x10]
101411848: b4001016    	cbz	x22, 0x101411a48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1de0>
10141184c: f94006b5    	ldr	x21, [x21, #0x8]
101411850: 394002bc    	ldrb	w28, [x21]
101411854: 7100b79f    	cmp	w28, #0x2d
101411858: 54000f81    	b.ne	0x101411a48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1de0>
10141185c: f1000adf    	cmp	x22, #0x2
101411860: 54fffe21    	b.ne	0x101411824 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1bbc>
101411864: 794002b6    	ldrh	w22, [x21]
101411868: 6b0b02df    	cmp	w22, w11
10141186c: 54000740    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
101411870: 794002b6    	ldrh	w22, [x21]
101411874: 6b0c02df    	cmp	w22, w12
101411878: 540006e0    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
10141187c: 794002b6    	ldrh	w22, [x21]
101411880: 6b0d02df    	cmp	w22, w13
101411884: 54000680    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
101411888: 794002b6    	ldrh	w22, [x21]
10141188c: 6b0e02df    	cmp	w22, w14
101411890: 54000620    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
101411894: 794002b6    	ldrh	w22, [x21]
101411898: 6b0f02df    	cmp	w22, w15
10141189c: 540005c0    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
1014118a0: 794002b6    	ldrh	w22, [x21]
1014118a4: 6b1002df    	cmp	w22, w16
1014118a8: 54000560    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
1014118ac: 794002b6    	ldrh	w22, [x21]
1014118b0: 6b1102df    	cmp	w22, w17
1014118b4: 54000500    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
1014118b8: 794002b6    	ldrh	w22, [x21]
1014118bc: 6b0102df    	cmp	w22, w1
1014118c0: 540004a0    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
1014118c4: 794002b6    	ldrh	w22, [x21]
1014118c8: 6b0202df    	cmp	w22, w2
1014118cc: 54000440    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
1014118d0: 794002b6    	ldrh	w22, [x21]
1014118d4: 6b0302df    	cmp	w22, w3
1014118d8: 540003e0    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
1014118dc: 794002b6    	ldrh	w22, [x21]
1014118e0: 6b0402df    	cmp	w22, w4
1014118e4: 54000380    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
1014118e8: 794002b6    	ldrh	w22, [x21]
1014118ec: 6b0502df    	cmp	w22, w5
1014118f0: 54000320    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
1014118f4: 794002b6    	ldrh	w22, [x21]
1014118f8: 6b0602df    	cmp	w22, w6
1014118fc: 540002c0    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
101411900: 794002b6    	ldrh	w22, [x21]
101411904: 6b0702df    	cmp	w22, w7
101411908: 54000260    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
10141190c: 794002b6    	ldrh	w22, [x21]
101411910: 6b1402df    	cmp	w22, w20
101411914: 54000200    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
101411918: 794002b6    	ldrh	w22, [x21]
10141191c: 6b1702df    	cmp	w22, w23
101411920: 540001a0    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
101411924: 794002b6    	ldrh	w22, [x21]
101411928: 6b1802df    	cmp	w22, w24
10141192c: 54000140    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
101411930: 794002b6    	ldrh	w22, [x21]
101411934: 6b1902df    	cmp	w22, w25
101411938: 540000e0    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
10141193c: 794002b6    	ldrh	w22, [x21]
101411940: 6b1a02df    	cmp	w22, w26
101411944: 54000080    	b.eq	0x101411954 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1cec>
101411948: 794002b5    	ldrh	w21, [x21]
10141194c: 6b1b02bf    	cmp	w21, w27
101411950: 54fff6a1    	b.ne	0x101411824 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1bbc>
101411954: 52800055    	mov	w21, #0x2               ; =2
101411958: 8b0002a0    	add	x0, x21, x0
10141195c: eb08001f    	cmp	x0, x8
101411960: 54fff6a3    	b.lo	0x101411834 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1bcc>
101411964: 17fffe14    	b	0x1014111b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x154c>
101411968: f1002d3f    	cmp	x9, #0xb
10141196c: 54001500    	b.eq	0x101411c0c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fa4>
101411970: f100213f    	cmp	x9, #0x8
101411974: 54001661    	b.ne	0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
101411978: f9400108    	ldr	x8, [x8]
10141197c: d28d0c69    	mov	x9, #0x6863             ; =26723
101411980: f2ac6ca9    	movk	x9, #0x6365, lsl #16
101411984: f2cded69    	movk	x9, #0x6f6b, lsl #32
101411988: f2ee8ea9    	movk	x9, #0x7475, lsl #48
10141198c: eb09011f    	cmp	x8, x9
101411990: 54001581    	b.ne	0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
101411994: 14000195    	b	0x101411fe8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2380>
101411998: f9400f29    	ldr	x9, [x25, #0x18]
10141199c: b4002ee9    	cbz	x9, 0x101411f78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2310>
1014119a0: f9400b29    	ldr	x9, [x25, #0x10]
1014119a4: a940a528    	ldp	x8, x9, [x9, #0x8]
1014119a8: f100113f    	cmp	x9, #0x4
1014119ac: 540041a0    	b.eq	0x1014121e0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2578>
1014119b0: f1000d3f    	cmp	x9, #0x3
1014119b4: 54005c61    	b.ne	0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
1014119b8: 79400109    	ldrh	w9, [x8]
1014119bc: 3940090a    	ldrb	w10, [x8, #0x2]
1014119c0: 528eae4b    	mov	w11, #0x7572            ; =30066
1014119c4: 6b0b013f    	cmp	w9, w11
1014119c8: 52800dc9    	mov	w9, #0x6e               ; =110
1014119cc: 7a490140    	ccmp	w10, w9, #0x0, eq
1014119d0: 54005c60    	b.eq	0x10141255c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28f4>
1014119d4: 79400109    	ldrh	w9, [x8]
1014119d8: 39400908    	ldrb	w8, [x8, #0x2]
1014119dc: 528d8c8a    	mov	w10, #0x6c64            ; =27748
1014119e0: 6b0a013f    	cmp	w9, w10
1014119e4: 52800f09    	mov	w9, #0x78               ; =120
1014119e8: 7a490100    	ccmp	w8, w9, #0x0, eq
1014119ec: 54005aa1    	b.ne	0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
1014119f0: 14000201    	b	0x1014121f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x258c>
1014119f4: f9400f28    	ldr	x8, [x25, #0x18]
1014119f8: b4ffbb68    	cbz	x8, 0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
1014119fc: f9400b29    	ldr	x9, [x25, #0x10]
101411a00: f940092a    	ldr	x10, [x9, #0x10]
101411a04: f1001d5f    	cmp	x10, #0x7
101411a08: 54ffbae1    	b.ne	0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
101411a0c: f940052a    	ldr	x10, [x9, #0x8]
101411a10: b940014b    	ldr	w11, [x10]
101411a14: b840314a    	ldur	w10, [x10, #0x3]
101411a18: 528cae4c    	mov	w12, #0x6572            ; =25970
101411a1c: 72acae6c    	movk	w12, #0x6573, lsl #16
101411a20: 1127f98c    	add	w12, w12, #0x9fe
101411a24: 528dec6d    	mov	w13, #0x6f63            ; =28515
101411a28: 72ae0dad    	movk	w13, #0x706d, lsl #16
101411a2c: 6b0d017f    	cmp	w11, w13
101411a30: 7a4c0140    	ccmp	w10, w12, #0x0, eq
101411a34: 54ffb981    	b.ne	0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
101411a38: d1000508    	sub	x8, x8, #0x1
101411a3c: 91006129    	add	x9, x9, #0x18
101411a40: b5ff5328    	cbnz	x8, 0x1014104a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x83c>
101411a44: 17fffdc8    	b	0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
101411a48: d2800014    	mov	x20, #0x0               ; =0
101411a4c: d2800015    	mov	x21, #0x0               ; =0
101411a50: f94037f7    	ldr	x23, [sp, #0x68]
101411a54: 1400139a    	b	0x1014168bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c54>
101411a58: d2800003    	mov	x3, #0x0                ; =0
101411a5c: 140000a6    	b	0x101411cf4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x208c>
101411a60: 7940018c    	ldrh	w12, [x12]
101411a64: 6b0b019f    	cmp	w12, w11
101411a68: 5400e8e0    	b.eq	0x101413784 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b1c>
101411a6c: 9100614a    	add	x10, x10, #0x18
101411a70: f1006108    	subs	x8, x8, #0x18
101411a74: 54006480    	b.eq	0x101412704 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2a9c>
101411a78: a97fb54c    	ldp	x12, x13, [x10, #-0x8]
101411a7c: f10009bf    	cmp	x13, #0x2
101411a80: 54ffff00    	b.eq	0x101411a60 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1df8>
101411a84: f10021bf    	cmp	x13, #0x8
101411a88: 54ffff21    	b.ne	0x101411a6c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1e04>
101411a8c: f940018c    	ldr	x12, [x12]
101411a90: eb0c013f    	cmp	x9, x12
101411a94: 54fffec1    	b.ne	0x101411a6c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1e04>
101411a98: 1400073b    	b	0x101413784 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b1c>
101411a9c: f100113f    	cmp	x9, #0x4
101411aa0: 54002fc0    	b.eq	0x101412098 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2430>
101411aa4: aa1803fb    	mov	x27, x24
101411aa8: f100293f    	cmp	x9, #0xa
101411aac: 54005521    	b.ne	0x101412550 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28e8>
101411ab0: f9400109    	ldr	x9, [x8]
101411ab4: 79401108    	ldrh	w8, [x8, #0x8]
101411ab8: d28eae4a    	mov	x10, #0x7572            ; =30066
101411abc: f2a5adca    	movk	x10, #0x2d6e, lsl #16
101411ac0: f2cc6e6a    	movk	x10, #0x6373, lsl #32
101411ac4: f2ed2e4a    	movk	x10, #0x6972, lsl #48
101411ac8: eb0a013f    	cmp	x9, x10
101411acc: 528e8e09    	mov	w9, #0x7470             ; =29808
101411ad0: 7a490100    	ccmp	w8, w9, #0x0, eq
101411ad4: aa1c03f7    	mov	x23, x28
101411ad8: 54005361    	b.ne	0x101412544 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28dc>
101411adc: 140002a0    	b	0x10141255c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28f4>
101411ae0: d2800013    	mov	x19, #0x0               ; =0
101411ae4: d2800017    	mov	x23, #0x0               ; =0
101411ae8: 52800114    	mov	w20, #0x8               ; =8
101411aec: b4ff78b5    	cbz	x21, 0x101410a00 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xd98>
101411af0: aa1903e0    	mov	x0, x25
101411af4: aa1503e1    	mov	x1, x21
101411af8: 52800022    	mov	w2, #0x1                ; =1
101411afc: 97da32f8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411b00: 17fffbc0    	b	0x101410a00 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xd98>
101411b04: 79400109    	ldrh	w9, [x8]
101411b08: 3940090a    	ldrb	w10, [x8, #0x2]
101411b0c: 528c8c2b    	mov	w11, #0x6461            ; =25697
101411b10: 6b0b013f    	cmp	w9, w11
101411b14: 52800c89    	mov	w9, #0x64               ; =100
101411b18: 7a490140    	ccmp	w10, w9, #0x0, eq
101411b1c: 54005ae0    	b.eq	0x101412678 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2a10>
101411b20: 79400109    	ldrh	w9, [x8]
101411b24: 3940090a    	ldrb	w10, [x8, #0x2]
101411b28: 528ded8b    	mov	w11, #0x6f6c            ; =28524
101411b2c: 6b0b013f    	cmp	w9, w11
101411b30: 52800ce9    	mov	w9, #0x67               ; =103
101411b34: 7a490140    	ccmp	w10, w9, #0x0, eq
101411b38: 54000c40    	b.eq	0x101411cc0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2058>
101411b3c: 7940010a    	ldrh	w10, [x8]
101411b40: 39400908    	ldrb	w8, [x8, #0x2]
101411b44: 528c2e8b    	mov	w11, #0x6174            ; =24948
101411b48: 6b0b015f    	cmp	w10, w11
101411b4c: 7a490100    	ccmp	w8, w9, #0x0, eq
101411b50: 54000781    	b.ne	0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
101411b54: f00072a1    	adrp	x1, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101411b58: 91202021    	add	x1, x1, #0x808
101411b5c: aa1903e0    	mov	x0, x25
101411b60: 52800042    	mov	w2, #0x2                ; =2
101411b64: 97fff471    	bl	0x10140ed28 <__ZN17otty_autocomplete10generators16GeneratorContext8has_flag17hfe88895f58e09f66E>
101411b68: 340006c0    	cbz	w0, 0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
101411b6c: 97da32e1    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101411b70: 52800033    	mov	w19, #0x1               ; =1
101411b74: 52800020    	mov	w0, #0x1                ; =1
101411b78: 52800021    	mov	w1, #0x1                ; =1
101411b7c: 97da32d7    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101411b80: b401f600    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
101411b84: aa0003e9    	mov	x9, x0
101411b88: 52800068    	mov	w8, #0x3                ; =3
101411b8c: 14000706    	b	0x1014137a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b3c>
101411b90: b9400109    	ldr	w9, [x8]
101411b94: 7940090a    	ldrh	w10, [x8, #0x4]
101411b98: 528eee6b    	mov	w11, #0x7773            ; =30579
101411b9c: 72ae8d2b    	movk	w11, #0x7469, lsl #16
101411ba0: 6b0b013f    	cmp	w9, w11
101411ba4: 528d0c69    	mov	w9, #0x6863             ; =26723
101411ba8: 7a490140    	ccmp	w10, w9, #0x0, eq
101411bac: 540021e0    	b.eq	0x101411fe8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2380>
101411bb0: b9400109    	ldr	w9, [x8]
101411bb4: 7940090a    	ldrh	w10, [x8, #0x4]
101411bb8: 528cae4b    	mov	w11, #0x6572            ; =25970
101411bbc: 72ac2c4b    	movk	w11, #0x6162, lsl #16
101411bc0: 6b0b013f    	cmp	w9, w11
101411bc4: 528cae69    	mov	w9, #0x6573             ; =25971
101411bc8: 7a490140    	ccmp	w10, w9, #0x0, eq
101411bcc: 540003e0    	b.eq	0x101411c48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fe0>
101411bd0: b9400109    	ldr	w9, [x8]
101411bd4: 79400908    	ldrh	w8, [x8, #0x4]
101411bd8: 528e4c4a    	mov	w10, #0x7262            ; =29282
101411bdc: 72adcc2a    	movk	w10, #0x6e61, lsl #16
101411be0: 6b0a013f    	cmp	w9, w10
101411be4: 528d0c69    	mov	w9, #0x6863             ; =26723
101411be8: 7a490100    	ccmp	w8, w9, #0x0, eq
101411bec: 540002a1    	b.ne	0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
101411bf0: f00072a1    	adrp	x1, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101411bf4: 911f6021    	add	x1, x1, #0x7d8
101411bf8: aa1903e0    	mov	x0, x25
101411bfc: 52800062    	mov	w2, #0x3                ; =3
101411c00: 97fff44a    	bl	0x10140ed28 <__ZN17otty_autocomplete10generators16GeneratorContext8has_flag17hfe88895f58e09f66E>
101411c04: 340001e0    	cbz	w0, 0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
101411c08: 14000010    	b	0x101411c48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fe0>
101411c0c: f9400109    	ldr	x9, [x8]
101411c10: f8403108    	ldur	x8, [x8, #0x3]
101411c14: d28d0c6a    	mov	x10, #0x6863            ; =26723
101411c18: f2ae4caa    	movk	x10, #0x7265, lsl #16
101411c1c: f2cf2e4a    	movk	x10, #0x7972, lsl #32
101411c20: f2ee05aa    	movk	x10, #0x702d, lsl #48
101411c24: eb0a013f    	cmp	x9, x10
101411c28: d28e4e49    	mov	x9, #0x7272             ; =29298
101411c2c: f2a5af29    	movk	x9, #0x2d79, lsl #16
101411c30: f2cd2e09    	movk	x9, #0x6970, lsl #32
101411c34: f2ed6c69    	movk	x9, #0x6b63, lsl #48
101411c38: fa490100    	ccmp	x8, x9, #0x0, eq
101411c3c: 54000060    	b.eq	0x101411c48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fe0>
101411c40: d280001a    	mov	x26, #0x0               ; =0
101411c44: 1400092d    	b	0x1014140f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4490>
101411c48: 97da32aa    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101411c4c: 52800033    	mov	w19, #0x1               ; =1
101411c50: 52800020    	mov	w0, #0x1                ; =1
101411c54: 52800021    	mov	w1, #0x1                ; =1
101411c58: 97da32a0    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101411c5c: b401ef20    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
101411c60: aa0003e9    	mov	x9, x0
101411c64: 3900001f    	strb	wzr, [x0]
101411c68: 52800028    	mov	w8, #0x1                ; =1
101411c6c: 14000708    	b	0x10141388c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3c24>
101411c70: b9400109    	ldr	w9, [x8]
101411c74: 528eae0a    	mov	w10, #0x7570            ; =30064
101411c78: 72ad0e6a    	movk	w10, #0x6873, lsl #16
101411c7c: 6b0a013f    	cmp	w9, w10
101411c80: 540013c0    	b.eq	0x101411ef8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2290>
101411c84: b9400109    	ldr	w9, [x8]
101411c88: 528eae0a    	mov	w10, #0x7570            ; =30064
101411c8c: 72ad8d8a    	movk	w10, #0x6c6c, lsl #16
101411c90: 6b0a013f    	cmp	w9, w10
101411c94: 54001320    	b.eq	0x101411ef8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2290>
101411c98: b9400109    	ldr	w9, [x8]
101411c9c: 528d2c8a    	mov	w10, #0x6964            ; =26980
101411ca0: 72acccca    	movk	w10, #0x6666, lsl #16
101411ca4: 6b0a013f    	cmp	w9, w10
101411ca8: 5400d360    	b.eq	0x101413714 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3aac>
101411cac: b9400108    	ldr	w8, [x8]
101411cb0: 528d0e69    	mov	w9, #0x6873             ; =26739
101411cb4: 72aeede9    	movk	w9, #0x776f, lsl #16
101411cb8: 6b09011f    	cmp	w8, w9
101411cbc: 54fffc21    	b.ne	0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
101411cc0: 97da328c    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101411cc4: 52800053    	mov	w19, #0x2               ; =2
101411cc8: 52800040    	mov	w0, #0x2                ; =2
101411ccc: 52800021    	mov	w1, #0x1                ; =1
101411cd0: 97da3282    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101411cd4: b401eb60    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
101411cd8: aa0003e9    	mov	x9, x0
101411cdc: 52806008    	mov	w8, #0x300              ; =768
101411ce0: 140006e8    	b	0x101413880 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3c18>
101411ce4: 54ffa9e1    	b.ne	0x101411220 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x15b8>
101411ce8: aa1603f3    	mov	x19, x22
101411cec: 8b0302d6    	add	x22, x22, x3
101411cf0: f9004be8    	str	x8, [sp, #0x90]
101411cf4: f90973f3    	str	x19, [sp, #0x12e0]
101411cf8: f90977e3    	str	x3, [sp, #0x12e8]
101411cfc: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
101411d00: 910be108    	add	x8, x8, #0x2f8
101411d04: 94062426    	bl	0x10159ad9c <__ZN11otty_config6Config13user_home_dir17hfc53f12b1c41c57eE>
101411d08: f9497fe8    	ldr	x8, [sp, #0x12f8]
101411d0c: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101411d10: eb09011f    	cmp	x8, x9
101411d14: 540000e1    	b.ne	0x101411d30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x20c8>
101411d18: d2800009    	mov	x9, #0x0                ; =0
101411d1c: d2800008    	mov	x8, #0x0                ; =0
101411d20: 5280010a    	mov	w10, #0x8               ; =8
101411d24: a9102bea    	stp	x10, x10, [sp, #0x100]
101411d28: a9112bff    	stp	xzr, x10, [sp, #0x110]
101411d2c: 14001154    	b	0x10141627c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6614>
101411d30: f94983f3    	ldr	x19, [sp, #0x1300]
101411d34: f94987f4    	ldr	x20, [sp, #0x1308]
101411d38: 912783e8    	add	x8, sp, #0x9e0
101411d3c: 94061ebc    	bl	0x10159982c <__ZN11otty_config6Config10config_dir17h840d21c19fd23261E>
101411d40: f944f7f8    	ldr	x24, [sp, #0x9e8]
101411d44: f944fbe1    	ldr	x1, [sp, #0x9f0]
101411d48: d0004662    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101411d4c: 91202442    	add	x2, x2, #0x809
101411d50: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
101411d54: 910ca108    	add	x8, x8, #0x328
101411d58: aa1803e0    	mov	x0, x24
101411d5c: 52800143    	mov	w3, #0xa                ; =10
101411d60: 940ec94f    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101411d64: f944f3e1    	ldr	x1, [sp, #0x9e0]
101411d68: b4000081    	cbz	x1, 0x101411d78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2110>
101411d6c: aa1803e0    	mov	x0, x24
101411d70: 52800022    	mov	w2, #0x1                ; =1
101411d74: 97da325a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411d78: f9499bf8    	ldr	x24, [sp, #0x1330]
101411d7c: f9499fe3    	ldr	x3, [sp, #0x1338]
101411d80: d10363a8    	sub	x8, x29, #0xd8
101411d84: aa1303e0    	mov	x0, x19
101411d88: aa1403e1    	mov	x1, x20
101411d8c: aa1803e2    	mov	x2, x24
101411d90: 94019aef    	bl	0x10147894c <__ZN15otty_ssh_config21all_config_host_names17hdfb8c07f6de11aabE>
101411d94: 912783e8    	add	x8, sp, #0x9e0
101411d98: 9406255a    	bl	0x10159b300 <__ZN11otty_config6Config15app_support_dir17h7e5345c1919e313bE>
101411d9c: f944f7f3    	ldr	x19, [sp, #0x9e8]
101411da0: f944fbe1    	ldr	x1, [sp, #0x9f0]
101411da4: d00037a2    	adrp	x2, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
101411da8: 912a4042    	add	x2, x2, #0xa90
101411dac: d10303a8    	sub	x8, x29, #0xc0
101411db0: aa1303e0    	mov	x0, x19
101411db4: 52800103    	mov	w3, #0x8                ; =8
101411db8: 940ec939    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101411dbc: f944f3e1    	ldr	x1, [sp, #0x9e0]
101411dc0: b4000081    	cbz	x1, 0x101411dd0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2168>
101411dc4: aa1303e0    	mov	x0, x19
101411dc8: 52800022    	mov	w2, #0x1                ; =1
101411dcc: 97da3244    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411dd0: a974cfb9    	ldp	x25, x19, [x29, #-0xb8]
101411dd4: 912783e8    	add	x8, sp, #0x9e0
101411dd8: aa1903e0    	mov	x0, x25
101411ddc: aa1303e1    	mov	x1, x19
101411de0: 940ea547    	bl	0x1017bb2fc <__ZN3std3sys2fs8metadata17h317aa82d489c5e37E>
101411de4: b949e3e8    	ldr	w8, [sp, #0x9e0]
101411de8: 7100051f    	cmp	w8, #0x1
101411dec: 54000501    	b.ne	0x101411e8c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2224>
101411df0: f944f7f3    	ldr	x19, [sp, #0x9e8]
101411df4: 92400668    	and	x8, x19, #0x3
101411df8: f100051f    	cmp	x8, #0x1
101411dfc: 54000201    	b.ne	0x101411e3c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x21d4>
101411e00: f85ffe74    	ldr	x20, [x19, #-0x1]!
101411e04: f9400675    	ldr	x21, [x19, #0x8]
101411e08: f94002a8    	ldr	x8, [x21]
101411e0c: b4000068    	cbz	x8, 0x101411e18 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x21b0>
101411e10: aa1403e0    	mov	x0, x20
101411e14: d63f0100    	blr	x8
101411e18: f94006a1    	ldr	x1, [x21, #0x8]
101411e1c: b4000081    	cbz	x1, 0x101411e2c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x21c4>
101411e20: f9400aa2    	ldr	x2, [x21, #0x10]
101411e24: aa1403e0    	mov	x0, x20
101411e28: 97da322d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411e2c: aa1303e0    	mov	x0, x19
101411e30: 52800301    	mov	w1, #0x18               ; =24
101411e34: 52800102    	mov	w2, #0x8                ; =8
101411e38: 97da3229    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101411e3c: f0007b40    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101411e40: 9131a000    	add	x0, x0, #0xc68
101411e44: f9400008    	ldr	x8, [x0]
101411e48: d63f0100    	blr	x8
101411e4c: aa0003fa    	mov	x26, x0
101411e50: 39404008    	ldrb	w8, [x0, #0x10]
101411e54: 7100051f    	cmp	w8, #0x1
101411e58: 54021901    	b.ne	0x101416178 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6510>
101411e5c: a9402354    	ldp	x20, x8, [x26]
101411e60: f90057e8    	str	x8, [sp, #0xa8]
101411e64: 91000688    	add	x8, x20, #0x1
101411e68: f9000348    	str	x8, [x26]
101411e6c: f85403a1    	ldur	x1, [x29, #-0xc0]
101411e70: b4021981    	cbz	x1, 0x1014161a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6538>
101411e74: d280001c    	mov	x28, #0x0               ; =0
101411e78: d2800017    	mov	x23, #0x0               ; =0
101411e7c: d00037a8    	adrp	x8, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
101411e80: 91242108    	add	x8, x8, #0x908
101411e84: f9005be8    	str	x8, [sp, #0xb0]
101411e88: 14000267    	b	0x101412824 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2bbc>
101411e8c: 910403e8    	add	x8, sp, #0x100
101411e90: aa1903e0    	mov	x0, x25
101411e94: aa1303e1    	mov	x1, x19
101411e98: 9401f363    	bl	0x10148ec24 <__ZN10otty_state4open17h1d9a351a8e583abfE>
101411e9c: 394583fb    	ldrb	w27, [sp, #0x160]
101411ea0: 71000f7f    	cmp	w27, #0x3
101411ea4: 54002f01    	b.ne	0x101412484 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x281c>
101411ea8: f0007b40    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101411eac: 9131a000    	add	x0, x0, #0xc68
101411eb0: f9400008    	ldr	x8, [x0]
101411eb4: d63f0100    	blr	x8
101411eb8: aa0003fa    	mov	x26, x0
101411ebc: 39404008    	ldrb	w8, [x0, #0x10]
101411ec0: 7100051f    	cmp	w8, #0x1
101411ec4: 54025201    	b.ne	0x101416904 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c9c>
101411ec8: a9402354    	ldp	x20, x8, [x26]
101411ecc: f90057e8    	str	x8, [sp, #0xa8]
101411ed0: 91000688    	add	x8, x20, #0x1
101411ed4: f9000348    	str	x8, [x26]
101411ed8: 910403e0    	add	x0, sp, #0x100
101411edc: 94010596    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
101411ee0: d280001c    	mov	x28, #0x0               ; =0
101411ee4: d2800017    	mov	x23, #0x0               ; =0
101411ee8: d00037a8    	adrp	x8, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
101411eec: 91242108    	add	x8, x8, #0x908
101411ef0: f9005be8    	str	x8, [sp, #0xb0]
101411ef4: 1400024a    	b	0x10141281c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2bb4>
101411ef8: f9401f29    	ldr	x9, [x25, #0x38]
101411efc: f9401728    	ldr	x8, [x25, #0x28]
101411f00: f100050a    	subs	x10, x8, #0x1
101411f04: 9a8a33ea    	csel	x10, xzr, x10, lo
101411f08: f100013f    	cmp	x9, #0x0
101411f0c: 9a8a0109    	csel	x9, x8, x10, eq
101411f10: 9100044a    	add	x10, x2, #0x1
101411f14: eb09015f    	cmp	x10, x9
101411f18: 54003002    	b.hs	0x101412518 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28b0>
101411f1c: d280000b    	mov	x11, #0x0               ; =0
101411f20: f940132c    	ldr	x12, [x25, #0x20]
101411f24: 5280030d    	mov	w13, #0x18              ; =24
101411f28: 9b0d304c    	madd	x12, x2, x13, x12
101411f2c: 9100a18c    	add	x12, x12, #0x28
101411f30: 14000007    	b	0x101411f4c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x22e4>
101411f34: d280000d    	mov	x13, #0x0               ; =0
101411f38: 9100054a    	add	x10, x10, #0x1
101411f3c: 8b0b01ab    	add	x11, x13, x11
101411f40: 9100618c    	add	x12, x12, #0x18
101411f44: eb0a013f    	cmp	x9, x10
101411f48: 54002d00    	b.eq	0x1014124e8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2880>
101411f4c: eb08015f    	cmp	x10, x8
101411f50: 54ffff22    	b.hs	0x101411f34 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x22cc>
101411f54: f940018d    	ldr	x13, [x12]
101411f58: b40000cd    	cbz	x13, 0x101411f70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2308>
101411f5c: f85f818d    	ldur	x13, [x12, #-0x8]
101411f60: 394001ad    	ldrb	w13, [x13]
101411f64: 7100b5bf    	cmp	w13, #0x2d
101411f68: 1a9f07ed    	cset	w13, ne
101411f6c: 17fffff3    	b	0x101411f38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x22d0>
101411f70: 5280002d    	mov	w13, #0x1               ; =1
101411f74: 17fffff1    	b	0x101411f38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x22d0>
101411f78: f9401f29    	ldr	x9, [x25, #0x38]
101411f7c: f100013f    	cmp	x9, #0x0
101411f80: 1a9f07e9    	cset	w9, ne
101411f84: cb090109    	sub	x9, x8, x9
101411f88: f100093f    	cmp	x9, #0x2
101411f8c: 54002e83    	b.lo	0x10141255c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28f4>
101411f90: d280000a    	mov	x10, #0x0               ; =0
101411f94: 9100a16b    	add	x11, x11, #0x28
101411f98: 5280002c    	mov	w12, #0x1               ; =1
101411f9c: 14000007    	b	0x101411fb8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2350>
101411fa0: d280000d    	mov	x13, #0x0               ; =0
101411fa4: 9100058c    	add	x12, x12, #0x1
101411fa8: 8b0a01aa    	add	x10, x13, x10
101411fac: 9100616b    	add	x11, x11, #0x18
101411fb0: eb0c013f    	cmp	x9, x12
101411fb4: 54002c40    	b.eq	0x10141253c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d4>
101411fb8: eb08019f    	cmp	x12, x8
101411fbc: 54ffff22    	b.hs	0x101411fa0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2338>
101411fc0: f940016d    	ldr	x13, [x11]
101411fc4: b40000ed    	cbz	x13, 0x101411fe0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2378>
101411fc8: f85f816d    	ldur	x13, [x11, #-0x8]
101411fcc: 394001ad    	ldrb	w13, [x13]
101411fd0: 12001dad    	and	w13, w13, #0xff
101411fd4: 7100b5bf    	cmp	w13, #0x2d
101411fd8: 1a9f07ed    	cset	w13, ne
101411fdc: 17fffff2    	b	0x101411fa4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x233c>
101411fe0: 5280002d    	mov	w13, #0x1               ; =1
101411fe4: 17fffff0    	b	0x101411fa4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x233c>
101411fe8: 97da31c2    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101411fec: 52800073    	mov	w19, #0x3               ; =3
101411ff0: 52800060    	mov	w0, #0x3                ; =3
101411ff4: 52800021    	mov	w1, #0x1                ; =1
101411ff8: 97da31b8    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101411ffc: b401d220    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
101412000: aa0003e9    	mov	x9, x0
101412004: 52802008    	mov	w8, #0x100              ; =256
101412008: 79000008    	strh	w8, [x0]
10141200c: 39000813    	strb	w19, [x0, #0x2]
101412010: 52800068    	mov	w8, #0x3                ; =3
101412014: 1400061e    	b	0x10141388c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3c24>
101412018: f100153f    	cmp	x9, #0x5
10141201c: 54005520    	b.eq	0x101412ac0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2e58>
101412020: f100193f    	cmp	x9, #0x6
101412024: 54005960    	b.eq	0x101412b50 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2ee8>
101412028: aa1703f6    	mov	x22, x23
10141202c: aa1303f7    	mov	x23, x19
101412030: f1001d3f    	cmp	x9, #0x7
101412034: 54ff8a01    	b.ne	0x101411174 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x150c>
101412038: b9400109    	ldr	w9, [x8]
10141203c: b840310a    	ldur	w10, [x8, #0x3]
101412040: 528cae4b    	mov	w11, #0x6572            ; =25970
101412044: 72ae8e6b    	movk	w11, #0x7473, lsl #16
101412048: 6b0b013f    	cmp	w9, w11
10141204c: 528c2e89    	mov	w9, #0x6174             ; =24948
101412050: 72ae8e49    	movk	w9, #0x7472, lsl #16
101412054: 7a490140    	ccmp	w10, w9, #0x0, eq
101412058: aa1603f7    	mov	x23, x22
10141205c: 540058a0    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412060: b9400109    	ldr	w9, [x8]
101412064: b8403108    	ldur	w8, [x8, #0x3]
101412068: 528cae4a    	mov	w10, #0x6572            ; =25970
10141206c: 72acae6a    	movk	w10, #0x6573, lsl #16
101412070: 113fbd4a    	add	w10, w10, #0xfef
101412074: 528dceab    	mov	w11, #0x6e75            ; =28277
101412078: 72ac2e0b    	movk	w11, #0x6170, lsl #16
10141207c: 6b0b013f    	cmp	w9, w11
101412080: 7a480140    	ccmp	w10, w8, #0x0, eq
101412084: 54ff8721    	b.ne	0x101411168 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1500>
101412088: 140002ba    	b	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
10141208c: 39400108    	ldrb	w8, [x8]
101412090: 7101e11f    	cmp	w8, #0x78
101412094: 14000005    	b	0x1014120a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2440>
101412098: b9400108    	ldr	w8, [x8]
10141209c: 528f0ca9    	mov	w9, #0x7865             ; =30821
1014120a0: 72ac6ca9    	movk	w9, #0x6365, lsl #16
1014120a4: 6b09011f    	cmp	w8, w9
1014120a8: aa1c03f7    	mov	x23, x28
1014120ac: 540024c1    	b.ne	0x101412544 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28dc>
1014120b0: 14000051    	b	0x1014121f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x258c>
1014120b4: aa0803fb    	mov	x27, x8
1014120b8: eb08001f    	cmp	x0, x8
1014120bc: 5400086a    	b.ge	0x1014121c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2560>
1014120c0: f9401720    	ldr	x0, [x25, #0x28]
1014120c4: f100041f    	cmp	x0, #0x1
1014120c8: 54000349    	b.ls	0x101412130 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x24c8>
1014120cc: f9401328    	ldr	x8, [x25, #0x20]
1014120d0: f9400909    	ldr	x9, [x8, #0x10]
1014120d4: f100113f    	cmp	x9, #0x4
1014120d8: 540002c1    	b.ne	0x101412130 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x24c8>
1014120dc: f9400509    	ldr	x9, [x8, #0x8]
1014120e0: b9400129    	ldr	w9, [x9]
1014120e4: 528e8dea    	mov	w10, #0x746f            ; =29807
1014120e8: 72af2e8a    	movk	w10, #0x7974, lsl #16
1014120ec: 6b0a013f    	cmp	w9, w10
1014120f0: 54000201    	b.ne	0x101412130 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x24c8>
1014120f4: f9401509    	ldr	x9, [x8, #0x28]
1014120f8: f100113f    	cmp	x9, #0x4
1014120fc: 540001a1    	b.ne	0x101412130 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x24c8>
101412100: f9401108    	ldr	x8, [x8, #0x20]
101412104: b9400108    	ldr	w8, [x8]
101412108: 5ac00908    	rev	w8, w8
10141210c: 528dae09    	mov	w9, #0x6d70             ; =28016
101412110: 72ad4ea9    	movk	w9, #0x6a75, lsl #16
101412114: 6b09011f    	cmp	w8, w9
101412118: 1a9f97e8    	cset	w8, hi
10141211c: 5a9f2108    	csinv	w8, w8, wzr, hs
101412120: 7100011f    	cmp	w8, #0x0
101412124: 52800028    	mov	w8, #0x1                ; =1
101412128: 9a881509    	cinc	x9, x8, eq
10141212c: 14000002    	b	0x101412134 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x24cc>
101412130: 52800029    	mov	w9, #0x1                ; =1
101412134: f1000408    	subs	x8, x0, #0x1
101412138: 9a8833e8    	csel	x8, xzr, x8, lo
10141213c: eb08013f    	cmp	x9, x8
101412140: 54002ae2    	b.hs	0x10141269c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2a34>
101412144: aa2903e8    	mvn	x8, x9
101412148: 8b080008    	add	x8, x0, x8
10141214c: d1000508    	sub	x8, x8, #0x1
101412150: cb09000a    	sub	x10, x0, x9
101412154: eb08015f    	cmp	x10, x8
101412158: 54024e89    	b.ls	0x101416b28 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6ec0>
10141215c: 52800008    	mov	w8, #0x0                ; =0
101412160: f940132a    	ldr	x10, [x25, #0x20]
101412164: 5280030b    	mov	w11, #0x18              ; =24
101412168: 9b0b292a    	madd	x10, x9, x11, x10
10141216c: 9100414a    	add	x10, x10, #0x10
101412170: f100041f    	cmp	x0, #0x1
101412174: 9a9f340b    	csinc	x11, x0, xzr, lo
101412178: 8b0b0129    	add	x9, x9, x11
10141217c: cb000129    	sub	x9, x9, x0
101412180: 14000006    	b	0x101412198 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2530>
101412184: 5280002b    	mov	w11, #0x1               ; =1
101412188: 0b080168    	add	w8, w11, w8
10141218c: 9100614a    	add	x10, x10, #0x18
101412190: b1000529    	adds	x9, x9, #0x1
101412194: 54000182    	b.hs	0x1014121c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x255c>
101412198: f940014b    	ldr	x11, [x10]
10141219c: b4ffff4b    	cbz	x11, 0x101412184 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x251c>
1014121a0: f85f814b    	ldur	x11, [x10, #-0x8]
1014121a4: 3940016b    	ldrb	w11, [x11]
1014121a8: 12001d6b    	and	w11, w11, #0xff
1014121ac: 7100b57f    	cmp	w11, #0x2d
1014121b0: 1a9f07eb    	cset	w11, ne
1014121b4: 0b080168    	add	w8, w11, w8
1014121b8: 9100614a    	add	x10, x10, #0x18
1014121bc: b1000529    	adds	x9, x9, #0x1
1014121c0: 54fffec3    	b.lo	0x101412198 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2530>
1014121c4: 340026c8    	cbz	w8, 0x10141269c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2a34>
1014121c8: d2800008    	mov	x8, #0x0                ; =0
1014121cc: d2800013    	mov	x19, #0x0               ; =0
1014121d0: 52800114    	mov	w20, #0x8               ; =8
1014121d4: a90052f3    	stp	x19, x20, [x23]
1014121d8: f9000ae8    	str	x8, [x23, #0x10]
1014121dc: 140011ba    	b	0x1014168c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c5c>
1014121e0: b9400108    	ldr	w8, [x8]
1014121e4: 528f0ca9    	mov	w9, #0x7865             ; =30821
1014121e8: 72ac6ca9    	movk	w9, #0x6365, lsl #16
1014121ec: 6b09011f    	cmp	w8, w9
1014121f0: 54001a81    	b.ne	0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
1014121f4: f9400333    	ldr	x19, [x25]
1014121f8: b4001a53    	cbz	x19, 0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
1014121fc: f9400734    	ldr	x20, [x25, #0x8]
101412200: 940ed0ab    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101412204: eb1a001f    	cmp	x0, x26
101412208: 540000a1    	b.ne	0x10141221c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x25b4>
10141220c: b9407b28    	ldr	w8, [x25, #0x78]
101412210: 6b08003f    	cmp	w1, w8
101412214: 54001962    	b.hs	0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
101412218: 14000003    	b	0x101412224 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x25bc>
10141221c: eb1a001f    	cmp	x0, x26
101412220: 5400190a    	b.ge	0x101412540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28d8>
101412224: b0004662    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101412228: 911ed842    	add	x2, x2, #0x7b6
10141222c: 912783e8    	add	x8, sp, #0x9e0
101412230: aa1303e0    	mov	x0, x19
101412234: aa1403e1    	mov	x1, x20
101412238: 52800183    	mov	w3, #0xc                ; =12
10141223c: 940ec818    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101412240: f944f7f3    	ldr	x19, [sp, #0x9e8]
101412244: f944fbe1    	ldr	x1, [sp, #0x9f0]
101412248: b0004682    	adrp	x2, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
10141224c: 910a6042    	add	x2, x2, #0x298
101412250: d10283a8    	sub	x8, x29, #0xa0
101412254: aa1303e0    	mov	x0, x19
101412258: 52800083    	mov	w3, #0x4                ; =4
10141225c: 940ec810    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101412260: f944f3e1    	ldr	x1, [sp, #0x9e0]
101412264: b4000081    	cbz	x1, 0x101412274 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x260c>
101412268: aa1303e0    	mov	x0, x19
10141226c: 52800022    	mov	w2, #0x1                ; =1
101412270: 97da311b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412274: a97687b5    	ldp	x21, x1, [x29, #-0x98]
101412278: 912783e8    	add	x8, sp, #0x9e0
10141227c: aa1503e0    	mov	x0, x21
101412280: 940ea469    	bl	0x1017bb424 <__ZN3std3sys2fs8read_dir17h3de3d951fc53246fE>
101412284: 3967a3e8    	ldrb	w8, [sp, #0x9e8]
101412288: f944f3f4    	ldr	x20, [sp, #0x9e0]
10141228c: 7100091f    	cmp	w8, #0x2
101412290: 54000341    	b.ne	0x1014122f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2690>
101412294: 92400688    	and	x8, x20, #0x3
101412298: f100051f    	cmp	x8, #0x1
10141229c: 54000201    	b.ne	0x1014122dc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2674>
1014122a0: f85ffe93    	ldr	x19, [x20, #-0x1]!
1014122a4: f9400696    	ldr	x22, [x20, #0x8]
1014122a8: f94002c8    	ldr	x8, [x22]
1014122ac: b4000068    	cbz	x8, 0x1014122b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2650>
1014122b0: aa1303e0    	mov	x0, x19
1014122b4: d63f0100    	blr	x8
1014122b8: f94006c1    	ldr	x1, [x22, #0x8]
1014122bc: b4000081    	cbz	x1, 0x1014122cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2664>
1014122c0: f9400ac2    	ldr	x2, [x22, #0x10]
1014122c4: aa1303e0    	mov	x0, x19
1014122c8: 97da3105    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014122cc: aa1403e0    	mov	x0, x20
1014122d0: 52800301    	mov	w1, #0x18               ; =24
1014122d4: 52800102    	mov	w2, #0x8                ; =8
1014122d8: 97da3101    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014122dc: aa1703fc    	mov	x28, x23
1014122e0: d2800018    	mov	x24, #0x0               ; =0
1014122e4: d280001b    	mov	x27, #0x0               ; =0
1014122e8: f85603a1    	ldur	x1, [x29, #-0xa0]
1014122ec: 52800117    	mov	w23, #0x8               ; =8
1014122f0: b5000c21    	cbnz	x1, 0x101412474 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x280c>
1014122f4: 14000097    	b	0x101412550 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28e8>
1014122f8: f90083ff    	str	xzr, [sp, #0x100]
1014122fc: f90297ff    	str	xzr, [sp, #0x528]
101412300: f904abf4    	str	x20, [sp, #0x950]
101412304: 392563e8    	strb	w8, [sp, #0x958]
101412308: 52801908    	mov	w8, #0xc8               ; =200
10141230c: f904b3e8    	str	x8, [sp, #0x960]
101412310: f904b7f9    	str	x25, [sp, #0x968]
101412314: 9125c3e0    	add	x0, sp, #0x970
101412318: 910403e1    	add	x1, sp, #0x100
10141231c: 97ffafa4    	bl	0x1013fe1ac <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x484>
101412320: f944bbe8    	ldr	x8, [sp, #0x970]
101412324: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101412328: aa1703fc    	mov	x28, x23
10141232c: eb09011f    	cmp	x8, x9
101412330: 540000e1    	b.ne	0x10141234c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x26e4>
101412334: f904f3ff    	str	xzr, [sp, #0x9e0]
101412338: 910403e0    	add	x0, sp, #0x100
10141233c: 94010f16    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
101412340: d2800018    	mov	x24, #0x0               ; =0
101412344: 52800117    	mov	w23, #0x8               ; =8
101412348: 14000048    	b	0x101412468 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2800>
10141234c: 97da30e9    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101412350: 52803400    	mov	w0, #0x1a0              ; =416
101412354: 52800101    	mov	w1, #0x8                ; =8
101412358: 97da30e0    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10141235c: b4023c60    	cbz	x0, 0x101416ae8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6e80>
101412360: aa0003f3    	mov	x19, x0
101412364: 3dc26fe0    	ldr	q0, [sp, #0x9b0]
101412368: 3dc273e1    	ldr	q1, [sp, #0x9c0]
10141236c: ad020400    	stp	q0, q1, [x0, #0x40]
101412370: f944ebe8    	ldr	x8, [sp, #0x9d0]
101412374: f9003008    	str	x8, [x0, #0x60]
101412378: 3dc25fe0    	ldr	q0, [sp, #0x970]
10141237c: 3dc263e1    	ldr	q1, [sp, #0x980]
101412380: ad000400    	stp	q0, q1, [x0]
101412384: 3dc26be0    	ldr	q0, [sp, #0x9a0]
101412388: 3dc267e1    	ldr	q1, [sp, #0x990]
10141238c: ad010001    	stp	q1, q0, [x0, #0x20]
101412390: 52800088    	mov	w8, #0x4                ; =4
101412394: a90c03e8    	stp	x8, x0, [sp, #0xc0]
101412398: 52800034    	mov	w20, #0x1               ; =1
10141239c: f9006bf4    	str	x20, [sp, #0xd0]
1014123a0: 912783e0    	add	x0, sp, #0x9e0
1014123a4: 910403e1    	add	x1, sp, #0x100
1014123a8: 52810e02    	mov	w2, #0x870              ; =2160
1014123ac: 941ade1f    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014123b0: 52800d16    	mov	w22, #0x68              ; =104
1014123b4: d2f00017    	mov	x23, #-0x8000000000000000 ; =-9223372036854775808
1014123b8: 14000012    	b	0x101412400 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2798>
1014123bc: f94067f3    	ldr	x19, [sp, #0xc8]
1014123c0: 8b160268    	add	x8, x19, x22
1014123c4: 3dc497e0    	ldr	q0, [sp, #0x1250]
1014123c8: 3dc49be1    	ldr	q1, [sp, #0x1260]
1014123cc: 3dc49fe2    	ldr	q2, [sp, #0x1270]
1014123d0: ad008901    	stp	q1, q2, [x8, #0x10]
1014123d4: 3d800100    	str	q0, [x8]
1014123d8: 3dc4a3e0    	ldr	q0, [sp, #0x1280]
1014123dc: 3dc4a7e1    	ldr	q1, [sp, #0x1290]
1014123e0: 3dc4abe2    	ldr	q2, [sp, #0x12a0]
1014123e4: f9495be9    	ldr	x9, [sp, #0x12b0]
1014123e8: f9003109    	str	x9, [x8, #0x60]
1014123ec: ad020901    	stp	q1, q2, [x8, #0x40]
1014123f0: 3d800d00    	str	q0, [x8, #0x30]
1014123f4: 91000694    	add	x20, x20, #0x1
1014123f8: f9006bf4    	str	x20, [sp, #0xd0]
1014123fc: 9101a2d6    	add	x22, x22, #0x68
101412400: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101412404: 91094000    	add	x0, x0, #0x250
101412408: 912783e1    	add	x1, sp, #0x9e0
10141240c: 97ffaf68    	bl	0x1013fe1ac <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x484>
101412410: f9492be8    	ldr	x8, [sp, #0x1250]
101412414: eb17011f    	cmp	x8, x23
101412418: 54000160    	b.eq	0x101412444 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x27dc>
10141241c: f94063e8    	ldr	x8, [sp, #0xc0]
101412420: eb08029f    	cmp	x20, x8
101412424: 54fffce1    	b.ne	0x1014123c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2758>
101412428: 910303e0    	add	x0, sp, #0xc0
10141242c: aa1403e1    	mov	x1, x20
101412430: 52800022    	mov	w2, #0x1                ; =1
101412434: 52800103    	mov	w3, #0x8                ; =8
101412438: 52800d04    	mov	w4, #0x68               ; =104
10141243c: 94185905    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101412440: 17ffffdf    	b	0x1014123bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2754>
101412444: 912783e0    	add	x0, sp, #0x9e0
101412448: 94010ed3    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
10141244c: 3dc033e0    	ldr	q0, [sp, #0xc0]
101412450: 3d827be0    	str	q0, [sp, #0x9e0]
101412454: f9406bf8    	ldr	x24, [sp, #0xd0]
101412458: f904fbf8    	str	x24, [sp, #0x9f0]
10141245c: f944f7f7    	ldr	x23, [sp, #0x9e8]
101412460: f1000b1f    	cmp	x24, #0x2
101412464: 5401e7e2    	b.hs	0x101416160 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x64f8>
101412468: f944f3fb    	ldr	x27, [sp, #0x9e0]
10141246c: f85603a1    	ldur	x1, [x29, #-0xa0]
101412470: b4000701    	cbz	x1, 0x101412550 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28e8>
101412474: aa1503e0    	mov	x0, x21
101412478: 52800022    	mov	w2, #0x1                ; =1
10141247c: 97da3098    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412480: 14000034    	b	0x101412550 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28e8>
101412484: ad4a07e0    	ldp	q0, q1, [sp, #0x140]
101412488: 3d828be0    	str	q0, [sp, #0xa20]
10141248c: 3d828fe1    	str	q1, [sp, #0xa30]
101412490: f940b3e8    	ldr	x8, [sp, #0x160]
101412494: f90523e8    	str	x8, [sp, #0xa40]
101412498: ad4807e0    	ldp	q0, q1, [sp, #0x100]
10141249c: 3d827be0    	str	q0, [sp, #0x9e0]
1014124a0: 3d827fe1    	str	q1, [sp, #0x9f0]
1014124a4: ad4903e1    	ldp	q1, q0, [sp, #0x120]
1014124a8: 3d8287e0    	str	q0, [sp, #0xa10]
1014124ac: 3d8283e1    	str	q1, [sp, #0xa00]
1014124b0: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
1014124b4: 91094108    	add	x8, x8, #0x250
1014124b8: 912783e0    	add	x0, sp, #0x9e0
1014124bc: 94020481    	bl	0x1014936c0 <__ZN10otty_state8anywhere3sql19hidden_host_aliases17h5a502cbbca5ac6edE>
1014124c0: 928000c8    	mov	x8, #-0x7               ; =-7
1014124c4: f2efffe8    	movk	x8, #0x7fff, lsl #48
1014124c8: f9492be9    	ldr	x9, [sp, #0x1250]
1014124cc: 91006908    	add	x8, x8, #0x1a
1014124d0: eb08013f    	cmp	x9, x8
1014124d4: 540012a1    	b.ne	0x101412728 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2ac0>
1014124d8: f9492fe8    	ldr	x8, [sp, #0x1258]
1014124dc: f94933e9    	ldr	x9, [sp, #0x1260]
1014124e0: f94937f3    	ldr	x19, [sp, #0x1268]
1014124e4: 14000097    	b	0x101412740 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2ad8>
1014124e8: b400018b    	cbz	x11, 0x101412518 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28b0>
1014124ec: f100057f    	cmp	x11, #0x1
1014124f0: 54ffba81    	b.ne	0x101411c40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1fd8>
1014124f4: 97da307f    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014124f8: 52800033    	mov	w19, #0x1               ; =1
1014124fc: 52800020    	mov	w0, #0x1                ; =1
101412500: 52800021    	mov	w1, #0x1                ; =1
101412504: 97da3075    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101412508: b401a9c0    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
10141250c: aa0003e9    	mov	x9, x0
101412510: 3900001f    	strb	wzr, [x0]
101412514: 140004a5    	b	0x1014137a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b40>
101412518: 97da3076    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10141251c: 52800033    	mov	w19, #0x1               ; =1
101412520: 52800020    	mov	w0, #0x1                ; =1
101412524: 52800021    	mov	w1, #0x1                ; =1
101412528: 97da306c    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10141252c: b401a8a0    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
101412530: aa0003e9    	mov	x9, x0
101412534: 52800048    	mov	w8, #0x2                ; =2
101412538: 1400049b    	b	0x1014137a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b3c>
10141253c: b400010a    	cbz	x10, 0x10141255c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28f4>
101412540: aa1703fc    	mov	x28, x23
101412544: d2800018    	mov	x24, #0x0               ; =0
101412548: d280001b    	mov	x27, #0x0               ; =0
10141254c: 52800117    	mov	w23, #0x8               ; =8
101412550: a9005f9b    	stp	x27, x23, [x28]
101412554: f9000b98    	str	x24, [x28, #0x10]
101412558: 140010db    	b	0x1014168c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c5c>
10141255c: aa1703fc    	mov	x28, x23
101412560: f9400333    	ldr	x19, [x25]
101412564: b4ffff13    	cbz	x19, 0x101412544 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28dc>
101412568: f9400734    	ldr	x20, [x25, #0x8]
10141256c: b9407b28    	ldr	w8, [x25, #0x78]
101412570: b900bbe8    	str	w8, [sp, #0xb8]
101412574: 52800156    	mov	w22, #0xa               ; =10
101412578: 52800117    	mov	w23, #0x8               ; =8
10141257c: 14000005    	b	0x101412590 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2928>
101412580: d2800018    	mov	x24, #0x0               ; =0
101412584: d280001b    	mov	x27, #0x0               ; =0
101412588: f10006d6    	subs	x22, x22, #0x1
10141258c: 54fffe20    	b.eq	0x101412550 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28e8>
101412590: 940ecfc7    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101412594: eb1a001f    	cmp	x0, x26
101412598: 540000a1    	b.ne	0x1014125ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2944>
10141259c: b940bbe8    	ldr	w8, [sp, #0xb8]
1014125a0: 6b08003f    	cmp	w1, w8
1014125a4: 54000083    	b.lo	0x1014125b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x294c>
1014125a8: 1400036e    	b	0x101413360 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x36f8>
1014125ac: eb1a001f    	cmp	x0, x26
1014125b0: 54006d8a    	b.ge	0x101413360 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x36f8>
1014125b4: 910403e8    	add	x8, sp, #0x100
1014125b8: aa1303e0    	mov	x0, x19
1014125bc: aa1403e1    	mov	x1, x20
1014125c0: b0004662    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014125c4: 911f1442    	add	x2, x2, #0x7c5
1014125c8: 52800183    	mov	w3, #0xc                ; =12
1014125cc: 940ec734    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
1014125d0: a950e3f5    	ldp	x21, x24, [sp, #0x108]
1014125d4: 912783e8    	add	x8, sp, #0x9e0
1014125d8: aa1503e0    	mov	x0, x21
1014125dc: aa1803e1    	mov	x1, x24
1014125e0: 940ea347    	bl	0x1017bb2fc <__ZN3std3sys2fs8metadata17h317aa82d489c5e37E>
1014125e4: b949e3e8    	ldr	w8, [sp, #0x9e0]
1014125e8: 36006c28    	tbz	w8, #0x0, 0x10141336c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3704>
1014125ec: f944f7f8    	ldr	x24, [sp, #0x9e8]
1014125f0: 92400708    	and	x8, x24, #0x3
1014125f4: f100051f    	cmp	x8, #0x1
1014125f8: 54000281    	b.ne	0x101412648 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x29e0>
1014125fc: f9005bf5    	str	x21, [sp, #0xb0]
101412600: aa1903f5    	mov	x21, x25
101412604: f85fff19    	ldr	x25, [x24, #-0x1]!
101412608: f940071b    	ldr	x27, [x24, #0x8]
10141260c: f9400368    	ldr	x8, [x27]
101412610: b4000068    	cbz	x8, 0x10141261c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x29b4>
101412614: aa1903e0    	mov	x0, x25
101412618: d63f0100    	blr	x8
10141261c: f9400761    	ldr	x1, [x27, #0x8]
101412620: b4000081    	cbz	x1, 0x101412630 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x29c8>
101412624: f9400b62    	ldr	x2, [x27, #0x10]
101412628: aa1903e0    	mov	x0, x25
10141262c: 97da302c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412630: aa1803e0    	mov	x0, x24
101412634: 52800301    	mov	w1, #0x18               ; =24
101412638: 52800102    	mov	w2, #0x8                ; =8
10141263c: 97da3028    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412640: aa1503f9    	mov	x25, x21
101412644: f9405bf5    	ldr	x21, [sp, #0xb0]
101412648: aa1303e0    	mov	x0, x19
10141264c: aa1403e1    	mov	x1, x20
101412650: 940ec7e6    	bl	0x1017c45e8 <__ZN3std4path4Path6parent17h81615573672c555dE>
101412654: aa0003f3    	mov	x19, x0
101412658: b4006a00    	cbz	x0, 0x101413398 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3730>
10141265c: aa0103f4    	mov	x20, x1
101412660: f94083e1    	ldr	x1, [sp, #0x100]
101412664: b4fff8e1    	cbz	x1, 0x101412580 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2918>
101412668: aa1503e0    	mov	x0, x21
10141266c: 52800022    	mov	w2, #0x1                ; =1
101412670: 97da301b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412674: 17ffffc3    	b	0x101412580 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2918>
101412678: 97da301e    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10141267c: 52800033    	mov	w19, #0x1               ; =1
101412680: 52800020    	mov	w0, #0x1                ; =1
101412684: 52800021    	mov	w1, #0x1                ; =1
101412688: 97da3014    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10141268c: b4019da0    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
101412690: aa0003e9    	mov	x9, x0
101412694: 528000a8    	mov	w8, #0x5                ; =5
101412698: 14000443    	b	0x1014137a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b3c>
10141269c: f9401b33    	ldr	x19, [x25, #0x30]
1014126a0: f1003ebf    	cmp	x21, #0xf
1014126a4: 54006828    	b.hi	0x1014133a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3740>
1014126a8: aa1303e8    	mov	x8, x19
1014126ac: aa1503e9    	mov	x9, x21
1014126b0: 3840150a    	ldrb	w10, [x8], #0x1
1014126b4: 7100bd5f    	cmp	w10, #0x2f
1014126b8: 54006840    	b.eq	0x1014133c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3758>
1014126bc: f1000529    	subs	x9, x9, #0x1
1014126c0: 54ffff81    	b.ne	0x1014126b0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2a48>
1014126c4: 1400036d    	b	0x101413478 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3810>
1014126c8: f100093f    	cmp	x9, #0x2
1014126cc: 54008b60    	b.eq	0x101413838 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3bd0>
1014126d0: aa1303f5    	mov	x21, x19
1014126d4: f100153f    	cmp	x9, #0x5
1014126d8: 5400efa1    	b.ne	0x1014144cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4864>
1014126dc: b9400109    	ldr	w9, [x8]
1014126e0: 39401108    	ldrb	w8, [x8, #0x4]
1014126e4: 5285a5aa    	mov	w10, #0x2d2d            ; =11565
1014126e8: 72ad2c4a    	movk	w10, #0x6962, lsl #16
1014126ec: 6b0a013f    	cmp	w9, w10
1014126f0: 52800dc9    	mov	w9, #0x6e               ; =110
1014126f4: 7a490100    	ccmp	w8, w9, #0x0, eq
1014126f8: 5400ee41    	b.ne	0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
1014126fc: b900b3ff    	str	wzr, [sp, #0xb0]
101412700: 1400068d    	b	0x101414134 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44cc>
101412704: 97da2ffb    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101412708: 52800033    	mov	w19, #0x1               ; =1
10141270c: 52800020    	mov	w0, #0x1                ; =1
101412710: 52800021    	mov	w1, #0x1                ; =1
101412714: 97da2ff1    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101412718: b4019940    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
10141271c: aa0003e9    	mov	x9, x0
101412720: 528000e8    	mov	w8, #0x7                ; =7
101412724: 14000420    	b	0x1014137a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b3c>
101412728: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10141272c: 91094000    	add	x0, x0, #0x250
101412730: 94010381    	bl	0x101453534 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x60ac>
101412734: d2800013    	mov	x19, #0x0               ; =0
101412738: d2800008    	mov	x8, #0x0                ; =0
10141273c: 52800109    	mov	w9, #0x8                ; =8
101412740: 5280030a    	mov	w10, #0x18              ; =24
101412744: 9b0a266a    	madd	x10, x19, x10, x9
101412748: a90c27e9    	stp	x9, x9, [sp, #0xc0]
10141274c: a90d2be8    	stp	x8, x10, [sp, #0xd0]
101412750: d0007b40    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101412754: 9131a000    	add	x0, x0, #0xc68
101412758: f9400008    	ldr	x8, [x0]
10141275c: d63f0100    	blr	x8
101412760: aa0003f4    	mov	x20, x0
101412764: 39404008    	ldrb	w8, [x0, #0x10]
101412768: 7100051f    	cmp	w8, #0x1
10141276c: 54020dc1    	b.ne	0x101416924 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6cbc>
101412770: a9400680    	ldp	x0, x1, [x20]
101412774: 91000408    	add	x8, x0, #0x1
101412778: f9000288    	str	x8, [x20]
10141277c: d00072a8    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101412780: 91166108    	add	x8, x8, #0x598
101412784: ad400500    	ldp	q0, q1, [x8]
101412788: 3d8497e0    	str	q0, [sp, #0x1250]
10141278c: 3d849be1    	str	q1, [sp, #0x1260]
101412790: f9093be0    	str	x0, [sp, #0x1270]
101412794: f9093fe1    	str	x1, [sp, #0x1278]
101412798: b5020d13    	cbnz	x19, 0x101416938 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6cd0>
10141279c: ad4603e1    	ldp	q1, q0, [sp, #0xc0]
1014127a0: 3d8263e0    	str	q0, [sp, #0x980]
1014127a4: 3d825fe1    	str	q1, [sp, #0x970]
1014127a8: f944c7f4    	ldr	x20, [sp, #0x988]
1014127ac: f944bff3    	ldr	x19, [sp, #0x978]
1014127b0: eb14027f    	cmp	x19, x20
1014127b4: 54000160    	b.eq	0x1014127e0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2b78>
1014127b8: 3dc00260    	ldr	q0, [x19]
1014127bc: 3c9603a0    	stur	q0, [x29, #-0xa0]
1014127c0: f9400a68    	ldr	x8, [x19, #0x10]
1014127c4: f81703a8    	stur	x8, [x29, #-0x90]
1014127c8: 91006273    	add	x19, x19, #0x18
1014127cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014127d0: 91094000    	add	x0, x0, #0x250
1014127d4: d10283a1    	sub	x1, x29, #0xa0
1014127d8: 940190dd    	bl	0x101476b4c <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xee0>
1014127dc: 17fffff5    	b	0x1014127b0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2b48>
1014127e0: f944c3e8    	ldr	x8, [sp, #0x980]
1014127e4: b40000c8    	cbz	x8, 0x1014127fc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2b94>
1014127e8: f944bbe0    	ldr	x0, [sp, #0x970]
1014127ec: 8b080508    	add	x8, x8, x8, lsl #1
1014127f0: d37df101    	lsl	x1, x8, #3
1014127f4: 52800102    	mov	w2, #0x8                ; =8
1014127f8: 97da2fb9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014127fc: f9492be9    	ldr	x9, [sp, #0x1250]
101412800: f9492ffc    	ldr	x28, [sp, #0x1258]
101412804: f94937f7    	ldr	x23, [sp, #0x1268]
101412808: f9493bf4    	ldr	x20, [sp, #0x1270]
10141280c: f9493fe8    	ldr	x8, [sp, #0x1278]
101412810: a90aa7e8    	stp	x8, x9, [sp, #0xa8]
101412814: 912783e0    	add	x0, sp, #0x9e0
101412818: 94010211    	bl	0x10145305c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5bd4>
10141281c: f85403a1    	ldur	x1, [x29, #-0xc0]
101412820: b4000081    	cbz	x1, 0x101412830 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2bc8>
101412824: aa1903e0    	mov	x0, x25
101412828: 52800022    	mov	w2, #0x1                ; =1
10141282c: 97da2fac    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412830: a972ebb3    	ldp	x19, x26, [x29, #-0xd8]
101412834: f85383b9    	ldur	x25, [x29, #-0xc8]
101412838: b4001137    	cbz	x23, 0x101412a5c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2df4>
10141283c: f90053f4    	str	x20, [sp, #0xa0]
101412840: a9085bf3    	stp	x19, x22, [sp, #0x80]
101412844: aa1a03fb    	mov	x27, x26
101412848: b4000a19    	cbz	x25, 0x101412988 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d20>
10141284c: 52800308    	mov	w8, #0x18               ; =24
101412850: 9b086b28    	madd	x8, x25, x8, x26
101412854: f9004fe8    	str	x8, [sp, #0x98]
101412858: aa1a03f4    	mov	x20, x26
10141285c: aa1a03fb    	mov	x27, x26
101412860: 14000034    	b	0x101412930 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2cc8>
101412864: aa1c03f6    	mov	x22, x28
101412868: 8a1c001c    	and	x28, x0, x28
10141286c: f9405be8    	ldr	x8, [sp, #0xb0]
101412870: fc7c6909    	ldr	d9, [x8, x28]
101412874: 2e288d20    	cmeq.8b	v0, v9, v8
101412878: 9e660008    	fmov	x8, d0
10141287c: f201c11a    	ands	x26, x8, #0x8080808080808080
101412880: 54000280    	b.eq	0x1014128d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2c68>
101412884: dac00348    	rbit	x8, x26
101412888: dac01108    	clz	x8, x8
10141288c: 8b480f88    	add	x8, x28, x8, lsr #3
101412890: 8a160108    	and	x8, x8, x22
101412894: 52800309    	mov	w9, #0x18               ; =24
101412898: 9b09fd08    	mneg	x8, x8, x9
10141289c: f9405be9    	ldr	x9, [sp, #0xb0]
1014128a0: 8b080128    	add	x8, x9, x8
1014128a4: f85f8109    	ldur	x9, [x8, #-0x8]
1014128a8: eb09033f    	cmp	x25, x9
1014128ac: 540000c1    	b.ne	0x1014128c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2c5c>
1014128b0: f85f0101    	ldur	x1, [x8, #-0x10]
1014128b4: aa1803e0    	mov	x0, x24
1014128b8: aa1903e2    	mov	x2, x25
1014128bc: 941adcd8    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
1014128c0: 340001a0    	cbz	w0, 0x1014128f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2c8c>
1014128c4: d1000748    	sub	x8, x26, #0x1
1014128c8: ea1a011a    	ands	x26, x8, x26
1014128cc: 54fffdc1    	b.ne	0x101412884 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2c1c>
1014128d0: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
1014128d4: 2e208d20    	cmeq.8b	v0, v9, v0
1014128d8: 2e30a800    	umaxv.8b	b0, v0
1014128dc: 1e260008    	fmov	w8, s0
1014128e0: 37000168    	tbnz	w8, #0x0, 0x10141290c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2ca4>
1014128e4: 91002273    	add	x19, x19, #0x8
1014128e8: 8b130380    	add	x0, x28, x19
1014128ec: aa1603fc    	mov	x28, x22
1014128f0: 17ffffdd    	b	0x101412864 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2bfc>
1014128f4: f944fbe1    	ldr	x1, [sp, #0x9f0]
1014128f8: b4000121    	cbz	x1, 0x10141291c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2cb4>
1014128fc: aa1803e0    	mov	x0, x24
101412900: 52800022    	mov	w2, #0x1                ; =1
101412904: 97da2f76    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412908: 14000005    	b	0x10141291c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2cb4>
10141290c: 3dc043e0    	ldr	q0, [sp, #0x100]
101412910: f9408be8    	ldr	x8, [sp, #0x110]
101412914: f9000b68    	str	x8, [x27, #0x10]
101412918: 3c818760    	str	q0, [x27], #0x18
10141291c: aa1503fa    	mov	x26, x21
101412920: aa1603fc    	mov	x28, x22
101412924: f9404fe8    	ldr	x8, [sp, #0x98]
101412928: eb08029f    	cmp	x20, x8
10141292c: 540002e0    	b.eq	0x101412988 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d20>
101412930: 3dc00280    	ldr	q0, [x20]
101412934: 3d8043e0    	str	q0, [sp, #0x100]
101412938: f9400a88    	ldr	x8, [x20, #0x10]
10141293c: f9008be8    	str	x8, [sp, #0x110]
101412940: aa1a03f5    	mov	x21, x26
101412944: f904f3fa    	str	x26, [sp, #0x9e0]
101412948: f904f7fb    	str	x27, [sp, #0x9e8]
10141294c: 3dc00280    	ldr	q0, [x20]
101412950: 912783e9    	add	x9, sp, #0x9e0
101412954: 3c810120    	stur	q0, [x9, #0x10]
101412958: f9400a88    	ldr	x8, [x20, #0x10]
10141295c: 91006294    	add	x20, x20, #0x18
101412960: f8020128    	stur	x8, [x9, #0x20]
101412964: 91004122    	add	x2, x9, #0x10
101412968: a94a07e0    	ldp	x0, x1, [sp, #0xa0]
10141296c: 97d4ebc4    	bl	0x10094d87c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3a854>
101412970: d2800013    	mov	x19, #0x0               ; =0
101412974: d379fc08    	lsr	x8, x0, #57
101412978: 0e010d08    	dup.8b	v8, w8
10141297c: f94503f9    	ldr	x25, [sp, #0xa00]
101412980: f944fff8    	ldr	x24, [sp, #0x9f8]
101412984: 17ffffb8    	b	0x101412864 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2bfc>
101412988: cb1a0368    	sub	x8, x27, x26
10141298c: d343fd08    	lsr	x8, x8, #3
101412990: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
101412994: f2955569    	movk	x9, #0xaaab
101412998: 9b097d19    	mul	x25, x8, x9
10141299c: b400051c    	cbz	x28, 0x101412a3c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2dd4>
1014129a0: f9405bf3    	ldr	x19, [sp, #0xb0]
1014129a4: aa1303f4    	mov	x20, x19
1014129a8: fc408680    	ldr	d0, [x20], #0x8
1014129ac: 2e208800    	cmge.8b	v0, v0, #0
1014129b0: 9e660008    	fmov	x8, d0
1014129b4: 9201c116    	and	x22, x8, #0x8080808080808080
1014129b8: 52800315    	mov	w21, #0x18              ; =24
1014129bc: 14000005    	b	0x1014129d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d68>
1014129c0: d10006c8    	sub	x8, x22, #0x1
1014129c4: 8a160116    	and	x22, x8, x22
1014129c8: d10006f7    	sub	x23, x23, #0x1
1014129cc: b4000257    	cbz	x23, 0x101412a14 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2dac>
1014129d0: b50000f6    	cbnz	x22, 0x1014129ec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d84>
1014129d4: fc408680    	ldr	d0, [x20], #0x8
1014129d8: 2e208800    	cmge.8b	v0, v0, #0
1014129dc: 9e660008    	fmov	x8, d0
1014129e0: d1030273    	sub	x19, x19, #0xc0
1014129e4: 9201c116    	and	x22, x8, #0x8080808080808080
1014129e8: b4ffff76    	cbz	x22, 0x1014129d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d6c>
1014129ec: dac002c8    	rbit	x8, x22
1014129f0: dac01108    	clz	x8, x8
1014129f4: cb480fe8    	neg	x8, x8, lsr #3
1014129f8: 9b354d08    	smaddl	x8, w8, w21, x19
1014129fc: f85e8101    	ldur	x1, [x8, #-0x18]
101412a00: b4fffe01    	cbz	x1, 0x1014129c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d58>
101412a04: f85f0100    	ldur	x0, [x8, #-0x10]
101412a08: 52800022    	mov	w2, #0x1                ; =1
101412a0c: 97da2f34    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412a10: 17ffffec    	b	0x1014129c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2d58>
101412a14: 8b1c0788    	add	x8, x28, x28, lsl #1
101412a18: d37df108    	lsl	x8, x8, #3
101412a1c: 8b1c0109    	add	x9, x8, x28
101412a20: b1008521    	adds	x1, x9, #0x21
101412a24: 540000c0    	b.eq	0x101412a3c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2dd4>
101412a28: f9405be9    	ldr	x9, [sp, #0xb0]
101412a2c: cb080128    	sub	x8, x9, x8
101412a30: d1006100    	sub	x0, x8, #0x18
101412a34: 52800102    	mov	w2, #0x8                ; =8
101412a38: 97da2f29    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412a3c: f94997e1    	ldr	x1, [sp, #0x1328]
101412a40: f94043f3    	ldr	x19, [sp, #0x80]
101412a44: b4000081    	cbz	x1, 0x101412a54 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2dec>
101412a48: f9499be0    	ldr	x0, [sp, #0x1330]
101412a4c: 52800022    	mov	w2, #0x1                ; =1
101412a50: 97da2f23    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412a54: f94047f6    	ldr	x22, [sp, #0x88]
101412a58: 14000dd9    	b	0x1014161bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6554>
101412a5c: b401ba7c    	cbz	x28, 0x1014161a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6540>
101412a60: 8b1c0788    	add	x8, x28, x28, lsl #1
101412a64: d37df108    	lsl	x8, x8, #3
101412a68: 8b1c0109    	add	x9, x8, x28
101412a6c: b1008521    	adds	x1, x9, #0x21
101412a70: 5401b9c0    	b.eq	0x1014161a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6540>
101412a74: f9405be9    	ldr	x9, [sp, #0xb0]
101412a78: cb080128    	sub	x8, x9, x8
101412a7c: d1006100    	sub	x0, x8, #0x18
101412a80: 52800102    	mov	w2, #0x8                ; =8
101412a84: 97da2f16    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412a88: 14000dc8    	b	0x1014161a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6540>
101412a8c: 79400109    	ldrh	w9, [x8]
101412a90: 528e0eaa    	mov	w10, #0x7075            ; =28789
101412a94: 6b0a013f    	cmp	w9, w10
101412a98: 540006c0    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412a9c: 79400109    	ldrh	w9, [x8]
101412aa0: 528dae4a    	mov	w10, #0x6d72            ; =28018
101412aa4: 6b0a013f    	cmp	w9, w10
101412aa8: 54000640    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412aac: 79400108    	ldrh	w8, [x8]
101412ab0: 528e6e09    	mov	w9, #0x7370             ; =29552
101412ab4: 6b09011f    	cmp	w8, w9
101412ab8: 54ff3561    	b.ne	0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
101412abc: 1400002d    	b	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412ac0: b9400109    	ldr	w9, [x8]
101412ac4: 3940110a    	ldrb	w10, [x8, #0x4]
101412ac8: 528e8e6b    	mov	w11, #0x7473            ; =29811
101412acc: 72ae4c2b    	movk	w11, #0x7261, lsl #16
101412ad0: 6b0b013f    	cmp	w9, w11
101412ad4: 52800e89    	mov	w9, #0x74               ; =116
101412ad8: 7a490140    	ccmp	w10, w9, #0x0, eq
101412adc: 540004a0    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412ae0: b9400109    	ldr	w9, [x8]
101412ae4: 3940110a    	ldrb	w10, [x8, #0x4]
101412ae8: 528c2e0b    	mov	w11, #0x6170            ; =24944
101412aec: 72ae6eab    	movk	w11, #0x7375, lsl #16
101412af0: 6b0b013f    	cmp	w9, w11
101412af4: 52800ca9    	mov	w9, #0x65               ; =101
101412af8: 7a490140    	ccmp	w10, w9, #0x0, eq
101412afc: 540003a0    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412b00: b9400109    	ldr	w9, [x8]
101412b04: 39401108    	ldrb	w8, [x8, #0x4]
101412b08: 528eac4a    	mov	w10, #0x7562            ; =30050
101412b0c: 72ad8d2a    	movk	w10, #0x6c69, lsl #16
101412b10: 6b0a013f    	cmp	w9, w10
101412b14: 52800c89    	mov	w9, #0x64               ; =100
101412b18: 14000014    	b	0x101412b68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f00>
101412b1c: 79400109    	ldrh	w9, [x8]
101412b20: 3940090a    	ldrb	w10, [x8, #0x2]
101412b24: 528eae4b    	mov	w11, #0x7572            ; =30066
101412b28: 6b0b013f    	cmp	w9, w11
101412b2c: 52800dc9    	mov	w9, #0x6e               ; =110
101412b30: 7a490140    	ccmp	w10, w9, #0x0, eq
101412b34: 540001e0    	b.eq	0x101412b70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f08>
101412b38: 79400109    	ldrh	w9, [x8]
101412b3c: 39400908    	ldrb	w8, [x8, #0x2]
101412b40: 528dee8a    	mov	w10, #0x6f74            ; =28532
101412b44: 6b0a013f    	cmp	w9, w10
101412b48: 52800e09    	mov	w9, #0x70               ; =112
101412b4c: 14000007    	b	0x101412b68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f00>
101412b50: b9400109    	ldr	w9, [x8]
101412b54: 79400908    	ldrh	w8, [x8, #0x4]
101412b58: 528e4c6a    	mov	w10, #0x7263            ; =29283
101412b5c: 72ac2caa    	movk	w10, #0x6165, lsl #16
101412b60: 6b0a013f    	cmp	w9, w10
101412b64: 528cae89    	mov	w9, #0x6574             ; =25972
101412b68: 7a490100    	ccmp	w8, w9, #0x0, eq
101412b6c: 54ff2fc1    	b.ne	0x101411164 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x14fc>
101412b70: f9400333    	ldr	x19, [x25]
101412b74: b40032b3    	cbz	x19, 0x1014131c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3560>
101412b78: f9400734    	ldr	x20, [x25, #0x8]
101412b7c: b0004662    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101412b80: 91242442    	add	x2, x2, #0x909
101412b84: 912783e8    	add	x8, sp, #0x9e0
101412b88: aa1303e0    	mov	x0, x19
101412b8c: aa1403e1    	mov	x1, x20
101412b90: 52800163    	mov	w3, #0xb                ; =11
101412b94: 940ec5c2    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101412b98: f944f7f5    	ldr	x21, [sp, #0x9e8]
101412b9c: f944fbe1    	ldr	x1, [sp, #0x9f0]
101412ba0: 910403e8    	add	x8, sp, #0x100
101412ba4: aa1503e0    	mov	x0, x21
101412ba8: 940e76d1    	bl	0x1017b06ec <__ZN3std2fs14read_to_string5inner17h33327e834bd59c04E>
101412bac: f9001ff9    	str	x25, [sp, #0x38]
101412bb0: f944f3e1    	ldr	x1, [sp, #0x9e0]
101412bb4: b4000081    	cbz	x1, 0x101412bc4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f5c>
101412bb8: aa1503e0    	mov	x0, x21
101412bbc: 52800022    	mov	w2, #0x1                ; =1
101412bc0: 97da2ec7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412bc4: f94083f5    	ldr	x21, [sp, #0x100]
101412bc8: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101412bcc: eb0802bf    	cmp	x21, x8
101412bd0: 54001281    	b.ne	0x101412e20 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x31b8>
101412bd4: f94087f5    	ldr	x21, [sp, #0x108]
101412bd8: 924006a8    	and	x8, x21, #0x3
101412bdc: f100051f    	cmp	x8, #0x1
101412be0: 54000241    	b.ne	0x101412c28 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2fc0>
101412be4: aa1703f6    	mov	x22, x23
101412be8: f85ffeb8    	ldr	x24, [x21, #-0x1]!
101412bec: f94006b7    	ldr	x23, [x21, #0x8]
101412bf0: f94002e8    	ldr	x8, [x23]
101412bf4: b4000068    	cbz	x8, 0x101412c00 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2f98>
101412bf8: aa1803e0    	mov	x0, x24
101412bfc: d63f0100    	blr	x8
101412c00: f94006e1    	ldr	x1, [x23, #0x8]
101412c04: b4000081    	cbz	x1, 0x101412c14 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2fac>
101412c08: f9400ae2    	ldr	x2, [x23, #0x10]
101412c0c: aa1803e0    	mov	x0, x24
101412c10: 97da2eb3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412c14: aa1503e0    	mov	x0, x21
101412c18: 52800301    	mov	w1, #0x18               ; =24
101412c1c: 52800102    	mov	w2, #0x8                ; =8
101412c20: 97da2eaf    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412c24: aa1603f7    	mov	x23, x22
101412c28: b0004662    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101412c2c: 91245042    	add	x2, x2, #0x914
101412c30: 912783e8    	add	x8, sp, #0x9e0
101412c34: aa1303e0    	mov	x0, x19
101412c38: aa1403e1    	mov	x1, x20
101412c3c: 52800183    	mov	w3, #0xc                ; =12
101412c40: 940ec597    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101412c44: f944f7f5    	ldr	x21, [sp, #0x9e8]
101412c48: f944fbe1    	ldr	x1, [sp, #0x9f0]
101412c4c: 910403e8    	add	x8, sp, #0x100
101412c50: aa1503e0    	mov	x0, x21
101412c54: 940e76a6    	bl	0x1017b06ec <__ZN3std2fs14read_to_string5inner17h33327e834bd59c04E>
101412c58: f944f3e1    	ldr	x1, [sp, #0x9e0]
101412c5c: b4000081    	cbz	x1, 0x101412c6c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3004>
101412c60: aa1503e0    	mov	x0, x21
101412c64: 52800022    	mov	w2, #0x1                ; =1
101412c68: 97da2e9d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412c6c: f94083f5    	ldr	x21, [sp, #0x100]
101412c70: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101412c74: eb0802bf    	cmp	x21, x8
101412c78: 54000d41    	b.ne	0x101412e20 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x31b8>
101412c7c: f94087f5    	ldr	x21, [sp, #0x108]
101412c80: 924006a8    	and	x8, x21, #0x3
101412c84: f100051f    	cmp	x8, #0x1
101412c88: 54000241    	b.ne	0x101412cd0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3068>
101412c8c: aa1703f6    	mov	x22, x23
101412c90: f85ffeb8    	ldr	x24, [x21, #-0x1]!
101412c94: f94006b7    	ldr	x23, [x21, #0x8]
101412c98: f94002e8    	ldr	x8, [x23]
101412c9c: b4000068    	cbz	x8, 0x101412ca8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3040>
101412ca0: aa1803e0    	mov	x0, x24
101412ca4: d63f0100    	blr	x8
101412ca8: f94006e1    	ldr	x1, [x23, #0x8]
101412cac: b4000081    	cbz	x1, 0x101412cbc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3054>
101412cb0: f9400ae2    	ldr	x2, [x23, #0x10]
101412cb4: aa1803e0    	mov	x0, x24
101412cb8: 97da2e89    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412cbc: aa1503e0    	mov	x0, x21
101412cc0: 52800301    	mov	w1, #0x18               ; =24
101412cc4: 52800102    	mov	w2, #0x8                ; =8
101412cc8: 97da2e85    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412ccc: aa1603f7    	mov	x23, x22
101412cd0: b0004662    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101412cd4: 91248042    	add	x2, x2, #0x920
101412cd8: 912783e8    	add	x8, sp, #0x9e0
101412cdc: aa1303e0    	mov	x0, x19
101412ce0: aa1403e1    	mov	x1, x20
101412ce4: 52800243    	mov	w3, #0x12               ; =18
101412ce8: 940ec56d    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101412cec: f944f7f5    	ldr	x21, [sp, #0x9e8]
101412cf0: f944fbe1    	ldr	x1, [sp, #0x9f0]
101412cf4: 910403e8    	add	x8, sp, #0x100
101412cf8: aa1503e0    	mov	x0, x21
101412cfc: 940e767c    	bl	0x1017b06ec <__ZN3std2fs14read_to_string5inner17h33327e834bd59c04E>
101412d00: f944f3e1    	ldr	x1, [sp, #0x9e0]
101412d04: b4000081    	cbz	x1, 0x101412d14 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x30ac>
101412d08: aa1503e0    	mov	x0, x21
101412d0c: 52800022    	mov	w2, #0x1                ; =1
101412d10: 97da2e73    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412d14: f94083f5    	ldr	x21, [sp, #0x100]
101412d18: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101412d1c: eb0802bf    	cmp	x21, x8
101412d20: 54000801    	b.ne	0x101412e20 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x31b8>
101412d24: f94087f5    	ldr	x21, [sp, #0x108]
101412d28: 924006a8    	and	x8, x21, #0x3
101412d2c: f100051f    	cmp	x8, #0x1
101412d30: 54000241    	b.ne	0x101412d78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3110>
101412d34: aa1703f6    	mov	x22, x23
101412d38: f85ffeb8    	ldr	x24, [x21, #-0x1]!
101412d3c: f94006b7    	ldr	x23, [x21, #0x8]
101412d40: f94002e8    	ldr	x8, [x23]
101412d44: b4000068    	cbz	x8, 0x101412d50 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x30e8>
101412d48: aa1803e0    	mov	x0, x24
101412d4c: d63f0100    	blr	x8
101412d50: f94006e1    	ldr	x1, [x23, #0x8]
101412d54: b4000081    	cbz	x1, 0x101412d64 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x30fc>
101412d58: f9400ae2    	ldr	x2, [x23, #0x10]
101412d5c: aa1803e0    	mov	x0, x24
101412d60: 97da2e5f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412d64: aa1503e0    	mov	x0, x21
101412d68: 52800301    	mov	w1, #0x18               ; =24
101412d6c: 52800102    	mov	w2, #0x8                ; =8
101412d70: 97da2e5b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412d74: aa1603f7    	mov	x23, x22
101412d78: b0004662    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101412d7c: 9124c842    	add	x2, x2, #0x932
101412d80: 912783e8    	add	x8, sp, #0x9e0
101412d84: aa1303e0    	mov	x0, x19
101412d88: aa1403e1    	mov	x1, x20
101412d8c: 52800263    	mov	w3, #0x13               ; =19
101412d90: 940ec543    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101412d94: f944f7f5    	ldr	x21, [sp, #0x9e8]
101412d98: f944fbe1    	ldr	x1, [sp, #0x9f0]
101412d9c: 910403e8    	add	x8, sp, #0x100
101412da0: aa1503e0    	mov	x0, x21
101412da4: 940e7652    	bl	0x1017b06ec <__ZN3std2fs14read_to_string5inner17h33327e834bd59c04E>
101412da8: f944f3e1    	ldr	x1, [sp, #0x9e0]
101412dac: b4000081    	cbz	x1, 0x101412dbc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3154>
101412db0: aa1503e0    	mov	x0, x21
101412db4: 52800022    	mov	w2, #0x1                ; =1
101412db8: 97da2e49    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412dbc: f94083f5    	ldr	x21, [sp, #0x100]
101412dc0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101412dc4: eb0802bf    	cmp	x21, x8
101412dc8: 540002c1    	b.ne	0x101412e20 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x31b8>
101412dcc: aa1703f6    	mov	x22, x23
101412dd0: f94087f5    	ldr	x21, [sp, #0x108]
101412dd4: 924006a8    	and	x8, x21, #0x3
101412dd8: f100051f    	cmp	x8, #0x1
101412ddc: 54ff1c61    	b.ne	0x101411168 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1500>
101412de0: f85ffeb8    	ldr	x24, [x21, #-0x1]!
101412de4: f94006b7    	ldr	x23, [x21, #0x8]
101412de8: f94002e8    	ldr	x8, [x23]
101412dec: b4000068    	cbz	x8, 0x101412df8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3190>
101412df0: aa1803e0    	mov	x0, x24
101412df4: d63f0100    	blr	x8
101412df8: f94006e1    	ldr	x1, [x23, #0x8]
101412dfc: b4000081    	cbz	x1, 0x101412e0c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x31a4>
101412e00: f9400ae2    	ldr	x2, [x23, #0x10]
101412e04: aa1803e0    	mov	x0, x24
101412e08: 97da2e35    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412e0c: aa1503e0    	mov	x0, x21
101412e10: 52800301    	mov	w1, #0x18               ; =24
101412e14: 52800102    	mov	w2, #0x8                ; =8
101412e18: 97da2e31    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101412e1c: 17fff8d3    	b	0x101411168 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1500>
101412e20: aa1703f6    	mov	x22, x23
101412e24: 5280001a    	mov	w26, #0x0               ; =0
101412e28: 52800017    	mov	w23, #0x0               ; =0
101412e2c: a950a3ea    	ldp	x10, x8, [sp, #0x108]
101412e30: 52800109    	mov	w9, #0x8                ; =8
101412e34: f9092bff    	str	xzr, [sp, #0x1250]
101412e38: f9092fe9    	str	x9, [sp, #0x1258]
101412e3c: f90933ff    	str	xzr, [sp, #0x1260]
101412e40: f904f3ff    	str	xzr, [sp, #0x9e0]
101412e44: f904f7e8    	str	x8, [sp, #0x9e8]
101412e48: 912783f8    	add	x24, sp, #0x9e0
101412e4c: f9005fea    	str	x10, [sp, #0xb8]
101412e50: f904fbea    	str	x10, [sp, #0x9f0]
101412e54: f904ffe8    	str	x8, [sp, #0x9f8]
101412e58: f90503ff    	str	xzr, [sp, #0xa00]
101412e5c: f90507e8    	str	x8, [sp, #0xa08]
101412e60: 0f000540    	movi.2s	v0, #0xa
101412e64: fd050be0    	str	d0, [sp, #0xa10]
101412e68: 52800039    	mov	w25, #0x1               ; =1
101412e6c: 392863f9    	strb	w25, [sp, #0xa18]
101412e70: 791443ff    	strh	wzr, [sp, #0xa20]
101412e74: 14000003    	b	0x101412e80 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3218>
101412e78: 396887e8    	ldrb	w8, [sp, #0xa21]
101412e7c: 370015c8    	tbnz	w8, #0x0, 0x101413134 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x34cc>
101412e80: f944fbf3    	ldr	x19, [sp, #0x9f0]
101412e84: 910403e0    	add	x0, sp, #0x100
101412e88: 91004301    	add	x1, x24, #0x10
101412e8c: 94016814    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101412e90: b94103e8    	ldr	w8, [sp, #0x100]
101412e94: 7100051f    	cmp	w8, #0x1
101412e98: 540000e1    	b.ne	0x101412eb4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x324c>
101412e9c: f9408be8    	ldr	x8, [sp, #0x110]
101412ea0: f944f3e9    	ldr	x9, [sp, #0x9e0]
101412ea4: cb09011b    	sub	x27, x8, x9
101412ea8: 8b090273    	add	x19, x19, x9
101412eac: f904f3e8    	str	x8, [sp, #0x9e0]
101412eb0: 1400000d    	b	0x101412ee4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x327c>
101412eb4: 396887e8    	ldrb	w8, [sp, #0xa21]
101412eb8: 370013e8    	tbnz	w8, #0x0, 0x101413134 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x34cc>
101412ebc: 392887f9    	strb	w25, [sp, #0xa21]
101412ec0: 396883ea    	ldrb	w10, [sp, #0xa20]
101412ec4: f944f3e8    	ldr	x8, [sp, #0x9e0]
101412ec8: f944f7e9    	ldr	x9, [sp, #0x9e8]
101412ecc: 3700006a    	tbnz	w10, #0x0, 0x101412ed8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3270>
101412ed0: eb08013f    	cmp	x9, x8
101412ed4: 54001300    	b.eq	0x101413134 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x34cc>
101412ed8: f944fbea    	ldr	x10, [sp, #0x9f0]
101412edc: cb08013b    	sub	x27, x9, x8
101412ee0: 8b080153    	add	x19, x10, x8
101412ee4: b400021b    	cbz	x27, 0x101412f24 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x32bc>
101412ee8: d1000768    	sub	x8, x27, #0x1
101412eec: 38686a69    	ldrb	w9, [x19, x8]
101412ef0: 7100293f    	cmp	w9, #0xa
101412ef4: 54000181    	b.ne	0x101412f24 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x32bc>
101412ef8: d1000b69    	sub	x9, x27, #0x2
101412efc: b40000c8    	cbz	x8, 0x101412f14 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x32ac>
101412f00: 38696a6a    	ldrb	w10, [x19, x9]
101412f04: 12001d4a    	and	w10, w10, #0xff
101412f08: 7100355f    	cmp	w10, #0xd
101412f0c: 9a9f026a    	csel	x10, x19, xzr, eq
101412f10: 14000002    	b	0x101412f18 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x32b0>
101412f14: d280000a    	mov	x10, #0x0               ; =0
101412f18: f100015f    	cmp	x10, #0x0
101412f1c: 9a89011b    	csel	x27, x8, x9, eq
101412f20: 9a8a0273    	csel	x19, x19, x10, eq
101412f24: aa1303e0    	mov	x0, x19
101412f28: aa1b03e1    	mov	x1, x27
101412f2c: 97d4e68e    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
101412f30: b4fffa41    	cbz	x1, 0x101412e78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3210>
101412f34: 39400008    	ldrb	w8, [x0]
101412f38: 71008d1f    	cmp	w8, #0x23
101412f3c: 54fff9e0    	b.eq	0x101412e78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3210>
101412f40: d280000a    	mov	x10, #0x0               ; =0
101412f44: 8b1b0268    	add	x8, x19, x27
101412f48: cb080368    	sub	x8, x27, x8
101412f4c: 14000007    	b	0x101412f68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3300>
101412f50: 9100096a    	add	x10, x11, #0x2
101412f54: 331a112d    	bfi	w13, w9, #6, #5
101412f58: aa0d03e9    	mov	x9, x13
101412f5c: 8b0a010a    	add	x10, x8, x10
101412f60: 7100813f    	cmp	w9, #0x20
101412f64: 540003a1    	b.ne	0x101412fd8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3370>
101412f68: eb1b015f    	cmp	x10, x27
101412f6c: 54000340    	b.eq	0x101412fd4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x336c>
101412f70: aa0a03f4    	mov	x20, x10
101412f74: 8b0a026b    	add	x11, x19, x10
101412f78: aa0b03ea    	mov	x10, x11
101412f7c: 38c0154c    	ldrsb	w12, [x10], #0x1
101412f80: 12001d89    	and	w9, w12, #0xff
101412f84: 36fffecc    	tbz	w12, #0x1f, 0x101412f5c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x32f4>
101412f88: 3940056a    	ldrb	w10, [x11, #0x1]
101412f8c: 1200154d    	and	w13, w10, #0x3f
101412f90: 7103813f    	cmp	w9, #0xe0
101412f94: 54fffde3    	b.lo	0x101412f50 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x32e8>
101412f98: 1200112c    	and	w12, w9, #0x1f
101412f9c: 3940096a    	ldrb	w10, [x11, #0x2]
101412fa0: 1200154a    	and	w10, w10, #0x3f
101412fa4: 2a0d194d    	orr	w13, w10, w13, lsl #6
101412fa8: 7103c13f    	cmp	w9, #0xf0
101412fac: 540000e3    	b.lo	0x101412fc8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3360>
101412fb0: 9100116a    	add	x10, x11, #0x4
101412fb4: 39400d69    	ldrb	w9, [x11, #0x3]
101412fb8: 12001529    	and	w9, w9, #0x3f
101412fbc: 2a0d1929    	orr	w9, w9, w13, lsl #6
101412fc0: 330e0989    	bfi	w9, w12, #18, #3
101412fc4: 17ffffe6    	b	0x101412f5c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x32f4>
101412fc8: 91000d6a    	add	x10, x11, #0x3
101412fcc: 2a0c31a9    	orr	w9, w13, w12, lsl #12
101412fd0: 17ffffe3    	b	0x101412f5c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x32f4>
101412fd4: aa1b03f4    	mov	x20, x27
101412fd8: 3600033a    	tbz	w26, #0x0, 0x10141303c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x33d4>
101412fdc: b4000ad4    	cbz	x20, 0x101413134 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x34cc>
101412fe0: 720002ff    	tst	w23, #0x1
101412fe4: 9a941388    	csel	x8, x28, x20, ne
101412fe8: eb08029f    	cmp	x20, x8
101412fec: 54000461    	b.ne	0x101413078 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3410>
101412ff0: 8b010008    	add	x8, x0, x1
101412ff4: 385ff108    	ldurb	w8, [x8, #-0x1]
101412ff8: 7100e91f    	cmp	w8, #0x3a
101412ffc: 54000581    	b.ne	0x1014130ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3444>
101413000: d1000421    	sub	x1, x1, #0x1
101413004: 97d4e658    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
101413008: b4000521    	cbz	x1, 0x1014130ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3444>
10141300c: aa0003f3    	mov	x19, x0
101413010: aa0103fa    	mov	x26, x1
101413014: aa0003e8    	mov	x8, x0
101413018: aa0103e9    	mov	x9, x1
10141301c: f1003c3f    	cmp	x1, #0xf
101413020: 540003a8    	b.hi	0x101413094 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x342c>
101413024: 3840150a    	ldrb	w10, [x8], #0x1
101413028: 7100815f    	cmp	w10, #0x20
10141302c: 54000400    	b.eq	0x1014130ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3444>
101413030: f1000529    	subs	x9, x9, #0x1
101413034: 54ffff81    	b.ne	0x101413024 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x33bc>
101413038: 14000023    	b	0x1014130c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x345c>
10141303c: 5280001a    	mov	w26, #0x0               ; =0
101413040: b5fff1d4    	cbnz	x20, 0x101412e78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3210>
101413044: f100243f    	cmp	x1, #0x9
101413048: 54fff183    	b.lo	0x101412e78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3210>
10141304c: f9400008    	ldr	x8, [x0]
101413050: 39402009    	ldrb	w9, [x0, #0x8]
101413054: d28cae6a    	mov	x10, #0x6573            ; =25971
101413058: f2aece4a    	movk	x10, #0x7672, lsl #16
10141305c: f2cc6d2a    	movk	x10, #0x6369, lsl #32
101413060: f2ee6caa    	movk	x10, #0x7365, lsl #48
101413064: eb0a011f    	cmp	x8, x10
101413068: 52800748    	mov	w8, #0x3a               ; =58
10141306c: 7a480120    	ccmp	w9, w8, #0x0, eq
101413070: 1a9f17fa    	cset	w26, eq
101413074: 17ffff81    	b	0x101412e78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3210>
101413078: 52800037    	mov	w23, #0x1               ; =1
10141307c: aa0803f4    	mov	x20, x8
101413080: 5280003a    	mov	w26, #0x1               ; =1
101413084: 396887e8    	ldrb	w8, [sp, #0xa21]
101413088: aa1403fc    	mov	x28, x20
10141308c: 3607efa8    	tbz	w8, #0x0, 0x101412e80 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3218>
101413090: 14000029    	b	0x101413134 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x34cc>
101413094: 52800400    	mov	w0, #0x20               ; =32
101413098: aa1303e1    	mov	x1, x19
10141309c: aa1a03e2    	mov	x2, x26
1014130a0: 941048a8    	bl	0x101825340 <__ZN4core5slice6memchr14memchr_aligned17hb4aaf9792c60d219E>
1014130a4: f100041f    	cmp	x0, #0x1
1014130a8: 540000e1    	b.ne	0x1014130c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x345c>
1014130ac: 52800037    	mov	w23, #0x1               ; =1
1014130b0: 5280003a    	mov	w26, #0x1               ; =1
1014130b4: 396887e8    	ldrb	w8, [sp, #0xa21]
1014130b8: aa1403fc    	mov	x28, x20
1014130bc: 3607ee28    	tbz	w8, #0x0, 0x101412e80 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3218>
1014130c0: 1400001d    	b	0x101413134 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x34cc>
1014130c4: 97da2d8b    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014130c8: aa1a03e0    	mov	x0, x26
1014130cc: 52800021    	mov	w1, #0x1                ; =1
1014130d0: 97da2d82    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014130d4: b401d420    	cbz	x0, 0x101416b58 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6ef0>
1014130d8: aa0003f7    	mov	x23, x0
1014130dc: aa1303e1    	mov	x1, x19
1014130e0: aa1a03e2    	mov	x2, x26
1014130e4: 941adad1    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014130e8: f94933f3    	ldr	x19, [sp, #0x1260]
1014130ec: f9492be8    	ldr	x8, [sp, #0x1250]
1014130f0: eb08027f    	cmp	x19, x8
1014130f4: 54000081    	b.ne	0x101413104 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x349c>
1014130f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014130fc: 91094000    	add	x0, x0, #0x250
101413100: 941abe9c    	bl	0x101ac2b70 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hb575521872840d8cE>
101413104: f9492fe8    	ldr	x8, [sp, #0x1258]
101413108: 52800309    	mov	w9, #0x18               ; =24
10141310c: 9b092268    	madd	x8, x19, x9, x8
101413110: a9005d1a    	stp	x26, x23, [x8]
101413114: f900091a    	str	x26, [x8, #0x10]
101413118: 91000668    	add	x8, x19, #0x1
10141311c: f90933e8    	str	x8, [sp, #0x1260]
101413120: 52800037    	mov	w23, #0x1               ; =1
101413124: 5280003a    	mov	w26, #0x1               ; =1
101413128: 396887e8    	ldrb	w8, [sp, #0xa21]
10141312c: aa1403fc    	mov	x28, x20
101413130: 3607ea88    	tbz	w8, #0x0, 0x101412e80 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3218>
101413134: f9492be8    	ldr	x8, [sp, #0x1250]
101413138: f9492fe9    	ldr	x9, [sp, #0x1258]
10141313c: f94933ea    	ldr	x10, [sp, #0x1260]
101413140: 5280030b    	mov	w11, #0x18              ; =24
101413144: 9b0b254a    	madd	x10, x10, x11, x9
101413148: f904bbe9    	str	x9, [sp, #0x970]
10141314c: f904bfe9    	str	x9, [sp, #0x978]
101413150: f904c3e8    	str	x8, [sp, #0x980]
101413154: f904c7ea    	str	x10, [sp, #0x988]
101413158: f9401fe8    	ldr	x8, [sp, #0x38]
10141315c: f904cbe8    	str	x8, [sp, #0x990]
101413160: 910403e0    	add	x0, sp, #0x100
101413164: 9125c3e1    	add	x1, sp, #0x970
101413168: 97ffad8d    	bl	0x1013fe79c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xa74>
10141316c: f94083e8    	ldr	x8, [sp, #0x100]
101413170: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101413174: eb09011f    	cmp	x8, x9
101413178: 540002c1    	b.ne	0x1014131d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3568>
10141317c: f944bfe8    	ldr	x8, [sp, #0x978]
101413180: f944c7e9    	ldr	x9, [sp, #0x988]
101413184: eb080129    	subs	x9, x9, x8
101413188: 540009e0    	b.eq	0x1014132c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x365c>
10141318c: b201f3ea    	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
101413190: f295556a    	movk	x10, #0xaaab
101413194: 9bca7d29    	umulh	x9, x9, x10
101413198: d344fd33    	lsr	x19, x9, #4
10141319c: 91002114    	add	x20, x8, #0x8
1014131a0: 14000004    	b	0x1014131b0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3548>
1014131a4: 91006294    	add	x20, x20, #0x18
1014131a8: f1000673    	subs	x19, x19, #0x1
1014131ac: 540008c0    	b.eq	0x1014132c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x365c>
1014131b0: f85f8281    	ldur	x1, [x20, #-0x8]
1014131b4: b4ffff81    	cbz	x1, 0x1014131a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x353c>
1014131b8: f9400280    	ldr	x0, [x20]
1014131bc: 52800022    	mov	w2, #0x1                ; =1
1014131c0: 97da2d47    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014131c4: 17fffff8    	b	0x1014131a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x353c>
1014131c8: aa1703f6    	mov	x22, x23
1014131cc: 17fff7e8    	b	0x10141116c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1504>
1014131d0: 97da2d48    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014131d4: 52803400    	mov	w0, #0x1a0              ; =416
1014131d8: 52800101    	mov	w1, #0x8                ; =8
1014131dc: 97da2d3f    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014131e0: b401cac0    	cbz	x0, 0x101416b38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6ed0>
1014131e4: aa0003f4    	mov	x20, x0
1014131e8: ad4a07e0    	ldp	q0, q1, [sp, #0x140]
1014131ec: ad020400    	stp	q0, q1, [x0, #0x40]
1014131f0: f940b3e8    	ldr	x8, [sp, #0x160]
1014131f4: f9003008    	str	x8, [x0, #0x60]
1014131f8: ad4807e0    	ldp	q0, q1, [sp, #0x100]
1014131fc: ad000400    	stp	q0, q1, [x0]
101413200: ad4903e1    	ldp	q1, q0, [sp, #0x120]
101413204: ad010001    	stp	q1, q0, [x0, #0x20]
101413208: 52800088    	mov	w8, #0x4                ; =4
10141320c: a90c03e8    	stp	x8, x0, [sp, #0xc0]
101413210: 52800033    	mov	w19, #0x1               ; =1
101413214: f9006bf3    	str	x19, [sp, #0xd0]
101413218: 3dc25fe0    	ldr	q0, [sp, #0x970]
10141321c: 3dc263e1    	ldr	q1, [sp, #0x980]
101413220: f944cbe8    	ldr	x8, [sp, #0x990]
101413224: f9093be8    	str	x8, [sp, #0x1270]
101413228: 52800d17    	mov	w23, #0x68              ; =104
10141322c: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
101413230: 3d8497e0    	str	q0, [sp, #0x1250]
101413234: 3d849be1    	str	q1, [sp, #0x1260]
101413238: 14000012    	b	0x101413280 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3618>
10141323c: f94067f4    	ldr	x20, [sp, #0xc8]
101413240: 8b170288    	add	x8, x20, x23
101413244: 3dc27be0    	ldr	q0, [sp, #0x9e0]
101413248: 3dc27fe1    	ldr	q1, [sp, #0x9f0]
10141324c: 3dc283e2    	ldr	q2, [sp, #0xa00]
101413250: ad008901    	stp	q1, q2, [x8, #0x10]
101413254: 3d800100    	str	q0, [x8]
101413258: 3dc287e0    	ldr	q0, [sp, #0xa10]
10141325c: 3dc28be1    	ldr	q1, [sp, #0xa20]
101413260: 3dc28fe2    	ldr	q2, [sp, #0xa30]
101413264: f94523e9    	ldr	x9, [sp, #0xa40]
101413268: f9003109    	str	x9, [x8, #0x60]
10141326c: ad020901    	stp	q1, q2, [x8, #0x40]
101413270: 3d800d00    	str	q0, [x8, #0x30]
101413274: 91000673    	add	x19, x19, #0x1
101413278: f9006bf3    	str	x19, [sp, #0xd0]
10141327c: 9101a2f7    	add	x23, x23, #0x68
101413280: 912783e0    	add	x0, sp, #0x9e0
101413284: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
101413288: 91094021    	add	x1, x1, #0x250
10141328c: 97ffad44    	bl	0x1013fe79c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xa74>
101413290: f944f3e8    	ldr	x8, [sp, #0x9e0]
101413294: eb18011f    	cmp	x8, x24
101413298: 540002c0    	b.eq	0x1014132f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3688>
10141329c: f94063e8    	ldr	x8, [sp, #0xc0]
1014132a0: eb08027f    	cmp	x19, x8
1014132a4: 54fffce1    	b.ne	0x101413240 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x35d8>
1014132a8: 910303e0    	add	x0, sp, #0xc0
1014132ac: aa1303e1    	mov	x1, x19
1014132b0: 52800022    	mov	w2, #0x1                ; =1
1014132b4: 52800103    	mov	w3, #0x8                ; =8
1014132b8: 52800d04    	mov	w4, #0x68               ; =104
1014132bc: 94185565    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1014132c0: 17ffffdf    	b	0x10141323c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x35d4>
1014132c4: f944c3e8    	ldr	x8, [sp, #0x980]
1014132c8: b4007208    	cbz	x8, 0x101414108 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44a0>
1014132cc: f944bbe0    	ldr	x0, [sp, #0x970]
1014132d0: 8b080508    	add	x8, x8, x8, lsl #1
1014132d4: d37df101    	lsl	x1, x8, #3
1014132d8: 52800114    	mov	w20, #0x8               ; =8
1014132dc: 52800102    	mov	w2, #0x8                ; =8
1014132e0: 97da2cff    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014132e4: d2800013    	mov	x19, #0x0               ; =0
1014132e8: d2800017    	mov	x23, #0x0               ; =0
1014132ec: 1400038a    	b	0x101414114 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44ac>
1014132f0: f9492fe8    	ldr	x8, [sp, #0x1258]
1014132f4: f94937e9    	ldr	x9, [sp, #0x1268]
1014132f8: eb080129    	subs	x9, x9, x8
1014132fc: 54000200    	b.eq	0x10141333c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x36d4>
101413300: b201f3ea    	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
101413304: f295556a    	movk	x10, #0xaaab
101413308: 9bca7d29    	umulh	x9, x9, x10
10141330c: d344fd37    	lsr	x23, x9, #4
101413310: 91002118    	add	x24, x8, #0x8
101413314: 14000004    	b	0x101413324 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x36bc>
101413318: 91006318    	add	x24, x24, #0x18
10141331c: f10006f7    	subs	x23, x23, #0x1
101413320: 540000e0    	b.eq	0x10141333c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x36d4>
101413324: f85f8301    	ldur	x1, [x24, #-0x8]
101413328: b4ffff81    	cbz	x1, 0x101413318 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x36b0>
10141332c: f9400300    	ldr	x0, [x24]
101413330: 52800022    	mov	w2, #0x1                ; =1
101413334: 97da2cea    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101413338: 17fffff8    	b	0x101413318 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x36b0>
10141333c: f94933e8    	ldr	x8, [sp, #0x1260]
101413340: b40000c8    	cbz	x8, 0x101413358 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x36f0>
101413344: f9492be0    	ldr	x0, [sp, #0x1250]
101413348: 8b080508    	add	x8, x8, x8, lsl #1
10141334c: d37df101    	lsl	x1, x8, #3
101413350: 52800102    	mov	w2, #0x8                ; =8
101413354: 97da2ce2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101413358: f94063f7    	ldr	x23, [sp, #0xc0]
10141335c: 1400036e    	b	0x101414114 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44ac>
101413360: d2800018    	mov	x24, #0x0               ; =0
101413364: d280001b    	mov	x27, #0x0               ; =0
101413368: 17fffc7a    	b	0x101412550 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28e8>
10141336c: f94083f6    	ldr	x22, [sp, #0x100]
101413370: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101413374: eb0802df    	cmp	x22, x8
101413378: 54ff8e60    	b.eq	0x101412544 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28dc>
10141337c: 940ecc4c    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101413380: eb1a001f    	cmp	x0, x26
101413384: 54008261    	b.ne	0x1014143d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4768>
101413388: b940bbe8    	ldr	w8, [sp, #0xb8]
10141338c: 6b08003f    	cmp	w1, w8
101413390: 54008243    	b.lo	0x1014143d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4770>
101413394: 1400042d    	b	0x101414448 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x47e0>
101413398: f94083e1    	ldr	x1, [sp, #0x100]
10141339c: b4ff8d41    	cbz	x1, 0x101412544 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28dc>
1014133a0: aa1503e0    	mov	x0, x21
1014133a4: 1400042c    	b	0x101414454 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x47ec>
1014133a8: 528005e0    	mov	w0, #0x2f               ; =47
1014133ac: aa1303e1    	mov	x1, x19
1014133b0: aa1503e2    	mov	x2, x21
1014133b4: 941047e3    	bl	0x101825340 <__ZN4core5slice6memchr14memchr_aligned17hb4aaf9792c60d219E>
1014133b8: f100041f    	cmp	x0, #0x1
1014133bc: 540005e1    	b.ne	0x101413478 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3810>
1014133c0: 52800114    	mov	w20, #0x8               ; =8
1014133c4: aa1503e2    	mov	x2, x21
1014133c8: 14000003    	b	0x1014133d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x376c>
1014133cc: eb15005f    	cmp	x2, x21
1014133d0: 54001f08    	b.hi	0x1014137b0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b48>
1014133d4: 528005e0    	mov	w0, #0x2f               ; =47
1014133d8: aa1303e1    	mov	x1, x19
1014133dc: 94104810    	bl	0x10182541c <__ZN4core5slice6memchr7memrchr17h46fa36c0891baeaeE>
1014133e0: 36001e80    	tbz	w0, #0x0, 0x1014137b0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b48>
1014133e4: aa0103e2    	mov	x2, x1
1014133e8: eb15003f    	cmp	x1, x21
1014133ec: 54ffff02    	b.hs	0x1014133cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3764>
1014133f0: 38626a68    	ldrb	w8, [x19, x2]
1014133f4: 7100bd1f    	cmp	w8, #0x2f
1014133f8: 54fffea1    	b.ne	0x1014133cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3764>
1014133fc: f9001ff9    	str	x25, [sp, #0x38]
101413400: f90037f7    	str	x23, [sp, #0x68]
101413404: f9095ff3    	str	x19, [sp, #0x12b8]
101413408: f90963e2    	str	x2, [sp, #0x12c0]
10141340c: 91000454    	add	x20, x2, #0x1
101413410: eb1402a8    	subs	x8, x21, x20
101413414: f9005fe8    	str	x8, [sp, #0xb8]
101413418: 54000089    	b.ls	0x101413428 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x37c0>
10141341c: 38f46a68    	ldrsb	w8, [x19, x20]
101413420: 3101011f    	cmn	w8, #0x40
101413424: 5401ba2b    	b.lt	0x101416b68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6f00>
101413428: b400a442    	cbz	x2, 0x1014148b0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4c48>
10141342c: f9401fe8    	ldr	x8, [sp, #0x38]
101413430: a9452100    	ldp	x0, x8, [x8, #0x50]
101413434: f9401509    	ldr	x9, [x8, #0x28]
101413438: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10141343c: 910b2108    	add	x8, x8, #0x2c8
101413440: aa1303e1    	mov	x1, x19
101413444: d63f0120    	blr	x9
101413448: f9496ff5    	ldr	x21, [sp, #0x12d8]
10141344c: f9496be8    	ldr	x8, [sp, #0x12d0]
101413450: f9005be8    	str	x8, [sp, #0xb0]
101413454: b400d0f5    	cbz	x21, 0x101414e70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5208>
101413458: 940ecc15    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
10141345c: eb1b001f    	cmp	x0, x27
101413460: 5400cb81    	b.ne	0x101414dd0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5168>
101413464: f9401fe8    	ldr	x8, [sp, #0x38]
101413468: b9407908    	ldr	w8, [x8, #0x78]
10141346c: 6b08003f    	cmp	w1, w8
101413470: 5400cb43    	b.lo	0x101414dd8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5170>
101413474: 14000673    	b	0x101414e40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x51d8>
101413478: d10283a0    	sub	x0, x29, #0xa0
10141347c: 97fff24d    	bl	0x10140fdb0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x148>
101413480: b0007b40    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101413484: 9131a000    	add	x0, x0, #0xc68
101413488: f9400008    	ldr	x8, [x0]
10141348c: d63f0100    	blr	x8
101413490: aa0003f4    	mov	x20, x0
101413494: 39404008    	ldrb	w8, [x0, #0x10]
101413498: 7100051f    	cmp	w8, #0x1
10141349c: 5401a601    	b.ne	0x10141695c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6cf4>
1014134a0: a9400680    	ldp	x0, x1, [x20]
1014134a4: 91000408    	add	x8, x0, #0x1
1014134a8: f9000288    	str	x8, [x20]
1014134ac: b00072a8    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
1014134b0: 91166108    	add	x8, x8, #0x598
1014134b4: ad400500    	ldp	q0, q1, [x8]
1014134b8: ad0807e0    	stp	q0, q1, [sp, #0x100]
1014134bc: a91207e0    	stp	x0, x1, [sp, #0x120]
1014134c0: 52800108    	mov	w8, #0x8                ; =8
1014134c4: a90c23ff    	stp	xzr, x8, [sp, #0xc0]
1014134c8: f9006bff    	str	xzr, [sp, #0xd0]
1014134cc: a9452320    	ldp	x0, x8, [x25, #0x50]
1014134d0: f9401509    	ldr	x9, [x8, #0x28]
1014134d4: 912783e8    	add	x8, sp, #0x9e0
1014134d8: aa1303e1    	mov	x1, x19
1014134dc: aa1503e2    	mov	x2, x21
1014134e0: d63f0120    	blr	x9
1014134e4: f9005fff    	str	xzr, [sp, #0xb8]
1014134e8: f944f3ea    	ldr	x10, [sp, #0x9e0]
1014134ec: f944f7f3    	ldr	x19, [sp, #0x9e8]
1014134f0: f944fbe8    	ldr	x8, [sp, #0x9f0]
1014134f4: 8b080509    	add	x9, x8, x8, lsl #1
1014134f8: d37df134    	lsl	x20, x9, #3
1014134fc: 8b140269    	add	x9, x19, x20
101413500: f9092bf3    	str	x19, [sp, #0x1250]
101413504: a9072be9    	stp	x9, x10, [sp, #0x70]
101413508: f90933ea    	str	x10, [sp, #0x1260]
10141350c: f90937e9    	str	x9, [sp, #0x1268]
101413510: b9407b29    	ldr	w9, [x25, #0x78]
101413514: b900abe9    	str	w9, [sp, #0xa8]
101413518: a9762ba9    	ldp	x9, x10, [x29, #-0xa0]
10141351c: d2f0000b    	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
101413520: f90043e9    	str	x9, [sp, #0x80]
101413524: eb0b013f    	cmp	x9, x11
101413528: 9a8a03e9    	csel	x9, xzr, x10, eq
10141352c: 52800176    	mov	w22, #0xb               ; =11
101413530: cb0802c8    	sub	x8, x22, x8
101413534: a9052be8    	stp	x8, x10, [sp, #0x50]
101413538: f85703a8    	ldur	x8, [x29, #-0x90]
10141353c: a908a7e8    	stp	x8, x9, [sp, #0x88]
101413540: 91006278    	add	x24, x19, #0x18
101413544: 52800108    	mov	w8, #0x8                ; =8
101413548: a909a3fb    	stp	x27, x8, [sp, #0x98]
10141354c: f90033f3    	str	x19, [sp, #0x60]
101413550: aa1b03f5    	mov	x21, x27
101413554: 1400000d    	b	0x101413588 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3920>
101413558: b40000b7    	cbz	x23, 0x10141356c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3904>
10141355c: aa1903e0    	mov	x0, x25
101413560: aa1703e1    	mov	x1, x23
101413564: 52800022    	mov	w2, #0x1                ; =1
101413568: 97da2c5d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141356c: 91006273    	add	x19, x19, #0x18
101413570: 91006318    	add	x24, x24, #0x18
101413574: d1006294    	sub	x20, x20, #0x18
101413578: d10006d6    	sub	x22, x22, #0x1
10141357c: b10006df    	cmn	x22, #0x1
101413580: aa1c03f7    	mov	x23, x28
101413584: 54007d00    	b.eq	0x101414524 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x48bc>
101413588: b4007a94    	cbz	x20, 0x1014144d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4870>
10141358c: aa1703fc    	mov	x28, x23
101413590: f9400277    	ldr	x23, [x19]
101413594: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101413598: eb0802ff    	cmp	x23, x8
10141359c: 54007a80    	b.eq	0x1014144ec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4884>
1014135a0: a940ea79    	ldp	x25, x26, [x19, #0x8]
1014135a4: 940ecbc2    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
1014135a8: eb15001f    	cmp	x0, x21
1014135ac: 540000a1    	b.ne	0x1014135c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3958>
1014135b0: b940abe8    	ldr	w8, [sp, #0xa8]
1014135b4: 6b08003f    	cmp	w1, w8
1014135b8: 54000083    	b.lo	0x1014135c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3960>
1014135bc: 140003cf    	b	0x1014144f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4890>
1014135c0: eb15001f    	cmp	x0, x21
1014135c4: 540079aa    	b.ge	0x1014144f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4890>
1014135c8: aa1903e0    	mov	x0, x25
1014135cc: aa1a03e1    	mov	x1, x26
1014135d0: 940ec4c5    	bl	0x1017c48e4 <__ZN3std4path4Path9file_name17h5a3a680f74d1c784E>
1014135d4: b4fffc20    	cbz	x0, 0x101413558 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x38f0>
1014135d8: 912783e8    	add	x8, sp, #0x9e0
1014135dc: 941045b7    	bl	0x101824cb8 <__ZN4core3str8converts9from_utf817ha54c467cc832e2ffE>
1014135e0: b949e3e8    	ldr	w8, [sp, #0x9e0]
1014135e4: 3707fba8    	tbnz	w8, #0x0, 0x101413558 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x38f0>
1014135e8: f944f7e8    	ldr	x8, [sp, #0x9e8]
1014135ec: f9005be8    	str	x8, [sp, #0xb0]
1014135f0: f944fbfb    	ldr	x27, [sp, #0x9f0]
1014135f4: b400011b    	cbz	x27, 0x101413614 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x39ac>
1014135f8: 97da2c3e    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014135fc: aa1b03e0    	mov	x0, x27
101413600: 52800021    	mov	w1, #0x1                ; =1
101413604: 97da2c35    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101413608: aa0003f5    	mov	x21, x0
10141360c: b5000060    	cbnz	x0, 0x101413618 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x39b0>
101413610: 14000d40    	b	0x101416b10 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6ea8>
101413614: 52800035    	mov	w21, #0x1               ; =1
101413618: aa1503e0    	mov	x0, x21
10141361c: f9405be1    	ldr	x1, [sp, #0xb0]
101413620: aa1b03e2    	mov	x2, x27
101413624: 941ad981    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101413628: f904f3fb    	str	x27, [sp, #0x9e0]
10141362c: f904f7f5    	str	x21, [sp, #0x9e8]
101413630: f904fbfb    	str	x27, [sp, #0x9f0]
101413634: 910403e0    	add	x0, sp, #0x100
101413638: 912783e1    	add	x1, sp, #0x9e0
10141363c: 94018d44    	bl	0x101476b4c <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xee0>
101413640: f9404ff5    	ldr	x21, [sp, #0x98]
101413644: 3707f8a0    	tbnz	w0, #0x0, 0x101413558 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x38f0>
101413648: 912783e8    	add	x8, sp, #0x9e0
10141364c: aa1903e0    	mov	x0, x25
101413650: aa1a03e1    	mov	x1, x26
101413654: a9488be3    	ldp	x3, x2, [sp, #0x88]
101413658: 97fff184    	bl	0x10140fc68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E>
10141365c: 3dc27be0    	ldr	q0, [sp, #0x9e0]
101413660: 3d825fe0    	str	q0, [sp, #0x970]
101413664: f944fbe8    	ldr	x8, [sp, #0x9f0]
101413668: f904c3e8    	str	x8, [sp, #0x980]
10141366c: 912783e0    	add	x0, sp, #0x9e0
101413670: 9125c3e3    	add	x3, sp, #0x970
101413674: f9405be1    	ldr	x1, [sp, #0xb0]
101413678: aa1b03e2    	mov	x2, x27
10141367c: 52800084    	mov	w4, #0x4                ; =4
101413680: 94006c56    	bl	0x10142e7d8 <__ZN17otty_autocomplete3fix8distance19damerau_levenshtein17hab3f29809ff4c368E+0x7a4>
101413684: a94ba3e9    	ldp	x9, x8, [sp, #0xb8]
101413688: eb08013f    	cmp	x9, x8
10141368c: 540000a1    	b.ne	0x1014136a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3a38>
101413690: 910303e0    	add	x0, sp, #0xc0
101413694: 9419f214    	bl	0x101a8fee4 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h79ba5ff6649e4cf8E>
101413698: f94067e8    	ldr	x8, [sp, #0xc8]
10141369c: f90053e8    	str	x8, [sp, #0xa0]
1014136a0: f9405fea    	ldr	x10, [sp, #0xb8]
1014136a4: f94053e8    	ldr	x8, [sp, #0xa0]
1014136a8: 52800d09    	mov	w9, #0x68               ; =104
1014136ac: 9b092148    	madd	x8, x10, x9, x8
1014136b0: 3dc27be0    	ldr	q0, [sp, #0x9e0]
1014136b4: 3dc27fe1    	ldr	q1, [sp, #0x9f0]
1014136b8: 3dc283e2    	ldr	q2, [sp, #0xa00]
1014136bc: ad008901    	stp	q1, q2, [x8, #0x10]
1014136c0: 3d800100    	str	q0, [x8]
1014136c4: 3dc287e0    	ldr	q0, [sp, #0xa10]
1014136c8: 3dc28be1    	ldr	q1, [sp, #0xa20]
1014136cc: 3dc28fe2    	ldr	q2, [sp, #0xa30]
1014136d0: f94523e9    	ldr	x9, [sp, #0xa40]
1014136d4: f9003109    	str	x9, [x8, #0x60]
1014136d8: ad020901    	stp	q1, q2, [x8, #0x40]
1014136dc: 3d800d00    	str	q0, [x8, #0x30]
1014136e0: 9100054a    	add	x10, x10, #0x1
1014136e4: f9005fea    	str	x10, [sp, #0xb8]
1014136e8: f9006bea    	str	x10, [sp, #0xd0]
1014136ec: b5fff397    	cbnz	x23, 0x10141355c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x38f4>
1014136f0: 17ffff9f    	b	0x10141356c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3904>
1014136f4: 912783e0    	add	x0, sp, #0x9e0
1014136f8: 97ffee3f    	bl	0x10140eff4 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x21c>
1014136fc: f944f3e1    	ldr	x1, [sp, #0x9e0]
101413700: f944f7e9    	ldr	x9, [sp, #0x9e8]
101413704: f944fbe8    	ldr	x8, [sp, #0x9f0]
101413708: b4005fe8    	cbz	x8, 0x101414304 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x469c>
10141370c: f90007e1    	str	x1, [sp, #0x8]
101413710: 14000060    	b	0x101413890 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3c28>
101413714: f9401728    	ldr	x8, [x25, #0x28]
101413718: b4000a48    	cbz	x8, 0x101413860 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3bf8>
10141371c: 8b080508    	add	x8, x8, x8, lsl #1
101413720: f940132a    	ldr	x10, [x25, #0x20]
101413724: d37df108    	lsl	x8, x8, #3
101413728: d285a5a9    	mov	x9, #0x2d2d             ; =11565
10141372c: f2ae8e69    	movk	x9, #0x7473, lsl #16
101413730: f2ccec29    	movk	x9, #0x6761, lsl #32
101413734: f2ec8ca9    	movk	x9, #0x6465, lsl #48
101413738: 9100414a    	add	x10, x10, #0x10
10141373c: d285a5ab    	mov	x11, #0x2d2d            ; =11565
101413740: f2ac2c6b    	movk	x11, #0x6163, lsl #16
101413744: f2cd0c6b    	movk	x11, #0x6863, lsl #32
101413748: f2ec8cab    	movk	x11, #0x6465, lsl #48
10141374c: 14000004    	b	0x10141375c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3af4>
101413750: 9100614a    	add	x10, x10, #0x18
101413754: f1006108    	subs	x8, x8, #0x18
101413758: 54000840    	b.eq	0x101413860 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3bf8>
10141375c: f940014c    	ldr	x12, [x10]
101413760: f100219f    	cmp	x12, #0x8
101413764: 54ffff61    	b.ne	0x101413750 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3ae8>
101413768: f85f814c    	ldur	x12, [x10, #-0x8]
10141376c: f940018d    	ldr	x13, [x12]
101413770: eb0d013f    	cmp	x9, x13
101413774: 54000080    	b.eq	0x101413784 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3b1c>
101413778: f940018c    	ldr	x12, [x12]
10141377c: eb0b019f    	cmp	x12, x11
101413780: 54fffe81    	b.ne	0x101413750 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3ae8>
101413784: 97da2bdb    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101413788: 52800033    	mov	w19, #0x1               ; =1
10141378c: 52800020    	mov	w0, #0x1                ; =1
101413790: 52800021    	mov	w1, #0x1                ; =1
101413794: 97da2bd1    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101413798: b4011540    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
10141379c: aa0003e9    	mov	x9, x0
1014137a0: 528000c8    	mov	w8, #0x6                ; =6
1014137a4: 39000128    	strb	w8, [x9]
1014137a8: 52800028    	mov	w8, #0x1                ; =1
1014137ac: 14000037    	b	0x101413888 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3c20>
1014137b0: d2800008    	mov	x8, #0x0                ; =0
1014137b4: d2800013    	mov	x19, #0x0               ; =0
1014137b8: 17fffa87    	b	0x1014121d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x256c>
1014137bc: b9400109    	ldr	w9, [x8]
1014137c0: b8403108    	ldur	w8, [x8, #0x3]
1014137c4: 5285a5aa    	mov	w10, #0x2d2d            ; =11565
1014137c8: 72acac4a    	movk	w10, #0x6562, lsl #16
1014137cc: 6b0a013f    	cmp	w9, w10
1014137d0: 528dcca9    	mov	w9, #0x6e65             ; =28261
1014137d4: 72ad0c69    	movk	w9, #0x6863, lsl #16
1014137d8: 7a490100    	ccmp	w8, w9, #0x0, eq
1014137dc: 54006721    	b.ne	0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
1014137e0: 52800068    	mov	w8, #0x3                ; =3
1014137e4: 14000253    	b	0x101414130 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44c8>
1014137e8: f9400109    	ldr	x9, [x8]
1014137ec: 3940210a    	ldrb	w10, [x8, #0x8]
1014137f0: d285a5ab    	mov	x11, #0x2d2d            ; =11565
1014137f4: f2af0cab    	movk	x11, #0x7865, lsl #16
1014137f8: f2cdac2b    	movk	x11, #0x6d61, lsl #32
1014137fc: f2ed8e0b    	movk	x11, #0x6c70, lsl #48
101413800: eb0b013f    	cmp	x9, x11
101413804: 52800ca9    	mov	w9, #0x65               ; =101
101413808: 7a490140    	ccmp	w10, w9, #0x0, eq
10141380c: 540062a0    	b.eq	0x101414460 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x47f8>
101413810: f940010a    	ldr	x10, [x8]
101413814: 39402108    	ldrb	w8, [x8, #0x8]
101413818: d285a5ab    	mov	x11, #0x2d2d            ; =11565
10141381c: f2ac2e0b    	movk	x11, #0x6170, lsl #16
101413820: f2cd6c6b    	movk	x11, #0x6b63, lsl #32
101413824: f2ecec2b    	movk	x11, #0x6761, lsl #48
101413828: eb0b015f    	cmp	x10, x11
10141382c: 7a490100    	ccmp	w8, w9, #0x0, eq
101413830: 54006481    	b.ne	0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
101413834: 14000009    	b	0x101413858 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3bf0>
101413838: 79400109    	ldrh	w9, [x8]
10141383c: 5288c5aa    	mov	w10, #0x462d            ; =17965
101413840: 6b0a013f    	cmp	w9, w10
101413844: 54004740    	b.eq	0x10141412c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44c4>
101413848: 79400108    	ldrh	w8, [x8]
10141384c: 528e05a9    	mov	w9, #0x702d             ; =28717
101413850: 6b09011f    	cmp	w8, w9
101413854: 54006361    	b.ne	0x1014144c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4858>
101413858: 52800088    	mov	w8, #0x4                ; =4
10141385c: 14000235    	b	0x101414130 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44c8>
101413860: 97da2ba4    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101413864: 52800053    	mov	w19, #0x2               ; =2
101413868: 52800040    	mov	w0, #0x2                ; =2
10141386c: 52800021    	mov	w1, #0x1                ; =1
101413870: 97da2b9a    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101413874: b4010e60    	cbz	x0, 0x101415a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5dd8>
101413878: aa0003e9    	mov	x9, x0
10141387c: 528000e8    	mov	w8, #0x7                ; =7
101413880: 79000128    	strh	w8, [x9]
101413884: 52800048    	mov	w8, #0x2                ; =2
101413888: f904f3e8    	str	x8, [sp, #0x9e0]
10141388c: f90007e8    	str	x8, [sp, #0x8]
101413890: 8b080128    	add	x8, x9, x8
101413894: f90023e8    	str	x8, [sp, #0x40]
101413898: b9407b28    	ldr	w8, [x25, #0x78]
10141389c: b90023e8    	str	w8, [sp, #0x20]
1014138a0: a940232a    	ldp	x10, x8, [x25]
1014138a4: a904abe8    	stp	x8, x10, [sp, #0x48]
1014138a8: b0007b40    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
1014138ac: 9131a000    	add	x0, x0, #0xc68
1014138b0: f9400008    	ldr	x8, [x0]
1014138b4: d63f0100    	blr	x8
1014138b8: a90103f8    	stp	x24, x0, [sp, #0x10]
1014138bc: d280001a    	mov	x26, #0x0               ; =0
1014138c0: 52800d1b    	mov	w27, #0x68              ; =104
1014138c4: 52800108    	mov	w8, #0x8                ; =8
1014138c8: a9065fe8    	stp	x8, x23, [sp, #0x60]
1014138cc: f90003e9    	str	x9, [sp]
1014138d0: aa0903f3    	mov	x19, x9
1014138d4: f9001ff9    	str	x25, [sp, #0x38]
1014138d8: 14000006    	b	0x1014138f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3c88>
1014138dc: f9400bf8    	ldr	x24, [sp, #0x10]
1014138e0: f94023e8    	ldr	x8, [sp, #0x40]
1014138e4: f9403bf3    	ldr	x19, [sp, #0x70]
1014138e8: eb08027f    	cmp	x19, x8
1014138ec: 54003fa0    	b.eq	0x1014140e0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4478>
1014138f0: 38401675    	ldrb	w21, [x19], #0x1
1014138f4: 940ecaee    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
1014138f8: eb18001f    	cmp	x0, x24
1014138fc: 540000a1    	b.ne	0x101413910 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3ca8>
101413900: b94023e8    	ldr	w8, [sp, #0x20]
101413904: 6b08003f    	cmp	w1, w8
101413908: 54000083    	b.lo	0x101413918 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3cb0>
10141390c: 140001f5    	b	0x1014140e0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4478>
101413910: eb18001f    	cmp	x0, x24
101413914: 54003e6a    	b.ge	0x1014140e0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4478>
101413918: f00072a8    	adrp	x8, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
10141391c: 911f0108    	add	x8, x8, #0x7c0
101413920: f8757916    	ldr	x22, [x8, x21, lsl #3]
101413924: 90004688    	adrp	x8, 0x101ce3000 <__ZN17otty_autocomplete3fix5rules7MKDIR_P17h2b4d2f94c82eab42E+0x175e>
101413928: 91052108    	add	x8, x8, #0x148
10141392c: f8757901    	ldr	x1, [x8, x21, lsl #3]
101413930: f00072a8    	adrp	x8, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
101413934: 91200108    	add	x8, x8, #0x800
101413938: f8757900    	ldr	x0, [x8, x21, lsl #3]
10141393c: 912783e8    	add	x8, sp, #0x9e0
101413940: a9448be3    	ldp	x3, x2, [sp, #0x48]
101413944: 52800044    	mov	w4, #0x2                ; =2
101413948: 52800005    	mov	w5, #0x0                ; =0
10141394c: 9400cf4a    	bl	0x101447674 <__ZN17otty_autocomplete7process4exec17h82ed0cc7a8ed723eE>
101413950: f9003bf3    	str	x19, [sp, #0x70]
101413954: f944f3f3    	ldr	x19, [sp, #0x9e0]
101413958: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10141395c: eb08027f    	cmp	x19, x8
101413960: 540000c1    	b.ne	0x101413978 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3d10>
101413964: f904bbff    	str	xzr, [sp, #0x970]
101413968: 52800108    	mov	w8, #0x8                ; =8
10141396c: f904bfe8    	str	x8, [sp, #0x978]
101413970: f904c3ff    	str	xzr, [sp, #0x980]
101413974: 1400000c    	b	0x1014139a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3d3c>
101413978: f944f7f4    	ldr	x20, [sp, #0x9e8]
10141397c: f944fbe1    	ldr	x1, [sp, #0x9f0]
101413980: 9125c3e8    	add	x8, sp, #0x970
101413984: aa1403e0    	mov	x0, x20
101413988: aa1903e2    	mov	x2, x25
10141398c: d63f02c0    	blr	x22
101413990: b40000b3    	cbz	x19, 0x1014139a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3d3c>
101413994: aa1403e0    	mov	x0, x20
101413998: aa1303e1    	mov	x1, x19
10141399c: 52800022    	mov	w2, #0x1                ; =1
1014139a0: 97da2b4f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014139a4: 710006bf    	cmp	w21, #0x1
1014139a8: 54002aa1    	b.ne	0x101413efc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4294>
1014139ac: f94067e8    	ldr	x8, [sp, #0xc8]
1014139b0: f90033e8    	str	x8, [sp, #0x60]
1014139b4: f9400fe9    	ldr	x9, [sp, #0x18]
1014139b8: 39404128    	ldrb	w8, [x9, #0x10]
1014139bc: 7100051f    	cmp	w8, #0x1
1014139c0: 54003441    	b.ne	0x101414048 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x43e0>
1014139c4: a9400520    	ldp	x0, x1, [x9]
1014139c8: 91000408    	add	x8, x0, #0x1
1014139cc: f9000128    	str	x8, [x9]
1014139d0: b00072a8    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
1014139d4: 91166108    	add	x8, x8, #0x598
1014139d8: ad400500    	ldp	q0, q1, [x8]
1014139dc: 3d827be0    	str	q0, [sp, #0x9e0]
1014139e0: 3d827fe1    	str	q1, [sp, #0x9f0]
1014139e4: f90503e0    	str	x0, [sp, #0xa00]
1014139e8: f90507e1    	str	x1, [sp, #0xa08]
1014139ec: b500353a    	cbnz	x26, 0x101414090 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4428>
1014139f0: 3dc27be0    	ldr	q0, [sp, #0x9e0]
1014139f4: 3dc27fe1    	ldr	q1, [sp, #0x9f0]
1014139f8: ad0807e0    	stp	q0, q1, [sp, #0x100]
1014139fc: 3dc283e0    	ldr	q0, [sp, #0xa00]
101413a00: 3d804be0    	str	q0, [sp, #0x120]
101413a04: f944bbea    	ldr	x10, [sp, #0x970]
101413a08: f944bff8    	ldr	x24, [sp, #0x978]
101413a0c: f944c3e8    	ldr	x8, [sp, #0x980]
101413a10: 9b1b6116    	madd	x22, x8, x27, x24
101413a14: f9092bf8    	str	x24, [sp, #0x1250]
101413a18: f9092ff8    	str	x24, [sp, #0x1258]
101413a1c: f90933ea    	str	x10, [sp, #0x1260]
101413a20: f90937f6    	str	x22, [sp, #0x1268]
101413a24: 910403e9    	add	x9, sp, #0x100
101413a28: f9093be9    	str	x9, [sp, #0x1270]
101413a2c: b4002a88    	cbz	x8, 0x101413f7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4314>
101413a30: a902e3ea    	stp	x10, x24, [sp, #0x28]
101413a34: f90053f6    	str	x22, [sp, #0xa0]
101413a38: f9002ffa    	str	x26, [sp, #0x58]
101413a3c: f9408fe8    	ldr	x8, [sp, #0x118]
101413a40: b5000b88    	cbnz	x8, 0x101413bb0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3f48>
101413a44: 9101a318    	add	x24, x24, #0x68
101413a48: aa1803e8    	mov	x8, x24
101413a4c: a9f9d11a    	ldp	x26, x20, [x8, #-0x68]!
101413a50: a9410d1b    	ldp	x27, x3, [x8, #0x10]
101413a54: a9421904    	ldp	x4, x6, [x8, #0x20]
101413a58: a9430901    	ldp	x1, x2, [x8, #0x30]
101413a5c: a9440107    	ldp	x7, x0, [x8, #0x40]
101413a60: f940290a    	ldr	x10, [x8, #0x50]
101413a64: 3cc58100    	ldur	q0, [x8, #0x58]
101413a68: 3c9603a0    	stur	q0, [x29, #-0xa0]
101413a6c: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101413a70: eb09035f    	cmp	x26, x9
101413a74: 54001e61    	b.ne	0x101413e40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x41d8>
101413a78: 9101a318    	add	x24, x24, #0x68
101413a7c: 9101a108    	add	x8, x8, #0x68
101413a80: eb16011f    	cmp	x8, x22
101413a84: 54fffe21    	b.ne	0x101413a48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3de0>
101413a88: 14000138    	b	0x101413f68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4300>
101413a8c: 8a15011c    	and	x28, x8, x21
101413a90: fc7c6a69    	ldr	d9, [x19, x28]
101413a94: 2e288d20    	cmeq.8b	v0, v9, v8
101413a98: 9e660008    	fmov	x8, d0
101413a9c: f201c116    	ands	x22, x8, #0x8080808080808080
101413aa0: 540003a0    	b.eq	0x101413b14 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3eac>
101413aa4: a90913e2    	stp	x2, x4, [sp, #0x90]
101413aa8: a90a83e1    	stp	x1, x0, [sp, #0xa8]
101413aac: a9081be7    	stp	x7, x6, [sp, #0x80]
101413ab0: f9003fef    	str	x15, [sp, #0x78]
101413ab4: dac002c8    	rbit	x8, x22
101413ab8: dac01108    	clz	x8, x8
101413abc: 8b480f88    	add	x8, x28, x8, lsr #3
101413ac0: 8a150108    	and	x8, x8, x21
101413ac4: 52800309    	mov	w9, #0x18               ; =24
101413ac8: 9b09fd08    	mneg	x8, x8, x9
101413acc: 8b080268    	add	x8, x19, x8
101413ad0: f85f8109    	ldur	x9, [x8, #-0x8]
101413ad4: eb09037f    	cmp	x27, x9
101413ad8: 54000101    	b.ne	0x101413af8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3e90>
101413adc: f85f0101    	ldur	x1, [x8, #-0x10]
101413ae0: aa1403e0    	mov	x0, x20
101413ae4: aa1b03e2    	mov	x2, x27
101413ae8: aa0303f9    	mov	x25, x3
101413aec: 941ad84c    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101413af0: aa1903e3    	mov	x3, x25
101413af4: 34000220    	cbz	w0, 0x101413b38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3ed0>
101413af8: d10006c8    	sub	x8, x22, #0x1
101413afc: ea160116    	ands	x22, x8, x22
101413b00: a94a83e1    	ldp	x1, x0, [sp, #0xa8]
101413b04: a94913e2    	ldp	x2, x4, [sp, #0x90]
101413b08: a9481be7    	ldp	x7, x6, [sp, #0x80]
101413b0c: f9403fef    	ldr	x15, [sp, #0x78]
101413b10: 54fffd21    	b.ne	0x101413ab4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3e4c>
101413b14: 6f07e7e0    	movi.2d	v0, #0xffffffffffffffff
101413b18: 2e208d20    	cmeq.8b	v0, v9, v0
101413b1c: 2e30a800    	umaxv.8b	b0, v0
101413b20: 1e260008    	fmov	w8, s0
101413b24: f94053f6    	ldr	x22, [sp, #0xa0]
101413b28: 37000c28    	tbnz	w8, #0x0, 0x101413cac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4044>
101413b2c: 910021ef    	add	x15, x15, #0x8
101413b30: 8b0f0388    	add	x8, x28, x15
101413b34: 17ffffd6    	b	0x101413a8c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3e24>
101413b38: b40000da    	cbz	x26, 0x101413b50 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3ee8>
101413b3c: aa1403e0    	mov	x0, x20
101413b40: aa1a03e1    	mov	x1, x26
101413b44: 52800022    	mov	w2, #0x1                ; =1
101413b48: 97da2ae5    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101413b4c: aa1903e3    	mov	x3, x25
101413b50: f94053f6    	ldr	x22, [sp, #0xa0]
101413b54: b40000a3    	cbz	x3, 0x101413b68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3f00>
101413b58: f9404fe0    	ldr	x0, [sp, #0x98]
101413b5c: aa0303e1    	mov	x1, x3
101413b60: 52800022    	mov	w2, #0x1                ; =1
101413b64: 97da2ade    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101413b68: f94057e1    	ldr	x1, [sp, #0xa8]
101413b6c: f240f83f    	tst	x1, #0x7fffffffffffffff
101413b70: 540000a1    	b.ne	0x101413b84 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3f1c>
101413b74: f9405bf9    	ldr	x25, [sp, #0xb0]
101413b78: f240fb3f    	tst	x25, #0x7fffffffffffffff
101413b7c: 54000a20    	b.eq	0x101413cc0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4058>
101413b80: 14000007    	b	0x101413b9c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3f34>
101413b84: f9404be0    	ldr	x0, [sp, #0x90]
101413b88: 52800022    	mov	w2, #0x1                ; =1
101413b8c: 97da2ad4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101413b90: f9405bf9    	ldr	x25, [sp, #0xb0]
101413b94: f240fb3f    	tst	x25, #0x7fffffffffffffff
101413b98: 54000940    	b.eq	0x101413cc0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4058>
101413b9c: aa1903e1    	mov	x1, x25
101413ba0: f9405fe0    	ldr	x0, [sp, #0xb8]
101413ba4: 52800022    	mov	w2, #0x1                ; =1
101413ba8: 97da2acd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101413bac: 14000045    	b	0x101413cc0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4058>
101413bb0: aa1803f7    	mov	x23, x24
101413bb4: a940531a    	ldp	x26, x20, [x24]
101413bb8: a9410f1b    	ldp	x27, x3, [x24, #0x10]
101413bbc: a9421b04    	ldp	x4, x6, [x24, #0x20]
101413bc0: a9430b01    	ldp	x1, x2, [x24, #0x30]
101413bc4: a9440307    	ldp	x7, x0, [x24, #0x40]
101413bc8: f9402b08    	ldr	x8, [x24, #0x50]
101413bcc: f9005fe8    	str	x8, [sp, #0xb8]
101413bd0: 9101a318    	add	x24, x24, #0x68
101413bd4: f9408fe8    	ldr	x8, [sp, #0x118]
101413bd8: b40006a8    	cbz	x8, 0x101413cac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4044>
101413bdc: a9522fe9    	ldp	x9, x11, [sp, #0x120]
101413be0: d28caea8    	mov	x8, #0x6575             ; =25973
101413be4: f2ae0e68    	movk	x8, #0x7073, lsl #16
101413be8: f2cdaca8    	movk	x8, #0x6d65, lsl #32
101413bec: f2ee6de8    	movk	x8, #0x736f, lsl #48
101413bf0: ca08012a    	eor	x10, x9, x8
101413bf4: d28deda8    	mov	x8, #0x6f6d             ; =28525
101413bf8: f2adcc88    	movk	x8, #0x6e64, lsl #16
101413bfc: f2ce4c28    	movk	x8, #0x7261, lsl #32
101413c00: f2ec8de8    	movk	x8, #0x646f, lsl #48
101413c04: ca080168    	eor	x8, x11, x8
101413c08: d28e4c2c    	mov	x12, #0x7261            ; =29281
101413c0c: f2adccac    	movk	x12, #0x6e65, lsl #16
101413c10: f2ccecac    	movk	x12, #0x6765, lsl #32
101413c14: f2ed8f2c    	movk	x12, #0x6c79, lsl #48
101413c18: ca0c0129    	eor	x9, x9, x12
101413c1c: d28cae6c    	mov	x12, #0x6573            ; =25971
101413c20: f2af2e8c    	movk	x12, #0x7974, lsl #16
101413c24: f2cc8c4c    	movk	x12, #0x6462, lsl #32
101413c28: f2ee8cac    	movk	x12, #0x7465, lsl #48
101413c2c: ca0c016b    	eor	x11, x11, x12
101413c30: f27df36c    	ands	x12, x27, #0xfffffffffffffff8
101413c34: 540002a0    	b.eq	0x101413c88 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4020>
101413c38: d280000d    	mov	x13, #0x0               ; =0
101413c3c: f86d6a8e    	ldr	x14, [x20, x13]
101413c40: ca0b01cb    	eor	x11, x14, x11
101413c44: 8b08014a    	add	x10, x10, x8
101413c48: cac8cd48    	eor	x8, x10, x8, ror #51
101413c4c: 8b090169    	add	x9, x11, x9
101413c50: 8b08012f    	add	x15, x9, x8
101413c54: cacbc129    	eor	x9, x9, x11, ror #48
101413c58: 93ca814a    	ror	x10, x10, #0x20
101413c5c: cac8bde8    	eor	x8, x15, x8, ror #47
101413c60: 8b0a012b    	add	x11, x9, x10
101413c64: ca0e016a    	eor	x10, x11, x14
101413c68: cac9ad6b    	eor	x11, x11, x9, ror #43
101413c6c: 93cf81e9    	ror	x9, x15, #0x20
101413c70: 910021ad    	add	x13, x13, #0x8
101413c74: eb0c01bf    	cmp	x13, x12
101413c78: 54fffe23    	b.lo	0x101413c3c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3fd4>
101413c7c: d100058c    	sub	x12, x12, #0x1
101413c80: 927df18c    	and	x12, x12, #0xfffffffffffffff8
101413c84: 9100218c    	add	x12, x12, #0x8
101413c88: 92400b6d    	and	x13, x27, #0x7
101413c8c: f10011bf    	cmp	x13, #0x4
101413c90: 540001e3    	b.lo	0x101413ccc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4064>
101413c94: b86c6a8e    	ldr	w14, [x20, x12]
101413c98: 5280008f    	mov	w15, #0x4               ; =4
101413c9c: b24001f0    	orr	x16, x15, #0x1
101413ca0: eb0d021f    	cmp	x16, x13
101413ca4: 540001e3    	b.lo	0x101413ce0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4078>
101413ca8: 14000014    	b	0x101413cf8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4090>
101413cac: 3cc582e0    	ldur	q0, [x23, #0x58]
101413cb0: 3c9603a0    	stur	q0, [x29, #-0xa0]
101413cb4: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101413cb8: eb08035f    	cmp	x26, x8
101413cbc: 54000be1    	b.ne	0x101413e38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x41d0>
101413cc0: eb16031f    	cmp	x24, x22
101413cc4: 54fff761    	b.ne	0x101413bb0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3f48>
101413cc8: 140000a7    	b	0x101413f64 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x42fc>
101413ccc: d280000f    	mov	x15, #0x0               ; =0
101413cd0: d280000e    	mov	x14, #0x0               ; =0
101413cd4: b24001f0    	orr	x16, x15, #0x1
101413cd8: eb0d021f    	cmp	x16, x13
101413cdc: 540000e2    	b.hs	0x101413cf8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4090>
101413ce0: 8b0c0290    	add	x16, x20, x12
101413ce4: 786f6a10    	ldrh	w16, [x16, x15]
101413ce8: d37df1f1    	lsl	x17, x15, #3
101413cec: 9ad12210    	lsl	x16, x16, x17
101413cf0: aa0e020e    	orr	x14, x16, x14
101413cf4: b27f01ef    	orr	x15, x15, #0x2
101413cf8: eb0d01ff    	cmp	x15, x13
101413cfc: 54000102    	b.hs	0x101413d1c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x40b4>
101413d00: 8b0c01ec    	add	x12, x15, x12
101413d04: 386c6a8c    	ldrb	w12, [x20, x12]
101413d08: d37df1ef    	lsl	x15, x15, #3
101413d0c: 9acf218c    	lsl	x12, x12, x15
101413d10: aa0e018e    	orr	x14, x12, x14
101413d14: 9100076c    	add	x12, x27, #0x1
101413d18: 14000003    	b	0x101413d24 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x40bc>
101413d1c: 9100076c    	add	x12, x27, #0x1
101413d20: b40002ad    	cbz	x13, 0x101413d74 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x410c>
101413d24: d37df1af    	lsl	x15, x13, #3
101413d28: 52801ff0    	mov	w16, #0xff              ; =255
101413d2c: 9acf220f    	lsl	x15, x16, x15
101413d30: aa0f01ce    	orr	x14, x14, x15
101413d34: f1001dbf    	cmp	x13, #0x7
101413d38: 54000201    	b.ne	0x101413d78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4110>
101413d3c: ca0b01cb    	eor	x11, x14, x11
101413d40: 8b0a010a    	add	x10, x8, x10
101413d44: cac8cd48    	eor	x8, x10, x8, ror #51
101413d48: 8b090169    	add	x9, x11, x9
101413d4c: 8b08012d    	add	x13, x9, x8
101413d50: cacbc129    	eor	x9, x9, x11, ror #48
101413d54: 93ca814a    	ror	x10, x10, #0x20
101413d58: cac8bda8    	eor	x8, x13, x8, ror #47
101413d5c: 8b0a012b    	add	x11, x9, x10
101413d60: ca0e016a    	eor	x10, x11, x14
101413d64: cac9ad6b    	eor	x11, x11, x9, ror #43
101413d68: 93cd81a9    	ror	x9, x13, #0x20
101413d6c: d280000e    	mov	x14, #0x0               ; =0
101413d70: 14000002    	b	0x101413d78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4110>
101413d74: 52801fee    	mov	w14, #0xff              ; =255
101413d78: d280000f    	mov	x15, #0x0               ; =0
101413d7c: aa0ce1cc    	orr	x12, x14, x12, lsl #56
101413d80: ca0b018b    	eor	x11, x12, x11
101413d84: 8b0a010a    	add	x10, x8, x10
101413d88: cac8cd48    	eor	x8, x10, x8, ror #51
101413d8c: 8b090169    	add	x9, x11, x9
101413d90: 8b08012d    	add	x13, x9, x8
101413d94: cacbc129    	eor	x9, x9, x11, ror #48
101413d98: 93ca814a    	ror	x10, x10, #0x20
101413d9c: cac8bda8    	eor	x8, x13, x8, ror #47
101413da0: 8b0a012a    	add	x10, x9, x10
101413da4: ca0c014b    	eor	x11, x10, x12
101413da8: cac9ad49    	eor	x9, x10, x9, ror #43
101413dac: 93cd81aa    	ror	x10, x13, #0x20
101413db0: d2401d4a    	eor	x10, x10, #0xff
101413db4: 8b08016b    	add	x11, x11, x8
101413db8: cac8cd68    	eor	x8, x11, x8, ror #51
101413dbc: 8b0a012a    	add	x10, x9, x10
101413dc0: 8b0a010c    	add	x12, x8, x10
101413dc4: cac9c149    	eor	x9, x10, x9, ror #48
101413dc8: 93cb816a    	ror	x10, x11, #0x20
101413dcc: cac8bd88    	eor	x8, x12, x8, ror #47
101413dd0: 8b0a012a    	add	x10, x9, x10
101413dd4: 8b0a010b    	add	x11, x8, x10
101413dd8: cac9ad49    	eor	x9, x10, x9, ror #43
101413ddc: 93cc818a    	ror	x10, x12, #0x20
101413de0: cac8cd68    	eor	x8, x11, x8, ror #51
101413de4: 8b0a012a    	add	x10, x9, x10
101413de8: 8b0a010c    	add	x12, x8, x10
101413dec: cac9c149    	eor	x9, x10, x9, ror #48
101413df0: 93cb816a    	ror	x10, x11, #0x20
101413df4: cac8bd88    	eor	x8, x12, x8, ror #47
101413df8: 8b0a012a    	add	x10, x9, x10
101413dfc: 8b0a010b    	add	x11, x8, x10
101413e00: cac9ad49    	eor	x9, x10, x9, ror #43
101413e04: 93cc818a    	ror	x10, x12, #0x20
101413e08: cac8cd68    	eor	x8, x11, x8, ror #51
101413e0c: 8b0a012a    	add	x10, x9, x10
101413e10: 8b0a010b    	add	x11, x8, x10
101413e14: cac9c149    	eor	x9, x10, x9, ror #48
101413e18: 93c9ad29    	ror	x9, x9, #0x2b
101413e1c: cac8bd28    	eor	x8, x9, x8, ror #47
101413e20: cacb8108    	eor	x8, x8, x11, ror #32
101413e24: ca0b0108    	eor	x8, x8, x11
101413e28: d379fd09    	lsr	x9, x8, #57
101413e2c: a95057f3    	ldp	x19, x21, [sp, #0x100]
101413e30: 0e010d28    	dup.8b	v8, w9
101413e34: 17ffff16    	b	0x101413a8c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3e24>
101413e38: f94037f7    	ldr	x23, [sp, #0x68]
101413e3c: f9405fea    	ldr	x10, [sp, #0xb8]
101413e40: 3cd603a0    	ldur	q0, [x29, #-0xa0]
101413e44: 912783e8    	add	x8, sp, #0x9e0
101413e48: 3c858100    	stur	q0, [x8, #0x58]
101413e4c: f904f3fa    	str	x26, [sp, #0x9e0]
101413e50: f904f7f4    	str	x20, [sp, #0x9e8]
101413e54: f904fbfb    	str	x27, [sp, #0x9f0]
101413e58: f904ffe3    	str	x3, [sp, #0x9f8]
101413e5c: f90503e4    	str	x4, [sp, #0xa00]
101413e60: f90507e6    	str	x6, [sp, #0xa08]
101413e64: f9050be1    	str	x1, [sp, #0xa10]
101413e68: f9050fe2    	str	x2, [sp, #0xa18]
101413e6c: f90513e7    	str	x7, [sp, #0xa20]
101413e70: f90517e0    	str	x0, [sp, #0xa28]
101413e74: f9051bea    	str	x10, [sp, #0xa30]
101413e78: f94063e8    	ldr	x8, [sp, #0xc0]
101413e7c: f9402ffa    	ldr	x26, [sp, #0x58]
101413e80: eb08035f    	cmp	x26, x8
101413e84: f9401ff9    	ldr	x25, [sp, #0x38]
101413e88: 52800d1b    	mov	w27, #0x68              ; =104
101413e8c: 54000121    	b.ne	0x101413eb0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4248>
101413e90: 910303e0    	add	x0, sp, #0xc0
101413e94: aa1a03e1    	mov	x1, x26
101413e98: 52800022    	mov	w2, #0x1                ; =1
101413e9c: 52800103    	mov	w3, #0x8                ; =8
101413ea0: 52800d04    	mov	w4, #0x68               ; =104
101413ea4: 9418526b    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101413ea8: f94067e8    	ldr	x8, [sp, #0xc8]
101413eac: f90033e8    	str	x8, [sp, #0x60]
101413eb0: f94033e8    	ldr	x8, [sp, #0x60]
101413eb4: 9b1b2348    	madd	x8, x26, x27, x8
101413eb8: 3dc27be0    	ldr	q0, [sp, #0x9e0]
101413ebc: 3dc27fe1    	ldr	q1, [sp, #0x9f0]
101413ec0: 3dc283e2    	ldr	q2, [sp, #0xa00]
101413ec4: ad008901    	stp	q1, q2, [x8, #0x10]
101413ec8: 3d800100    	str	q0, [x8]
101413ecc: 3dc287e0    	ldr	q0, [sp, #0xa10]
101413ed0: 3dc28be1    	ldr	q1, [sp, #0xa20]
101413ed4: 3dc28fe2    	ldr	q2, [sp, #0xa30]
101413ed8: f94523e9    	ldr	x9, [sp, #0xa40]
101413edc: f9003109    	str	x9, [x8, #0x60]
101413ee0: ad020901    	stp	q1, q2, [x8, #0x40]
101413ee4: 3d800d00    	str	q0, [x8, #0x30]
101413ee8: 9100075a    	add	x26, x26, #0x1
101413eec: f9006bfa    	str	x26, [sp, #0xd0]
101413ef0: eb16031f    	cmp	x24, x22
101413ef4: 54ffda21    	b.ne	0x101413a38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3dd0>
101413ef8: 1400001f    	b	0x101413f74 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x430c>
101413efc: f944bbf6    	ldr	x22, [sp, #0x970]
101413f00: f944bff3    	ldr	x19, [sp, #0x978]
101413f04: f944c3f4    	ldr	x20, [sp, #0x980]
101413f08: 9b1b7e95    	mul	x21, x20, x27
101413f0c: 8b150268    	add	x8, x19, x21
101413f10: f904f3f3    	str	x19, [sp, #0x9e0]
101413f14: f904f7f3    	str	x19, [sp, #0x9e8]
101413f18: f904fbf6    	str	x22, [sp, #0x9f0]
101413f1c: f904ffe8    	str	x8, [sp, #0x9f8]
101413f20: f94063e8    	ldr	x8, [sp, #0xc0]
101413f24: cb1a0108    	sub	x8, x8, x26
101413f28: eb08029f    	cmp	x20, x8
101413f2c: 540009c8    	b.hi	0x101414064 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x43fc>
101413f30: f94033e8    	ldr	x8, [sp, #0x60]
101413f34: 9b1b2340    	madd	x0, x26, x27, x8
101413f38: aa1303e1    	mov	x1, x19
101413f3c: aa1503e2    	mov	x2, x21
101413f40: 941ad73a    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101413f44: 8b14035a    	add	x26, x26, x20
101413f48: f9006bfa    	str	x26, [sp, #0xd0]
101413f4c: b4ffccb6    	cbz	x22, 0x1014138e0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3c78>
101413f50: 9b1b7ec1    	mul	x1, x22, x27
101413f54: aa1303e0    	mov	x0, x19
101413f58: 52800102    	mov	w2, #0x8                ; =8
101413f5c: 97da29e0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101413f60: 17fffe60    	b	0x1014138e0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3c78>
101413f64: f94037f7    	ldr	x23, [sp, #0x68]
101413f68: f9401ff9    	ldr	x25, [sp, #0x38]
101413f6c: f9402ffa    	ldr	x26, [sp, #0x58]
101413f70: 52800d1b    	mov	w27, #0x68              ; =104
101413f74: f9092ff6    	str	x22, [sp, #0x1258]
101413f78: a942e3ea    	ldp	x10, x24, [sp, #0x28]
101413f7c: b40000aa    	cbz	x10, 0x101413f90 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4328>
101413f80: 9b1b7d41    	mul	x1, x10, x27
101413f84: aa1803e0    	mov	x0, x24
101413f88: 52800102    	mov	w2, #0x8                ; =8
101413f8c: 97da29d4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101413f90: f94087f3    	ldr	x19, [sp, #0x108]
101413f94: b4ffca53    	cbz	x19, 0x1014138dc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3c74>
101413f98: aa1703f8    	mov	x24, x23
101413f9c: f9408ff4    	ldr	x20, [sp, #0x118]
101413fa0: b40003d4    	cbz	x20, 0x101414018 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x43b0>
101413fa4: f94083f5    	ldr	x21, [sp, #0x100]
101413fa8: aa1503f6    	mov	x22, x21
101413fac: fc4086c0    	ldr	d0, [x22], #0x8
101413fb0: 2e208800    	cmge.8b	v0, v0, #0
101413fb4: 9e660008    	fmov	x8, d0
101413fb8: 9201c117    	and	x23, x8, #0x8080808080808080
101413fbc: 14000005    	b	0x101413fd0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4368>
101413fc0: d10006e8    	sub	x8, x23, #0x1
101413fc4: 8a170117    	and	x23, x8, x23
101413fc8: d1000694    	sub	x20, x20, #0x1
101413fcc: b4000274    	cbz	x20, 0x101414018 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x43b0>
101413fd0: b50000f7    	cbnz	x23, 0x101413fec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4384>
101413fd4: fc4086c0    	ldr	d0, [x22], #0x8
101413fd8: 2e208800    	cmge.8b	v0, v0, #0
101413fdc: 9e660008    	fmov	x8, d0
101413fe0: d10302b5    	sub	x21, x21, #0xc0
101413fe4: 9201c117    	and	x23, x8, #0x8080808080808080
101413fe8: b4ffff77    	cbz	x23, 0x101413fd4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x436c>
101413fec: dac002e8    	rbit	x8, x23
101413ff0: dac01108    	clz	x8, x8
101413ff4: cb480fe8    	neg	x8, x8, lsr #3
101413ff8: 52800309    	mov	w9, #0x18               ; =24
101413ffc: 9b295508    	smaddl	x8, w8, w9, x21
101414000: f85e8101    	ldur	x1, [x8, #-0x18]
101414004: b4fffde1    	cbz	x1, 0x101413fc0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4358>
101414008: f85f0100    	ldur	x0, [x8, #-0x10]
10141400c: 52800022    	mov	w2, #0x1                ; =1
101414010: 97da29b3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414014: 17ffffeb    	b	0x101413fc0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4358>
101414018: 8b130668    	add	x8, x19, x19, lsl #1
10141401c: d37df108    	lsl	x8, x8, #3
101414020: 8b130109    	add	x9, x8, x19
101414024: b1008521    	adds	x1, x9, #0x21
101414028: aa1803f7    	mov	x23, x24
10141402c: 54ffc580    	b.eq	0x1014138dc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3c74>
101414030: f94083e9    	ldr	x9, [sp, #0x100]
101414034: cb080128    	sub	x8, x9, x8
101414038: d1006100    	sub	x0, x8, #0x18
10141403c: 52800102    	mov	w2, #0x8                ; =8
101414040: 97da29a7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414044: 17fffe26    	b	0x1014138dc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3c74>
101414048: 940eae50    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
10141404c: f9400fe9    	ldr	x9, [sp, #0x18]
101414050: f9000521    	str	x1, [x9, #0x8]
101414054: 52800028    	mov	w8, #0x1                ; =1
101414058: 39004128    	strb	w8, [x9, #0x10]
10141405c: 52800d1b    	mov	w27, #0x68              ; =104
101414060: 17fffe5a    	b	0x1014139c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3d60>
101414064: 910303e0    	add	x0, sp, #0xc0
101414068: aa1a03e1    	mov	x1, x26
10141406c: aa1403e2    	mov	x2, x20
101414070: 52800103    	mov	w3, #0x8                ; =8
101414074: 52800d04    	mov	w4, #0x68               ; =104
101414078: 941851f6    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10141407c: a94cebe8    	ldp	x8, x26, [sp, #0xc8]
101414080: f90033e8    	str	x8, [sp, #0x60]
101414084: f9400bf8    	ldr	x24, [sp, #0x10]
101414088: 52800d1b    	mov	w27, #0x68              ; =104
10141408c: 17ffffa9    	b	0x101413f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x42c8>
101414090: 912783e0    	add	x0, sp, #0x9e0
101414094: 912783e8    	add	x8, sp, #0x9e0
101414098: 91008102    	add	x2, x8, #0x20
10141409c: aa1a03f4    	mov	x20, x26
1014140a0: aa1a03e1    	mov	x1, x26
1014140a4: 52800023    	mov	w3, #0x1                ; =1
1014140a8: 941a8040    	bl	0x101ab41a8 <__ZN9hashbrown3raw21RawTable$LT$T$C$A$GT$14reserve_rehash17h8ad6e75f269338c4E>
1014140ac: f94033f3    	ldr	x19, [sp, #0x60]
1014140b0: aa1403fa    	mov	x26, x20
1014140b4: 52800d1b    	mov	w27, #0x68              ; =104
1014140b8: 910403e8    	add	x8, sp, #0x100
1014140bc: aa1303e0    	mov	x0, x19
1014140c0: 940fec43    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1014140c4: 912783e0    	add	x0, sp, #0x9e0
1014140c8: 910403e1    	add	x1, sp, #0x100
1014140cc: 94018aa0    	bl	0x101476b4c <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xee0>
1014140d0: 9101a273    	add	x19, x19, #0x68
1014140d4: f1000694    	subs	x20, x20, #0x1
1014140d8: 54ffff01    	b.ne	0x1014140b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4450>
1014140dc: 17fffe45    	b	0x1014139f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x3d88>
1014140e0: f94007e1    	ldr	x1, [sp, #0x8]
1014140e4: b40000a1    	cbz	x1, 0x1014140f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4490>
1014140e8: f94003e0    	ldr	x0, [sp]
1014140ec: 52800022    	mov	w2, #0x1                ; =1
1014140f0: 97da297b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014140f4: f9406bfa    	ldr	x26, [sp, #0xd0]
1014140f8: a94c27e8    	ldp	x8, x9, [sp, #0xc0]
1014140fc: a90026e8    	stp	x8, x9, [x23]
101414100: f9000afa    	str	x26, [x23, #0x10]
101414104: 140009f0    	b	0x1014168c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c5c>
101414108: d2800013    	mov	x19, #0x0               ; =0
10141410c: d2800017    	mov	x23, #0x0               ; =0
101414110: 52800114    	mov	w20, #0x8               ; =8
101414114: b4fe8315    	cbz	x21, 0x101411174 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x150c>
101414118: f9405fe0    	ldr	x0, [sp, #0xb8]
10141411c: aa1503e1    	mov	x1, x21
101414120: 52800022    	mov	w2, #0x1                ; =1
101414124: 97da296e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414128: 17fff413    	b	0x101411174 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x150c>
10141412c: 52800048    	mov	w8, #0x2                ; =2
101414130: b900b3e8    	str	w8, [sp, #0xb0]
101414134: f9001ff9    	str	x25, [sp, #0x38]
101414138: b9407b38    	ldr	w24, [x25, #0x78]
10141413c: 52800159    	mov	w25, #0xa               ; =10
101414140: f0004653    	adrp	x19, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101414144: 91214a73    	add	x19, x19, #0x852
101414148: b900bbf8    	str	w24, [sp, #0xb8]
10141414c: 14000003    	b	0x101414158 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44f0>
101414150: f1000739    	subs	x25, x25, #0x1
101414154: 540008c0    	b.eq	0x10141426c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4604>
101414158: 940ec8d5    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
10141415c: eb1a001f    	cmp	x0, x26
101414160: 54000081    	b.ne	0x101414170 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4508>
101414164: 6b18003f    	cmp	w1, w24
101414168: 54000063    	b.lo	0x101414174 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x450c>
10141416c: 14000040    	b	0x10141426c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4604>
101414170: 540007ea    	b.ge	0x10141426c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4604>
101414174: 910403e8    	add	x8, sp, #0x100
101414178: aa1603e0    	mov	x0, x22
10141417c: aa1703e1    	mov	x1, x23
101414180: aa1303e2    	mov	x2, x19
101414184: 52800143    	mov	w3, #0xa                ; =10
101414188: 940ec045    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
10141418c: a950d3f5    	ldp	x21, x20, [sp, #0x108]
101414190: 912783e8    	add	x8, sp, #0x9e0
101414194: aa1503e0    	mov	x0, x21
101414198: aa1403e1    	mov	x1, x20
10141419c: 940e9c58    	bl	0x1017bb2fc <__ZN3std3sys2fs8metadata17h317aa82d489c5e37E>
1014141a0: b949e3e8    	ldr	w8, [sp, #0x9e0]
1014141a4: 36000428    	tbz	w8, #0x0, 0x101414228 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x45c0>
1014141a8: f944f7f4    	ldr	x20, [sp, #0x9e8]
1014141ac: 92400688    	and	x8, x20, #0x3
1014141b0: f100051f    	cmp	x8, #0x1
1014141b4: 54000221    	b.ne	0x1014141f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4590>
1014141b8: f85ffe98    	ldr	x24, [x20, #-0x1]!
1014141bc: f940069b    	ldr	x27, [x20, #0x8]
1014141c0: f9400368    	ldr	x8, [x27]
1014141c4: b4000068    	cbz	x8, 0x1014141d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4568>
1014141c8: aa1803e0    	mov	x0, x24
1014141cc: d63f0100    	blr	x8
1014141d0: f9400761    	ldr	x1, [x27, #0x8]
1014141d4: b4000081    	cbz	x1, 0x1014141e4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x457c>
1014141d8: f9400b62    	ldr	x2, [x27, #0x10]
1014141dc: aa1803e0    	mov	x0, x24
1014141e0: 97da293f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014141e4: aa1403e0    	mov	x0, x20
1014141e8: 52800301    	mov	w1, #0x18               ; =24
1014141ec: 52800102    	mov	w2, #0x8                ; =8
1014141f0: 97da293b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014141f4: b940bbf8    	ldr	w24, [sp, #0xb8]
1014141f8: aa1603e0    	mov	x0, x22
1014141fc: aa1703e1    	mov	x1, x23
101414200: 940ec0fa    	bl	0x1017c45e8 <__ZN3std4path4Path6parent17h81615573672c555dE>
101414204: aa0003f6    	mov	x22, x0
101414208: b4000280    	cbz	x0, 0x101414258 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x45f0>
10141420c: aa0103f7    	mov	x23, x1
101414210: f94083e1    	ldr	x1, [sp, #0x100]
101414214: b4fff9e1    	cbz	x1, 0x101414150 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44e8>
101414218: aa1503e0    	mov	x0, x21
10141421c: 52800022    	mov	w2, #0x1                ; =1
101414220: 97da292f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414224: 17ffffcb    	b	0x101414150 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x44e8>
101414228: f94083e9    	ldr	x9, [sp, #0x100]
10141422c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101414230: a90a27f5    	stp	x21, x9, [sp, #0xa0]
101414234: eb08013f    	cmp	x9, x8
101414238: 540001a0    	b.eq	0x10141426c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4604>
10141423c: 940ec89c    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101414240: eb1a001f    	cmp	x0, x26
101414244: 54002761    	b.ne	0x101414730 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4ac8>
101414248: b940bbe8    	ldr	w8, [sp, #0xb8]
10141424c: 6b08003f    	cmp	w1, w8
101414250: 54002743    	b.lo	0x101414738 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4ad0>
101414254: 14000155    	b	0x1014147a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4b40>
101414258: f94083e1    	ldr	x1, [sp, #0x100]
10141425c: b4000081    	cbz	x1, 0x10141426c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4604>
101414260: aa1503e0    	mov	x0, x21
101414264: 52800022    	mov	w2, #0x1                ; =1
101414268: 97da291d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141426c: 52800108    	mov	w8, #0x8                ; =8
101414270: a91023ff    	stp	xzr, x8, [sp, #0x100]
101414274: a9117fff    	stp	xzr, xzr, [sp, #0x110]
101414278: a9127fe8    	stp	x8, xzr, [sp, #0x120]
10141427c: a91323ff    	stp	xzr, x8, [sp, #0x130]
101414280: a9147fff    	stp	xzr, xzr, [sp, #0x140]
101414284: f900abe8    	str	x8, [sp, #0x150]
101414288: f0003788    	adrp	x8, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
10141428c: 3dc2f900    	ldr	q0, [x8, #0xbe0]
101414290: 910403e8    	add	x8, sp, #0x100
101414294: 3c858100    	stur	q0, [x8, #0x58]
101414298: b940b3e8    	ldr	w8, [sp, #0xb0]
10141429c: 7100051f    	cmp	w8, #0x1
1014142a0: 5400018d    	b.le	0x1014142d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4668>
1014142a4: 7100091f    	cmp	w8, #0x2
1014142a8: 54000360    	b.eq	0x101414314 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x46ac>
1014142ac: 71000d1f    	cmp	w8, #0x3
1014142b0: 54000741    	b.ne	0x101414398 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4730>
1014142b4: a9520be1    	ldp	x1, x2, [sp, #0x120]
1014142b8: d10303a0    	sub	x0, x29, #0xc0
1014142bc: 94015fdb    	bl	0x10146c228 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xaf8>
1014142c0: f0004648    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014142c4: 91218d08    	add	x8, x8, #0x863
1014142c8: 528000a9    	mov	w9, #0x5                ; =5
1014142cc: 140001f6    	b	0x101414aa4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e3c>
1014142d0: 35000728    	cbnz	w8, 0x1014143b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x474c>
1014142d4: a9508be1    	ldp	x1, x2, [sp, #0x108]
1014142d8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014142dc: 91094000    	add	x0, x0, #0x250
1014142e0: 94015fd2    	bl	0x10146c228 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xaf8>
1014142e4: f94933e8    	ldr	x8, [sp, #0x1260]
1014142e8: b5003d08    	cbnz	x8, 0x101414a88 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e20>
1014142ec: f940b3e8    	ldr	x8, [sp, #0x160]
1014142f0: d2f00016    	mov	x22, #-0x8000000000000000 ; =-9223372036854775808
1014142f4: eb16011f    	cmp	x8, x22
1014142f8: 540039a1    	b.ne	0x101414a2c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4dc4>
1014142fc: d2f00014    	mov	x20, #-0x8000000000000000 ; =-9223372036854775808
101414300: 140001d2    	b	0x101414a48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4de0>
101414304: f90003e9    	str	x9, [sp]
101414308: d280001a    	mov	x26, #0x0               ; =0
10141430c: b5ffeee1    	cbnz	x1, 0x1014140e8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4480>
101414310: 17ffff7a    	b	0x1014140f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4490>
101414314: 528eac37    	mov	w23, #0x7561            ; =30049
101414318: 72ae8d97    	movk	w23, #0x746c, lsl #16
10141431c: 528cac98    	mov	w24, #0x6564            ; =25956
101414320: 72ac2cd8    	movk	w24, #0x6166, lsl #16
101414324: a953a3e9    	ldp	x9, x8, [sp, #0x138]
101414328: 8b080508    	add	x8, x8, x8, lsl #1
10141432c: d37df108    	lsl	x8, x8, #3
101414330: 8b080139    	add	x25, x9, x8
101414334: 91006129    	add	x9, x9, #0x18
101414338: b4000288    	cbz	x8, 0x101414388 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4720>
10141433c: aa0903fa    	mov	x26, x9
101414340: f85f8129    	ldur	x9, [x9, #-0x8]
101414344: f1001d3f    	cmp	x9, #0x7
101414348: 54000121    	b.ne	0x10141436c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4704>
10141434c: f85f0349    	ldur	x9, [x26, #-0x10]
101414350: b940012a    	ldr	w10, [x9]
101414354: b8403129    	ldur	w9, [x9, #0x3]
101414358: 6b18015f    	cmp	w10, w24
10141435c: 7a570120    	ccmp	w9, w23, #0x0, eq
101414360: 91006349    	add	x9, x26, #0x18
101414364: d1006108    	sub	x8, x8, #0x18
101414368: 54fffe80    	b.eq	0x101414338 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x46d0>
10141436c: d1006340    	sub	x0, x26, #0x18
101414370: 912783e8    	add	x8, sp, #0x9e0
101414374: 940feb96    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101414378: f944f3f3    	ldr	x19, [sp, #0x9e0]
10141437c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101414380: eb08027f    	cmp	x19, x8
101414384: 54001b81    	b.ne	0x1014146f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4a8c>
101414388: 52800108    	mov	w8, #0x8                ; =8
10141438c: a93423bf    	stp	xzr, x8, [x29, #-0xc0]
101414390: f81503bf    	stur	xzr, [x29, #-0xb0]
101414394: 14000143    	b	0x1014148a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4c38>
101414398: a9550be1    	ldp	x1, x2, [sp, #0x150]
10141439c: d10303a0    	sub	x0, x29, #0xc0
1014143a0: 94015fa2    	bl	0x10146c228 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xaf8>
1014143a4: f0004648    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014143a8: 9121a108    	add	x8, x8, #0x868
1014143ac: 528000e9    	mov	w9, #0x7                ; =7
1014143b0: 140001bd    	b	0x101414aa4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e3c>
1014143b4: 52800108    	mov	w8, #0x8                ; =8
1014143b8: a93423bf    	stp	xzr, x8, [x29, #-0xc0]
1014143bc: f81503bf    	stur	xzr, [x29, #-0xb0]
1014143c0: f0004648    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014143c4: 91212d08    	add	x8, x8, #0x84b
1014143c8: 528000e9    	mov	w9, #0x7                ; =7
1014143cc: 140001b6    	b	0x101414aa4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e3c>
1014143d0: eb1a001f    	cmp	x0, x26
1014143d4: 540003aa    	b.ge	0x101414448 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x47e0>
1014143d8: 912783e8    	add	x8, sp, #0x9e0
1014143dc: aa1503e0    	mov	x0, x21
1014143e0: aa1803e1    	mov	x1, x24
1014143e4: 940e70c2    	bl	0x1017b06ec <__ZN3std2fs14read_to_string5inner17h33327e834bd59c04E>
1014143e8: aa1903f3    	mov	x19, x25
1014143ec: f944f3f9    	ldr	x25, [sp, #0x9e0]
1014143f0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014143f4: eb08033f    	cmp	x25, x8
1014143f8: 540013a1    	b.ne	0x10141466c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4a04>
1014143fc: f944f7f3    	ldr	x19, [sp, #0x9e8]
101414400: 92400668    	and	x8, x19, #0x3
101414404: f100051f    	cmp	x8, #0x1
101414408: 54000201    	b.ne	0x101414448 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x47e0>
10141440c: f85ffe74    	ldr	x20, [x19, #-0x1]!
101414410: f9400677    	ldr	x23, [x19, #0x8]
101414414: f94002e8    	ldr	x8, [x23]
101414418: b4000068    	cbz	x8, 0x101414424 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x47bc>
10141441c: aa1403e0    	mov	x0, x20
101414420: d63f0100    	blr	x8
101414424: f94006e1    	ldr	x1, [x23, #0x8]
101414428: b4000081    	cbz	x1, 0x101414438 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x47d0>
10141442c: f9400ae2    	ldr	x2, [x23, #0x10]
101414430: aa1403e0    	mov	x0, x20
101414434: 97da28aa    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414438: aa1303e0    	mov	x0, x19
10141443c: 52800301    	mov	w1, #0x18               ; =24
101414440: 52800102    	mov	w2, #0x8                ; =8
101414444: 97da28a6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414448: b4ff07f6    	cbz	x22, 0x101412544 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28dc>
10141444c: aa1503e0    	mov	x0, x21
101414450: aa1603e1    	mov	x1, x22
101414454: 52800022    	mov	w2, #0x1                ; =1
101414458: 97da28a1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141445c: 17fff83a    	b	0x101412544 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28dc>
101414460: f0004642    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101414464: 910b6042    	add	x2, x2, #0x2d8
101414468: 912783e8    	add	x8, sp, #0x9e0
10141446c: aa1603e0    	mov	x0, x22
101414470: aa1703e1    	mov	x1, x23
101414474: 52800103    	mov	w3, #0x8                ; =8
101414478: 940ebf89    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
10141447c: f944f7f3    	ldr	x19, [sp, #0x9e8]
101414480: f944fbe1    	ldr	x1, [sp, #0x9f0]
101414484: 910403e8    	add	x8, sp, #0x100
101414488: aa1303e0    	mov	x0, x19
10141448c: 940e9be6    	bl	0x1017bb424 <__ZN3std3sys2fs8read_dir17h3de3d951fc53246fE>
101414490: 394423f4    	ldrb	w20, [sp, #0x108]
101414494: f94083f5    	ldr	x21, [sp, #0x100]
101414498: f944f3e1    	ldr	x1, [sp, #0x9e0]
10141449c: b4000081    	cbz	x1, 0x1014144ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4844>
1014144a0: aa1303e0    	mov	x0, x19
1014144a4: 52800022    	mov	w2, #0x1                ; =1
1014144a8: 97da288d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014144ac: 71000a9f    	cmp	w20, #0x2
1014144b0: 54000f81    	b.ne	0x1014146a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4a38>
1014144b4: 924006a8    	and	x8, x21, #0x3
1014144b8: f100051f    	cmp	x8, #0x1
1014144bc: 54005060    	b.eq	0x101414ec8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5260>
1014144c0: d2800013    	mov	x19, #0x0               ; =0
1014144c4: d2800015    	mov	x21, #0x0               ; =0
1014144c8: 52800114    	mov	w20, #0x8               ; =8
1014144cc: a9005395    	stp	x21, x20, [x28]
1014144d0: f9000b93    	str	x19, [x28, #0x10]
1014144d4: 140008fc    	b	0x1014168c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c5c>
1014144d8: a94757e8    	ldp	x8, x21, [sp, #0x70]
1014144dc: aa0803f3    	mov	x19, x8
1014144e0: f94043fb    	ldr	x27, [sp, #0x80]
1014144e4: f9402bf6    	ldr	x22, [sp, #0x50]
1014144e8: 14000012    	b	0x101414530 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x48c8>
1014144ec: aa1803f3    	mov	x19, x24
1014144f0: aa1c03f7    	mov	x23, x28
1014144f4: 1400000d    	b	0x101414528 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x48c0>
1014144f8: f9093bf6    	str	x22, [sp, #0x1270]
1014144fc: f9092ff8    	str	x24, [sp, #0x1258]
101414500: b40000b7    	cbz	x23, 0x101414514 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x48ac>
101414504: aa1903e0    	mov	x0, x25
101414508: aa1703e1    	mov	x1, x23
10141450c: 52800022    	mov	w2, #0x1                ; =1
101414510: 97da2873    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414514: aa1c03f7    	mov	x23, x28
101414518: a947eff5    	ldp	x21, x27, [sp, #0x78]
10141451c: f9403be8    	ldr	x8, [sp, #0x70]
101414520: 14000007    	b	0x10141453c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x48d4>
101414524: d2800016    	mov	x22, #0x0               ; =0
101414528: a947eff5    	ldp	x21, x27, [sp, #0x78]
10141452c: f9403be8    	ldr	x8, [sp, #0x70]
101414530: f9093bf6    	str	x22, [sp, #0x1270]
101414534: f9092ff3    	str	x19, [sp, #0x1258]
101414538: aa1303f8    	mov	x24, x19
10141453c: eb180108    	subs	x8, x8, x24
101414540: 54000200    	b.eq	0x101414580 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4918>
101414544: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
101414548: f2955569    	movk	x9, #0xaaab
10141454c: 9bc97d08    	umulh	x8, x8, x9
101414550: d344fd13    	lsr	x19, x8, #4
101414554: 91002314    	add	x20, x24, #0x8
101414558: 14000004    	b	0x101414568 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4900>
10141455c: 91006294    	add	x20, x20, #0x18
101414560: f1000673    	subs	x19, x19, #0x1
101414564: 540000e0    	b.eq	0x101414580 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4918>
101414568: f85f8281    	ldur	x1, [x20, #-0x8]
10141456c: b4ffff81    	cbz	x1, 0x10141455c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x48f4>
101414570: f9400280    	ldr	x0, [x20]
101414574: 52800022    	mov	w2, #0x1                ; =1
101414578: 97da2859    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141457c: 17fffff8    	b	0x10141455c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x48f4>
101414580: b40000d5    	cbz	x21, 0x101414598 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4930>
101414584: 8b1506a8    	add	x8, x21, x21, lsl #1
101414588: d37df101    	lsl	x1, x8, #3
10141458c: f94033e0    	ldr	x0, [sp, #0x60]
101414590: 52800102    	mov	w2, #0x8                ; =8
101414594: 97da2852    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414598: f94063f3    	ldr	x19, [sp, #0xc0]
10141459c: f94087f4    	ldr	x20, [sp, #0x108]
1014145a0: b4000594    	cbz	x20, 0x101414650 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x49e8>
1014145a4: aa1703fa    	mov	x26, x23
1014145a8: f9408ff5    	ldr	x21, [sp, #0x118]
1014145ac: b40003d5    	cbz	x21, 0x101414624 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x49bc>
1014145b0: f94083f6    	ldr	x22, [sp, #0x100]
1014145b4: aa1603f7    	mov	x23, x22
1014145b8: fc4086e0    	ldr	d0, [x23], #0x8
1014145bc: 2e208800    	cmge.8b	v0, v0, #0
1014145c0: 9e660008    	fmov	x8, d0
1014145c4: 9201c119    	and	x25, x8, #0x8080808080808080
1014145c8: 52800318    	mov	w24, #0x18              ; =24
1014145cc: 14000005    	b	0x1014145e0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4978>
1014145d0: d1000728    	sub	x8, x25, #0x1
1014145d4: 8a190119    	and	x25, x8, x25
1014145d8: d10006b5    	sub	x21, x21, #0x1
1014145dc: b4000255    	cbz	x21, 0x101414624 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x49bc>
1014145e0: b50000f9    	cbnz	x25, 0x1014145fc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4994>
1014145e4: fc4086e0    	ldr	d0, [x23], #0x8
1014145e8: 2e208800    	cmge.8b	v0, v0, #0
1014145ec: 9e660008    	fmov	x8, d0
1014145f0: d10302d6    	sub	x22, x22, #0xc0
1014145f4: 9201c119    	and	x25, x8, #0x8080808080808080
1014145f8: b4ffff79    	cbz	x25, 0x1014145e4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x497c>
1014145fc: dac00328    	rbit	x8, x25
101414600: dac01108    	clz	x8, x8
101414604: cb480fe8    	neg	x8, x8, lsr #3
101414608: 9b385908    	smaddl	x8, w8, w24, x22
10141460c: f85e8101    	ldur	x1, [x8, #-0x18]
101414610: b4fffe01    	cbz	x1, 0x1014145d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4968>
101414614: f85f0100    	ldur	x0, [x8, #-0x10]
101414618: 52800022    	mov	w2, #0x1                ; =1
10141461c: 97da2830    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414620: 17ffffec    	b	0x1014145d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4968>
101414624: 8b140688    	add	x8, x20, x20, lsl #1
101414628: d37df108    	lsl	x8, x8, #3
10141462c: 8b140109    	add	x9, x8, x20
101414630: b1008521    	adds	x1, x9, #0x21
101414634: aa1a03f7    	mov	x23, x26
101414638: 540000c0    	b.eq	0x101414650 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x49e8>
10141463c: f94083e9    	ldr	x9, [sp, #0x100]
101414640: cb080128    	sub	x8, x9, x8
101414644: d1006100    	sub	x0, x8, #0x18
101414648: 52800102    	mov	w2, #0x8                ; =8
10141464c: 97da2824    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414650: f240fb7f    	tst	x27, #0x7fffffffffffffff
101414654: 54004260    	b.eq	0x101414ea0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5238>
101414658: f9402fe0    	ldr	x0, [sp, #0x58]
10141465c: aa1b03e1    	mov	x1, x27
101414660: 52800022    	mov	w2, #0x1                ; =1
101414664: 97da281e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414668: 1400020e    	b	0x101414ea0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5238>
10141466c: f944f7f4    	ldr	x20, [sp, #0x9e8]
101414670: f944fbe8    	ldr	x8, [sp, #0x9f0]
101414674: a91023f4    	stp	x20, x8, [sp, #0x100]
101414678: f9008bff    	str	xzr, [sp, #0x110]
10141467c: 912783e0    	add	x0, sp, #0x9e0
101414680: 910403e1    	add	x1, sp, #0x100
101414684: 97ffbc04    	bl	0x101403694 <__ZN108_$LT$otty_autocomplete..fix..rules..TerraformInitRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17ha6c5d91531514264E+0x2648>
101414688: 396783e8    	ldrb	w8, [sp, #0x9e0]
10141468c: 7100191f    	cmp	w8, #0x6
101414690: 540011a1    	b.ne	0x1014148c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4c5c>
101414694: 912783e0    	add	x0, sp, #0x9e0
101414698: 9400efd5    	bl	0x1014505ec <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x3164>
10141469c: 14000195    	b	0x101414cf0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5088>
1014146a0: f90083ff    	str	xzr, [sp, #0x100]
1014146a4: f90297ff    	str	xzr, [sp, #0x528]
1014146a8: f904abf5    	str	x21, [sp, #0x950]
1014146ac: 392563f4    	strb	w20, [sp, #0x958]
1014146b0: 52801908    	mov	w8, #0xc8               ; =200
1014146b4: f904b3e8    	str	x8, [sp, #0x960]
1014146b8: f904b7f9    	str	x25, [sp, #0x968]
1014146bc: 9125c3e0    	add	x0, sp, #0x970
1014146c0: 910403e1    	add	x1, sp, #0x100
1014146c4: 97ffaa8e    	bl	0x1013ff0fc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x13d4>
1014146c8: f944bbe8    	ldr	x8, [sp, #0x970]
1014146cc: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1014146d0: eb09011f    	cmp	x8, x9
1014146d4: 540011a1    	b.ne	0x101414908 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4ca0>
1014146d8: f904f3ff    	str	xzr, [sp, #0x9e0]
1014146dc: 910403e0    	add	x0, sp, #0x100
1014146e0: 9401062d    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
1014146e4: d2800013    	mov	x19, #0x0               ; =0
1014146e8: 52800114    	mov	w20, #0x8               ; =8
1014146ec: f944f3f5    	ldr	x21, [sp, #0x9e0]
1014146f0: 17ffff77    	b	0x1014144cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4864>
1014146f4: f944f7f5    	ldr	x21, [sp, #0x9e8]
1014146f8: f944fbf6    	ldr	x22, [sp, #0x9f0]
1014146fc: 97da27fd    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101414700: 52800c00    	mov	w0, #0x60               ; =96
101414704: 52800101    	mov	w1, #0x8                ; =8
101414708: 97da27f4    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10141470c: b40123c0    	cbz	x0, 0x101416b84 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6f1c>
101414710: aa0003f4    	mov	x20, x0
101414714: a9005413    	stp	x19, x21, [x0]
101414718: f9000816    	str	x22, [x0, #0x10]
10141471c: 52800088    	mov	w8, #0x4                ; =4
101414720: f9092be8    	str	x8, [sp, #0x1250]
101414724: f9092fe0    	str	x0, [sp, #0x1258]
101414728: 52800033    	mov	w19, #0x1               ; =1
10141472c: 14000036    	b	0x101414804 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4b9c>
101414730: eb1a001f    	cmp	x0, x26
101414734: 540003aa    	b.ge	0x1014147a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4b40>
101414738: 912783e8    	add	x8, sp, #0x9e0
10141473c: f94053e0    	ldr	x0, [sp, #0xa0]
101414740: aa1403e1    	mov	x1, x20
101414744: 940e6fea    	bl	0x1017b06ec <__ZN3std2fs14read_to_string5inner17h33327e834bd59c04E>
101414748: f944f3e8    	ldr	x8, [sp, #0x9e0]
10141474c: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101414750: f9005fe8    	str	x8, [sp, #0xb8]
101414754: eb09011f    	cmp	x8, x9
101414758: 54002e41    	b.ne	0x101414d20 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x50b8>
10141475c: f944f7f3    	ldr	x19, [sp, #0x9e8]
101414760: 92400668    	and	x8, x19, #0x3
101414764: f100051f    	cmp	x8, #0x1
101414768: 54000201    	b.ne	0x1014147a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4b40>
10141476c: f85ffe74    	ldr	x20, [x19, #-0x1]!
101414770: f9400677    	ldr	x23, [x19, #0x8]
101414774: f94002e8    	ldr	x8, [x23]
101414778: b4000068    	cbz	x8, 0x101414784 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4b1c>
10141477c: aa1403e0    	mov	x0, x20
101414780: d63f0100    	blr	x8
101414784: f94006e1    	ldr	x1, [x23, #0x8]
101414788: b4000081    	cbz	x1, 0x101414798 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4b30>
10141478c: f9400ae2    	ldr	x2, [x23, #0x10]
101414790: aa1403e0    	mov	x0, x20
101414794: 97da27d2    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414798: aa1303e0    	mov	x0, x19
10141479c: 52800301    	mov	w1, #0x18               ; =24
1014147a0: 52800102    	mov	w2, #0x8                ; =8
1014147a4: 97da27ce    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014147a8: 52800108    	mov	w8, #0x8                ; =8
1014147ac: a91023ff    	stp	xzr, x8, [sp, #0x100]
1014147b0: a9117fff    	stp	xzr, xzr, [sp, #0x110]
1014147b4: a9127fe8    	stp	x8, xzr, [sp, #0x120]
1014147b8: a91323ff    	stp	xzr, x8, [sp, #0x130]
1014147bc: a9147fff    	stp	xzr, xzr, [sp, #0x140]
1014147c0: f900abe8    	str	x8, [sp, #0x150]
1014147c4: f0003788    	adrp	x8, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
1014147c8: 3dc2f900    	ldr	q0, [x8, #0xbe0]
1014147cc: 910403e8    	add	x8, sp, #0x100
1014147d0: 3c858100    	stur	q0, [x8, #0x58]
1014147d4: f94057e8    	ldr	x8, [sp, #0xa8]
1014147d8: b4ffd608    	cbz	x8, 0x101414298 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4630>
1014147dc: a94a07e0    	ldp	x0, x1, [sp, #0xa0]
1014147e0: 52800022    	mov	w2, #0x1                ; =1
1014147e4: 97da27be    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014147e8: 17fffeac    	b	0x101414298 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4630>
1014147ec: f9492ff4    	ldr	x20, [sp, #0x1258]
1014147f0: 52800308    	mov	w8, #0x18               ; =24
1014147f4: 9b085268    	madd	x8, x19, x8, x20
1014147f8: a9005915    	stp	x21, x22, [x8]
1014147fc: f900091b    	str	x27, [x8, #0x10]
101414800: 91000673    	add	x19, x19, #0x1
101414804: f90933f3    	str	x19, [sp, #0x1260]
101414808: 91006348    	add	x8, x26, #0x18
10141480c: d1006100    	sub	x0, x8, #0x18
101414810: eb19001f    	cmp	x0, x25
101414814: 540003e0    	b.eq	0x101414890 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4c28>
101414818: aa0803fa    	mov	x26, x8
10141481c: f85f8108    	ldur	x8, [x8, #-0x8]
101414820: f1001d1f    	cmp	x8, #0x7
101414824: 54000101    	b.ne	0x101414844 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4bdc>
101414828: f85f0348    	ldur	x8, [x26, #-0x10]
10141482c: b9400109    	ldr	w9, [x8]
101414830: b8403108    	ldur	w8, [x8, #0x3]
101414834: 6b18013f    	cmp	w9, w24
101414838: 7a570100    	ccmp	w8, w23, #0x0, eq
10141483c: 91006348    	add	x8, x26, #0x18
101414840: 54fffe60    	b.eq	0x10141480c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4ba4>
101414844: 912783e8    	add	x8, sp, #0x9e0
101414848: 940fea61    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10141484c: f944f3f5    	ldr	x21, [sp, #0x9e0]
101414850: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101414854: eb0802bf    	cmp	x21, x8
101414858: 540001c0    	b.eq	0x101414890 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4c28>
10141485c: f944f7f6    	ldr	x22, [sp, #0x9e8]
101414860: f944fbfb    	ldr	x27, [sp, #0x9f0]
101414864: f9492be8    	ldr	x8, [sp, #0x1250]
101414868: eb08027f    	cmp	x19, x8
10141486c: 54fffc21    	b.ne	0x1014147f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4b88>
101414870: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101414874: 91094000    	add	x0, x0, #0x250
101414878: aa1303e1    	mov	x1, x19
10141487c: 52800022    	mov	w2, #0x1                ; =1
101414880: 52800103    	mov	w3, #0x8                ; =8
101414884: 52800304    	mov	w4, #0x18               ; =24
101414888: 94184ff2    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10141488c: 17ffffd8    	b	0x1014147ec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4b84>
101414890: 3dc497e0    	ldr	q0, [sp, #0x1250]
101414894: 3c9403a0    	stur	q0, [x29, #-0xc0]
101414898: f94933e8    	ldr	x8, [sp, #0x1260]
10141489c: f81503a8    	stur	x8, [x29, #-0xb0]
1014148a0: f0004648    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014148a4: 91217108    	add	x8, x8, #0x85c
1014148a8: 528000e9    	mov	w9, #0x7                ; =7
1014148ac: 1400007e    	b	0x101414aa4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e3c>
1014148b0: f9005fff    	str	xzr, [sp, #0xb8]
1014148b4: d2800013    	mov	x19, #0x0               ; =0
1014148b8: 52800108    	mov	w8, #0x8                ; =8
1014148bc: f90053e8    	str	x8, [sp, #0xa0]
1014148c0: 14000177    	b	0x101414e9c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5234>
1014148c4: 3dc27be0    	ldr	q0, [sp, #0x9e0]
1014148c8: 3dc27fe1    	ldr	q1, [sp, #0x9f0]
1014148cc: ad0607e0    	stp	q0, q1, [sp, #0xc0]
1014148d0: f0004640    	adrp	x0, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014148d4: 911ebc00    	add	x0, x0, #0x7af
1014148d8: 910303e2    	add	x2, sp, #0xc0
1014148dc: 528000e1    	mov	w1, #0x7                ; =7
1014148e0: 9409e799    	bl	0x10168e744 <__ZN55_$LT$str$u20$as$u20$serde_json..value..index..Index$GT$10index_into17hf1f119782d5b9e1fE>
1014148e4: b4002020    	cbz	x0, 0x101414ce8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5080>
1014148e8: 39400008    	ldrb	w8, [x0]
1014148ec: 7100151f    	cmp	w8, #0x5
1014148f0: 54001fc1    	b.ne	0x101414ce8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5080>
1014148f4: f9400408    	ldr	x8, [x0, #0x8]
1014148f8: b400ae28    	cbz	x8, 0x101415ebc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6254>
1014148fc: a941240a    	ldp	x10, x9, [x0, #0x10]
101414900: 5280002b    	mov	w11, #0x1               ; =1
101414904: 14000570    	b	0x101415ec4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x625c>
101414908: 97da277a    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10141490c: 52803400    	mov	w0, #0x1a0              ; =416
101414910: 52800101    	mov	w1, #0x8                ; =8
101414914: 97da2771    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101414918: b40113e0    	cbz	x0, 0x101416b94 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6f2c>
10141491c: aa0003f3    	mov	x19, x0
101414920: 3dc26fe0    	ldr	q0, [sp, #0x9b0]
101414924: 3dc273e1    	ldr	q1, [sp, #0x9c0]
101414928: ad020400    	stp	q0, q1, [x0, #0x40]
10141492c: f944ebe8    	ldr	x8, [sp, #0x9d0]
101414930: f9003008    	str	x8, [x0, #0x60]
101414934: 3dc25fe0    	ldr	q0, [sp, #0x970]
101414938: 3dc263e1    	ldr	q1, [sp, #0x980]
10141493c: ad000400    	stp	q0, q1, [x0]
101414940: 3dc26be0    	ldr	q0, [sp, #0x9a0]
101414944: 3dc267e1    	ldr	q1, [sp, #0x990]
101414948: ad010001    	stp	q1, q0, [x0, #0x20]
10141494c: 52800088    	mov	w8, #0x4                ; =4
101414950: a90c03e8    	stp	x8, x0, [sp, #0xc0]
101414954: 52800034    	mov	w20, #0x1               ; =1
101414958: f9006bf4    	str	x20, [sp, #0xd0]
10141495c: 912783e0    	add	x0, sp, #0x9e0
101414960: 910403e1    	add	x1, sp, #0x100
101414964: 52810e02    	mov	w2, #0x870              ; =2160
101414968: 941ad4b0    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10141496c: 52800d15    	mov	w21, #0x68              ; =104
101414970: d2f00016    	mov	x22, #-0x8000000000000000 ; =-9223372036854775808
101414974: 14000011    	b	0x1014149b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4d50>
101414978: 8b150268    	add	x8, x19, x21
10141497c: 3dc497e0    	ldr	q0, [sp, #0x1250]
101414980: 3dc49be1    	ldr	q1, [sp, #0x1260]
101414984: 3dc49fe2    	ldr	q2, [sp, #0x1270]
101414988: ad008901    	stp	q1, q2, [x8, #0x10]
10141498c: 3d800100    	str	q0, [x8]
101414990: 3dc4a3e0    	ldr	q0, [sp, #0x1280]
101414994: 3dc4a7e1    	ldr	q1, [sp, #0x1290]
101414998: 3dc4abe2    	ldr	q2, [sp, #0x12a0]
10141499c: f9495be9    	ldr	x9, [sp, #0x12b0]
1014149a0: f9003109    	str	x9, [x8, #0x60]
1014149a4: ad020901    	stp	q1, q2, [x8, #0x40]
1014149a8: 3d800d00    	str	q0, [x8, #0x30]
1014149ac: 91000694    	add	x20, x20, #0x1
1014149b0: f9006bf4    	str	x20, [sp, #0xd0]
1014149b4: 9101a2b5    	add	x21, x21, #0x68
1014149b8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014149bc: 91094000    	add	x0, x0, #0x250
1014149c0: 912783e1    	add	x1, sp, #0x9e0
1014149c4: 97ffa9ce    	bl	0x1013ff0fc <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x13d4>
1014149c8: f9492be8    	ldr	x8, [sp, #0x1250]
1014149cc: eb16011f    	cmp	x8, x22
1014149d0: 54000180    	b.eq	0x101414a00 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4d98>
1014149d4: f94063e8    	ldr	x8, [sp, #0xc0]
1014149d8: eb08029f    	cmp	x20, x8
1014149dc: 54fffce1    	b.ne	0x101414978 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4d10>
1014149e0: 910303e0    	add	x0, sp, #0xc0
1014149e4: aa1403e1    	mov	x1, x20
1014149e8: 52800022    	mov	w2, #0x1                ; =1
1014149ec: 52800103    	mov	w3, #0x8                ; =8
1014149f0: 52800d04    	mov	w4, #0x68               ; =104
1014149f4: 94184f97    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1014149f8: f94067f3    	ldr	x19, [sp, #0xc8]
1014149fc: 17ffffdf    	b	0x101414978 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4d10>
101414a00: 912783e0    	add	x0, sp, #0x9e0
101414a04: 94010564    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
101414a08: 3dc033e0    	ldr	q0, [sp, #0xc0]
101414a0c: 3d827be0    	str	q0, [sp, #0x9e0]
101414a10: f9406bf3    	ldr	x19, [sp, #0xd0]
101414a14: f904fbf3    	str	x19, [sp, #0x9f0]
101414a18: f944f7f4    	ldr	x20, [sp, #0x9e8]
101414a1c: f1000a7f    	cmp	x19, #0x2
101414a20: 5400fb82    	b.hs	0x101416990 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6d28>
101414a24: f944f3f5    	ldr	x21, [sp, #0x9e0]
101414a28: 17fffea9    	b	0x1014144cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4864>
101414a2c: 910403e9    	add	x9, sp, #0x100
101414a30: 912783e8    	add	x8, sp, #0x9e0
101414a34: 91018120    	add	x0, x9, #0x60
101414a38: 940fe9e5    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101414a3c: f944f3f4    	ldr	x20, [sp, #0x9e0]
101414a40: f944f7f3    	ldr	x19, [sp, #0x9e8]
101414a44: f944fbf5    	ldr	x21, [sp, #0x9f0]
101414a48: eb16029f    	cmp	x20, x22
101414a4c: 1a9f07e2    	cset	w2, ne
101414a50: f9492be8    	ldr	x8, [sp, #0x1250]
101414a54: eb02011f    	cmp	x8, x2
101414a58: 5400fb03    	b.lo	0x1014169b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6d50>
101414a5c: d2800008    	mov	x8, #0x0                ; =0
101414a60: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101414a64: eb09029f    	cmp	x20, x9
101414a68: 540000e0    	b.eq	0x101414a84 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e1c>
101414a6c: f9492fe9    	ldr	x9, [sp, #0x1258]
101414a70: 5280030a    	mov	w10, #0x18              ; =24
101414a74: 9b0a2509    	madd	x9, x8, x10, x9
101414a78: a9004d34    	stp	x20, x19, [x9]
101414a7c: f9000935    	str	x21, [x9, #0x10]
101414a80: 91000508    	add	x8, x8, #0x1
101414a84: f90933e8    	str	x8, [sp, #0x1260]
101414a88: 3dc497e0    	ldr	q0, [sp, #0x1250]
101414a8c: 3c9403a0    	stur	q0, [x29, #-0xc0]
101414a90: f94933e8    	ldr	x8, [sp, #0x1260]
101414a94: f81503a8    	stur	x8, [x29, #-0xb0]
101414a98: f0004648    	adrp	x8, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101414a9c: 911f0908    	add	x8, x8, #0x7c2
101414aa0: 52800069    	mov	w9, #0x3                ; =3
101414aa4: f9401fee    	ldr	x14, [sp, #0x38]
101414aa8: a9742faa    	ldp	x10, x11, [x29, #-0xc0]
101414aac: f85503ac    	ldur	x12, [x29, #-0xb0]
101414ab0: 5280030d    	mov	w13, #0x18              ; =24
101414ab4: 9b0d2d8c    	madd	x12, x12, x13, x11
101414ab8: a90c2feb    	stp	x11, x11, [sp, #0xc0]
101414abc: a90d33ea    	stp	x10, x12, [sp, #0xd0]
101414ac0: a90e23ee    	stp	x14, x8, [sp, #0xe0]
101414ac4: f9007be9    	str	x9, [sp, #0xf0]
101414ac8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101414acc: 91094000    	add	x0, x0, #0x250
101414ad0: 910303e1    	add	x1, sp, #0xc0
101414ad4: 97ffa553    	bl	0x1013fe020 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x2f8>
101414ad8: f9492be8    	ldr	x8, [sp, #0x1250]
101414adc: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101414ae0: eb09011f    	cmp	x8, x9
101414ae4: 54000281    	b.ne	0x101414b34 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4ecc>
101414ae8: f94067e8    	ldr	x8, [sp, #0xc8]
101414aec: f9406fe9    	ldr	x9, [sp, #0xd8]
101414af0: eb080129    	subs	x9, x9, x8
101414af4: 54000a00    	b.eq	0x101414c34 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4fcc>
101414af8: b201f3ea    	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
101414afc: f295556a    	movk	x10, #0xaaab
101414b00: 9bca7d29    	umulh	x9, x9, x10
101414b04: d344fd33    	lsr	x19, x9, #4
101414b08: 91002114    	add	x20, x8, #0x8
101414b0c: 14000004    	b	0x101414b1c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4eb4>
101414b10: 91006294    	add	x20, x20, #0x18
101414b14: f1000673    	subs	x19, x19, #0x1
101414b18: 540008e0    	b.eq	0x101414c34 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4fcc>
101414b1c: f85f8281    	ldur	x1, [x20, #-0x8]
101414b20: b4ffff81    	cbz	x1, 0x101414b10 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4ea8>
101414b24: f9400280    	ldr	x0, [x20]
101414b28: 52800022    	mov	w2, #0x1                ; =1
101414b2c: 97da26ec    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414b30: 17fffff8    	b	0x101414b10 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4ea8>
101414b34: 97da26ef    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101414b38: 52803400    	mov	w0, #0x1a0              ; =416
101414b3c: 52800101    	mov	w1, #0x8                ; =8
101414b40: 97da26e6    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101414b44: b4010020    	cbz	x0, 0x101416b48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6ee0>
101414b48: aa0003f4    	mov	x20, x0
101414b4c: 3dc4a7e0    	ldr	q0, [sp, #0x1290]
101414b50: 3dc4abe1    	ldr	q1, [sp, #0x12a0]
101414b54: ad020400    	stp	q0, q1, [x0, #0x40]
101414b58: f9495be8    	ldr	x8, [sp, #0x12b0]
101414b5c: f9003008    	str	x8, [x0, #0x60]
101414b60: 3dc497e0    	ldr	q0, [sp, #0x1250]
101414b64: 3dc49be1    	ldr	q1, [sp, #0x1260]
101414b68: ad000400    	stp	q0, q1, [x0]
101414b6c: 3dc4a3e0    	ldr	q0, [sp, #0x1280]
101414b70: 3dc49fe1    	ldr	q1, [sp, #0x1270]
101414b74: ad010001    	stp	q1, q0, [x0, #0x20]
101414b78: 52800088    	mov	w8, #0x4                ; =4
101414b7c: a93603a8    	stp	x8, x0, [x29, #-0xa0]
101414b80: 52800033    	mov	w19, #0x1               ; =1
101414b84: f81703b3    	stur	x19, [x29, #-0x90]
101414b88: ad4607e0    	ldp	q0, q1, [sp, #0xc0]
101414b8c: 3d825fe0    	str	q0, [sp, #0x970]
101414b90: 3d8263e1    	str	q1, [sp, #0x980]
101414b94: 3dc03be0    	ldr	q0, [sp, #0xe0]
101414b98: f9407be8    	ldr	x8, [sp, #0xf0]
101414b9c: f904d3e8    	str	x8, [sp, #0x9a0]
101414ba0: 52800d15    	mov	w21, #0x68              ; =104
101414ba4: d2f00016    	mov	x22, #-0x8000000000000000 ; =-9223372036854775808
101414ba8: 3d8267e0    	str	q0, [sp, #0x990]
101414bac: 14000011    	b	0x101414bf0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4f88>
101414bb0: 8b150288    	add	x8, x20, x21
101414bb4: 3dc27be0    	ldr	q0, [sp, #0x9e0]
101414bb8: 3dc27fe1    	ldr	q1, [sp, #0x9f0]
101414bbc: 3dc283e2    	ldr	q2, [sp, #0xa00]
101414bc0: ad008901    	stp	q1, q2, [x8, #0x10]
101414bc4: 3d800100    	str	q0, [x8]
101414bc8: 3dc287e0    	ldr	q0, [sp, #0xa10]
101414bcc: 3dc28be1    	ldr	q1, [sp, #0xa20]
101414bd0: 3dc28fe2    	ldr	q2, [sp, #0xa30]
101414bd4: f94523e9    	ldr	x9, [sp, #0xa40]
101414bd8: f9003109    	str	x9, [x8, #0x60]
101414bdc: ad020901    	stp	q1, q2, [x8, #0x40]
101414be0: 3d800d00    	str	q0, [x8, #0x30]
101414be4: 91000673    	add	x19, x19, #0x1
101414be8: f81703b3    	stur	x19, [x29, #-0x90]
101414bec: 9101a2b5    	add	x21, x21, #0x68
101414bf0: 912783e0    	add	x0, sp, #0x9e0
101414bf4: 9125c3e1    	add	x1, sp, #0x970
101414bf8: 97ffa50a    	bl	0x1013fe020 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x2f8>
101414bfc: f944f3e8    	ldr	x8, [sp, #0x9e0]
101414c00: eb16011f    	cmp	x8, x22
101414c04: 540002e0    	b.eq	0x101414c60 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4ff8>
101414c08: f85603a8    	ldur	x8, [x29, #-0xa0]
101414c0c: eb08027f    	cmp	x19, x8
101414c10: 54fffd01    	b.ne	0x101414bb0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4f48>
101414c14: d10283a0    	sub	x0, x29, #0xa0
101414c18: aa1303e1    	mov	x1, x19
101414c1c: 52800022    	mov	w2, #0x1                ; =1
101414c20: 52800103    	mov	w3, #0x8                ; =8
101414c24: 52800d04    	mov	w4, #0x68               ; =104
101414c28: 94184f0a    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101414c2c: f85683b4    	ldur	x20, [x29, #-0x98]
101414c30: 17ffffe0    	b	0x101414bb0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4f48>
101414c34: f9406be8    	ldr	x8, [sp, #0xd0]
101414c38: b40004c8    	cbz	x8, 0x101414cd0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5068>
101414c3c: f94063e0    	ldr	x0, [sp, #0xc0]
101414c40: 8b080508    	add	x8, x8, x8, lsl #1
101414c44: d37df101    	lsl	x1, x8, #3
101414c48: 52800114    	mov	w20, #0x8               ; =8
101414c4c: 52800102    	mov	w2, #0x8                ; =8
101414c50: 97da26a3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414c54: d2800013    	mov	x19, #0x0               ; =0
101414c58: d2800015    	mov	x21, #0x0               ; =0
101414c5c: 14000020    	b	0x101414cdc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5074>
101414c60: f944bfe8    	ldr	x8, [sp, #0x978]
101414c64: f944c7e9    	ldr	x9, [sp, #0x988]
101414c68: eb080129    	subs	x9, x9, x8
101414c6c: 54000200    	b.eq	0x101414cac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5044>
101414c70: b201f3ea    	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
101414c74: f295556a    	movk	x10, #0xaaab
101414c78: 9bca7d29    	umulh	x9, x9, x10
101414c7c: d344fd35    	lsr	x21, x9, #4
101414c80: 91002116    	add	x22, x8, #0x8
101414c84: 14000004    	b	0x101414c94 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x502c>
101414c88: 910062d6    	add	x22, x22, #0x18
101414c8c: f10006b5    	subs	x21, x21, #0x1
101414c90: 540000e0    	b.eq	0x101414cac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5044>
101414c94: f85f82c1    	ldur	x1, [x22, #-0x8]
101414c98: b4ffff81    	cbz	x1, 0x101414c88 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5020>
101414c9c: f94002c0    	ldr	x0, [x22]
101414ca0: 52800022    	mov	w2, #0x1                ; =1
101414ca4: 97da268e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414ca8: 17fffff8    	b	0x101414c88 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5020>
101414cac: f944c3e8    	ldr	x8, [sp, #0x980]
101414cb0: b40000c8    	cbz	x8, 0x101414cc8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5060>
101414cb4: f944bbe0    	ldr	x0, [sp, #0x970]
101414cb8: 8b080508    	add	x8, x8, x8, lsl #1
101414cbc: d37df101    	lsl	x1, x8, #3
101414cc0: 52800102    	mov	w2, #0x8                ; =8
101414cc4: 97da2686    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414cc8: f85603b5    	ldur	x21, [x29, #-0xa0]
101414ccc: 14000004    	b	0x101414cdc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5074>
101414cd0: d2800013    	mov	x19, #0x0               ; =0
101414cd4: d2800015    	mov	x21, #0x0               ; =0
101414cd8: 52800114    	mov	w20, #0x8               ; =8
101414cdc: 910403e0    	add	x0, sp, #0x100
101414ce0: 940100f3    	bl	0x1014550ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7c24>
101414ce4: 17fffdfa    	b	0x1014144cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4864>
101414ce8: 910303e0    	add	x0, sp, #0xc0
101414cec: 9400fa78    	bl	0x1014536cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6244>
101414cf0: d2800018    	mov	x24, #0x0               ; =0
101414cf4: d280001b    	mov	x27, #0x0               ; =0
101414cf8: 52800117    	mov	w23, #0x8               ; =8
101414cfc: b40000b9    	cbz	x25, 0x101414d10 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x50a8>
101414d00: aa1403e0    	mov	x0, x20
101414d04: aa1903e1    	mov	x1, x25
101414d08: 52800022    	mov	w2, #0x1                ; =1
101414d0c: 97da2674    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414d10: b4fec216    	cbz	x22, 0x101412550 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x28e8>
101414d14: aa1503e0    	mov	x0, x21
101414d18: aa1603e1    	mov	x1, x22
101414d1c: 17fff5d7    	b	0x101412478 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2810>
101414d20: f9004fff    	str	xzr, [sp, #0x98]
101414d24: d280001b    	mov	x27, #0x0               ; =0
101414d28: 528dec88    	mov	w8, #0x6f64             ; =28516
101414d2c: 72ad6c68    	movk	w8, #0x6b63, lsl #16
101414d30: f944f7eb    	ldr	x11, [sp, #0x9e8]
101414d34: f944fbe9    	ldr	x9, [sp, #0x9f0]
101414d38: 5280010a    	mov	w10, #0x8               ; =8
101414d3c: f904f3ff    	str	xzr, [sp, #0x9e0]
101414d40: f904f7ea    	str	x10, [sp, #0x9e8]
101414d44: f904ffff    	str	xzr, [sp, #0x9f8]
101414d48: f904fbff    	str	xzr, [sp, #0x9f0]
101414d4c: f90503ea    	str	x10, [sp, #0xa00]
101414d50: f90507ff    	str	xzr, [sp, #0xa08]
101414d54: f9050bff    	str	xzr, [sp, #0xa10]
101414d58: f9050fea    	str	x10, [sp, #0xa18]
101414d5c: f90517ff    	str	xzr, [sp, #0xa28]
101414d60: f90513ff    	str	xzr, [sp, #0xa20]
101414d64: f9051bea    	str	x10, [sp, #0xa30]
101414d68: f000378a    	adrp	x10, 0x101b07000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x14>
101414d6c: 3dc2f940    	ldr	q0, [x10, #0xbe0]
101414d70: 0f000541    	movi.2s	v1, #0xa
101414d74: 5280002c    	mov	w12, #0x1               ; =1
101414d78: 912783ea    	add	x10, sp, #0x9e0
101414d7c: 3c858140    	stur	q0, [x10, #0x58]
101414d80: 910403ea    	add	x10, sp, #0x100
101414d84: 9100bd4a    	add	x10, x10, #0x2f
101414d88: a9082fea    	stp	x10, x11, [sp, #0x80]
101414d8c: 0f0107a8    	movi.2s	v8, #0x3d
101414d90: f904bbff    	str	xzr, [sp, #0x970]
101414d94: f904bfe9    	str	x9, [sp, #0x978]
101414d98: f904c3eb    	str	x11, [sp, #0x980]
101414d9c: f904c7e9    	str	x9, [sp, #0x988]
101414da0: fd04d3e1    	str	d1, [sp, #0x9a0]
101414da4: 0f0207a9    	movi.2s	v9, #0x5d
101414da8: 0f01058a    	movi.2s	v10, #0x2c
101414dac: f904cbff    	str	xzr, [sp, #0x990]
101414db0: f904cfe9    	str	x9, [sp, #0x998]
101414db4: 5137d108    	sub	w8, w8, #0xdf4
101414db8: b90093e8    	str	w8, [sp, #0x90]
101414dbc: 52800036    	mov	w22, #0x1               ; =1
101414dc0: 3926a3ec    	strb	w12, [sp, #0x9a8]
101414dc4: 5280003a    	mov	w26, #0x1               ; =1
101414dc8: 791363ff    	strh	wzr, [sp, #0x9b0]
101414dcc: 1400005b    	b	0x101414f38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52d0>
101414dd0: eb1b001f    	cmp	x0, x27
101414dd4: 5400036a    	b.ge	0x101414e40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x51d8>
101414dd8: f9405be8    	ldr	x8, [sp, #0xb0]
101414ddc: a9408500    	ldp	x0, x1, [x8, #0x8]
101414de0: 912783e8    	add	x8, sp, #0x9e0
101414de4: 940e9990    	bl	0x1017bb424 <__ZN3std3sys2fs8read_dir17h3de3d951fc53246fE>
101414de8: 3967a3e8    	ldrb	w8, [sp, #0x9e8]
101414dec: f944f3f6    	ldr	x22, [sp, #0x9e0]
101414df0: 7100091f    	cmp	w8, #0x2
101414df4: 54005f01    	b.ne	0x1014159d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5d6c>
101414df8: 924006c8    	and	x8, x22, #0x3
101414dfc: f100051f    	cmp	x8, #0x1
101414e00: 54000201    	b.ne	0x101414e40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x51d8>
101414e04: f85ffed3    	ldr	x19, [x22, #-0x1]!
101414e08: f94006d4    	ldr	x20, [x22, #0x8]
101414e0c: f9400288    	ldr	x8, [x20]
101414e10: b4000068    	cbz	x8, 0x101414e1c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x51b4>
101414e14: aa1303e0    	mov	x0, x19
101414e18: d63f0100    	blr	x8
101414e1c: f9400681    	ldr	x1, [x20, #0x8]
101414e20: b4000081    	cbz	x1, 0x101414e30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x51c8>
101414e24: f9400a82    	ldr	x2, [x20, #0x10]
101414e28: aa1303e0    	mov	x0, x19
101414e2c: 97da262c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414e30: aa1603e0    	mov	x0, x22
101414e34: 52800301    	mov	w1, #0x18               ; =24
101414e38: 52800102    	mov	w2, #0x8                ; =8
101414e3c: 97da2628    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414e40: f9405be8    	ldr	x8, [sp, #0xb0]
101414e44: 91002113    	add	x19, x8, #0x8
101414e48: 14000004    	b	0x101414e58 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x51f0>
101414e4c: 91006273    	add	x19, x19, #0x18
101414e50: f10006b5    	subs	x21, x21, #0x1
101414e54: 540000e0    	b.eq	0x101414e70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5208>
101414e58: f85f8261    	ldur	x1, [x19, #-0x8]
101414e5c: b4ffff81    	cbz	x1, 0x101414e4c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x51e4>
101414e60: f9400260    	ldr	x0, [x19]
101414e64: 52800022    	mov	w2, #0x1                ; =1
101414e68: 97da261d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414e6c: 17fffff8    	b	0x101414e4c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x51e4>
101414e70: f9005fff    	str	xzr, [sp, #0xb8]
101414e74: d2800013    	mov	x19, #0x0               ; =0
101414e78: f94967e8    	ldr	x8, [sp, #0x12c8]
101414e7c: 52800109    	mov	w9, #0x8                ; =8
101414e80: f90053e9    	str	x9, [sp, #0xa0]
101414e84: b40000c8    	cbz	x8, 0x101414e9c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5234>
101414e88: 8b080508    	add	x8, x8, x8, lsl #1
101414e8c: d37df101    	lsl	x1, x8, #3
101414e90: f9405be0    	ldr	x0, [sp, #0xb0]
101414e94: 52800102    	mov	w2, #0x8                ; =8
101414e98: 97da2611    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414e9c: f94037f7    	ldr	x23, [sp, #0x68]
101414ea0: f9405fe8    	ldr	x8, [sp, #0xb8]
101414ea4: f94053f4    	ldr	x20, [sp, #0xa0]
101414ea8: 17fff4cb    	b	0x1014121d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x256c>
101414eac: f107e27f    	cmp	x19, #0x1f8
101414eb0: 5400dc22    	b.hs	0x101416a34 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6dcc>
101414eb4: aa1403e0    	mov	x0, x20
101414eb8: aa1503e1    	mov	x1, x21
101414ebc: 94011251    	bl	0x101459800 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xc378>
101414ec0: f9405ff9    	ldr	x25, [sp, #0xb8]
101414ec4: 17ffee3f    	b	0x1014107c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xb58>
101414ec8: f85ffeb3    	ldr	x19, [x21, #-0x1]!
101414ecc: f94006b4    	ldr	x20, [x21, #0x8]
101414ed0: f9400288    	ldr	x8, [x20]
101414ed4: b4000068    	cbz	x8, 0x101414ee0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5278>
101414ed8: aa1303e0    	mov	x0, x19
101414edc: d63f0100    	blr	x8
101414ee0: f9400681    	ldr	x1, [x20, #0x8]
101414ee4: b4000081    	cbz	x1, 0x101414ef4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x528c>
101414ee8: f9400a82    	ldr	x2, [x20, #0x10]
101414eec: aa1303e0    	mov	x0, x19
101414ef0: 97da25fb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414ef4: 52800114    	mov	w20, #0x8               ; =8
101414ef8: aa1503e0    	mov	x0, x21
101414efc: 52800301    	mov	w1, #0x18               ; =24
101414f00: 52800102    	mov	w2, #0x8                ; =8
101414f04: 97da25f6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101414f08: d2800013    	mov	x19, #0x0               ; =0
101414f0c: d2800015    	mov	x21, #0x0               ; =0
101414f10: 17fffd6f    	b	0x1014144cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4864>
101414f14: f9450fe8    	ldr	x8, [sp, #0xa18]
101414f18: 52800309    	mov	w9, #0x18               ; =24
101414f1c: 9b092308    	madd	x8, x24, x9, x8
101414f20: a9004d14    	stp	x20, x19, [x8]
101414f24: f9000914    	str	x20, [x8, #0x10]
101414f28: 91000708    	add	x8, x24, #0x1
101414f2c: f90513e8    	str	x8, [sp, #0xa20]
101414f30: 3966c7e8    	ldrb	w8, [sp, #0x9b1]
101414f34: 370051a8    	tbnz	w8, #0x0, 0x101415968 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5d00>
101414f38: f944c3f3    	ldr	x19, [sp, #0x980]
101414f3c: 910403e0    	add	x0, sp, #0x100
101414f40: 9125c3e8    	add	x8, sp, #0x970
101414f44: 91004101    	add	x1, x8, #0x10
101414f48: 94015fe5    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101414f4c: b94103e8    	ldr	w8, [sp, #0x100]
101414f50: 7100051f    	cmp	w8, #0x1
101414f54: 540000e1    	b.ne	0x101414f70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5308>
101414f58: f9408be8    	ldr	x8, [sp, #0x110]
101414f5c: f944bbe9    	ldr	x9, [sp, #0x970]
101414f60: cb090101    	sub	x1, x8, x9
101414f64: 8b090260    	add	x0, x19, x9
101414f68: f904bbe8    	str	x8, [sp, #0x970]
101414f6c: 1400000d    	b	0x101414fa0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5338>
101414f70: 3966c7e8    	ldrb	w8, [sp, #0x9b1]
101414f74: 37004fa8    	tbnz	w8, #0x0, 0x101415968 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5d00>
101414f78: 3926c7f6    	strb	w22, [sp, #0x9b1]
101414f7c: 3966c3ea    	ldrb	w10, [sp, #0x9b0]
101414f80: f944bbe8    	ldr	x8, [sp, #0x970]
101414f84: f944bfe9    	ldr	x9, [sp, #0x978]
101414f88: 3700006a    	tbnz	w10, #0x0, 0x101414f94 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x532c>
101414f8c: eb08013f    	cmp	x9, x8
101414f90: 54004ec0    	b.eq	0x101415968 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5d00>
101414f94: f944c3ea    	ldr	x10, [sp, #0x980]
101414f98: cb080121    	sub	x1, x9, x8
101414f9c: 8b080140    	add	x0, x10, x8
101414fa0: b4000201    	cbz	x1, 0x101414fe0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5378>
101414fa4: d1000428    	sub	x8, x1, #0x1
101414fa8: 38686809    	ldrb	w9, [x0, x8]
101414fac: 7100293f    	cmp	w9, #0xa
101414fb0: 54000181    	b.ne	0x101414fe0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5378>
101414fb4: d1000829    	sub	x9, x1, #0x2
101414fb8: b40000c8    	cbz	x8, 0x101414fd0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5368>
101414fbc: 3869680a    	ldrb	w10, [x0, x9]
101414fc0: 12001d4a    	and	w10, w10, #0xff
101414fc4: 7100355f    	cmp	w10, #0xd
101414fc8: 9a9f000a    	csel	x10, x0, xzr, eq
101414fcc: 14000002    	b	0x101414fd4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x536c>
101414fd0: d280000a    	mov	x10, #0x0               ; =0
101414fd4: f100015f    	cmp	x10, #0x0
101414fd8: 9a890101    	csel	x1, x8, x9, eq
101414fdc: 9a8a0000    	csel	x0, x0, x10, eq
101414fe0: b4004c40    	cbz	x0, 0x101415968 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5d00>
101414fe4: 97d4de60    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
101414fe8: b4001c61    	cbz	x1, 0x101415374 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x570c>
101414fec: aa0003f3    	mov	x19, x0
101414ff0: 39400008    	ldrb	w8, [x0]
101414ff4: 12001d09    	and	w9, w8, #0xff
101414ff8: 71008d3f    	cmp	w9, #0x23
101414ffc: 54001bc0    	b.eq	0x101415374 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x570c>
101415000: aa0103f4    	mov	x20, x1
101415004: f100043f    	cmp	x1, #0x1
101415008: 54000300    	b.eq	0x101415068 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5400>
10141500c: 927ffa89    	and	x9, x20, #0xfffffffffffffffe
101415010: f100093f    	cmp	x9, #0x2
101415014: 540001a0    	b.eq	0x101415048 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x53e0>
101415018: 79400269    	ldrh	w9, [x19]
10141501c: 5ac00929    	rev	w9, w9
101415020: 528b6b6a    	mov	w10, #0x5b5b            ; =23387
101415024: 4b494149    	sub	w9, w10, w9, lsr #16
101415028: 35000109    	cbnz	w9, 0x101415048 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x53e0>
10141502c: 91000a60    	add	x0, x19, #0x2
101415030: d1001281    	sub	x1, x20, #0x4
101415034: 78616809    	ldrh	w9, [x0, x1]
101415038: 5ac00929    	rev	w9, w9
10141503c: 528babaa    	mov	w10, #0x5d5d            ; =23901
101415040: 6b49415f    	cmp	w10, w9, lsr #16
101415044: 54001ba0    	b.eq	0x1014153b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5750>
101415048: 12001d08    	and	w8, w8, #0xff
10141504c: 71016d1f    	cmp	w8, #0x5b
101415050: 540000c1    	b.ne	0x101415068 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5400>
101415054: 91000660    	add	x0, x19, #0x1
101415058: d1000a81    	sub	x1, x20, #0x2
10141505c: 38616808    	ldrb	w8, [x0, x1]
101415060: 7101751f    	cmp	w8, #0x5d
101415064: 54001aa0    	b.eq	0x1014153b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5750>
101415068: a91053f3    	stp	x19, x20, [sp, #0x100]
10141506c: a91153ff    	stp	xzr, x20, [sp, #0x110]
101415070: 3904a3f6    	strb	w22, [sp, #0x128]
101415074: fd0093e8    	str	d8, [sp, #0x120]
101415078: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10141507c: 91094000    	add	x0, x0, #0x250
101415080: 910403e1    	add	x1, sp, #0x100
101415084: 94015f96    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101415088: b95253e8    	ldr	w8, [sp, #0x1250]
10141508c: 36001748    	tbz	w8, #0x0, 0x101415374 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x570c>
101415090: f9492fe1    	ldr	x1, [sp, #0x1258]
101415094: f94933f9    	ldr	x25, [sp, #0x1260]
101415098: cb190298    	sub	x24, x20, x25
10141509c: aa1303e0    	mov	x0, x19
1014150a0: 97d4de31    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
1014150a4: aa0003f7    	mov	x23, x0
1014150a8: aa0103f4    	mov	x20, x1
1014150ac: 8b190260    	add	x0, x19, x25
1014150b0: aa1803e1    	mov	x1, x24
1014150b4: 97d4de2c    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
1014150b8: aa0003f3    	mov	x19, x0
1014150bc: aa0103e2    	mov	x2, x1
1014150c0: f1001b7f    	cmp	x27, #0x6
1014150c4: 5400052d    	b.le	0x101415168 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5500>
1014150c8: f100277f    	cmp	x27, #0x9
1014150cc: 540009c0    	b.eq	0x101415204 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x559c>
1014150d0: f100237f    	cmp	x27, #0x8
1014150d4: 54000f00    	b.eq	0x1014152b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x564c>
1014150d8: f1001f7f    	cmp	x27, #0x7
1014150dc: 54fff2a1    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
1014150e0: b9400348    	ldr	w8, [x26]
1014150e4: b8403349    	ldur	w9, [x26, #0x3]
1014150e8: b94093ea    	ldr	w10, [sp, #0x90]
1014150ec: 6b0a011f    	cmp	w8, w10
1014150f0: 528c2d68    	mov	w8, #0x616b             ; =24939
1014150f4: 72acace8    	movk	w8, #0x6567, lsl #16
1014150f8: 7a480120    	ccmp	w9, w8, #0x0, eq
1014150fc: 54fff1a1    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
101415100: f100129f    	cmp	x20, #0x4
101415104: 54fff161    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
101415108: b94002e8    	ldr	w8, [x23]
10141510c: 528c2dc9    	mov	w9, #0x616e             ; =24942
101415110: 72acada9    	movk	w9, #0x656d, lsl #16
101415114: 6b09011f    	cmp	w8, w9
101415118: 54fff0c1    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
10141511c: 910403e0    	add	x0, sp, #0x100
101415120: aa1303e1    	mov	x1, x19
101415124: 97ffeb62    	bl	0x10140feac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x244>
101415128: 3dc043e0    	ldr	q0, [sp, #0x100]
10141512c: 3d8497e0    	str	q0, [sp, #0x1250]
101415130: f9408be8    	ldr	x8, [sp, #0x110]
101415134: f90933e8    	str	x8, [sp, #0x1260]
101415138: f94523e1    	ldr	x1, [sp, #0xa40]
10141513c: f240f83f    	tst	x1, #0x7fffffffffffffff
101415140: 54000080    	b.eq	0x101415150 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x54e8>
101415144: f94527e0    	ldr	x0, [sp, #0xa48]
101415148: 52800022    	mov	w2, #0x1                ; =1
10141514c: 97da2564    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101415150: 3dc497e0    	ldr	q0, [sp, #0x1250]
101415154: 912783e9    	add	x9, sp, #0x9e0
101415158: 3c860120    	stur	q0, [x9, #0x60]
10141515c: f94933e8    	ldr	x8, [sp, #0x1260]
101415160: f8070128    	stur	x8, [x9, #0x70]
101415164: 17ffff73    	b	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
101415168: f1000f7f    	cmp	x27, #0x3
10141516c: 54000c20    	b.eq	0x1014152f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5688>
101415170: f100177f    	cmp	x27, #0x5
101415174: 54ffede1    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
101415178: b9400348    	ldr	w8, [x26]
10141517c: 39401349    	ldrb	w9, [x26, #0x4]
101415180: 528cac4a    	mov	w10, #0x6562            ; =25954
101415184: 72ac6dca    	movk	w10, #0x636e, lsl #16
101415188: 6b0a011f    	cmp	w8, w10
10141518c: 52800d08    	mov	w8, #0x68               ; =104
101415190: 7a480120    	ccmp	w9, w8, #0x0, eq
101415194: 54ffece1    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
101415198: f100129f    	cmp	x20, #0x4
10141519c: 54ffeca1    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
1014151a0: b94002e8    	ldr	w8, [x23]
1014151a4: 528c2dc9    	mov	w9, #0x616e             ; =24942
1014151a8: 72acada9    	movk	w9, #0x656d, lsl #16
1014151ac: 6b09011f    	cmp	w8, w9
1014151b0: 54ffec01    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
1014151b4: 910403e0    	add	x0, sp, #0x100
1014151b8: aa1303e1    	mov	x1, x19
1014151bc: 97ffeb3c    	bl	0x10140feac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x244>
1014151c0: f94507f3    	ldr	x19, [sp, #0xa08]
1014151c4: f944ffe8    	ldr	x8, [sp, #0x9f8]
1014151c8: eb08027f    	cmp	x19, x8
1014151cc: 54000081    	b.ne	0x1014151dc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5574>
1014151d0: 912783e8    	add	x8, sp, #0x9e0
1014151d4: 91006100    	add	x0, x8, #0x18
1014151d8: 941ab666    	bl	0x101ac2b70 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hb575521872840d8cE>
1014151dc: f94503e8    	ldr	x8, [sp, #0xa00]
1014151e0: 52800309    	mov	w9, #0x18               ; =24
1014151e4: 9b092268    	madd	x8, x19, x9, x8
1014151e8: 3dc043e0    	ldr	q0, [sp, #0x100]
1014151ec: 3d800100    	str	q0, [x8]
1014151f0: f9408be9    	ldr	x9, [sp, #0x110]
1014151f4: f9000909    	str	x9, [x8, #0x10]
1014151f8: 91000668    	add	x8, x19, #0x1
1014151fc: f90507e8    	str	x8, [sp, #0xa08]
101415200: 17ffff4c    	b	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
101415204: f9400348    	ldr	x8, [x26]
101415208: 39402349    	ldrb	w9, [x26, #0x8]
10141520c: d28deeea    	mov	x10, #0x6f77            ; =28535
101415210: f2ad6e4a    	movk	x10, #0x6b72, lsl #16
101415214: f2ce0e6a    	movk	x10, #0x7073, lsl #32
101415218: f2ec6c2a    	movk	x10, #0x6361, lsl #48
10141521c: eb0a011f    	cmp	x8, x10
101415220: 52800ca8    	mov	w8, #0x65               ; =101
101415224: 7a480120    	ccmp	w9, w8, #0x0, eq
101415228: 54ffe841    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
10141522c: f1001e9f    	cmp	x20, #0x7
101415230: 54ffe801    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
101415234: b94002e8    	ldr	w8, [x23]
101415238: b84032e9    	ldur	w9, [x23, #0x3]
10141523c: 528cadaa    	mov	w10, #0x656d            ; =25965
101415240: 72ac4daa    	movk	w10, #0x626d, lsl #16
101415244: 6b0a011f    	cmp	w8, w10
101415248: 528cac48    	mov	w8, #0x6562             ; =25954
10141524c: 72ae6e48    	movk	w8, #0x7372, lsl #16
101415250: 7a480120    	ccmp	w9, w8, #0x0, eq
101415254: 54ffe6e1    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
101415258: b4001682    	cbz	x2, 0x101415528 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x58c0>
10141525c: 38401668    	ldrb	w8, [x19], #0x1
101415260: 71016d1f    	cmp	w8, #0x5b
101415264: 54001621    	b.ne	0x101415528 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x58c0>
101415268: d1000454    	sub	x20, x2, #0x1
10141526c: a91053f3    	stp	x19, x20, [sp, #0x100]
101415270: a91153ff    	stp	xzr, x20, [sp, #0x110]
101415274: 3904a3f6    	strb	w22, [sp, #0x128]
101415278: fd0093e9    	str	d9, [sp, #0x120]
10141527c: 910303e0    	add	x0, sp, #0xc0
101415280: 910403e1    	add	x1, sp, #0x100
101415284: 94015f16    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
101415288: b940c3e8    	ldr	w8, [sp, #0xc0]
10141528c: 7100051f    	cmp	w8, #0x1
101415290: 540014c1    	b.ne	0x101415528 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x58c0>
101415294: f94067e3    	ldr	x3, [sp, #0xc8]
101415298: b4000c83    	cbz	x3, 0x101415428 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x57c0>
10141529c: eb14007f    	cmp	x3, x20
1014152a0: 54000c22    	b.hs	0x101415424 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x57bc>
1014152a4: 38e36a68    	ldrsb	w8, [x19, x3]
1014152a8: 3101011f    	cmn	w8, #0x40
1014152ac: 54000bea    	b.ge	0x101415428 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x57c0>
1014152b0: 14000661    	b	0x101416c34 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6fcc>
1014152b4: f9400348    	ldr	x8, [x26]
1014152b8: d28cacc9    	mov	x9, #0x6566             ; =25958
1014152bc: f2ae8c29    	movk	x9, #0x7461, lsl #16
1014152c0: f2ce4ea9    	movk	x9, #0x7275, lsl #32
1014152c4: f2ee6ca9    	movk	x9, #0x7365, lsl #48
1014152c8: eb09011f    	cmp	x8, x9
1014152cc: 54ffe321    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
1014152d0: b40005b4    	cbz	x20, 0x101415384 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x571c>
1014152d4: 97da2507    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014152d8: aa1403e0    	mov	x0, x20
1014152dc: 52800021    	mov	w1, #0x1                ; =1
1014152e0: 97da24fe    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014152e4: aa0003f3    	mov	x19, x0
1014152e8: b5000500    	cbnz	x0, 0x101415388 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5720>
1014152ec: 14000634    	b	0x101416bbc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6f54>
1014152f0: 79400348    	ldrh	w8, [x26]
1014152f4: 39400b49    	ldrb	w9, [x26, #0x2]
1014152f8: 528d2c4a    	mov	w10, #0x6962            ; =26978
1014152fc: 6b0a011f    	cmp	w8, w10
101415300: 52800dc8    	mov	w8, #0x6e               ; =110
101415304: 7a480120    	ccmp	w9, w8, #0x0, eq
101415308: 54ffe141    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
10141530c: f100129f    	cmp	x20, #0x4
101415310: 54ffe101    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
101415314: b94002e8    	ldr	w8, [x23]
101415318: 528c2dc9    	mov	w9, #0x616e             ; =24942
10141531c: 72acada9    	movk	w9, #0x656d, lsl #16
101415320: 6b09011f    	cmp	w8, w9
101415324: 54ffe061    	b.ne	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
101415328: 910403e0    	add	x0, sp, #0x100
10141532c: aa1303e1    	mov	x1, x19
101415330: 97ffeadf    	bl	0x10140feac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x244>
101415334: f944fbf3    	ldr	x19, [sp, #0x9f0]
101415338: f944f3e8    	ldr	x8, [sp, #0x9e0]
10141533c: eb08027f    	cmp	x19, x8
101415340: 54000061    	b.ne	0x10141534c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x56e4>
101415344: 912783e0    	add	x0, sp, #0x9e0
101415348: 941ab60a    	bl	0x101ac2b70 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hb575521872840d8cE>
10141534c: f944f7e8    	ldr	x8, [sp, #0x9e8]
101415350: 52800309    	mov	w9, #0x18               ; =24
101415354: 9b092268    	madd	x8, x19, x9, x8
101415358: 3dc043e0    	ldr	q0, [sp, #0x100]
10141535c: 3d800100    	str	q0, [x8]
101415360: f9408be9    	ldr	x9, [sp, #0x110]
101415364: f9000909    	str	x9, [x8, #0x10]
101415368: 91000668    	add	x8, x19, #0x1
10141536c: f904fbe8    	str	x8, [sp, #0x9f0]
101415370: 17fffef0    	b	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
101415374: aa1a03f3    	mov	x19, x26
101415378: 3966c7e8    	ldrb	w8, [sp, #0x9b1]
10141537c: 3607dde8    	tbz	w8, #0x0, 0x101414f38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52d0>
101415380: 1400017b    	b	0x10141596c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5d04>
101415384: 52800033    	mov	w19, #0x1               ; =1
101415388: aa1303e0    	mov	x0, x19
10141538c: aa1703e1    	mov	x1, x23
101415390: aa1403e2    	mov	x2, x20
101415394: 941ad225    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101415398: f94513f8    	ldr	x24, [sp, #0xa20]
10141539c: f9450be8    	ldr	x8, [sp, #0xa10]
1014153a0: eb08031f    	cmp	x24, x8
1014153a4: 54ffdb81    	b.ne	0x101414f14 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52ac>
1014153a8: 912783e8    	add	x8, sp, #0x9e0
1014153ac: 9100c100    	add	x0, x8, #0x30
1014153b0: 941ab5f0    	bl	0x101ac2b70 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hb575521872840d8cE>
1014153b4: 17fffed8    	b	0x101414f14 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52ac>
1014153b8: 97d4dd6b    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
1014153bc: aa0003f4    	mov	x20, x0
1014153c0: aa0103fb    	mov	x27, x1
1014153c4: b4000101    	cbz	x1, 0x1014153e4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x577c>
1014153c8: 97da24ca    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014153cc: aa1b03e0    	mov	x0, x27
1014153d0: 52800021    	mov	w1, #0x1                ; =1
1014153d4: 97da24c1    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014153d8: aa0003f3    	mov	x19, x0
1014153dc: b5000060    	cbnz	x0, 0x1014153e8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5780>
1014153e0: 1400060d    	b	0x101416c14 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6fac>
1014153e4: 52800033    	mov	w19, #0x1               ; =1
1014153e8: aa1303e0    	mov	x0, x19
1014153ec: aa1403e1    	mov	x1, x20
1014153f0: aa1b03e2    	mov	x2, x27
1014153f4: 941ad20d    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014153f8: f9404fe8    	ldr	x8, [sp, #0x98]
1014153fc: b40000a8    	cbz	x8, 0x101415410 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x57a8>
101415400: aa1a03e0    	mov	x0, x26
101415404: f9404fe1    	ldr	x1, [sp, #0x98]
101415408: 52800022    	mov	w2, #0x1                ; =1
10141540c: 97da24b4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101415410: f9004ffb    	str	x27, [sp, #0x98]
101415414: 3966c7e8    	ldrb	w8, [sp, #0x9b1]
101415418: aa1303fa    	mov	x26, x19
10141541c: 3607d8e8    	tbz	w8, #0x0, 0x101414f38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52d0>
101415420: 14000153    	b	0x10141596c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5d04>
101415424: 5400c081    	b.ne	0x101416c34 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6fcc>
101415428: f9092bff    	str	xzr, [sp, #0x1250]
10141542c: f9092fe3    	str	x3, [sp, #0x1258]
101415430: f90933f3    	str	x19, [sp, #0x1260]
101415434: f90937e3    	str	x3, [sp, #0x1268]
101415438: f9093bff    	str	xzr, [sp, #0x1270]
10141543c: f9093fe3    	str	x3, [sp, #0x1278]
101415440: fd0943ea    	str	d10, [sp, #0x1280]
101415444: 912783e8    	add	x8, sp, #0x9e0
101415448: 52800029    	mov	w9, #0x1                ; =1
10141544c: 3922a109    	strb	w9, [x8, #0x8a8]
101415450: 52800036    	mov	w22, #0x1               ; =1
101415454: 792523e9    	strh	w9, [sp, #0x1290]
101415458: 14000007    	b	0x101415474 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x580c>
10141545c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101415460: eb08027f    	cmp	x19, x8
101415464: 54000841    	b.ne	0x10141556c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5904>
101415468: 912783e8    	add	x8, sp, #0x9e0
10141546c: 3962c508    	ldrb	w8, [x8, #0x8b1]
101415470: 370005c8    	tbnz	w8, #0x0, 0x101415528 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x58c0>
101415474: f94933f3    	ldr	x19, [sp, #0x1260]
101415478: 910403e0    	add	x0, sp, #0x100
10141547c: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
101415480: 91094108    	add	x8, x8, #0x250
101415484: 91004101    	add	x1, x8, #0x10
101415488: 94015e95    	bl	0x10146cedc <__ZN80_$LT$otty_autocomplete..db..RecoveryScratch$u20$as$u20$core..ops..drop..Drop$GT$4drop17h896735b0efcbd1f7E+0x6f0>
10141548c: b94103e8    	ldr	w8, [sp, #0x100]
101415490: 7100051f    	cmp	w8, #0x1
101415494: 540000e1    	b.ne	0x1014154b0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5848>
101415498: a950a7e8    	ldp	x8, x9, [sp, #0x108]
10141549c: f9492bea    	ldr	x10, [sp, #0x1250]
1014154a0: cb0a0101    	sub	x1, x8, x10
1014154a4: 8b0a0260    	add	x0, x19, x10
1014154a8: f9092be9    	str	x9, [sp, #0x1250]
1014154ac: 1400000f    	b	0x1014154e8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5880>
1014154b0: 912783e8    	add	x8, sp, #0x9e0
1014154b4: 3962c508    	ldrb	w8, [x8, #0x8b1]
1014154b8: 37000388    	tbnz	w8, #0x0, 0x101415528 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x58c0>
1014154bc: 912783e8    	add	x8, sp, #0x9e0
1014154c0: 3922c516    	strb	w22, [x8, #0x8b1]
1014154c4: 3962c10a    	ldrb	w10, [x8, #0x8b0]
1014154c8: f9492be8    	ldr	x8, [sp, #0x1250]
1014154cc: f9492fe9    	ldr	x9, [sp, #0x1258]
1014154d0: 3700006a    	tbnz	w10, #0x0, 0x1014154dc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5874>
1014154d4: eb08013f    	cmp	x9, x8
1014154d8: 54000280    	b.eq	0x101415528 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x58c0>
1014154dc: f94933ea    	ldr	x10, [sp, #0x1260]
1014154e0: cb080121    	sub	x1, x9, x8
1014154e4: 8b080140    	add	x0, x10, x8
1014154e8: 97d4dd1f    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
1014154ec: aa0003e2    	mov	x2, x0
1014154f0: aa0103e3    	mov	x3, x1
1014154f4: 910403e0    	add	x0, sp, #0x100
1014154f8: aa0203e1    	mov	x1, x2
1014154fc: aa0303e2    	mov	x2, x3
101415500: 97ffea6b    	bl	0x10140feac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x244>
101415504: a95053f3    	ldp	x19, x20, [sp, #0x100]
101415508: f9408bf8    	ldr	x24, [sp, #0x110]
10141550c: b5fffa98    	cbnz	x24, 0x10141545c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x57f4>
101415510: b4fffad3    	cbz	x19, 0x101415468 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5800>
101415514: aa1403e0    	mov	x0, x20
101415518: aa1303e1    	mov	x1, x19
10141551c: 52800022    	mov	w2, #0x1                ; =1
101415520: 97da246f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101415524: 17ffffd1    	b	0x101415468 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5800>
101415528: d2800014    	mov	x20, #0x0               ; =0
10141552c: f90033ff    	str	xzr, [sp, #0x60]
101415530: 52800118    	mov	w24, #0x8               ; =8
101415534: f9451bf3    	ldr	x19, [sp, #0xa30]
101415538: f9451ff9    	ldr	x25, [sp, #0xa38]
10141553c: b4000519    	cbz	x25, 0x1014155dc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5974>
101415540: 91002275    	add	x21, x19, #0x8
101415544: 14000004    	b	0x101415554 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x58ec>
101415548: 910062b5    	add	x21, x21, #0x18
10141554c: f1000739    	subs	x25, x25, #0x1
101415550: 54000460    	b.eq	0x1014155dc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5974>
101415554: f85f82a1    	ldur	x1, [x21, #-0x8]
101415558: b4ffff81    	cbz	x1, 0x101415548 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x58e0>
10141555c: f94002a0    	ldr	x0, [x21]
101415560: 52800022    	mov	w2, #0x1                ; =1
101415564: 97da245e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101415568: 17fffff8    	b	0x101415548 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x58e0>
10141556c: 97da2461    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101415570: 52800c00    	mov	w0, #0x60               ; =96
101415574: 52800101    	mov	w1, #0x8                ; =8
101415578: 97da2458    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10141557c: f90013e0    	str	x0, [sp, #0x20]
101415580: b400b780    	cbz	x0, 0x101416c70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7008>
101415584: f94013e9    	ldr	x9, [sp, #0x20]
101415588: a9005133    	stp	x19, x20, [x9]
10141558c: f9000938    	str	x24, [x9, #0x10]
101415590: 52800088    	mov	w8, #0x4                ; =4
101415594: a90c27e8    	stp	x8, x9, [sp, #0xc0]
101415598: f9006bf6    	str	x22, [sp, #0xd0]
10141559c: f9494be8    	ldr	x8, [sp, #0x1290]
1014155a0: f900a3e8    	str	x8, [sp, #0x140]
1014155a4: 3dc49fe0    	ldr	q0, [sp, #0x1270]
1014155a8: 3dc4a3e1    	ldr	q1, [sp, #0x1280]
1014155ac: ad0907e0    	stp	q0, q1, [sp, #0x120]
1014155b0: 3dc49be0    	ldr	q0, [sp, #0x1260]
1014155b4: 3dc497e1    	ldr	q1, [sp, #0x1250]
1014155b8: ad0803e1    	stp	q1, q0, [sp, #0x100]
1014155bc: 52800028    	mov	w8, #0x1                ; =1
1014155c0: f90033e8    	str	x8, [sp, #0x60]
1014155c4: 394507e8    	ldrb	w8, [sp, #0x141]
1014155c8: 36000228    	tbz	w8, #0x0, 0x10141560c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x59a4>
1014155cc: a94c63f4    	ldp	x20, x24, [sp, #0xc0]
1014155d0: f9451bf3    	ldr	x19, [sp, #0xa30]
1014155d4: f9451ff9    	ldr	x25, [sp, #0xa38]
1014155d8: b5fffb59    	cbnz	x25, 0x101415540 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x58d8>
1014155dc: f94517e8    	ldr	x8, [sp, #0xa28]
1014155e0: b40000c8    	cbz	x8, 0x1014155f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5990>
1014155e4: 8b080508    	add	x8, x8, x8, lsl #1
1014155e8: d37df101    	lsl	x1, x8, #3
1014155ec: aa1303e0    	mov	x0, x19
1014155f0: 52800102    	mov	w2, #0x8                ; =8
1014155f4: 97da243a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014155f8: f90517f4    	str	x20, [sp, #0xa28]
1014155fc: f9051bf8    	str	x24, [sp, #0xa30]
101415600: f94033e8    	ldr	x8, [sp, #0x60]
101415604: f9051fe8    	str	x8, [sp, #0xa38]
101415608: 17fffe4a    	b	0x101414f30 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x52c8>
10141560c: a95123e9    	ldp	x9, x8, [sp, #0x110]
101415610: a90727e8    	stp	x8, x9, [sp, #0x70]
101415614: 3944e3f5    	ldrb	w21, [sp, #0x138]
101415618: 394503e8    	ldrb	w8, [sp, #0x140]
10141561c: b90033e8    	str	w8, [sp, #0x30]
101415620: a95023e9    	ldp	x9, x8, [sp, #0x100]
101415624: f9000fe9    	str	x9, [sp, #0x18]
101415628: f90023e8    	str	x8, [sp, #0x40]
10141562c: 52800028    	mov	w8, #0x1                ; =1
101415630: f90033e8    	str	x8, [sp, #0x60]
101415634: a95253f8    	ldp	x24, x20, [sp, #0x120]
101415638: b9004bff    	str	wzr, [sp, #0x48]
10141563c: f9400ff7    	ldr	x23, [sp, #0x18]
101415640: 1400000a    	b	0x101415668 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5a00>
101415644: 52800033    	mov	w19, #0x1               ; =1
101415648: aa1303e0    	mov	x0, x19
10141564c: aa1703e1    	mov	x1, x23
101415650: aa1903e2    	mov	x2, x25
101415654: 941ad175    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101415658: b5001599    	cbnz	x25, 0x101415908 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5ca0>
10141565c: f9402bf7    	ldr	x23, [sp, #0x50]
101415660: b9405be8    	ldr	w8, [sp, #0x58]
101415664: 3707fb48    	tbnz	w8, #0x0, 0x1014155cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5964>
101415668: f9403be8    	ldr	x8, [sp, #0x70]
10141566c: eb08029f    	cmp	x20, x8
101415670: 54000aa8    	b.hi	0x1014157c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5b5c>
101415674: eb18029f    	cmp	x20, x24
101415678: 54000a63    	b.lo	0x1014157c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5b5c>
10141567c: f94043e8    	ldr	x8, [sp, #0x80]
101415680: aa1503e9    	mov	x9, x21
101415684: 38756913    	ldrb	w19, [x8, x21]
101415688: 7100153f    	cmp	w9, #0x5
10141568c: 54000483    	b.lo	0x10141571c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5ab4>
101415690: cb180282    	sub	x2, x20, x24
101415694: f9403fe8    	ldr	x8, [sp, #0x78]
101415698: 8b180108    	add	x8, x8, x24
10141569c: f1003c5f    	cmp	x2, #0xf
1014156a0: 54000188    	b.hi	0x1014156d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5a68>
1014156a4: d2800001    	mov	x1, #0x0                ; =0
1014156a8: b40001c2    	cbz	x2, 0x1014156e0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5a78>
1014156ac: 38616909    	ldrb	w9, [x8, x1]
1014156b0: 6b13013f    	cmp	w9, w19
1014156b4: 540001a0    	b.eq	0x1014156e8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5a80>
1014156b8: 91000421    	add	x1, x1, #0x1
1014156bc: eb01005f    	cmp	x2, x1
1014156c0: 54ffff61    	b.ne	0x1014156ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5a44>
1014156c4: d2800000    	mov	x0, #0x0                ; =0
1014156c8: aa0203e1    	mov	x1, x2
1014156cc: 14000008    	b	0x1014156ec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5a84>
1014156d0: aa1303e0    	mov	x0, x19
1014156d4: aa0803e1    	mov	x1, x8
1014156d8: 94103f1a    	bl	0x101825340 <__ZN4core5slice6memchr14memchr_aligned17hb4aaf9792c60d219E>
1014156dc: 14000004    	b	0x1014156ec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5a84>
1014156e0: d2800000    	mov	x0, #0x0                ; =0
1014156e4: 14000002    	b	0x1014156ec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5a84>
1014156e8: 52800020    	mov	w0, #0x1                ; =1
1014156ec: 36000880    	tbz	w0, #0x0, 0x1014157fc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5b94>
1014156f0: 8b010308    	add	x8, x24, x1
1014156f4: 91000518    	add	x24, x8, #0x1
1014156f8: eb15031f    	cmp	x24, x21
1014156fc: f9403be8    	ldr	x8, [sp, #0x70]
101415700: fa482302    	ccmp	x24, x8, #0x2, hs
101415704: 5400abe9    	b.ls	0x101416c80 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7018>
101415708: eb18029f    	cmp	x20, x24
10141570c: 54fffc22    	b.hs	0x101415690 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5a28>
101415710: 1400002d    	b	0x1014157c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5b5c>
101415714: eb18029f    	cmp	x20, x24
101415718: 54000563    	b.lo	0x1014157c4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5b5c>
10141571c: cb180282    	sub	x2, x20, x24
101415720: f9403fe8    	ldr	x8, [sp, #0x78]
101415724: 8b180108    	add	x8, x8, x24
101415728: f100405f    	cmp	x2, #0x10
10141572c: 54000182    	b.hs	0x10141575c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5af4>
101415730: d2800001    	mov	x1, #0x0                ; =0
101415734: b40001c2    	cbz	x2, 0x10141576c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5b04>
101415738: 38616909    	ldrb	w9, [x8, x1]
10141573c: 6b13013f    	cmp	w9, w19
101415740: 540001a0    	b.eq	0x101415774 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5b0c>
101415744: 91000421    	add	x1, x1, #0x1
101415748: eb01005f    	cmp	x2, x1
10141574c: 54ffff61    	b.ne	0x101415738 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5ad0>
101415750: d2800000    	mov	x0, #0x0                ; =0
101415754: aa0203e1    	mov	x1, x2
101415758: 14000008    	b	0x101415778 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5b10>
10141575c: aa1303e0    	mov	x0, x19
101415760: aa0803e1    	mov	x1, x8
101415764: 94103ef7    	bl	0x101825340 <__ZN4core5slice6memchr14memchr_aligned17hb4aaf9792c60d219E>
101415768: 14000004    	b	0x101415778 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5b10>
10141576c: d2800000    	mov	x0, #0x0                ; =0
101415770: 14000002    	b	0x101415778 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5b10>
101415774: 52800020    	mov	w0, #0x1                ; =1
101415778: 36000240    	tbz	w0, #0x0, 0x1014157c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5b58>
10141577c: 8b010308    	add	x8, x24, x1
101415780: 91000518    	add	x24, x8, #0x1
101415784: eb150319    	subs	x25, x24, x21
101415788: f9403be8    	ldr	x8, [sp, #0x70]
10141578c: fa482302    	ccmp	x24, x8, #0x2, hs
101415790: 54fffc28    	b.hi	0x101415714 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5aac>
101415794: f9403fe8    	ldr	x8, [sp, #0x78]
101415798: 8b190100    	add	x0, x8, x25
10141579c: 910403e8    	add	x8, sp, #0x100
1014157a0: 9100c101    	add	x1, x8, #0x30
1014157a4: aa1503e2    	mov	x2, x21
1014157a8: 941ad11d    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
1014157ac: 35fffb40    	cbnz	w0, 0x101415714 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5aac>
1014157b0: b9005bff    	str	wzr, [sp, #0x58]
1014157b4: f9000ff8    	str	x24, [sp, #0x18]
1014157b8: f9002bf8    	str	x24, [sp, #0x50]
1014157bc: 1400001b    	b	0x101415828 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5bc0>
1014157c0: aa1403f8    	mov	x24, x20
1014157c4: 52800029    	mov	w9, #0x1                ; =1
1014157c8: 52800028    	mov	w8, #0x1                ; =1
1014157cc: b9004be8    	str	w8, [sp, #0x48]
1014157d0: 390507e9    	strb	w9, [sp, #0x141]
1014157d4: b94033e8    	ldr	w8, [sp, #0x30]
1014157d8: 37000208    	tbnz	w8, #0x0, 0x101415818 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5bb0>
1014157dc: 52800028    	mov	w8, #0x1                ; =1
1014157e0: b9005be8    	str	w8, [sp, #0x58]
1014157e4: f9002bf7    	str	x23, [sp, #0x50]
1014157e8: f94023e8    	ldr	x8, [sp, #0x40]
1014157ec: aa0803f9    	mov	x25, x8
1014157f0: eb17011f    	cmp	x8, x23
1014157f4: 540001a1    	b.ne	0x101415828 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5bc0>
1014157f8: 17ffff75    	b	0x1014155cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5964>
1014157fc: aa1403f8    	mov	x24, x20
101415800: 52800029    	mov	w9, #0x1                ; =1
101415804: 52800028    	mov	w8, #0x1                ; =1
101415808: b9004be8    	str	w8, [sp, #0x48]
10141580c: 390507e9    	strb	w9, [sp, #0x141]
101415810: b94033e8    	ldr	w8, [sp, #0x30]
101415814: 3607fe48    	tbz	w8, #0x0, 0x1014157dc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5b74>
101415818: 52800028    	mov	w8, #0x1                ; =1
10141581c: b9005be8    	str	w8, [sp, #0x58]
101415820: f9002bf7    	str	x23, [sp, #0x50]
101415824: f94023f9    	ldr	x25, [sp, #0x40]
101415828: cb170321    	sub	x1, x25, x23
10141582c: f9403fe8    	ldr	x8, [sp, #0x78]
101415830: 8b170100    	add	x0, x8, x23
101415834: 97d4dc4c    	bl	0x10094c964 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3993c>
101415838: aa0003f7    	mov	x23, x0
10141583c: aa0103f9    	mov	x25, x1
101415840: f100083f    	cmp	x1, #0x2
101415844: 54000163    	b.lo	0x101415870 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c08>
101415848: 394002e8    	ldrb	w8, [x23]
10141584c: 71009d1f    	cmp	w8, #0x27
101415850: 54000140    	b.eq	0x101415878 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c10>
101415854: 7100891f    	cmp	w8, #0x22
101415858: 54000341    	b.ne	0x1014158c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c58>
10141585c: 8b1902e8    	add	x8, x23, x25
101415860: 385ff108    	ldurb	w8, [x8, #-0x1]
101415864: 7100891f    	cmp	w8, #0x22
101415868: 54000100    	b.eq	0x101415888 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c20>
10141586c: 14000015    	b	0x1014158c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c58>
101415870: b5000299    	cbnz	x25, 0x1014158c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c58>
101415874: 17ffff74    	b	0x101415644 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x59dc>
101415878: 8b1902e8    	add	x8, x23, x25
10141587c: 385ff108    	ldurb	w8, [x8, #-0x1]
101415880: 71009d1f    	cmp	w8, #0x27
101415884: 540001e1    	b.ne	0x1014158c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c58>
101415888: aa1703e9    	mov	x9, x23
10141588c: 38c01d28    	ldrsb	w8, [x9, #0x1]!
101415890: f90017e9    	str	x9, [sp, #0x28]
101415894: 3101011f    	cmn	w8, #0x40
101415898: 54009dcb    	b.lt	0x101416c50 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6fe8>
10141589c: f1000b39    	subs	x25, x25, #0x2
1014158a0: 54000280    	b.eq	0x1014158f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c88>
1014158a4: 97da2393    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014158a8: aa1903e0    	mov	x0, x25
1014158ac: 52800021    	mov	w1, #0x1                ; =1
1014158b0: 97da238a    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014158b4: aa0003f3    	mov	x19, x0
1014158b8: b50001e0    	cbnz	x0, 0x1014158f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c8c>
1014158bc: 140004da    	b	0x101416c24 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6fbc>
1014158c0: 97da238c    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014158c4: aa1903e0    	mov	x0, x25
1014158c8: 52800021    	mov	w1, #0x1                ; =1
1014158cc: 97da2383    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014158d0: aa0003f3    	mov	x19, x0
1014158d4: b4009a80    	cbz	x0, 0x101416c24 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6fbc>
1014158d8: aa1303e0    	mov	x0, x19
1014158dc: aa1703e1    	mov	x1, x23
1014158e0: aa1903e2    	mov	x2, x25
1014158e4: 941ad0d1    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014158e8: b4ffebb9    	cbz	x25, 0x10141565c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x59f4>
1014158ec: 14000007    	b	0x101415908 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5ca0>
1014158f0: 52800033    	mov	w19, #0x1               ; =1
1014158f4: aa1303e0    	mov	x0, x19
1014158f8: f94017e1    	ldr	x1, [sp, #0x28]
1014158fc: aa1903e2    	mov	x2, x25
101415900: 941ad0ca    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101415904: b4ffead9    	cbz	x25, 0x10141565c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x59f4>
101415908: f94063e8    	ldr	x8, [sp, #0xc0]
10141590c: f94033e9    	ldr	x9, [sp, #0x60]
101415910: eb08013f    	cmp	x9, x8
101415914: 54000121    	b.ne	0x101415938 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5cd0>
101415918: 910303e0    	add	x0, sp, #0xc0
10141591c: f94033e1    	ldr	x1, [sp, #0x60]
101415920: 52800022    	mov	w2, #0x1                ; =1
101415924: 52800103    	mov	w3, #0x8                ; =8
101415928: 52800304    	mov	w4, #0x18               ; =24
10141592c: 94184bc9    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101415930: f94067e8    	ldr	x8, [sp, #0xc8]
101415934: f90013e8    	str	x8, [sp, #0x20]
101415938: 52800308    	mov	w8, #0x18               ; =24
10141593c: f94033e9    	ldr	x9, [sp, #0x60]
101415940: f94013ea    	ldr	x10, [sp, #0x20]
101415944: 9b082928    	madd	x8, x9, x8, x10
101415948: a9004d19    	stp	x25, x19, [x8]
10141594c: f9000919    	str	x25, [x8, #0x10]
101415950: 91000529    	add	x9, x9, #0x1
101415954: f90033e9    	str	x9, [sp, #0x60]
101415958: f9006be9    	str	x9, [sp, #0xd0]
10141595c: b9404be8    	ldr	w8, [sp, #0x48]
101415960: 3607e6c8    	tbz	w8, #0x0, 0x101415638 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x59d0>
101415964: 17ffff1a    	b	0x1014155cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5964>
101415968: aa1a03f3    	mov	x19, x26
10141596c: 3dc28be0    	ldr	q0, [sp, #0xa20]
101415970: 3dc28fe1    	ldr	q1, [sp, #0xa30]
101415974: ad0a07e0    	stp	q0, q1, [sp, #0x140]
101415978: 3dc293e0    	ldr	q0, [sp, #0xa40]
10141597c: 3d805be0    	str	q0, [sp, #0x160]
101415980: f9452be8    	ldr	x8, [sp, #0xa50]
101415984: f900bbe8    	str	x8, [sp, #0x170]
101415988: 3dc27be0    	ldr	q0, [sp, #0x9e0]
10141598c: 3dc27fe1    	ldr	q1, [sp, #0x9f0]
101415990: ad0807e0    	stp	q0, q1, [sp, #0x100]
101415994: 3dc283e0    	ldr	q0, [sp, #0xa00]
101415998: 3dc287e1    	ldr	q1, [sp, #0xa10]
10141599c: ad0907e0    	stp	q0, q1, [sp, #0x120]
1014159a0: f9404fe8    	ldr	x8, [sp, #0x98]
1014159a4: b40000a8    	cbz	x8, 0x1014159b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5d50>
1014159a8: aa1303e0    	mov	x0, x19
1014159ac: f9404fe1    	ldr	x1, [sp, #0x98]
1014159b0: 52800022    	mov	w2, #0x1                ; =1
1014159b4: 97da234a    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014159b8: f9405fe8    	ldr	x8, [sp, #0xb8]
1014159bc: b4ff70c8    	cbz	x8, 0x1014147d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4b6c>
1014159c0: f94047e0    	ldr	x0, [sp, #0x88]
1014159c4: f9405fe1    	ldr	x1, [sp, #0xb8]
1014159c8: 52800022    	mov	w2, #0x1                ; =1
1014159cc: 97da2344    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014159d0: 17fffb81    	b	0x1014147d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4b6c>
1014159d4: f90083ff    	str	xzr, [sp, #0x100]
1014159d8: f90297ff    	str	xzr, [sp, #0x528]
1014159dc: f904abf6    	str	x22, [sp, #0x950]
1014159e0: 392563e8    	strb	w8, [sp, #0x958]
1014159e4: 912783e0    	add	x0, sp, #0x9e0
1014159e8: 910403e1    	add	x1, sp, #0x100
1014159ec: 97ffdffe    	bl	0x10140d9e4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2698>
1014159f0: f944f3f6    	ldr	x22, [sp, #0x9e0]
1014159f4: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1014159f8: eb0802df    	cmp	x22, x8
1014159fc: 540002a1    	b.ne	0x101415a50 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5de8>
101415a00: 52800108    	mov	w8, #0x8                ; =8
101415a04: f90973ff    	str	xzr, [sp, #0x12e0]
101415a08: f90977e8    	str	x8, [sp, #0x12e8]
101415a0c: f9097bff    	str	xzr, [sp, #0x12f0]
101415a10: 910403e0    	add	x0, sp, #0x100
101415a14: 94010160    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
101415a18: d2800019    	mov	x25, #0x0               ; =0
101415a1c: 52800108    	mov	w8, #0x8                ; =8
101415a20: f90047e8    	str	x8, [sp, #0x88]
101415a24: 14000045    	b	0x101415b38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5ed0>
101415a28: 940ea7d8    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101415a2c: f9000661    	str	x1, [x19, #0x8]
101415a30: 52800028    	mov	w8, #0x1                ; =1
101415a34: 39004268    	strb	w8, [x19, #0x10]
101415a38: f9405fe9    	ldr	x9, [sp, #0xb8]
101415a3c: 17ffec50    	b	0x101410b7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xf14>
101415a40: 52800020    	mov	w0, #0x1                ; =1
101415a44: aa1303e1    	mov	x1, x19
101415a48: 941ab63d    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
101415a4c: 14000493    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101415a50: f944f7f9    	ldr	x25, [sp, #0x9e8]
101415a54: f944fbf5    	ldr	x21, [sp, #0x9f0]
101415a58: 97da2326    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101415a5c: 52800c00    	mov	w0, #0x60               ; =96
101415a60: 52800101    	mov	w1, #0x8                ; =8
101415a64: 97da231d    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101415a68: b4008ba0    	cbz	x0, 0x101416bdc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6f74>
101415a6c: aa0003f7    	mov	x23, x0
101415a70: a9006416    	stp	x22, x25, [x0]
101415a74: f9000815    	str	x21, [x0, #0x10]
101415a78: 52800088    	mov	w8, #0x4                ; =4
101415a7c: f904bbe8    	str	x8, [sp, #0x970]
101415a80: f904bfe0    	str	x0, [sp, #0x978]
101415a84: 52800036    	mov	w22, #0x1               ; =1
101415a88: f904c3f6    	str	x22, [sp, #0x980]
101415a8c: 912783e0    	add	x0, sp, #0x9e0
101415a90: 910403e1    	add	x1, sp, #0x100
101415a94: 52810c02    	mov	w2, #0x860              ; =2144
101415a98: 941ad064    	bl	0x101ac9c28 <_writev+0x101ac9c28>
101415a9c: d2800015    	mov	x21, #0x0               ; =0
101415aa0: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
101415aa4: 14000007    	b	0x101415ac0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5e58>
101415aa8: 8b1502e8    	add	x8, x23, x21
101415aac: a901e919    	stp	x25, x26, [x8, #0x18]
101415ab0: f900151c    	str	x28, [x8, #0x28]
101415ab4: 910006d6    	add	x22, x22, #0x1
101415ab8: f904c3f6    	str	x22, [sp, #0x980]
101415abc: 910062b5    	add	x21, x21, #0x18
101415ac0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101415ac4: 91094000    	add	x0, x0, #0x250
101415ac8: 912783e1    	add	x1, sp, #0x9e0
101415acc: 97ffdfc6    	bl	0x10140d9e4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2698>
101415ad0: f9492bf9    	ldr	x25, [sp, #0x1250]
101415ad4: eb18033f    	cmp	x25, x24
101415ad8: 540001c0    	b.eq	0x101415b10 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5ea8>
101415adc: f9492ffa    	ldr	x26, [sp, #0x1258]
101415ae0: f94933fc    	ldr	x28, [sp, #0x1260]
101415ae4: f944bbe8    	ldr	x8, [sp, #0x970]
101415ae8: eb0802df    	cmp	x22, x8
101415aec: 54fffde1    	b.ne	0x101415aa8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5e40>
101415af0: 9125c3e0    	add	x0, sp, #0x970
101415af4: aa1603e1    	mov	x1, x22
101415af8: 52800022    	mov	w2, #0x1                ; =1
101415afc: 52800103    	mov	w3, #0x8                ; =8
101415b00: 52800304    	mov	w4, #0x18               ; =24
101415b04: 94184b53    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101415b08: f944bff7    	ldr	x23, [sp, #0x978]
101415b0c: 17ffffe7    	b	0x101415aa8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5e40>
101415b10: 912783e0    	add	x0, sp, #0x9e0
101415b14: 94010120    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
101415b18: 3dc25fe0    	ldr	q0, [sp, #0x970]
101415b1c: 3d84bbe0    	str	q0, [sp, #0x12e0]
101415b20: f944c3f9    	ldr	x25, [sp, #0x980]
101415b24: f9097bf9    	str	x25, [sp, #0x12f0]
101415b28: f94977e8    	ldr	x8, [sp, #0x12e8]
101415b2c: f90047e8    	str	x8, [sp, #0x88]
101415b30: f1000b3f    	cmp	x25, #0x2
101415b34: 54007b62    	b.hs	0x101416aa0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6e38>
101415b38: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101415b3c: 910be000    	add	x0, x0, #0x2f8
101415b40: 97ffe89c    	bl	0x10140fdb0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x148>
101415b44: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
101415b48: 910c4108    	add	x8, x8, #0x310
101415b4c: 8b140260    	add	x0, x19, x20
101415b50: f9405fe1    	ldr	x1, [sp, #0xb8]
101415b54: 940fd6f8    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
101415b58: 52800109    	mov	w9, #0x8                ; =8
101415b5c: f90997ff    	str	xzr, [sp, #0x1328]
101415b60: 52800108    	mov	w8, #0x8                ; =8
101415b64: f90053e8    	str	x8, [sp, #0xa0]
101415b68: f9099be9    	str	x9, [sp, #0x1330]
101415b6c: f9099fff    	str	xzr, [sp, #0x1338]
101415b70: f94973ea    	ldr	x10, [sp, #0x12e0]
101415b74: 52800308    	mov	w8, #0x18               ; =24
101415b78: f94047e9    	ldr	x9, [sp, #0x88]
101415b7c: 9b082728    	madd	x8, x25, x8, x9
101415b80: f9092be9    	str	x9, [sp, #0x1250]
101415b84: f9003fea    	str	x10, [sp, #0x78]
101415b88: f90933ea    	str	x10, [sp, #0x1260]
101415b8c: f90057e8    	str	x8, [sp, #0xa8]
101415b90: f90937e8    	str	x8, [sp, #0x1268]
101415b94: b40025b9    	cbz	x25, 0x101416048 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x63e0>
101415b98: f9005fff    	str	xzr, [sp, #0xb8]
101415b9c: f9401fe8    	ldr	x8, [sp, #0x38]
101415ba0: b9407908    	ldr	w8, [x8, #0x78]
101415ba4: b90093e8    	str	w8, [sp, #0x90]
101415ba8: 52800108    	mov	w8, #0x8                ; =8
101415bac: f90053e8    	str	x8, [sp, #0xa0]
101415bb0: f94047f5    	ldr	x21, [sp, #0x88]
101415bb4: 14000004    	b	0x101415bc4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5f5c>
101415bb8: f94057e8    	ldr	x8, [sp, #0xa8]
101415bbc: eb0802bf    	cmp	x21, x8
101415bc0: 54002480    	b.eq	0x101416050 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x63e8>
101415bc4: f94002a8    	ldr	x8, [x21]
101415bc8: 3cc082a0    	ldur	q0, [x21, #0x8]
101415bcc: 910062b5    	add	x21, x21, #0x18
101415bd0: 3c9103a0    	stur	q0, [x29, #-0xf0]
101415bd4: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101415bd8: eb09011f    	cmp	x8, x9
101415bdc: 540023a0    	b.eq	0x101416050 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x63e8>
101415be0: f81283a8    	stur	x8, [x29, #-0xd8]
101415be4: 3cd103a0    	ldur	q0, [x29, #-0xf0]
101415be8: d10363a8    	sub	x8, x29, #0xd8
101415bec: 3c808100    	stur	q0, [x8, #0x8]
101415bf0: 940ec22f    	bl	0x1017c64ac <__ZN3std4time7Instant3now17h87d5cb233fd870c8E>
101415bf4: eb1b001f    	cmp	x0, x27
101415bf8: 540000a1    	b.ne	0x101415c0c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5fa4>
101415bfc: b94093e8    	ldr	w8, [sp, #0x90]
101415c00: 6b08003f    	cmp	w1, w8
101415c04: 54000083    	b.lo	0x101415c14 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5fac>
101415c08: 1400014f    	b	0x101416144 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x64dc>
101415c0c: eb1b001f    	cmp	x0, x27
101415c10: 540029aa    	b.ge	0x101416144 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x64dc>
101415c14: a9730fa2    	ldp	x2, x3, [x29, #-0xd0]
101415c18: b4000083    	cbz	x3, 0x101415c28 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5fc0>
101415c1c: 39400048    	ldrb	w8, [x2]
101415c20: 7100b91f    	cmp	w8, #0x2e
101415c24: 54001360    	b.eq	0x101415e90 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6228>
101415c28: f94993f7    	ldr	x23, [sp, #0x1320]
101415c2c: b40005f7    	cbz	x23, 0x101415ce8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6080>
101415c30: 910303e8    	add	x8, sp, #0xc0
101415c34: aa0203e0    	mov	x0, x2
101415c38: aa0303e1    	mov	x1, x3
101415c3c: 940fd6be    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
101415c40: a94c8bf3    	ldp	x19, x2, [sp, #0xc8]
101415c44: f9498fe9    	ldr	x9, [sp, #0x1318]
101415c48: eb0202ff    	cmp	x23, x2
101415c4c: 540001a2    	b.hs	0x101415c80 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6018>
101415c50: f10006ff    	cmp	x23, #0x1
101415c54: 54000281    	b.ne	0x101415ca4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x603c>
101415c58: 39400120    	ldrb	w0, [x9]
101415c5c: f1003c5f    	cmp	x2, #0xf
101415c60: 54001248    	b.hi	0x101415ea8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6240>
101415c64: aa1303e8    	mov	x8, x19
101415c68: 38401509    	ldrb	w9, [x8], #0x1
101415c6c: 6b00013f    	cmp	w9, w0
101415c70: 54000300    	b.eq	0x101415cd0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6068>
101415c74: f1000442    	subs	x2, x2, #0x1
101415c78: 54ffff81    	b.ne	0x101415c68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6000>
101415c7c: 14000007    	b	0x101415c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6030>
101415c80: 540000c1    	b.ne	0x101415c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6030>
101415c84: aa0903e0    	mov	x0, x9
101415c88: aa1303e1    	mov	x1, x19
101415c8c: aa1703e2    	mov	x2, x23
101415c90: 941acfe3    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
101415c94: 340001e0    	cbz	w0, 0x101415cd0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6068>
101415c98: f94063e1    	ldr	x1, [sp, #0xc0]
101415c9c: b5000f41    	cbnz	x1, 0x101415e84 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x621c>
101415ca0: 1400007c    	b	0x101415e90 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6228>
101415ca4: 912783e8    	add	x8, sp, #0x9e0
101415ca8: aa1303e0    	mov	x0, x19
101415cac: aa0203e1    	mov	x1, x2
101415cb0: aa0903e2    	mov	x2, x9
101415cb4: aa1703e3    	mov	x3, x23
101415cb8: 9410393d    	bl	0x1018241ac <__ZN4core3str7pattern11StrSearcher3new17hb0ec4e7243414bb1E>
101415cbc: 9125c3e0    	add	x0, sp, #0x970
101415cc0: 912783e1    	add	x1, sp, #0x9e0
101415cc4: 94015a5d    	bl	0x10146c638 <__ZN5alloc4sync16Arc$LT$T$C$A$GT$9drop_slow17hef5d12e32655eb94E+0xf08>
101415cc8: b94973e8    	ldr	w8, [sp, #0x970]
101415ccc: 3607fe68    	tbz	w8, #0x0, 0x101415c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6030>
101415cd0: f94063e1    	ldr	x1, [sp, #0xc0]
101415cd4: b4000081    	cbz	x1, 0x101415ce4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x607c>
101415cd8: aa1303e0    	mov	x0, x19
101415cdc: 52800022    	mov	w2, #0x1                ; =1
101415ce0: 97da227f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101415ce4: a9730fa2    	ldp	x2, x3, [x29, #-0xd0]
101415ce8: f9405be8    	ldr	x8, [sp, #0xb0]
101415cec: a9408500    	ldp	x0, x1, [x8, #0x8]
101415cf0: d10303a8    	sub	x8, x29, #0xc0
101415cf4: 940eb96a    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101415cf8: a974dfb3    	ldp	x19, x23, [x29, #-0xb8]
101415cfc: aa1303e0    	mov	x0, x19
101415d00: aa1703e1    	mov	x1, x23
101415d04: 940eb9c7    	bl	0x1017c4420 <__ZN3std4path4Path6is_dir17hdaadc6576e56c526E>
101415d08: 36000ba0    	tbz	w0, #0x0, 0x101415e7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6214>
101415d0c: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
101415d10: 910ae108    	add	x8, x8, #0x2b8
101415d14: f904f3e8    	str	x8, [sp, #0x9e0]
101415d18: d00001c8    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101415d1c: 91117108    	add	x8, x8, #0x45c
101415d20: f904f7e8    	str	x8, [sp, #0x9e8]
101415d24: d10363a8    	sub	x8, x29, #0xd8
101415d28: f904fbe8    	str	x8, [sp, #0x9f0]
101415d2c: d00002a8    	adrp	x8, 0x10146b000 <__ZN4core5slice4sort8unstable8heapsort8heapsort17h14b311923aeea277E+0x3bbc>
101415d30: 913b4108    	add	x8, x8, #0xed0
101415d34: f904ffe8    	str	x8, [sp, #0x9f8]
101415d38: 9125c3e8    	add	x8, sp, #0x970
101415d3c: 912783e1    	add	x1, sp, #0x9e0
101415d40: f0004ec0    	adrp	x0, 0x101df0000 <_writev+0x101df0000>
101415d44: 9125d000    	add	x0, x0, #0x974
101415d48: 940fd60e    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
101415d4c: f944bbf9    	ldr	x25, [sp, #0x970]
101415d50: f944bffa    	ldr	x26, [sp, #0x978]
101415d54: f944c3f4    	ldr	x20, [sp, #0x980]
101415d58: d10283a8    	sub	x8, x29, #0xa0
101415d5c: aa1303e0    	mov	x0, x19
101415d60: aa1703e1    	mov	x1, x23
101415d64: 940fe28e    	bl	0x10180e79c <__ZN5alloc6string6String15from_utf8_lossy17hcb81682812c4da7aE>
101415d68: a9765fa8    	ldp	x8, x23, [x29, #-0xa0]
101415d6c: f90043e8    	str	x8, [sp, #0x80]
101415d70: f85703a1    	ldur	x1, [x29, #-0x90]
101415d74: f9497fe8    	ldr	x8, [sp, #0x12f8]
101415d78: f94983e9    	ldr	x9, [sp, #0x1300]
101415d7c: f94987e3    	ldr	x3, [sp, #0x1308]
101415d80: d2f0000a    	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
101415d84: eb0a011f    	cmp	x8, x10
101415d88: 9a8903e2    	csel	x2, xzr, x9, eq
101415d8c: 912783e8    	add	x8, sp, #0x9e0
101415d90: aa1703e0    	mov	x0, x23
101415d94: 97ffe7b5    	bl	0x10140fc68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E>
101415d98: f944f3fc    	ldr	x28, [sp, #0x9e0]
101415d9c: f944f7f8    	ldr	x24, [sp, #0x9e8]
101415da0: f944fbf6    	ldr	x22, [sp, #0x9f0]
101415da4: a90c6bf9    	stp	x25, x26, [sp, #0xc0]
101415da8: f9006bf4    	str	x20, [sp, #0xd0]
101415dac: 9125c3e8    	add	x8, sp, #0x970
101415db0: 910303e0    	add	x0, sp, #0xc0
101415db4: 940fe506    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
101415db8: f90503fa    	str	x26, [sp, #0xa00]
101415dbc: f90507f4    	str	x20, [sp, #0xa08]
101415dc0: 3dc25fe0    	ldr	q0, [sp, #0x970]
101415dc4: f944c3e8    	ldr	x8, [sp, #0x980]
101415dc8: 3d827be0    	str	q0, [sp, #0x9e0]
101415dcc: f904fff9    	str	x25, [sp, #0x9f8]
101415dd0: f904fbe8    	str	x8, [sp, #0x9f0]
101415dd4: f9050bfc    	str	x28, [sp, #0xa10]
101415dd8: f9050ff8    	str	x24, [sp, #0xa18]
101415ddc: f90513f6    	str	x22, [sp, #0xa20]
101415de0: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101415de4: f90517e8    	str	x8, [sp, #0xa28]
101415de8: 52808008    	mov	w8, #0x400              ; =1024
101415dec: 791483e8    	strh	w8, [sp, #0xa40]
101415df0: f94997e8    	ldr	x8, [sp, #0x1328]
101415df4: f9405fe9    	ldr	x9, [sp, #0xb8]
101415df8: eb08013f    	cmp	x9, x8
101415dfc: 540000c1    	b.ne	0x101415e14 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x61ac>
101415e00: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101415e04: 910ca000    	add	x0, x0, #0x328
101415e08: 9419e837    	bl	0x101a8fee4 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h79ba5ff6649e4cf8E>
101415e0c: f9499be8    	ldr	x8, [sp, #0x1330]
101415e10: f90053e8    	str	x8, [sp, #0xa0]
101415e14: f9405fea    	ldr	x10, [sp, #0xb8]
101415e18: f94053e8    	ldr	x8, [sp, #0xa0]
101415e1c: 52800d09    	mov	w9, #0x68               ; =104
101415e20: 9b092148    	madd	x8, x10, x9, x8
101415e24: 3dc27be0    	ldr	q0, [sp, #0x9e0]
101415e28: 3dc27fe1    	ldr	q1, [sp, #0x9f0]
101415e2c: 3dc283e2    	ldr	q2, [sp, #0xa00]
101415e30: ad008901    	stp	q1, q2, [x8, #0x10]
101415e34: 3d800100    	str	q0, [x8]
101415e38: 3dc287e0    	ldr	q0, [sp, #0xa10]
101415e3c: 3dc28be1    	ldr	q1, [sp, #0xa20]
101415e40: 3dc28fe2    	ldr	q2, [sp, #0xa30]
101415e44: f94523e9    	ldr	x9, [sp, #0xa40]
101415e48: f9003109    	str	x9, [x8, #0x60]
101415e4c: ad020901    	stp	q1, q2, [x8, #0x40]
101415e50: 3d800d00    	str	q0, [x8, #0x30]
101415e54: 9100054a    	add	x10, x10, #0x1
101415e58: f9005fea    	str	x10, [sp, #0xb8]
101415e5c: f9099fea    	str	x10, [sp, #0x1338]
101415e60: f94043e8    	ldr	x8, [sp, #0x80]
101415e64: f240f91f    	tst	x8, #0x7fffffffffffffff
101415e68: 540000a0    	b.eq	0x101415e7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6214>
101415e6c: aa1703e0    	mov	x0, x23
101415e70: f94043e1    	ldr	x1, [sp, #0x80]
101415e74: 52800022    	mov	w2, #0x1                ; =1
101415e78: 97da2219    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101415e7c: f85403a1    	ldur	x1, [x29, #-0xc0]
101415e80: b4000081    	cbz	x1, 0x101415e90 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6228>
101415e84: aa1303e0    	mov	x0, x19
101415e88: 52800022    	mov	w2, #0x1                ; =1
101415e8c: 97da2214    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101415e90: f85283a1    	ldur	x1, [x29, #-0xd8]
101415e94: b4ffe921    	cbz	x1, 0x101415bb8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5f50>
101415e98: f85303a0    	ldur	x0, [x29, #-0xd0]
101415e9c: 52800022    	mov	w2, #0x1                ; =1
101415ea0: 97da220f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101415ea4: 17ffff45    	b	0x101415bb8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5f50>
101415ea8: aa1303e1    	mov	x1, x19
101415eac: 94103d25    	bl	0x101825340 <__ZN4core5slice6memchr14memchr_aligned17hb4aaf9792c60d219E>
101415eb0: f100041f    	cmp	x0, #0x1
101415eb4: 54ffef21    	b.ne	0x101415c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6030>
101415eb8: 17ffff86    	b	0x101415cd0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6068>
101415ebc: d280000b    	mov	x11, #0x0               ; =0
101415ec0: d2800009    	mov	x9, #0x0                ; =0
101415ec4: f904bbeb    	str	x11, [sp, #0x970]
101415ec8: f904bfff    	str	xzr, [sp, #0x978]
101415ecc: f904c3e8    	str	x8, [sp, #0x980]
101415ed0: f904c7ea    	str	x10, [sp, #0x988]
101415ed4: f904cbeb    	str	x11, [sp, #0x990]
101415ed8: f904cfff    	str	xzr, [sp, #0x998]
101415edc: f904d3e8    	str	x8, [sp, #0x9a0]
101415ee0: f904d7ea    	str	x10, [sp, #0x9a8]
101415ee4: f904dbe9    	str	x9, [sp, #0x9b0]
101415ee8: f904dff3    	str	x19, [sp, #0x9b8]
101415eec: 910403e0    	add	x0, sp, #0x100
101415ef0: 9125c3e1    	add	x1, sp, #0x970
101415ef4: 97ffa28c    	bl	0x1013fe924 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xbfc>
101415ef8: f94083e8    	ldr	x8, [sp, #0x100]
101415efc: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101415f00: eb09011f    	cmp	x8, x9
101415f04: 540000a1    	b.ne	0x101415f18 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x62b0>
101415f08: d2800018    	mov	x24, #0x0               ; =0
101415f0c: f904f3ff    	str	xzr, [sp, #0x9e0]
101415f10: 52800117    	mov	w23, #0x8               ; =8
101415f14: 14000049    	b	0x101416038 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x63d0>
101415f18: 97da21f6    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101415f1c: 52803400    	mov	w0, #0x1a0              ; =416
101415f20: 52800101    	mov	w1, #0x8                ; =8
101415f24: 97da21ed    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101415f28: b4006520    	cbz	x0, 0x101416bcc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6f64>
101415f2c: aa0003f3    	mov	x19, x0
101415f30: ad4a07e0    	ldp	q0, q1, [sp, #0x140]
101415f34: ad020400    	stp	q0, q1, [x0, #0x40]
101415f38: f940b3e8    	ldr	x8, [sp, #0x160]
101415f3c: f9003008    	str	x8, [x0, #0x60]
101415f40: ad4807e0    	ldp	q0, q1, [sp, #0x100]
101415f44: ad000400    	stp	q0, q1, [x0]
101415f48: ad4903e1    	ldp	q1, q0, [sp, #0x120]
101415f4c: ad010001    	stp	q1, q0, [x0, #0x20]
101415f50: 52800088    	mov	w8, #0x4                ; =4
101415f54: a93603a8    	stp	x8, x0, [x29, #-0xa0]
101415f58: 52800037    	mov	w23, #0x1               ; =1
101415f5c: f81703b7    	stur	x23, [x29, #-0x90]
101415f60: 3dc267e0    	ldr	q0, [sp, #0x990]
101415f64: 3dc26be1    	ldr	q1, [sp, #0x9a0]
101415f68: 3d849fe0    	str	q0, [sp, #0x1270]
101415f6c: 3d84a3e1    	str	q1, [sp, #0x1280]
101415f70: 3dc26fe0    	ldr	q0, [sp, #0x9b0]
101415f74: 3d84a7e0    	str	q0, [sp, #0x1290]
101415f78: 3dc263e0    	ldr	q0, [sp, #0x980]
101415f7c: 3dc25fe1    	ldr	q1, [sp, #0x970]
101415f80: 52800d18    	mov	w24, #0x68              ; =104
101415f84: d2f0001a    	mov	x26, #-0x8000000000000000 ; =-9223372036854775808
101415f88: 3d849be0    	str	q0, [sp, #0x1260]
101415f8c: 3d8497e1    	str	q1, [sp, #0x1250]
101415f90: 14000012    	b	0x101415fd8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6370>
101415f94: f85683b3    	ldur	x19, [x29, #-0x98]
101415f98: 8b180268    	add	x8, x19, x24
101415f9c: 3dc27be0    	ldr	q0, [sp, #0x9e0]
101415fa0: 3dc27fe1    	ldr	q1, [sp, #0x9f0]
101415fa4: 3dc283e2    	ldr	q2, [sp, #0xa00]
101415fa8: ad008901    	stp	q1, q2, [x8, #0x10]
101415fac: 3d800100    	str	q0, [x8]
101415fb0: 3dc287e0    	ldr	q0, [sp, #0xa10]
101415fb4: 3dc28be1    	ldr	q1, [sp, #0xa20]
101415fb8: 3dc28fe2    	ldr	q2, [sp, #0xa30]
101415fbc: f94523e9    	ldr	x9, [sp, #0xa40]
101415fc0: f9003109    	str	x9, [x8, #0x60]
101415fc4: ad020901    	stp	q1, q2, [x8, #0x40]
101415fc8: 3d800d00    	str	q0, [x8, #0x30]
101415fcc: 910006f7    	add	x23, x23, #0x1
101415fd0: f81703b7    	stur	x23, [x29, #-0x90]
101415fd4: 9101a318    	add	x24, x24, #0x68
101415fd8: 912783e0    	add	x0, sp, #0x9e0
101415fdc: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
101415fe0: 91094021    	add	x1, x1, #0x250
101415fe4: 97ffa250    	bl	0x1013fe924 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xbfc>
101415fe8: f944f3e8    	ldr	x8, [sp, #0x9e0]
101415fec: eb1a011f    	cmp	x8, x26
101415ff0: 54000160    	b.eq	0x10141601c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x63b4>
101415ff4: f85603a8    	ldur	x8, [x29, #-0xa0]
101415ff8: eb0802ff    	cmp	x23, x8
101415ffc: 54fffce1    	b.ne	0x101415f98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6330>
101416000: d10283a0    	sub	x0, x29, #0xa0
101416004: aa1703e1    	mov	x1, x23
101416008: 52800022    	mov	w2, #0x1                ; =1
10141600c: 52800103    	mov	w3, #0x8                ; =8
101416010: 52800d04    	mov	w4, #0x68               ; =104
101416014: 94184a0f    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
101416018: 17ffffdf    	b	0x101415f94 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x632c>
10141601c: 3cd603a0    	ldur	q0, [x29, #-0xa0]
101416020: 3d827be0    	str	q0, [sp, #0x9e0]
101416024: f85703b8    	ldur	x24, [x29, #-0x90]
101416028: f904fbf8    	str	x24, [sp, #0x9f0]
10141602c: f944f7f7    	ldr	x23, [sp, #0x9e8]
101416030: f1000b1f    	cmp	x24, #0x2
101416034: 540052a2    	b.hs	0x101416a88 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6e20>
101416038: f944f3fb    	ldr	x27, [sp, #0x9e0]
10141603c: 910303e0    	add	x0, sp, #0xc0
101416040: 9400f5a3    	bl	0x1014536cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6244>
101416044: 17fffb2e    	b	0x101414cfc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5094>
101416048: f9005fff    	str	xzr, [sp, #0xb8]
10141604c: f94047f5    	ldr	x21, [sp, #0x88]
101416050: f9092ff5    	str	x21, [sp, #0x1258]
101416054: f94057e8    	ldr	x8, [sp, #0xa8]
101416058: eb150108    	subs	x8, x8, x21
10141605c: 54000200    	b.eq	0x10141609c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6434>
101416060: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
101416064: f2955569    	movk	x9, #0xaaab
101416068: 9bc97d08    	umulh	x8, x8, x9
10141606c: d344fd13    	lsr	x19, x8, #4
101416070: 910022b4    	add	x20, x21, #0x8
101416074: 14000004    	b	0x101416084 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x641c>
101416078: 91006294    	add	x20, x20, #0x18
10141607c: f1000673    	subs	x19, x19, #0x1
101416080: 540000e0    	b.eq	0x10141609c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6434>
101416084: f85f8281    	ldur	x1, [x20, #-0x8]
101416088: b4ffff81    	cbz	x1, 0x101416078 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6410>
10141608c: f9400280    	ldr	x0, [x20]
101416090: 52800022    	mov	w2, #0x1                ; =1
101416094: 97da2192    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416098: 17fffff8    	b	0x101416078 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6410>
10141609c: f9403fe8    	ldr	x8, [sp, #0x78]
1014160a0: b40000e8    	cbz	x8, 0x1014160bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6454>
1014160a4: f9403fe8    	ldr	x8, [sp, #0x78]
1014160a8: 8b080508    	add	x8, x8, x8, lsl #1
1014160ac: d37df101    	lsl	x1, x8, #3
1014160b0: f94047e0    	ldr	x0, [sp, #0x88]
1014160b4: 52800102    	mov	w2, #0x8                ; =8
1014160b8: 97da2189    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014160bc: f94997f3    	ldr	x19, [sp, #0x1328]
1014160c0: f9498be1    	ldr	x1, [sp, #0x1310]
1014160c4: b4000081    	cbz	x1, 0x1014160d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x646c>
1014160c8: f9498fe0    	ldr	x0, [sp, #0x1318]
1014160cc: 52800022    	mov	w2, #0x1                ; =1
1014160d0: 97da2183    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014160d4: f9497fe1    	ldr	x1, [sp, #0x12f8]
1014160d8: f240f83f    	tst	x1, #0x7fffffffffffffff
1014160dc: 54000080    	b.eq	0x1014160ec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6484>
1014160e0: f94983e0    	ldr	x0, [sp, #0x1300]
1014160e4: 52800022    	mov	w2, #0x1                ; =1
1014160e8: 97da217d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014160ec: f9496be8    	ldr	x8, [sp, #0x12d0]
1014160f0: f9005be8    	str	x8, [sp, #0xb0]
1014160f4: f9496ff4    	ldr	x20, [sp, #0x12d8]
1014160f8: b40001b4    	cbz	x20, 0x10141612c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x64c4>
1014160fc: f9405be8    	ldr	x8, [sp, #0xb0]
101416100: 91002115    	add	x21, x8, #0x8
101416104: 14000004    	b	0x101416114 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x64ac>
101416108: 910062b5    	add	x21, x21, #0x18
10141610c: f1000694    	subs	x20, x20, #0x1
101416110: 540000e0    	b.eq	0x10141612c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x64c4>
101416114: f85f82a1    	ldur	x1, [x21, #-0x8]
101416118: b4ffff81    	cbz	x1, 0x101416108 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x64a0>
10141611c: f94002a0    	ldr	x0, [x21]
101416120: 52800022    	mov	w2, #0x1                ; =1
101416124: 97da216e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416128: 17fffff8    	b	0x101416108 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x64a0>
10141612c: f94967e8    	ldr	x8, [sp, #0x12c8]
101416130: b5ff6ac8    	cbnz	x8, 0x101414e88 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5220>
101416134: 17fffb5a    	b	0x101414e9c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5234>
101416138: d0007280    	adrp	x0, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
10141613c: 9120a000    	add	x0, x0, #0x828
101416140: 941ab53c    	bl	0x101ac3630 <__ZN4core3str6traits23str_index_overflow_fail17h7f8b92a7ba988549E>
101416144: f9092ff5    	str	x21, [sp, #0x1258]
101416148: f85283a1    	ldur	x1, [x29, #-0xd8]
10141614c: b4fff841    	cbz	x1, 0x101416054 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x63ec>
101416150: f85303a0    	ldur	x0, [x29, #-0xd0]
101416154: 52800022    	mov	w2, #0x1                ; =1
101416158: 97da2161    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141615c: 17ffffbe    	b	0x101416054 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x63ec>
101416160: f100571f    	cmp	x24, #0x15
101416164: 54004ca2    	b.hs	0x101416af8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6e90>
101416168: aa1703e0    	mov	x0, x23
10141616c: aa1803e1    	mov	x1, x24
101416170: 94010c17    	bl	0x1014591cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbd44>
101416174: 17fff0bd    	b	0x101412468 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2800>
101416178: 940ea604    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
10141617c: f90057e1    	str	x1, [sp, #0xa8]
101416180: aa0003f4    	mov	x20, x0
101416184: f94057e9    	ldr	x9, [sp, #0xa8]
101416188: 52800028    	mov	w8, #0x1                ; =1
10141618c: 39004348    	strb	w8, [x26, #0x10]
101416190: 91000408    	add	x8, x0, #0x1
101416194: a9002748    	stp	x8, x9, [x26]
101416198: f85403a1    	ldur	x1, [x29, #-0xc0]
10141619c: b5fde6c1    	cbnz	x1, 0x101411e74 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x220c>
1014161a0: a972ebb3    	ldp	x19, x26, [x29, #-0xd8]
1014161a4: f85383b9    	ldur	x25, [x29, #-0xc8]
1014161a8: f94997e1    	ldr	x1, [sp, #0x1328]
1014161ac: b4000081    	cbz	x1, 0x1014161bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6554>
1014161b0: aa1803e0    	mov	x0, x24
1014161b4: 52800022    	mov	w2, #0x1                ; =1
1014161b8: 97da2149    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014161bc: f9497fe8    	ldr	x8, [sp, #0x12f8]
1014161c0: 52800309    	mov	w9, #0x18               ; =24
1014161c4: 9b096b29    	madd	x9, x25, x9, x26
1014161c8: a9106bfa    	stp	x26, x26, [sp, #0x100]
1014161cc: a91127f3    	stp	x19, x9, [sp, #0x110]
1014161d0: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1014161d4: eb09011f    	cmp	x8, x9
1014161d8: 540000c1    	b.ne	0x1014161f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6588>
1014161dc: d2800009    	mov	x9, #0x0                ; =0
1014161e0: d2800008    	mov	x8, #0x0                ; =0
1014161e4: 5280010a    	mov	w10, #0x8               ; =8
1014161e8: f9401ff5    	ldr	x21, [sp, #0x38]
1014161ec: 14000024    	b	0x10141627c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6614>
1014161f0: f94987e1    	ldr	x1, [sp, #0x1308]
1014161f4: f94983e0    	ldr	x0, [sp, #0x1300]
1014161f8: 90003842    	adrp	x2, 0x101b1e000 <_$s4Otty8HeldKeysV7isEmptySbvpMV+0x17014>
1014161fc: 9111f042    	add	x2, x2, #0x47c
101416200: 912783e8    	add	x8, sp, #0x9e0
101416204: 52800083    	mov	w3, #0x4                ; =4
101416208: 940eb825    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
10141620c: f9401ff5    	ldr	x21, [sp, #0x38]
101416210: f944f7f4    	ldr	x20, [sp, #0x9e8]
101416214: f944fbe1    	ldr	x1, [sp, #0x9f0]
101416218: b0004642    	adrp	x2, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
10141621c: 911ff842    	add	x2, x2, #0x7fe
101416220: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
101416224: 91094108    	add	x8, x8, #0x250
101416228: aa1403e0    	mov	x0, x20
10141622c: 52800163    	mov	w3, #0xb                ; =11
101416230: 940eb81b    	bl	0x1017c429c <__ZN3std4path4Path5_join17h44fb22321377b570E>
101416234: f9492ff3    	ldr	x19, [sp, #0x1258]
101416238: f94933e1    	ldr	x1, [sp, #0x1260]
10141623c: 9125c3e8    	add	x8, sp, #0x970
101416240: aa1303e0    	mov	x0, x19
101416244: 9401875f    	bl	0x101477fc0 <__ZN15otty_ssh_config11known_hosts11known_hosts17hf71f534e749e4cf0E>
101416248: f9492be1    	ldr	x1, [sp, #0x1250]
10141624c: b4000081    	cbz	x1, 0x10141625c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x65f4>
101416250: aa1303e0    	mov	x0, x19
101416254: 52800022    	mov	w2, #0x1                ; =1
101416258: 97da2121    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141625c: f944f3e1    	ldr	x1, [sp, #0x9e0]
101416260: b4000081    	cbz	x1, 0x101416270 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6608>
101416264: aa1403e0    	mov	x0, x20
101416268: 52800022    	mov	w2, #0x1                ; =1
10141626c: 97da211c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416270: f944bbe8    	ldr	x8, [sp, #0x970]
101416274: f944bfea    	ldr	x10, [sp, #0x978]
101416278: f944c3e9    	ldr	x9, [sp, #0x980]
10141627c: 5280030b    	mov	w11, #0x18              ; =24
101416280: ad4807e0    	ldp	q0, q1, [sp, #0x100]
101416284: 9b0b2929    	madd	x9, x9, x11, x10
101416288: 3d827be0    	str	q0, [sp, #0x9e0]
10141628c: 3d827fe1    	str	q1, [sp, #0x9f0]
101416290: f90503ea    	str	x10, [sp, #0xa00]
101416294: f90507ea    	str	x10, [sp, #0xa08]
101416298: f9050be8    	str	x8, [sp, #0xa10]
10141629c: f9050fe9    	str	x9, [sp, #0xa18]
1014162a0: f9405fe8    	ldr	x8, [sp, #0xb8]
1014162a4: b4003b48    	cbz	x8, 0x101416a0c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6da4>
1014162a8: f94012a8    	ldr	x8, [x21, #0x20]
1014162ac: a94626a0    	ldp	x0, x9, [x21, #0x60]
1014162b0: a9408901    	ldp	x1, x2, [x8, #0x8]
1014162b4: f9401529    	ldr	x9, [x9, #0x28]
1014162b8: 910403e8    	add	x8, sp, #0x100
1014162bc: 52800023    	mov	w3, #0x1                ; =1
1014162c0: d2800004    	mov	x4, #0x0                ; =0
1014162c4: d63f0120    	blr	x9
1014162c8: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
1014162cc: 91094108    	add	x8, x8, #0x250
1014162d0: 3dc27be0    	ldr	q0, [sp, #0x9e0]
1014162d4: 3dc27fe1    	ldr	q1, [sp, #0x9f0]
1014162d8: 3c808100    	stur	q0, [x8, #0x8]
1014162dc: 3c818101    	stur	q1, [x8, #0x18]
1014162e0: 3dc283e0    	ldr	q0, [sp, #0xa00]
1014162e4: 3dc287e1    	ldr	q1, [sp, #0xa10]
1014162e8: 3c828100    	stur	q0, [x8, #0x28]
1014162ec: a9502be9    	ldp	x9, x10, [sp, #0x100]
1014162f0: f9408beb    	ldr	x11, [sp, #0x110]
1014162f4: 5280030c    	mov	w12, #0x18              ; =24
1014162f8: 9b0c296b    	madd	x11, x11, x12, x10
1014162fc: 5280002c    	mov	w12, #0x1               ; =1
101416300: 3c838101    	stur	q1, [x8, #0x38]
101416304: f9092bec    	str	x12, [sp, #0x1250]
101416308: f9094fea    	str	x10, [sp, #0x1298]
10141630c: f90953ea    	str	x10, [sp, #0x12a0]
101416310: f90957e9    	str	x9, [sp, #0x12a8]
101416314: f9095beb    	str	x11, [sp, #0x12b0]
101416318: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10141631c: 910c4108    	add	x8, x8, #0x310
101416320: aa1603e0    	mov	x0, x22
101416324: f9404be1    	ldr	x1, [sp, #0x90]
101416328: 940fd503    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
10141632c: d0007b20    	adrp	x0, 0x10237c000 <_OBJC_METACLASS_$__TtC9TextStory23TextMutationEventRouter+0x4a0>
101416330: 9131a000    	add	x0, x0, #0xc68
101416334: f9400008    	ldr	x8, [x0]
101416338: d63f0100    	blr	x8
10141633c: aa0003f3    	mov	x19, x0
101416340: 39404008    	ldrb	w8, [x0, #0x10]
101416344: 7100051f    	cmp	w8, #0x1
101416348: 54002d41    	b.ne	0x1014168f0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c88>
10141634c: a9400660    	ldp	x0, x1, [x19]
101416350: 91000408    	add	x8, x0, #0x1
101416354: f9000268    	str	x8, [x19]
101416358: d0007288    	adrp	x8, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
10141635c: 91166108    	add	x8, x8, #0x598
101416360: ad400500    	ldp	q0, q1, [x8]
101416364: 3d825fe0    	str	q0, [sp, #0x970]
101416368: 3d8263e1    	str	q1, [sp, #0x980]
10141636c: f904cbe0    	str	x0, [sp, #0x990]
101416370: f904cfe1    	str	x1, [sp, #0x998]
101416374: 52800108    	mov	w8, #0x8                ; =8
101416378: f90997ff    	str	xzr, [sp, #0x1328]
10141637c: f9099be8    	str	x8, [sp, #0x1330]
101416380: f9099fff    	str	xzr, [sp, #0x1338]
101416384: 3dc497e0    	ldr	q0, [sp, #0x1250]
101416388: 3dc49be1    	ldr	q1, [sp, #0x1260]
10141638c: ad0807e0    	stp	q0, q1, [sp, #0x100]
101416390: 3dc4abe0    	ldr	q0, [sp, #0x12a0]
101416394: 3dc4a7e1    	ldr	q1, [sp, #0x1290]
101416398: ad0a03e1    	stp	q1, q0, [sp, #0x140]
10141639c: f9495be8    	ldr	x8, [sp, #0x12b0]
1014163a0: f900b3e8    	str	x8, [sp, #0x160]
1014163a4: d2f00019    	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
1014163a8: 3dc4a3e0    	ldr	q0, [sp, #0x1280]
1014163ac: 3dc49fe1    	ldr	q1, [sp, #0x1270]
1014163b0: ad0903e1    	stp	q1, q0, [sp, #0x120]
1014163b4: a9504ffb    	ldp	x27, x19, [sp, #0x100]
1014163b8: f9408bfa    	ldr	x26, [sp, #0x110]
1014163bc: f9409bf4    	ldr	x20, [sp, #0x130]
1014163c0: f940abf7    	ldr	x23, [sp, #0x150]
1014163c4: 1400001e    	b	0x10141643c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x67d4>
1014163c8: f9499be8    	ldr	x8, [sp, #0x1330]
1014163cc: 52800d09    	mov	w9, #0x68               ; =104
1014163d0: 9b092288    	madd	x8, x20, x9, x8
1014163d4: 3dc287e0    	ldr	q0, [sp, #0xa10]
1014163d8: 3d800d00    	str	q0, [x8, #0x30]
1014163dc: 3dc28be0    	ldr	q0, [sp, #0xa20]
1014163e0: 3d801100    	str	q0, [x8, #0x40]
1014163e4: 3dc28fe0    	ldr	q0, [sp, #0xa30]
1014163e8: 3d801500    	str	q0, [x8, #0x50]
1014163ec: f94523e9    	ldr	x9, [sp, #0xa40]
1014163f0: f9003109    	str	x9, [x8, #0x60]
1014163f4: 3dc27be0    	ldr	q0, [sp, #0x9e0]
1014163f8: 3d800100    	str	q0, [x8]
1014163fc: 3dc27fe0    	ldr	q0, [sp, #0x9f0]
101416400: 3d800500    	str	q0, [x8, #0x10]
101416404: 3dc283e0    	ldr	q0, [sp, #0xa00]
101416408: 3d800900    	str	q0, [x8, #0x20]
10141640c: 91000688    	add	x8, x20, #0x1
101416410: f9099fe8    	str	x8, [sp, #0x1338]
101416414: aa1303f4    	mov	x20, x19
101416418: aa1b03f3    	mov	x19, x27
10141641c: aa1a03fb    	mov	x27, x26
101416420: f9405ffa    	ldr	x26, [sp, #0xb8]
101416424: f85283a1    	ldur	x1, [x29, #-0xd8]
101416428: b4000081    	cbz	x1, 0x101416438 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x67d0>
10141642c: f85303a0    	ldur	x0, [x29, #-0xd0]
101416430: 52800022    	mov	w2, #0x1                ; =1
101416434: 97da20aa    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416438: aa1c03f7    	mov	x23, x28
10141643c: 360001bb    	tbz	w27, #0x0, 0x101416470 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6808>
101416440: b40001d3    	cbz	x19, 0x101416478 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6810>
101416444: f94093e9    	ldr	x9, [sp, #0x120]
101416448: eb09035f    	cmp	x26, x9
10141644c: 540001a0    	b.eq	0x101416480 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6818>
101416450: aa1a03f8    	mov	x24, x26
101416454: f8418708    	ldr	x8, [x24], #0x18
101416458: f9008bf8    	str	x24, [sp, #0x110]
10141645c: eb19011f    	cmp	x8, x25
101416460: 54000bc1    	b.ne	0x1014165d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6970>
101416464: aa1303f6    	mov	x22, x19
101416468: aa1403f3    	mov	x19, x20
10141646c: 14000008    	b	0x10141648c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6824>
101416470: aa1a03f8    	mov	x24, x26
101416474: 14000030    	b	0x101416534 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x68cc>
101416478: aa1a03f8    	mov	x24, x26
10141647c: 1400001e    	b	0x1014164f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x688c>
101416480: aa1303f6    	mov	x22, x19
101416484: aa1403f3    	mov	x19, x20
101416488: aa1a03f8    	mov	x24, x26
10141648c: eb180128    	subs	x8, x9, x24
101416490: 54000200    	b.eq	0x1014164d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6868>
101416494: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
101416498: f2955569    	movk	x9, #0xaaab
10141649c: 9bc97d08    	umulh	x8, x8, x9
1014164a0: d344fd14    	lsr	x20, x8, #4
1014164a4: 91002315    	add	x21, x24, #0x8
1014164a8: 14000004    	b	0x1014164b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6850>
1014164ac: 910062b5    	add	x21, x21, #0x18
1014164b0: f1000694    	subs	x20, x20, #0x1
1014164b4: 540000e0    	b.eq	0x1014164d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6868>
1014164b8: f85f82a1    	ldur	x1, [x21, #-0x8]
1014164bc: b4ffff81    	cbz	x1, 0x1014164ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6844>
1014164c0: f94002a0    	ldr	x0, [x21]
1014164c4: 52800022    	mov	w2, #0x1                ; =1
1014164c8: 97da2085    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014164cc: 17fffff8    	b	0x1014164ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6844>
1014164d0: f9408fe8    	ldr	x8, [sp, #0x118]
1014164d4: b40000c8    	cbz	x8, 0x1014164ec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6884>
1014164d8: 8b080508    	add	x8, x8, x8, lsl #1
1014164dc: d37df101    	lsl	x1, x8, #3
1014164e0: aa1603e0    	mov	x0, x22
1014164e4: 52800102    	mov	w2, #0x8                ; =8
1014164e8: 97da207d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014164ec: f90087ff    	str	xzr, [sp, #0x108]
1014164f0: aa1303f4    	mov	x20, x19
1014164f4: f94097e8    	ldr	x8, [sp, #0x128]
1014164f8: b4000148    	cbz	x8, 0x101416520 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x68b8>
1014164fc: f940a3e8    	ldr	x8, [sp, #0x140]
101416500: eb08029f    	cmp	x20, x8
101416504: 540000e0    	b.eq	0x101416520 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x68b8>
101416508: aa1403e9    	mov	x9, x20
10141650c: f8418528    	ldr	x8, [x9], #0x18
101416510: f9009be9    	str	x9, [sp, #0x130]
101416514: eb19011f    	cmp	x8, x25
101416518: 54000661    	b.ne	0x1014165e4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x697c>
10141651c: aa0903f4    	mov	x20, x9
101416520: 910403e8    	add	x8, sp, #0x100
101416524: b27d0100    	orr	x0, x8, #0x8
101416528: 97ec53dc    	bl	0x100f2b498 <__ZN200_$LT$otty_sync_dotfiles..catalog.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_sync_dotfiles..catalog..CatalogAppSpec$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hace6feb1294ba67fE+0x6bc0>
10141652c: d2800013    	mov	x19, #0x0               ; =0
101416530: f90083ff    	str	xzr, [sp, #0x100]
101416534: f940a7f5    	ldr	x21, [sp, #0x148]
101416538: b40010f5    	cbz	x21, 0x101416754 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6aec>
10141653c: f940b3e8    	ldr	x8, [sp, #0x160]
101416540: eb0802ff    	cmp	x23, x8
101416544: 54001080    	b.eq	0x101416754 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6aec>
101416548: aa1703fc    	mov	x28, x23
10141654c: f8418788    	ldr	x8, [x28], #0x18
101416550: f900abfc    	str	x28, [sp, #0x150]
101416554: eb19011f    	cmp	x8, x25
101416558: 54000fe0    	b.eq	0x101416754 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6aec>
10141655c: d280001b    	mov	x27, #0x0               ; =0
101416560: aa1803fa    	mov	x26, x24
101416564: b0004656    	adrp	x22, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
101416568: 911fe2d6    	add	x22, x22, #0x7f8
10141656c: 528000d5    	mov	w21, #0x6               ; =6
101416570: a94086e0    	ldp	x0, x1, [x23, #0x8]
101416574: a93283a8    	stp	x8, x0, [x29, #-0xd8]
101416578: f81383a1    	stur	x1, [x29, #-0xc8]
10141657c: f94993f8    	ldr	x24, [sp, #0x1320]
101416580: b4000518    	cbz	x24, 0x101416620 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x69b8>
101416584: 912783e8    	add	x8, sp, #0x9e0
101416588: 940fd46b    	bl	0x10180b734 <__ZN5alloc3str21_$LT$impl$u20$str$GT$12to_lowercase17h02b944ce7d5c06f6E>
10141658c: f944f7f7    	ldr	x23, [sp, #0x9e8]
101416590: f944fbe8    	ldr	x8, [sp, #0x9f0]
101416594: eb18011f    	cmp	x8, x24
101416598: 540000c3    	b.lo	0x1014165b0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6948>
10141659c: f9498fe0    	ldr	x0, [sp, #0x1318]
1014165a0: aa1703e1    	mov	x1, x23
1014165a4: aa1803e2    	mov	x2, x24
1014165a8: 941acd9d    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
1014165ac: 340000a0    	cbz	w0, 0x1014165c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6958>
1014165b0: f944f3e1    	ldr	x1, [sp, #0x9e0]
1014165b4: b4000761    	cbz	x1, 0x1014166a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6a38>
1014165b8: aa1703e0    	mov	x0, x23
1014165bc: 14000037    	b	0x101416698 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6a30>
1014165c0: f944f3e1    	ldr	x1, [sp, #0x9e0]
1014165c4: b40002e1    	cbz	x1, 0x101416620 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x69b8>
1014165c8: aa1703e0    	mov	x0, x23
1014165cc: 52800022    	mov	w2, #0x1                ; =1
1014165d0: 97da2043    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014165d4: 14000013    	b	0x101416620 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x69b8>
1014165d8: b0004656    	adrp	x22, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014165dc: 911f92d6    	add	x22, x22, #0x7e4
1014165e0: 14000006    	b	0x1014165f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6990>
1014165e4: d2800013    	mov	x19, #0x0               ; =0
1014165e8: aa1403fa    	mov	x26, x20
1014165ec: b0004656    	adrp	x22, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
1014165f0: 911fbad6    	add	x22, x22, #0x7ee
1014165f4: aa0903f4    	mov	x20, x9
1014165f8: aa1703fc    	mov	x28, x23
1014165fc: aa1a03f7    	mov	x23, x26
101416600: aa1803fa    	mov	x26, x24
101416604: 5280003b    	mov	w27, #0x1               ; =1
101416608: 52800155    	mov	w21, #0xa               ; =10
10141660c: a94086e0    	ldp	x0, x1, [x23, #0x8]
101416610: a93283a8    	stp	x8, x0, [x29, #-0xd8]
101416614: f81383a1    	stur	x1, [x29, #-0xc8]
101416618: f94993f8    	ldr	x24, [sp, #0x1320]
10141661c: b5fffb58    	cbnz	x24, 0x101416584 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x691c>
101416620: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
101416624: 910b8108    	add	x8, x8, #0x2e0
101416628: f904f3e8    	str	x8, [sp, #0x9e0]
10141662c: b00001c8    	adrp	x8, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
101416630: 91117108    	add	x8, x8, #0x45c
101416634: f904f7e8    	str	x8, [sp, #0x9e8]
101416638: d10363a8    	sub	x8, x29, #0xd8
10141663c: f904fbe8    	str	x8, [sp, #0x9f0]
101416640: b00002a8    	adrp	x8, 0x10146b000 <__ZN4core5slice4sort8unstable8heapsort8heapsort17h14b311923aeea277E+0x3bbc>
101416644: 913b4108    	add	x8, x8, #0xed0
101416648: f904ffe8    	str	x8, [sp, #0x9f8]
10141664c: 910303e8    	add	x8, sp, #0xc0
101416650: 912783e1    	add	x1, sp, #0x9e0
101416654: b0005020    	adrp	x0, 0x101e1b000 <_writev+0x101e1b000>
101416658: 9102d000    	add	x0, x0, #0xb4
10141665c: 940fd3c9    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
101416660: 3dc033e0    	ldr	q0, [sp, #0xc0]
101416664: 3c9403a0    	stur	q0, [x29, #-0xc0]
101416668: f9406be8    	ldr	x8, [sp, #0xd0]
10141666c: f81503a8    	stur	x8, [x29, #-0xb0]
101416670: 912783e8    	add	x8, sp, #0x9e0
101416674: d10303a0    	sub	x0, x29, #0xc0
101416678: 940fe2d5    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
10141667c: 9125c3e0    	add	x0, sp, #0x970
101416680: 912783e1    	add	x1, sp, #0x9e0
101416684: 94018132    	bl	0x101476b4c <__ZN99_$LT$otty_autocomplete..fix..rules..SudoRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h9979272d02bfed12E+0xee0>
101416688: 34000120    	cbz	w0, 0x1014166ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6a44>
10141668c: f85403a1    	ldur	x1, [x29, #-0xc0]
101416690: b4000081    	cbz	x1, 0x1014166a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6a38>
101416694: f85483a0    	ldur	x0, [x29, #-0xb8]
101416698: 52800022    	mov	w2, #0x1                ; =1
10141669c: 97da2010    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014166a0: f85283a1    	ldur	x1, [x29, #-0xd8]
1014166a4: b5ffec41    	cbnz	x1, 0x10141642c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x67c4>
1014166a8: 17ffff64    	b	0x101416438 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x67d0>
1014166ac: f9005ffa    	str	x26, [sp, #0xb8]
1014166b0: aa1b03fa    	mov	x26, x27
1014166b4: aa1303fb    	mov	x27, x19
1014166b8: aa1403f3    	mov	x19, x20
1014166bc: a97463b7    	ldp	x23, x24, [x29, #-0xc0]
1014166c0: f85503b4    	ldur	x20, [x29, #-0xb0]
1014166c4: 97da200b    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014166c8: aa1503e0    	mov	x0, x21
1014166cc: 52800021    	mov	w1, #0x1                ; =1
1014166d0: 97da2002    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
1014166d4: b40016a0    	cbz	x0, 0x1014169a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6d40>
1014166d8: aa0003f9    	mov	x25, x0
1014166dc: aa1603e1    	mov	x1, x22
1014166e0: aa1503e2    	mov	x2, x21
1014166e4: 941acd51    	bl	0x101ac9c28 <_writev+0x101ac9c28>
1014166e8: a93663b7    	stp	x23, x24, [x29, #-0xa0]
1014166ec: f81703b4    	stur	x20, [x29, #-0x90]
1014166f0: 910303e8    	add	x8, sp, #0xc0
1014166f4: d10283a0    	sub	x0, x29, #0xa0
1014166f8: 940fe2b5    	bl	0x10180f1cc <__ZN60_$LT$alloc..string..String$u20$as$u20$core..clone..Clone$GT$5clone17h390876fd411fb394E>
1014166fc: f90503f8    	str	x24, [sp, #0xa00]
101416700: f90507f4    	str	x20, [sp, #0xa08]
101416704: 3dc033e0    	ldr	q0, [sp, #0xc0]
101416708: f9406be8    	ldr	x8, [sp, #0xd0]
10141670c: 3d827be0    	str	q0, [sp, #0x9e0]
101416710: f904fff7    	str	x23, [sp, #0x9f8]
101416714: f904fbe8    	str	x8, [sp, #0x9f0]
101416718: f9050bf5    	str	x21, [sp, #0xa10]
10141671c: f9050ff9    	str	x25, [sp, #0xa18]
101416720: f90513f5    	str	x21, [sp, #0xa20]
101416724: d2f00019    	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
101416728: f90517f9    	str	x25, [sp, #0xa28]
10141672c: 52804008    	mov	w8, #0x200              ; =512
101416730: 791483e8    	strh	w8, [sp, #0xa40]
101416734: f9499ff4    	ldr	x20, [sp, #0x1338]
101416738: f94997e8    	ldr	x8, [sp, #0x1328]
10141673c: eb08029f    	cmp	x20, x8
101416740: 54ffe441    	b.ne	0x1014163c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6760>
101416744: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101416748: 910ca000    	add	x0, x0, #0x328
10141674c: 9419e5e6    	bl	0x101a8fee4 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h79ba5ff6649e4cf8E>
101416750: 17ffff1e    	b	0x1014163c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6760>
101416754: f94083e8    	ldr	x8, [sp, #0x100]
101416758: b4000088    	cbz	x8, 0x101416768 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b00>
10141675c: 910403e8    	add	x8, sp, #0x100
101416760: b27d0100    	orr	x0, x8, #0x8
101416764: 97ec534d    	bl	0x100f2b498 <__ZN200_$LT$otty_sync_dotfiles..catalog.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_sync_dotfiles..catalog..CatalogAppSpec$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hace6feb1294ba67fE+0x6bc0>
101416768: b4000375    	cbz	x21, 0x1014167d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b6c>
10141676c: f940abe8    	ldr	x8, [sp, #0x150]
101416770: f940b3e9    	ldr	x9, [sp, #0x160]
101416774: eb080129    	subs	x9, x9, x8
101416778: 54000200    	b.eq	0x1014167b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b50>
10141677c: b201f3ea    	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
101416780: f295556a    	movk	x10, #0xaaab
101416784: 9bca7d29    	umulh	x9, x9, x10
101416788: d344fd33    	lsr	x19, x9, #4
10141678c: 91002114    	add	x20, x8, #0x8
101416790: 14000004    	b	0x1014167a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b38>
101416794: 91006294    	add	x20, x20, #0x18
101416798: f1000673    	subs	x19, x19, #0x1
10141679c: 540000e0    	b.eq	0x1014167b8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b50>
1014167a0: f85f8281    	ldur	x1, [x20, #-0x8]
1014167a4: b4ffff81    	cbz	x1, 0x101416794 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b2c>
1014167a8: f9400280    	ldr	x0, [x20]
1014167ac: 52800022    	mov	w2, #0x1                ; =1
1014167b0: 97da1fcb    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014167b4: 17fffff8    	b	0x101416794 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b2c>
1014167b8: f940afe8    	ldr	x8, [sp, #0x158]
1014167bc: b40000c8    	cbz	x8, 0x1014167d4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6b6c>
1014167c0: 8b080508    	add	x8, x8, x8, lsl #1
1014167c4: d37df101    	lsl	x1, x8, #3
1014167c8: aa1503e0    	mov	x0, x21
1014167cc: 52800102    	mov	w2, #0x8                ; =8
1014167d0: 97da1fc3    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014167d4: f94997f5    	ldr	x21, [sp, #0x1328]
1014167d8: f9499bf3    	ldr	x19, [sp, #0x1330]
1014167dc: f9499ff4    	ldr	x20, [sp, #0x1338]
1014167e0: f944bff6    	ldr	x22, [sp, #0x978]
1014167e4: b4000556    	cbz	x22, 0x10141688c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c24>
1014167e8: f944c7f7    	ldr	x23, [sp, #0x988]
1014167ec: b40003d7    	cbz	x23, 0x101416864 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6bfc>
1014167f0: f944bbf8    	ldr	x24, [sp, #0x970]
1014167f4: aa1803f9    	mov	x25, x24
1014167f8: fc408720    	ldr	d0, [x25], #0x8
1014167fc: 2e208800    	cmge.8b	v0, v0, #0
101416800: 9e660008    	fmov	x8, d0
101416804: 9201c11b    	and	x27, x8, #0x8080808080808080
101416808: 5280031a    	mov	w26, #0x18              ; =24
10141680c: 14000005    	b	0x101416820 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6bb8>
101416810: d1000768    	sub	x8, x27, #0x1
101416814: 8a1b011b    	and	x27, x8, x27
101416818: d10006f7    	sub	x23, x23, #0x1
10141681c: b4000257    	cbz	x23, 0x101416864 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6bfc>
101416820: b50000fb    	cbnz	x27, 0x10141683c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6bd4>
101416824: fc408720    	ldr	d0, [x25], #0x8
101416828: 2e208800    	cmge.8b	v0, v0, #0
10141682c: 9e660008    	fmov	x8, d0
101416830: d1030318    	sub	x24, x24, #0xc0
101416834: 9201c11b    	and	x27, x8, #0x8080808080808080
101416838: b4ffff7b    	cbz	x27, 0x101416824 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6bbc>
10141683c: dac00368    	rbit	x8, x27
101416840: dac01108    	clz	x8, x8
101416844: cb480fe8    	neg	x8, x8, lsr #3
101416848: 9b3a6108    	smaddl	x8, w8, w26, x24
10141684c: f85e8101    	ldur	x1, [x8, #-0x18]
101416850: b4fffe01    	cbz	x1, 0x101416810 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6ba8>
101416854: f85f0100    	ldur	x0, [x8, #-0x10]
101416858: 52800022    	mov	w2, #0x1                ; =1
10141685c: 97da1fa0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416860: 17ffffec    	b	0x101416810 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6ba8>
101416864: 8b1606c8    	add	x8, x22, x22, lsl #1
101416868: d37df108    	lsl	x8, x8, #3
10141686c: 8b160109    	add	x9, x8, x22
101416870: b1008521    	adds	x1, x9, #0x21
101416874: 540000c0    	b.eq	0x10141688c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c24>
101416878: f944bbe9    	ldr	x9, [sp, #0x970]
10141687c: cb080128    	sub	x8, x9, x8
101416880: d1006100    	sub	x0, x8, #0x18
101416884: 52800102    	mov	w2, #0x8                ; =8
101416888: 97da1f95    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141688c: f9498be1    	ldr	x1, [sp, #0x1310]
101416890: b4000081    	cbz	x1, 0x1014168a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c38>
101416894: f9498fe0    	ldr	x0, [sp, #0x1318]
101416898: 52800022    	mov	w2, #0x1                ; =1
10141689c: 97da1f90    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014168a0: f9497fe1    	ldr	x1, [sp, #0x12f8]
1014168a4: f240f83f    	tst	x1, #0x7fffffffffffffff
1014168a8: f94037f7    	ldr	x23, [sp, #0x68]
1014168ac: 54000080    	b.eq	0x1014168bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6c54>
1014168b0: f94983e0    	ldr	x0, [sp, #0x1300]
1014168b4: 52800022    	mov	w2, #0x1                ; =1
1014168b8: 97da1f89    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014168bc: a9004ef5    	stp	x21, x19, [x23]
1014168c0: f9000af4    	str	x20, [x23, #0x10]
1014168c4: 914007ff    	add	sp, sp, #0x1, lsl #12   ; =0x1000
1014168c8: 910f03ff    	add	sp, sp, #0x3c0
1014168cc: a9477bfd    	ldp	x29, x30, [sp, #0x70]
1014168d0: a9464ff4    	ldp	x20, x19, [sp, #0x60]
1014168d4: a94557f6    	ldp	x22, x21, [sp, #0x50]
1014168d8: a9445ff8    	ldp	x24, x23, [sp, #0x40]
1014168dc: a94367fa    	ldp	x26, x25, [sp, #0x30]
1014168e0: a9426ffc    	ldp	x28, x27, [sp, #0x20]
1014168e4: 6d4123e9    	ldp	d9, d8, [sp, #0x10]
1014168e8: 6cc82beb    	ldp	d11, d10, [sp], #0x80
1014168ec: d65f03c0    	ret
1014168f0: 940ea426    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
1014168f4: f9000661    	str	x1, [x19, #0x8]
1014168f8: 52800028    	mov	w8, #0x1                ; =1
1014168fc: 39004268    	strb	w8, [x19, #0x10]
101416900: 17fffe94    	b	0x101416350 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x66e8>
101416904: 940ea421    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101416908: f90057e1    	str	x1, [sp, #0xa8]
10141690c: aa0003f4    	mov	x20, x0
101416910: f94057e8    	ldr	x8, [sp, #0xa8]
101416914: f9000748    	str	x8, [x26, #0x8]
101416918: 52800028    	mov	w8, #0x1                ; =1
10141691c: 39004348    	strb	w8, [x26, #0x10]
101416920: 17ffed6c    	b	0x101411ed0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2268>
101416924: 940ea419    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101416928: f9000681    	str	x1, [x20, #0x8]
10141692c: 52800028    	mov	w8, #0x1                ; =1
101416930: 39004288    	strb	w8, [x20, #0x10]
101416934: 17ffef90    	b	0x101412774 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2b0c>
101416938: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10141693c: 91094108    	add	x8, x8, #0x250
101416940: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101416944: 91094000    	add	x0, x0, #0x250
101416948: 91008102    	add	x2, x8, #0x20
10141694c: aa1303e1    	mov	x1, x19
101416950: 52800023    	mov	w3, #0x1                ; =1
101416954: 941a7615    	bl	0x101ab41a8 <__ZN9hashbrown3raw21RawTable$LT$T$C$A$GT$14reserve_rehash17h8ad6e75f269338c4E>
101416958: 17ffef91    	b	0x10141279c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2b34>
10141695c: 940ea40b    	bl	0x1017bf988 <__ZN3std3sys6random19hashmap_random_keys17h29b3be0077be9613E>
101416960: f9000681    	str	x1, [x20, #0x8]
101416964: 52800028    	mov	w8, #0x1                ; =1
101416968: 39004288    	strb	w8, [x20, #0x10]
10141696c: 17fff2ce    	b	0x1014134a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x383c>
101416970: d0007282    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101416974: 91216042    	add	x2, x2, #0x858
101416978: f9405fe1    	ldr	x1, [sp, #0xb8]
10141697c: 941ab4f0    	bl	0x101ac3d3c <__ZN4core9panicking18panic_bounds_check17hd6142ed38f8c399dE>
101416980: 52800020    	mov	w0, #0x1                ; =1
101416984: aa1403e1    	mov	x1, x20
101416988: 941ab27b    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10141698c: 140000c3    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416990: f100567f    	cmp	x19, #0x15
101416994: 54001082    	b.hs	0x101416ba4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6f3c>
101416998: aa1403e0    	mov	x0, x20
10141699c: aa1303e1    	mov	x1, x19
1014169a0: 94010a0b    	bl	0x1014591cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbd44>
1014169a4: 17fff820    	b	0x101414a24 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4dbc>
1014169a8: 52800020    	mov	w0, #0x1                ; =1
1014169ac: aa1503e1    	mov	x1, x21
1014169b0: 941ab271    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014169b4: 140000b9    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
1014169b8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014169bc: 91094000    	add	x0, x0, #0x250
1014169c0: d2800001    	mov	x1, #0x0                ; =0
1014169c4: 52800103    	mov	w3, #0x8                ; =8
1014169c8: 52800304    	mov	w4, #0x18               ; =24
1014169cc: 941847a1    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
1014169d0: f94933e8    	ldr	x8, [sp, #0x1260]
1014169d4: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1014169d8: eb09029f    	cmp	x20, x9
1014169dc: 54ff0481    	b.ne	0x101414a6c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e04>
1014169e0: 17fff829    	b	0x101414a84 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4e1c>
1014169e4: 52800100    	mov	w0, #0x8                ; =8
1014169e8: 52800d01    	mov	w1, #0x68               ; =104
1014169ec: 941ab262    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
1014169f0: 140000aa    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
1014169f4: f904f7fb    	str	x27, [sp, #0x9e8]
1014169f8: f90503ff    	str	xzr, [sp, #0xa00]
1014169fc: 52800020    	mov	w0, #0x1                ; =1
101416a00: 528000c1    	mov	w1, #0x6                ; =6
101416a04: 941ab25c    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416a08: 140000a4    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416a0c: d0007282    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101416a10: 91210042    	add	x2, x2, #0x840
101416a14: d2800000    	mov	x0, #0x0                ; =0
101416a18: d2800001    	mov	x1, #0x0                ; =0
101416a1c: 941ab4c8    	bl	0x101ac3d3c <__ZN4core9panicking18panic_bounds_check17hd6142ed38f8c399dE>
101416a20: 1400009e    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416a24: 52800100    	mov	w0, #0x8                ; =8
101416a28: 52803401    	mov	w1, #0x1a0              ; =416
101416a2c: 941ab252    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416a30: 1400009a    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416a34: 910403e2    	add	x2, sp, #0x100
101416a38: aa1403e0    	mov	x0, x20
101416a3c: aa1503e1    	mov	x1, x21
101416a40: 94010d62    	bl	0x101459fc8 <__ZN4core5slice4sort6stable14driftsort_main17h86247584ffefca32E>
101416a44: f112c27f    	cmp	x19, #0x4b0
101416a48: f9405ff9    	ldr	x25, [sp, #0xb8]
101416a4c: 54fceba3    	b.lo	0x1014107c0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xb58>
101416a50: 9112c297    	add	x23, x20, #0x4b0
101416a54: f100cab3    	subs	x19, x21, #0x32
101416a58: 54000300    	b.eq	0x101416ab8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6e50>
101416a5c: 9112e295    	add	x21, x20, #0x4b8
101416a60: 14000004    	b	0x101416a70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6e08>
101416a64: 910062b5    	add	x21, x21, #0x18
101416a68: f1000673    	subs	x19, x19, #0x1
101416a6c: 54000260    	b.eq	0x101416ab8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6e50>
101416a70: f85f82a1    	ldur	x1, [x21, #-0x8]
101416a74: b4ffff81    	cbz	x1, 0x101416a64 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6dfc>
101416a78: f94002a0    	ldr	x0, [x21]
101416a7c: 52800022    	mov	w2, #0x1                ; =1
101416a80: 97da1f17    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416a84: 17fffff8    	b	0x101416a64 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6dfc>
101416a88: f100571f    	cmp	x24, #0x15
101416a8c: 54000b02    	b.hs	0x101416bec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6f84>
101416a90: aa1703e0    	mov	x0, x23
101416a94: aa1803e1    	mov	x1, x24
101416a98: 940109cd    	bl	0x1014591cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0xbd44>
101416a9c: 17fffd67    	b	0x101416038 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x63d0>
101416aa0: f100573f    	cmp	x25, #0x15
101416aa4: 54000ae2    	b.hs	0x101416c00 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x6f98>
101416aa8: f94047e0    	ldr	x0, [sp, #0x88]
101416aac: aa1903e1    	mov	x1, x25
101416ab0: 97d4e613    	bl	0x1009502fc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x3d2d4>
101416ab4: 17fffc21    	b	0x101415b38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5ed0>
101416ab8: 52828a16    	mov	w22, #0x1450            ; =5200
101416abc: 52800655    	mov	w21, #0x32              ; =50
101416ac0: f9405ff9    	ldr	x25, [sp, #0xb8]
101416ac4: 97da1f0b    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101416ac8: aa1603e0    	mov	x0, x22
101416acc: 52800101    	mov	w1, #0x8                ; =8
101416ad0: 97da1f02    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
101416ad4: b5fce880    	cbnz	x0, 0x1014107e4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xb7c>
101416ad8: 52800100    	mov	w0, #0x8                ; =8
101416adc: aa1603e1    	mov	x1, x22
101416ae0: 941ab225    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416ae4: 1400006d    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416ae8: 52800100    	mov	w0, #0x8                ; =8
101416aec: 52803401    	mov	w1, #0x1a0              ; =416
101416af0: 941ab221    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416af4: 14000069    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416af8: 914007e2    	add	x2, sp, #0x1, lsl #12   ; =0x1000
101416afc: 91094042    	add	x2, x2, #0x250
101416b00: aa1703e0    	mov	x0, x23
101416b04: aa1803e1    	mov	x1, x24
101416b08: 94010eae    	bl	0x10145a5c0 <__ZN4core5slice4sort6stable14driftsort_main17hd0839377c8e61f05E>
101416b0c: 17ffee57    	b	0x101412468 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2800>
101416b10: f9093bf6    	str	x22, [sp, #0x1270]
101416b14: f9092ff8    	str	x24, [sp, #0x1258]
101416b18: 52800020    	mov	w0, #0x1                ; =1
101416b1c: aa1b03e1    	mov	x1, x27
101416b20: 941ab215    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416b24: 1400005d    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416b28: d0007282    	adrp	x2, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101416b2c: 91222042    	add	x2, x2, #0x888
101416b30: aa0003e1    	mov	x1, x0
101416b34: 941ab482    	bl	0x101ac3d3c <__ZN4core9panicking18panic_bounds_check17hd6142ed38f8c399dE>
101416b38: 52800100    	mov	w0, #0x8                ; =8
101416b3c: 52803401    	mov	w1, #0x1a0              ; =416
101416b40: 941ab20d    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416b44: 14000055    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416b48: 52800100    	mov	w0, #0x8                ; =8
101416b4c: 52803401    	mov	w1, #0x1a0              ; =416
101416b50: 941ab209    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416b54: 14000051    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416b58: 52800020    	mov	w0, #0x1                ; =1
101416b5c: aa1a03e1    	mov	x1, x26
101416b60: 941ab205    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416b64: 1400004d    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416b68: d0007284    	adrp	x4, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101416b6c: 9121c084    	add	x4, x4, #0x870
101416b70: aa1303e0    	mov	x0, x19
101416b74: aa1503e1    	mov	x1, x21
101416b78: aa1403e2    	mov	x2, x20
101416b7c: aa1503e3    	mov	x3, x21
101416b80: 941ab2a2    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
101416b84: 52800100    	mov	w0, #0x8                ; =8
101416b88: 52800c01    	mov	w1, #0x60               ; =96
101416b8c: 941ab1fa    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416b90: 14000042    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416b94: 52800100    	mov	w0, #0x8                ; =8
101416b98: 52803401    	mov	w1, #0x1a0              ; =416
101416b9c: 941ab1f6    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416ba0: 1400003e    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416ba4: 914007e2    	add	x2, sp, #0x1, lsl #12   ; =0x1000
101416ba8: 91094042    	add	x2, x2, #0x250
101416bac: aa1403e0    	mov	x0, x20
101416bb0: aa1303e1    	mov	x1, x19
101416bb4: 94010ba1    	bl	0x101459a38 <__ZN4core5slice4sort6stable14driftsort_main17h09f3fb579065c468E>
101416bb8: 17fff79b    	b	0x101414a24 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x4dbc>
101416bbc: 52800020    	mov	w0, #0x1                ; =1
101416bc0: aa1403e1    	mov	x1, x20
101416bc4: 941ab1ec    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416bc8: 14000034    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416bcc: 52800100    	mov	w0, #0x8                ; =8
101416bd0: 52803401    	mov	w1, #0x1a0              ; =416
101416bd4: 941ab1e8    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416bd8: 14000030    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416bdc: 52800100    	mov	w0, #0x8                ; =8
101416be0: 52800c01    	mov	w1, #0x60               ; =96
101416be4: 941ab1e4    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416be8: 1400002c    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416bec: 910403e2    	add	x2, sp, #0x100
101416bf0: aa1703e0    	mov	x0, x23
101416bf4: aa1803e1    	mov	x1, x24
101416bf8: 94010d90    	bl	0x10145a238 <__ZN4core5slice4sort6stable14driftsort_main17had64d1eda71ae686E>
101416bfc: 17fffd0f    	b	0x101416038 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x63d0>
101416c00: 912783e2    	add	x2, sp, #0x9e0
101416c04: f94047e0    	ldr	x0, [sp, #0x88]
101416c08: aa1903e1    	mov	x1, x25
101416c0c: 9407d052    	bl	0x10160ad54 <__ZN4core5slice4sort6stable14driftsort_main17h1e762a7023a11e2bE>
101416c10: 17fffbca    	b	0x101415b38 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5ed0>
101416c14: 52800020    	mov	w0, #0x1                ; =1
101416c18: aa1b03e1    	mov	x1, x27
101416c1c: 941ab1d6    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416c20: 1400001e    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416c24: 52800020    	mov	w0, #0x1                ; =1
101416c28: aa1903e1    	mov	x1, x25
101416c2c: 941ab1d2    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416c30: 1400001a    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416c34: d0007284    	adrp	x4, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101416c38: 91228084    	add	x4, x4, #0x8a0
101416c3c: aa1303e0    	mov	x0, x19
101416c40: aa1403e1    	mov	x1, x20
101416c44: d2800002    	mov	x2, #0x0                ; =0
101416c48: 941ab270    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
101416c4c: 14000013    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416c50: d1000723    	sub	x3, x25, #0x1
101416c54: d0007284    	adrp	x4, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
101416c58: 9122e084    	add	x4, x4, #0x8b8
101416c5c: aa1703e0    	mov	x0, x23
101416c60: aa1903e1    	mov	x1, x25
101416c64: 52800022    	mov	w2, #0x1                ; =1
101416c68: 941ab268    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
101416c6c: 1400000b    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416c70: 52800100    	mov	w0, #0x8                ; =8
101416c74: 52800c01    	mov	w1, #0x60               ; =96
101416c78: 941ab1bf    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
101416c7c: 14000007    	b	0x101416c98 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7030>
101416c80: 900072a3    	adrp	x3, 0x10226a000 <__ZN17otty_autocomplete3fix5rules10CODE_RULES17hbcc86d8abd77fc03E+0x12a0>
101416c84: 9113c063    	add	x3, x3, #0x4f0
101416c88: d2800000    	mov	x0, #0x0                ; =0
101416c8c: aa1503e1    	mov	x1, x21
101416c90: 52800082    	mov	w2, #0x4                ; =4
101416c94: 941ab2f5    	bl	0x101ac3868 <__ZN4core5slice5index16slice_index_fail17h88b945c1204cb3a0E>
101416c98: d4200020    	brk	#0x1
101416c9c: f9004be0    	str	x0, [sp, #0x90]
101416ca0: 912783e0    	add	x0, sp, #0x9e0
101416ca4: 14000132    	b	0x10141716c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7504>
101416ca8: f9004be0    	str	x0, [sp, #0x90]
101416cac: 912783e0    	add	x0, sp, #0x9e0
101416cb0: 14000372    	b	0x101417a78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e10>
101416cb4: f9004be0    	str	x0, [sp, #0x90]
101416cb8: 912783e0    	add	x0, sp, #0x9e0
101416cbc: 140002f5    	b	0x101417890 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c28>
101416cc0: f9004be0    	str	x0, [sp, #0x90]
101416cc4: d10303a0    	sub	x0, x29, #0xc0
101416cc8: 97d4af91    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101416ccc: 14000362    	b	0x101417a54 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7dec>
101416cd0: 1400005e    	b	0x101416e48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x71e0>
101416cd4: f9004be0    	str	x0, [sp, #0x90]
101416cd8: f240fa9f    	tst	x20, #0x7fffffffffffffff
101416cdc: 54001be0    	b.eq	0x101417058 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x73f0>
101416ce0: aa1303e0    	mov	x0, x19
101416ce4: aa1403e1    	mov	x1, x20
101416ce8: 140000b3    	b	0x101416fb4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x734c>
101416cec: f9004be0    	str	x0, [sp, #0x90]
101416cf0: aa1303e0    	mov	x0, x19
101416cf4: aa1903e1    	mov	x1, x25
101416cf8: 52800022    	mov	w2, #0x1                ; =1
101416cfc: 97da1e78    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416d00: 14000053    	b	0x101416e4c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x71e4>
101416d04: f9004be0    	str	x0, [sp, #0x90]
101416d08: b40029d3    	cbz	x19, 0x101417240 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d8>
101416d0c: aa1403e0    	mov	x0, x20
101416d10: aa1303e1    	mov	x1, x19
101416d14: 14000045    	b	0x101416e28 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x71c0>
101416d18: f9004be0    	str	x0, [sp, #0x90]
101416d1c: 1400022f    	b	0x1014175d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7970>
101416d20: f9004be0    	str	x0, [sp, #0x90]
101416d24: 910303e0    	add	x0, sp, #0xc0
101416d28: 97d468b8    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101416d2c: 1400029b    	b	0x101417798 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b30>
101416d30: f9004be0    	str	x0, [sp, #0x90]
101416d34: 910303e0    	add	x0, sp, #0xc0
101416d38: 97d468b4    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101416d3c: 1400029a    	b	0x1014177a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b3c>
101416d40: f9004be0    	str	x0, [sp, #0x90]
101416d44: f9400681    	ldr	x1, [x20, #0x8]
101416d48: b4000081    	cbz	x1, 0x101416d58 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x70f0>
101416d4c: f9400a82    	ldr	x2, [x20, #0x10]
101416d50: aa1303e0    	mov	x0, x19
101416d54: 97da1e62    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416d58: aa1603e0    	mov	x0, x22
101416d5c: 52800301    	mov	w1, #0x18               ; =24
101416d60: 52800102    	mov	w2, #0x8                ; =8
101416d64: 97da1e5e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416d68: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101416d6c: 910b2000    	add	x0, x0, #0x2c8
101416d70: 97d4af67    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101416d74: f9404be0    	ldr	x0, [sp, #0x90]
101416d78: 941aca17    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101416d7c: 14000033    	b	0x101416e48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x71e0>
101416d80: 14000001    	b	0x101416d84 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x711c>
101416d84: f9004be0    	str	x0, [sp, #0x90]
101416d88: f94083e1    	ldr	x1, [sp, #0x100]
101416d8c: b40025a1    	cbz	x1, 0x101417240 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d8>
101416d90: f94087e0    	ldr	x0, [sp, #0x108]
101416d94: 14000025    	b	0x101416e28 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x71c0>
101416d98: f9004be0    	str	x0, [sp, #0x90]
101416d9c: f94006e1    	ldr	x1, [x23, #0x8]
101416da0: b4000081    	cbz	x1, 0x101416db0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7148>
101416da4: f9400ae2    	ldr	x2, [x23, #0x10]
101416da8: aa1403e0    	mov	x0, x20
101416dac: 97da1e4c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416db0: aa1303e0    	mov	x0, x19
101416db4: 52800301    	mov	w1, #0x18               ; =24
101416db8: 52800102    	mov	w2, #0x8                ; =8
101416dbc: 1400013b    	b	0x1014172a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7640>
101416dc0: f9004be0    	str	x0, [sp, #0x90]
101416dc4: b40005b6    	cbz	x22, 0x101416e78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7210>
101416dc8: aa1903e0    	mov	x0, x25
101416dcc: aa1603e1    	mov	x1, x22
101416dd0: 52800022    	mov	w2, #0x1                ; =1
101416dd4: 97da1e42    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416dd8: 14000028    	b	0x101416e78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7210>
101416ddc: f9004be0    	str	x0, [sp, #0x90]
101416de0: 140000d9    	b	0x101417144 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x74dc>
101416de4: f9004be0    	str	x0, [sp, #0x90]
101416de8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101416dec: 910b2000    	add	x0, x0, #0x2c8
101416df0: 97d4af47    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101416df4: f9404be0    	ldr	x0, [sp, #0x90]
101416df8: 941ac9f7    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101416dfc: f9004be0    	str	x0, [sp, #0x90]
101416e00: 52800033    	mov	w19, #0x1               ; =1
101416e04: 140002c9    	b	0x101417928 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7cc0>
101416e08: f9004be0    	str	x0, [sp, #0x90]
101416e0c: 910403e0    	add	x0, sp, #0x100
101416e10: 97db9a32    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101416e14: 140000d7    	b	0x101417170 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7508>
101416e18: f9004be0    	str	x0, [sp, #0x90]
101416e1c: b4002134    	cbz	x20, 0x101417240 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d8>
101416e20: aa1303e0    	mov	x0, x19
101416e24: aa1403e1    	mov	x1, x20
101416e28: 52800022    	mov	w2, #0x1                ; =1
101416e2c: 97da1e2c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416e30: 14000104    	b	0x101417240 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d8>
101416e34: f9004be0    	str	x0, [sp, #0x90]
101416e38: f9092ff5    	str	x21, [sp, #0x1258]
101416e3c: 912783e0    	add	x0, sp, #0x9e0
101416e40: 97db9a26    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101416e44: 14000036    	b	0x101416f1c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x72b4>
101416e48: f9004be0    	str	x0, [sp, #0x90]
101416e4c: 910303e0    	add	x0, sp, #0xc0
101416e50: 97d4af2f    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101416e54: 140000fb    	b	0x101417240 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d8>
101416e58: f9004be0    	str	x0, [sp, #0x90]
101416e5c: 140002d5    	b	0x1014179b0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d48>
101416e60: f9004be0    	str	x0, [sp, #0x90]
101416e64: 140000a2    	b	0x1014170ec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7484>
101416e68: f9004be0    	str	x0, [sp, #0x90]
101416e6c: 52800033    	mov	w19, #0x1               ; =1
101416e70: 14000098    	b	0x1014170d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7468>
101416e74: f9004be0    	str	x0, [sp, #0x90]
101416e78: 910403e0    	add	x0, sp, #0x100
101416e7c: 9400fc46    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
101416e80: 140000b3    	b	0x10141714c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x74e4>
101416e84: 941ab3a8    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101416e88: f9004be0    	str	x0, [sp, #0x90]
101416e8c: f9400681    	ldr	x1, [x20, #0x8]
101416e90: b4002e81    	cbz	x1, 0x101417460 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77f8>
101416e94: f9400a82    	ldr	x2, [x20, #0x10]
101416e98: aa1303e0    	mov	x0, x19
101416e9c: 14000170    	b	0x10141745c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77f4>
101416ea0: 140000e7    	b	0x10141723c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d4>
101416ea4: f9004be0    	str	x0, [sp, #0x90]
101416ea8: f94006e1    	ldr	x1, [x23, #0x8]
101416eac: b4000081    	cbz	x1, 0x101416ebc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7254>
101416eb0: f9400ae2    	ldr	x2, [x23, #0x10]
101416eb4: aa1403e0    	mov	x0, x20
101416eb8: 97da1e09    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416ebc: aa1303e0    	mov	x0, x19
101416ec0: 52800301    	mov	w1, #0x18               ; =24
101416ec4: 52800102    	mov	w2, #0x8                ; =8
101416ec8: 97da1e05    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416ecc: 140000d5    	b	0x101417220 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75b8>
101416ed0: f9004be0    	str	x0, [sp, #0x90]
101416ed4: f9092ff5    	str	x21, [sp, #0x1258]
101416ed8: b40000b9    	cbz	x25, 0x101416eec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7284>
101416edc: aa1a03e0    	mov	x0, x26
101416ee0: aa1903e1    	mov	x1, x25
101416ee4: 52800022    	mov	w2, #0x1                ; =1
101416ee8: 97da1dfd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416eec: f240fb9f    	tst	x28, #0x7fffffffffffffff
101416ef0: 54000160    	b.eq	0x101416f1c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x72b4>
101416ef4: aa1803e0    	mov	x0, x24
101416ef8: aa1c03e1    	mov	x1, x28
101416efc: 14000006    	b	0x101416f14 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x72ac>
101416f00: f9004be0    	str	x0, [sp, #0x90]
101416f04: f9092ff5    	str	x21, [sp, #0x1258]
101416f08: b40000b9    	cbz	x25, 0x101416f1c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x72b4>
101416f0c: aa1a03e0    	mov	x0, x26
101416f10: aa1903e1    	mov	x1, x25
101416f14: 52800022    	mov	w2, #0x1                ; =1
101416f18: 97da1df1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416f1c: f94043e8    	ldr	x8, [sp, #0x80]
101416f20: f240f91f    	tst	x8, #0x7fffffffffffffff
101416f24: 54000340    	b.eq	0x101416f8c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7324>
101416f28: aa1703e0    	mov	x0, x23
101416f2c: f94043e1    	ldr	x1, [sp, #0x80]
101416f30: 14000006    	b	0x101416f48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x72e0>
101416f34: f9004be0    	str	x0, [sp, #0x90]
101416f38: f9092ff5    	str	x21, [sp, #0x1258]
101416f3c: b4000299    	cbz	x25, 0x101416f8c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7324>
101416f40: aa1a03e0    	mov	x0, x26
101416f44: aa1903e1    	mov	x1, x25
101416f48: 52800022    	mov	w2, #0x1                ; =1
101416f4c: 97da1de4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416f50: 1400000f    	b	0x101416f8c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7324>
101416f54: f9004be0    	str	x0, [sp, #0x90]
101416f58: f9092ff5    	str	x21, [sp, #0x1258]
101416f5c: f94063e1    	ldr	x1, [sp, #0xc0]
101416f60: b50001a1    	cbnz	x1, 0x101416f94 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x732c>
101416f64: 1400004a    	b	0x10141708c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7424>
101416f68: 140000b5    	b	0x10141723c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75d4>
101416f6c: 1400003a    	b	0x101417054 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x73ec>
101416f70: 140002c0    	b	0x101417a70 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e08>
101416f74: f9004be0    	str	x0, [sp, #0x90]
101416f78: 9125c3e0    	add	x0, sp, #0x970
101416f7c: 97db99d7    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101416f80: 1400002a    	b	0x101417028 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x73c0>
101416f84: f9004be0    	str	x0, [sp, #0x90]
101416f88: f9092ff5    	str	x21, [sp, #0x1258]
101416f8c: f85403a1    	ldur	x1, [x29, #-0xc0]
101416f90: b40007e1    	cbz	x1, 0x10141708c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7424>
101416f94: aa1303e0    	mov	x0, x19
101416f98: 52800022    	mov	w2, #0x1                ; =1
101416f9c: 97da1dd0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416fa0: 1400003b    	b	0x10141708c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7424>
101416fa4: f9004be0    	str	x0, [sp, #0x90]
101416fa8: b4000595    	cbz	x21, 0x101417058 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x73f0>
101416fac: aa1603e0    	mov	x0, x22
101416fb0: aa1503e1    	mov	x1, x21
101416fb4: 52800022    	mov	w2, #0x1                ; =1
101416fb8: 97da1dc9    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416fbc: 14000027    	b	0x101417058 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x73f0>
101416fc0: f9004be0    	str	x0, [sp, #0x90]
101416fc4: 1400006b    	b	0x101417170 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7508>
101416fc8: f9004be0    	str	x0, [sp, #0x90]
101416fcc: b4002d93    	cbz	x19, 0x10141757c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7914>
101416fd0: aa1503e0    	mov	x0, x21
101416fd4: aa1303e1    	mov	x1, x19
101416fd8: 52800022    	mov	w2, #0x1                ; =1
101416fdc: 97da1dc0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101416fe0: 910403e0    	add	x0, sp, #0x100
101416fe4: 9400f832    	bl	0x1014550ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7c24>
101416fe8: f9404be0    	ldr	x0, [sp, #0x90]
101416fec: 941ac97a    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101416ff0: 14000123    	b	0x10141747c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7814>
101416ff4: f9004be0    	str	x0, [sp, #0x90]
101416ff8: 912783e0    	add	x0, sp, #0x9e0
101416ffc: 9400ef57    	bl	0x101452d58 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x58d0>
101417000: 14000276    	b	0x1014179d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d70>
101417004: f9004be0    	str	x0, [sp, #0x90]
101417008: 14000120    	b	0x101417488 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7820>
10141700c: f9004be0    	str	x0, [sp, #0x90]
101417010: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101417014: 910b2000    	add	x0, x0, #0x2c8
101417018: 97d4aebd    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10141701c: f9404be0    	ldr	x0, [sp, #0x90]
101417020: 941ac96d    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417024: f9004be0    	str	x0, [sp, #0x90]
101417028: 910403e0    	add	x0, sp, #0x100
10141702c: 9400fbda    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
101417030: 14000293    	b	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417034: 941ab33c    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101417038: f9004be0    	str	x0, [sp, #0x90]
10141703c: b4000819    	cbz	x25, 0x10141713c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x74d4>
101417040: aa1a03e0    	mov	x0, x26
101417044: aa1903e1    	mov	x1, x25
101417048: 52800022    	mov	w2, #0x1                ; =1
10141704c: 97da1da4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417050: 1400003b    	b	0x10141713c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x74d4>
101417054: f9004be0    	str	x0, [sp, #0x90]
101417058: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10141705c: 91094000    	add	x0, x0, #0x250
101417060: 97d4aeab    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101417064: 910403e0    	add	x0, sp, #0x100
101417068: 9400f811    	bl	0x1014550ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7c24>
10141706c: f9404be0    	ldr	x0, [sp, #0x90]
101417070: 941ac959    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417074: f9004be0    	str	x0, [sp, #0x90]
101417078: 912783e0    	add	x0, sp, #0x9e0
10141707c: 97db9997    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101417080: 1400003a    	b	0x101417168 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7500>
101417084: f9004be0    	str	x0, [sp, #0x90]
101417088: f9092ff5    	str	x21, [sp, #0x1258]
10141708c: f85283a1    	ldur	x1, [x29, #-0xd8]
101417090: b4000081    	cbz	x1, 0x1014170a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7438>
101417094: f85303a0    	ldur	x0, [x29, #-0xd0]
101417098: 52800022    	mov	w2, #0x1                ; =1
10141709c: 97da1d90    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014170a0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014170a4: 91094000    	add	x0, x0, #0x250
1014170a8: 97d467d8    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
1014170ac: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014170b0: 910ca000    	add	x0, x0, #0x328
1014170b4: 9400fb6c    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
1014170b8: f9498be1    	ldr	x1, [sp, #0x1310]
1014170bc: b4000081    	cbz	x1, 0x1014170cc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7464>
1014170c0: f9498fe0    	ldr	x0, [sp, #0x1318]
1014170c4: 52800022    	mov	w2, #0x1                ; =1
1014170c8: 97da1d85    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014170cc: 52800013    	mov	w19, #0x0               ; =0
1014170d0: f9497fe1    	ldr	x1, [sp, #0x12f8]
1014170d4: f240f83f    	tst	x1, #0x7fffffffffffffff
1014170d8: 54000080    	b.eq	0x1014170e8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7480>
1014170dc: f94983e0    	ldr	x0, [sp, #0x1300]
1014170e0: 52800022    	mov	w2, #0x1                ; =1
1014170e4: 97da1d7e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014170e8: 36000333    	tbz	w19, #0x0, 0x10141714c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x74e4>
1014170ec: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014170f0: 910b8000    	add	x0, x0, #0x2e0
1014170f4: 97d4ae86    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
1014170f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014170fc: 910b2000    	add	x0, x0, #0x2c8
101417100: 97d4ae83    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101417104: f9404be0    	ldr	x0, [sp, #0x90]
101417108: 941ac933    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10141710c: f9004be0    	str	x0, [sp, #0x90]
101417110: aa1703e0    	mov	x0, x23
101417114: aa1a03e1    	mov	x1, x26
101417118: 52800022    	mov	w2, #0x1                ; =1
10141711c: 97da1d70    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417120: 1400018e    	b	0x101417758 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7af0>
101417124: f9004be0    	str	x0, [sp, #0x90]
101417128: 14000061    	b	0x1014172ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7644>
10141712c: 140000fb    	b	0x101417518 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x78b0>
101417130: f9004be0    	str	x0, [sp, #0x90]
101417134: 14000011    	b	0x101417178 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7510>
101417138: f9004be0    	str	x0, [sp, #0x90]
10141713c: 912783e0    	add	x0, sp, #0x9e0
101417140: 9400fb95    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
101417144: 9125c3e0    	add	x0, sp, #0x970
101417148: 97d4ae71    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10141714c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101417150: 910b2000    	add	x0, x0, #0x2c8
101417154: 97d4ae6e    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101417158: f9404be0    	ldr	x0, [sp, #0x90]
10141715c: 941ac91e    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417160: 941ab2f1    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101417164: f9004be0    	str	x0, [sp, #0x90]
101417168: d10283a0    	sub	x0, x29, #0xa0
10141716c: 9400fb3e    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417170: 910303e0    	add	x0, sp, #0xc0
101417174: 9400f156    	bl	0x1014536cc <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x6244>
101417178: b4000559    	cbz	x25, 0x101417220 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75b8>
10141717c: aa1403e0    	mov	x0, x20
101417180: aa1903e1    	mov	x1, x25
101417184: 52800022    	mov	w2, #0x1                ; =1
101417188: 97da1d55    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141718c: 14000025    	b	0x101417220 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75b8>
101417190: 941ab2e5    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101417194: f9004be0    	str	x0, [sp, #0x90]
101417198: f94006e1    	ldr	x1, [x23, #0x8]
10141719c: b4001621    	cbz	x1, 0x101417460 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77f8>
1014171a0: f9400ae2    	ldr	x2, [x23, #0x10]
1014171a4: aa1803e0    	mov	x0, x24
1014171a8: 140000ad    	b	0x10141745c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77f4>
1014171ac: 1400016a    	b	0x101417754 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7aec>
1014171b0: f9004be0    	str	x0, [sp, #0x90]
1014171b4: f9093bf6    	str	x22, [sp, #0x1270]
1014171b8: f9092ff8    	str	x24, [sp, #0x1258]
1014171bc: 912783e0    	add	x0, sp, #0x9e0
1014171c0: 97db9946    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014171c4: 140000f9    	b	0x1014175a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7940>
1014171c8: f9004be0    	str	x0, [sp, #0x90]
1014171cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014171d0: 91094000    	add	x0, x0, #0x250
1014171d4: 97db9941    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014171d8: 910303e0    	add	x0, sp, #0xc0
1014171dc: 97d4678b    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
1014171e0: 910403e0    	add	x0, sp, #0x100
1014171e4: 9400f7b2    	bl	0x1014550ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7c24>
1014171e8: f9404be0    	ldr	x0, [sp, #0x90]
1014171ec: 941ac8fa    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014171f0: f9004be0    	str	x0, [sp, #0x90]
1014171f4: f94006a1    	ldr	x1, [x21, #0x8]
1014171f8: b4000081    	cbz	x1, 0x101417208 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75a0>
1014171fc: f9400aa2    	ldr	x2, [x21, #0x10]
101417200: aa1403e0    	mov	x0, x20
101417204: 97da1d36    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417208: aa1303e0    	mov	x0, x19
10141720c: 52800301    	mov	w1, #0x18               ; =24
101417210: 52800102    	mov	w2, #0x8                ; =8
101417214: 97da1d32    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417218: 14000169    	b	0x1014177bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b54>
10141721c: f9004be0    	str	x0, [sp, #0x90]
101417220: b40042f6    	cbz	x22, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417224: aa1503e0    	mov	x0, x21
101417228: aa1603e1    	mov	x1, x22
10141722c: 52800022    	mov	w2, #0x1                ; =1
101417230: 97da1d2b    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417234: f9404be0    	ldr	x0, [sp, #0x90]
101417238: 941ac8e7    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10141723c: f9004be0    	str	x0, [sp, #0x90]
101417240: f9404fe8    	ldr	x8, [sp, #0x98]
101417244: b40000a8    	cbz	x8, 0x101417258 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x75f0>
101417248: aa1a03e0    	mov	x0, x26
10141724c: f9404fe1    	ldr	x1, [sp, #0x98]
101417250: 52800022    	mov	w2, #0x1                ; =1
101417254: 97da1d22    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417258: f94523e1    	ldr	x1, [sp, #0xa40]
10141725c: f240f83f    	tst	x1, #0x7fffffffffffffff
101417260: 54000080    	b.eq	0x101417270 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7608>
101417264: f94527e0    	ldr	x0, [sp, #0xa48]
101417268: 52800022    	mov	w2, #0x1                ; =1
10141726c: 97da1d1c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417270: 912783f3    	add	x19, sp, #0x9e0
101417274: 912783e0    	add	x0, sp, #0x9e0
101417278: 97d4ae25    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10141727c: 91006260    	add	x0, x19, #0x18
101417280: 97d4ae23    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101417284: 9100c260    	add	x0, x19, #0x30
101417288: 97d4ae21    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
10141728c: 91012260    	add	x0, x19, #0x48
101417290: 97d4ae1f    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101417294: f9405fe8    	ldr	x8, [sp, #0xb8]
101417298: b40000a8    	cbz	x8, 0x1014172ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7644>
10141729c: f94047e0    	ldr	x0, [sp, #0x88]
1014172a0: f9405fe1    	ldr	x1, [sp, #0xb8]
1014172a4: 52800022    	mov	w2, #0x1                ; =1
1014172a8: 97da1d0d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014172ac: f94057e8    	ldr	x8, [sp, #0xa8]
1014172b0: b4003e68    	cbz	x8, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
1014172b4: a94a07e0    	ldp	x0, x1, [sp, #0xa0]
1014172b8: 52800022    	mov	w2, #0x1                ; =1
1014172bc: 97da1d08    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014172c0: f9404be0    	ldr	x0, [sp, #0x90]
1014172c4: 941ac8c4    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014172c8: f9004be0    	str	x0, [sp, #0x90]
1014172cc: 140000bf    	b	0x1014175c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7960>
1014172d0: f9004be0    	str	x0, [sp, #0x90]
1014172d4: 910403e0    	add	x0, sp, #0x100
1014172d8: 9400f775    	bl	0x1014550ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7c24>
1014172dc: f9404be0    	ldr	x0, [sp, #0x90]
1014172e0: 941ac8bd    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014172e4: f9004be0    	str	x0, [sp, #0x90]
1014172e8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014172ec: 91094000    	add	x0, x0, #0x250
1014172f0: 97db98fa    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014172f4: 14000025    	b	0x101417388 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7720>
1014172f8: f9004be0    	str	x0, [sp, #0x90]
1014172fc: f94006c1    	ldr	x1, [x22, #0x8]
101417300: b4000081    	cbz	x1, 0x101417310 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x76a8>
101417304: f9400ac2    	ldr	x2, [x22, #0x10]
101417308: aa1303e0    	mov	x0, x19
10141730c: 97da1cf4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417310: aa1403e0    	mov	x0, x20
101417314: 52800301    	mov	w1, #0x18               ; =24
101417318: 52800102    	mov	w2, #0x8                ; =8
10141731c: 97da1cf0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417320: 1400015d    	b	0x101417894 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c2c>
101417324: f9004be0    	str	x0, [sp, #0x90]
101417328: 910303e0    	add	x0, sp, #0xc0
10141732c: 97d46737    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417330: 910403e0    	add	x0, sp, #0x100
101417334: 9400f75e    	bl	0x1014550ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7c24>
101417338: f9404be0    	ldr	x0, [sp, #0x90]
10141733c: 941ac8a6    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417340: f9004be0    	str	x0, [sp, #0x90]
101417344: 910403e0    	add	x0, sp, #0x100
101417348: 97db98e4    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10141734c: 14000016    	b	0x1014173a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x773c>
101417350: f9004be0    	str	x0, [sp, #0x90]
101417354: 14000095    	b	0x1014175a8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7940>
101417358: f9004be0    	str	x0, [sp, #0x90]
10141735c: f9400761    	ldr	x1, [x27, #0x8]
101417360: b4000081    	cbz	x1, 0x101417370 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7708>
101417364: f9400b62    	ldr	x2, [x27, #0x10]
101417368: aa1803e0    	mov	x0, x24
10141736c: 97da1cdc    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417370: aa1403e0    	mov	x0, x20
101417374: 52800301    	mov	w1, #0x18               ; =24
101417378: 52800102    	mov	w2, #0x8                ; =8
10141737c: 97da1cd8    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417380: 14000077    	b	0x10141755c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x78f4>
101417384: f9004be0    	str	x0, [sp, #0x90]
101417388: 912783e0    	add	x0, sp, #0x9e0
10141738c: 9400fb02    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
101417390: 140001b9    	b	0x101417a74 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e0c>
101417394: 941ab264    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
101417398: f9004be0    	str	x0, [sp, #0x90]
10141739c: 14000104    	b	0x1014177ac <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b44>
1014173a0: f9004be0    	str	x0, [sp, #0x90]
1014173a4: 9125c3e0    	add	x0, sp, #0x970
1014173a8: 97d46718    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
1014173ac: 140000f5    	b	0x101417780 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b18>
1014173b0: f9004be0    	str	x0, [sp, #0x90]
1014173b4: 14000136    	b	0x10141788c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c24>
1014173b8: f9004be0    	str	x0, [sp, #0x90]
1014173bc: 9125c3e0    	add	x0, sp, #0x970
1014173c0: 97db98c6    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014173c4: 14000036    	b	0x10141749c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7834>
1014173c8: 14000052    	b	0x101417510 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x78a8>
1014173cc: f9004be0    	str	x0, [sp, #0x90]
1014173d0: 140000f5    	b	0x1014177a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b3c>
1014173d4: f9004be0    	str	x0, [sp, #0x90]
1014173d8: f9492be1    	ldr	x1, [sp, #0x1250]
1014173dc: b40000c1    	cbz	x1, 0x1014173f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x778c>
1014173e0: aa1303e0    	mov	x0, x19
1014173e4: 52800022    	mov	w2, #0x1                ; =1
1014173e8: 97da1cbd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014173ec: 14000002    	b	0x1014173f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x778c>
1014173f0: f9004be0    	str	x0, [sp, #0x90]
1014173f4: f944f3e1    	ldr	x1, [sp, #0x9e0]
1014173f8: b40000c1    	cbz	x1, 0x101417410 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77a8>
1014173fc: aa1403e0    	mov	x0, x20
101417400: 52800022    	mov	w2, #0x1                ; =1
101417404: 97da1cb6    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417408: 14000002    	b	0x101417410 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77a8>
10141740c: f9004be0    	str	x0, [sp, #0x90]
101417410: 910403e0    	add	x0, sp, #0x100
101417414: 97d466fd    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417418: 1400014d    	b	0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
10141741c: f9004be0    	str	x0, [sp, #0x90]
101417420: f9400761    	ldr	x1, [x27, #0x8]
101417424: b4000081    	cbz	x1, 0x101417434 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77cc>
101417428: f9400b62    	ldr	x2, [x27, #0x10]
10141742c: aa1903e0    	mov	x0, x25
101417430: 97da1cab    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417434: aa1803e0    	mov	x0, x24
101417438: 52800301    	mov	w1, #0x18               ; =24
10141743c: 52800102    	mov	w2, #0x8                ; =8
101417440: 97da1ca7    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417444: 14000101    	b	0x101417848 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7be0>
101417448: f9004be0    	str	x0, [sp, #0x90]
10141744c: f94006e1    	ldr	x1, [x23, #0x8]
101417450: b4000081    	cbz	x1, 0x101417460 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x77f8>
101417454: f9400ae2    	ldr	x2, [x23, #0x10]
101417458: aa1603e0    	mov	x0, x22
10141745c: 97da1ca0    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417460: aa1503e0    	mov	x0, x21
101417464: 52800301    	mov	w1, #0x18               ; =24
101417468: 52800102    	mov	w2, #0x8                ; =8
10141746c: 97da1c9c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417470: f9404be0    	ldr	x0, [sp, #0x90]
101417474: 941ac858    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417478: 140000fd    	b	0x10141786c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c04>
10141747c: f9004be0    	str	x0, [sp, #0x90]
101417480: 912783e0    	add	x0, sp, #0x9e0
101417484: 97d4c576    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
101417488: 9125c3e0    	add	x0, sp, #0x970
10141748c: 9400fa76    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417490: 14000152    	b	0x1014179d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d70>
101417494: 14000019    	b	0x1014174f8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7890>
101417498: f9004be0    	str	x0, [sp, #0x90]
10141749c: 910403e0    	add	x0, sp, #0x100
1014174a0: 9400fabd    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
1014174a4: 140000fc    	b	0x101417894 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c2c>
1014174a8: 941ab21f    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014174ac: f9004be0    	str	x0, [sp, #0x90]
1014174b0: f944f3e1    	ldr	x1, [sp, #0x9e0]
1014174b4: b40018e1    	cbz	x1, 0x1014177d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b68>
1014174b8: aa1303e0    	mov	x0, x19
1014174bc: 140000c3    	b	0x1014177c8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b60>
1014174c0: f9004be0    	str	x0, [sp, #0x90]
1014174c4: 140000c3    	b	0x1014177d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b68>
1014174c8: f9004be0    	str	x0, [sp, #0x90]
1014174cc: 140000c3    	b	0x1014177d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b70>
1014174d0: f9004be0    	str	x0, [sp, #0x90]
1014174d4: f944f3e1    	ldr	x1, [sp, #0x9e0]
1014174d8: b5001841    	cbnz	x1, 0x1014177e0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b78>
1014174dc: 1400011c    	b	0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
1014174e0: f9004be0    	str	x0, [sp, #0x90]
1014174e4: 1400011a    	b	0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
1014174e8: f9004be0    	str	x0, [sp, #0x90]
1014174ec: 912783e0    	add	x0, sp, #0x9e0
1014174f0: 97db987a    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014174f4: 1400001e    	b	0x10141756c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7904>
1014174f8: f9004be0    	str	x0, [sp, #0x90]
1014174fc: aa1703e0    	mov	x0, x23
101417500: aa1403e1    	mov	x1, x20
101417504: 52800022    	mov	w2, #0x1                ; =1
101417508: 97da1c75    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141750c: 14000126    	b	0x1014179a4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d3c>
101417510: f9004be0    	str	x0, [sp, #0x90]
101417514: 140000e0    	b	0x101417894 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c2c>
101417518: f9004be0    	str	x0, [sp, #0x90]
10141751c: f944f3e1    	ldr	x1, [sp, #0x9e0]
101417520: b4002ae1    	cbz	x1, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417524: aa1303e0    	mov	x0, x19
101417528: 52800022    	mov	w2, #0x1                ; =1
10141752c: 97da1c6c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417530: f9404be0    	ldr	x0, [sp, #0x90]
101417534: 941ac828    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417538: f9004be0    	str	x0, [sp, #0x90]
10141753c: 140000a0    	b	0x1014177bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b54>
101417540: f9004be0    	str	x0, [sp, #0x90]
101417544: 910403e0    	add	x0, sp, #0x100
101417548: 97db9864    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10141754c: 1400005a    	b	0x1014176b4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7a4c>
101417550: f9004be0    	str	x0, [sp, #0x90]
101417554: 140000fb    	b	0x101417940 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7cd8>
101417558: f9004be0    	str	x0, [sp, #0x90]
10141755c: f94083e1    	ldr	x1, [sp, #0x100]
101417560: b50019e1    	cbnz	x1, 0x10141789c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c34>
101417564: 14000146    	b	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417568: f9004be0    	str	x0, [sp, #0x90]
10141756c: 9125c3e0    	add	x0, sp, #0x970
101417570: 97d466a6    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417574: d10283a0    	sub	x0, x29, #0xa0
101417578: 9400fa3b    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10141757c: 910403e0    	add	x0, sp, #0x100
101417580: 9400f6cb    	bl	0x1014550ac <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x7c24>
101417584: f9404be0    	ldr	x0, [sp, #0x90]
101417588: 941ac813    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10141758c: f9004be0    	str	x0, [sp, #0x90]
101417590: 912783e0    	add	x0, sp, #0x9e0
101417594: 97db9851    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101417598: 14000075    	b	0x10141776c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b04>
10141759c: f9004be0    	str	x0, [sp, #0x90]
1014175a0: f9093bf6    	str	x22, [sp, #0x1270]
1014175a4: f9092ff8    	str	x24, [sp, #0x1258]
1014175a8: b40000b7    	cbz	x23, 0x1014175bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7954>
1014175ac: aa1903e0    	mov	x0, x25
1014175b0: aa1703e1    	mov	x1, x23
1014175b4: 52800022    	mov	w2, #0x1                ; =1
1014175b8: 97da1c49    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014175bc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014175c0: 91094000    	add	x0, x0, #0x250
1014175c4: 97d46691    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
1014175c8: 910303e0    	add	x0, sp, #0xc0
1014175cc: 9400fa26    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
1014175d0: 910403e0    	add	x0, sp, #0x100
1014175d4: 97d4c522    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
1014175d8: f85603a1    	ldur	x1, [x29, #-0xa0]
1014175dc: f240f83f    	tst	x1, #0x7fffffffffffffff
1014175e0: 540024e0    	b.eq	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
1014175e4: f85683a0    	ldur	x0, [x29, #-0x98]
1014175e8: 52800022    	mov	w2, #0x1                ; =1
1014175ec: 97da1c3c    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014175f0: f9404be0    	ldr	x0, [sp, #0x90]
1014175f4: 941ac7f8    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014175f8: f9004be0    	str	x0, [sp, #0x90]
1014175fc: f904f7fb    	str	x27, [sp, #0x9e8]
101417600: f90503ff    	str	xzr, [sp, #0xa00]
101417604: b40000b5    	cbz	x21, 0x101417618 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x79b0>
101417608: aa1603e0    	mov	x0, x22
10141760c: aa1503e1    	mov	x1, x21
101417610: 52800022    	mov	w2, #0x1                ; =1
101417614: 97da1c32    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417618: aa1703e0    	mov	x0, x23
10141761c: 528000c1    	mov	w1, #0x6                ; =6
101417620: 14000005    	b	0x101417634 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x79cc>
101417624: f9004be0    	str	x0, [sp, #0x90]
101417628: b40000b5    	cbz	x21, 0x10141763c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x79d4>
10141762c: aa1603e0    	mov	x0, x22
101417630: aa1503e1    	mov	x1, x21
101417634: 52800022    	mov	w2, #0x1                ; =1
101417638: 97da1c29    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141763c: f904c3ff    	str	xzr, [sp, #0x980]
101417640: 912783e0    	add	x0, sp, #0x9e0
101417644: 97d46671    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417648: 9125c3e0    	add	x0, sp, #0x970
10141764c: 1400010b    	b	0x101417a78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e10>
101417650: f9004be0    	str	x0, [sp, #0x90]
101417654: 91002293    	add	x19, x20, #0x8
101417658: 14000004    	b	0x101417668 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7a00>
10141765c: 91006273    	add	x19, x19, #0x18
101417660: f10006b5    	subs	x21, x21, #0x1
101417664: 540000e0    	b.eq	0x101417680 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7a18>
101417668: f85f8261    	ldur	x1, [x19, #-0x8]
10141766c: b4ffff81    	cbz	x1, 0x10141765c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x79f4>
101417670: f9400260    	ldr	x0, [x19]
101417674: 52800022    	mov	w2, #0x1                ; =1
101417678: 97da1c19    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141767c: 17fffff8    	b	0x10141765c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x79f4>
101417680: b4001ff9    	cbz	x25, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417684: 8b190728    	add	x8, x25, x25, lsl #1
101417688: d37df101    	lsl	x1, x8, #3
10141768c: aa1403e0    	mov	x0, x20
101417690: 52800102    	mov	w2, #0x8                ; =8
101417694: 97da1c12    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417698: f9404be0    	ldr	x0, [sp, #0x90]
10141769c: 941ac7ce    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014176a0: f9004be0    	str	x0, [sp, #0x90]
1014176a4: 912783e0    	add	x0, sp, #0x9e0
1014176a8: 97db980c    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014176ac: 14000092    	b	0x1014178f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c8c>
1014176b0: f9004be0    	str	x0, [sp, #0x90]
1014176b4: 9125c3e0    	add	x0, sp, #0x970
1014176b8: 97d46654    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
1014176bc: b5001815    	cbnz	x21, 0x1014179bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d54>
1014176c0: 140000ef    	b	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
1014176c4: f9004be0    	str	x0, [sp, #0x90]
1014176c8: 912783e0    	add	x0, sp, #0x9e0
1014176cc: 97ec4f73    	bl	0x100f2b498 <__ZN200_$LT$otty_sync_dotfiles..catalog.._..$LT$impl$u20$serde_core..de..Deserialize$u20$for$u20$otty_sync_dotfiles..catalog..CatalogAppSpec$GT$..deserialize..__Visitor$u20$as$u20$serde_core..de..Visitor$GT$9expecting17hace6feb1294ba67fE+0x6bc0>
1014176d0: 1400009f    	b	0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
1014176d4: f9004be0    	str	x0, [sp, #0x90]
1014176d8: f9092ff8    	str	x24, [sp, #0x1258]
1014176dc: 912783e0    	add	x0, sp, #0x9e0
1014176e0: 97db97fe    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
1014176e4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014176e8: 91094000    	add	x0, x0, #0x250
1014176ec: 9400ed9b    	bl	0x101452d58 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x58d0>
1014176f0: 910403e0    	add	x0, sp, #0x100
1014176f4: 97d4c4da    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
1014176f8: 140000b8    	b	0x1014179d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d70>
1014176fc: f9004be0    	str	x0, [sp, #0x90]
101417700: b5000155    	cbnz	x21, 0x101417728 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ac0>
101417704: f9405fe8    	ldr	x8, [sp, #0xb8]
101417708: b4001a68    	cbz	x8, 0x101417a54 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7dec>
10141770c: f9405fe8    	ldr	x8, [sp, #0xb8]
101417710: 8b080508    	add	x8, x8, x8, lsl #1
101417714: d37df101    	lsl	x1, x8, #3
101417718: aa1403e0    	mov	x0, x20
10141771c: 52800102    	mov	w2, #0x8                ; =8
101417720: 97da1bef    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417724: 140000cc    	b	0x101417a54 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7dec>
101417728: 91002293    	add	x19, x20, #0x8
10141772c: 14000004    	b	0x10141773c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ad4>
101417730: 91006273    	add	x19, x19, #0x18
101417734: f10006b5    	subs	x21, x21, #0x1
101417738: 54fffe60    	b.eq	0x101417704 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7a9c>
10141773c: f85f8261    	ldur	x1, [x19, #-0x8]
101417740: b4ffff81    	cbz	x1, 0x101417730 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ac8>
101417744: f9400260    	ldr	x0, [x19]
101417748: 52800022    	mov	w2, #0x1                ; =1
10141774c: 97da1be4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417750: 17fffff8    	b	0x101417730 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ac8>
101417754: f9004be0    	str	x0, [sp, #0x90]
101417758: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10141775c: 91094000    	add	x0, x0, #0x250
101417760: 97d4aceb    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
101417764: 14000007    	b	0x101417780 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b18>
101417768: f9004be0    	str	x0, [sp, #0x90]
10141776c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101417770: 91094000    	add	x0, x0, #0x250
101417774: 97d46625    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417778: 910303e0    	add	x0, sp, #0xc0
10141777c: 9400f9ba    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417780: b50011f5    	cbnz	x21, 0x1014179bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d54>
101417784: 140000be    	b	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417788: f9004be0    	str	x0, [sp, #0x90]
10141778c: f904bff3    	str	x19, [sp, #0x978]
101417790: 9125c3e0    	add	x0, sp, #0x970
101417794: 97d4661d    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417798: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10141779c: 91094000    	add	x0, x0, #0x250
1014177a0: 97d4c4af    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
1014177a4: 912783e0    	add	x0, sp, #0x9e0
1014177a8: 9400ee2d    	bl	0x10145305c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x5bd4>
1014177ac: 71000f7f    	cmp	w27, #0x3
1014177b0: 54000061    	b.ne	0x1014177bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b54>
1014177b4: 910403e0    	add	x0, sp, #0x100
1014177b8: 9400fbf8    	bl	0x101456798 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x9310>
1014177bc: f85403a1    	ldur	x1, [x29, #-0xc0]
1014177c0: b4000081    	cbz	x1, 0x1014177d0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7b68>
1014177c4: aa1903e0    	mov	x0, x25
1014177c8: 52800022    	mov	w2, #0x1                ; =1
1014177cc: 97da1bc4    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014177d0: d10363a0    	sub	x0, x29, #0xd8
1014177d4: 97d4acce    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
1014177d8: f94997e1    	ldr	x1, [sp, #0x1328]
1014177dc: b4000b81    	cbz	x1, 0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
1014177e0: aa1803e0    	mov	x0, x24
1014177e4: 52800022    	mov	w2, #0x1                ; =1
1014177e8: 97da1bbd    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014177ec: 14000058    	b	0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
1014177f0: 941ab14d    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014177f4: f9004be0    	str	x0, [sp, #0x90]
1014177f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014177fc: 91094000    	add	x0, x0, #0x250
101417800: 97db97b6    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101417804: 14000020    	b	0x101417884 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c1c>
101417808: f9004be0    	str	x0, [sp, #0x90]
10141780c: b4000757    	cbz	x23, 0x1014178f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c8c>
101417810: aa1803e0    	mov	x0, x24
101417814: aa1703e1    	mov	x1, x23
101417818: 14000033    	b	0x1014178e4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c7c>
10141781c: f9004be0    	str	x0, [sp, #0x90]
101417820: b40000b7    	cbz	x23, 0x101417834 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7bcc>
101417824: aa1803e0    	mov	x0, x24
101417828: aa1703e1    	mov	x1, x23
10141782c: 52800022    	mov	w2, #0x1                ; =1
101417830: 97da1bab    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417834: aa1903e0    	mov	x0, x25
101417838: aa1503e1    	mov	x1, x21
10141783c: 1400002a    	b	0x1014178e4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c7c>
101417840: f9005bf5    	str	x21, [sp, #0xb0]
101417844: f9004be0    	str	x0, [sp, #0x90]
101417848: f94083e1    	ldr	x1, [sp, #0x100]
10141784c: b4001181    	cbz	x1, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417850: f9405be0    	ldr	x0, [sp, #0xb0]
101417854: 52800022    	mov	w2, #0x1                ; =1
101417858: 97da1ba1    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141785c: f9404be0    	ldr	x0, [sp, #0x90]
101417860: 941ac75d    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417864: f9004be0    	str	x0, [sp, #0x90]
101417868: 1400007b    	b	0x101417a54 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7dec>
10141786c: f9004be0    	str	x0, [sp, #0x90]
101417870: f944f3e1    	ldr	x1, [sp, #0x9e0]
101417874: b5000141    	cbnz	x1, 0x10141789c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c34>
101417878: 14000081    	b	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
10141787c: 14000049    	b	0x1014179a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d38>
101417880: f9004be0    	str	x0, [sp, #0x90]
101417884: 912783e0    	add	x0, sp, #0x9e0
101417888: 9400f9c3    	bl	0x101455f94 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x8b0c>
10141788c: 910303e0    	add	x0, sp, #0xc0
101417890: 9400f975    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417894: f85603a1    	ldur	x1, [x29, #-0xa0]
101417898: b4000f21    	cbz	x1, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
10141789c: aa1503e0    	mov	x0, x21
1014178a0: 52800022    	mov	w2, #0x1                ; =1
1014178a4: 97da1b8e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014178a8: f9404be0    	ldr	x0, [sp, #0x90]
1014178ac: 941ac74a    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014178b0: 941ab11d    	bl	0x101ac3d24 <__ZN4core9panicking16panic_in_cleanup17h611124c659c60d5fE>
1014178b4: 1400003b    	b	0x1014179a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d38>
1014178b8: f9004be0    	str	x0, [sp, #0x90]
1014178bc: b40008f3    	cbz	x19, 0x1014179d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d70>
1014178c0: aa1403e0    	mov	x0, x20
1014178c4: aa1303e1    	mov	x1, x19
1014178c8: 52800022    	mov	w2, #0x1                ; =1
1014178cc: 97da1b84    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014178d0: 14000042    	b	0x1014179d8 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d70>
1014178d4: f9004be0    	str	x0, [sp, #0x90]
1014178d8: f85403a1    	ldur	x1, [x29, #-0xc0]
1014178dc: b40000c1    	cbz	x1, 0x1014178f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c8c>
1014178e0: f85483a0    	ldur	x0, [x29, #-0xb8]
1014178e4: 52800022    	mov	w2, #0x1                ; =1
1014178e8: 97da1b7d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014178ec: 14000002    	b	0x1014178f4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7c8c>
1014178f0: f9004be0    	str	x0, [sp, #0x90]
1014178f4: f85283a1    	ldur	x1, [x29, #-0xd8]
1014178f8: b4000081    	cbz	x1, 0x101417908 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ca0>
1014178fc: f85303a0    	ldur	x0, [x29, #-0xd0]
101417900: 52800022    	mov	w2, #0x1                ; =1
101417904: 97da1b76    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417908: 910403e0    	add	x0, sp, #0x100
10141790c: 9400f550    	bl	0x101454e4c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x79c4>
101417910: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101417914: 910ca000    	add	x0, x0, #0x328
101417918: 9400f953    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10141791c: 9125c3e0    	add	x0, sp, #0x970
101417920: 97d4c44f    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
101417924: 52800013    	mov	w19, #0x0               ; =0
101417928: f9498be1    	ldr	x1, [sp, #0x1310]
10141792c: b4000081    	cbz	x1, 0x10141793c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7cd4>
101417930: f9498fe0    	ldr	x0, [sp, #0x1318]
101417934: 52800022    	mov	w2, #0x1                ; =1
101417938: 97da1b69    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10141793c: 36000093    	tbz	w19, #0x0, 0x10141794c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7ce4>
101417940: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101417944: 91094000    	add	x0, x0, #0x250
101417948: 9400f541    	bl	0x101454e4c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x79c4>
10141794c: f9497fe1    	ldr	x1, [sp, #0x12f8]
101417950: f240f83f    	tst	x1, #0x7fffffffffffffff
101417954: 54000940    	b.eq	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417958: f94983e0    	ldr	x0, [sp, #0x1300]
10141795c: 52800022    	mov	w2, #0x1                ; =1
101417960: 97da1b5f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417964: f9404be0    	ldr	x0, [sp, #0x90]
101417968: 941ac71b    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10141796c: f9004be0    	str	x0, [sp, #0x90]
101417970: 912783e0    	add	x0, sp, #0x9e0
101417974: 97db9759    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
101417978: 14000003    	b	0x101417984 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d1c>
10141797c: 14000009    	b	0x1014179a0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d38>
101417980: f9004be0    	str	x0, [sp, #0x90]
101417984: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
101417988: 91094000    	add	x0, x0, #0x250
10141798c: 97d4659f    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417990: 910303e0    	add	x0, sp, #0xc0
101417994: 9400f934    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417998: b5000135    	cbnz	x21, 0x1014179bc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7d54>
10141799c: 14000038    	b	0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
1014179a0: f9004be0    	str	x0, [sp, #0x90]
1014179a4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1014179a8: 91094000    	add	x0, x0, #0x250
1014179ac: 97d4c42c    	bl	0x100948a5c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x35a34>
1014179b0: 910303e0    	add	x0, sp, #0xc0
1014179b4: 97d4ac56    	bl	0x100942b0c <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x2fae4>
1014179b8: b4000635    	cbz	x21, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
1014179bc: f9405fe0    	ldr	x0, [sp, #0xb8]
1014179c0: aa1503e1    	mov	x1, x21
1014179c4: 52800022    	mov	w2, #0x1                ; =1
1014179c8: 97da1b45    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014179cc: f9404be0    	ldr	x0, [sp, #0x90]
1014179d0: 941ac701    	bl	0x101ac95d4 <_writev+0x101ac95d4>
1014179d4: f9004be0    	str	x0, [sp, #0x90]
1014179d8: f94007e8    	ldr	x8, [sp, #0x8]
1014179dc: b40004c8    	cbz	x8, 0x101417a74 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e0c>
1014179e0: a94007e0    	ldp	x0, x1, [sp]
1014179e4: 52800022    	mov	w2, #0x1                ; =1
1014179e8: 97da1b3d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
1014179ec: 14000022    	b	0x101417a74 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e0c>
1014179f0: f9004be0    	str	x0, [sp, #0x90]
1014179f4: f90087fc    	str	x28, [sp, #0x108]
1014179f8: f944bbe1    	ldr	x1, [sp, #0x970]
1014179fc: b4000081    	cbz	x1, 0x101417a0c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7da4>
101417a00: f944bfe0    	ldr	x0, [sp, #0x978]
101417a04: 52800022    	mov	w2, #0x1                ; =1
101417a08: 97da1b35    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417a0c: f81703b5    	stur	x21, [x29, #-0x90]
101417a10: 910403e0    	add	x0, sp, #0x100
101417a14: 97d4657d    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417a18: d10283a0    	sub	x0, x29, #0xa0
101417a1c: 9400f912    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417a20: 1400000d    	b	0x101417a54 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7dec>
101417a24: f9004be0    	str	x0, [sp, #0x90]
101417a28: f904f7fb    	str	x27, [sp, #0x9e8]
101417a2c: b40000b3    	cbz	x19, 0x101417a40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7dd8>
101417a30: aa1603e0    	mov	x0, x22
101417a34: aa1303e1    	mov	x1, x19
101417a38: 52800022    	mov	w2, #0x1                ; =1
101417a3c: 97da1b28    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417a40: aa1403e0    	mov	x0, x20
101417a44: aa1503e1    	mov	x1, x21
101417a48: 97d4c688    	bl	0x100949468 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x36440>
101417a4c: 912783e0    	add	x0, sp, #0x9e0
101417a50: 97d4656e    	bl	0x100931008 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17hf6243c7e031621e7E+0x1dfe0>
101417a54: f85283a1    	ldur	x1, [x29, #-0xd8]
101417a58: b4000121    	cbz	x1, 0x101417a7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x7e14>
101417a5c: f85303a0    	ldur	x0, [x29, #-0xd0]
101417a60: 52800022    	mov	w2, #0x1                ; =1
101417a64: 97da1b1e    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
101417a68: f9404be0    	ldr	x0, [sp, #0x90]
101417a6c: 941ac6da    	bl	0x101ac95d4 <_writev+0x101ac95d4>
101417a70: f9004be0    	str	x0, [sp, #0x90]
101417a74: 910303e0    	add	x0, sp, #0xc0
101417a78: 9400f8fb    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
101417a7c: f9404be0    	ldr	x0, [sp, #0x90]
101417a80: 941ac6d5    	bl	0x101ac95d4 <_writev+0x101ac95d4>
