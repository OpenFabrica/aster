
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001001964f8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg>:
100196920: 6db733ed    	stp	d13, d12, [sp, #-0x90]!
100196924: 6d012beb    	stp	d11, d10, [sp, #0x10]
100196928: 6d0223e9    	stp	d9, d8, [sp, #0x20]
10019692c: a9036ffc    	stp	x28, x27, [sp, #0x30]
100196930: a90467fa    	stp	x26, x25, [sp, #0x40]
100196934: a9055ff8    	stp	x24, x23, [sp, #0x50]
100196938: a90657f6    	stp	x22, x21, [sp, #0x60]
10019693c: a9074ff4    	stp	x20, x19, [sp, #0x70]
100196940: a9087bfd    	stp	x29, x30, [sp, #0x80]
100196944: 910203fd    	add	x29, sp, #0x80
100196948: d10603ff    	sub	sp, sp, #0x180
10019694c: aa1403fa    	mov	x26, x20
100196950: f9400813    	ldr	x19, [x0, #0x10]
100196954: b40002d3    	cbz	x19, 0x1001969ac <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x4b4>
100196958: aa0203f4    	mov	x20, x2
10019695c: 4ea21c4b    	mov.16b	v11, v2
100196960: 4ea11c29    	mov.16b	v9, v1
100196964: 4ea01c0a    	mov.16b	v10, v0
100196968: aa0103f7    	mov	x23, x1
10019696c: aa0003f5    	mov	x21, x0
100196970: aa0103e0    	mov	x0, x1
100196974: 9464fe23    	bl	0x101ad6200 <_writev+0x101ad6200>
100196978: aa1d03fd    	mov	x29, x29
10019697c: 9464ccf6    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100196980: b4000160    	cbz	x0, 0x1001969ac <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x4b4>
100196984: aa0003f8    	mov	x24, x0
100196988: 9464e1ce    	bl	0x101acf0c0 <_writev+0x101acf0c0>
10019698c: 34000dc0    	cbz	w0, 0x100196b44 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x64c>
100196990: aa1803e0    	mov	x0, x24
100196994: 9464d3b3    	bl	0x101acb860 <_writev+0x101acb860>
100196998: aa1d03fd    	mov	x29, x29
10019699c: 9464ccee    	bl	0x101ac9d54 <_writev+0x101ac9d54>
1001969a0: b40001c0    	cbz	x0, 0x1001969d8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x4e0>
1001969a4: 9464cce3    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001969a8: 14000067    	b	0x100196b44 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x64c>
1001969ac: 910603ff    	add	sp, sp, #0x180
1001969b0: a9487bfd    	ldp	x29, x30, [sp, #0x80]
1001969b4: a9474ff4    	ldp	x20, x19, [sp, #0x70]
1001969b8: a94657f6    	ldp	x22, x21, [sp, #0x60]
1001969bc: a9455ff8    	ldp	x24, x23, [sp, #0x50]
1001969c0: a94467fa    	ldp	x26, x25, [sp, #0x40]
1001969c4: a9436ffc    	ldp	x28, x27, [sp, #0x30]
1001969c8: 6d4223e9    	ldp	d9, d8, [sp, #0x20]
1001969cc: 6d412beb    	ldp	d11, d10, [sp, #0x10]
1001969d0: 6cc933ed    	ldp	d13, d12, [sp], #0x90
1001969d4: 14000465    	b	0x100197b68 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1670>
1001969d8: aa1803e0    	mov	x0, x24
1001969dc: 9464e119    	bl	0x101acee40 <_writev+0x101acee40>
1001969e0: 34000b20    	cbz	w0, 0x100196b44 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x64c>
1001969e4: 91014340    	add	x0, x26, #0x50
1001969e8: aa1803e1    	mov	x1, x24
1001969ec: 9464d02b    	bl	0x101acaa98 <_writev+0x101acaa98>
1001969f0: aa1803e0    	mov	x0, x24
1001969f4: 9464ccd2    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
1001969f8: aa0003f6    	mov	x22, x0
1001969fc: aa1403e0    	mov	x0, x20
100196a00: aa1a03f4    	mov	x20, x26
100196a04: 940004a7    	bl	0x100197ca0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x17a8>
100196a08: 52800108    	mov	w8, #0x8                ; =8
100196a0c: f100227f    	cmp	x19, #0x8
100196a10: 9a883268    	csel	x8, x19, x8, lo
100196a14: 52800309    	mov	w9, #0x18               ; =24
100196a18: d280010a    	mov	x10, #0x8               ; =8
100196a1c: 9b092908    	madd	x8, x8, x9, x10
100196a20: 9e630108    	ucvtf	d8, x8
100196a24: 94000451    	bl	0x100197b68 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1670>
100196a28: f9401754    	ldr	x20, [x26, #0x28]
100196a2c: f9001755    	str	x21, [x26, #0x28]
100196a30: aa1503e0    	mov	x0, x21
100196a34: 9464cefc    	bl	0x101aca624 <_writev+0x101aca624>
100196a38: aa1403e0    	mov	x0, x20
100196a3c: 9464cef4    	bl	0x101aca60c <_writev+0x101aca60c>
100196a40: 9100c340    	add	x0, x26, #0x30
100196a44: 910263e1    	add	x1, sp, #0x98
100196a48: 52800022    	mov	w2, #0x1                ; =1
100196a4c: d2800003    	mov	x3, #0x0                ; =0
100196a50: 9464ceec    	bl	0x101aca600 <_writev+0x101aca600>
100196a54: 92800008    	mov	x8, #-0x1               ; =-1
100196a58: f9001b48    	str	x8, [x26, #0x30]
100196a5c: aa1703e0    	mov	x0, x23
100196a60: 4eaa1d40    	mov.16b	v0, v10
100196a64: 4ea91d21    	mov.16b	v1, v9
100196a68: d2800002    	mov	x2, #0x0                ; =0
100196a6c: 9464d7b5    	bl	0x101acc940 <_writev+0x101acc940>
100196a70: aa1603e0    	mov	x0, x22
100196a74: 9464d7c3    	bl	0x101acc980 <_writev+0x101acc980>
100196a78: 4ea01c09    	mov.16b	v9, v0
100196a7c: 4ea11c2c    	mov.16b	v12, v1
100196a80: 1e683820    	fsub	d0, d1, d8
100196a84: 1e721001    	fmov	d1, #-4.00000000
100196a88: 1e61280a    	fadd	d10, d0, d1
100196a8c: aa1603e0    	mov	x0, x22
100196a90: 9464dc8c    	bl	0x101acdcc0 <_writev+0x101acdcc0>
100196a94: 9464c8c6    	bl	0x101ac8dac <_writev+0x101ac8dac>
100196a98: 1e621001    	fmov	d1, #4.00000000
100196a9c: 1e61280d    	fadd	d13, d0, d1
100196aa0: 1e6d2140    	fcmp	d10, d13
100196aa4: 54000705    	b.pl	0x100196b84 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x68c>
100196aa8: 1e6c2960    	fadd	d0, d11, d12
100196aac: 1e61280a    	fadd	d10, d0, d1
100196ab0: aa1603e0    	mov	x0, x22
100196ab4: 9464e9a3    	bl	0x101ad1140 <_writev+0x101ad1140>
100196ab8: aa1d03fd    	mov	x29, x29
100196abc: 9464cca6    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100196ac0: b4000620    	cbz	x0, 0x100196b84 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x68c>
100196ac4: aa0003f4    	mov	x20, x0
100196ac8: aa1603e0    	mov	x0, x22
100196acc: 9464dc7d    	bl	0x101acdcc0 <_writev+0x101acdcc0>
100196ad0: 9464c8ab    	bl	0x101ac8d7c <_writev+0x101ac8d7c>
100196ad4: 4ea01c0b    	mov.16b	v11, v0
100196ad8: aa1403e0    	mov	x0, x20
100196adc: 9464fd69    	bl	0x101ad6080 <_writev+0x101ad6080>
100196ae0: 9464c8a7    	bl	0x101ac8d7c <_writev+0x101ac8d7c>
100196ae4: 1e6b2000    	fcmp	d0, d11
100196ae8: 1e6b4c00    	fcsel	d0, d0, d11, mi
100196aec: 1e682941    	fadd	d1, d10, d8
100196af0: 1e72100c    	fmov	d12, #-4.00000000
100196af4: 1e6c2800    	fadd	d0, d0, d12
100196af8: 1e612000    	fcmp	d0, d1
100196afc: 54000405    	b.pl	0x100196b7c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x684>
100196b00: aa1603e0    	mov	x0, x22
100196b04: 9464dc6f    	bl	0x101acdcc0 <_writev+0x101acdcc0>
100196b08: 9464c89d    	bl	0x101ac8d7c <_writev+0x101ac8d7c>
100196b0c: 4ea01c0a    	mov.16b	v10, v0
100196b10: aa1403e0    	mov	x0, x20
100196b14: 9464fd5b    	bl	0x101ad6080 <_writev+0x101ad6080>
100196b18: 9464c899    	bl	0x101ac8d7c <_writev+0x101ac8d7c>
100196b1c: 4ea01c0b    	mov.16b	v11, v0
100196b20: aa1403e0    	mov	x0, x20
100196b24: 9464cc83    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100196b28: 1e6a2160    	fcmp	d11, d10
100196b2c: 1e6a4d60    	fcsel	d0, d11, d10, mi
100196b30: 1e6c2800    	fadd	d0, d0, d12
100196b34: 1e683800    	fsub	d0, d0, d8
100196b38: 1e6021a0    	fcmp	d13, d0
100196b3c: 1e608daa    	fcsel	d10, d13, d0, hi
100196b40: 14000011    	b	0x100196b84 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x68c>
100196b44: aa1a03f4    	mov	x20, x26
100196b48: 94000408    	bl	0x100197b68 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1670>
100196b4c: aa1803e0    	mov	x0, x24
100196b50: 910603ff    	add	sp, sp, #0x180
100196b54: a9487bfd    	ldp	x29, x30, [sp, #0x80]
100196b58: a9474ff4    	ldp	x20, x19, [sp, #0x70]
100196b5c: a94657f6    	ldp	x22, x21, [sp, #0x60]
100196b60: a9455ff8    	ldp	x24, x23, [sp, #0x50]
100196b64: a94467fa    	ldp	x26, x25, [sp, #0x40]
100196b68: a9436ffc    	ldp	x28, x27, [sp, #0x30]
100196b6c: 6d4223e9    	ldp	d9, d8, [sp, #0x20]
100196b70: 6d412beb    	ldp	d11, d10, [sp, #0x10]
100196b74: 6cc933ed    	ldp	d13, d12, [sp], #0x90
100196b78: 1464cc6e    	b	0x101ac9d30 <_writev+0x101ac9d30>
100196b7c: aa1403e0    	mov	x0, x20
100196b80: 9464cc6c    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100196b84: aa1603e0    	mov	x0, x22
100196b88: 9464e96e    	bl	0x101ad1140 <_writev+0x101ad1140>
100196b8c: aa1d03fd    	mov	x29, x29
100196b90: 9464cc71    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100196b94: b40002e0    	cbz	x0, 0x100196bf0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x6f8>
100196b98: aa0003f4    	mov	x20, x0
100196b9c: d2e80d28    	mov	x8, #0x4069000000000000 ; =4641240890982006784
100196ba0: 9e670100    	fmov	d0, x8
100196ba4: 1e60292b    	fadd	d11, d9, d0
100196ba8: 9464fd36    	bl	0x101ad6080 <_writev+0x101ad6080>
100196bac: 9464c871    	bl	0x101ac8d70 <_writev+0x101ac8d70>
100196bb0: 1e6b2000    	fcmp	d0, d11
100196bb4: 540001a5    	b.pl	0x100196be8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x6f0>
100196bb8: aa1403e0    	mov	x0, x20
100196bbc: 9464fd31    	bl	0x101ad6080 <_writev+0x101ad6080>
100196bc0: 9464c86c    	bl	0x101ac8d70 <_writev+0x101ac8d70>
100196bc4: 4ea01c09    	mov.16b	v9, v0
100196bc8: aa1403e0    	mov	x0, x20
100196bcc: 9464cc59    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100196bd0: d2f80d28    	mov	x8, #-0x3f97000000000000 ; =-4582131145872769024
100196bd4: 9e670100    	fmov	d0, x8
100196bd8: 1e602920    	fadd	d0, d9, d0
100196bdc: 1e721001    	fmov	d1, #-4.00000000
100196be0: 1e612809    	fadd	d9, d0, d1
100196be4: 14000003    	b	0x100196bf0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x6f8>
100196be8: aa1403e0    	mov	x0, x20
100196bec: 9464cc51    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100196bf0: d2e80d28    	mov	x8, #0x4069000000000000 ; =4641240890982006784
100196bf4: 9e670100    	fmov	d0, x8
100196bf8: 4ea81d01    	mov.16b	v1, v8
100196bfc: 94000e3c    	bl	0x10019a4ec <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3ff4>
100196c00: 9464cc4f    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100196c04: 9464cc4e    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100196c08: aa0003f7    	mov	x23, x0
100196c0c: 4ea91d20    	mov.16b	v0, v9
100196c10: 4eaa1d41    	mov.16b	v1, v10
100196c14: 9464effb    	bl	0x101ad2c00 <_writev+0x101ad2c00>
100196c18: aa1703e0    	mov	x0, x23
100196c1c: 9464d6e1    	bl	0x101acc7a0 <_writev+0x101acc7a0>
100196c20: aa1d03fd    	mov	x29, x29
100196c24: 9464cc4c    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100196c28: aa0003f4    	mov	x20, x0
100196c2c: aa1703e0    	mov	x0, x23
100196c30: 9464cc40    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100196c34: b4007914    	cbz	x20, 0x100197b54 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x165c>
100196c38: aa1403e0    	mov	x0, x20
100196c3c: a900e3f7    	stp	x23, x24, [sp, #0x8]
100196c40: a901dbe0    	stp	x0, x22, [sp, #0x18]
100196c44: f100227f    	cmp	x19, #0x8
100196c48: 1a9f97f4    	cset	w20, hi
100196c4c: 9464d465    	bl	0x101acbde0 <_writev+0x101acbde0>
100196c50: 4ea01c08    	mov.16b	v8, v0
100196c54: 4ea11c29    	mov.16b	v9, v1
100196c58: 4ea21c4a    	mov.16b	v10, v2
100196c5c: 4ea31c6b    	mov.16b	v11, v3
100196c60: 90010c88    	adrp	x8, 0x102326000 <_writev+0x102326000>
100196c64: f945dd00    	ldr	x0, [x8, #0xbb8]
100196c68: 9464cc14    	bl	0x101ac9cb8 <_writev+0x101ac9cb8>
100196c6c: 4ea81d00    	mov.16b	v0, v8
100196c70: 4ea91d21    	mov.16b	v1, v9
100196c74: 4eaa1d42    	mov.16b	v2, v10
100196c78: 4eab1d63    	mov.16b	v3, v11
100196c7c: 9464de49    	bl	0x101ace5a0 <_writev+0x101ace5a0>
100196c80: aa0003f6    	mov	x22, x0
100196c84: aa1403e2    	mov	x2, x20
100196c88: 9464f02e    	bl	0x101ad2d40 <_writev+0x101ad2d40>
100196c8c: aa1603e0    	mov	x0, x22
100196c90: 52800002    	mov	w2, #0x0                ; =0
100196c94: 9464f013    	bl	0x101ad2ce0 <_writev+0x101ad2ce0>
100196c98: aa1603e0    	mov	x0, x22
100196c9c: 52800002    	mov	w2, #0x0                ; =0
100196ca0: 9464eef0    	bl	0x101ad2860 <_writev+0x101ad2860>
100196ca4: aa1603e0    	mov	x0, x22
100196ca8: 52800242    	mov	w2, #0x12               ; =18
100196cac: 9464ec45    	bl	0x101ad1dc0 <_writev+0x101ad1dc0>
100196cb0: aa1603e0    	mov	x0, x22
100196cb4: 52800022    	mov	w2, #0x1                ; =1
100196cb8: 9464f49a    	bl	0x101ad3f20 <_writev+0x101ad3f20>
100196cbc: f90003f6    	str	x22, [sp]
100196cc0: aa1603e0    	mov	x0, x22
100196cc4: 52800022    	mov	w2, #0x1                ; =1
100196cc8: 9464f7ce    	bl	0x101ad4c00 <_writev+0x101ad4c00>
100196ccc: 90010c88    	adrp	x8, 0x102326000 <_writev+0x102326000>
100196cd0: f945bd00    	ldr	x0, [x8, #0xb78]
100196cd4: 9464cbf9    	bl	0x101ac9cb8 <_writev+0x101ac9cb8>
100196cd8: 9464dd7a    	bl	0x101ace2c0 <_writev+0x101ace2c0>
100196cdc: aa0003f4    	mov	x20, x0
100196ce0: 52800022    	mov	w2, #0x1                ; =1
100196ce4: 9464f32f    	bl	0x101ad39a0 <_writev+0x101ad39a0>
100196ce8: 1e6e1000    	fmov	d0, #1.00000000
100196cec: aa1403e0    	mov	x0, x20
100196cf0: 9464f574    	bl	0x101ad42c0 <_writev+0x101ad42c0>
100196cf4: aa1403e0    	mov	x0, x20
100196cf8: 528000a2    	mov	w2, #0x5                ; =5
100196cfc: 9464eac9    	bl	0x101ad1820 <_writev+0x101ad1820>
100196d00: 1e621000    	fmov	d0, #4.00000000
100196d04: 1e621001    	fmov	d1, #4.00000000
100196d08: 1e621002    	fmov	d2, #4.00000000
100196d0c: 1e621003    	fmov	d3, #4.00000000
100196d10: f90027f4    	str	x20, [sp, #0x48]
100196d14: aa1403e0    	mov	x0, x20
100196d18: 9464eeea    	bl	0x101ad28c0 <_writev+0x101ad28c0>
100196d1c: 9100e340    	add	x0, x26, #0x38
100196d20: 910203e1    	add	x1, sp, #0x80
100196d24: 52800022    	mov	w2, #0x1                ; =1
100196d28: d2800003    	mov	x3, #0x0                ; =0
100196d2c: 9464ce35    	bl	0x101aca600 <_writev+0x101aca600>
100196d30: f9401f40    	ldr	x0, [x26, #0x38]
100196d34: b00109c8    	adrp	x8, 0x1022cf000 <_writev+0x1022cf000>
100196d38: f9425508    	ldr	x8, [x8, #0x4a8]
100196d3c: f9001f48    	str	x8, [x26, #0x38]
100196d40: 9464ce33    	bl	0x101aca60c <_writev+0x101aca60c>
100196d44: 910082b8    	add	x24, x21, #0x20
100196d48: 94000e89    	bl	0x10019a76c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x4274>
100196d4c: f90023e0    	str	x0, [sp, #0x40]
100196d50: d2800019    	mov	x25, #0x0               ; =0
100196d54: 900109a8    	adrp	x8, 0x1022ca000 <_writev+0x1022ca000>
100196d58: f9430d08    	ldr	x8, [x8, #0x618]
100196d5c: 9000e169    	adrp	x9, 0x101dc2000 <_writev+0x101dc2000>
100196d60: 91110129    	add	x9, x9, #0x440
100196d64: fd400108    	ldr	d8, [x8]
100196d68: d100812a    	sub	x10, x9, #0x20
100196d6c: d000e188    	adrp	x8, 0x101dc8000 <_writev+0x101dc8000>
100196d70: 91104108    	add	x8, x8, #0x410
100196d74: d000e189    	adrp	x9, 0x101dc8000 <_writev+0x101dc8000>
100196d78: 9110c129    	add	x9, x9, #0x430
100196d7c: d1008108    	sub	x8, x8, #0x20
100196d80: a902abe8    	stp	x8, x10, [sp, #0x28]
100196d84: d1008128    	sub	x8, x9, #0x20
100196d88: f9001fe8    	str	x8, [sp, #0x38]
100196d8c: d2e80d08    	mov	x8, #0x4068000000000000 ; =4640959416005296128
100196d90: 9e670109    	fmov	d9, x8
100196d94: f9002bfa    	str	x26, [sp, #0x50]
100196d98: ad410700    	ldp	q0, q1, [x24, #0x20]
100196d9c: ad0687e0    	stp	q0, q1, [sp, #0xd0]
100196da0: 3dc01300    	ldr	q0, [x24, #0x40]
100196da4: 9102c3f7    	add	x23, sp, #0xb0
100196da8: 3d8012e0    	str	q0, [x23, #0x40]
100196dac: 3cc49300    	ldur	q0, [x24, #0x49]
100196db0: 3c8492e0    	stur	q0, [x23, #0x49]
100196db4: ad400700    	ldp	q0, q1, [x24]
100196db8: ad0587e0    	stp	q0, q1, [sp, #0xb0]
100196dbc: a9445b55    	ldp	x21, x22, [x26, #0x40]
100196dc0: f94023fc    	ldr	x28, [sp, #0x40]
100196dc4: aa1c03e0    	mov	x0, x28
100196dc8: 9464cbbc    	bl	0x101ac9cb8 <_writev+0x101ac9cb8>
100196dcc: aa0003f4    	mov	x20, x0
100196dd0: 9102c3e0    	add	x0, sp, #0xb0
100196dd4: d103c3a1    	sub	x1, x29, #0xf0
100196dd8: 97ff0f70    	bl	0x10015ab98 <_$s11_RopeModule0A0V7BuilderV12_prefixTreesSayACyxGGvg+0x50c8>
100196ddc: aa1503e0    	mov	x0, x21
100196de0: 9464cbd7    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100196de4: aa0003f5    	mov	x21, x0
100196de8: aa1603e0    	mov	x0, x22
100196dec: 9464cbd4    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100196df0: aa0003f6    	mov	x22, x0
100196df4: d0010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100196df8: f940e108    	ldr	x8, [x8, #0x1c0]
100196dfc: f8286a9f    	str	xzr, [x20, x8]
100196e00: d0010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100196e04: f940e508    	ldr	x8, [x8, #0x1c8]
100196e08: f8286a9f    	str	xzr, [x20, x8]
100196e0c: d0010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100196e10: f940e908    	ldr	x8, [x8, #0x1d0]
100196e14: f8286a9f    	str	xzr, [x20, x8]
100196e18: d0010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100196e1c: f940d508    	ldr	x8, [x8, #0x1a8]
100196e20: 8b080288    	add	x8, x20, x8
100196e24: ad4583e1    	ldp	q1, q0, [sp, #0xb0]
100196e28: ad000101    	stp	q1, q0, [x8]
100196e2c: 3dc012e0    	ldr	q0, [x23, #0x40]
100196e30: 3cc492e1    	ldur	q1, [x23, #0x49]
100196e34: ad468be3    	ldp	q3, q2, [sp, #0xd0]
100196e38: 3c849101    	stur	q1, [x8, #0x49]
100196e3c: ad018102    	stp	q2, q0, [x8, #0x30]
100196e40: 3d800903    	str	q3, [x8, #0x20]
100196e44: d0010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100196e48: f940d908    	ldr	x8, [x8, #0x1b0]
100196e4c: f8286a99    	str	x25, [x20, x8]
100196e50: d0010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100196e54: f940ed08    	ldr	x8, [x8, #0x1d8]
100196e58: f8286a95    	str	x21, [x20, x8]
100196e5c: d0010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100196e60: f940f108    	ldr	x8, [x8, #0x1e0]
100196e64: f8286a80    	str	x0, [x20, x8]
100196e68: a94c6ffa    	ldp	x26, x27, [sp, #0xc0]
100196e6c: aa1503e0    	mov	x0, x21
100196e70: 9464cbb3    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100196e74: f90033e0    	str	x0, [sp, #0x60]
100196e78: aa1603e0    	mov	x0, x22
100196e7c: 9464cbb0    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100196e80: f9002fe0    	str	x0, [sp, #0x58]
100196e84: 9102c3e0    	add	x0, sp, #0xb0
100196e88: d103c3a1    	sub	x1, x29, #0xf0
100196e8c: 97ff0f43    	bl	0x10015ab98 <_$s11_RopeModule0A0V7BuilderV12_prefixTreesSayACyxGGvg+0x50c8>
100196e90: aa1a03e0    	mov	x0, x26
100196e94: aa1b03e1    	mov	x1, x27
100196e98: 9464bce8    	bl	0x101ac6238 <_writev+0x101ac6238>
100196e9c: aa0003f5    	mov	x21, x0
100196ea0: 90010c88    	adrp	x8, 0x102326000 <_writev+0x102326000>
100196ea4: f9459900    	ldr	x0, [x8, #0xb30]
100196ea8: 9464cb9f    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100196eac: aa1503e2    	mov	x2, x21
100196eb0: 9464e0e4    	bl	0x101acf240 <_writev+0x101acf240>
100196eb4: aa1d03fd    	mov	x29, x29
100196eb8: 9464cba7    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100196ebc: aa0003f6    	mov	x22, x0
100196ec0: aa1503e0    	mov	x0, x21
100196ec4: 9464cb9b    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100196ec8: d0010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100196ecc: f940dd17    	ldr	x23, [x8, #0x1b8]
100196ed0: f8376a96    	str	x22, [x20, x23]
100196ed4: aa1603e0    	mov	x0, x22
100196ed8: 9464cb99    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100196edc: aa0003f5    	mov	x21, x0
100196ee0: 1e651000    	fmov	d0, #12.00000000
100196ee4: 4ea81d01    	mov.16b	v1, v8
100196ee8: 97f9b644    	bl	0x1000047f8 <_$s9TextStory09CompositeA14StoringMonitorV8monitorsACSayAA0adE0_pG_tcfC+0x8b8>
100196eec: aa0003f6    	mov	x22, x0
100196ef0: aa1503e0    	mov	x0, x21
100196ef4: aa1603e2    	mov	x2, x22
100196ef8: 9464eeea    	bl	0x101ad2aa0 <_writev+0x101ad2aa0>
100196efc: aa1603e0    	mov	x0, x22
100196f00: 9464cb8c    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100196f04: aa1503e0    	mov	x0, x21
100196f08: 9464cb8a    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100196f0c: f8776a95    	ldr	x21, [x20, x23]
100196f10: 90010c88    	adrp	x8, 0x102326000 <_writev+0x102326000>
100196f14: f944e500    	ldr	x0, [x8, #0x9c8]
100196f18: 9464cb83    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100196f1c: aa0003fa    	mov	x26, x0
100196f20: aa1503e0    	mov	x0, x21
100196f24: 9464cb86    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100196f28: aa0003f5    	mov	x21, x0
100196f2c: aa1a03e0    	mov	x0, x26
100196f30: 9464e0bc    	bl	0x101acf220 <_writev+0x101acf220>
100196f34: aa1d03fd    	mov	x29, x29
100196f38: 9464cb87    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100196f3c: aa0003f6    	mov	x22, x0
100196f40: aa1503e0    	mov	x0, x21
100196f44: aa1603e2    	mov	x2, x22
100196f48: 9464f5c6    	bl	0x101ad4660 <_writev+0x101ad4660>
100196f4c: aa1603e0    	mov	x0, x22
100196f50: 9464cb78    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100196f54: aa1503e0    	mov	x0, x21
100196f58: 9464cb76    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100196f5c: f8776a80    	ldr	x0, [x20, x23]
100196f60: 52800082    	mov	w2, #0x4                ; =4
100196f64: 9464f0f7    	bl	0x101ad3340 <_writev+0x101ad3340>
100196f68: a93173b4    	stp	x20, x28, [x29, #-0xf0]
100196f6c: b0010c68    	adrp	x8, 0x102323000 <_writev+0x102323000>
100196f70: f9402901    	ldr	x1, [x8, #0x50]
100196f74: d103c3a0    	sub	x0, x29, #0xf0
100196f78: 6f00e400    	movi.2d	v0, #0000000000000000
100196f7c: 6f00e401    	movi.2d	v1, #0000000000000000
100196f80: 6f00e402    	movi.2d	v2, #0000000000000000
100196f84: 6f00e403    	movi.2d	v3, #0000000000000000
100196f88: 9464cb61    	bl	0x101ac9d0c <_writev+0x101ac9d0c>
100196f8c: aa1d03fd    	mov	x29, x29
100196f90: 9464cb71    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100196f94: aa0003f5    	mov	x21, x0
100196f98: 52800022    	mov	w2, #0x1                ; =1
100196f9c: 9464f741    	bl	0x101ad4ca0 <_writev+0x101ad4ca0>
100196fa0: aa1503e0    	mov	x0, x21
100196fa4: 9464e0c7    	bl	0x101acf2c0 <_writev+0x101acf2c0>
100196fa8: aa1d03fd    	mov	x29, x29
100196fac: 9464cb6a    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100196fb0: aa0003f4    	mov	x20, x0
100196fb4: aa1503e0    	mov	x0, x21
100196fb8: 9464cb5e    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100196fbc: b40000d4    	cbz	x20, 0x100196fd4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xadc>
100196fc0: 1e629000    	fmov	d0, #5.00000000
100196fc4: aa1403e0    	mov	x0, x20
100196fc8: 9464ed1e    	bl	0x101ad2440 <_writev+0x101ad2440>
100196fcc: aa1403e0    	mov	x0, x20
100196fd0: 9464cb58    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100196fd4: d0010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100196fd8: f940d508    	ldr	x8, [x8, #0x1a8]
100196fdc: 8b0802b7    	add	x23, x21, x8
100196fe0: 52800068    	mov	w8, #0x3                ; =3
100196fe4: 3901a3e8    	strb	w8, [sp, #0x68]
100196fe8: 97ff6adc    	bl	0x100171b58 <_$s8Markdown12ParseOptionsV19parseMinimalDoxygenACvgZ+0x14f04>
100196fec: aa0003fb    	mov	x27, x0
100196ff0: 9100c2e0    	add	x0, x23, #0x30
100196ff4: 9101a3e1    	add	x1, sp, #0x68
100196ff8: 90010176    	adrp	x22, 0x1021c2000 <_$s4Otty16SleepHelperNamesON+0x1f38>
100196ffc: 910322d6    	add	x22, x22, #0xc8
100197000: aa1603f4    	mov	x20, x22
100197004: aa1603e2    	mov	x2, x22
100197008: aa1b03e3    	mov	x3, x27
10019700c: 9464bc64    	bl	0x101ac619c <_writev+0x101ac619c>
100197010: 37000140    	tbnz	w0, #0x0, 0x100197038 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xb40>
100197014: 52800088    	mov	w8, #0x4                ; =4
100197018: 3901a3e8    	strb	w8, [sp, #0x68]
10019701c: 9100c2e0    	add	x0, x23, #0x30
100197020: 9101a3e1    	add	x1, sp, #0x68
100197024: aa1603f4    	mov	x20, x22
100197028: aa1603e2    	mov	x2, x22
10019702c: aa1b03e3    	mov	x3, x27
100197030: 9464bc5b    	bl	0x101ac619c <_writev+0x101ac619c>
100197034: 36000ac0    	tbz	w0, #0x0, 0x10019718c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xc94>
100197038: 394383e8    	ldrb	w8, [sp, #0xe0]
10019703c: 3901a3e8    	strb	w8, [sp, #0x68]
100197040: 52800088    	mov	w8, #0x4                ; =4
100197044: 3810f3a8    	sturb	w8, [x29, #-0xf1]
100197048: 9101a3e0    	add	x0, sp, #0x68
10019704c: d103c7a1    	sub	x1, x29, #0xf1
100197050: aa1603f4    	mov	x20, x22
100197054: aa1603e2    	mov	x2, x22
100197058: aa1b03e3    	mov	x3, x27
10019705c: 9464bc50    	bl	0x101ac619c <_writev+0x101ac619c>
100197060: aa0003f4    	mov	x20, x0
100197064: 9102c3e0    	add	x0, sp, #0xb0
100197068: 97ff0edb    	bl	0x10015abd4 <_$s11_RopeModule0A0V7BuilderV12_prefixTreesSayACyxGGvg+0x5104>
10019706c: 36000134    	tbz	w20, #0x0, 0x100197090 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xb98>
100197070: d28decc0    	mov	x0, #0x6f66             ; =28518
100197074: f2ac8d80    	movk	x0, #0x646c, lsl #16
100197078: f2ce4ca0    	movk	x0, #0x7265, lsl #32
10019707c: f2ecc5c0    	movk	x0, #0x662e, lsl #48
100197080: d28d8d21    	mov	x1, #0x6c69             ; =27753
100197084: f2a00d81    	movk	x1, #0x6c, lsl #16
100197088: f2fd6001    	movk	x1, #0xeb00, lsl #48
10019708c: 14000004    	b	0x10019709c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xba4>
100197090: 528dec80    	mov	w0, #0x6f64             ; =28516
100197094: 72a00c60    	movk	w0, #0x63, lsl #16
100197098: d2fc6001    	mov	x1, #-0x1d00000000000000 ; =-2089670227099910144
10019709c: 9464bc67    	bl	0x101ac6238 <_writev+0x101ac6238>
1001970a0: aa0003f6    	mov	x22, x0
1001970a4: f0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
1001970a8: f9459500    	ldr	x0, [x8, #0xb28]
1001970ac: 9464cb1e    	bl	0x101ac9d24 <_writev+0x101ac9d24>
1001970b0: aa1603e2    	mov	x2, x22
1001970b4: d2800003    	mov	x3, #0x0                ; =0
1001970b8: 9464dc5a    	bl	0x101ace220 <_writev+0x101ace220>
1001970bc: aa1d03fd    	mov	x29, x29
1001970c0: 9464cb25    	bl	0x101ac9d54 <_writev+0x101ac9d54>
1001970c4: aa0003f4    	mov	x20, x0
1001970c8: aa1603e0    	mov	x0, x22
1001970cc: 9464cb19    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001970d0: aa1403f6    	mov	x22, x20
1001970d4: b50000d4    	cbnz	x20, 0x1001970ec <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xbf4>
1001970d8: f0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
1001970dc: f9459500    	ldr	x0, [x8, #0xb28]
1001970e0: 9464caf6    	bl	0x101ac9cb8 <_writev+0x101ac9cb8>
1001970e4: 9464dc77    	bl	0x101ace2c0 <_writev+0x101ace2c0>
1001970e8: aa0003f6    	mov	x22, x0
1001970ec: f0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
1001970f0: f945a900    	ldr	x0, [x8, #0xb50]
1001970f4: 9464cb0c    	bl	0x101ac9d24 <_writev+0x101ac9d24>
1001970f8: aa0003fc    	mov	x28, x0
1001970fc: aa1403e0    	mov	x0, x20
100197100: 9464cb0f    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100197104: aa0003f4    	mov	x20, x0
100197108: aa1c03e0    	mov	x0, x28
10019710c: aa1603e2    	mov	x2, x22
100197110: 9464dc2c    	bl	0x101ace1c0 <_writev+0x101ace1c0>
100197114: aa1d03fd    	mov	x29, x29
100197118: 9464cb0f    	bl	0x101ac9d54 <_writev+0x101ac9d54>
10019711c: aa0003fc    	mov	x28, x0
100197120: aa1603e0    	mov	x0, x22
100197124: 9464cb03    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197128: aa1a03e0    	mov	x0, x26
10019712c: 9464e86d    	bl	0x101ad12e0 <_writev+0x101ad12e0>
100197130: aa1d03fd    	mov	x29, x29
100197134: 9464cb08    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197138: aa0003f6    	mov	x22, x0
10019713c: aa1c03e0    	mov	x0, x28
100197140: aa1603e2    	mov	x2, x22
100197144: 9464ec6f    	bl	0x101ad2300 <_writev+0x101ad2300>
100197148: aa1603e0    	mov	x0, x22
10019714c: 9464caf9    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197150: aa1503e0    	mov	x0, x21
100197154: aa1c03e2    	mov	x2, x28
100197158: 9464d0c2    	bl	0x101acb460 <_writev+0x101acb460>
10019715c: aa1403e0    	mov	x0, x20
100197160: 9464caf4    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197164: b0010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100197168: f940e108    	ldr	x8, [x8, #0x1c0]
10019716c: f8686aa0    	ldr	x0, [x21, x8]
100197170: f8286abc    	str	x28, [x21, x8]
100197174: 9464caef    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197178: f94016e1    	ldr	x1, [x23, #0x28]
10019717c: f0010156    	adrp	x22, 0x1021c2000 <_$s4Otty16SleepHelperNamesON+0x1f38>
100197180: 910322d6    	add	x22, x22, #0xc8
100197184: b50000c1    	cbnz	x1, 0x10019719c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xca4>
100197188: 14000039    	b	0x10019726c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xd74>
10019718c: 9102c3e0    	add	x0, sp, #0xb0
100197190: 97ff0e91    	bl	0x10015abd4 <_$s11_RopeModule0A0V7BuilderV12_prefixTreesSayACyxGGvg+0x5104>
100197194: f94016e1    	ldr	x1, [x23, #0x28]
100197198: b40006a1    	cbz	x1, 0x10019726c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xd74>
10019719c: f94012e0    	ldr	x0, [x23, #0x20]
1001971a0: d2fcc008    	mov	x8, #-0x1a00000000000000 ; =-1873497444986126336
1001971a4: eb08003f    	cmp	x1, x8
1001971a8: 54000121    	b.ne	0x1001971cc <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xcd4>
1001971ac: d28cae48    	mov	x8, #0x6572             ; =25970
1001971b0: f2acac68    	movk	x8, #0x6563, lsl #16
1001971b4: f2ce8dc8    	movk	x8, #0x746e, lsl #32
1001971b8: eb08001f    	cmp	x0, x8
1001971bc: 54000081    	b.ne	0x1001971cc <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xcd4>
1001971c0: d2fcc000    	mov	x0, #-0x1a00000000000000 ; =-1873497444986126336
1001971c4: 9464cd12    	bl	0x101aca60c <_writev+0x101aca60c>
1001971c8: 1400000b    	b	0x1001971f4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xcfc>
1001971cc: d28cae42    	mov	x2, #0x6572             ; =25970
1001971d0: f2acac62    	movk	x2, #0x6563, lsl #16
1001971d4: f2ce8dc2    	movk	x2, #0x746e, lsl #32
1001971d8: d2fcc003    	mov	x3, #-0x1a00000000000000 ; =-1873497444986126336
1001971dc: 52800004    	mov	w4, #0x0                ; =0
1001971e0: 9464c2ac    	bl	0x101ac7c90 <_writev+0x101ac7c90>
1001971e4: aa0003f4    	mov	x20, x0
1001971e8: d2fcc000    	mov	x0, #-0x1a00000000000000 ; =-1873497444986126336
1001971ec: 9464cd08    	bl	0x101aca60c <_writev+0x101aca60c>
1001971f0: 360003f4    	tbz	w20, #0x0, 0x10019726c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xd74>
1001971f4: d28d8c60    	mov	x0, #0x6c63             ; =27747
1001971f8: f2ac6de0    	movk	x0, #0x636f, lsl #16
1001971fc: f2c00d60    	movk	x0, #0x6b, lsl #32
100197200: d2fca001    	mov	x1, #-0x1b00000000000000 ; =-1945555039024054272
100197204: 9464bc0d    	bl	0x101ac6238 <_writev+0x101ac6238>
100197208: aa0003f6    	mov	x22, x0
10019720c: d28cae40    	mov	x0, #0x6572             ; =25970
100197210: f2acac60    	movk	x0, #0x6563, lsl #16
100197214: f2ce8dc0    	movk	x0, #0x746e, lsl #32
100197218: d2fcc001    	mov	x1, #-0x1a00000000000000 ; =-1873497444986126336
10019721c: 9464bc07    	bl	0x101ac6238 <_writev+0x101ac6238>
100197220: aa0003fb    	mov	x27, x0
100197224: f0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
100197228: f9459500    	ldr	x0, [x8, #0xb28]
10019722c: 9464cabe    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100197230: aa1603e2    	mov	x2, x22
100197234: aa1b03e3    	mov	x3, x27
100197238: 9464dbfa    	bl	0x101ace220 <_writev+0x101ace220>
10019723c: aa1d03fd    	mov	x29, x29
100197240: 9464cac5    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197244: aa0003f4    	mov	x20, x0
100197248: aa1b03e0    	mov	x0, x27
10019724c: 9464cab9    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197250: aa1603e0    	mov	x0, x22
100197254: 9464cab7    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197258: b40008b4    	cbz	x20, 0x10019736c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xe74>
10019725c: aa1403fb    	mov	x27, x20
100197260: b0010d97    	adrp	x23, 0x102348000 <_writev+0x102348000>
100197264: 910722f7    	add	x23, x23, #0x1c8
100197268: 14000074    	b	0x100197438 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xf40>
10019726c: 52800128    	mov	w8, #0x9                ; =9
100197270: 3901a3e8    	strb	w8, [sp, #0x68]
100197274: 9100c2e0    	add	x0, x23, #0x30
100197278: 9101a3e1    	add	x1, sp, #0x68
10019727c: aa1603f4    	mov	x20, x22
100197280: aa1603e2    	mov	x2, x22
100197284: aa1b03e3    	mov	x3, x27
100197288: 9464bbc5    	bl	0x101ac619c <_writev+0x101ac619c>
10019728c: 360002c0    	tbz	w0, #0x0, 0x1001972e4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xdec>
100197290: d2800288    	mov	x8, #0x14               ; =20
100197294: f2fa0008    	movk	x8, #0xd000, lsl #48
100197298: 91000500    	add	x0, x8, #0x1
10019729c: f9401fe8    	ldr	x8, [sp, #0x38]
1001972a0: b2410101    	orr	x1, x8, #0x8000000000000000
1001972a4: 9464bbe5    	bl	0x101ac6238 <_writev+0x101ac6238>
1001972a8: aa0003f6    	mov	x22, x0
1001972ac: d28cae40    	mov	x0, #0x6572             ; =25970
1001972b0: f2ac8c20    	movk	x0, #0x6461, lsl #16
1001972b4: f2ccada0    	movk	x0, #0x656d, lsl #32
1001972b8: d2fcc001    	mov	x1, #-0x1a00000000000000 ; =-1873497444986126336
1001972bc: 9464bbdf    	bl	0x101ac6238 <_writev+0x101ac6238>
1001972c0: aa0003fb    	mov	x27, x0
1001972c4: f0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
1001972c8: f9459500    	ldr	x0, [x8, #0xb28]
1001972cc: 9464ca96    	bl	0x101ac9d24 <_writev+0x101ac9d24>
1001972d0: aa1603e2    	mov	x2, x22
1001972d4: aa1b03e3    	mov	x3, x27
1001972d8: 9464dbd2    	bl	0x101ace220 <_writev+0x101ace220>
1001972dc: aa1d03fd    	mov	x29, x29
1001972e0: 14000043    	b	0x1001973ec <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xef4>
1001972e4: 52800148    	mov	w8, #0xa                ; =10
1001972e8: 3901a3e8    	strb	w8, [sp, #0x68]
1001972ec: 9100c2e0    	add	x0, x23, #0x30
1001972f0: 9101a3e1    	add	x1, sp, #0x68
1001972f4: aa1603f4    	mov	x20, x22
1001972f8: aa1603e2    	mov	x2, x22
1001972fc: aa1b03e3    	mov	x3, x27
100197300: 9464bba7    	bl	0x101ac619c <_writev+0x101ac619c>
100197304: 360003a0    	tbz	w0, #0x0, 0x100197378 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xe80>
100197308: d28dec40    	mov	x0, #0x6f62             ; =28514
10019730c: f2ad6de0    	movk	x0, #0x6b6f, lsl #16
100197310: f2cc2da0    	movk	x0, #0x616d, lsl #32
100197314: f2ed6e40    	movk	x0, #0x6b72, lsl #48
100197318: d28cc5c1    	mov	x1, #0x662e             ; =26158
10019731c: f2ad8d21    	movk	x1, #0x6c69, lsl #16
100197320: f2c00d81    	movk	x1, #0x6c, lsl #32
100197324: f2fda001    	movk	x1, #0xed00, lsl #48
100197328: 9464bbc4    	bl	0x101ac6238 <_writev+0x101ac6238>
10019732c: aa0003f6    	mov	x22, x0
100197330: d28cad80    	mov	x0, #0x656c             ; =25964
100197334: f2ae4c20    	movk	x0, #0x7261, lsl #16
100197338: f2ccadc0    	movk	x0, #0x656e, lsl #32
10019733c: f2e00c80    	movk	x0, #0x64, lsl #48
100197340: d2fce001    	mov	x1, #-0x1900000000000000 ; =-1801439850948198400
100197344: 9464bbbd    	bl	0x101ac6238 <_writev+0x101ac6238>
100197348: aa0003fb    	mov	x27, x0
10019734c: f0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
100197350: f9459500    	ldr	x0, [x8, #0xb28]
100197354: 9464ca74    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100197358: aa1603e2    	mov	x2, x22
10019735c: aa1b03e3    	mov	x3, x27
100197360: 9464dbb0    	bl	0x101ace220 <_writev+0x101ace220>
100197364: aa1d03fd    	mov	x29, x29
100197368: 14000021    	b	0x1001973ec <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xef4>
10019736c: b0010d97    	adrp	x23, 0x102348000 <_writev+0x102348000>
100197370: 910722f7    	add	x23, x23, #0x1c8
100197374: 1400002b    	b	0x100197420 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xf28>
100197378: 52800168    	mov	w8, #0xb                ; =11
10019737c: 3901a3e8    	strb	w8, [sp, #0x68]
100197380: 9100c2e0    	add	x0, x23, #0x30
100197384: 9101a3e1    	add	x1, sp, #0x68
100197388: aa1603f4    	mov	x20, x22
10019738c: aa1603e2    	mov	x2, x22
100197390: aa1b03e3    	mov	x3, x27
100197394: 9464bb82    	bl	0x101ac619c <_writev+0x101ac619c>
100197398: 36000940    	tbz	w0, #0x0, 0x1001974c0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xfc8>
10019739c: d2800288    	mov	x8, #0x14               ; =20
1001973a0: f2fa0008    	movk	x8, #0xd000, lsl #48
1001973a4: 91000900    	add	x0, x8, #0x2
1001973a8: f9401be8    	ldr	x8, [sp, #0x30]
1001973ac: b2410101    	orr	x1, x8, #0x8000000000000000
1001973b0: 9464bba2    	bl	0x101ac6238 <_writev+0x101ac6238>
1001973b4: aa0003f6    	mov	x22, x0
1001973b8: f94017e8    	ldr	x8, [sp, #0x28]
1001973bc: b2410101    	orr	x1, x8, #0x8000000000000000
1001973c0: d2800280    	mov	x0, #0x14               ; =20
1001973c4: f2fa0000    	movk	x0, #0xd000, lsl #48
1001973c8: 9464bb9c    	bl	0x101ac6238 <_writev+0x101ac6238>
1001973cc: aa0003fb    	mov	x27, x0
1001973d0: f0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
1001973d4: f9459500    	ldr	x0, [x8, #0xb28]
1001973d8: 9464ca53    	bl	0x101ac9d24 <_writev+0x101ac9d24>
1001973dc: aa1603e2    	mov	x2, x22
1001973e0: aa1b03e3    	mov	x3, x27
1001973e4: 9464db8f    	bl	0x101ace220 <_writev+0x101ace220>
1001973e8: aa1d03fd    	mov	x29, x29
1001973ec: 9464ca5a    	bl	0x101ac9d54 <_writev+0x101ac9d54>
1001973f0: aa0003f4    	mov	x20, x0
1001973f4: aa1b03e0    	mov	x0, x27
1001973f8: 9464ca4e    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001973fc: aa1603e0    	mov	x0, x22
100197400: 9464ca4c    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197404: b40000b4    	cbz	x20, 0x100197418 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xf20>
100197408: aa1403fb    	mov	x27, x20
10019740c: b0010d97    	adrp	x23, 0x102348000 <_writev+0x102348000>
100197410: 910742f7    	add	x23, x23, #0x1d0
100197414: 14000009    	b	0x100197438 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0xf40>
100197418: b0010d97    	adrp	x23, 0x102348000 <_writev+0x102348000>
10019741c: 910742f7    	add	x23, x23, #0x1d0
100197420: f0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
100197424: f9459500    	ldr	x0, [x8, #0xb28]
100197428: 9464ca24    	bl	0x101ac9cb8 <_writev+0x101ac9cb8>
10019742c: 9464dba5    	bl	0x101ace2c0 <_writev+0x101ace2c0>
100197430: aa0003fb    	mov	x27, x0
100197434: d2800014    	mov	x20, #0x0               ; =0
100197438: f0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
10019743c: f945a900    	ldr	x0, [x8, #0xb50]
100197440: 9464ca39    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100197444: aa0003f6    	mov	x22, x0
100197448: aa1403e0    	mov	x0, x20
10019744c: 9464ca3c    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100197450: aa0003f4    	mov	x20, x0
100197454: aa1603e0    	mov	x0, x22
100197458: aa1b03e2    	mov	x2, x27
10019745c: 9464db59    	bl	0x101ace1c0 <_writev+0x101ace1c0>
100197460: aa1d03fd    	mov	x29, x29
100197464: 9464ca3c    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197468: aa0003f6    	mov	x22, x0
10019746c: aa1b03e0    	mov	x0, x27
100197470: 9464ca30    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197474: aa1a03e0    	mov	x0, x26
100197478: 9464f90a    	bl	0x101ad58a0 <_writev+0x101ad58a0>
10019747c: aa1d03fd    	mov	x29, x29
100197480: 9464ca35    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197484: aa0003fa    	mov	x26, x0
100197488: aa1603e0    	mov	x0, x22
10019748c: aa1a03e2    	mov	x2, x26
100197490: 9464eb9c    	bl	0x101ad2300 <_writev+0x101ad2300>
100197494: aa1a03e0    	mov	x0, x26
100197498: 9464ca26    	bl	0x101ac9d30 <_writev+0x101ac9d30>
10019749c: aa1503e0    	mov	x0, x21
1001974a0: aa1603e2    	mov	x2, x22
1001974a4: 9464cfef    	bl	0x101acb460 <_writev+0x101acb460>
1001974a8: aa1403e0    	mov	x0, x20
1001974ac: 9464ca21    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001974b0: f94002e8    	ldr	x8, [x23]
1001974b4: f8686aa0    	ldr	x0, [x21, x8]
1001974b8: f8286ab6    	str	x22, [x21, x8]
1001974bc: 9464ca1d    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001974c0: b0010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
1001974c4: f940dd08    	ldr	x8, [x8, #0x1b8]
1001974c8: f8686aa2    	ldr	x2, [x21, x8]
1001974cc: aa1503e0    	mov	x0, x21
1001974d0: 9464cfe4    	bl	0x101acb460 <_writev+0x101acb460>
1001974d4: 52800000    	mov	w0, #0x0                ; =0
1001974d8: aa1503f4    	mov	x20, x21
1001974dc: 94000b43    	bl	0x10019a1e8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3cf0>
1001974e0: f94033e0    	ldr	x0, [sp, #0x60]
1001974e4: 9464ca13    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001974e8: f9402fe0    	ldr	x0, [sp, #0x58]
1001974ec: 9464ca11    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001974f0: aa1503e0    	mov	x0, x21
1001974f4: 9464ca12    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
1001974f8: aa0003f5    	mov	x21, x0
1001974fc: 52800002    	mov	w2, #0x0                ; =0
100197500: 9464f500    	bl	0x101ad4900 <_writev+0x101ad4900>
100197504: aa1503e0    	mov	x0, x21
100197508: 9464fb36    	bl	0x101ad61e0 <_writev+0x101ad61e0>
10019750c: aa1d03fd    	mov	x29, x29
100197510: 9464ca11    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197514: aa0003f4    	mov	x20, x0
100197518: 4ea91d20    	mov.16b	v0, v9
10019751c: 9464d449    	bl	0x101acc640 <_writev+0x101acc640>
100197520: aa1d03fd    	mov	x29, x29
100197524: 9464ca0c    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197528: aa0003f6    	mov	x22, x0
10019752c: aa1403e0    	mov	x0, x20
100197530: 9464ca00    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197534: aa1603e0    	mov	x0, x22
100197538: 52800022    	mov	w2, #0x1                ; =1
10019753c: 9464e8a9    	bl	0x101ad17e0 <_writev+0x101ad17e0>
100197540: aa1603e0    	mov	x0, x22
100197544: 9464c9fb    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197548: aa1503e0    	mov	x0, x21
10019754c: 9464da9d    	bl	0x101acdfc0 <_writev+0x101acdfc0>
100197550: aa1d03fd    	mov	x29, x29
100197554: 9464ca00    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197558: aa0003f4    	mov	x20, x0
10019755c: aa1503e0    	mov	x0, x21
100197560: 9464c9f4    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197564: 1e671000    	fmov	d0, #24.00000000
100197568: aa1403e0    	mov	x0, x20
10019756c: 9464d435    	bl	0x101acc640 <_writev+0x101acc640>
100197570: aa1d03fd    	mov	x29, x29
100197574: 9464c9f8    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197578: aa0003f6    	mov	x22, x0
10019757c: aa1403e0    	mov	x0, x20
100197580: 9464c9ec    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197584: aa1603e0    	mov	x0, x22
100197588: 52800022    	mov	w2, #0x1                ; =1
10019758c: 9464e895    	bl	0x101ad17e0 <_writev+0x101ad17e0>
100197590: aa1603e0    	mov	x0, x22
100197594: 9464c9e7    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197598: f94027e0    	ldr	x0, [sp, #0x48]
10019759c: aa1503e2    	mov	x2, x21
1001975a0: 9464cf00    	bl	0x101acb1a0 <_writev+0x101acb1a0>
1001975a4: f9402bfa    	ldr	x26, [sp, #0x50]
1001975a8: 9100e340    	add	x0, x26, #0x38
1001975ac: d103c3a1    	sub	x1, x29, #0xf0
1001975b0: 52800422    	mov	w2, #0x21               ; =33
1001975b4: d2800003    	mov	x3, #0x0                ; =0
1001975b8: 9464cc12    	bl	0x101aca600 <_writev+0x101aca600>
1001975bc: 9100e354    	add	x20, x26, #0x38
1001975c0: 9464bc62    	bl	0x101ac6748 <_writev+0x101ac6748>
1001975c4: f8438348    	ldur	x8, [x26, #0x38]
1001975c8: 927de108    	and	x8, x8, #0xffffffffffffff8
1001975cc: a9412116    	ldp	x22, x8, [x8, #0x10]
1001975d0: eb4806df    	cmp	x22, x8, lsr #1
1001975d4: 54000222    	b.hs	0x100197618 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1120>
1001975d8: 91000739    	add	x25, x25, #0x1
1001975dc: aa1503e0    	mov	x0, x21
1001975e0: 9464c9d7    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
1001975e4: aa0003f5    	mov	x21, x0
1001975e8: 9100e354    	add	x20, x26, #0x38
1001975ec: aa1603e0    	mov	x0, x22
1001975f0: aa1503e1    	mov	x1, x21
1001975f4: 9464bc73    	bl	0x101ac67c0 <_writev+0x101ac67c0>
1001975f8: d103c3a0    	sub	x0, x29, #0xf0
1001975fc: 9464cc4f    	bl	0x101aca738 <_writev+0x101aca738>
100197600: aa1503e0    	mov	x0, x21
100197604: 9464c9cb    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197608: 91018318    	add	x24, x24, #0x60
10019760c: eb19027f    	cmp	x19, x25
100197610: 54ffbc41    	b.ne	0x100196d98 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x8a0>
100197614: 14000008    	b	0x100197634 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x113c>
100197618: f100051f    	cmp	x8, #0x1
10019761c: 1a9f97e0    	cset	w0, hi
100197620: 910006c1    	add	x1, x22, #0x1
100197624: 9100e354    	add	x20, x26, #0x38
100197628: 52800022    	mov	w2, #0x1                ; =1
10019762c: 9464bc59    	bl	0x101ac6790 <_writev+0x101ac6790>
100197630: 17ffffea    	b	0x1001975d8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x10e0>
100197634: 9e630260    	ucvtf	d0, x19
100197638: 1e673001    	fmov	d1, #25.00000000
10019763c: 1e610800    	fmul	d0, d0, d1
100197640: 1e641001    	fmov	d1, #8.00000000
100197644: 1e612808    	fadd	d8, d0, d1
100197648: 94000c51    	bl	0x10019a78c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x4294>
10019764c: 9464c99b    	bl	0x101ac9cb8 <_writev+0x101ac9cb8>
100197650: d2e80d28    	mov	x8, #0x4069000000000000 ; =4641240890982006784
100197654: 9e670102    	fmov	d2, x8
100197658: 6f00e400    	movi.2d	v0, #0000000000000000
10019765c: 6f00e401    	movi.2d	v1, #0000000000000000
100197660: 4ea81d03    	mov.16b	v3, v8
100197664: 9464dbcf    	bl	0x101ace5a0 <_writev+0x101ace5a0>
100197668: aa1d03fd    	mov	x29, x29
10019766c: 9464c9ba    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197670: 9464c9b3    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100197674: 9464c9b2    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100197678: aa0003f5    	mov	x21, x0
10019767c: f94027e0    	ldr	x0, [sp, #0x48]
100197680: 9464c9af    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100197684: 9464c9ae    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100197688: aa0003f7    	mov	x23, x0
10019768c: aa1503e0    	mov	x0, x21
100197690: aa1703e2    	mov	x2, x23
100197694: 9464cf73    	bl	0x101acb460 <_writev+0x101acb460>
100197698: aa1703e0    	mov	x0, x23
10019769c: 52800002    	mov	w2, #0x0                ; =0
1001976a0: 9464f498    	bl	0x101ad4900 <_writev+0x101ad4900>
1001976a4: f0010c78    	adrp	x24, 0x102326000 <_writev+0x102326000>
1001976a8: 912e0318    	add	x24, x24, #0xb80
1001976ac: f9400300    	ldr	x0, [x24]
1001976b0: 9464c99d    	bl	0x101ac9d24 <_writev+0x101ac9d24>
1001976b4: aa0003f4    	mov	x20, x0
1001976b8: 90010d60    	adrp	x0, 0x102343000 <_writev+0x102343000>
1001976bc: 91088000    	add	x0, x0, #0x220
1001976c0: f000ca41    	adrp	x1, 0x101ae2000 <_writev+0x101ae2000>
1001976c4: 91320021    	add	x1, x1, #0xc80
1001976c8: 97f9b161    	bl	0x100003c4c <_$s9TextStory0A19MutationEventRouterCfD+0x578>
1001976cc: 52800701    	mov	w1, #0x38               ; =56
1001976d0: 528000e2    	mov	w2, #0x7                ; =7
1001976d4: 9464cbad    	bl	0x101aca588 <_writev+0x101aca588>
1001976d8: aa0003f9    	mov	x25, x0
1001976dc: f000ca48    	adrp	x8, 0x101ae2000 <_writev+0x101ae2000>
1001976e0: 3dc30d00    	ldr	q0, [x8, #0xc30]
1001976e4: 3d800400    	str	q0, [x0, #0x10]
1001976e8: aa1703e0    	mov	x0, x23
1001976ec: 9464f94d    	bl	0x101ad5c20 <_writev+0x101ad5c20>
1001976f0: aa1d03fd    	mov	x29, x29
1001976f4: 9464c998    	bl	0x101ac9d54 <_writev+0x101ac9d54>
1001976f8: aa0003f6    	mov	x22, x0
1001976fc: aa1503e0    	mov	x0, x21
100197700: 9464f948    	bl	0x101ad5c20 <_writev+0x101ad5c20>
100197704: aa1d03fd    	mov	x29, x29
100197708: 9464c993    	bl	0x101ac9d54 <_writev+0x101ac9d54>
10019770c: aa1a03f3    	mov	x19, x26
100197710: aa0003fa    	mov	x26, x0
100197714: aa1603e0    	mov	x0, x22
100197718: aa1a03e2    	mov	x2, x26
10019771c: 9464d3b9    	bl	0x101acc600 <_writev+0x101acc600>
100197720: aa1d03fd    	mov	x29, x29
100197724: 9464c98c    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197728: aa0003fb    	mov	x27, x0
10019772c: aa1603e0    	mov	x0, x22
100197730: 9464c980    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197734: aa1a03e0    	mov	x0, x26
100197738: 9464c97e    	bl	0x101ac9d30 <_writev+0x101ac9d30>
10019773c: f900133b    	str	x27, [x25, #0x20]
100197740: aa1703e0    	mov	x0, x23
100197744: 9464df0f    	bl	0x101acf380 <_writev+0x101acf380>
100197748: aa1d03fd    	mov	x29, x29
10019774c: 9464c982    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197750: aa0003f6    	mov	x22, x0
100197754: aa1703e0    	mov	x0, x23
100197758: 9464c976    	bl	0x101ac9d30 <_writev+0x101ac9d30>
10019775c: aa1503e0    	mov	x0, x21
100197760: 9464df08    	bl	0x101acf380 <_writev+0x101acf380>
100197764: aa1d03fd    	mov	x29, x29
100197768: 9464c97b    	bl	0x101ac9d54 <_writev+0x101ac9d54>
10019776c: aa0003fa    	mov	x26, x0
100197770: aa1503e0    	mov	x0, x21
100197774: 9464c96f    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197778: aa1603e0    	mov	x0, x22
10019777c: aa1a03e2    	mov	x2, x26
100197780: 9464d3a0    	bl	0x101acc600 <_writev+0x101acc600>
100197784: aa1d03fd    	mov	x29, x29
100197788: 9464c973    	bl	0x101ac9d54 <_writev+0x101ac9d54>
10019778c: aa0003fb    	mov	x27, x0
100197790: aa1603e0    	mov	x0, x22
100197794: 9464c967    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197798: aa1a03e0    	mov	x0, x26
10019779c: 9464c965    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001977a0: f900173b    	str	x27, [x25, #0x28]
1001977a4: aa1703e0    	mov	x0, x23
1001977a8: 9464f92e    	bl	0x101ad5c60 <_writev+0x101ad5c60>
1001977ac: aa1d03fd    	mov	x29, x29
1001977b0: 9464c969    	bl	0x101ac9d54 <_writev+0x101ac9d54>
1001977b4: aa0003f6    	mov	x22, x0
1001977b8: aa1703e0    	mov	x0, x23
1001977bc: 9464c95d    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001977c0: aa1503e0    	mov	x0, x21
1001977c4: 9464f927    	bl	0x101ad5c60 <_writev+0x101ad5c60>
1001977c8: aa1d03fd    	mov	x29, x29
1001977cc: 9464c962    	bl	0x101ac9d54 <_writev+0x101ac9d54>
1001977d0: aa0003fa    	mov	x26, x0
1001977d4: aa1503e0    	mov	x0, x21
1001977d8: 9464c956    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001977dc: aa1603e0    	mov	x0, x22
1001977e0: aa1a03e2    	mov	x2, x26
1001977e4: 9464d387    	bl	0x101acc600 <_writev+0x101acc600>
1001977e8: aa1d03fd    	mov	x29, x29
1001977ec: 9464c95a    	bl	0x101ac9d54 <_writev+0x101ac9d54>
1001977f0: aa0003fb    	mov	x27, x0
1001977f4: aa1603e0    	mov	x0, x22
1001977f8: 9464c94e    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001977fc: aa1a03e0    	mov	x0, x26
100197800: 9464c94c    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197804: f9001b3b    	str	x27, [x25, #0x30]
100197808: f0010d41    	adrp	x1, 0x102342000 <_writev+0x102342000>
10019780c: 91260021    	add	x1, x1, #0x980
100197810: d2800000    	mov	x0, #0x0                ; =0
100197814: aa1803e2    	mov	x2, x24
100197818: 97fa5859    	bl	0x10002d97c <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xab5c>
10019781c: aa0003e1    	mov	x1, x0
100197820: aa1903e0    	mov	x0, x25
100197824: 9464bbcc    	bl	0x101ac6754 <_writev+0x101ac6754>
100197828: aa0003f6    	mov	x22, x0
10019782c: aa1903e0    	mov	x0, x25
100197830: 9464cc4c    	bl	0x101aca960 <_writev+0x101aca960>
100197834: aa1403e0    	mov	x0, x20
100197838: aa1603e2    	mov	x2, x22
10019783c: 9464ce29    	bl	0x101acb0e0 <_writev+0x101acb0e0>
100197840: aa1603e0    	mov	x0, x22
100197844: 9464c93b    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197848: f94003f8    	ldr	x24, [sp]
10019784c: aa1803e0    	mov	x0, x24
100197850: aa1503e2    	mov	x2, x21
100197854: 9464ebbb    	bl	0x101ad2740 <_writev+0x101ad2740>
100197858: aa1503e0    	mov	x0, x21
10019785c: 9464c935    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197860: f9400ffb    	ldr	x27, [sp, #0x18]
100197864: aa1b03e0    	mov	x0, x27
100197868: aa1803e2    	mov	x2, x24
10019786c: 9464cefd    	bl	0x101acb460 <_writev+0x101acb460>
100197870: b000e188    	adrp	x8, 0x101dc8000 <_writev+0x101dc8000>
100197874: 910d4108    	add	x8, x8, #0x350
100197878: d1008108    	sub	x8, x8, #0x20
10019787c: d2800289    	mov	x9, #0x14               ; =20
100197880: f2fa0009    	movk	x9, #0xd000, lsl #48
100197884: 91004520    	add	x0, x9, #0x11
100197888: b2410101    	orr	x1, x8, #0x8000000000000000
10019788c: f9400be2    	ldr	x2, [sp, #0x10]
100197890: 97fb37d2    	bl	0x1000657d8 <_$s18OrderedCollections0A10DictionaryV8ElementsV11SubSequenceV8IteratorV4_endSivg+0x339c>
100197894: f94013fa    	ldr	x26, [sp, #0x20]
100197898: aa1a03e0    	mov	x0, x26
10019789c: 9464c925    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001978a0: aa1a03e0    	mov	x0, x26
1001978a4: f94007f6    	ldr	x22, [sp, #0x8]
1001978a8: aa1603e2    	mov	x2, x22
1001978ac: 52800023    	mov	w3, #0x1                ; =1
1001978b0: 9464ce5c    	bl	0x101acb220 <_writev+0x101acb220>
1001978b4: aa1603e0    	mov	x0, x22
1001978b8: d2800002    	mov	x2, #0x0                ; =0
1001978bc: 9464e161    	bl	0x101acfe40 <_writev+0x101acfe40>
1001978c0: aa1a03e0    	mov	x0, x26
1001978c4: 9464df97    	bl	0x101acf720 <_writev+0x101acf720>
1001978c8: f9400a74    	ldr	x20, [x19, #0x10]
1001978cc: f9000a76    	str	x22, [x19, #0x10]
1001978d0: aa1603e0    	mov	x0, x22
1001978d4: 9464c91a    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
1001978d8: aa0003f6    	mov	x22, x0
1001978dc: aa1403e0    	mov	x0, x20
1001978e0: 9464c914    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001978e4: f9401274    	ldr	x20, [x19, #0x20]
1001978e8: f9001278    	str	x24, [x19, #0x20]
1001978ec: aa1803e0    	mov	x0, x24
1001978f0: 9464c913    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
1001978f4: aa0003f8    	mov	x24, x0
1001978f8: aa1403e0    	mov	x0, x20
1001978fc: 9464c90d    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197900: aa1603e0    	mov	x0, x22
100197904: 9464d3a7    	bl	0x101acc7a0 <_writev+0x101acc7a0>
100197908: aa1d03fd    	mov	x29, x29
10019790c: 9464c912    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197910: aa0003f4    	mov	x20, x0
100197914: aa1603e0    	mov	x0, x22
100197918: 9464c906    	bl	0x101ac9d30 <_writev+0x101ac9d30>
10019791c: b4000574    	cbz	x20, 0x1001979c8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x14d0>
100197920: 94000c47    	bl	0x10019aa3c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x4544>
100197924: aa0003e1    	mov	x1, x0
100197928: aa1403e0    	mov	x0, x20
10019792c: 9464cb74    	bl	0x101aca6fc <_writev+0x101aca6fc>
100197930: b4000460    	cbz	x0, 0x1001979bc <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x14c4>
100197934: aa0003f9    	mov	x25, x0
100197938: 90010160    	adrp	x0, 0x1021c3000 <_$s4Otty16SleepHelperNamesON+0x2f38>
10019793c: 9108e000    	add	x0, x0, #0x238
100197940: 52800301    	mov	w1, #0x18               ; =24
100197944: 528000e2    	mov	w2, #0x7                ; =7
100197948: 9464cb10    	bl	0x101aca588 <_writev+0x101aca588>
10019794c: aa0003fa    	mov	x26, x0
100197950: 91004000    	add	x0, x0, #0x10
100197954: f9402bf3    	ldr	x19, [sp, #0x50]
100197958: aa1303e1    	mov	x1, x19
10019795c: 9464cc7f    	bl	0x101acab58 <_writev+0x101acab58>
100197960: b0010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100197964: f9401908    	ldr	x8, [x8, #0x30]
100197968: 8b080328    	add	x8, x25, x8
10019796c: a940711b    	ldp	x27, x28, [x8]
100197970: f0000009    	adrp	x9, 0x10019a000 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3b08>
100197974: 91297129    	add	x9, x9, #0xa5c
100197978: a9006909    	stp	x9, x26, [x8]
10019797c: aa1a03e0    	mov	x0, x26
100197980: 52800041    	mov	w1, #0x2                ; =2
100197984: 9464cc00    	bl	0x101aca984 <_writev+0x101aca984>
100197988: aa1b03e0    	mov	x0, x27
10019798c: f9400ffb    	ldr	x27, [sp, #0x18]
100197990: aa1c03e1    	mov	x1, x28
100197994: 97f9afab    	bl	0x100003840 <_$s9TextStory0A19MutationEventRouterCfD+0x16c>
100197998: aa1903e0    	mov	x0, x25
10019799c: 9464f959    	bl	0x101ad5f00 <_writev+0x101ad5f00>
1001979a0: aa1403e0    	mov	x0, x20
1001979a4: 9464c8e3    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001979a8: aa1a03e0    	mov	x0, x26
1001979ac: f94013fa    	ldr	x26, [sp, #0x20]
1001979b0: 52800041    	mov	w1, #0x2                ; =2
1001979b4: 9464cbee    	bl	0x101aca96c <_writev+0x101aca96c>
1001979b8: 14000004    	b	0x1001979c8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x14d0>
1001979bc: aa1403e0    	mov	x0, x20
1001979c0: 9464c8dc    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001979c4: f9402bf3    	ldr	x19, [sp, #0x50]
1001979c8: aa1303f4    	mov	x20, x19
1001979cc: 94000602    	bl	0x1001991d4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2cdc>
1001979d0: f0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
1001979d4: f9458100    	ldr	x0, [x8, #0xb00]
1001979d8: 9464c8d3    	bl	0x101ac9d24 <_writev+0x101ac9d24>
1001979dc: aa0003f4    	mov	x20, x0
1001979e0: 90010160    	adrp	x0, 0x1021c3000 <_$s4Otty16SleepHelperNamesON+0x2f38>
1001979e4: 9108e000    	add	x0, x0, #0x238
1001979e8: 52800301    	mov	w1, #0x18               ; =24
1001979ec: 528000e2    	mov	w2, #0x7                ; =7
1001979f0: 9464cae6    	bl	0x101aca588 <_writev+0x101aca588>
1001979f4: aa0003f9    	mov	x25, x0
1001979f8: 91004000    	add	x0, x0, #0x10
1001979fc: aa1303e1    	mov	x1, x19
100197a00: 9464cc56    	bl	0x101acab58 <_writev+0x101acab58>
100197a04: f0000008    	adrp	x8, 0x10019a000 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3b08>
100197a08: 911f4108    	add	x8, x8, #0x7d0
100197a0c: a93367a8    	stp	x8, x25, [x29, #-0xd0]
100197a10: 900109a8    	adrp	x8, 0x1022cb000 <_writev+0x1022cb000>
100197a14: f9418108    	ldr	x8, [x8, #0x300]
100197a18: f81103a8    	stur	x8, [x29, #-0xf0]
100197a1c: d000ca48    	adrp	x8, 0x101ae1000 <_writev+0x101ae1000>
100197a20: fd400100    	ldr	d0, [x8]
100197a24: fc1183a0    	stur	d0, [x29, #-0xe8]
100197a28: 90fff6c8    	adrp	x8, 0x10006f000 <_$s8Markdown17MarkupDumpOptionsV15printEverythingACvgZ+0x1dc4>
100197a2c: 912c9108    	add	x8, x8, #0xb24
100197a30: 90010169    	adrp	x9, 0x1021c3000 <_$s4Otty16SleepHelperNamesON+0x2f38>
100197a34: 91094129    	add	x9, x9, #0x250
100197a38: a93227a8    	stp	x8, x9, [x29, #-0xe0]
100197a3c: d103c3a0    	sub	x0, x29, #0xf0
100197a40: 9464c6b5    	bl	0x101ac9514 <_writev+0x101ac9514>
100197a44: aa0003f9    	mov	x25, x0
100197a48: f85383a0    	ldur	x0, [x29, #-0xc8]
100197a4c: 9464cbc5    	bl	0x101aca960 <_writev+0x101aca960>
100197a50: aa1403e0    	mov	x0, x20
100197a54: 528000c2    	mov	w2, #0x6                ; =6
100197a58: aa1903e3    	mov	x3, x25
100197a5c: 9464ce41    	bl	0x101acb360 <_writev+0x101acb360>
100197a60: aa1d03fd    	mov	x29, x29
100197a64: 9464c8bc    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197a68: aa0003f4    	mov	x20, x0
100197a6c: aa1903e0    	mov	x0, x25
100197a70: 9464c6ac    	bl	0x101ac9520 <_writev+0x101ac9520>
100197a74: b4000274    	cbz	x20, 0x100197ac0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x15c8>
100197a78: d103c3a8    	sub	x8, x29, #0xf0
100197a7c: aa1403e0    	mov	x0, x20
100197a80: 9464be44    	bl	0x101ac7390 <_writev+0x101ac7390>
100197a84: aa1403e0    	mov	x0, x20
100197a88: 9464cbf8    	bl	0x101acaa68 <_writev+0x101acaa68>
100197a8c: aa1a03e0    	mov	x0, x26
100197a90: 9464c8a8    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197a94: aa1603e0    	mov	x0, x22
100197a98: 9464c8a6    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197a9c: aa1803e0    	mov	x0, x24
100197aa0: 9464c8a4    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197aa4: aa1703e0    	mov	x0, x23
100197aa8: 9464c8a2    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197aac: aa1503e0    	mov	x0, x21
100197ab0: 9464c8a0    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197ab4: aa1b03e0    	mov	x0, x27
100197ab8: 9464c89e    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197abc: 14000010    	b	0x100197afc <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1604>
100197ac0: aa1a03e0    	mov	x0, x26
100197ac4: 9464c89b    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197ac8: aa1603e0    	mov	x0, x22
100197acc: 9464c899    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197ad0: aa1803e0    	mov	x0, x24
100197ad4: 9464c897    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197ad8: aa1703e0    	mov	x0, x23
100197adc: 9464c895    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197ae0: aa1503e0    	mov	x0, x21
100197ae4: 9464c893    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197ae8: aa1b03e0    	mov	x0, x27
100197aec: 9464c891    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197af0: 6f00e400    	movi.2d	v0, #0000000000000000
100197af4: 9102c3e8    	add	x8, sp, #0xb0
100197af8: ad030100    	stp	q0, q0, [x8, #0x60]
100197afc: f9402bf3    	ldr	x19, [sp, #0x50]
100197b00: 91016260    	add	x0, x19, #0x58
100197b04: 9101a3e1    	add	x1, sp, #0x68
100197b08: 52800422    	mov	w2, #0x21               ; =33
100197b0c: d2800003    	mov	x3, #0x0                ; =0
100197b10: 9464cabc    	bl	0x101aca600 <_writev+0x101aca600>
100197b14: d103c3a0    	sub	x0, x29, #0xf0
100197b18: 91016261    	add	x1, x19, #0x58
100197b1c: 97fa4b94    	bl	0x10002a96c <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x7b4c>
100197b20: 9101a3e0    	add	x0, sp, #0x68
100197b24: 9464cb05    	bl	0x101aca738 <_writev+0x101aca738>
100197b28: 910603ff    	add	sp, sp, #0x180
100197b2c: a9487bfd    	ldp	x29, x30, [sp, #0x80]
100197b30: a9474ff4    	ldp	x20, x19, [sp, #0x70]
100197b34: a94657f6    	ldp	x22, x21, [sp, #0x60]
100197b38: a9455ff8    	ldp	x24, x23, [sp, #0x50]
100197b3c: a94467fa    	ldp	x26, x25, [sp, #0x40]
100197b40: a9436ffc    	ldp	x28, x27, [sp, #0x30]
100197b44: 6d4223e9    	ldp	d9, d8, [sp, #0x20]
100197b48: 6d412beb    	ldp	d11, d10, [sp, #0x10]
100197b4c: 6cc933ed    	ldp	d13, d12, [sp], #0x90
100197b50: d65f03c0    	ret
100197b54: aa1603e0    	mov	x0, x22
100197b58: 9464c876    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197b5c: aa1703e0    	mov	x0, x23
100197b60: 9464c874    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197b64: d4200020    	brk	#0x1
100197b68: d10183ff    	sub	sp, sp, #0x60
100197b6c: a90357f6    	stp	x22, x21, [sp, #0x30]
100197b70: a9044ff4    	stp	x20, x19, [sp, #0x40]
100197b74: a9057bfd    	stp	x29, x30, [sp, #0x50]
100197b78: 910143fd    	add	x29, sp, #0x50
100197b7c: 94000596    	bl	0x1001991d4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2cdc>
100197b80: f9400e93    	ldr	x19, [x20, #0x18]
100197b84: b40002b3    	cbz	x19, 0x100197bd8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x16e0>
100197b88: 91014280    	add	x0, x20, #0x50
100197b8c: 9464cbd2    	bl	0x101acaad4 <_writev+0x101acaad4>
100197b90: aa0003f5    	mov	x21, x0
100197b94: aa1303e0    	mov	x0, x19
100197b98: 9464c869    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100197b9c: aa0003f3    	mov	x19, x0
100197ba0: b40000d5    	cbz	x21, 0x100197bb8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x16c0>
100197ba4: aa1503e0    	mov	x0, x21
100197ba8: aa1303e2    	mov	x2, x19
100197bac: 9464e395    	bl	0x101ad0a00 <_writev+0x101ad0a00>
100197bb0: aa1503e0    	mov	x0, x21
100197bb4: 9464c85f    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197bb8: aa1303e0    	mov	x0, x19
100197bbc: d2800002    	mov	x2, #0x0                ; =0
100197bc0: 9464e0c0    	bl	0x101acfec0 <_writev+0x101acfec0>
100197bc4: aa1303e0    	mov	x0, x19
100197bc8: 9464c85a    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197bcc: f9400e80    	ldr	x0, [x20, #0x18]
100197bd0: f9000e9f    	str	xzr, [x20, #0x18]
100197bd4: 9464c857    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197bd8: f9400a93    	ldr	x19, [x20, #0x10]
100197bdc: b40002b3    	cbz	x19, 0x100197c30 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1738>
100197be0: 91014280    	add	x0, x20, #0x50
100197be4: 9464cbbc    	bl	0x101acaad4 <_writev+0x101acaad4>
100197be8: aa0003f5    	mov	x21, x0
100197bec: aa1303e0    	mov	x0, x19
100197bf0: 9464c853    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100197bf4: aa0003f3    	mov	x19, x0
100197bf8: b40000d5    	cbz	x21, 0x100197c10 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1718>
100197bfc: aa1503e0    	mov	x0, x21
100197c00: aa1303e2    	mov	x2, x19
100197c04: 9464e37f    	bl	0x101ad0a00 <_writev+0x101ad0a00>
100197c08: aa1503e0    	mov	x0, x21
100197c0c: 9464c849    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197c10: aa1303e0    	mov	x0, x19
100197c14: d2800002    	mov	x2, #0x0                ; =0
100197c18: 9464e0aa    	bl	0x101acfec0 <_writev+0x101acfec0>
100197c1c: aa1303e0    	mov	x0, x19
100197c20: 9464c844    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197c24: f9400a80    	ldr	x0, [x20, #0x10]
100197c28: f9000a9f    	str	xzr, [x20, #0x10]
100197c2c: 9464c841    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197c30: f9401280    	ldr	x0, [x20, #0x20]
100197c34: f900129f    	str	xzr, [x20, #0x20]
100197c38: 9464c83e    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197c3c: 9100e280    	add	x0, x20, #0x38
100197c40: 910063e1    	add	x1, sp, #0x18
100197c44: 52800022    	mov	w2, #0x1                ; =1
100197c48: d2800003    	mov	x3, #0x0                ; =0
100197c4c: 9464ca6d    	bl	0x101aca600 <_writev+0x101aca600>
100197c50: f9401e80    	ldr	x0, [x20, #0x38]
100197c54: 900109d3    	adrp	x19, 0x1022cf000 <_writev+0x1022cf000>
100197c58: f9425673    	ldr	x19, [x19, #0x4a8]
100197c5c: f9001e93    	str	x19, [x20, #0x38]
100197c60: 9464ca6b    	bl	0x101aca60c <_writev+0x101aca60c>
100197c64: f9401680    	ldr	x0, [x20, #0x28]
100197c68: f9001693    	str	x19, [x20, #0x28]
100197c6c: 9464ca68    	bl	0x101aca60c <_writev+0x101aca60c>
100197c70: 9100c280    	add	x0, x20, #0x30
100197c74: 910003e1    	mov	x1, sp
100197c78: 52800022    	mov	w2, #0x1                ; =1
100197c7c: d2800003    	mov	x3, #0x0                ; =0
100197c80: 9464ca60    	bl	0x101aca600 <_writev+0x101aca600>
100197c84: 92800008    	mov	x8, #-0x1               ; =-1
100197c88: f9001a88    	str	x8, [x20, #0x30]
100197c8c: a9457bfd    	ldp	x29, x30, [sp, #0x50]
100197c90: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100197c94: a94357f6    	ldp	x22, x21, [sp, #0x30]
100197c98: 910183ff    	add	sp, sp, #0x60
100197c9c: d65f03c0    	ret
100197ca0: 6db92beb    	stp	d11, d10, [sp, #-0x70]!
100197ca4: 6d0123e9    	stp	d9, d8, [sp, #0x10]
100197ca8: a90267fa    	stp	x26, x25, [sp, #0x20]
100197cac: a9035ff8    	stp	x24, x23, [sp, #0x30]
100197cb0: a90457f6    	stp	x22, x21, [sp, #0x40]
100197cb4: a9054ff4    	stp	x20, x19, [sp, #0x50]
100197cb8: a9067bfd    	stp	x29, x30, [sp, #0x60]
100197cbc: 910183fd    	add	x29, sp, #0x60
100197cc0: d10103ff    	sub	sp, sp, #0x40
100197cc4: aa1403f3    	mov	x19, x20
100197cc8: aa0003f4    	mov	x20, x0
100197ccc: 900109a8    	adrp	x8, 0x1022cb000 <_writev+0x1022cb000>
100197cd0: f941e508    	ldr	x8, [x8, #0x3c8]
100197cd4: f9400108    	ldr	x8, [x8]
100197cd8: f81983a8    	stur	x8, [x29, #-0x68]
100197cdc: d2800000    	mov	x0, #0x0                ; =0
100197ce0: 9464b983    	bl	0x101ac62ec <_writev+0x101ac62ec>
100197ce4: aa0003f5    	mov	x21, x0
100197ce8: f85f801a    	ldur	x26, [x0, #-0x8]
100197cec: f9402348    	ldr	x8, [x26, #0x40]
100197cf0: aa0803e9    	mov	x9, x8
100197cf4: 900109b0    	adrp	x16, 0x1022cb000 <_writev+0x1022cb000>
100197cf8: f941ce10    	ldr	x16, [x16, #0x398]
100197cfc: d63f0200    	blr	x16
100197d00: 910003e9    	mov	x9, sp
100197d04: 91003d08    	add	x8, x8, #0xf
100197d08: 927ced08    	and	x8, x8, #0xfffffffffffffff0
100197d0c: cb080138    	sub	x24, x9, x8
100197d10: 9100031f    	mov	sp, x24
100197d14: aa1403e0    	mov	x0, x20
100197d18: 9422eb71    	bl	0x100a52adc <_otty_engine_ui_theme_json>
100197d1c: b4002640    	cbz	x0, 0x1001981e4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1cec>
100197d20: aa0003f4    	mov	x20, x0
100197d24: 9464b9e7    	bl	0x101ac64c0 <_writev+0x101ac64c0>
100197d28: aa0003f6    	mov	x22, x0
100197d2c: aa0103f9    	mov	x25, x1
100197d30: aa1403e0    	mov	x0, x20
100197d34: 9422ff03    	bl	0x100a57940 <_otty_free_string>
100197d38: a937e7b6    	stp	x22, x25, [x29, #-0x88]
100197d3c: aa1803e8    	mov	x8, x24
100197d40: 9464b95c    	bl	0x101ac62b0 <_writev+0x101ac62b0>
100197d44: 97fa4a75    	bl	0x10002a718 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x78f8>
100197d48: aa0003e3    	mov	x3, x0
100197d4c: f00109a2    	adrp	x2, 0x1022ce000 <_writev+0x1022ce000>
100197d50: f9401c42    	ldr	x2, [x2, #0x38]
100197d54: d10223b4    	sub	x20, x29, #0x88
100197d58: aa1803e0    	mov	x0, x24
100197d5c: 52800001    	mov	w1, #0x0                ; =0
100197d60: 9464bd62    	bl	0x101ac72e8 <_writev+0x101ac72e8>
100197d64: aa0003f7    	mov	x23, x0
100197d68: aa0103f6    	mov	x22, x1
100197d6c: f9400748    	ldr	x8, [x26, #0x8]
100197d70: aa1803e0    	mov	x0, x24
100197d74: aa1503e1    	mov	x1, x21
100197d78: d63f0100    	blr	x8
100197d7c: aa1903e0    	mov	x0, x25
100197d80: 9464ca23    	bl	0x101aca60c <_writev+0x101aca60c>
100197d84: d37cfec8    	lsr	x8, x22, #60
100197d88: f100391f    	cmp	x8, #0xe
100197d8c: 540022c8    	b.hi	0x1001981e4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1cec>
100197d90: f0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
100197d94: f9453d00    	ldr	x0, [x8, #0xa78]
100197d98: 9464c7e3    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100197d9c: aa0003f4    	mov	x20, x0
100197da0: aa1703e0    	mov	x0, x23
100197da4: aa1603e1    	mov	x1, x22
100197da8: 9464b447    	bl	0x101ac4ec4 <_writev+0x101ac4ec4>
100197dac: aa0003f5    	mov	x21, x0
100197db0: f81783bf    	stur	xzr, [x29, #-0x88]
100197db4: d10223a4    	sub	x4, x29, #0x88
100197db8: aa1403e0    	mov	x0, x20
100197dbc: aa1503e2    	mov	x2, x21
100197dc0: d2800003    	mov	x3, #0x0                ; =0
100197dc4: 9464cc07    	bl	0x101acade0 <_writev+0x101acade0>
100197dc8: aa1d03fd    	mov	x29, x29
100197dcc: 9464c7e2    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197dd0: aa0003f4    	mov	x20, x0
100197dd4: aa1503e0    	mov	x0, x21
100197dd8: 9464c7d6    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197ddc: f85783a0    	ldur	x0, [x29, #-0x88]
100197de0: b4000f94    	cbz	x20, 0x100197fd0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1ad8>
100197de4: 9464c7d6    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100197de8: d10223a8    	sub	x8, x29, #0x88
100197dec: aa1403e0    	mov	x0, x20
100197df0: 9464bd68    	bl	0x101ac7390 <_writev+0x101ac7390>
100197df4: aa1403e0    	mov	x0, x20
100197df8: 9464cb1c    	bl	0x101acaa68 <_writev+0x101acaa68>
100197dfc: d0010d40    	adrp	x0, 0x102341000 <_writev+0x102341000>
100197e00: 9113c000    	add	x0, x0, #0x4f0
100197e04: d000ca41    	adrp	x1, 0x101ae1000 <_writev+0x101ae1000>
100197e08: 9124c021    	add	x1, x1, #0x930
100197e0c: 97f9af90    	bl	0x100003c4c <_$s9TextStory0A19MutationEventRouterCfD+0x578>
100197e10: aa0003f5    	mov	x21, x0
100197e14: 900109d9    	adrp	x25, 0x1022cf000 <_writev+0x1022cf000>
100197e18: f9424b39    	ldr	x25, [x25, #0x490]
100197e1c: d10263a0    	sub	x0, x29, #0x98
100197e20: d10223a1    	sub	x1, x29, #0x88
100197e24: 91002322    	add	x2, x25, #0x8
100197e28: aa1503e3    	mov	x3, x21
100197e2c: 528000c4    	mov	w4, #0x6                ; =6
100197e30: 9464ca30    	bl	0x101aca6f0 <_writev+0x101aca6f0>
100197e34: 36001c60    	tbz	w0, #0x0, 0x1001981c0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1cc8>
100197e38: f85683b8    	ldur	x24, [x29, #-0x98]
100197e3c: f9400b08    	ldr	x8, [x24, #0x10]
100197e40: b4000ec8    	cbz	x8, 0x100198018 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1b20>
100197e44: d28c6c20    	mov	x0, #0x6361             ; =25441
100197e48: f2acac60    	movk	x0, #0x6563, lsl #16
100197e4c: f2ce8dc0    	movk	x0, #0x746e, lsl #32
100197e50: d2fcc001    	mov	x1, #-0x1a00000000000000 ; =-1873497444986126336
100197e54: aa1803f4    	mov	x20, x24
100197e58: 97fa3094    	bl	0x1000240a8 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x1288>
100197e5c: 36000de1    	tbz	w1, #0x0, 0x100198018 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1b20>
100197e60: f9401f08    	ldr	x8, [x24, #0x38]
100197e64: 8b001500    	add	x0, x8, x0, lsl #5
100197e68: d10223a1    	sub	x1, x29, #0x88
100197e6c: 97fa46e7    	bl	0x100029a08 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x6be8>
100197e70: d10263a0    	sub	x0, x29, #0x98
100197e74: d10223a1    	sub	x1, x29, #0x88
100197e78: 91002322    	add	x2, x25, #0x8
100197e7c: aa1503e3    	mov	x3, x21
100197e80: 528000c4    	mov	w4, #0x6                ; =6
100197e84: 9464ca1b    	bl	0x101aca6f0 <_writev+0x101aca6f0>
100197e88: 36000c80    	tbz	w0, #0x0, 0x100198018 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1b20>
100197e8c: f85683b4    	ldur	x20, [x29, #-0x98]
100197e90: f9400a88    	ldr	x8, [x20, #0x10]
100197e94: b4000be8    	cbz	x8, 0x100198010 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1b18>
100197e98: 52800e40    	mov	w0, #0x72               ; =114
100197e9c: d2fc2001    	mov	x1, #-0x1f00000000000000 ; =-2233785415175766016
100197ea0: 97fa3082    	bl	0x1000240a8 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x1288>
100197ea4: 36000b61    	tbz	w1, #0x0, 0x100198010 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1b18>
100197ea8: f9401e88    	ldr	x8, [x20, #0x38]
100197eac: 8b001500    	add	x0, x8, x0, lsl #5
100197eb0: d10223a1    	sub	x1, x29, #0x88
100197eb4: 97fa46d5    	bl	0x100029a08 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x6be8>
100197eb8: 900109c3    	adrp	x3, 0x1022cf000 <_writev+0x1022cf000>
100197ebc: f9443863    	ldr	x3, [x3, #0x870]
100197ec0: d10263a0    	sub	x0, x29, #0x98
100197ec4: d10223a1    	sub	x1, x29, #0x88
100197ec8: 91002322    	add	x2, x25, #0x8
100197ecc: 528000c4    	mov	w4, #0x6                ; =6
100197ed0: 9464ca08    	bl	0x101aca6f0 <_writev+0x101aca6f0>
100197ed4: 360009e0    	tbz	w0, #0x0, 0x100198010 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1b18>
100197ed8: f9400a88    	ldr	x8, [x20, #0x10]
100197edc: b40009a8    	cbz	x8, 0x100198010 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1b18>
100197ee0: fc5683a8    	ldur	d8, [x29, #-0x98]
100197ee4: 52800ce0    	mov	w0, #0x67               ; =103
100197ee8: d2fc2001    	mov	x1, #-0x1f00000000000000 ; =-2233785415175766016
100197eec: 97fa306f    	bl	0x1000240a8 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x1288>
100197ef0: 36000901    	tbz	w1, #0x0, 0x100198010 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1b18>
100197ef4: f9401e88    	ldr	x8, [x20, #0x38]
100197ef8: 8b001500    	add	x0, x8, x0, lsl #5
100197efc: d10223a1    	sub	x1, x29, #0x88
100197f00: 97fa46c2    	bl	0x100029a08 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x6be8>
100197f04: 900109c3    	adrp	x3, 0x1022cf000 <_writev+0x1022cf000>
100197f08: f9443863    	ldr	x3, [x3, #0x870]
100197f0c: d10263a0    	sub	x0, x29, #0x98
100197f10: d10223a1    	sub	x1, x29, #0x88
100197f14: 91002322    	add	x2, x25, #0x8
100197f18: 528000c4    	mov	w4, #0x6                ; =6
100197f1c: 9464c9f5    	bl	0x101aca6f0 <_writev+0x101aca6f0>
100197f20: 36000780    	tbz	w0, #0x0, 0x100198010 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1b18>
100197f24: f9400a88    	ldr	x8, [x20, #0x10]
100197f28: b4000748    	cbz	x8, 0x100198010 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1b18>
100197f2c: fc5683a9    	ldur	d9, [x29, #-0x98]
100197f30: 52800c40    	mov	w0, #0x62               ; =98
100197f34: d2fc2001    	mov	x1, #-0x1f00000000000000 ; =-2233785415175766016
100197f38: 97fa305c    	bl	0x1000240a8 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x1288>
100197f3c: 360006a1    	tbz	w1, #0x0, 0x100198010 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1b18>
100197f40: f9401e88    	ldr	x8, [x20, #0x38]
100197f44: 8b001500    	add	x0, x8, x0, lsl #5
100197f48: d10223a1    	sub	x1, x29, #0x88
100197f4c: 97fa46af    	bl	0x100029a08 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x6be8>
100197f50: aa1403e0    	mov	x0, x20
100197f54: 9464c9ae    	bl	0x101aca60c <_writev+0x101aca60c>
100197f58: 900109c3    	adrp	x3, 0x1022cf000 <_writev+0x1022cf000>
100197f5c: f9443863    	ldr	x3, [x3, #0x870]
100197f60: d10263a0    	sub	x0, x29, #0x98
100197f64: d10223a1    	sub	x1, x29, #0x88
100197f68: 91002322    	add	x2, x25, #0x8
100197f6c: 528000c4    	mov	w4, #0x6                ; =6
100197f70: 9464c9e0    	bl	0x101aca6f0 <_writev+0x101aca6f0>
100197f74: 36000520    	tbz	w0, #0x0, 0x100198018 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1b20>
100197f78: fc5683a0    	ldur	d0, [x29, #-0x98]
100197f7c: d2dc0008    	mov	x8, #0xe00000000000     ; =246290604621824
100197f80: f2e80de8    	movk	x8, #0x406f, lsl #48
100197f84: 9e670101    	fmov	d1, x8
100197f88: 1e611908    	fdiv	d8, d8, d1
100197f8c: 1e611929    	fdiv	d9, d9, d1
100197f90: f0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
100197f94: f944e500    	ldr	x0, [x8, #0x9c8]
100197f98: 1e61180a    	fdiv	d10, d0, d1
100197f9c: 9464c762    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100197fa0: 1e6e1003    	fmov	d3, #1.00000000
100197fa4: 4ea81d00    	mov.16b	v0, v8
100197fa8: 4ea91d21    	mov.16b	v1, v9
100197fac: 4eaa1d42    	mov.16b	v2, v10
100197fb0: 9464d12c    	bl	0x101acc460 <_writev+0x101acc460>
100197fb4: aa1d03fd    	mov	x29, x29
100197fb8: 9464c767    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100197fbc: f9402268    	ldr	x8, [x19, #0x40]
100197fc0: f9002260    	str	x0, [x19, #0x40]
100197fc4: aa0803e0    	mov	x0, x8
100197fc8: 9464c75a    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197fcc: 14000013    	b	0x100198018 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1b20>
100197fd0: aa0003f3    	mov	x19, x0
100197fd4: 9464c75a    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100197fd8: aa0003f4    	mov	x20, x0
100197fdc: aa1303e0    	mov	x0, x19
100197fe0: 9464b338    	bl	0x101ac4cc0 <_writev+0x101ac4cc0>
100197fe4: aa0003f3    	mov	x19, x0
100197fe8: aa1403e0    	mov	x0, x20
100197fec: 9464c751    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100197ff0: aa1303f5    	mov	x21, x19
100197ff4: 9464cae5    	bl	0x101acab88 <_writev+0x101acab88>
100197ff8: aa1703e0    	mov	x0, x23
100197ffc: aa1603e1    	mov	x1, x22
100198000: 97fa567c    	bl	0x10002d9f0 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xabd0>
100198004: aa1303e0    	mov	x0, x19
100198008: 9464c9cf    	bl	0x101aca744 <_writev+0x101aca744>
10019800c: 14000076    	b	0x1001981e4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1cec>
100198010: aa1403e0    	mov	x0, x20
100198014: 9464c97e    	bl	0x101aca60c <_writev+0x101aca60c>
100198018: f9400b08    	ldr	x8, [x24, #0x10]
10019801c: b4000da8    	cbz	x8, 0x1001981d0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1cd8>
100198020: d28ded00    	mov	x0, #0x6f68             ; =28520
100198024: f2acaec0    	movk	x0, #0x6576, lsl #16
100198028: f2c00e40    	movk	x0, #0x72, lsl #32
10019802c: d2fca001    	mov	x1, #-0x1b00000000000000 ; =-1945555039024054272
100198030: aa1803f4    	mov	x20, x24
100198034: 97fa301d    	bl	0x1000240a8 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x1288>
100198038: 36000cc1    	tbz	w1, #0x0, 0x1001981d0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1cd8>
10019803c: f9401f08    	ldr	x8, [x24, #0x38]
100198040: 8b001500    	add	x0, x8, x0, lsl #5
100198044: d10223a1    	sub	x1, x29, #0x88
100198048: 97fa4670    	bl	0x100029a08 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x6be8>
10019804c: aa1803e0    	mov	x0, x24
100198050: 9464c96f    	bl	0x101aca60c <_writev+0x101aca60c>
100198054: d10263a0    	sub	x0, x29, #0x98
100198058: d10223a1    	sub	x1, x29, #0x88
10019805c: 91002322    	add	x2, x25, #0x8
100198060: aa1503e3    	mov	x3, x21
100198064: 528000c4    	mov	w4, #0x6                ; =6
100198068: 9464c9a2    	bl	0x101aca6f0 <_writev+0x101aca6f0>
10019806c: 36000aa0    	tbz	w0, #0x0, 0x1001981c0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1cc8>
100198070: f85683b4    	ldur	x20, [x29, #-0x98]
100198074: f9400a88    	ldr	x8, [x20, #0x10]
100198078: b4000d48    	cbz	x8, 0x100198220 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1d28>
10019807c: 52800e40    	mov	w0, #0x72               ; =114
100198080: d2fc2001    	mov	x1, #-0x1f00000000000000 ; =-2233785415175766016
100198084: 97fa3009    	bl	0x1000240a8 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x1288>
100198088: 36000cc1    	tbz	w1, #0x0, 0x100198220 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1d28>
10019808c: f9401e88    	ldr	x8, [x20, #0x38]
100198090: 8b001500    	add	x0, x8, x0, lsl #5
100198094: d10223a1    	sub	x1, x29, #0x88
100198098: 97fa465c    	bl	0x100029a08 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x6be8>
10019809c: f00109a3    	adrp	x3, 0x1022cf000 <_writev+0x1022cf000>
1001980a0: f9443863    	ldr	x3, [x3, #0x870]
1001980a4: d10263a0    	sub	x0, x29, #0x98
1001980a8: d10223a1    	sub	x1, x29, #0x88
1001980ac: 91002322    	add	x2, x25, #0x8
1001980b0: 528000c4    	mov	w4, #0x6                ; =6
1001980b4: 9464c98f    	bl	0x101aca6f0 <_writev+0x101aca6f0>
1001980b8: 36000b40    	tbz	w0, #0x0, 0x100198220 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1d28>
1001980bc: f9400a88    	ldr	x8, [x20, #0x10]
1001980c0: b4000b08    	cbz	x8, 0x100198220 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1d28>
1001980c4: fc5683a8    	ldur	d8, [x29, #-0x98]
1001980c8: 52800ce0    	mov	w0, #0x67               ; =103
1001980cc: d2fc2001    	mov	x1, #-0x1f00000000000000 ; =-2233785415175766016
1001980d0: 97fa2ff6    	bl	0x1000240a8 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x1288>
1001980d4: 36000a61    	tbz	w1, #0x0, 0x100198220 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1d28>
1001980d8: f9401e88    	ldr	x8, [x20, #0x38]
1001980dc: 8b001500    	add	x0, x8, x0, lsl #5
1001980e0: d10223a1    	sub	x1, x29, #0x88
1001980e4: 97fa4649    	bl	0x100029a08 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x6be8>
1001980e8: f00109a3    	adrp	x3, 0x1022cf000 <_writev+0x1022cf000>
1001980ec: f9443863    	ldr	x3, [x3, #0x870]
1001980f0: d10263a0    	sub	x0, x29, #0x98
1001980f4: d10223a1    	sub	x1, x29, #0x88
1001980f8: 91002322    	add	x2, x25, #0x8
1001980fc: 528000c4    	mov	w4, #0x6                ; =6
100198100: 9464c97c    	bl	0x101aca6f0 <_writev+0x101aca6f0>
100198104: 360008e0    	tbz	w0, #0x0, 0x100198220 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1d28>
100198108: f9400a88    	ldr	x8, [x20, #0x10]
10019810c: b40008a8    	cbz	x8, 0x100198220 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1d28>
100198110: fc5683a9    	ldur	d9, [x29, #-0x98]
100198114: 52800c40    	mov	w0, #0x62               ; =98
100198118: d2fc2001    	mov	x1, #-0x1f00000000000000 ; =-2233785415175766016
10019811c: 97fa2fe3    	bl	0x1000240a8 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x1288>
100198120: 36000801    	tbz	w1, #0x0, 0x100198220 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1d28>
100198124: f9401e88    	ldr	x8, [x20, #0x38]
100198128: 8b001500    	add	x0, x8, x0, lsl #5
10019812c: d10223a1    	sub	x1, x29, #0x88
100198130: 97fa4636    	bl	0x100029a08 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x6be8>
100198134: aa1403e0    	mov	x0, x20
100198138: 9464c935    	bl	0x101aca60c <_writev+0x101aca60c>
10019813c: f00109a3    	adrp	x3, 0x1022cf000 <_writev+0x1022cf000>
100198140: f9443863    	ldr	x3, [x3, #0x870]
100198144: d10263a0    	sub	x0, x29, #0x98
100198148: d10223a1    	sub	x1, x29, #0x88
10019814c: 91002322    	add	x2, x25, #0x8
100198150: 528000c4    	mov	w4, #0x6                ; =6
100198154: 9464c967    	bl	0x101aca6f0 <_writev+0x101aca6f0>
100198158: 36000340    	tbz	w0, #0x0, 0x1001981c0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1cc8>
10019815c: fc5683a0    	ldur	d0, [x29, #-0x98]
100198160: d2dc0008    	mov	x8, #0xe00000000000     ; =246290604621824
100198164: f2e80de8    	movk	x8, #0x406f, lsl #48
100198168: 9e670101    	fmov	d1, x8
10019816c: 1e611908    	fdiv	d8, d8, d1
100198170: 1e611929    	fdiv	d9, d9, d1
100198174: d0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
100198178: f944e500    	ldr	x0, [x8, #0x9c8]
10019817c: 1e61180a    	fdiv	d10, d0, d1
100198180: 9464c6e9    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100198184: 1e6e1003    	fmov	d3, #1.00000000
100198188: 4ea81d00    	mov.16b	v0, v8
10019818c: 4ea91d21    	mov.16b	v1, v9
100198190: 4eaa1d42    	mov.16b	v2, v10
100198194: 9464d0b3    	bl	0x101acc460 <_writev+0x101acc460>
100198198: aa1d03fd    	mov	x29, x29
10019819c: 9464c6ee    	bl	0x101ac9d54 <_writev+0x101ac9d54>
1001981a0: aa0003f4    	mov	x20, x0
1001981a4: aa1703e0    	mov	x0, x23
1001981a8: aa1603e1    	mov	x1, x22
1001981ac: 97fa5611    	bl	0x10002d9f0 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xabd0>
1001981b0: f9402660    	ldr	x0, [x19, #0x48]
1001981b4: f9002674    	str	x20, [x19, #0x48]
1001981b8: 9464c6de    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001981bc: 1400000a    	b	0x1001981e4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1cec>
1001981c0: aa1703e0    	mov	x0, x23
1001981c4: aa1603e1    	mov	x1, x22
1001981c8: 97fa560a    	bl	0x10002d9f0 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xabd0>
1001981cc: 14000006    	b	0x1001981e4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1cec>
1001981d0: aa1703e0    	mov	x0, x23
1001981d4: aa1603e1    	mov	x1, x22
1001981d8: 97fa5606    	bl	0x10002d9f0 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xabd0>
1001981dc: aa1803e0    	mov	x0, x24
1001981e0: 9464c90b    	bl	0x101aca60c <_writev+0x101aca60c>
1001981e4: f85983a8    	ldur	x8, [x29, #-0x68]
1001981e8: f0010989    	adrp	x9, 0x1022cb000 <_writev+0x1022cb000>
1001981ec: f941e529    	ldr	x9, [x9, #0x3c8]
1001981f0: f9400129    	ldr	x9, [x9]
1001981f4: eb08013f    	cmp	x9, x8
1001981f8: 540001e1    	b.ne	0x100198234 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1d3c>
1001981fc: d10183bf    	sub	sp, x29, #0x60
100198200: a9467bfd    	ldp	x29, x30, [sp, #0x60]
100198204: a9454ff4    	ldp	x20, x19, [sp, #0x50]
100198208: a94457f6    	ldp	x22, x21, [sp, #0x40]
10019820c: a9435ff8    	ldp	x24, x23, [sp, #0x30]
100198210: a94267fa    	ldp	x26, x25, [sp, #0x20]
100198214: 6d4123e9    	ldp	d9, d8, [sp, #0x10]
100198218: 6cc72beb    	ldp	d11, d10, [sp], #0x70
10019821c: d65f03c0    	ret
100198220: aa1703e0    	mov	x0, x23
100198224: aa1603e1    	mov	x1, x22
100198228: 97fa55f2    	bl	0x10002d9f0 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xabd0>
10019822c: aa1403e0    	mov	x0, x20
100198230: 17ffffec    	b	0x1001981e0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1ce8>
100198234: 9464c506    	bl	0x101ac964c <_writev+0x101ac964c>
100198238: 6dbc23e9    	stp	d9, d8, [sp, #-0x40]!
10019823c: a90157f6    	stp	x22, x21, [sp, #0x10]
100198240: a9024ff4    	stp	x20, x19, [sp, #0x20]
100198244: a9037bfd    	stp	x29, x30, [sp, #0x30]
100198248: 9100c3fd    	add	x29, sp, #0x30
10019824c: f9401280    	ldr	x0, [x20, #0x20]
100198250: b4000640    	cbz	x0, 0x100198318 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1e20>
100198254: 4ea01c09    	mov.16b	v9, v0
100198258: 4ea11c28    	mov.16b	v8, v1
10019825c: 9464c6b8    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100198260: aa0003f3    	mov	x19, x0
100198264: 9464d3f7    	bl	0x101acd240 <_writev+0x101acd240>
100198268: aa1d03fd    	mov	x29, x29
10019826c: 9464c6ba    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198270: b40004e0    	cbz	x0, 0x10019830c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1e14>
100198274: aa0003f5    	mov	x21, x0
100198278: 4ea91d20    	mov.16b	v0, v9
10019827c: 4ea81d01    	mov.16b	v1, v8
100198280: d2800002    	mov	x2, #0x0                ; =0
100198284: 9464d1a7    	bl	0x101acc920 <_writev+0x101acc920>
100198288: 4ea11c28    	mov.16b	v8, v1
10019828c: aa1503e0    	mov	x0, x21
100198290: 9464c6a8    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198294: aa1303e0    	mov	x0, x19
100198298: 9464c6a6    	bl	0x101ac9d30 <_writev+0x101ac9d30>
10019829c: 1e721000    	fmov	d0, #-4.00000000
1001982a0: 1e602900    	fadd	d0, d8, d0
1001982a4: 1e602008    	fcmp	d0, #0.0
1001982a8: 54000364    	b.mi	0x100198314 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1e1c>
1001982ac: 1e673001    	fmov	d1, #25.00000000
1001982b0: 1e611800    	fdiv	d0, d0, d1
1001982b4: 9e660008    	fmov	x8, d0
1001982b8: 9240f908    	and	x8, x8, #0x7fffffffffffffff
1001982bc: 92f00209    	mov	x9, #0x7fefffffffffffff ; =9218868437227405311
1001982c0: eb09011f    	cmp	x8, x9
1001982c4: 5400036c    	b.gt	0x100198330 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1e38>
1001982c8: d2800028    	mov	x8, #0x1                ; =1
1001982cc: f2f87c08    	movk	x8, #0xc3e0, lsl #48
1001982d0: 9e670101    	fmov	d1, x8
1001982d4: 1e612000    	fcmp	d0, d1
1001982d8: 540002ed    	b.le	0x100198334 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1e3c>
1001982dc: d2e87c08    	mov	x8, #0x43e0000000000000 ; =4890909195324358656
1001982e0: 9e670101    	fmov	d1, x8
1001982e4: 1e612000    	fcmp	d0, d1
1001982e8: 54000285    	b.pl	0x100198338 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1e40>
1001982ec: 9e780000    	fcvtzs	x0, d0
1001982f0: b7f80120    	tbnz	x0, #0x3f, 0x100198314 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1e1c>
1001982f4: f9401688    	ldr	x8, [x20, #0x28]
1001982f8: f9400908    	ldr	x8, [x8, #0x10]
1001982fc: eb00011f    	cmp	x8, x0
100198300: 540000a9    	b.ls	0x100198314 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1e1c>
100198304: 52800001    	mov	w1, #0x0                ; =0
100198308: 14000005    	b	0x10019831c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1e24>
10019830c: aa1303e0    	mov	x0, x19
100198310: 9464c688    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198314: d2800000    	mov	x0, #0x0                ; =0
100198318: 52800021    	mov	w1, #0x1                ; =1
10019831c: a9437bfd    	ldp	x29, x30, [sp, #0x30]
100198320: a9424ff4    	ldp	x20, x19, [sp, #0x20]
100198324: a94157f6    	ldp	x22, x21, [sp, #0x10]
100198328: 6cc423e9    	ldp	d9, d8, [sp], #0x40
10019832c: d65f03c0    	ret
100198330: d4200020    	brk	#0x1
100198334: d4200020    	brk	#0x1
100198338: d4200020    	brk	#0x1
10019833c: d10283ff    	sub	sp, sp, #0xa0
100198340: a9065ff8    	stp	x24, x23, [sp, #0x60]
100198344: a90757f6    	stp	x22, x21, [sp, #0x70]
100198348: a9084ff4    	stp	x20, x19, [sp, #0x80]
10019834c: a9097bfd    	stp	x29, x30, [sp, #0x90]
100198350: 910243fd    	add	x29, sp, #0x90
100198354: b7f81280    	tbnz	x0, #0x3f, 0x1001985a4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x20ac>
100198358: f9401688    	ldr	x8, [x20, #0x28]
10019835c: f9400908    	ldr	x8, [x8, #0x10]
100198360: eb08001f    	cmp	x0, x8
100198364: 54001202    	b.hs	0x1001985a4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x20ac>
100198368: aa0003f5    	mov	x21, x0
10019836c: 9100c280    	add	x0, x20, #0x30
100198370: 910123e1    	add	x1, sp, #0x48
100198374: 52800022    	mov	w2, #0x1                ; =1
100198378: d2800003    	mov	x3, #0x0                ; =0
10019837c: 9464c8a1    	bl	0x101aca600 <_writev+0x101aca600>
100198380: f9401a93    	ldr	x19, [x20, #0x30]
100198384: f9001a95    	str	x21, [x20, #0x30]
100198388: b7f80933    	tbnz	x19, #0x3f, 0x1001984ac <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1fb4>
10019838c: 9100e280    	add	x0, x20, #0x38
100198390: 910003e1    	mov	x1, sp
100198394: d2800002    	mov	x2, #0x0                ; =0
100198398: d2800003    	mov	x3, #0x0                ; =0
10019839c: 9464c899    	bl	0x101aca600 <_writev+0x101aca600>
1001983a0: f9401e88    	ldr	x8, [x20, #0x38]
1001983a4: d37efd09    	lsr	x9, x8, #62
1001983a8: b5001189    	cbnz	x9, 0x1001985d8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x20e0>
1001983ac: 927de108    	and	x8, x8, #0xffffffffffffff8
1001983b0: f9400900    	ldr	x0, [x8, #0x10]
1001983b4: eb00027f    	cmp	x19, x0
1001983b8: 540007aa    	b.ge	0x1001984ac <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1fb4>
1001983bc: 9100e280    	add	x0, x20, #0x38
1001983c0: 9100c3e1    	add	x1, sp, #0x30
1001983c4: 52800402    	mov	w2, #0x20               ; =32
1001983c8: d2800003    	mov	x3, #0x0                ; =0
1001983cc: 9464c88d    	bl	0x101aca600 <_writev+0x101aca600>
1001983d0: f8438281    	ldur	x1, [x20, #0x38]
1001983d4: f242083f    	tst	x1, #0xc000000000000001
1001983d8: 54001181    	b.ne	0x100198608 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2110>
1001983dc: 927de028    	and	x8, x1, #0xffffffffffffff8
1001983e0: f9400908    	ldr	x8, [x8, #0x10]
1001983e4: eb08027f    	cmp	x19, x8
1001983e8: 54001162    	b.hs	0x100198614 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x211c>
1001983ec: 8b130c28    	add	x8, x1, x19, lsl #3
1001983f0: f9401100    	ldr	x0, [x8, #0x20]
1001983f4: 9464c652    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
1001983f8: aa0003f3    	mov	x19, x0
1001983fc: 9100c3e0    	add	x0, sp, #0x30
100198400: 9464c8ce    	bl	0x101aca738 <_writev+0x101aca738>
100198404: aa1303e0    	mov	x0, x19
100198408: 9464dbae    	bl	0x101acf2c0 <_writev+0x101acf2c0>
10019840c: aa1d03fd    	mov	x29, x29
100198410: 9464c651    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198414: d0010c78    	adrp	x24, 0x102326000 <_writev+0x102326000>
100198418: b40002a0    	cbz	x0, 0x10019846c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1f74>
10019841c: aa0003f5    	mov	x21, x0
100198420: f944e700    	ldr	x0, [x24, #0x9c8]
100198424: 9464c640    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100198428: 9464cf76    	bl	0x101acc200 <_writev+0x101acc200>
10019842c: aa1d03fd    	mov	x29, x29
100198430: 9464c649    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198434: aa0003f6    	mov	x22, x0
100198438: 9464ca32    	bl	0x101acad00 <_writev+0x101acad00>
10019843c: aa1d03fd    	mov	x29, x29
100198440: 9464c645    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198444: aa0003f7    	mov	x23, x0
100198448: aa1603e0    	mov	x0, x22
10019844c: 9464c639    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198450: aa1503e0    	mov	x0, x21
100198454: aa1703e2    	mov	x2, x23
100198458: 9464e66a    	bl	0x101ad1e00 <_writev+0x101ad1e00>
10019845c: aa1503e0    	mov	x0, x21
100198460: 9464c634    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198464: aa1703e0    	mov	x0, x23
100198468: 9464c632    	bl	0x101ac9d30 <_writev+0x101ac9d30>
10019846c: 90010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100198470: f940dd08    	ldr	x8, [x8, #0x1b8]
100198474: f8686a75    	ldr	x21, [x19, x8]
100198478: f944e700    	ldr	x0, [x24, #0x9c8]
10019847c: 9464c62a    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100198480: 9464db68    	bl	0x101acf220 <_writev+0x101acf220>
100198484: aa1d03fd    	mov	x29, x29
100198488: 9464c633    	bl	0x101ac9d54 <_writev+0x101ac9d54>
10019848c: aa0003f6    	mov	x22, x0
100198490: aa1503e0    	mov	x0, x21
100198494: aa1603e2    	mov	x2, x22
100198498: 9464f072    	bl	0x101ad4660 <_writev+0x101ad4660>
10019849c: aa1303e0    	mov	x0, x19
1001984a0: 9464c624    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001984a4: aa1603e0    	mov	x0, x22
1001984a8: 9464c622    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001984ac: f9401a93    	ldr	x19, [x20, #0x30]
1001984b0: 9100e280    	add	x0, x20, #0x38
1001984b4: 9100c3e1    	add	x1, sp, #0x30
1001984b8: d2800002    	mov	x2, #0x0                ; =0
1001984bc: d2800003    	mov	x3, #0x0                ; =0
1001984c0: 9464c850    	bl	0x101aca600 <_writev+0x101aca600>
1001984c4: f9401e88    	ldr	x8, [x20, #0x38]
1001984c8: d37efd09    	lsr	x9, x8, #62
1001984cc: b5000789    	cbnz	x9, 0x1001985bc <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x20c4>
1001984d0: 927de108    	and	x8, x8, #0xffffffffffffff8
1001984d4: f9400900    	ldr	x0, [x8, #0x10]
1001984d8: eb00027f    	cmp	x19, x0
1001984dc: 5400064a    	b.ge	0x1001985a4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x20ac>
1001984e0: f8430293    	ldur	x19, [x20, #0x30]
1001984e4: 9100e280    	add	x0, x20, #0x38
1001984e8: 910063e1    	add	x1, sp, #0x18
1001984ec: 52800402    	mov	w2, #0x20               ; =32
1001984f0: d2800003    	mov	x3, #0x0                ; =0
1001984f4: 9464c843    	bl	0x101aca600 <_writev+0x101aca600>
1001984f8: f8438281    	ldur	x1, [x20, #0x38]
1001984fc: f242083f    	tst	x1, #0xc000000000000001
100198500: 540007a1    	b.ne	0x1001985f4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x20fc>
100198504: b7f807f3    	tbnz	x19, #0x3f, 0x100198600 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2108>
100198508: 927de028    	and	x8, x1, #0xffffffffffffff8
10019850c: f9400908    	ldr	x8, [x8, #0x10]
100198510: eb08027f    	cmp	x19, x8
100198514: 54000782    	b.hs	0x100198604 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x210c>
100198518: 8b130c28    	add	x8, x1, x19, lsl #3
10019851c: f9401100    	ldr	x0, [x8, #0x20]
100198520: 9464c607    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100198524: aa0003f3    	mov	x19, x0
100198528: 910063e0    	add	x0, sp, #0x18
10019852c: 9464c883    	bl	0x101aca738 <_writev+0x101aca738>
100198530: aa1303e0    	mov	x0, x19
100198534: 9464db63    	bl	0x101acf2c0 <_writev+0x101acf2c0>
100198538: aa1d03fd    	mov	x29, x29
10019853c: 9464c606    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198540: b4000200    	cbz	x0, 0x100198580 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2088>
100198544: aa0003f4    	mov	x20, x0
100198548: 90010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
10019854c: f940f108    	ldr	x8, [x8, #0x1e0]
100198550: f8686a60    	ldr	x0, [x19, x8]
100198554: 9464c9eb    	bl	0x101acad00 <_writev+0x101acad00>
100198558: aa1d03fd    	mov	x29, x29
10019855c: 9464c5fe    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198560: aa0003f5    	mov	x21, x0
100198564: aa1403e0    	mov	x0, x20
100198568: aa1503e2    	mov	x2, x21
10019856c: 9464e625    	bl	0x101ad1e00 <_writev+0x101ad1e00>
100198570: aa1403e0    	mov	x0, x20
100198574: 9464c5ef    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198578: aa1503e0    	mov	x0, x21
10019857c: 9464c5ed    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198580: 90010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100198584: f940dd08    	ldr	x8, [x8, #0x1b8]
100198588: f8686a60    	ldr	x0, [x19, x8]
10019858c: 90010d88    	adrp	x8, 0x102348000 <_writev+0x102348000>
100198590: f940ed08    	ldr	x8, [x8, #0x1d8]
100198594: f8686a62    	ldr	x2, [x19, x8]
100198598: 9464f032    	bl	0x101ad4660 <_writev+0x101ad4660>
10019859c: aa1303e0    	mov	x0, x19
1001985a0: 9464c5e4    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001985a4: a9497bfd    	ldp	x29, x30, [sp, #0x90]
1001985a8: a9484ff4    	ldp	x20, x19, [sp, #0x80]
1001985ac: a94757f6    	ldp	x22, x21, [sp, #0x70]
1001985b0: a9465ff8    	ldp	x24, x23, [sp, #0x60]
1001985b4: 910283ff    	add	sp, sp, #0xa0
1001985b8: d65f03c0    	ret
1001985bc: 927de109    	and	x9, x8, #0xffffffffffffff8
1001985c0: b100051f    	cmn	x8, #0x1
1001985c4: 9a88c120    	csel	x0, x9, x8, gt
1001985c8: 9464bcce    	bl	0x101ac7900 <_writev+0x101ac7900>
1001985cc: eb00027f    	cmp	x19, x0
1001985d0: 54fff88b    	b.lt	0x1001984e0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1fe8>
1001985d4: 17fffff4    	b	0x1001985a4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x20ac>
1001985d8: 927de109    	and	x9, x8, #0xffffffffffffff8
1001985dc: b100051f    	cmn	x8, #0x1
1001985e0: 9a88c120    	csel	x0, x9, x8, gt
1001985e4: 9464bcc7    	bl	0x101ac7900 <_writev+0x101ac7900>
1001985e8: eb00027f    	cmp	x19, x0
1001985ec: 54ffee8b    	b.lt	0x1001983bc <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1ec4>
1001985f0: 17ffffaf    	b	0x1001984ac <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1fb4>
1001985f4: aa1303e0    	mov	x0, x19
1001985f8: 9464bbed    	bl	0x101ac75ac <_writev+0x101ac75ac>
1001985fc: 17ffffca    	b	0x100198524 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x202c>
100198600: d4200020    	brk	#0x1
100198604: d4200020    	brk	#0x1
100198608: aa1303e0    	mov	x0, x19
10019860c: 9464bbe8    	bl	0x101ac75ac <_writev+0x101ac75ac>
100198610: 17ffff7a    	b	0x1001983f8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1f00>
100198614: d4200020    	brk	#0x1
100198618: d10703ff    	sub	sp, sp, #0x1c0
10019861c: 6d123bef    	stp	d15, d14, [sp, #0x120]
100198620: 6d1333ed    	stp	d13, d12, [sp, #0x130]
100198624: 6d142beb    	stp	d11, d10, [sp, #0x140]
100198628: 6d1523e9    	stp	d9, d8, [sp, #0x150]
10019862c: a9166ffc    	stp	x28, x27, [sp, #0x160]
100198630: a91767fa    	stp	x26, x25, [sp, #0x170]
100198634: a9185ff8    	stp	x24, x23, [sp, #0x180]
100198638: a91957f6    	stp	x22, x21, [sp, #0x190]
10019863c: a91a4ff4    	stp	x20, x19, [sp, #0x1a0]
100198640: a91b7bfd    	stp	x29, x30, [sp, #0x1b0]
100198644: 9106c3fd    	add	x29, sp, #0x1b0
100198648: b7f80a00    	tbnz	x0, #0x3f, 0x100198788 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2290>
10019864c: f9401688    	ldr	x8, [x20, #0x28]
100198650: f9400908    	ldr	x8, [x8, #0x10]
100198654: eb08001f    	cmp	x0, x8
100198658: 54000982    	b.hs	0x100198788 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2290>
10019865c: f9400a93    	ldr	x19, [x20, #0x10]
100198660: b4000953    	cbz	x19, 0x100198788 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2290>
100198664: aa0003f6    	mov	x22, x0
100198668: 91014280    	add	x0, x20, #0x50
10019866c: 9464c91a    	bl	0x101acaad4 <_writev+0x101acaad4>
100198670: b40008c0    	cbz	x0, 0x100198788 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2290>
100198674: aa0003f5    	mov	x21, x0
100198678: aa1303e0    	mov	x0, x19
10019867c: 9464c5b0    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100198680: aa0003f3    	mov	x19, x0
100198684: aa1503e0    	mov	x0, x21
100198688: 9464da8e    	bl	0x101acf0c0 <_writev+0x101acf0c0>
10019868c: 34000960    	cbz	w0, 0x1001987b8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x22c0>
100198690: aa1503e0    	mov	x0, x21
100198694: 9464cc73    	bl	0x101acb860 <_writev+0x101acb860>
100198698: aa1d03fd    	mov	x29, x29
10019869c: 9464c5ae    	bl	0x101ac9d54 <_writev+0x101ac9d54>
1001986a0: b4000060    	cbz	x0, 0x1001986ac <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x21b4>
1001986a4: 9464c5a3    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001986a8: 14000044    	b	0x1001987b8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x22c0>
1001986ac: aa1503e0    	mov	x0, x21
1001986b0: 9464d9e4    	bl	0x101acee40 <_writev+0x101acee40>
1001986b4: 34000820    	cbz	w0, 0x1001987b8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x22c0>
1001986b8: f9401688    	ldr	x8, [x20, #0x28]
1001986bc: f9400909    	ldr	x9, [x8, #0x10]
1001986c0: eb0902df    	cmp	x22, x9
1001986c4: 54005802    	b.hs	0x1001991c4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2ccc>
1001986c8: aa1403f8    	mov	x24, x20
1001986cc: 52800c09    	mov	w9, #0x60               ; =96
1001986d0: 9b0922c8    	madd	x8, x22, x9, x8
1001986d4: ad428103    	ldp	q3, q0, [x8, #0x50]
1001986d8: 3cc69101    	ldur	q1, [x8, #0x69]
1001986dc: 3dc01102    	ldr	q2, [x8, #0x40]
1001986e0: 3d8037e3    	str	q3, [sp, #0xd0]
1001986e4: ad411103    	ldp	q3, q4, [x8, #0x20]
1001986e8: ad0513e3    	stp	q3, q4, [sp, #0xa0]
1001986ec: 3c8e93e1    	stur	q1, [sp, #0xe9]
1001986f0: 3d803be0    	str	q0, [sp, #0xe0]
1001986f4: 3d8033e2    	str	q2, [sp, #0xc0]
1001986f8: 394343f6    	ldrb	w22, [sp, #0xd0]
1001986fc: 381503b6    	sturb	w22, [x29, #-0xb0]
100198700: 52800068    	mov	w8, #0x3                ; =3
100198704: 3900c3e8    	strb	w8, [sp, #0x30]
100198708: 910283e0    	add	x0, sp, #0xa0
10019870c: 910103e1    	add	x1, sp, #0x40
100198710: 97ff0922    	bl	0x10015ab98 <_$s11_RopeModule0A0V7BuilderV12_prefixTreesSayACyxGGvg+0x50c8>
100198714: 97ff6511    	bl	0x100171b58 <_$s8Markdown12ParseOptionsV19parseMinimalDoxygenACvgZ+0x14f04>
100198718: aa0003f7    	mov	x23, x0
10019871c: d0010142    	adrp	x2, 0x1021c2000 <_$s4Otty16SleepHelperNamesON+0x1f38>
100198720: 91032042    	add	x2, x2, #0xc8
100198724: d102c3a0    	sub	x0, x29, #0xb0
100198728: 9100c3e1    	add	x1, sp, #0x30
10019872c: aa0203f4    	mov	x20, x2
100198730: aa1703e3    	mov	x3, x23
100198734: 9464b69a    	bl	0x101ac619c <_writev+0x101ac619c>
100198738: 37000180    	tbnz	w0, #0x0, 0x100198768 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2270>
10019873c: 390103f6    	strb	w22, [sp, #0x40]
100198740: 52800088    	mov	w8, #0x4                ; =4
100198744: 381503a8    	sturb	w8, [x29, #-0xb0]
100198748: d0010142    	adrp	x2, 0x1021c2000 <_$s4Otty16SleepHelperNamesON+0x1f38>
10019874c: 91032042    	add	x2, x2, #0xc8
100198750: 910103e0    	add	x0, sp, #0x40
100198754: d102c3a1    	sub	x1, x29, #0xb0
100198758: aa0203f4    	mov	x20, x2
10019875c: aa1703e3    	mov	x3, x23
100198760: 9464b68f    	bl	0x101ac619c <_writev+0x101ac619c>
100198764: 360004a0    	tbz	w0, #0x0, 0x1001987f8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2300>
100198768: 910283e0    	add	x0, sp, #0xa0
10019876c: 97ff091a    	bl	0x10015abd4 <_$s11_RopeModule0A0V7BuilderV12_prefixTreesSayACyxGGvg+0x5104>
100198770: aa1803f4    	mov	x20, x24
100198774: 94000351    	bl	0x1001994b8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2fc0>
100198778: aa1303e0    	mov	x0, x19
10019877c: 9464c56d    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198780: aa1503e0    	mov	x0, x21
100198784: 9464c56b    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198788: a95b7bfd    	ldp	x29, x30, [sp, #0x1b0]
10019878c: a95a4ff4    	ldp	x20, x19, [sp, #0x1a0]
100198790: a95957f6    	ldp	x22, x21, [sp, #0x190]
100198794: a9585ff8    	ldp	x24, x23, [sp, #0x180]
100198798: a95767fa    	ldp	x26, x25, [sp, #0x170]
10019879c: a9566ffc    	ldp	x28, x27, [sp, #0x160]
1001987a0: 6d5523e9    	ldp	d9, d8, [sp, #0x150]
1001987a4: 6d542beb    	ldp	d11, d10, [sp, #0x140]
1001987a8: 6d5333ed    	ldp	d13, d12, [sp, #0x130]
1001987ac: 6d523bef    	ldp	d15, d14, [sp, #0x120]
1001987b0: 910703ff    	add	sp, sp, #0x1c0
1001987b4: d65f03c0    	ret
1001987b8: 94000340    	bl	0x1001994b8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2fc0>
1001987bc: aa1303e0    	mov	x0, x19
1001987c0: 9464c55c    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001987c4: aa1503e0    	mov	x0, x21
1001987c8: a95b7bfd    	ldp	x29, x30, [sp, #0x1b0]
1001987cc: a95a4ff4    	ldp	x20, x19, [sp, #0x1a0]
1001987d0: a95957f6    	ldp	x22, x21, [sp, #0x190]
1001987d4: a9585ff8    	ldp	x24, x23, [sp, #0x180]
1001987d8: a95767fa    	ldp	x26, x25, [sp, #0x170]
1001987dc: a9566ffc    	ldp	x28, x27, [sp, #0x160]
1001987e0: 6d5523e9    	ldp	d9, d8, [sp, #0x150]
1001987e4: 6d542beb    	ldp	d11, d10, [sp, #0x140]
1001987e8: 6d5333ed    	ldp	d13, d12, [sp, #0x130]
1001987ec: 6d523bef    	ldp	d15, d14, [sp, #0x120]
1001987f0: 910703ff    	add	sp, sp, #0x1c0
1001987f4: 1464c54f    	b	0x101ac9d30 <_writev+0x101ac9d30>
1001987f8: 910283e0    	add	x0, sp, #0xa0
1001987fc: 94000350    	bl	0x10019953c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3044>
100198800: aa0003fc    	mov	x28, x0
100198804: aa0103f9    	mov	x25, x1
100198808: 390103f6    	strb	w22, [sp, #0x40]
10019880c: 52800128    	mov	w8, #0x9                ; =9
100198810: 381503a8    	sturb	w8, [x29, #-0xb0]
100198814: d0010142    	adrp	x2, 0x1021c2000 <_$s4Otty16SleepHelperNamesON+0x1f38>
100198818: 91032042    	add	x2, x2, #0xc8
10019881c: 910103e0    	add	x0, sp, #0x40
100198820: d102c3a1    	sub	x1, x29, #0xb0
100198824: aa0203f4    	mov	x20, x2
100198828: aa1703e3    	mov	x3, x23
10019882c: 9464b65c    	bl	0x101ac619c <_writev+0x101ac619c>
100198830: 37000180    	tbnz	w0, #0x0, 0x100198860 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2368>
100198834: 390103f6    	strb	w22, [sp, #0x40]
100198838: 52800148    	mov	w8, #0xa                ; =10
10019883c: 381503a8    	sturb	w8, [x29, #-0xb0]
100198840: d0010142    	adrp	x2, 0x1021c2000 <_$s4Otty16SleepHelperNamesON+0x1f38>
100198844: 91032042    	add	x2, x2, #0xc8
100198848: 910103e0    	add	x0, sp, #0x40
10019884c: d102c3a1    	sub	x1, x29, #0xb0
100198850: aa0203f4    	mov	x20, x2
100198854: aa1703e3    	mov	x3, x23
100198858: 9464b651    	bl	0x101ac619c <_writev+0x101ac619c>
10019885c: 360000c0    	tbz	w0, #0x0, 0x100198874 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x237c>
100198860: a94eebe8    	ldp	x8, x26, [sp, #0xe8]
100198864: f90013e8    	str	x8, [sp, #0x20]
100198868: aa1a03e0    	mov	x0, x26
10019886c: 9464c76e    	bl	0x101aca624 <_writev+0x101aca624>
100198870: 14000003    	b	0x10019887c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2384>
100198874: f90013ff    	str	xzr, [sp, #0x20]
100198878: d280001a    	mov	x26, #0x0               ; =0
10019887c: 390103f6    	strb	w22, [sp, #0x40]
100198880: 52800168    	mov	w8, #0xb                ; =11
100198884: 381503a8    	sturb	w8, [x29, #-0xb0]
100198888: d0010142    	adrp	x2, 0x1021c2000 <_$s4Otty16SleepHelperNamesON+0x1f38>
10019888c: 91032042    	add	x2, x2, #0xc8
100198890: 910103e0    	add	x0, sp, #0x40
100198894: d102c3a1    	sub	x1, x29, #0xb0
100198898: aa0203f4    	mov	x20, x2
10019889c: aa1703e3    	mov	x3, x23
1001988a0: 9464b63f    	bl	0x101ac619c <_writev+0x101ac619c>
1001988a4: 360000c0    	tbz	w0, #0x0, 0x1001988bc <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x23c4>
1001988a8: a94a6fe8    	ldp	x8, x27, [sp, #0xa0]
1001988ac: f90007e8    	str	x8, [sp, #0x8]
1001988b0: aa1b03e0    	mov	x0, x27
1001988b4: 9464c75c    	bl	0x101aca624 <_writev+0x101aca624>
1001988b8: 14000003    	b	0x1001988c4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x23cc>
1001988bc: f90007ff    	str	xzr, [sp, #0x8]
1001988c0: d280001b    	mov	x27, #0x0               ; =0
1001988c4: aa1803f4    	mov	x20, x24
1001988c8: b5000359    	cbnz	x25, 0x100198930 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2438>
1001988cc: b500033a    	cbnz	x26, 0x100198930 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2438>
1001988d0: b500031b    	cbnz	x27, 0x100198930 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2438>
1001988d4: f94067e1    	ldr	x1, [sp, #0xc8]
1001988d8: b4000261    	cbz	x1, 0x100198924 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x242c>
1001988dc: f94063e0    	ldr	x0, [sp, #0xc0]
1001988e0: 9240bc08    	and	x8, x0, #0xffffffffffff
1001988e4: d378ec29    	ubfx	x9, x1, #56, #4
1001988e8: f243003f    	tst	x1, #0x2000000000000000
1001988ec: 9a890108    	csel	x8, x8, x9, eq
1001988f0: b40001a8    	cbz	x8, 0x100198924 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x242c>
1001988f4: d28cae42    	mov	x2, #0x6572             ; =25970
1001988f8: f2acac62    	movk	x2, #0x6563, lsl #16
1001988fc: f2ce8dc2    	movk	x2, #0x746e, lsl #32
100198900: eb02001f    	cmp	x0, x2
100198904: 54000081    	b.ne	0x100198914 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x241c>
100198908: d2fcc008    	mov	x8, #-0x1a00000000000000 ; =-1873497444986126336
10019890c: eb08003f    	cmp	x1, x8
100198910: 540000a0    	b.eq	0x100198924 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x242c>
100198914: d2fcc003    	mov	x3, #-0x1a00000000000000 ; =-1873497444986126336
100198918: 52800004    	mov	w4, #0x0                ; =0
10019891c: 9464bcdd    	bl	0x101ac7c90 <_writev+0x101ac7c90>
100198920: 36000080    	tbz	w0, #0x0, 0x100198930 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2438>
100198924: 910283e0    	add	x0, sp, #0xa0
100198928: 97ff08ab    	bl	0x10015abd4 <_$s11_RopeModule0A0V7BuilderV12_prefixTreesSayACyxGGvg+0x5104>
10019892c: 17ffff92    	b	0x100198774 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x227c>
100198930: f90003fc    	str	x28, [sp]
100198934: 940002e1    	bl	0x1001994b8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2fc0>
100198938: d2e80dc8    	mov	x8, #0x406e000000000000 ; =4642648265865560064
10019893c: 9e670100    	fmov	d0, x8
100198940: d2e809c8    	mov	x8, #0x404e000000000000 ; =4633641066610819072
100198944: 9e670101    	fmov	d1, x8
100198948: 940006e9    	bl	0x10019a4ec <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3ff4>
10019894c: f90017e0    	str	x0, [sp, #0x28]
100198950: 390103f6    	strb	w22, [sp, #0x40]
100198954: 52800168    	mov	w8, #0xb                ; =11
100198958: 381503a8    	sturb	w8, [x29, #-0xb0]
10019895c: d0010142    	adrp	x2, 0x1021c2000 <_$s4Otty16SleepHelperNamesON+0x1f38>
100198960: 91032042    	add	x2, x2, #0xc8
100198964: 910103e0    	add	x0, sp, #0x40
100198968: d102c3a1    	sub	x1, x29, #0xb0
10019896c: aa0203f4    	mov	x20, x2
100198970: aa1703e3    	mov	x3, x23
100198974: 9464b60a    	bl	0x101ac619c <_writev+0x101ac619c>
100198978: f9000bf8    	str	x24, [sp, #0x10]
10019897c: 36000100    	tbz	w0, #0x0, 0x10019899c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x24a4>
100198980: 9000e188    	adrp	x8, 0x101dc8000 <_writev+0x101dc8000>
100198984: 910fc108    	add	x8, x8, #0x3f0
100198988: d1008108    	sub	x8, x8, #0x20
10019898c: b241011c    	orr	x28, x8, #0x8000000000000000
100198990: d2800314    	mov	x20, #0x18              ; =24
100198994: f2e20014    	movk	x20, #0x1000, lsl #48
100198998: 14000050    	b	0x100198ad8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x25e0>
10019899c: 390103f6    	strb	w22, [sp, #0x40]
1001989a0: 52800128    	mov	w8, #0x9                ; =9
1001989a4: 381503a8    	sturb	w8, [x29, #-0xb0]
1001989a8: d0010142    	adrp	x2, 0x1021c2000 <_$s4Otty16SleepHelperNamesON+0x1f38>
1001989ac: 91032042    	add	x2, x2, #0xc8
1001989b0: 910103e0    	add	x0, sp, #0x40
1001989b4: d102c3a1    	sub	x1, x29, #0xb0
1001989b8: aa0203f4    	mov	x20, x2
1001989bc: aa1703e3    	mov	x3, x23
1001989c0: 9464b5f7    	bl	0x101ac619c <_writev+0x101ac619c>
1001989c4: 360002e0    	tbz	w0, #0x0, 0x100198a20 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2528>
1001989c8: 3dc033e0    	ldr	q0, [sp, #0xc0]
1001989cc: 3c9503a0    	stur	q0, [x29, #-0xb0]
1001989d0: f85583bc    	ldur	x28, [x29, #-0xa8]
1001989d4: b400027c    	cbz	x28, 0x100198a20 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2528>
1001989d8: f85503b4    	ldur	x20, [x29, #-0xb0]
1001989dc: 9240be88    	and	x8, x20, #0xffffffffffff
1001989e0: d378ef89    	ubfx	x9, x28, #56, #4
1001989e4: f243039f    	tst	x28, #0x2000000000000000
1001989e8: 9a890108    	csel	x8, x8, x9, eq
1001989ec: b40001a8    	cbz	x8, 0x100198a20 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2528>
1001989f0: f0010db6    	adrp	x22, 0x10234f000 <_writev+0x10234f000>
1001989f4: 912142d6    	add	x22, x22, #0x850
1001989f8: b000ca57    	adrp	x23, 0x101ae1000 <_writev+0x101ae1000>
1001989fc: 913402f7    	add	x23, x23, #0xd00
100198a00: d102c3a0    	sub	x0, x29, #0xb0
100198a04: 910103e1    	add	x1, sp, #0x40
100198a08: aa1603e2    	mov	x2, x22
100198a0c: aa1703e3    	mov	x3, x23
100198a10: 97fa53b9    	bl	0x10002d8f4 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xaad4>
100198a14: d102c3a0    	sub	x0, x29, #0xb0
100198a18: 910103e1    	add	x1, sp, #0x40
100198a1c: 14000021    	b	0x100198aa0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x25a8>
100198a20: 390103f6    	strb	w22, [sp, #0x40]
100198a24: 52800148    	mov	w8, #0xa                ; =10
100198a28: 3900c3e8    	strb	w8, [sp, #0x30]
100198a2c: d0010142    	adrp	x2, 0x1021c2000 <_$s4Otty16SleepHelperNamesON+0x1f38>
100198a30: 91032042    	add	x2, x2, #0xc8
100198a34: 910103e0    	add	x0, sp, #0x40
100198a38: 9100c3e1    	add	x1, sp, #0x30
100198a3c: aa0203f4    	mov	x20, x2
100198a40: aa1703e3    	mov	x3, x23
100198a44: 9464b5d6    	bl	0x101ac619c <_writev+0x101ac619c>
100198a48: 36000340    	tbz	w0, #0x0, 0x100198ab0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x25b8>
100198a4c: 3dc033e0    	ldr	q0, [sp, #0xc0]
100198a50: 3d8013e0    	str	q0, [sp, #0x40]
100198a54: f94027fc    	ldr	x28, [sp, #0x48]
100198a58: b40002dc    	cbz	x28, 0x100198ab0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x25b8>
100198a5c: f94023f4    	ldr	x20, [sp, #0x40]
100198a60: 9240be88    	and	x8, x20, #0xffffffffffff
100198a64: d378ef89    	ubfx	x9, x28, #56, #4
100198a68: f243039f    	tst	x28, #0x2000000000000000
100198a6c: 9a890108    	csel	x8, x8, x9, eq
100198a70: b4000208    	cbz	x8, 0x100198ab0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x25b8>
100198a74: f0010db6    	adrp	x22, 0x10234f000 <_writev+0x10234f000>
100198a78: 912142d6    	add	x22, x22, #0x850
100198a7c: b000ca57    	adrp	x23, 0x101ae1000 <_writev+0x101ae1000>
100198a80: 913402f7    	add	x23, x23, #0xd00
100198a84: 910103e0    	add	x0, sp, #0x40
100198a88: 9100c3e1    	add	x1, sp, #0x30
100198a8c: aa1603e2    	mov	x2, x22
100198a90: aa1703e3    	mov	x3, x23
100198a94: 97fa5398    	bl	0x10002d8f4 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xaad4>
100198a98: 910103e0    	add	x0, sp, #0x40
100198a9c: 9100c3e1    	add	x1, sp, #0x30
100198aa0: aa1603e2    	mov	x2, x22
100198aa4: aa1703e3    	mov	x3, x23
100198aa8: 97fa5393    	bl	0x10002d8f4 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xaad4>
100198aac: 1400000b    	b	0x100198ad8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x25e0>
100198ab0: aa1603e0    	mov	x0, x22
100198ab4: 940002eb    	bl	0x100199660 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3168>
100198ab8: aa0103f6    	mov	x22, x1
100198abc: 9464b61b    	bl	0x101ac6328 <_writev+0x101ac6328>
100198ac0: aa0003f4    	mov	x20, x0
100198ac4: aa0103fc    	mov	x28, x1
100198ac8: aa1603e0    	mov	x0, x22
100198acc: 9464c6d0    	bl	0x101aca60c <_writev+0x101aca60c>
100198ad0: aa1c03e0    	mov	x0, x28
100198ad4: 9464c6d4    	bl	0x101aca624 <_writev+0x101aca624>
100198ad8: aa1403e0    	mov	x0, x20
100198adc: aa1c03e1    	mov	x1, x28
100198ae0: 9464b5d6    	bl	0x101ac6238 <_writev+0x101ac6238>
100198ae4: aa0003f4    	mov	x20, x0
100198ae8: f9000ffc    	str	x28, [sp, #0x18]
100198aec: aa1c03e0    	mov	x0, x28
100198af0: 9464c6c7    	bl	0x101aca60c <_writev+0x101aca60c>
100198af4: d0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
100198af8: f9459900    	ldr	x0, [x8, #0xb30]
100198afc: 9464c48a    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100198b00: aa0003f7    	mov	x23, x0
100198b04: aa1403e2    	mov	x2, x20
100198b08: 9464d9ce    	bl	0x101acf240 <_writev+0x101acf240>
100198b0c: aa1d03fd    	mov	x29, x29
100198b10: 9464c491    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198b14: aa0003f6    	mov	x22, x0
100198b18: aa1403e0    	mov	x0, x20
100198b1c: 9464c485    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198b20: d0010988    	adrp	x8, 0x1022ca000 <_writev+0x1022ca000>
100198b24: f9431108    	ldr	x8, [x8, #0x620]
100198b28: fd400108    	ldr	d8, [x8]
100198b2c: aa1603e0    	mov	x0, x22
100198b30: 9464c483    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100198b34: aa0003f6    	mov	x22, x0
100198b38: 1e649000    	fmov	d0, #10.00000000
100198b3c: 4ea81d01    	mov.16b	v1, v8
100198b40: 97f9aef0    	bl	0x100004700 <_$s9TextStory09CompositeA14StoringMonitorV8monitorsACSayAA0adE0_pG_tcfC+0x7c0>
100198b44: aa0003f4    	mov	x20, x0
100198b48: aa1603e0    	mov	x0, x22
100198b4c: aa1403e2    	mov	x2, x20
100198b50: 9464e7d4    	bl	0x101ad2aa0 <_writev+0x101ad2aa0>
100198b54: aa1403e0    	mov	x0, x20
100198b58: 9464c476    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198b5c: d0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
100198b60: f944e500    	ldr	x0, [x8, #0x9c8]
100198b64: 9464c470    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100198b68: aa0003f4    	mov	x20, x0
100198b6c: 9464f34d    	bl	0x101ad58a0 <_writev+0x101ad58a0>
100198b70: aa1d03fd    	mov	x29, x29
100198b74: 9464c478    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198b78: aa0003fc    	mov	x28, x0
100198b7c: aa1603e0    	mov	x0, x22
100198b80: aa1c03e2    	mov	x2, x28
100198b84: 9464eeb7    	bl	0x101ad4660 <_writev+0x101ad4660>
100198b88: aa1c03e0    	mov	x0, x28
100198b8c: 9464c469    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198b90: aa1603e0    	mov	x0, x22
100198b94: 528000a2    	mov	w2, #0x5                ; =5
100198b98: 9464e9ea    	bl	0x101ad3340 <_writev+0x101ad3340>
100198b9c: aa1603e0    	mov	x0, x22
100198ba0: 9464c464    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198ba4: b40000d9    	cbz	x25, 0x100198bbc <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x26c4>
100198ba8: aa1a03e0    	mov	x0, x26
100198bac: 9464c698    	bl	0x101aca60c <_writev+0x101aca60c>
100198bb0: f94003fc    	ldr	x28, [sp]
100198bb4: aa1903fa    	mov	x26, x25
100198bb8: 14000003    	b	0x100198bc4 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x26cc>
100198bbc: f94013fc    	ldr	x28, [sp, #0x20]
100198bc0: b4002a9a    	cbz	x26, 0x100199110 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2c18>
100198bc4: aa1b03e0    	mov	x0, x27
100198bc8: 9464c691    	bl	0x101aca60c <_writev+0x101aca60c>
100198bcc: aa1a03fb    	mov	x27, x26
100198bd0: 910283e0    	add	x0, sp, #0xa0
100198bd4: 97ff0800    	bl	0x10015abd4 <_$s11_RopeModule0A0V7BuilderV12_prefixTreesSayACyxGGvg+0x5104>
100198bd8: aa1c03e0    	mov	x0, x28
100198bdc: aa1b03e1    	mov	x1, x27
100198be0: 9464b596    	bl	0x101ac6238 <_writev+0x101ac6238>
100198be4: aa0003f8    	mov	x24, x0
100198be8: aa1b03e0    	mov	x0, x27
100198bec: 9464c688    	bl	0x101aca60c <_writev+0x101aca60c>
100198bf0: aa1703e0    	mov	x0, x23
100198bf4: aa1803e2    	mov	x2, x24
100198bf8: 9464f5b2    	bl	0x101ad62c0 <_writev+0x101ad62c0>
100198bfc: aa1d03fd    	mov	x29, x29
100198c00: 9464c455    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198c04: aa0003f7    	mov	x23, x0
100198c08: aa1803e0    	mov	x0, x24
100198c0c: 9464c449    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198c10: d0010988    	adrp	x8, 0x1022ca000 <_writev+0x1022ca000>
100198c14: f9430d08    	ldr	x8, [x8, #0x618]
100198c18: fd400108    	ldr	d8, [x8]
100198c1c: aa1703e0    	mov	x0, x23
100198c20: 9464c447    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100198c24: 9464c446    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100198c28: aa0003f7    	mov	x23, x0
100198c2c: 1e64d000    	fmov	d0, #11.00000000
100198c30: 4ea81d01    	mov.16b	v1, v8
100198c34: 97f9aef1    	bl	0x1000047f8 <_$s9TextStory09CompositeA14StoringMonitorV8monitorsACSayAA0adE0_pG_tcfC+0x8b8>
100198c38: aa0003f8    	mov	x24, x0
100198c3c: aa1703e0    	mov	x0, x23
100198c40: aa1803e2    	mov	x2, x24
100198c44: 9464e797    	bl	0x101ad2aa0 <_writev+0x101ad2aa0>
100198c48: aa1703e0    	mov	x0, x23
100198c4c: 9464c439    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198c50: aa1803e0    	mov	x0, x24
100198c54: 9464c437    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198c58: aa1703e0    	mov	x0, x23
100198c5c: 52800102    	mov	w2, #0x8                ; =8
100198c60: 9464ea60    	bl	0x101ad35e0 <_writev+0x101ad35e0>
100198c64: aa1403e0    	mov	x0, x20
100198c68: 9464e19e    	bl	0x101ad12e0 <_writev+0x101ad12e0>
100198c6c: aa1d03fd    	mov	x29, x29
100198c70: 9464c439    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198c74: aa0003f4    	mov	x20, x0
100198c78: aa1703e0    	mov	x0, x23
100198c7c: aa1403e2    	mov	x2, x20
100198c80: 9464ee78    	bl	0x101ad4660 <_writev+0x101ad4660>
100198c84: aa1403e0    	mov	x0, x20
100198c88: 9464c42a    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198c8c: d2e80d68    	mov	x8, #0x406b000000000000 ; =4641803840935428096
100198c90: 9e670100    	fmov	d0, x8
100198c94: aa1703e0    	mov	x0, x23
100198c98: 9464ebc2    	bl	0x101ad3ba0 <_writev+0x101ad3ba0>
100198c9c: f0010d40    	adrp	x0, 0x102343000 <_writev+0x102343000>
100198ca0: 91088000    	add	x0, x0, #0x220
100198ca4: d000ca41    	adrp	x1, 0x101ae2000 <_writev+0x101ae2000>
100198ca8: 91320021    	add	x1, x1, #0xc80
100198cac: 97f9abe8    	bl	0x100003c4c <_$s9TextStory0A19MutationEventRouterCfD+0x578>
100198cb0: aa0003fb    	mov	x27, x0
100198cb4: 52800601    	mov	w1, #0x30               ; =48
100198cb8: 528000e2    	mov	w2, #0x7                ; =7
100198cbc: 9464c633    	bl	0x101aca588 <_writev+0x101aca588>
100198cc0: aa0003f4    	mov	x20, x0
100198cc4: d000ca48    	adrp	x8, 0x101ae2000 <_writev+0x101ae2000>
100198cc8: 3dc31900    	ldr	q0, [x8, #0xc60]
100198ccc: 3d800400    	str	q0, [x0, #0x10]
100198cd0: a9025c16    	stp	x22, x23, [x0, #0x20]
100198cd4: 90010d41    	adrp	x1, 0x102340000 <_OBJC_CLASS_$__TtC16CodeEditTextView20TextSelectionManager+0x480>
100198cd8: 91334021    	add	x1, x1, #0xcd0
100198cdc: d0010c62    	adrp	x2, 0x102326000 <_writev+0x102326000>
100198ce0: 91290042    	add	x2, x2, #0xa40
100198ce4: d2800000    	mov	x0, #0x0                ; =0
100198ce8: 97fa5325    	bl	0x10002d97c <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xab5c>
100198cec: aa0003f9    	mov	x25, x0
100198cf0: aa1603e0    	mov	x0, x22
100198cf4: 9464c412    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100198cf8: f90013e0    	str	x0, [sp, #0x20]
100198cfc: aa1403e0    	mov	x0, x20
100198d00: aa1903e1    	mov	x1, x25
100198d04: 9464b694    	bl	0x101ac6754 <_writev+0x101ac6754>
100198d08: aa0003f6    	mov	x22, x0
100198d0c: aa1403e0    	mov	x0, x20
100198d10: 9464c714    	bl	0x101aca960 <_writev+0x101aca960>
100198d14: d0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
100198d18: f945bd00    	ldr	x0, [x8, #0xb78]
100198d1c: 9464c402    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100198d20: aa1603e2    	mov	x2, x22
100198d24: 9464f0d7    	bl	0x101ad5080 <_writev+0x101ad5080>
100198d28: aa1d03fd    	mov	x29, x29
100198d2c: 9464c40a    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198d30: aa0003f4    	mov	x20, x0
100198d34: aa1603e0    	mov	x0, x22
100198d38: 9464c3fe    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198d3c: aa1403e0    	mov	x0, x20
100198d40: 52800022    	mov	w2, #0x1                ; =1
100198d44: 9464eb17    	bl	0x101ad39a0 <_writev+0x101ad39a0>
100198d48: aa1403e0    	mov	x0, x20
100198d4c: 528000a2    	mov	w2, #0x5                ; =5
100198d50: 9464e2b4    	bl	0x101ad1820 <_writev+0x101ad1820>
100198d54: 1e641000    	fmov	d0, #8.00000000
100198d58: aa1403e0    	mov	x0, x20
100198d5c: 9464ed59    	bl	0x101ad42c0 <_writev+0x101ad42c0>
100198d60: 1e649000    	fmov	d0, #10.00000000
100198d64: 1e651001    	fmov	d1, #12.00000000
100198d68: 1e649002    	fmov	d2, #10.00000000
100198d6c: 1e651003    	fmov	d3, #12.00000000
100198d70: aa1403e0    	mov	x0, x20
100198d74: 9464e6d3    	bl	0x101ad28c0 <_writev+0x101ad28c0>
100198d78: aa1403e0    	mov	x0, x20
100198d7c: 9464c3f0    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100198d80: aa0003f9    	mov	x25, x0
100198d84: 52800002    	mov	w2, #0x0                ; =0
100198d88: 9464eede    	bl	0x101ad4900 <_writev+0x101ad4900>
100198d8c: f94017e0    	ldr	x0, [sp, #0x28]
100198d90: 9464ce84    	bl	0x101acc7a0 <_writev+0x101acc7a0>
100198d94: aa1d03fd    	mov	x29, x29
100198d98: 9464c3ef    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198d9c: b4002160    	cbz	x0, 0x1001991c8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2cd0>
100198da0: aa0003fa    	mov	x26, x0
100198da4: aa1903e2    	mov	x2, x25
100198da8: 9464c9ae    	bl	0x101acb460 <_writev+0x101acb460>
100198dac: d0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
100198db0: 912e0108    	add	x8, x8, #0xb80
100198db4: f9400100    	ldr	x0, [x8]
100198db8: 9464c3db    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100198dbc: aa0003f4    	mov	x20, x0
100198dc0: aa1b03e0    	mov	x0, x27
100198dc4: 52800801    	mov	w1, #0x40               ; =64
100198dc8: 528000e2    	mov	w2, #0x7                ; =7
100198dcc: 9464c5ef    	bl	0x101aca588 <_writev+0x101aca588>
100198dd0: aa0003fb    	mov	x27, x0
100198dd4: d000ca48    	adrp	x8, 0x101ae2000 <_writev+0x101ae2000>
100198dd8: 3dc31100    	ldr	q0, [x8, #0xc40]
100198ddc: 3d800400    	str	q0, [x0, #0x10]
100198de0: aa1903e0    	mov	x0, x25
100198de4: 9464f38f    	bl	0x101ad5c20 <_writev+0x101ad5c20>
100198de8: aa1d03fd    	mov	x29, x29
100198dec: 9464c3da    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198df0: aa0003fc    	mov	x28, x0
100198df4: aa1a03e0    	mov	x0, x26
100198df8: 9464f38a    	bl	0x101ad5c20 <_writev+0x101ad5c20>
100198dfc: aa1d03fd    	mov	x29, x29
100198e00: 9464c3d5    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198e04: aa0003f8    	mov	x24, x0
100198e08: aa1c03e0    	mov	x0, x28
100198e0c: aa1803e2    	mov	x2, x24
100198e10: 9464cdfc    	bl	0x101acc600 <_writev+0x101acc600>
100198e14: aa1d03fd    	mov	x29, x29
100198e18: 9464c3cf    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198e1c: aa0003f6    	mov	x22, x0
100198e20: aa1c03e0    	mov	x0, x28
100198e24: 9464c3c3    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198e28: aa1803e0    	mov	x0, x24
100198e2c: 9464c3c1    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198e30: f9001376    	str	x22, [x27, #0x20]
100198e34: aa1903e0    	mov	x0, x25
100198e38: 9464d952    	bl	0x101acf380 <_writev+0x101acf380>
100198e3c: aa1d03fd    	mov	x29, x29
100198e40: 9464c3c5    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198e44: aa0003f6    	mov	x22, x0
100198e48: aa1a03e0    	mov	x0, x26
100198e4c: 9464d94d    	bl	0x101acf380 <_writev+0x101acf380>
100198e50: aa1d03fd    	mov	x29, x29
100198e54: 9464c3c0    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198e58: aa0003f8    	mov	x24, x0
100198e5c: aa1603e0    	mov	x0, x22
100198e60: aa1803e2    	mov	x2, x24
100198e64: 9464cde7    	bl	0x101acc600 <_writev+0x101acc600>
100198e68: aa1d03fd    	mov	x29, x29
100198e6c: 9464c3ba    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198e70: aa0003fc    	mov	x28, x0
100198e74: aa1603e0    	mov	x0, x22
100198e78: 9464c3ae    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198e7c: aa1803e0    	mov	x0, x24
100198e80: 9464c3ac    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198e84: f900177c    	str	x28, [x27, #0x28]
100198e88: aa1903e0    	mov	x0, x25
100198e8c: 9464f375    	bl	0x101ad5c60 <_writev+0x101ad5c60>
100198e90: aa1d03fd    	mov	x29, x29
100198e94: 9464c3b0    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198e98: aa0003f6    	mov	x22, x0
100198e9c: aa1a03e0    	mov	x0, x26
100198ea0: 9464f370    	bl	0x101ad5c60 <_writev+0x101ad5c60>
100198ea4: aa1d03fd    	mov	x29, x29
100198ea8: 9464c3ab    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198eac: aa0003f8    	mov	x24, x0
100198eb0: aa1603e0    	mov	x0, x22
100198eb4: aa1803e2    	mov	x2, x24
100198eb8: 9464cdd2    	bl	0x101acc600 <_writev+0x101acc600>
100198ebc: aa1d03fd    	mov	x29, x29
100198ec0: 9464c3a5    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198ec4: aa0003fc    	mov	x28, x0
100198ec8: aa1603e0    	mov	x0, x22
100198ecc: 9464c399    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198ed0: aa1803e0    	mov	x0, x24
100198ed4: 9464c397    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198ed8: f9001b7c    	str	x28, [x27, #0x30]
100198edc: aa1903e0    	mov	x0, x25
100198ee0: 9464cba8    	bl	0x101acbd80 <_writev+0x101acbd80>
100198ee4: aa1d03fd    	mov	x29, x29
100198ee8: 9464c39b    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198eec: aa0003f6    	mov	x22, x0
100198ef0: aa1a03e0    	mov	x0, x26
100198ef4: 9464cba3    	bl	0x101acbd80 <_writev+0x101acbd80>
100198ef8: aa1d03fd    	mov	x29, x29
100198efc: 9464c396    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198f00: aa0003f8    	mov	x24, x0
100198f04: aa1603e0    	mov	x0, x22
100198f08: aa1803e2    	mov	x2, x24
100198f0c: 9464cdbd    	bl	0x101acc600 <_writev+0x101acc600>
100198f10: aa1d03fd    	mov	x29, x29
100198f14: 9464c390    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198f18: aa0003fc    	mov	x28, x0
100198f1c: aa1603e0    	mov	x0, x22
100198f20: 9464c384    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198f24: aa1803e0    	mov	x0, x24
100198f28: 9464c382    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198f2c: f9001f7c    	str	x28, [x27, #0x38]
100198f30: d0010d41    	adrp	x1, 0x102342000 <_writev+0x102342000>
100198f34: 91260021    	add	x1, x1, #0x980
100198f38: d2800000    	mov	x0, #0x0                ; =0
100198f3c: d0010c62    	adrp	x2, 0x102326000 <_writev+0x102326000>
100198f40: 912e0042    	add	x2, x2, #0xb80
100198f44: 97fa528e    	bl	0x10002d97c <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xab5c>
100198f48: aa0003e1    	mov	x1, x0
100198f4c: aa1b03e0    	mov	x0, x27
100198f50: 9464b601    	bl	0x101ac6754 <_writev+0x101ac6754>
100198f54: aa0003f6    	mov	x22, x0
100198f58: aa1b03e0    	mov	x0, x27
100198f5c: 9464c681    	bl	0x101aca960 <_writev+0x101aca960>
100198f60: aa1403e0    	mov	x0, x20
100198f64: aa1603e2    	mov	x2, x22
100198f68: 9464c85e    	bl	0x101acb0e0 <_writev+0x101acb0e0>
100198f6c: aa1603e0    	mov	x0, x22
100198f70: 9464c370    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198f74: aa1903e0    	mov	x0, x25
100198f78: 9464d2fa    	bl	0x101acdb60 <_writev+0x101acdb60>
100198f7c: 4ea11c28    	mov.16b	v8, v1
100198f80: aa1903e0    	mov	x0, x25
100198f84: 9464c36b    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100198f88: d2e80928    	mov	x8, #0x4049000000000000 ; =4632233691727265792
100198f8c: 9e670100    	fmov	d0, x8
100198f90: 1e606908    	fmaxnm	d8, d8, d0
100198f94: aa1303e0    	mov	x0, x19
100198f98: 9464d34a    	bl	0x101acdcc0 <_writev+0x101acdcc0>
100198f9c: 4ea01c0a    	mov.16b	v10, v0
100198fa0: 4ea11c2b    	mov.16b	v11, v1
100198fa4: 4ea21c4c    	mov.16b	v12, v2
100198fa8: 4ea31c6d    	mov.16b	v13, v3
100198fac: 9464bf71    	bl	0x101ac8d70 <_writev+0x101ac8d70>
100198fb0: 1e621001    	fmov	d1, #4.00000000
100198fb4: 1e61280e    	fadd	d14, d0, d1
100198fb8: 4eaa1d40    	mov.16b	v0, v10
100198fbc: 4eab1d61    	mov.16b	v1, v11
100198fc0: 4eac1d82    	mov.16b	v2, v12
100198fc4: 4ead1da3    	mov.16b	v3, v13
100198fc8: 9464bf6d    	bl	0x101ac8d7c <_writev+0x101ac8d7c>
100198fcc: 1e683809    	fsub	d9, d0, d8
100198fd0: aa1503e0    	mov	x0, x21
100198fd4: 9464e05b    	bl	0x101ad1140 <_writev+0x101ad1140>
100198fd8: aa1d03fd    	mov	x29, x29
100198fdc: 9464c35e    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100198fe0: b4000300    	cbz	x0, 0x100199040 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2b48>
100198fe4: aa0003f4    	mov	x20, x0
100198fe8: d2e80dc8    	mov	x8, #0x406e000000000000 ; =4642648265865560064
100198fec: 9e670100    	fmov	d0, x8
100198ff0: 1e6029cf    	fadd	d15, d14, d0
100198ff4: 9464f423    	bl	0x101ad6080 <_writev+0x101ad6080>
100198ff8: 9464bf5e    	bl	0x101ac8d70 <_writev+0x101ac8d70>
100198ffc: 1e6f2000    	fcmp	d0, d15
100199000: a9416ffc    	ldp	x28, x27, [sp, #0x10]
100199004: 54000225    	b.pl	0x100199048 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2b50>
100199008: 4eaa1d40    	mov.16b	v0, v10
10019900c: 4eab1d61    	mov.16b	v1, v11
100199010: 4eac1d82    	mov.16b	v2, v12
100199014: 4ead1da3    	mov.16b	v3, v13
100199018: 9464bf62    	bl	0x101ac8da0 <_writev+0x101ac8da0>
10019901c: 4ea01c0a    	mov.16b	v10, v0
100199020: aa1403e0    	mov	x0, x20
100199024: 9464c343    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100199028: d2f80dc8    	mov	x8, #-0x3f92000000000000 ; =-4580723770989215744
10019902c: 9e670100    	fmov	d0, x8
100199030: 1e602940    	fadd	d0, d10, d0
100199034: 1e721001    	fmov	d1, #-4.00000000
100199038: 1e61280e    	fadd	d14, d0, d1
10019903c: 14000005    	b	0x100199050 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2b58>
100199040: a9416ffc    	ldp	x28, x27, [sp, #0x10]
100199044: 14000003    	b	0x100199050 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2b58>
100199048: aa1403e0    	mov	x0, x20
10019904c: 9464c339    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100199050: d2e80dc8    	mov	x8, #0x406e000000000000 ; =4642648265865560064
100199054: 9e670102    	fmov	d2, x8
100199058: f94017f8    	ldr	x24, [sp, #0x28]
10019905c: aa1803e0    	mov	x0, x24
100199060: 4eae1dc0    	mov.16b	v0, v14
100199064: 4ea91d21    	mov.16b	v1, v9
100199068: 4ea81d03    	mov.16b	v3, v8
10019906c: 52800022    	mov	w2, #0x1                ; =1
100199070: 9464e6cc    	bl	0x101ad2ba0 <_writev+0x101ad2ba0>
100199074: f000e168    	adrp	x8, 0x101dc8000 <_writev+0x101dc8000>
100199078: 910f0108    	add	x8, x8, #0x3c0
10019907c: d1008116    	sub	x22, x8, #0x20
100199080: aa1503e0    	mov	x0, x21
100199084: 9464c32e    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100199088: aa0003f4    	mov	x20, x0
10019908c: b24102c1    	orr	x1, x22, #0x8000000000000000
100199090: d2800560    	mov	x0, #0x2b               ; =43
100199094: f2fa0000    	movk	x0, #0xd000, lsl #48
100199098: aa1503e2    	mov	x2, x21
10019909c: 97fb31cf    	bl	0x1000657d8 <_$s18OrderedCollections0A10DictionaryV8ElementsV11SubSequenceV8IteratorV4_endSivg+0x339c>
1001990a0: aa1403e0    	mov	x0, x20
1001990a4: 9464c323    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001990a8: aa1403e0    	mov	x0, x20
1001990ac: aa1803e2    	mov	x2, x24
1001990b0: 52800023    	mov	w3, #0x1                ; =1
1001990b4: 9464c85b    	bl	0x101acb220 <_writev+0x101acb220>
1001990b8: aa1803e0    	mov	x0, x24
1001990bc: d2800002    	mov	x2, #0x0                ; =0
1001990c0: 9464db60    	bl	0x101acfe40 <_writev+0x101acfe40>
1001990c4: aa1403e0    	mov	x0, x20
1001990c8: 9464d996    	bl	0x101acf720 <_writev+0x101acf720>
1001990cc: aa1903e0    	mov	x0, x25
1001990d0: 9464c318    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001990d4: aa1a03e0    	mov	x0, x26
1001990d8: 9464c316    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001990dc: f94013e0    	ldr	x0, [sp, #0x20]
1001990e0: 9464c314    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001990e4: aa1403e0    	mov	x0, x20
1001990e8: 9464c312    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001990ec: aa1303e0    	mov	x0, x19
1001990f0: 9464c310    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001990f4: aa1703e0    	mov	x0, x23
1001990f8: 9464c30e    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001990fc: aa1b03e0    	mov	x0, x27
100199100: 9464c543    	bl	0x101aca60c <_writev+0x101aca60c>
100199104: f9400f80    	ldr	x0, [x28, #0x18]
100199108: f9000f98    	str	x24, [x28, #0x18]
10019910c: 17fffd9e    	b	0x100198784 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x228c>
100199110: f94007fc    	ldr	x28, [sp, #0x8]
100199114: b5ffd5fb    	cbnz	x27, 0x100198bd0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x26d8>
100199118: f94067f9    	ldr	x25, [sp, #0xc8]
10019911c: b40000b9    	cbz	x25, 0x100199130 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2c38>
100199120: f94063fa    	ldr	x26, [sp, #0xc0]
100199124: aa1903e0    	mov	x0, x25
100199128: 9464c53f    	bl	0x101aca624 <_writev+0x101aca624>
10019912c: 14000003    	b	0x100199138 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2c40>
100199130: d280001a    	mov	x26, #0x0               ; =0
100199134: d2fc0019    	mov	x25, #-0x2000000000000000 ; =-2305843009213693952
100199138: 910283e0    	add	x0, sp, #0xa0
10019913c: 97ff06a6    	bl	0x10015abd4 <_$s11_RopeModule0A0V7BuilderV12_prefixTreesSayACyxGGvg+0x5104>
100199140: aa1a03e0    	mov	x0, x26
100199144: aa1903e1    	mov	x1, x25
100199148: 9464b43c    	bl	0x101ac6238 <_writev+0x101ac6238>
10019914c: aa0003fa    	mov	x26, x0
100199150: aa1903e0    	mov	x0, x25
100199154: 9464c52e    	bl	0x101aca60c <_writev+0x101aca60c>
100199158: aa1703e0    	mov	x0, x23
10019915c: aa1a03e2    	mov	x2, x26
100199160: 9464f458    	bl	0x101ad62c0 <_writev+0x101ad62c0>
100199164: aa1d03fd    	mov	x29, x29
100199168: 9464c2fb    	bl	0x101ac9d54 <_writev+0x101ac9d54>
10019916c: aa0003f7    	mov	x23, x0
100199170: aa1a03e0    	mov	x0, x26
100199174: 9464c2ef    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100199178: aa1703e0    	mov	x0, x23
10019917c: 9464c2f0    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100199180: 9464c2ef    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
100199184: aa0003f7    	mov	x23, x0
100199188: 97fa52df    	bl	0x10002dd04 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xaee4>
10019918c: 4ea01c01    	mov.16b	v1, v0
100199190: 1e64f000    	fmov	d0, #11.50000000
100199194: 97f9ad5b    	bl	0x100004700 <_$s9TextStory09CompositeA14StoringMonitorV8monitorsACSayAA0adE0_pG_tcfC+0x7c0>
100199198: aa0003f9    	mov	x25, x0
10019919c: aa1703e0    	mov	x0, x23
1001991a0: aa1903e2    	mov	x2, x25
1001991a4: 9464e63f    	bl	0x101ad2aa0 <_writev+0x101ad2aa0>
1001991a8: aa1703e0    	mov	x0, x23
1001991ac: 9464c2e1    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001991b0: aa1903e0    	mov	x0, x25
1001991b4: 9464c2df    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001991b8: aa1703e0    	mov	x0, x23
1001991bc: 528000c2    	mov	w2, #0x6                ; =6
1001991c0: 17fffea8    	b	0x100198c60 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2768>
1001991c4: d4200020    	brk	#0x1
1001991c8: aa1903e0    	mov	x0, x25
1001991cc: 9464c2d9    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001991d0: d4200020    	brk	#0x1
1001991d4: d102c3ff    	sub	sp, sp, #0xb0
1001991d8: a90857f6    	stp	x22, x21, [sp, #0x80]
1001991dc: a9094ff4    	stp	x20, x19, [sp, #0x90]
1001991e0: a90a7bfd    	stp	x29, x30, [sp, #0xa0]
1001991e4: 910283fd    	add	x29, sp, #0xa0
1001991e8: 91016280    	add	x0, x20, #0x58
1001991ec: 910123e1    	add	x1, sp, #0x48
1001991f0: d2800002    	mov	x2, #0x0                ; =0
1001991f4: d2800003    	mov	x3, #0x0                ; =0
1001991f8: 9464c502    	bl	0x101aca600 <_writev+0x101aca600>
1001991fc: f0010d22    	adrp	x2, 0x102340000 <_OBJC_CLASS_$__TtC16CodeEditTextView20TextSelectionManager+0x480>
100199200: 9130c042    	add	x2, x2, #0xc30
100199204: 9000ca43    	adrp	x3, 0x101ae1000 <_writev+0x101ae1000>
100199208: 91040063    	add	x3, x3, #0x100
10019920c: 91016280    	add	x0, x20, #0x58
100199210: 910083e1    	add	x1, sp, #0x20
100199214: 97fa51b8    	bl	0x10002d8f4 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xaad4>
100199218: f9401fe8    	ldr	x8, [sp, #0x38]
10019921c: b4000468    	cbz	x8, 0x1001992a8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2db0>
100199220: 910083e0    	add	x0, sp, #0x20
100199224: d10103a1    	sub	x1, x29, #0x40
100199228: 97fa479e    	bl	0x10002b0a0 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x8280>
10019922c: b0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
100199230: f9458100    	ldr	x0, [x8, #0xb00]
100199234: 9464c2bc    	bl	0x101ac9d24 <_writev+0x101ac9d24>
100199238: aa0003f3    	mov	x19, x0
10019923c: f85d83b5    	ldur	x21, [x29, #-0x28]
100199240: d10103a0    	sub	x0, x29, #0x40
100199244: aa1503e1    	mov	x1, x21
100199248: 97fa519a    	bl	0x10002d8b0 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xaa90>
10019924c: aa1503e1    	mov	x1, x21
100199250: 9464ba8d    	bl	0x101ac7c84 <_writev+0x101ac7c84>
100199254: aa0003f5    	mov	x21, x0
100199258: aa1303e0    	mov	x0, x19
10019925c: aa1503e2    	mov	x2, x21
100199260: 9464de38    	bl	0x101ad0b40 <_writev+0x101ad0b40>
100199264: aa1503e0    	mov	x0, x21
100199268: 9464c600    	bl	0x101acaa68 <_writev+0x101acaa68>
10019926c: d10103a0    	sub	x0, x29, #0x40
100199270: 97fa5199    	bl	0x10002d8d4 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xaab4>
100199274: 6f00e400    	movi.2d	v0, #0000000000000000
100199278: ad0103e0    	stp	q0, q0, [sp, #0x20]
10019927c: 91016280    	add	x0, x20, #0x58
100199280: 910023e1    	add	x1, sp, #0x8
100199284: 52800422    	mov	w2, #0x21               ; =33
100199288: d2800003    	mov	x3, #0x0                ; =0
10019928c: 9464c4dd    	bl	0x101aca600 <_writev+0x101aca600>
100199290: 910083e0    	add	x0, sp, #0x20
100199294: 91016281    	add	x1, x20, #0x58
100199298: 97fa45b5    	bl	0x10002a96c <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0x7b4c>
10019929c: 910023e0    	add	x0, sp, #0x8
1001992a0: 9464c526    	bl	0x101aca738 <_writev+0x101aca738>
1001992a4: 14000007    	b	0x1001992c0 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2dc8>
1001992a8: f0010d21    	adrp	x1, 0x102340000 <_OBJC_CLASS_$__TtC16CodeEditTextView20TextSelectionManager+0x480>
1001992ac: 9130c021    	add	x1, x1, #0xc30
1001992b0: 9000ca42    	adrp	x2, 0x101ae1000 <_writev+0x101ae1000>
1001992b4: 91040042    	add	x2, x2, #0x100
1001992b8: 910083e0    	add	x0, sp, #0x20
1001992bc: 97fa516d    	bl	0x10002d870 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xaa50>
1001992c0: a94a7bfd    	ldp	x29, x30, [sp, #0xa0]
1001992c4: a9494ff4    	ldp	x20, x19, [sp, #0x90]
1001992c8: a94857f6    	ldp	x22, x21, [sp, #0x80]
1001992cc: 9102c3ff    	add	sp, sp, #0xb0
1001992d0: d65f03c0    	ret
1001992d4: d102c3ff    	sub	sp, sp, #0xb0
1001992d8: 6d0533ed    	stp	d13, d12, [sp, #0x50]
1001992dc: 6d062beb    	stp	d11, d10, [sp, #0x60]
1001992e0: 6d0723e9    	stp	d9, d8, [sp, #0x70]
1001992e4: a90857f6    	stp	x22, x21, [sp, #0x80]
1001992e8: a9094ff4    	stp	x20, x19, [sp, #0x90]
1001992ec: a90a7bfd    	stp	x29, x30, [sp, #0xa0]
1001992f0: 910283fd    	add	x29, sp, #0xa0
1001992f4: f9401688    	ldr	x8, [x20, #0x28]
1001992f8: f9400915    	ldr	x21, [x8, #0x10]
1001992fc: b4000bd5    	cbz	x21, 0x100199474 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2f7c>
100199300: aa0003f3    	mov	x19, x0
100199304: 9100c280    	add	x0, x20, #0x30
100199308: 910023e1    	add	x1, sp, #0x8
10019930c: d2800002    	mov	x2, #0x0                ; =0
100199310: d2800003    	mov	x3, #0x0                ; =0
100199314: 9464c4bb    	bl	0x101aca600 <_writev+0x101aca600>
100199318: f9401a88    	ldr	x8, [x20, #0x30]
10019931c: b7f80108    	tbnz	x8, #0x3f, 0x10019933c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2e44>
100199320: ab130108    	adds	x8, x8, x19
100199324: 54000b86    	b.vs	0x100199494 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2f9c>
100199328: ab150108    	adds	x8, x8, x21
10019932c: 54000b66    	b.vs	0x100199498 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2fa0>
100199330: 9ad50d09    	sdiv	x9, x8, x21
100199334: 9b15a133    	msub	x19, x9, x21, x8
100199338: 14000004    	b	0x100199348 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2e50>
10019933c: d10006a8    	sub	x8, x21, #0x1
100199340: f100027f    	cmp	x19, #0x0
100199344: 9a88c3f3    	csel	x19, xzr, x8, gt
100199348: aa1303e0    	mov	x0, x19
10019934c: 97fffbfc    	bl	0x10019833c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x1e44>
100199350: aa1303e0    	mov	x0, x19
100199354: 97fffcb1    	bl	0x100198618 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2120>
100199358: f9401293    	ldr	x19, [x20, #0x20]
10019935c: b40008d3    	cbz	x19, 0x100199474 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2f7c>
100199360: 9100c280    	add	x0, x20, #0x30
100199364: 9100e3e1    	add	x1, sp, #0x38
100199368: d2800002    	mov	x2, #0x0                ; =0
10019936c: d2800003    	mov	x3, #0x0                ; =0
100199370: 9464c4a4    	bl	0x101aca600 <_writev+0x101aca600>
100199374: f9401a95    	ldr	x21, [x20, #0x30]
100199378: 9100e280    	add	x0, x20, #0x38
10019937c: 910083e1    	add	x1, sp, #0x20
100199380: d2800002    	mov	x2, #0x0                ; =0
100199384: d2800003    	mov	x3, #0x0                ; =0
100199388: 9464c49e    	bl	0x101aca600 <_writev+0x101aca600>
10019938c: f9401e88    	ldr	x8, [x20, #0x38]
100199390: d37efd09    	lsr	x9, x8, #62
100199394: b5000849    	cbnz	x9, 0x10019949c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2fa4>
100199398: 927de108    	and	x8, x8, #0xffffffffffffff8
10019939c: f9400900    	ldr	x0, [x8, #0x10]
1001993a0: eb0002bf    	cmp	x21, x0
1001993a4: 5400068a    	b.ge	0x100199474 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2f7c>
1001993a8: fc430280    	ldur	d0, [x20, #0x30]
1001993ac: 5e61d800    	scvtf	d0, d0
1001993b0: 1e673001    	fmov	d1, #25.00000000
1001993b4: 1e610800    	fmul	d0, d0, d1
1001993b8: 1e621001    	fmov	d1, #4.00000000
1001993bc: 1e612808    	fadd	d8, d0, d1
1001993c0: aa1303e0    	mov	x0, x19
1001993c4: 9464c25e    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
1001993c8: aa0003f3    	mov	x19, x0
1001993cc: 9464cfa5    	bl	0x101acd260 <_writev+0x101acd260>
1001993d0: 4ea01c09    	mov.16b	v9, v0
1001993d4: 4ea11c2a    	mov.16b	v10, v1
1001993d8: 4ea21c4b    	mov.16b	v11, v2
1001993dc: 4ea31c6c    	mov.16b	v12, v3
1001993e0: 9464be73    	bl	0x101ac8dac <_writev+0x101ac8dac>
1001993e4: 1e602100    	fcmp	d8, d0
1001993e8: 540000e5    	b.pl	0x100199404 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2f0c>
1001993ec: aa1303e0    	mov	x0, x19
1001993f0: 9464ccec    	bl	0x101acc7a0 <_writev+0x101acc7a0>
1001993f4: aa1d03fd    	mov	x29, x29
1001993f8: 9464c257    	bl	0x101ac9d54 <_writev+0x101ac9d54>
1001993fc: aa0003f4    	mov	x20, x0
100199400: 14000015    	b	0x100199454 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2f5c>
100199404: 1e671000    	fmov	d0, #24.00000000
100199408: 1e602908    	fadd	d8, d8, d0
10019940c: 4ea91d20    	mov.16b	v0, v9
100199410: 4eaa1d41    	mov.16b	v1, v10
100199414: 4eab1d62    	mov.16b	v2, v11
100199418: 4eac1d83    	mov.16b	v3, v12
10019941c: 9464be58    	bl	0x101ac8d7c <_writev+0x101ac8d7c>
100199420: 1e682000    	fcmp	d0, d8
100199424: 54000245    	b.pl	0x10019946c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2f74>
100199428: aa1303e0    	mov	x0, x19
10019942c: 9464ccdd    	bl	0x101acc7a0 <_writev+0x101acc7a0>
100199430: aa1d03fd    	mov	x29, x29
100199434: 9464c248    	bl	0x101ac9d54 <_writev+0x101ac9d54>
100199438: aa0003f4    	mov	x20, x0
10019943c: 4ea91d20    	mov.16b	v0, v9
100199440: 4eaa1d41    	mov.16b	v1, v10
100199444: 4eab1d62    	mov.16b	v2, v11
100199448: 4eac1d83    	mov.16b	v3, v12
10019944c: 9464be46    	bl	0x101ac8d64 <_writev+0x101ac8d64>
100199450: 1e603908    	fsub	d8, d8, d0
100199454: 6f00e400    	movi.2d	v0, #0000000000000000
100199458: aa1403e0    	mov	x0, x20
10019945c: 4ea81d01    	mov.16b	v1, v8
100199460: 9464df70    	bl	0x101ad1220 <_writev+0x101ad1220>
100199464: aa1403e0    	mov	x0, x20
100199468: 9464c232    	bl	0x101ac9d30 <_writev+0x101ac9d30>
10019946c: aa1303e0    	mov	x0, x19
100199470: 9464c230    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100199474: a94a7bfd    	ldp	x29, x30, [sp, #0xa0]
100199478: a9494ff4    	ldp	x20, x19, [sp, #0x90]
10019947c: a94857f6    	ldp	x22, x21, [sp, #0x80]
100199480: 6d4723e9    	ldp	d9, d8, [sp, #0x70]
100199484: 6d462beb    	ldp	d11, d10, [sp, #0x60]
100199488: 6d4533ed    	ldp	d13, d12, [sp, #0x50]
10019948c: 9102c3ff    	add	sp, sp, #0xb0
100199490: d65f03c0    	ret
100199494: d4200020    	brk	#0x1
100199498: d4200020    	brk	#0x1
10019949c: 927de109    	and	x9, x8, #0xffffffffffffff8
1001994a0: b100051f    	cmn	x8, #0x1
1001994a4: 9a88c120    	csel	x0, x9, x8, gt
1001994a8: 9464b916    	bl	0x101ac7900 <_writev+0x101ac7900>
1001994ac: eb0002bf    	cmp	x21, x0
1001994b0: 54fff7cb    	b.lt	0x1001993a8 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2eb0>
1001994b4: 17fffff0    	b	0x100199474 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x2f7c>
1001994b8: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
1001994bc: a9014ff4    	stp	x20, x19, [sp, #0x10]
1001994c0: a9027bfd    	stp	x29, x30, [sp, #0x20]
1001994c4: 910083fd    	add	x29, sp, #0x20
1001994c8: f9400e93    	ldr	x19, [x20, #0x18]
1001994cc: b4000313    	cbz	x19, 0x10019952c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3034>
1001994d0: 91014280    	add	x0, x20, #0x50
1001994d4: 9464c580    	bl	0x101acaad4 <_writev+0x101acaad4>
1001994d8: aa0003f5    	mov	x21, x0
1001994dc: aa1303e0    	mov	x0, x19
1001994e0: 9464c217    	bl	0x101ac9d3c <_writev+0x101ac9d3c>
1001994e4: aa0003f3    	mov	x19, x0
1001994e8: b40000d5    	cbz	x21, 0x100199500 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3008>
1001994ec: aa1503e0    	mov	x0, x21
1001994f0: aa1303e2    	mov	x2, x19
1001994f4: 9464dd43    	bl	0x101ad0a00 <_writev+0x101ad0a00>
1001994f8: aa1503e0    	mov	x0, x21
1001994fc: 9464c20d    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100199500: aa1303e0    	mov	x0, x19
100199504: d2800002    	mov	x2, #0x0                ; =0
100199508: 9464da6e    	bl	0x101acfec0 <_writev+0x101acfec0>
10019950c: aa1303e0    	mov	x0, x19
100199510: 9464c208    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100199514: f9400e80    	ldr	x0, [x20, #0x18]
100199518: f9000e9f    	str	xzr, [x20, #0x18]
10019951c: a9427bfd    	ldp	x29, x30, [sp, #0x20]
100199520: a9414ff4    	ldp	x20, x19, [sp, #0x10]
100199524: a8c357f6    	ldp	x22, x21, [sp], #0x30
100199528: 1464c202    	b	0x101ac9d30 <_writev+0x101ac9d30>
10019952c: a9427bfd    	ldp	x29, x30, [sp, #0x20]
100199530: a9414ff4    	ldp	x20, x19, [sp, #0x10]
100199534: a8c357f6    	ldp	x22, x21, [sp], #0x30
100199538: d65f03c0    	ret
10019953c: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
100199540: a9014ff4    	stp	x20, x19, [sp, #0x10]
100199544: a9027bfd    	stp	x29, x30, [sp, #0x20]
100199548: 910083fd    	add	x29, sp, #0x20
10019954c: d10043ff    	sub	sp, sp, #0x10
100199550: aa0003f5    	mov	x21, x0
100199554: f0010d60    	adrp	x0, 0x102348000 <_writev+0x102348000>
100199558: 91084000    	add	x0, x0, #0x210
10019955c: f000ca61    	adrp	x1, 0x101ae8000 <_$s4Otty16SleepHelperNamesO9plistNameSSvpZMV+0x20a0>
100199560: 91026021    	add	x1, x1, #0x98
100199564: 97f9a9ba    	bl	0x100003c4c <_$s9TextStory0A19MutationEventRouterCfD+0x578>
100199568: f85f8008    	ldur	x8, [x0, #-0x8]
10019956c: f9402109    	ldr	x9, [x8, #0x40]
100199570: 91003d28    	add	x8, x9, #0xf
100199574: 927ced08    	and	x8, x8, #0xfffffffffffffff0
100199578: d0010990    	adrp	x16, 0x1022cb000 <_writev+0x1022cb000>
10019957c: f941ce10    	ldr	x16, [x16, #0x398]
100199580: d63f0200    	blr	x16
100199584: 910003e9    	mov	x9, sp
100199588: cb080133    	sub	x19, x9, x8
10019958c: 9100027f    	mov	sp, x19
100199590: 3940c2a8    	ldrb	w8, [x21, #0x30]
100199594: 381df3a8    	sturb	w8, [x29, #-0x21]
100199598: 528000e8    	mov	w8, #0x7                ; =7
10019959c: 381de3a8    	sturb	w8, [x29, #-0x22]
1001995a0: 97ff616e    	bl	0x100171b58 <_$s8Markdown12ParseOptionsV19parseMinimalDoxygenACvgZ+0x14f04>
1001995a4: aa0003e3    	mov	x3, x0
1001995a8: b0010142    	adrp	x2, 0x1021c2000 <_$s4Otty16SleepHelperNamesON+0x1f38>
1001995ac: 91032042    	add	x2, x2, #0xc8
1001995b0: d10087a0    	sub	x0, x29, #0x21
1001995b4: d1008ba1    	sub	x1, x29, #0x22
1001995b8: aa0203f4    	mov	x20, x2
1001995bc: 9464b2f8    	bl	0x101ac619c <_writev+0x101ac619c>
1001995c0: 360002c0    	tbz	w0, #0x0, 0x100199618 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3120>
1001995c4: f94022a1    	ldr	x1, [x21, #0x40]
1001995c8: b40002e1    	cbz	x1, 0x100199624 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x312c>
1001995cc: f9401ea0    	ldr	x0, [x21, #0x38]
1001995d0: aa1303e8    	mov	x8, x19
1001995d4: 9405c953    	bl	0x10030bb20 <_$s19HashTreeCollections01_aB10StatisticsV13capacityBytesSivg+0x1df0>
1001995d8: d2800000    	mov	x0, #0x0                ; =0
1001995dc: 9405c237    	bl	0x100309eb8 <_$s19HashTreeCollections01_aB10StatisticsV13capacityBytesSivg+0x188>
1001995e0: aa0003e2    	mov	x2, x0
1001995e4: f85f8008    	ldur	x8, [x0, #-0x8]
1001995e8: f9401908    	ldr	x8, [x8, #0x30]
1001995ec: aa1303e0    	mov	x0, x19
1001995f0: 52800021    	mov	w1, #0x1                ; =1
1001995f4: d63f0100    	blr	x8
1001995f8: 7100041f    	cmp	w0, #0x1
1001995fc: 54000181    	b.ne	0x10019962c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3134>
100199600: f0010d61    	adrp	x1, 0x102348000 <_writev+0x102348000>
100199604: 91084021    	add	x1, x1, #0x210
100199608: f000ca62    	adrp	x2, 0x101ae8000 <_$s4Otty16SleepHelperNamesO9plistNameSSvpZMV+0x20a0>
10019960c: 91026042    	add	x2, x2, #0x98
100199610: aa1303e0    	mov	x0, x19
100199614: 97fa5097    	bl	0x10002d870 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xaa50>
100199618: d2800000    	mov	x0, #0x0                ; =0
10019961c: d2800001    	mov	x1, #0x0                ; =0
100199620: 1400000b    	b	0x10019964c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3154>
100199624: d2800000    	mov	x0, #0x0                ; =0
100199628: 14000009    	b	0x10019964c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3154>
10019962c: a9465275    	ldp	x21, x20, [x19, #0x60]
100199630: aa1403e0    	mov	x0, x20
100199634: 9464c3fc    	bl	0x101aca624 <_writev+0x101aca624>
100199638: aa1303e0    	mov	x0, x19
10019963c: 9400054b    	bl	0x10019ab68 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x4670>
100199640: aa1403e1    	mov	x1, x20
100199644: f100029f    	cmp	x20, #0x0
100199648: 9a9503e0    	csel	x0, xzr, x21, eq
10019964c: d10083bf    	sub	sp, x29, #0x20
100199650: a9427bfd    	ldp	x29, x30, [sp, #0x20]
100199654: a9414ff4    	ldp	x20, x19, [sp, #0x10]
100199658: a8c357f6    	ldp	x22, x21, [sp], #0x30
10019965c: d65f03c0    	ret
100199660: aa0003e8    	mov	x8, x0
100199664: d28c8dc1    	mov	x1, #0x646e             ; =25710
100199668: f2fd4001    	movk	x1, #0xea00, lsl #48
10019966c: d28eaa60    	mov	x0, #0x7553             ; =30035
100199670: f2ac6c40    	movk	x0, #0x6362, lsl #16
100199674: f2cdade0    	movk	x0, #0x6d6f, lsl #32
100199678: f2ec2da0    	movk	x0, #0x616d, lsl #48
10019967c: 92401d08    	and	x8, x8, #0xff
100199680: d000ca69    	adrp	x9, 0x101ae7000 <_$s4Otty16SleepHelperNamesO9plistNameSSvpZMV+0x10a0>
100199684: 913e0129    	add	x9, x9, #0xf80
100199688: 1000008a    	adr	x10, 0x100199698 <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x31a0>
10019968c: 3868692b    	ldrb	w11, [x9, x8]
100199690: 8b0b094a    	add	x10, x10, x11, lsl #2
100199694: d61f0140    	br	x10
100199698: d2fcc001    	mov	x1, #-0x1a00000000000000 ; =-1873497444986126336
10019969c: d28e09e0    	mov	x0, #0x704f             ; =28751
1001996a0: f2ad2e80    	movk	x0, #0x6974, lsl #16
1001996a4: f2cdcde0    	movk	x0, #0x6e6f, lsl #32
1001996a8: d65f03c0    	ret
1001996ac: d2fce001    	mov	x1, #-0x1900000000000000 ; =-1801439850948198400
1001996b0: d28d2900    	mov	x0, #0x6948             ; =26952
1001996b4: f2ae8e60    	movk	x0, #0x7473, lsl #16
1001996b8: f2ce4de0    	movk	x0, #0x726f, lsl #32
1001996bc: f2e00f20    	movk	x0, #0x79, lsl #48
1001996c0: d65f03c0    	ret
1001996c4: d2fcc001    	mov	x1, #-0x1a00000000000000 ; =-1873497444986126336
1001996c8: d28de8c0    	mov	x0, #0x6f46             ; =28486
1001996cc: f2ac8d80    	movk	x0, #0x646c, lsl #16
1001996d0: f2ce4ca0    	movk	x0, #0x7265, lsl #32
1001996d4: d65f03c0    	ret
1001996d8: d2fcc001    	mov	x1, #-0x1a00000000000000 ; =-1873497444986126336
1001996dc: d28caa40    	mov	x0, #0x6552             ; =25938
1001996e0: f2ac8c20    	movk	x0, #0x6461, lsl #16
1001996e4: f2ccada0    	movk	x0, #0x656d, lsl #32
1001996e8: d65f03c0    	ret
1001996ec: d2fd0001    	mov	x1, #-0x1800000000000000 ; =-1729382256910270464
1001996f0: d28e4820    	mov	x0, #0x7241             ; =29249
1001996f4: f2aeace0    	movk	x0, #0x7567, lsl #16
1001996f8: f2ccada0    	movk	x0, #0x656d, lsl #32
1001996fc: f2ee8dc0    	movk	x0, #0x746e, lsl #48
100199700: d65f03c0    	ret
100199704: d2fc8001    	mov	x1, #-0x1c00000000000000 ; =-2017612633061982208
100199708: 528d28c0    	mov	w0, #0x6946             ; =26950
10019970c: 72acad80    	movk	w0, #0x656c, lsl #16
100199710: d65f03c0    	ret
100199714: d2fce001    	mov	x1, #-0x1900000000000000 ; =-1801439850948198400
100199718: d28dca60    	mov	x0, #0x6e53             ; =28243
10019971c: f2ae0d20    	movk	x0, #0x7069, lsl #16
100199720: f2ccae00    	movk	x0, #0x6570, lsl #32
100199724: f2e00e80    	movk	x0, #0x74, lsl #48
100199728: d65f03c0    	ret
10019972c: d2fca001    	mov	x1, #-0x1b00000000000000 ; =-1945555039024054272
100199730: d28d8820    	mov	x0, #0x6c41             ; =27713
100199734: f2ac2d20    	movk	x0, #0x6169, lsl #16
100199738: f2c00e60    	movk	x0, #0x73, lsl #32
10019973c: d65f03c0    	ret
100199740: d2fc6001    	mov	x1, #-0x1d00000000000000 ; =-2089670227099910144
100199744: 528d28c0    	mov	w0, #0x6946             ; =26950
100199748: 72a00f00    	movk	w0, #0x78, lsl #16
10019974c: d65f03c0    	ret
100199750: d2fce001    	mov	x1, #-0x1900000000000000 ; =-1801439850948198400
100199754: d28ca980    	mov	x0, #0x654c             ; =25932
100199758: f2ae4c20    	movk	x0, #0x7261, lsl #16
10019975c: f2ccadc0    	movk	x0, #0x656e, lsl #32
100199760: f2e00c80    	movk	x0, #0x64, lsl #48
100199764: d65f03c0    	ret
100199768: d2fcc001    	mov	x1, #-0x1a00000000000000 ; =-1873497444986126336
10019976c: d28caa40    	mov	x0, #0x6552             ; =25938
100199770: f2ad2c60    	movk	x0, #0x6963, lsl #16
100199774: f2ccae00    	movk	x0, #0x6570, lsl #32
100199778: d65f03c0    	ret
10019977c: a9bf7bfd    	stp	x29, x30, [sp, #-0x10]!
100199780: 910003fd    	mov	x29, sp
100199784: f9400a80    	ldr	x0, [x20, #0x10]
100199788: 9464c16a    	bl	0x101ac9d30 <_writev+0x101ac9d30>
10019978c: f9400e80    	ldr	x0, [x20, #0x18]
100199790: 9464c168    	bl	0x101ac9d30 <_writev+0x101ac9d30>
100199794: f9401280    	ldr	x0, [x20, #0x20]
100199798: 9464c166    	bl	0x101ac9d30 <_writev+0x101ac9d30>
10019979c: f9401680    	ldr	x0, [x20, #0x28]
1001997a0: 9464c39b    	bl	0x101aca60c <_writev+0x101aca60c>
1001997a4: f9401e80    	ldr	x0, [x20, #0x38]
1001997a8: 9464c399    	bl	0x101aca60c <_writev+0x101aca60c>
1001997ac: f9402280    	ldr	x0, [x20, #0x40]
1001997b0: 9464c160    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001997b4: f9402680    	ldr	x0, [x20, #0x48]
1001997b8: 9464c15e    	bl	0x101ac9d30 <_writev+0x101ac9d30>
1001997bc: 91014280    	add	x0, x20, #0x50
1001997c0: 9464c4bf    	bl	0x101acaabc <_writev+0x101acaabc>
1001997c4: f0010d21    	adrp	x1, 0x102340000 <_OBJC_CLASS_$__TtC16CodeEditTextView20TextSelectionManager+0x480>
1001997c8: 9130c021    	add	x1, x1, #0xc30
1001997cc: 9000ca42    	adrp	x2, 0x101ae1000 <_writev+0x101ae1000>
1001997d0: 91040042    	add	x2, x2, #0x100
1001997d4: 91016280    	add	x0, x20, #0x58
1001997d8: 97fa5026    	bl	0x10002d870 <_$s9TextStory09BufferingA7StorageC5coderACSgSo7NSCoderC_tcfC+0xaa50>
1001997dc: a9478680    	ldp	x0, x1, [x20, #0x78]
1001997e0: 97f9a818    	bl	0x100003840 <_$s9TextStory0A19MutationEventRouterCfD+0x16c>
1001997e4: a9488680    	ldp	x0, x1, [x20, #0x88]
1001997e8: 97f9a816    	bl	0x100003840 <_$s9TextStory0A19MutationEventRouterCfD+0x16c>
1001997ec: aa1403e0    	mov	x0, x20
1001997f0: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1001997f4: d65f03c0    	ret
1001997f8: a9bf7bfd    	stp	x29, x30, [sp, #-0x10]!
1001997fc: 910003fd    	mov	x29, sp
100199800: 97ffffdf    	bl	0x10019977c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3284>
100199804: aa1403e0    	mov	x0, x20
100199808: 52801301    	mov	w1, #0x98               ; =152
10019980c: 528000e2    	mov	w2, #0x7                ; =7
100199810: a8c17bfd    	ldp	x29, x30, [sp], #0x10
100199814: 1464c3a2    	b	0x101aca69c <_writev+0x101aca69c>
100199818: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
10019981c: a9017bfd    	stp	x29, x30, [sp, #0x10]
100199820: 910043fd    	add	x29, sp, #0x10
100199824: aa1403e0    	mov	x0, x20
100199828: 52801301    	mov	w1, #0x98               ; =152
10019982c: 528000e2    	mov	w2, #0x7                ; =7
100199830: 9464c356    	bl	0x101aca588 <_writev+0x101aca588>
100199834: aa0003f4    	mov	x20, x0
100199838: 94000005    	bl	0x10019984c <_$s8Markdown21DirectiveArgumentTextV11LineSegmentV09untrimmedD0SSvg+0x3354>
10019983c: aa1403e0    	mov	x0, x20
100199840: a9417bfd    	ldp	x29, x30, [sp, #0x10]
100199844: a8c24ff4    	ldp	x20, x19, [sp], #0x20
100199848: d65f03c0    	ret
10019984c: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
100199850: a9017bfd    	stp	x29, x30, [sp, #0x10]
100199854: 910043fd    	add	x29, sp, #0x10
100199858: a9017e9f    	stp	xzr, xzr, [x20, #0x10]
10019985c: d00109a8    	adrp	x8, 0x1022cf000 <_writev+0x1022cf000>
100199860: f9425508    	ldr	x8, [x8, #0x4a8]
100199864: a902229f    	stp	xzr, x8, [x20, #0x20]
100199868: 92800009    	mov	x9, #-0x1               ; =-1
10019986c: a9032289    	stp	x9, x8, [x20, #0x30]
100199870: b0010c68    	adrp	x8, 0x102326000 <_writev+0x102326000>
100199874: f944e500    	ldr	x0, [x8, #0x9c8]
100199878: 9464c12b    	bl	0x101ac9d24 <_writev+0x101ac9d24>
10019987c: aa0003f3    	mov	x19, x0
100199880: d283a3a8    	mov	x8, #0x1d1d             ; =7453
100199884: f2a3a3a8    	movk	x8, #0x1d1d, lsl #16
100199888: f2c3a3a8    	movk	x8, #0x1d1d, lsl #32
10019988c: f2e7f9a8    	movk	x8, #0x3fcd, lsl #48
100199890: 9e670100    	fmov	d0, x8
100199894: b204cbe8    	mov	x8, #0x7070707070707070 ; =8102099357864587376
100199898: f2e7fc08    	movk	x8, #0x3fe0, lsl #48
10019989c: 9e670101    	fmov	d1, x8
1001998a0: d29bdbe8    	mov	x8, #0xdedf             ; =57055
1001998a4: f2bbdbc8    	movk	x8, #0xdede, lsl #16
1001998a8: f2dbdbc8    	movk	x8, #0xdede, lsl #32
1001998ac: f2e7fdc8    	movk	x8, #0x3fee, lsl #48
1001998b0: 9e670102    	fmov	d2, x8
1001998b4: 1e6e1003    	fmov	d3, #1.00000000
1001998b8: 9464caea    	bl	0x101acc460 <_writev+0x101acc460>
1001998bc: aa1d03fd    	mov	x29, x29
1001998c0: 9464c125    	bl	0x101ac9d54 <_writev+0x101ac9d54>
1001998c4: f9002280    	str	x0, [x20, #0x40]
1001998c8: d2828f68    	mov	x8, #0x147b             ; =5243
1001998cc: f2a8f5c8    	movk	x8, #0x47ae, lsl #16
1001998d0: f2cf5c28    	movk	x8, #0x7ae1, lsl #32
1001998d4: f2e7f688    	movk	x8, #0x3fb4, lsl #48
1001998d8: 9e670101    	fmov	d1, x8
1001998dc: 1e6c1000    	fmov	d0, #0.50000000
1001998e0: aa1303e0    	mov	x0, x19
1001998e4: 9464caf7    	bl	0x101acc4c0 <_writev+0x101acc4c0>
1001998e8: aa1d03fd    	mov	x29, x29
1001998ec: 9464c11a    	bl	0x101ac9d54 <_writev+0x101ac9d54>
1001998f0: f9002680    	str	x0, [x20, #0x48]
1001998f4: 91014280    	add	x0, x20, #0x50
1001998f8: d2800001    	mov	x1, #0x0                ; =0
1001998fc: 9464c473    	bl	0x101acaac8 <_writev+0x101acaac8>
100199900: 6f00e400    	movi.2d	v0, #0000000000000000
100199904: 3c888280    	stur	q0, [x20, #0x88]
100199908: 3c878280    	stur	q0, [x20, #0x78]
10019990c: 3c868280    	stur	q0, [x20, #0x68]
100199910: 3c858280    	stur	q0, [x20, #0x58]
100199914: aa1403e0    	mov	x0, x20
100199918: a9417bfd    	ldp	x29, x30, [sp, #0x10]
10019991c: a8c24ff4    	ldp	x20, x19, [sp], #0x20
100199920: d65f03c0    	ret
