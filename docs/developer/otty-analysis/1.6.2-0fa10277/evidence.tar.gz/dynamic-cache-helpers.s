
.build/rea/otty-arm64.macho:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010140edd8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E>:
10140ee14: d10783ff    	sub	sp, sp, #0x1e0
10140ee18: a9196ffc    	stp	x28, x27, [sp, #0x190]
10140ee1c: a91a5ff8    	stp	x24, x23, [sp, #0x1a0]
10140ee20: a91b57f6    	stp	x22, x21, [sp, #0x1b0]
10140ee24: a91c4ff4    	stp	x20, x19, [sp, #0x1c0]
10140ee28: a91d7bfd    	stp	x29, x30, [sp, #0x1d0]
10140ee2c: 910743fd    	add	x29, sp, #0x1d0
10140ee30: aa0803f3    	mov	x19, x8
10140ee34: a9007fe2    	stp	x2, xzr, [sp]
10140ee38: a90103e1    	stp	x1, x0, [sp, #0x10]
10140ee3c: a9027fe1    	stp	x1, xzr, [sp, #0x20]
10140ee40: f9001be1    	str	x1, [sp, #0x30]
10140ee44: 0f000540    	movi.2s	v0, #0xa
10140ee48: fd001fe0    	str	d0, [sp, #0x38]
10140ee4c: 52800028    	mov	w8, #0x1                ; =1
10140ee50: 390103e8    	strb	w8, [sp, #0x40]
10140ee54: 790093ff    	strh	wzr, [sp, #0x48]
10140ee58: 9101a3e0    	add	x0, sp, #0x68
10140ee5c: 910003e1    	mov	x1, sp
10140ee60: 97ffbf6c    	bl	0x1013fec10 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xee8>
10140ee64: f94037e8    	ldr	x8, [sp, #0x68]
10140ee68: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10140ee6c: eb09011f    	cmp	x8, x9
10140ee70: 540000a1    	b.ne	0x10140ee84 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xac>
10140ee74: 52800108    	mov	w8, #0x8                ; =8
10140ee78: a900227f    	stp	xzr, x8, [x19]
10140ee7c: f9000a7f    	str	xzr, [x19, #0x10]
10140ee80: 14000041    	b	0x10140ef84 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x1ac>
10140ee84: 97da3e1b    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140ee88: 52803400    	mov	w0, #0x1a0              ; =416
10140ee8c: 52800101    	mov	w1, #0x8                ; =8
10140ee90: 97da3e12    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140ee94: b4000860    	cbz	x0, 0x10140efa0 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x1c8>
10140ee98: aa0003f4    	mov	x20, x0
10140ee9c: 9101a3f6    	add	x22, sp, #0x68
10140eea0: ad4206c0    	ldp	q0, q1, [x22, #0x40]
10140eea4: ad020400    	stp	q0, q1, [x0, #0x40]
10140eea8: f94067e8    	ldr	x8, [sp, #0xc8]
10140eeac: f9003008    	str	x8, [x0, #0x60]
10140eeb0: 3cc683e0    	ldur	q0, [sp, #0x68]
10140eeb4: 3cc783e1    	ldur	q1, [sp, #0x78]
10140eeb8: ad000400    	stp	q0, q1, [x0]
10140eebc: ad4102c1    	ldp	q1, q0, [x22, #0x20]
10140eec0: ad010001    	stp	q1, q0, [x0, #0x20]
10140eec4: 52800088    	mov	w8, #0x4                ; =4
10140eec8: a90503e8    	stp	x8, x0, [sp, #0x50]
10140eecc: 52800035    	mov	w21, #0x1               ; =1
10140eed0: f90033f5    	str	x21, [sp, #0x60]
10140eed4: ad4107e0    	ldp	q0, q1, [sp, #0x20]
10140eed8: ad0787e0    	stp	q0, q1, [sp, #0xf0]
10140eedc: 3dc013e0    	ldr	q0, [sp, #0x40]
10140eee0: 3d8047e0    	str	q0, [sp, #0x110]
10140eee4: ad4003e1    	ldp	q1, q0, [sp]
10140eee8: 52800d17    	mov	w23, #0x68              ; =104
10140eeec: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
10140eef0: ad0683e1    	stp	q1, q0, [sp, #0xd0]
10140eef4: 1400000f    	b	0x10140ef30 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x158>
10140eef8: 8b170288    	add	x8, x20, x23
10140eefc: ad4606c0    	ldp	q0, q1, [x22, #0xc0]
10140ef00: 3dc03ac2    	ldr	q2, [x22, #0xe0]
10140ef04: ad008901    	stp	q1, q2, [x8, #0x10]
10140ef08: 3d800100    	str	q0, [x8]
10140ef0c: ad4786c0    	ldp	q0, q1, [x22, #0xf0]
10140ef10: 3dc046c2    	ldr	q2, [x22, #0x110]
10140ef14: f85b83a9    	ldur	x9, [x29, #-0x48]
10140ef18: f9003109    	str	x9, [x8, #0x60]
10140ef1c: ad020901    	stp	q1, q2, [x8, #0x40]
10140ef20: 3d800d00    	str	q0, [x8, #0x30]
10140ef24: 910006b5    	add	x21, x21, #0x1
10140ef28: f90033f5    	str	x21, [sp, #0x60]
10140ef2c: 9101a2f7    	add	x23, x23, #0x68
10140ef30: d102a3a0    	sub	x0, x29, #0xa8
10140ef34: 910343e1    	add	x1, sp, #0xd0
10140ef38: 97ffbf36    	bl	0x1013fec10 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xee8>
10140ef3c: f85583a8    	ldur	x8, [x29, #-0xa8]
10140ef40: eb18011f    	cmp	x8, x24
10140ef44: 54000180    	b.eq	0x10140ef74 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x19c>
10140ef48: f9402be8    	ldr	x8, [sp, #0x50]
10140ef4c: eb0802bf    	cmp	x21, x8
10140ef50: 54fffd41    	b.ne	0x10140eef8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x120>
10140ef54: 910143e0    	add	x0, sp, #0x50
10140ef58: aa1503e1    	mov	x1, x21
10140ef5c: 52800022    	mov	w2, #0x1                ; =1
10140ef60: 52800103    	mov	w3, #0x8                ; =8
10140ef64: 52800d04    	mov	w4, #0x68               ; =104
10140ef68: 9418663a    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10140ef6c: f9402ff4    	ldr	x20, [sp, #0x58]
10140ef70: 17ffffe2    	b	0x10140eef8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x120>
10140ef74: 3dc017e0    	ldr	q0, [sp, #0x50]
10140ef78: 3d800260    	str	q0, [x19]
10140ef7c: f94033e8    	ldr	x8, [sp, #0x60]
10140ef80: f9000a68    	str	x8, [x19, #0x10]
10140ef84: a95d7bfd    	ldp	x29, x30, [sp, #0x1d0]
10140ef88: a95c4ff4    	ldp	x20, x19, [sp, #0x1c0]
10140ef8c: a95b57f6    	ldp	x22, x21, [sp, #0x1b0]
10140ef90: a95a5ff8    	ldp	x24, x23, [sp, #0x1a0]
10140ef94: a9596ffc    	ldp	x28, x27, [sp, #0x190]
10140ef98: 910783ff    	add	sp, sp, #0x1e0
10140ef9c: d65f03c0    	ret
10140efa0: 52800100    	mov	w0, #0x8                ; =8
10140efa4: 52803401    	mov	w1, #0x1a0              ; =416
10140efa8: 941ad0f3    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140efac: d4200020    	brk	#0x1
10140efb0: aa0003f3    	mov	x19, x0
10140efb4: 9101a3e0    	add	x0, sp, #0x68
10140efb8: 97dbb9c8    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140efbc: aa1303e0    	mov	x0, x19
10140efc0: 941ae985    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140efc4: aa0003f3    	mov	x19, x0
10140efc8: d102a3a0    	sub	x0, x29, #0xa8
10140efcc: 97dbb9c3    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140efd0: 910143e0    	add	x0, sp, #0x50
10140efd4: 94011ba4    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140efd8: aa1303e0    	mov	x0, x19
10140efdc: 941ae97e    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140efe0: aa0003f3    	mov	x19, x0
10140efe4: 910143e0    	add	x0, sp, #0x50
10140efe8: 94011b9f    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140efec: aa1303e0    	mov	x0, x19
10140eff0: 941ae979    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140eff4: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
10140eff8: a9017bfd    	stp	x29, x30, [sp, #0x10]
10140effc: 910043fd    	add	x29, sp, #0x10
10140f000: f100085f    	cmp	x2, #0x2
10140f004: 540005c3    	b.lo	0x10140f0bc <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x2e4>
10140f008: a9422428    	ldp	x8, x9, [x1, #0x20]
10140f00c: f1000d3f    	cmp	x9, #0x3
10140f010: 54000480    	b.eq	0x10140f0a0 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x2c8>
10140f014: f100113f    	cmp	x9, #0x4
10140f018: 54000180    	b.eq	0x10140f048 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x270>
10140f01c: f100153f    	cmp	x9, #0x5
10140f020: 540004e1    	b.ne	0x10140f0bc <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x2e4>
10140f024: b9400109    	ldr	w9, [x8]
10140f028: 39401108    	ldrb	w8, [x8, #0x4]
10140f02c: 528e0c2a    	mov	w10, #0x7061            ; =28769
10140f030: 72ad8e0a    	movk	w10, #0x6c70, lsl #16
10140f034: 6b0a013f    	cmp	w9, w10
10140f038: 52800f29    	mov	w9, #0x79               ; =121
10140f03c: 7a490100    	ccmp	w8, w9, #0x0, eq
10140f040: 540003e1    	b.ne	0x10140f0bc <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x2e4>
10140f044: 1400000b    	b	0x10140f070 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x298>
10140f048: b9400109    	ldr	w9, [x8]
10140f04c: 528e4c8a    	mov	w10, #0x7264            ; =29284
10140f050: 72ae0dea    	movk	w10, #0x706f, lsl #16
10140f054: 6b0a013f    	cmp	w9, w10
10140f058: 540000c0    	b.eq	0x10140f070 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x298>
10140f05c: b9400108    	ldr	w8, [x8]
10140f060: 528d0e69    	mov	w9, #0x6873             ; =26739
10140f064: 72aeede9    	movk	w9, #0x776f, lsl #16
10140f068: 6b09011f    	cmp	w8, w9
10140f06c: 54000281    	b.ne	0x10140f0bc <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x2e4>
10140f070: aa0003f3    	mov	x19, x0
10140f074: 97da3d9f    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140f078: 52800020    	mov	w0, #0x1                ; =1
10140f07c: 52800021    	mov	w1, #0x1                ; =1
10140f080: 97da3d96    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140f084: b40002a0    	cbz	x0, 0x10140f0d8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x300>
10140f088: aa0003e8    	mov	x8, x0
10140f08c: 52800089    	mov	w9, #0x4                ; =4
10140f090: 39000009    	strb	w9, [x0]
10140f094: 52800029    	mov	w9, #0x1                ; =1
10140f098: aa1303e0    	mov	x0, x19
10140f09c: 1400000a    	b	0x10140f0c4 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x2ec>
10140f0a0: 79400109    	ldrh	w9, [x8]
10140f0a4: 39400908    	ldrb	w8, [x8, #0x2]
10140f0a8: 528dee0a    	mov	w10, #0x6f70            ; =28528
10140f0ac: 6b0a013f    	cmp	w9, w10
10140f0b0: 52800e09    	mov	w9, #0x70               ; =112
10140f0b4: 7a490100    	ccmp	w8, w9, #0x0, eq
10140f0b8: 54fffdc0    	b.eq	0x10140f070 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x298>
10140f0bc: d2800009    	mov	x9, #0x0                ; =0
10140f0c0: 52800028    	mov	w8, #0x1                ; =1
10140f0c4: a9002009    	stp	x9, x8, [x0]
10140f0c8: f9000809    	str	x9, [x0, #0x10]
10140f0cc: a9417bfd    	ldp	x29, x30, [sp, #0x10]
10140f0d0: a8c24ff4    	ldp	x20, x19, [sp], #0x20
10140f0d4: d65f03c0    	ret
10140f0d8: 52800020    	mov	w0, #0x1                ; =1
10140f0dc: 52800021    	mov	w1, #0x1                ; =1
10140f0e0: 941ad097    	bl	0x101ac333c <__ZN5alloc5alloc18handle_alloc_error17hb1cae578948d88efE>
10140f0e4: d10783ff    	sub	sp, sp, #0x1e0
10140f0e8: a9196ffc    	stp	x28, x27, [sp, #0x190]
10140f0ec: a91a5ff8    	stp	x24, x23, [sp, #0x1a0]
10140f0f0: a91b57f6    	stp	x22, x21, [sp, #0x1b0]
10140f0f4: a91c4ff4    	stp	x20, x19, [sp, #0x1c0]
10140f0f8: a91d7bfd    	stp	x29, x30, [sp, #0x1d0]
10140f0fc: 910743fd    	add	x29, sp, #0x1d0
10140f100: aa0803f3    	mov	x19, x8
10140f104: a9007fe2    	stp	x2, xzr, [sp]
10140f108: a90103e1    	stp	x1, x0, [sp, #0x10]
10140f10c: a9027fe1    	stp	x1, xzr, [sp, #0x20]
10140f110: f9001be1    	str	x1, [sp, #0x30]
10140f114: 0f000540    	movi.2s	v0, #0xa
10140f118: fd001fe0    	str	d0, [sp, #0x38]
10140f11c: 52800028    	mov	w8, #0x1                ; =1
10140f120: 390103e8    	strb	w8, [sp, #0x40]
10140f124: 790093ff    	strh	wzr, [sp, #0x48]
10140f128: 9101a3e0    	add	x0, sp, #0x68
10140f12c: 910003e1    	mov	x1, sp
10140f130: 97ffbe5a    	bl	0x1013fea98 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xd70>
10140f134: f94037e8    	ldr	x8, [sp, #0x68]
10140f138: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10140f13c: eb09011f    	cmp	x8, x9
10140f140: 540000a1    	b.ne	0x10140f154 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x37c>
10140f144: 52800108    	mov	w8, #0x8                ; =8
10140f148: a900227f    	stp	xzr, x8, [x19]
10140f14c: f9000a7f    	str	xzr, [x19, #0x10]
10140f150: 14000041    	b	0x10140f254 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x47c>
10140f154: 97da3d67    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140f158: 52803400    	mov	w0, #0x1a0              ; =416
10140f15c: 52800101    	mov	w1, #0x8                ; =8
10140f160: 97da3d5e    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140f164: b4000860    	cbz	x0, 0x10140f270 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x498>
10140f168: aa0003f4    	mov	x20, x0
10140f16c: 9101a3f6    	add	x22, sp, #0x68
10140f170: ad4206c0    	ldp	q0, q1, [x22, #0x40]
10140f174: ad020400    	stp	q0, q1, [x0, #0x40]
10140f178: f94067e8    	ldr	x8, [sp, #0xc8]
10140f17c: f9003008    	str	x8, [x0, #0x60]
10140f180: 3cc683e0    	ldur	q0, [sp, #0x68]
10140f184: 3cc783e1    	ldur	q1, [sp, #0x78]
10140f188: ad000400    	stp	q0, q1, [x0]
10140f18c: ad4102c1    	ldp	q1, q0, [x22, #0x20]
10140f190: ad010001    	stp	q1, q0, [x0, #0x20]
10140f194: 52800088    	mov	w8, #0x4                ; =4
10140f198: a90503e8    	stp	x8, x0, [sp, #0x50]
10140f19c: 52800035    	mov	w21, #0x1               ; =1
10140f1a0: f90033f5    	str	x21, [sp, #0x60]
10140f1a4: ad4107e0    	ldp	q0, q1, [sp, #0x20]
10140f1a8: ad0787e0    	stp	q0, q1, [sp, #0xf0]
10140f1ac: 3dc013e0    	ldr	q0, [sp, #0x40]
10140f1b0: 3d8047e0    	str	q0, [sp, #0x110]
10140f1b4: ad4003e1    	ldp	q1, q0, [sp]
10140f1b8: 52800d17    	mov	w23, #0x68              ; =104
10140f1bc: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
10140f1c0: ad0683e1    	stp	q1, q0, [sp, #0xd0]
10140f1c4: 1400000f    	b	0x10140f200 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x428>
10140f1c8: 8b170288    	add	x8, x20, x23
10140f1cc: ad4606c0    	ldp	q0, q1, [x22, #0xc0]
10140f1d0: 3dc03ac2    	ldr	q2, [x22, #0xe0]
10140f1d4: ad008901    	stp	q1, q2, [x8, #0x10]
10140f1d8: 3d800100    	str	q0, [x8]
10140f1dc: ad4786c0    	ldp	q0, q1, [x22, #0xf0]
10140f1e0: 3dc046c2    	ldr	q2, [x22, #0x110]
10140f1e4: f85b83a9    	ldur	x9, [x29, #-0x48]
10140f1e8: f9003109    	str	x9, [x8, #0x60]
10140f1ec: ad020901    	stp	q1, q2, [x8, #0x40]
10140f1f0: 3d800d00    	str	q0, [x8, #0x30]
10140f1f4: 910006b5    	add	x21, x21, #0x1
10140f1f8: f90033f5    	str	x21, [sp, #0x60]
10140f1fc: 9101a2f7    	add	x23, x23, #0x68
10140f200: d102a3a0    	sub	x0, x29, #0xa8
10140f204: 910343e1    	add	x1, sp, #0xd0
10140f208: 97ffbe24    	bl	0x1013fea98 <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0xd70>
10140f20c: f85583a8    	ldur	x8, [x29, #-0xa8]
10140f210: eb18011f    	cmp	x8, x24
10140f214: 54000180    	b.eq	0x10140f244 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x46c>
10140f218: f9402be8    	ldr	x8, [sp, #0x50]
10140f21c: eb0802bf    	cmp	x21, x8
10140f220: 54fffd41    	b.ne	0x10140f1c8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x3f0>
10140f224: 910143e0    	add	x0, sp, #0x50
10140f228: aa1503e1    	mov	x1, x21
10140f22c: 52800022    	mov	w2, #0x1                ; =1
10140f230: 52800103    	mov	w3, #0x8                ; =8
10140f234: 52800d04    	mov	w4, #0x68               ; =104
10140f238: 94186586    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10140f23c: f9402ff4    	ldr	x20, [sp, #0x58]
10140f240: 17ffffe2    	b	0x10140f1c8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x3f0>
10140f244: 3dc017e0    	ldr	q0, [sp, #0x50]
10140f248: 3d800260    	str	q0, [x19]
10140f24c: f94033e8    	ldr	x8, [sp, #0x60]
10140f250: f9000a68    	str	x8, [x19, #0x10]
10140f254: a95d7bfd    	ldp	x29, x30, [sp, #0x1d0]
10140f258: a95c4ff4    	ldp	x20, x19, [sp, #0x1c0]
10140f25c: a95b57f6    	ldp	x22, x21, [sp, #0x1b0]
10140f260: a95a5ff8    	ldp	x24, x23, [sp, #0x1a0]
10140f264: a9596ffc    	ldp	x28, x27, [sp, #0x190]
10140f268: 910783ff    	add	sp, sp, #0x1e0
10140f26c: d65f03c0    	ret
10140f270: 52800100    	mov	w0, #0x8                ; =8
10140f274: 52803401    	mov	w1, #0x1a0              ; =416
10140f278: 941ad03f    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140f27c: d4200020    	brk	#0x1
10140f280: aa0003f3    	mov	x19, x0
10140f284: 9101a3e0    	add	x0, sp, #0x68
10140f288: 97dbb914    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140f28c: aa1303e0    	mov	x0, x19
10140f290: 941ae8d1    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140f294: aa0003f3    	mov	x19, x0
10140f298: d102a3a0    	sub	x0, x29, #0xa8
10140f29c: 97dbb90f    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140f2a0: 910143e0    	add	x0, sp, #0x50
10140f2a4: 94011af0    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140f2a8: aa1303e0    	mov	x0, x19
10140f2ac: 941ae8ca    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140f2b0: aa0003f3    	mov	x19, x0
10140f2b4: 910143e0    	add	x0, sp, #0x50
10140f2b8: 94011aeb    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140f2bc: aa1303e0    	mov	x0, x19
10140f2c0: 941ae8c5    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140f2c4: d10783ff    	sub	sp, sp, #0x1e0
10140f2c8: a9196ffc    	stp	x28, x27, [sp, #0x190]
10140f2cc: a91a5ff8    	stp	x24, x23, [sp, #0x1a0]
10140f2d0: a91b57f6    	stp	x22, x21, [sp, #0x1b0]
10140f2d4: a91c4ff4    	stp	x20, x19, [sp, #0x1c0]
10140f2d8: a91d7bfd    	stp	x29, x30, [sp, #0x1d0]
10140f2dc: 910743fd    	add	x29, sp, #0x1d0
10140f2e0: aa0803f3    	mov	x19, x8
10140f2e4: a90103e1    	stp	x1, x0, [sp, #0x10]
10140f2e8: a9027fe1    	stp	x1, xzr, [sp, #0x20]
10140f2ec: f9001be1    	str	x1, [sp, #0x30]
10140f2f0: 0f000540    	movi.2s	v0, #0xa
10140f2f4: fd001fe0    	str	d0, [sp, #0x38]
10140f2f8: 52800028    	mov	w8, #0x1                ; =1
10140f2fc: 390103e8    	strb	w8, [sp, #0x40]
10140f300: 790093ff    	strh	wzr, [sp, #0x48]
10140f304: a9007fe2    	stp	x2, xzr, [sp]
10140f308: 9101a3e0    	add	x0, sp, #0x68
10140f30c: 910003e1    	mov	x1, sp
10140f310: 97fff8ac    	bl	0x10140d5c0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2274>
10140f314: f94037e8    	ldr	x8, [sp, #0x68]
10140f318: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10140f31c: eb09011f    	cmp	x8, x9
10140f320: 540000a1    	b.ne	0x10140f334 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x55c>
10140f324: 52800108    	mov	w8, #0x8                ; =8
10140f328: a900227f    	stp	xzr, x8, [x19]
10140f32c: f9000a7f    	str	xzr, [x19, #0x10]
10140f330: 14000041    	b	0x10140f434 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x65c>
10140f334: 97da3cef    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140f338: 52803400    	mov	w0, #0x1a0              ; =416
10140f33c: 52800101    	mov	w1, #0x8                ; =8
10140f340: 97da3ce6    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140f344: b4000860    	cbz	x0, 0x10140f450 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x678>
10140f348: aa0003f4    	mov	x20, x0
10140f34c: 9101a3f6    	add	x22, sp, #0x68
10140f350: ad4206c0    	ldp	q0, q1, [x22, #0x40]
10140f354: ad020400    	stp	q0, q1, [x0, #0x40]
10140f358: f94067e8    	ldr	x8, [sp, #0xc8]
10140f35c: f9003008    	str	x8, [x0, #0x60]
10140f360: 3cc683e0    	ldur	q0, [sp, #0x68]
10140f364: 3cc783e1    	ldur	q1, [sp, #0x78]
10140f368: ad000400    	stp	q0, q1, [x0]
10140f36c: ad4102c1    	ldp	q1, q0, [x22, #0x20]
10140f370: ad010001    	stp	q1, q0, [x0, #0x20]
10140f374: 52800088    	mov	w8, #0x4                ; =4
10140f378: a90503e8    	stp	x8, x0, [sp, #0x50]
10140f37c: 52800035    	mov	w21, #0x1               ; =1
10140f380: f90033f5    	str	x21, [sp, #0x60]
10140f384: ad4107e0    	ldp	q0, q1, [sp, #0x20]
10140f388: ad0787e0    	stp	q0, q1, [sp, #0xf0]
10140f38c: 3dc013e0    	ldr	q0, [sp, #0x40]
10140f390: 3d8047e0    	str	q0, [sp, #0x110]
10140f394: ad4003e1    	ldp	q1, q0, [sp]
10140f398: 52800d17    	mov	w23, #0x68              ; =104
10140f39c: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
10140f3a0: ad0683e1    	stp	q1, q0, [sp, #0xd0]
10140f3a4: 1400000f    	b	0x10140f3e0 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x608>
10140f3a8: 8b170288    	add	x8, x20, x23
10140f3ac: ad4606c0    	ldp	q0, q1, [x22, #0xc0]
10140f3b0: 3dc03ac2    	ldr	q2, [x22, #0xe0]
10140f3b4: ad008901    	stp	q1, q2, [x8, #0x10]
10140f3b8: 3d800100    	str	q0, [x8]
10140f3bc: ad4786c0    	ldp	q0, q1, [x22, #0xf0]
10140f3c0: 3dc046c2    	ldr	q2, [x22, #0x110]
10140f3c4: f85b83a9    	ldur	x9, [x29, #-0x48]
10140f3c8: f9003109    	str	x9, [x8, #0x60]
10140f3cc: ad020901    	stp	q1, q2, [x8, #0x40]
10140f3d0: 3d800d00    	str	q0, [x8, #0x30]
10140f3d4: 910006b5    	add	x21, x21, #0x1
10140f3d8: f90033f5    	str	x21, [sp, #0x60]
10140f3dc: 9101a2f7    	add	x23, x23, #0x68
10140f3e0: d102a3a0    	sub	x0, x29, #0xa8
10140f3e4: 910343e1    	add	x1, sp, #0xd0
10140f3e8: 97fff876    	bl	0x10140d5c0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2274>
10140f3ec: f85583a8    	ldur	x8, [x29, #-0xa8]
10140f3f0: eb18011f    	cmp	x8, x24
10140f3f4: 54000180    	b.eq	0x10140f424 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x64c>
10140f3f8: f9402be8    	ldr	x8, [sp, #0x50]
10140f3fc: eb0802bf    	cmp	x21, x8
10140f400: 54fffd41    	b.ne	0x10140f3a8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x5d0>
10140f404: 910143e0    	add	x0, sp, #0x50
10140f408: aa1503e1    	mov	x1, x21
10140f40c: 52800022    	mov	w2, #0x1                ; =1
10140f410: 52800103    	mov	w3, #0x8                ; =8
10140f414: 52800d04    	mov	w4, #0x68               ; =104
10140f418: 9418650e    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10140f41c: f9402ff4    	ldr	x20, [sp, #0x58]
10140f420: 17ffffe2    	b	0x10140f3a8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x5d0>
10140f424: 3dc017e0    	ldr	q0, [sp, #0x50]
10140f428: 3d800260    	str	q0, [x19]
10140f42c: f94033e8    	ldr	x8, [sp, #0x60]
10140f430: f9000a68    	str	x8, [x19, #0x10]
10140f434: a95d7bfd    	ldp	x29, x30, [sp, #0x1d0]
10140f438: a95c4ff4    	ldp	x20, x19, [sp, #0x1c0]
10140f43c: a95b57f6    	ldp	x22, x21, [sp, #0x1b0]
10140f440: a95a5ff8    	ldp	x24, x23, [sp, #0x1a0]
10140f444: a9596ffc    	ldp	x28, x27, [sp, #0x190]
10140f448: 910783ff    	add	sp, sp, #0x1e0
10140f44c: d65f03c0    	ret
10140f450: 52800100    	mov	w0, #0x8                ; =8
10140f454: 52803401    	mov	w1, #0x1a0              ; =416
10140f458: 941acfc7    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140f45c: d4200020    	brk	#0x1
10140f460: aa0003f3    	mov	x19, x0
10140f464: 9101a3e0    	add	x0, sp, #0x68
10140f468: 97dbb89c    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140f46c: aa1303e0    	mov	x0, x19
10140f470: 941ae859    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140f474: aa0003f3    	mov	x19, x0
10140f478: d102a3a0    	sub	x0, x29, #0xa8
10140f47c: 97dbb897    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140f480: 910143e0    	add	x0, sp, #0x50
10140f484: 94011a78    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140f488: aa1303e0    	mov	x0, x19
10140f48c: 941ae852    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140f490: aa0003f3    	mov	x19, x0
10140f494: 910143e0    	add	x0, sp, #0x50
10140f498: 94011a73    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140f49c: aa1303e0    	mov	x0, x19
10140f4a0: 941ae84d    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140f4a4: a9bb6ffc    	stp	x28, x27, [sp, #-0x50]!
10140f4a8: a9015ff8    	stp	x24, x23, [sp, #0x10]
10140f4ac: a90257f6    	stp	x22, x21, [sp, #0x20]
10140f4b0: a9034ff4    	stp	x20, x19, [sp, #0x30]
10140f4b4: a9047bfd    	stp	x29, x30, [sp, #0x40]
10140f4b8: 910103fd    	add	x29, sp, #0x40
10140f4bc: d106c3ff    	sub	sp, sp, #0x1b0
10140f4c0: aa0003f3    	mov	x19, x0
10140f4c4: a9017fe3    	stp	x3, xzr, [sp, #0x10]
10140f4c8: a90207e2    	stp	x2, x1, [sp, #0x20]
10140f4cc: a9037fe2    	stp	x2, xzr, [sp, #0x30]
10140f4d0: f90023e2    	str	x2, [sp, #0x40]
10140f4d4: 0f000540    	movi.2s	v0, #0xa
10140f4d8: fd0027e0    	str	d0, [sp, #0x48]
10140f4dc: 52800028    	mov	w8, #0x1                ; =1
10140f4e0: 390143e8    	strb	w8, [sp, #0x50]
10140f4e4: 7900b3ff    	strh	wzr, [sp, #0x58]
10140f4e8: a90017e4    	stp	x4, x5, [sp]
10140f4ec: 9101e3e0    	add	x0, sp, #0x78
10140f4f0: 910003e1    	mov	x1, sp
10140f4f4: 97ffbc4a    	bl	0x1013fe61c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8f4>
10140f4f8: f9403fe8    	ldr	x8, [sp, #0x78]
10140f4fc: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10140f500: eb09011f    	cmp	x8, x9
10140f504: 540000a1    	b.ne	0x10140f518 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x740>
10140f508: 52800108    	mov	w8, #0x8                ; =8
10140f50c: a900227f    	stp	xzr, x8, [x19]
10140f510: f9000a7f    	str	xzr, [x19, #0x10]
10140f514: 14000041    	b	0x10140f618 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x840>
10140f518: 97da3c76    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140f51c: 52803400    	mov	w0, #0x1a0              ; =416
10140f520: 52800101    	mov	w1, #0x8                ; =8
10140f524: 97da3c6d    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140f528: b4000860    	cbz	x0, 0x10140f634 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x85c>
10140f52c: aa0003f4    	mov	x20, x0
10140f530: 9101e3f6    	add	x22, sp, #0x78
10140f534: ad4186c0    	ldp	q0, q1, [x22, #0x30]
10140f538: 3dc016c2    	ldr	q2, [x22, #0x50]
10140f53c: ad020801    	stp	q1, q2, [x0, #0x40]
10140f540: 3cc783e1    	ldur	q1, [sp, #0x78]
10140f544: ad408ec2    	ldp	q2, q3, [x22, #0x10]
10140f548: ad000801    	stp	q1, q2, [x0]
10140f54c: f9406fe8    	ldr	x8, [sp, #0xd8]
10140f550: f9003008    	str	x8, [x0, #0x60]
10140f554: ad010003    	stp	q3, q0, [x0, #0x20]
10140f558: 52800088    	mov	w8, #0x4                ; =4
10140f55c: a90603e8    	stp	x8, x0, [sp, #0x60]
10140f560: 52800035    	mov	w21, #0x1               ; =1
10140f564: f9003bf5    	str	x21, [sp, #0x70]
10140f568: ad4107e0    	ldp	q0, q1, [sp, #0x20]
10140f56c: ad0807e0    	stp	q0, q1, [sp, #0x100]
10140f570: ad4207e0    	ldp	q0, q1, [sp, #0x40]
10140f574: ad0907e0    	stp	q0, q1, [sp, #0x120]
10140f578: ad4007e0    	ldp	q0, q1, [sp]
10140f57c: 52800d17    	mov	w23, #0x68              ; =104
10140f580: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
10140f584: ad0707e0    	stp	q0, q1, [sp, #0xe0]
10140f588: 1400000f    	b	0x10140f5c4 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x7ec>
10140f58c: 8b170288    	add	x8, x20, x23
10140f590: ad4686c0    	ldp	q0, q1, [x22, #0xd0]
10140f594: 3dc03ec2    	ldr	q2, [x22, #0xf0]
10140f598: ad008901    	stp	q1, q2, [x8, #0x10]
10140f59c: 3d800100    	str	q0, [x8]
10140f5a0: ad4806c0    	ldp	q0, q1, [x22, #0x100]
10140f5a4: 3dc04ac2    	ldr	q2, [x22, #0x120]
10140f5a8: f85b83a9    	ldur	x9, [x29, #-0x48]
10140f5ac: f9003109    	str	x9, [x8, #0x60]
10140f5b0: ad020901    	stp	q1, q2, [x8, #0x40]
10140f5b4: 3d800d00    	str	q0, [x8, #0x30]
10140f5b8: 910006b5    	add	x21, x21, #0x1
10140f5bc: f9003bf5    	str	x21, [sp, #0x70]
10140f5c0: 9101a2f7    	add	x23, x23, #0x68
10140f5c4: d102a3a0    	sub	x0, x29, #0xa8
10140f5c8: 910383e1    	add	x1, sp, #0xe0
10140f5cc: 97ffbc14    	bl	0x1013fe61c <__ZN101_$LT$otty_autocomplete..fix..rules..MkdirPRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h18f418f2ffbc60bdE+0x8f4>
10140f5d0: f85583a8    	ldur	x8, [x29, #-0xa8]
10140f5d4: eb18011f    	cmp	x8, x24
10140f5d8: 54000180    	b.eq	0x10140f608 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x830>
10140f5dc: f94033e8    	ldr	x8, [sp, #0x60]
10140f5e0: eb0802bf    	cmp	x21, x8
10140f5e4: 54fffd41    	b.ne	0x10140f58c <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x7b4>
10140f5e8: 910183e0    	add	x0, sp, #0x60
10140f5ec: aa1503e1    	mov	x1, x21
10140f5f0: 52800022    	mov	w2, #0x1                ; =1
10140f5f4: 52800103    	mov	w3, #0x8                ; =8
10140f5f8: 52800d04    	mov	w4, #0x68               ; =104
10140f5fc: 94186495    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10140f600: f94037f4    	ldr	x20, [sp, #0x68]
10140f604: 17ffffe2    	b	0x10140f58c <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x7b4>
10140f608: 3dc01be0    	ldr	q0, [sp, #0x60]
10140f60c: 3d800260    	str	q0, [x19]
10140f610: f9403be8    	ldr	x8, [sp, #0x70]
10140f614: f9000a68    	str	x8, [x19, #0x10]
10140f618: 9106c3ff    	add	sp, sp, #0x1b0
10140f61c: a9447bfd    	ldp	x29, x30, [sp, #0x40]
10140f620: a9434ff4    	ldp	x20, x19, [sp, #0x30]
10140f624: a94257f6    	ldp	x22, x21, [sp, #0x20]
10140f628: a9415ff8    	ldp	x24, x23, [sp, #0x10]
10140f62c: a8c56ffc    	ldp	x28, x27, [sp], #0x50
10140f630: d65f03c0    	ret
10140f634: 52800100    	mov	w0, #0x8                ; =8
10140f638: 52803401    	mov	w1, #0x1a0              ; =416
10140f63c: 941acf4e    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140f640: d4200020    	brk	#0x1
10140f644: aa0003f3    	mov	x19, x0
10140f648: 9101e3e0    	add	x0, sp, #0x78
10140f64c: 97dbb823    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140f650: aa1303e0    	mov	x0, x19
10140f654: 941ae7e0    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140f658: aa0003f3    	mov	x19, x0
10140f65c: d102a3a0    	sub	x0, x29, #0xa8
10140f660: 97dbb81e    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140f664: 910183e0    	add	x0, sp, #0x60
10140f668: 940119ff    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140f66c: aa1303e0    	mov	x0, x19
10140f670: 941ae7d9    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140f674: aa0003f3    	mov	x19, x0
10140f678: 910183e0    	add	x0, sp, #0x60
10140f67c: 940119fa    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140f680: aa1303e0    	mov	x0, x19
10140f684: 941ae7d4    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140f688: aa0203e3    	mov	x3, x2
10140f68c: aa0103e2    	mov	x2, x1
10140f690: aa0003e1    	mov	x1, x0
10140f694: aa0803e0    	mov	x0, x8
10140f698: 90004684    	adrp	x4, 0x101cdf000 <__ZN6flate22gz9FRESERVED17hc5fe87a211bdefc5E+0x4c8c>
10140f69c: 911ac084    	add	x4, x4, #0x6b0
10140f6a0: 528000c5    	mov	w5, #0x6                ; =6
10140f6a4: 17ffff80    	b	0x10140f4a4 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x6cc>
10140f6a8: d10783ff    	sub	sp, sp, #0x1e0
10140f6ac: a9196ffc    	stp	x28, x27, [sp, #0x190]
10140f6b0: a91a5ff8    	stp	x24, x23, [sp, #0x1a0]
10140f6b4: a91b57f6    	stp	x22, x21, [sp, #0x1b0]
10140f6b8: a91c4ff4    	stp	x20, x19, [sp, #0x1c0]
10140f6bc: a91d7bfd    	stp	x29, x30, [sp, #0x1d0]
10140f6c0: 910743fd    	add	x29, sp, #0x1d0
10140f6c4: aa0803f3    	mov	x19, x8
10140f6c8: a90103e1    	stp	x1, x0, [sp, #0x10]
10140f6cc: a9027fe1    	stp	x1, xzr, [sp, #0x20]
10140f6d0: f9001be1    	str	x1, [sp, #0x30]
10140f6d4: 0f000540    	movi.2s	v0, #0xa
10140f6d8: fd001fe0    	str	d0, [sp, #0x38]
10140f6dc: 52800028    	mov	w8, #0x1                ; =1
10140f6e0: 390103e8    	strb	w8, [sp, #0x40]
10140f6e4: 790093ff    	strh	wzr, [sp, #0x48]
10140f6e8: a9007fe2    	stp	x2, xzr, [sp]
10140f6ec: 9101a3e0    	add	x0, sp, #0x68
10140f6f0: 910003e1    	mov	x1, sp
10140f6f4: 97fff973    	bl	0x10140dcc0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2974>
10140f6f8: f94037e8    	ldr	x8, [sp, #0x68]
10140f6fc: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10140f700: eb09011f    	cmp	x8, x9
10140f704: 540000a1    	b.ne	0x10140f718 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x940>
10140f708: 52800108    	mov	w8, #0x8                ; =8
10140f70c: a900227f    	stp	xzr, x8, [x19]
10140f710: f9000a7f    	str	xzr, [x19, #0x10]
10140f714: 14000041    	b	0x10140f818 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xa40>
10140f718: 97da3bf6    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140f71c: 52803400    	mov	w0, #0x1a0              ; =416
10140f720: 52800101    	mov	w1, #0x8                ; =8
10140f724: 97da3bed    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140f728: b4000860    	cbz	x0, 0x10140f834 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xa5c>
10140f72c: aa0003f4    	mov	x20, x0
10140f730: 9101a3f6    	add	x22, sp, #0x68
10140f734: ad4206c0    	ldp	q0, q1, [x22, #0x40]
10140f738: ad020400    	stp	q0, q1, [x0, #0x40]
10140f73c: f94067e8    	ldr	x8, [sp, #0xc8]
10140f740: f9003008    	str	x8, [x0, #0x60]
10140f744: 3cc683e0    	ldur	q0, [sp, #0x68]
10140f748: 3cc783e1    	ldur	q1, [sp, #0x78]
10140f74c: ad000400    	stp	q0, q1, [x0]
10140f750: ad4102c1    	ldp	q1, q0, [x22, #0x20]
10140f754: ad010001    	stp	q1, q0, [x0, #0x20]
10140f758: 52800088    	mov	w8, #0x4                ; =4
10140f75c: a90503e8    	stp	x8, x0, [sp, #0x50]
10140f760: 52800035    	mov	w21, #0x1               ; =1
10140f764: f90033f5    	str	x21, [sp, #0x60]
10140f768: ad4107e0    	ldp	q0, q1, [sp, #0x20]
10140f76c: ad0787e0    	stp	q0, q1, [sp, #0xf0]
10140f770: 3dc013e0    	ldr	q0, [sp, #0x40]
10140f774: 3d8047e0    	str	q0, [sp, #0x110]
10140f778: ad4003e1    	ldp	q1, q0, [sp]
10140f77c: 52800d17    	mov	w23, #0x68              ; =104
10140f780: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
10140f784: ad0683e1    	stp	q1, q0, [sp, #0xd0]
10140f788: 1400000f    	b	0x10140f7c4 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x9ec>
10140f78c: 8b170288    	add	x8, x20, x23
10140f790: ad4606c0    	ldp	q0, q1, [x22, #0xc0]
10140f794: 3dc03ac2    	ldr	q2, [x22, #0xe0]
10140f798: ad008901    	stp	q1, q2, [x8, #0x10]
10140f79c: 3d800100    	str	q0, [x8]
10140f7a0: ad4786c0    	ldp	q0, q1, [x22, #0xf0]
10140f7a4: 3dc046c2    	ldr	q2, [x22, #0x110]
10140f7a8: f85b83a9    	ldur	x9, [x29, #-0x48]
10140f7ac: f9003109    	str	x9, [x8, #0x60]
10140f7b0: ad020901    	stp	q1, q2, [x8, #0x40]
10140f7b4: 3d800d00    	str	q0, [x8, #0x30]
10140f7b8: 910006b5    	add	x21, x21, #0x1
10140f7bc: f90033f5    	str	x21, [sp, #0x60]
10140f7c0: 9101a2f7    	add	x23, x23, #0x68
10140f7c4: d102a3a0    	sub	x0, x29, #0xa8
10140f7c8: 910343e1    	add	x1, sp, #0xd0
10140f7cc: 97fff93d    	bl	0x10140dcc0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x2974>
10140f7d0: f85583a8    	ldur	x8, [x29, #-0xa8]
10140f7d4: eb18011f    	cmp	x8, x24
10140f7d8: 54000180    	b.eq	0x10140f808 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xa30>
10140f7dc: f9402be8    	ldr	x8, [sp, #0x50]
10140f7e0: eb0802bf    	cmp	x21, x8
10140f7e4: 54fffd41    	b.ne	0x10140f78c <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x9b4>
10140f7e8: 910143e0    	add	x0, sp, #0x50
10140f7ec: aa1503e1    	mov	x1, x21
10140f7f0: 52800022    	mov	w2, #0x1                ; =1
10140f7f4: 52800103    	mov	w3, #0x8                ; =8
10140f7f8: 52800d04    	mov	w4, #0x68               ; =104
10140f7fc: 94186415    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10140f800: f9402ff4    	ldr	x20, [sp, #0x58]
10140f804: 17ffffe2    	b	0x10140f78c <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x9b4>
10140f808: 3dc017e0    	ldr	q0, [sp, #0x50]
10140f80c: 3d800260    	str	q0, [x19]
10140f810: f94033e8    	ldr	x8, [sp, #0x60]
10140f814: f9000a68    	str	x8, [x19, #0x10]
10140f818: a95d7bfd    	ldp	x29, x30, [sp, #0x1d0]
10140f81c: a95c4ff4    	ldp	x20, x19, [sp, #0x1c0]
10140f820: a95b57f6    	ldp	x22, x21, [sp, #0x1b0]
10140f824: a95a5ff8    	ldp	x24, x23, [sp, #0x1a0]
10140f828: a9596ffc    	ldp	x28, x27, [sp, #0x190]
10140f82c: 910783ff    	add	sp, sp, #0x1e0
10140f830: d65f03c0    	ret
10140f834: 52800100    	mov	w0, #0x8                ; =8
10140f838: 52803401    	mov	w1, #0x1a0              ; =416
10140f83c: 941acece    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140f840: d4200020    	brk	#0x1
10140f844: aa0003f3    	mov	x19, x0
10140f848: 9101a3e0    	add	x0, sp, #0x68
10140f84c: 97dbb7a3    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140f850: aa1303e0    	mov	x0, x19
10140f854: 941ae760    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140f858: aa0003f3    	mov	x19, x0
10140f85c: d102a3a0    	sub	x0, x29, #0xa8
10140f860: 97dbb79e    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140f864: 910143e0    	add	x0, sp, #0x50
10140f868: 9401197f    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140f86c: aa1303e0    	mov	x0, x19
10140f870: 941ae759    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140f874: aa0003f3    	mov	x19, x0
10140f878: 910143e0    	add	x0, sp, #0x50
10140f87c: 9401197a    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140f880: aa1303e0    	mov	x0, x19
10140f884: 941ae754    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140f888: aa0203e3    	mov	x3, x2
10140f88c: aa0103e2    	mov	x2, x1
10140f890: aa0003e1    	mov	x1, x0
10140f894: aa0803e0    	mov	x0, x8
10140f898: b0003e24    	adrp	x4, 0x101bd4000 <__ZN9zune_core10colorspace15ALL_COLORSPACES17h1bf93b46da0d6ab3E+0x26830>
10140f89c: 9118e084    	add	x4, x4, #0x638
10140f8a0: 52800105    	mov	w5, #0x8                ; =8
10140f8a4: 17ffff00    	b	0x10140f4a4 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0x6cc>
10140f8a8: d10783ff    	sub	sp, sp, #0x1e0
10140f8ac: a9196ffc    	stp	x28, x27, [sp, #0x190]
10140f8b0: a91a5ff8    	stp	x24, x23, [sp, #0x1a0]
10140f8b4: a91b57f6    	stp	x22, x21, [sp, #0x1b0]
10140f8b8: a91c4ff4    	stp	x20, x19, [sp, #0x1c0]
10140f8bc: a91d7bfd    	stp	x29, x30, [sp, #0x1d0]
10140f8c0: 910743fd    	add	x29, sp, #0x1d0
10140f8c4: aa0803f3    	mov	x19, x8
10140f8c8: a90103e1    	stp	x1, x0, [sp, #0x10]
10140f8cc: a9027fe1    	stp	x1, xzr, [sp, #0x20]
10140f8d0: f9001be1    	str	x1, [sp, #0x30]
10140f8d4: 0f000540    	movi.2s	v0, #0xa
10140f8d8: fd001fe0    	str	d0, [sp, #0x38]
10140f8dc: 52800028    	mov	w8, #0x1                ; =1
10140f8e0: 390103e8    	strb	w8, [sp, #0x40]
10140f8e4: 790093ff    	strh	wzr, [sp, #0x48]
10140f8e8: a9007fe2    	stp	x2, xzr, [sp]
10140f8ec: 9101a3e0    	add	x0, sp, #0x68
10140f8f0: 910003e1    	mov	x1, sp
10140f8f4: 97fff43f    	bl	0x10140c9f0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x16a4>
10140f8f8: f94037e8    	ldr	x8, [sp, #0x68]
10140f8fc: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10140f900: eb09011f    	cmp	x8, x9
10140f904: 540000a1    	b.ne	0x10140f918 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xb40>
10140f908: 52800108    	mov	w8, #0x8                ; =8
10140f90c: a900227f    	stp	xzr, x8, [x19]
10140f910: f9000a7f    	str	xzr, [x19, #0x10]
10140f914: 14000041    	b	0x10140fa18 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xc40>
10140f918: 97da3b76    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140f91c: 52803400    	mov	w0, #0x1a0              ; =416
10140f920: 52800101    	mov	w1, #0x8                ; =8
10140f924: 97da3b6d    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140f928: b4000860    	cbz	x0, 0x10140fa34 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xc5c>
10140f92c: aa0003f4    	mov	x20, x0
10140f930: 9101a3f6    	add	x22, sp, #0x68
10140f934: ad4206c0    	ldp	q0, q1, [x22, #0x40]
10140f938: ad020400    	stp	q0, q1, [x0, #0x40]
10140f93c: f94067e8    	ldr	x8, [sp, #0xc8]
10140f940: f9003008    	str	x8, [x0, #0x60]
10140f944: 3cc683e0    	ldur	q0, [sp, #0x68]
10140f948: 3cc783e1    	ldur	q1, [sp, #0x78]
10140f94c: ad000400    	stp	q0, q1, [x0]
10140f950: ad4102c1    	ldp	q1, q0, [x22, #0x20]
10140f954: ad010001    	stp	q1, q0, [x0, #0x20]
10140f958: 52800088    	mov	w8, #0x4                ; =4
10140f95c: a90503e8    	stp	x8, x0, [sp, #0x50]
10140f960: 52800035    	mov	w21, #0x1               ; =1
10140f964: f90033f5    	str	x21, [sp, #0x60]
10140f968: ad4107e0    	ldp	q0, q1, [sp, #0x20]
10140f96c: ad0787e0    	stp	q0, q1, [sp, #0xf0]
10140f970: 3dc013e0    	ldr	q0, [sp, #0x40]
10140f974: 3d8047e0    	str	q0, [sp, #0x110]
10140f978: ad4003e1    	ldp	q1, q0, [sp]
10140f97c: 52800d17    	mov	w23, #0x68              ; =104
10140f980: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
10140f984: ad0683e1    	stp	q1, q0, [sp, #0xd0]
10140f988: 1400000f    	b	0x10140f9c4 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xbec>
10140f98c: 8b170288    	add	x8, x20, x23
10140f990: ad4606c0    	ldp	q0, q1, [x22, #0xc0]
10140f994: 3dc03ac2    	ldr	q2, [x22, #0xe0]
10140f998: ad008901    	stp	q1, q2, [x8, #0x10]
10140f99c: 3d800100    	str	q0, [x8]
10140f9a0: ad4786c0    	ldp	q0, q1, [x22, #0xf0]
10140f9a4: 3dc046c2    	ldr	q2, [x22, #0x110]
10140f9a8: f85b83a9    	ldur	x9, [x29, #-0x48]
10140f9ac: f9003109    	str	x9, [x8, #0x60]
10140f9b0: ad020901    	stp	q1, q2, [x8, #0x40]
10140f9b4: 3d800d00    	str	q0, [x8, #0x30]
10140f9b8: 910006b5    	add	x21, x21, #0x1
10140f9bc: f90033f5    	str	x21, [sp, #0x60]
10140f9c0: 9101a2f7    	add	x23, x23, #0x68
10140f9c4: d102a3a0    	sub	x0, x29, #0xa8
10140f9c8: 910343e1    	add	x1, sp, #0xd0
10140f9cc: 97fff409    	bl	0x10140c9f0 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x16a4>
10140f9d0: f85583a8    	ldur	x8, [x29, #-0xa8]
10140f9d4: eb18011f    	cmp	x8, x24
10140f9d8: 54000180    	b.eq	0x10140fa08 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xc30>
10140f9dc: f9402be8    	ldr	x8, [sp, #0x50]
10140f9e0: eb0802bf    	cmp	x21, x8
10140f9e4: 54fffd41    	b.ne	0x10140f98c <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xbb4>
10140f9e8: 910143e0    	add	x0, sp, #0x50
10140f9ec: aa1503e1    	mov	x1, x21
10140f9f0: 52800022    	mov	w2, #0x1                ; =1
10140f9f4: 52800103    	mov	w3, #0x8                ; =8
10140f9f8: 52800d04    	mov	w4, #0x68               ; =104
10140f9fc: 94186395    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10140fa00: f9402ff4    	ldr	x20, [sp, #0x58]
10140fa04: 17ffffe2    	b	0x10140f98c <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xbb4>
10140fa08: 3dc017e0    	ldr	q0, [sp, #0x50]
10140fa0c: 3d800260    	str	q0, [x19]
10140fa10: f94033e8    	ldr	x8, [sp, #0x60]
10140fa14: f9000a68    	str	x8, [x19, #0x10]
10140fa18: a95d7bfd    	ldp	x29, x30, [sp, #0x1d0]
10140fa1c: a95c4ff4    	ldp	x20, x19, [sp, #0x1c0]
10140fa20: a95b57f6    	ldp	x22, x21, [sp, #0x1b0]
10140fa24: a95a5ff8    	ldp	x24, x23, [sp, #0x1a0]
10140fa28: a9596ffc    	ldp	x28, x27, [sp, #0x190]
10140fa2c: 910783ff    	add	sp, sp, #0x1e0
10140fa30: d65f03c0    	ret
10140fa34: 52800100    	mov	w0, #0x8                ; =8
10140fa38: 52803401    	mov	w1, #0x1a0              ; =416
10140fa3c: 941ace4e    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140fa40: d4200020    	brk	#0x1
10140fa44: aa0003f3    	mov	x19, x0
10140fa48: 9101a3e0    	add	x0, sp, #0x68
10140fa4c: 97dbb723    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140fa50: aa1303e0    	mov	x0, x19
10140fa54: 941ae6e0    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140fa58: aa0003f3    	mov	x19, x0
10140fa5c: d102a3a0    	sub	x0, x29, #0xa8
10140fa60: 97dbb71e    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140fa64: 910143e0    	add	x0, sp, #0x50
10140fa68: 940118ff    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140fa6c: aa1303e0    	mov	x0, x19
10140fa70: 941ae6d9    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140fa74: aa0003f3    	mov	x19, x0
10140fa78: 910143e0    	add	x0, sp, #0x50
10140fa7c: 940118fa    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140fa80: aa1303e0    	mov	x0, x19
10140fa84: 941ae6d4    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140fa88: d10783ff    	sub	sp, sp, #0x1e0
10140fa8c: a9196ffc    	stp	x28, x27, [sp, #0x190]
10140fa90: a91a5ff8    	stp	x24, x23, [sp, #0x1a0]
10140fa94: a91b57f6    	stp	x22, x21, [sp, #0x1b0]
10140fa98: a91c4ff4    	stp	x20, x19, [sp, #0x1c0]
10140fa9c: a91d7bfd    	stp	x29, x30, [sp, #0x1d0]
10140faa0: 910743fd    	add	x29, sp, #0x1d0
10140faa4: aa0803f3    	mov	x19, x8
10140faa8: a90103e1    	stp	x1, x0, [sp, #0x10]
10140faac: a9027fe1    	stp	x1, xzr, [sp, #0x20]
10140fab0: f9001be1    	str	x1, [sp, #0x30]
10140fab4: 0f000540    	movi.2s	v0, #0xa
10140fab8: fd001fe0    	str	d0, [sp, #0x38]
10140fabc: 52800028    	mov	w8, #0x1                ; =1
10140fac0: 390103e8    	strb	w8, [sp, #0x40]
10140fac4: 790093ff    	strh	wzr, [sp, #0x48]
10140fac8: a9007fe2    	stp	x2, xzr, [sp]
10140facc: 9101a3e0    	add	x0, sp, #0x68
10140fad0: 910003e1    	mov	x1, sp
10140fad4: 97fff27c    	bl	0x10140c4c4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x1178>
10140fad8: f94037e8    	ldr	x8, [sp, #0x68]
10140fadc: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10140fae0: eb09011f    	cmp	x8, x9
10140fae4: 540000a1    	b.ne	0x10140faf8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xd20>
10140fae8: 52800108    	mov	w8, #0x8                ; =8
10140faec: a900227f    	stp	xzr, x8, [x19]
10140faf0: f9000a7f    	str	xzr, [x19, #0x10]
10140faf4: 14000041    	b	0x10140fbf8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xe20>
10140faf8: 97da3afe    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140fafc: 52803400    	mov	w0, #0x1a0              ; =416
10140fb00: 52800101    	mov	w1, #0x8                ; =8
10140fb04: 97da3af5    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140fb08: b4000860    	cbz	x0, 0x10140fc14 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xe3c>
10140fb0c: aa0003f4    	mov	x20, x0
10140fb10: 9101a3f6    	add	x22, sp, #0x68
10140fb14: ad4206c0    	ldp	q0, q1, [x22, #0x40]
10140fb18: ad020400    	stp	q0, q1, [x0, #0x40]
10140fb1c: f94067e8    	ldr	x8, [sp, #0xc8]
10140fb20: f9003008    	str	x8, [x0, #0x60]
10140fb24: 3cc683e0    	ldur	q0, [sp, #0x68]
10140fb28: 3cc783e1    	ldur	q1, [sp, #0x78]
10140fb2c: ad000400    	stp	q0, q1, [x0]
10140fb30: ad4102c1    	ldp	q1, q0, [x22, #0x20]
10140fb34: ad010001    	stp	q1, q0, [x0, #0x20]
10140fb38: 52800088    	mov	w8, #0x4                ; =4
10140fb3c: a90503e8    	stp	x8, x0, [sp, #0x50]
10140fb40: 52800035    	mov	w21, #0x1               ; =1
10140fb44: f90033f5    	str	x21, [sp, #0x60]
10140fb48: ad4107e0    	ldp	q0, q1, [sp, #0x20]
10140fb4c: ad0787e0    	stp	q0, q1, [sp, #0xf0]
10140fb50: 3dc013e0    	ldr	q0, [sp, #0x40]
10140fb54: 3d8047e0    	str	q0, [sp, #0x110]
10140fb58: ad4003e1    	ldp	q1, q0, [sp]
10140fb5c: 52800d17    	mov	w23, #0x68              ; =104
10140fb60: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
10140fb64: ad0683e1    	stp	q1, q0, [sp, #0xd0]
10140fb68: 1400000f    	b	0x10140fba4 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xdcc>
10140fb6c: 8b170288    	add	x8, x20, x23
10140fb70: ad4606c0    	ldp	q0, q1, [x22, #0xc0]
10140fb74: 3dc03ac2    	ldr	q2, [x22, #0xe0]
10140fb78: ad008901    	stp	q1, q2, [x8, #0x10]
10140fb7c: 3d800100    	str	q0, [x8]
10140fb80: ad4786c0    	ldp	q0, q1, [x22, #0xf0]
10140fb84: 3dc046c2    	ldr	q2, [x22, #0x110]
10140fb88: f85b83a9    	ldur	x9, [x29, #-0x48]
10140fb8c: f9003109    	str	x9, [x8, #0x60]
10140fb90: ad020901    	stp	q1, q2, [x8, #0x40]
10140fb94: 3d800d00    	str	q0, [x8, #0x30]
10140fb98: 910006b5    	add	x21, x21, #0x1
10140fb9c: f90033f5    	str	x21, [sp, #0x60]
10140fba0: 9101a2f7    	add	x23, x23, #0x68
10140fba4: d102a3a0    	sub	x0, x29, #0xa8
10140fba8: 910343e1    	add	x1, sp, #0xd0
10140fbac: 97fff246    	bl	0x10140c4c4 <__ZN111_$LT$otty_autocomplete..fix..rules..SuggestedCommandRule$u20$as$u20$otty_autocomplete..fix..rules..CodeRule$GT$5apply17h5d1d969af825ba53E+0x1178>
10140fbb0: f85583a8    	ldur	x8, [x29, #-0xa8]
10140fbb4: eb18011f    	cmp	x8, x24
10140fbb8: 54000180    	b.eq	0x10140fbe8 <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xe10>
10140fbbc: f9402be8    	ldr	x8, [sp, #0x50]
10140fbc0: eb0802bf    	cmp	x21, x8
10140fbc4: 54fffd41    	b.ne	0x10140fb6c <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xd94>
10140fbc8: 910143e0    	add	x0, sp, #0x50
10140fbcc: aa1503e1    	mov	x1, x21
10140fbd0: 52800022    	mov	w2, #0x1                ; =1
10140fbd4: 52800103    	mov	w3, #0x8                ; =8
10140fbd8: 52800d04    	mov	w4, #0x68               ; =104
10140fbdc: 9418631d    	bl	0x101a28850 <__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hede53f5fc84b4154E+0x12c>
10140fbe0: f9402ff4    	ldr	x20, [sp, #0x58]
10140fbe4: 17ffffe2    	b	0x10140fb6c <__ZN17otty_autocomplete10generators16GeneratorContext8has_time17hd96530495b279787E+0xd94>
10140fbe8: 3dc017e0    	ldr	q0, [sp, #0x50]
10140fbec: 3d800260    	str	q0, [x19]
10140fbf0: f94033e8    	ldr	x8, [sp, #0x60]
10140fbf4: f9000a68    	str	x8, [x19, #0x10]
10140fbf8: a95d7bfd    	ldp	x29, x30, [sp, #0x1d0]
10140fbfc: a95c4ff4    	ldp	x20, x19, [sp, #0x1c0]
10140fc00: a95b57f6    	ldp	x22, x21, [sp, #0x1b0]
10140fc04: a95a5ff8    	ldp	x24, x23, [sp, #0x1a0]
10140fc08: a9596ffc    	ldp	x28, x27, [sp, #0x190]
10140fc0c: 910783ff    	add	sp, sp, #0x1e0
10140fc10: d65f03c0    	ret
10140fc14: 52800100    	mov	w0, #0x8                ; =8
10140fc18: 52803401    	mov	w1, #0x1a0              ; =416
10140fc1c: 941acdd6    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140fc20: d4200020    	brk	#0x1
10140fc24: aa0003f3    	mov	x19, x0
10140fc28: 9101a3e0    	add	x0, sp, #0x68
10140fc2c: 97dbb6ab    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140fc30: aa1303e0    	mov	x0, x19
10140fc34: 941ae668    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140fc38: aa0003f3    	mov	x19, x0
10140fc3c: d102a3a0    	sub	x0, x29, #0xa8
10140fc40: 97dbb6a6    	bl	0x100afd6d8 <__ZN13otty_activity8now_secs17h5c78a44b09e241ebE+0xd6c>
10140fc44: 910143e0    	add	x0, sp, #0x50
10140fc48: 94011887    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140fc4c: aa1303e0    	mov	x0, x19
10140fc50: 941ae661    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140fc54: aa0003f3    	mov	x19, x0
10140fc58: 910143e0    	add	x0, sp, #0x50
10140fc5c: 94011882    	bl	0x101455e64 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x89dc>
10140fc60: aa1303e0    	mov	x0, x19
10140fc64: 941ae65c    	bl	0x101ac95d4 <_writev+0x101ac95d4>

000000010140fc68 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E>:
10140fc68: d10183ff    	sub	sp, sp, #0x60
10140fc6c: a9025ff8    	stp	x24, x23, [sp, #0x20]
10140fc70: a90357f6    	stp	x22, x21, [sp, #0x30]
10140fc74: a9044ff4    	stp	x20, x19, [sp, #0x40]
10140fc78: a9057bfd    	stp	x29, x30, [sp, #0x50]
10140fc7c: 910143fd    	add	x29, sp, #0x50
10140fc80: aa0103f4    	mov	x20, x1
10140fc84: aa0003f5    	mov	x21, x0
10140fc88: aa0803f3    	mov	x19, x8
10140fc8c: b40001c2    	cbz	x2, 0x10140fcc4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c>
10140fc90: aa0303f6    	mov	x22, x3
10140fc94: b4000183    	cbz	x3, 0x10140fcc4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c>
10140fc98: eb16029f    	cmp	x20, x22
10140fc9c: 54000101    	b.ne	0x10140fcbc <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x54>
10140fca0: aa1503e0    	mov	x0, x21
10140fca4: aa0203e1    	mov	x1, x2
10140fca8: aa0203f7    	mov	x23, x2
10140fcac: aa1403e2    	mov	x2, x20
10140fcb0: 941ae7db    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10140fcb4: aa1703e2    	mov	x2, x23
10140fcb8: 34000600    	cbz	w0, 0x10140fd78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x110>
10140fcbc: eb160297    	subs	x23, x20, x22
10140fcc0: 54000302    	b.hs	0x10140fd20 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xb8>
10140fcc4: b4000154    	cbz	x20, 0x10140fcec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x84>
10140fcc8: 97da3a8a    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140fccc: aa1403e0    	mov	x0, x20
10140fcd0: 52800021    	mov	w1, #0x1                ; =1
10140fcd4: 97da3a81    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140fcd8: aa0003f6    	mov	x22, x0
10140fcdc: b50000a0    	cbnz	x0, 0x10140fcf0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x88>
10140fce0: 52800020    	mov	w0, #0x1                ; =1
10140fce4: aa1403e1    	mov	x1, x20
10140fce8: 941acda3    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140fcec: 52800036    	mov	w22, #0x1               ; =1
10140fcf0: aa1603e0    	mov	x0, x22
10140fcf4: aa1503e1    	mov	x1, x21
10140fcf8: aa1403e2    	mov	x2, x20
10140fcfc: 941ae7cb    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10140fd00: a9005a74    	stp	x20, x22, [x19]
10140fd04: f9000a74    	str	x20, [x19, #0x10]
10140fd08: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10140fd0c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10140fd10: a94357f6    	ldp	x22, x21, [sp, #0x30]
10140fd14: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10140fd18: 910183ff    	add	sp, sp, #0x60
10140fd1c: d65f03c0    	ret
10140fd20: aa0203e0    	mov	x0, x2
10140fd24: aa1503e1    	mov	x1, x21
10140fd28: aa1603e2    	mov	x2, x22
10140fd2c: 941ae7bc    	bl	0x101ac9c1c <_writev+0x101ac9c1c>
10140fd30: 35fffca0    	cbnz	w0, 0x10140fcc4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c>
10140fd34: eb16029f    	cmp	x20, x22
10140fd38: 54fffc60    	b.eq	0x10140fcc4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c>
10140fd3c: 8b1602a8    	add	x8, x21, x22
10140fd40: 39400109    	ldrb	w9, [x8]
10140fd44: 7100bd3f    	cmp	w9, #0x2f
10140fd48: 54fffbe1    	b.ne	0x10140fcc4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x5c>
10140fd4c: a9005fe8    	stp	x8, x23, [sp]
10140fd50: 910003e8    	mov	x8, sp
10140fd54: 90000209    	adrp	x9, 0x10144f000 <__ZN3std3sys9backtrace28__rust_begin_short_backtrace17he3717dc22ec2778aE+0x1b78>
10140fd58: 91117129    	add	x9, x9, #0x45c
10140fd5c: a90127e8    	stp	x8, x9, [sp, #0x10]
10140fd60: 90005000    	adrp	x0, 0x101e0f000 <_writev+0x101e0f000>
10140fd64: 91398000    	add	x0, x0, #0xe60
10140fd68: 910043e1    	add	x1, sp, #0x10
10140fd6c: aa1303e8    	mov	x8, x19
10140fd70: 940fee04    	bl	0x10180b580 <__ZN5alloc3fmt6format12format_inner17h988a1f024d2ed724E>
10140fd74: 17ffffe5    	b	0x10140fd08 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xa0>
10140fd78: 97da3a5e    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140fd7c: 52800020    	mov	w0, #0x1                ; =1
10140fd80: 52800021    	mov	w1, #0x1                ; =1
10140fd84: 97da3a55    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140fd88: b40000e0    	cbz	x0, 0x10140fda4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x13c>
10140fd8c: 52800fc8    	mov	w8, #0x7e               ; =126
10140fd90: 39000008    	strb	w8, [x0]
10140fd94: 52800028    	mov	w8, #0x1                ; =1
10140fd98: a9000268    	stp	x8, x0, [x19]
10140fd9c: f9000a68    	str	x8, [x19, #0x10]
10140fda0: 17ffffda    	b	0x10140fd08 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0xa0>
10140fda4: 52800020    	mov	w0, #0x1                ; =1
10140fda8: 52800021    	mov	w1, #0x1                ; =1
10140fdac: 941acd72    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140fdb0: d101c3ff    	sub	sp, sp, #0x70
10140fdb4: a9035ff8    	stp	x24, x23, [sp, #0x30]
10140fdb8: a90457f6    	stp	x22, x21, [sp, #0x40]
10140fdbc: a9054ff4    	stp	x20, x19, [sp, #0x50]
10140fdc0: a9067bfd    	stp	x29, x30, [sp, #0x60]
10140fdc4: 910183fd    	add	x29, sp, #0x60
10140fdc8: aa0003f4    	mov	x20, x0
10140fdcc: 910003e8    	mov	x8, sp
10140fdd0: 94062bf3    	bl	0x10159ad9c <__ZN11otty_config6Config13user_home_dir17hfc53f12b1c41c57eE>
10140fdd4: f94003f3    	ldr	x19, [sp]
10140fdd8: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140fddc: eb08027f    	cmp	x19, x8
10140fde0: 54000061    	b.ne	0x10140fdec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x184>
10140fde4: f9000288    	str	x8, [x20]
10140fde8: 14000023    	b	0x10140fe74 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x20c>
10140fdec: a94087f5    	ldp	x21, x1, [sp, #0x8]
10140fdf0: 910063e8    	add	x8, sp, #0x18
10140fdf4: aa1503e0    	mov	x0, x21
10140fdf8: 940ffa69    	bl	0x10180e79c <__ZN5alloc6string6String15from_utf8_lossy17hcb81682812c4da7aE>
10140fdfc: a941dff8    	ldp	x24, x23, [sp, #0x18]
10140fe00: f94017f6    	ldr	x22, [sp, #0x28]
10140fe04: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10140fe08: eb08031f    	cmp	x24, x8
10140fe0c: 54000261    	b.ne	0x10140fe58 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1f0>
10140fe10: b4000176    	cbz	x22, 0x10140fe3c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1d4>
10140fe14: 97da3a37    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140fe18: aa1603e0    	mov	x0, x22
10140fe1c: 52800021    	mov	w1, #0x1                ; =1
10140fe20: 97da3a2e    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140fe24: aa0003f8    	mov	x24, x0
10140fe28: b50000c0    	cbnz	x0, 0x10140fe40 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x1d8>
10140fe2c: 52800020    	mov	w0, #0x1                ; =1
10140fe30: aa1603e1    	mov	x1, x22
10140fe34: 941acd50    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140fe38: d4200020    	brk	#0x1
10140fe3c: 52800038    	mov	w24, #0x1               ; =1
10140fe40: aa1803e0    	mov	x0, x24
10140fe44: aa1703e1    	mov	x1, x23
10140fe48: aa1603e2    	mov	x2, x22
10140fe4c: 941ae777    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10140fe50: aa1803f7    	mov	x23, x24
10140fe54: aa1603f8    	mov	x24, x22
10140fe58: b40000b3    	cbz	x19, 0x10140fe6c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x204>
10140fe5c: aa1503e0    	mov	x0, x21
10140fe60: aa1303e1    	mov	x1, x19
10140fe64: 52800022    	mov	w2, #0x1                ; =1
10140fe68: 97da3a1d    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140fe6c: a9005e98    	stp	x24, x23, [x20]
10140fe70: f9000a96    	str	x22, [x20, #0x10]
10140fe74: a9467bfd    	ldp	x29, x30, [sp, #0x60]
10140fe78: a9454ff4    	ldp	x20, x19, [sp, #0x50]
10140fe7c: a94457f6    	ldp	x22, x21, [sp, #0x40]
10140fe80: a9435ff8    	ldp	x24, x23, [sp, #0x30]
10140fe84: 9101c3ff    	add	sp, sp, #0x70
10140fe88: d65f03c0    	ret
10140fe8c: aa0003f4    	mov	x20, x0
10140fe90: b40000b3    	cbz	x19, 0x10140fea4 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x23c>
10140fe94: aa1503e0    	mov	x0, x21
10140fe98: aa1303e1    	mov	x1, x19
10140fe9c: 52800022    	mov	w2, #0x1                ; =1
10140fea0: 97da3a0f    	bl	0x100a9e6dc <__RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
10140fea4: aa1403e0    	mov	x0, x20
10140fea8: 941ae5cb    	bl	0x101ac95d4 <_writev+0x101ac95d4>
10140feac: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
10140feb0: a9014ff4    	stp	x20, x19, [sp, #0x10]
10140feb4: a9027bfd    	stp	x29, x30, [sp, #0x20]
10140feb8: 910083fd    	add	x29, sp, #0x20
10140febc: aa0203f3    	mov	x19, x2
10140fec0: aa0003f4    	mov	x20, x0
10140fec4: f100085f    	cmp	x2, #0x2
10140fec8: 54000403    	b.lo	0x10140ff48 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2e0>
10140fecc: 39400028    	ldrb	w8, [x1]
10140fed0: 7100891f    	cmp	w8, #0x22
10140fed4: 540000c1    	b.ne	0x10140feec <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x284>
10140fed8: 8b130028    	add	x8, x1, x19
10140fedc: 385ff108    	ldurb	w8, [x8, #-0x1]
10140fee0: 7100891f    	cmp	w8, #0x22
10140fee4: 54000100    	b.eq	0x10140ff04 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x29c>
10140fee8: 39400028    	ldrb	w8, [x1]
10140feec: 71009d1f    	cmp	w8, #0x27
10140fef0: 540002e1    	b.ne	0x10140ff4c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2e4>
10140fef4: 8b130028    	add	x8, x1, x19
10140fef8: 385ff108    	ldurb	w8, [x8, #-0x1]
10140fefc: 71009d1f    	cmp	w8, #0x27
10140ff00: 54000261    	b.ne	0x10140ff4c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x2e4>
10140ff04: d1000663    	sub	x3, x19, #0x1
10140ff08: aa0103f6    	mov	x22, x1
10140ff0c: 38c01ec8    	ldrsb	w8, [x22, #0x1]!
10140ff10: 3101011f    	cmn	w8, #0x40
10140ff14: 540004eb    	b.lt	0x10140ffb0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x348>
10140ff18: 38e36828    	ldrsb	w8, [x1, x3]
10140ff1c: 3101011f    	cmn	w8, #0x40
10140ff20: 5400048b    	b.lt	0x10140ffb0 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x348>
10140ff24: f1000a73    	subs	x19, x19, #0x2
10140ff28: 540002e0    	b.eq	0x10140ff84 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x31c>
10140ff2c: 97da39f1    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140ff30: aa1303e0    	mov	x0, x19
10140ff34: 52800021    	mov	w1, #0x1                ; =1
10140ff38: 97da39e8    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140ff3c: aa0003f5    	mov	x21, x0
10140ff40: b5000240    	cbnz	x0, 0x10140ff88 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x320>
10140ff44: 1400000a    	b	0x10140ff6c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x304>
10140ff48: b4000193    	cbz	x19, 0x10140ff78 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x310>
10140ff4c: aa0103f5    	mov	x21, x1
10140ff50: 97da39e8    	bl	0x100a9e6f0 <__RNvCsdBezzDwma51_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10140ff54: aa1303e0    	mov	x0, x19
10140ff58: 52800021    	mov	w1, #0x1                ; =1
10140ff5c: 97da39df    	bl	0x100a9e6d8 <__RNvCsdBezzDwma51_7___rustc12___rust_alloc>
10140ff60: aa1503e1    	mov	x1, x21
10140ff64: aa0003f5    	mov	x21, x0
10140ff68: b50000a0    	cbnz	x0, 0x10140ff7c <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x314>
10140ff6c: 52800020    	mov	w0, #0x1                ; =1
10140ff70: aa1303e1    	mov	x1, x19
10140ff74: 941acd00    	bl	0x101ac3374 <__ZN5alloc7raw_vec12handle_error17h2d2c5c9552d6042aE>
10140ff78: 52800035    	mov	w21, #0x1               ; =1
10140ff7c: aa1503e0    	mov	x0, x21
10140ff80: 14000004    	b	0x10140ff90 <__ZN17otty_autocomplete10generators4jump11pretty_path17h027923c322605258E+0x328>
10140ff84: 52800035    	mov	w21, #0x1               ; =1
10140ff88: aa1503e0    	mov	x0, x21
10140ff8c: aa1603e1    	mov	x1, x22
10140ff90: aa1303e2    	mov	x2, x19
10140ff94: 941ae725    	bl	0x101ac9c28 <_writev+0x101ac9c28>
10140ff98: a9005693    	stp	x19, x21, [x20]
10140ff9c: f9000a93    	str	x19, [x20, #0x10]
10140ffa0: a9427bfd    	ldp	x29, x30, [sp, #0x20]
10140ffa4: a9414ff4    	ldp	x20, x19, [sp, #0x10]
10140ffa8: a8c357f6    	ldp	x22, x21, [sp], #0x30
10140ffac: d65f03c0    	ret
10140ffb0: b00072c4    	adrp	x4, 0x102268000 <__ZN21pulldown_cmark_escape9HEX_CHARS17ha5b471f2f57c8639E+0x51b8>
10140ffb4: 9122e084    	add	x4, x4, #0x8b8
10140ffb8: aa0103e0    	mov	x0, x1
10140ffbc: aa1303e1    	mov	x1, x19
10140ffc0: 52800022    	mov	w2, #0x1                ; =1
10140ffc4: 941acd91    	bl	0x101ac3608 <__ZN4core3str16slice_error_fail17hc9b55ae2038fffb6E>
